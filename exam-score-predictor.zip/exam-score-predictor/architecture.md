# Architecture & Data Flow

## Pipeline Overview (from main.py)

The Exam Score Predictor implements a classic end-to-end supervised regression pipeline:

```
[exam_scores.csv]
       │
       ▼
 [Data Ingestion] ────► pd.read_csv()
       │
       ▼
[Feature & Target] ───► X = df[["hours_studied"]] (2D DataFrame)
                        y = df["exam_score"] (1D Series)
       │
       ▼
[Train/Test Split] ───► train_test_split(test_size=0.25, random_state=42)
                        ├── X_train (21 samples), y_train (21 samples)
                        └── X_test (7 samples), y_test (7 samples)
       │
       ▼
[Model Training] ─────► LinearRegression().fit(X_train, y_train)
                        ├── Learned Slope: coef_[0] ≈ 5.28
                        └── Learned Intercept: intercept_ ≈ 35.85
       │
       ▼
  [Evaluation] ───────► MAE ≈ 4.32 points, R² ≈ 0.85 (evaluated on test set)
       │
       ▼
  [Inference] ────────► Predict on benchmark 6.0 hours: 67.51 points
       │
       ▼
 [Visualization] ─────► matplotlib: scatter plot + regression line + 6-hour star
       │
       ▼
[Persistence] ────────► Save outputs/exam_score_regression.png & outputs/metrics.txt
```

## Key Pipeline Components

1. **Imports & Environment Configuration**: Configures the headless `Agg` backend for matplotlib before pyplot import to enable reliable file-based rendering on any system.
2. **Directory & Path Resolution**: Uses `pathlib.Path(__file__).resolve().parent` to reliably locate `data/` and create `outputs/` regardless of the invocation directory.
3. **Data Ingestion**: Loads student study hours and exam scores into a pandas DataFrame.
4. **Data Preprocessing & Splitting**: Formats features into a 2D matrix structure required by scikit-learn and executes a 75/25 train/test split with seed 42.
5. **Model Estimation**: Uses Ordinary Least Squares (OLS) via `LinearRegression()` to determine the optimal slope and intercept.
6. **Model Validation**: Computes Mean Absolute Error (MAE) and Coefficient of Determination ($R^2$) exclusively on unseen test data.
7. **Simulation & Inference**: Creates a single-row DataFrame for 6.0 hours of study to test forward-looking inference.
8. **Visualization & Export**: Generates a high-resolution 150 DPI plot and writes metrics to disk for downstream reporting.

## Data Structures & Dimensionality

| Stage | Variable | Data Structure | Shape | Type | Description |
|---|---|---|---|---|---|
| Ingestion | `df` | `pandas.DataFrame` | `(28, 2)` | float64 | Full raw dataset |
| Features | `X` | `pandas.DataFrame` | `(28, 1)` | float64 | 2D feature matrix (`hours_studied`) |
| Target | `y` | `pandas.Series` | `(28,)` | float64 | 1D target vector (`exam_score`) |
| Training Split | `X_train`, `y_train` | DataFrame / Series | `(21, 1)` / `(21,)` | float64 | 75% subset used for model fitting |
| Testing Split | `X_test`, `y_test` | DataFrame / Series | `(7, 1)` / `(7,)` | float64 | 25% subset held out for validation |
| New Query | `pd.DataFrame({"hours_studied": [6.0]})` | `pandas.DataFrame` | `(1, 1)` | float64 | 2D query for single prediction |
