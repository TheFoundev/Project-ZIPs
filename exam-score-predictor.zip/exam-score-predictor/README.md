# Predict Your Exam Score: Linear Regression Educational Package

Welcome to the **Predict Your Exam Score** project. This educational package guides beginner AI and machine learning students through building, analyzing, and deploying a simple linear regression pipeline using real Python data science libraries.

## Project At A Glance
- **Subject**: Supervised Machine Learning (Simple Linear Regression)
- **Dataset**: `data/exam_scores.csv` (28 student records: study hours vs. exam scores)
- **Primary Feature ($X$)**: `hours_studied` (Continuous, range 1.5 - 9.9 hours)
- **Target Variable ($y$)**: `exam_score` (Continuous, range 35.4 - 92.1 points)
- **Algorithm**: Ordinary Least Squares (OLS) via `sklearn.linear_model.LinearRegression`
- **Benchmark Prediction**: Estimated exam score for a student studying 6.0 hours ($\approx 67.5\text{ points}$)
- **Performance**: MAE $\approx 4.32\text{ points}$, $R^2 \approx 0.85$

---

## What You Will Learn
1. **Machine Learning Foundations**: Understand how supervised regression differs fundamentally from classification and unsupervised clustering.
2. **Data Wrangling with pandas**: Read CSV records, compute summary statistics, and correctly structure 2D feature matrices and 1D target vectors.
3. **Model Training & Math**: Learn how Ordinary Least Squares fits the line of best fit ($y = mx + b$) and understand the real-world meaning of slope and intercept.
4. **Evaluation**: Measure accuracy on unseen test data using Mean Absolute Error (MAE) and Coefficient of Determination ($R^2$).
5. **Prediction & Inference**: Query the model with new study schedules to forecast expected academic outcomes.
6. **Data Storytelling & Visualization**: Construct clear, publication-quality regression plots highlighting training points, testing points, regression lines, and predictions.

---

## Directory Structure
```text
exam-score-predictor/
├── project.json                 # Project metadata & competencies
├── README.md                    # This master overview
├── architecture.md              # Detailed pipeline architecture & data flow
├── prerequisites.md             # Required tools, packages, and concepts
├── setup-guide.md               # Step-by-step setup and execution instructions
├── glossary.md                  # Comprehensive AI/ML glossary
├── references.json              # Official documentation and reading links
├── PROJECT_SUMMARY.md           # High-level summary for instructors & mentors
├── ALL_ASSESSMENT_ANSWERS.md    # Master reference of all assessment answers
├── final-project/               # Capstone project specifications
│   ├── requirements.md          # Comprehensive implementation requirements
│   ├── evaluation-rubric.json   # 105-point grading criteria
│   └── solution-guide.md        # Mentor solution guide & verification checkpoints
└── modules/                     # 6 In-Depth Learning Modules
    ├── module-01/               # Overview & Problem Understanding
    ├── module-02/               # Data Loading & Exploration
    ├── module-03/               # Linear Regression Algorithm & Math
    ├── module-04/               # Model Training & Prediction Mechanics
    ├── module-05/               # Evaluation & Visualization
    └── module-06/               # Complete Pipeline & Running
```

---

## Quick Start
To run the underlying reference implementation directly:

```bash
cd "beginner-projects-main/AI-ML Beginners/projects/06_exam_score"
pip install pandas numpy matplotlib scikit-learn
python main.py
```

Expected terminal output:
```text
============================================================
PREDICT YOUR EXAM SCORE
============================================================
Model: score = 5.28 x hours + 35.85
Mean absolute error: 4.3 points
R-squared: 0.85
Prediction for 6 hours: 67.5 points

Saved: outputs/exam_score_regression.png, outputs/metrics.txt
Try this: collect five real study-hour/score pairs and add them.
```

---

## How to Work Through This Course
1. **Read Lessons in Sequence**: Start with Module 1, Lesson 1 and proceed through Module 6, Lesson 4. Each lesson includes worked examples, code walkthroughs, and practical debugging tips.
2. **Complete Module Exercises**: Solidify concepts by implementing the practical hands-on exercises in each module's `exercises/` folder.
3. **Take Assessments**: Test your understanding with the 10 multiple-choice questions per module.
4. **Build the Final Project**: Rebuild the entire pipeline from scratch following `final-project/requirements.md` and verify your solution against `final-project/solution-guide.md`.
