# Setup Guide

## Step 1: Navigate to Project Directory
Open your terminal and navigate to the project directory:
```bash
cd "beginner-projects-main/AI-ML Beginners/projects/06_exam_score"
```

## Step 2: Set Up Python Virtual Environment (Recommended)
Creating an isolated environment keeps dependencies clean:
```bash
python3 -m venv venv
source venv/bin/activate  # On Windows use: venv\Scripts\activate
```

## Step 3: Install Required Libraries
Install the core data science and machine learning packages:
```bash
pip install pandas numpy matplotlib scikit-learn
```

Or install from a requirements file:
```bash
pip install -r requirements.txt
```

## Step 4: Verify the Dataset
Check that `data/exam_scores.csv` is present and properly formatted:
```bash
head -n 5 data/exam_scores.csv
```
You should see:
```text
hours_studied,exam_score
9.5,92.1
3.8,66.4
3.3,47.5
3.0,46.2
```

## Step 5: Run the Project
Execute `main.py` using Python:
```bash
python main.py
```

## Step 6: Verify Outputs
Check the console output and verify that output files have been generated:
- **Console**: Displays model equation ($5.28 \times \text{hours} + 35.85$), Mean Absolute Error ($4.3\text{ points}$), R-squared ($0.85$), and 6-hour prediction ($67.5\text{ points}$).
- **Plot**: `outputs/exam_score_regression.png` showing training data, test data, fitted regression line, and the 6-hour prediction star marker.
- **Metrics file**: `outputs/metrics.txt` containing the high-precision model parameters and evaluation metrics.
