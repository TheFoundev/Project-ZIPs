# Prerequisites

## Skills Required
- Basic Python syntax (functions, variables, imports, f-strings)
- Familiarity with reading CSV files
- Basic high school algebra: equation of a line ($y = mx + b$), slope, and intercept
- Familiarity with terminal commands (navigating directories, running scripts)

## Tools Required
- Python 3.8+ (Python 3.10+ recommended)
- `pip` package manager
- Terminal / Command Prompt / Shell
- Code editor (VS Code, Cursor, PyCharm, or text editor)

## Python Packages
- `pandas` (version 1.3+)
- `numpy` (version 1.20+)
- `matplotlib` (version 3.4+)
- `scikit-learn` (version 1.0+)

## Foundational Concepts to Review
- **What is a dataset?** A collection of rows (samples/observations) and columns (features/attributes).
- **Independent vs. Dependent variables:** Features ($X$, what you know) versus target ($y$, what you want to predict).
- **The Cartesian coordinate plane:** Plotting $(x, y)$ coordinate pairs where $x$ is horizontal (hours) and $y$ is vertical (exam score).
