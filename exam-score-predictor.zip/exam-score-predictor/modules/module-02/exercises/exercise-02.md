# Module 2 Exercises: Data Loading, Inspection & Partitioning

## Exercise 2.1: Robust Path Construction with pathlib (10 min)
**Objective:** Construct platform-agnostic, working-directory-independent paths in Python.

**Problem Statement:**
You are writing a script that needs to locate `data/exam_scores.csv` and create an output folder `outputs/`. If a user runs your script from outside the directory (e.g. from `/home/user` while the script is in `/home/user/project`), standard string paths like `"data/exam_scores.csv"` will crash. Implement the robust `pathlib` pattern from `main.py`.

**Requirements:**
1. Import `Path` from `pathlib`.
2. Define `BASE` using `Path(__file__).resolve().parent`.
3. Define `DATA` as `BASE / "data"` and `OUT` as `BASE / "outputs"`.
4. Call `.mkdir(exist_ok=True)` on `OUT`.
5. Check if `DATA / "exam_scores.csv"` exists using the `.exists()` method.

**Constraints:** Do not use `os.path` or raw string concatenation (`+`). Use pure `pathlib.Path`.

**Expected Behaviour:** A Python script or snippet that prints `True` for dataset existence and successfully creates the output folder.

**Acceptance Criteria:**
- [ ] `BASE` resolves the parent directory of `__file__`
- [ ] Path joins use the `/` operator
- [ ] Directory creation includes `exist_ok=True`
- [ ] Existence check confirms `exam_scores.csv` is present

**Hints:**
- Test with `python3 -c "from pathlib import Path; ..."` in the project folder.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes

---

## Exercise 2.2: Tabular Exploration & Summary Statistics (15 min)
**Objective:** Ingest `exam_scores.csv` and extract key statistical metrics.

**Problem Statement:**
Load the student exam scores dataset into a pandas DataFrame and extract essential summary statistics to verify data hygiene.

**Requirements:**
1. Load `data/exam_scores.csv` using `pd.read_csv()`.
2. Print the exact shape of the DataFrame.
3. Compute and print the mean, minimum, and maximum of `hours_studied`.
4. Compute and print the mean, minimum, and maximum of `exam_score`.
5. Check for null values across all columns using `.isna().sum()`.

**Constraints:** Use pandas DataFrame methods (`.shape`, `.describe()`, `.isna()`).

**Expected Behaviour:** Accurate output matching the project dataset: 28 rows, 0 nulls, hours mean ~5.39, scores mean ~65.10.

**Acceptance Criteria:**
- [ ] DataFrame shape confirmed as `(28, 2)`
- [ ] Hours studied range confirmed as 1.5 to 9.9
- [ ] Exam score range confirmed as 35.4 to 92.1
- [ ] Missing value counts confirmed as 0 for both columns

**Hints:**
- Use `df.describe()` to get all statistics at once.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes

---

## Exercise 2.3: Dimensionality Verification (X vs y) (15 min)
**Objective:** Verify 2D DataFrame vs. 1D Series extraction and observe scikit-learn's error behavior.

**Problem Statement:**
Demonstrate the practical difference between extracting features with single brackets versus double brackets, and prove why scikit-learn requires 2D features.

**Requirements:**
1. Extract `X_2d = df[["hours_studied"]]` and print its shape and `ndim`.
2. Extract `X_1d = df["hours_studied"]` and print its shape and `ndim`.
3. Extract `y = df["exam_score"]` and print its shape and `ndim`.
4. Attempt to fit a `LinearRegression()` model on `X_1d` and `y` inside a `try...except` block, capturing and printing the exact `ValueError` message.
5. Fit the model on `X_2d` and `y` to confirm successful training without error.

**Constraints:** Write a clean Python script demonstrating both failure and success cases.

**Expected Behaviour:** The script catches the `ValueError: Expected 2D array, got 1D array instead` when using `X_1d`, then fits cleanly with `X_2d`.

**Acceptance Criteria:**
- [ ] `X_2d.shape` verified as `(28, 1)` and `ndim` as 2
- [ ] `X_1d.shape` verified as `(28,)` and `ndim` as 1
- [ ] `y.shape` verified as `(28,)` and `ndim` as 1
- [ ] `ValueError` successfully captured and explained
- [ ] Clean fit with `X_2d` verified

**Hints:**
- `from sklearn.linear_model import LinearRegression` provides the estimator.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 2.4: Deterministic Train/Test Partitioning (15 min)
**Objective:** Implement `train_test_split` with exact reproducibility and analyze sample composition.

**Problem Statement:**
Split the 28-row dataset into training and testing sets using `test_size=0.25` and `random_state=42`. Inspect the resulting subsets and verify that no data leakage has occurred.

**Requirements:**
1. Call `train_test_split(X, y, test_size=0.25, random_state=42)`.
2. Verify that `len(X_train) == 21` and `len(X_test) == 7`.
3. Check the index intersection between `X_train` and `X_test` using `set(X_train.index).intersection(set(X_test.index))`. What should the intersection be?
4. Run the split twice with the same `random_state=42` and verify that the test indices are identical.
5. Print the mean study hours of `X_train` versus `X_test` and compare them.

**Constraints:** Use scikit-learn's `train_test_split`.

**Expected Behaviour:** Empty intersection (0 overlapping samples), exactly 21 train / 7 test rows, identical results across runs.

**Acceptance Criteria:**
- [ ] Split sizes confirmed as 21 and 7
- [ ] Index intersection confirmed as empty set `set()`
- [ ] Deterministic reproducibility across repeated calls confirmed
- [ ] Mean comparison shows balanced distribution between train and test

**Hints:**
- `X_train.index` gives the original row numbers preserved from the CSV.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes
