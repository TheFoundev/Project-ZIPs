# Lesson 01: Imports, Headless Backend Configuration, and Pathlib Setup

**Lesson ID:** lesson-01
**Module:** module-02
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why each library in `main.py` is imported
- Understand why `matplotlib.use("Agg")` must precede `import matplotlib.pyplot as plt`
- Construct robust, platform-agnostic file system paths using Python's `pathlib.Path`
- Safely create output directories using `.mkdir(exist_ok=True)`
- Avoid working directory pitfalls when executing Python scripts

## Prerequisites
- Completion of Module 01
- Basic understanding of Python module imports and file directories

## Concept Explanation

### The Anatomy of Imports in main.py
In professional data science pipelines, script execution begins with importing modular dependencies. In `main.py`, lines 10-20 bring together five specialized tools:
1. `from pathlib import Path`: Modern standard library utility for object-oriented filesystem paths.
2. `import matplotlib`: Base visualization package.
3. `import matplotlib.pyplot as plt`: High-level interface for creating charts and figures.
4. `import numpy as np`: Fundamental array computing library (used for linear coordinate spaces).
5. `import pandas as pd`: Tabular data analysis and manipulation library.
6. `from sklearn.linear_model import LinearRegression`: scikit-learn's Ordinary Least Squares estimator.
7. `from sklearn.metrics import mean_absolute_error, r2_score`: Regression evaluation functions.
8. `from sklearn.model_selection import train_test_split`: Data partitioning utility.

### Headless Rendering: Why matplotlib.use("Agg") Comes First
A frequent source of crashes in Python data science occurs when running scripts on headless Linux servers, Docker containers, remote SSH sessions, or automated test runners that lack a graphical monitor (GUI desktop).

By default, matplotlib attempts to load an interactive GUI backend (such as Qt, Tkinter, or GTK). If no display server (like X11 or Wayland) is found, matplotlib throws an error such as:
`_tkinter.TclError: no display name and no $DISPLAY environment variable`

To prevent this, `main.py` configures the **Agg** (Anti-Grain Geometry) backend:
```python
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
```
**CRITICAL RULE:** `matplotlib.use("Agg")` must be executed *before* importing `matplotlib.pyplot`. Once `pyplot` is imported, matplotlib binds to a default backend, and altering it later may emit warnings or fail silently.

### Platform-Neutral Paths with pathlib.Path
Beginner programmers often hardcode relative paths as strings, such as `"data/exam_scores.csv"`. 
However, if a user runs the script from their home directory (`python foundev/.../06_exam_score/main.py`), Python looks for `"data/exam_scores.csv"` inside the current terminal directory, causing a fatal `FileNotFoundError`.

In `main.py`, lines 22-25 resolve this elegantly:
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)
```
- `__file__`: Special Python variable holding the path of the currently executing script.
- `.resolve()`: Resolves any symbolic links and returns the absolute canonical path.
- `.parent`: Navigates to the directory containing `main.py`.
- `/`: The slash operator is overloaded by `pathlib` to join paths using the correct operating system separator (`/` on Linux/macOS, `\` on Windows).
- `OUT.mkdir(exist_ok=True)`: Creates the `outputs/` folder if it does not already exist; `exist_ok=True` suppresses errors if the folder already exists.

## Relevant Code (from main.py, lines 10-25)
```python
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)
```

### Code explanation
- The backend configuration is cleanly isolated at the very top of visualization imports.
- Global constants `BASE`, `DATA`, and `OUT` provide uniform, immutable reference points for the entire pipeline.
- Directory generation happens immediately at module load time, guaranteeing downstream save operations will succeed.

## Worked Example

**Problem:** Suppose your script is located at `/projects/06_exam_score/main.py`. What are the absolute paths evaluated for `BASE`, `DATA`, and `DATA / "exam_scores.csv"`?
**Solution:**
1. `__file__` is `"/projects/06_exam_score/main.py"`.
2. `Path(__file__).resolve().parent` strips `main.py`, resulting in `BASE = Path("/projects/06_exam_score")`.
3. `BASE / "data"` resolves to `Path("/projects/06_exam_score/data")`.
4. `DATA / "exam_scores.csv"` resolves to `Path("/projects/06_exam_score/data/exam_scores.csv")`.
No matter which directory the user opens in their terminal, the dataset path will always be 100% accurate.

## Step-by-Step Student Instructions
1. Open terminal and start python3 interactive shell:
   ```bash
   python3
   ```
2. Test importing pathlib and inspecting your current location:
   ```python
   from pathlib import Path
   import os
   print("CWD:", Path.cwd())
   ```
3. Test creating a temporary directory using `mkdir`:
   ```python
   temp_dir = Path("test_output")
   temp_dir.mkdir(exist_ok=True)
   print("Directory exists:", temp_dir.exists())
   temp_dir.mkdir(exist_ok=True) # Confirm no error on second call
   temp_dir.rmdir() # Clean up
   ```
4. Test the matplotlib backend check:
   ```python
   import matplotlib
   matplotlib.use("Agg")
   import matplotlib.pyplot as plt
   print("Current backend:", matplotlib.get_backend())
   ```
5. Confirm that `matplotlib.get_backend()` prints `'Agg'`.

## Expected Output or Observable Behaviour
```text
Current backend: agg
```
The output confirms that the non-interactive Agg engine is active.

## Practical Exercises
**Exercise 1.1:** What error occurs if you call `temp_dir.mkdir(exist_ok=False)` when `temp_dir` already exists?
**Exercise 1.2:** Why is using `Path(__file__).resolve().parent` safer than using `Path.cwd()`?
**Exercise 1.3:** Write a 2-line Python snippet to verify that `data/exam_scores.csv` exists using `pathlib`.

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Importing `pyplot` before setting backend | Matplotlib locks in the default GUI backend; `matplotlib.use()` will either fail or raise a UserWarning | Call `matplotlib.use("Agg")` before `import matplotlib.pyplot as plt` |
| Using string concatenation for paths: `BASE + "/data"` | `BASE` is a `Path` object, not a string; `+` raises a `TypeError` | Use the division operator `BASE / "data"` |
| Forgetting `exist_ok=True` | Second execution of the script raises `FileExistsError: [Errno 17] File exists: 'outputs'` | Always pass `exist_ok=True` to `.mkdir()` |

## Best Practices and Security Considerations
- **Platform Independence**: Never use hardcoded backslashes (`\`) or forward slashes (`/`) as strings; let `pathlib` manage operating system conventions.
- **Headless Portability**: Always enforce non-interactive backends when generating image files in non-interactive batch scripts.
- **Idempotency**: Designing directory creation with `exist_ok=True` makes scripts idempotent—they can be run repeatedly without failing or requiring manual cleanup.

## Summary
Proper configuration of imports and filesystem paths is the foundation of production-grade data science. By enforcing the headless Agg backend early and leveraging `pathlib.Path(__file__).resolve().parent`, `main.py` guarantees smooth, cross-platform execution on local workstations, remote servers, and automated pipelines alike.

## Knowledge-check Questions
1. Why must `matplotlib.use("Agg")` be called before importing `matplotlib.pyplot`?
2. What does `Path(__file__).resolve().parent` return?
3. Which operator does `pathlib` overload for path joining?
4. What happens if `.mkdir()` is called without `exist_ok=True` on an existing directory?
5. Name the scikit-learn module from which `LinearRegression` is imported.

## References
- Python `pathlib` official documentation: https://docs.python.org/3/library/pathlib.html
- Matplotlib backends documentation: https://matplotlib.org/stable/users/explain/backends.html
- scikit-learn linear model imports: https://scikit-learn.org/stable/modules/classes.html#module-sklearn.linear_model
