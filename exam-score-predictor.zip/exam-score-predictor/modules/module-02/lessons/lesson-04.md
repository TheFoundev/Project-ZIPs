# Lesson 04: Train/Test Splitting, Random State Reproducibility, and Leakage Prevention

**Lesson ID:** lesson-04
**Module:** module-02
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why datasets must be split into training and testing subsets
- Define and identify the danger of **data leakage**
- Implement `train_test_split()` with `test_size=0.25` and `random_state=42`
- Verify partition sizes: 21 training samples (75%) and 7 test samples (25%)
- Explain why pseudo-random number seeds (`random_state`) ensure scientific reproducibility

## Prerequisites
- Completion of Lesson 03
- Understanding of independent features ($X$) and target outcomes ($y$)

## Concept Explanation

### The Golden Rule of Machine Learning: Never Test on Training Data
Imagine a teacher gives students a practice exam with 21 questions and provides the full answer key. If the teacher then tests the students using the exact same 21 questions, a student who scored 100% might not actually understand the subject—they may have simply memorized the answers!

To truly measure whether a student (or a machine learning model) has learned the underlying principles, they must be evaluated on **unseen questions**.

In machine learning:
- **Training Set**: The subset of data shown to the algorithm during `model.fit()`. The model studies these examples to learn the optimal slope and intercept.
- **Testing Set**: The holdout subset kept strictly hidden during training. It is used exclusively during `model.predict()` and evaluation to measure how well the model generalizes to new, real-world data.

Evaluating a model on the same data used to train it is called **data leakage** or overfitting, and it leads to falsely optimistic performance metrics.

### The 75/25 Partition in main.py
In `main.py`, lines 33-35 execute the partition using scikit-learn's `train_test_split`:
```python
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)
```
- Total dataset: 28 rows.
- `test_size=0.25`: Allocates 25% of the data to the test set: $28 \times 0.25 = 7\text{ samples}$.
- Training set remainder: 75% of the data: $28 \times 0.75 = 21\text{ samples}$.

Let's inspect the shapes of all four generated variables:
- `X_train.shape`: `(21, 1)`
- `y_train.shape`: `(21,)`
- `X_test.shape`: `(7, 1)`
- `y_test.shape`: `(7,)`

### Why random_state=42 Matters
By default, `train_test_split` randomly shuffles the rows before splitting them so that the test set contains a representative sample across the whole data distribution.
However, computer random number generators are not truly random—they are **pseudo-random algorithms** driven by an initial mathematical seed number.

- If you omit `random_state`, Python selects a different seed every time the script runs. As a result, different rows would end up in `X_train` each time, causing the learned slope, intercept, MAE, and $R^2$ to fluctuate on every run!
- By specifying `random_state=42`, we lock the random number generator to a fixed sequence. Every student, teacher, or automated grader who runs `main.py` will get the exact same 21 training rows and the exact same 7 test rows.

Why 42? In computer science culture, 42 is a playful homage to Douglas Adams' *The Hitchhiker's Guide to the Galaxy* ("the answer to the ultimate question of life, the universe, and everything"). Any integer works, but 42 is the industry standard convention.

### The Specific Test Cohort in Our Project
With `random_state=42`, the 7 holdout test observations selected from `exam_scores.csv` are:

| Index in CSV | `hours_studied` | `exam_score` |
|---|---|---|
| **Row 9** | 5.4 hours | 69.5 points |
| **Row 25** | 4.2 hours | 54.1 points |
| **Row 8** | 4.8 hours | 61.3 points |
| **Row 21** | 6.4 hours | 74.0 points |
| **Row 0** | 9.5 hours | 92.1 points |
| **Row 12** | 2.4 hours | 50.5 points |
| **Row 17** | 4.7 hours | 69.2 points |

Notice that the test set includes low hours (2.4), moderate hours (4.2 - 6.4), and high hours (9.5), providing a fair and balanced evaluation sample!

## Relevant Code (from main.py, lines 33-35)
```python
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42
    )
```

### Code explanation
- The function unpacks four variables in a specific order: features first (`X_train`, `X_test`), then targets (`y_train`, `y_test`).
- `test_size=0.25` enforces a 3:1 ratio between training and testing data.
- `random_state=42` guarantees deterministic, reproducible partitioning across all machines.

## Worked Example

**Problem:** Suppose an engineer mistakenly writes:
```python
X_train, y_train, X_test, y_test = train_test_split(X, y, test_size=0.25)
```
What error will occur when they later call `model.fit(X_train, y_train)`?
**Solution:**
1. Notice the variable order! `train_test_split` returns `(X_train, X_test, y_train, y_test)`.
2. The engineer assigned the second return value (`X_test`, shape `(7, 1)`) to `y_train`, and the third return value (`y_train`, shape `(21,)`) to `X_test`.
3. When calling `model.fit(X_train, y_train)`, `X_train` has 21 rows, but `y_train` (which actually contains `X_test`) has only 7 rows!
4. scikit-learn will immediately crash with:
   `ValueError: Found input variables with inconsistent numbers of samples: [21, 7]`
5. Always unpack in the standard order: `X_train, X_test, y_train, y_test`.

## Step-by-Step Student Instructions
1. Open terminal and run python:
   ```bash
   python3
   ```
2. Run the train/test split on `exam_scores.csv`:
   ```python
   import pandas as pd
   from sklearn.model_selection import train_test_split
   df = pd.read_csv("beginner-projects-main/AI-ML Beginners/projects/06_exam_score/data/exam_scores.csv")
   X = df[["hours_studied"]]
   y = df["exam_score"]
   X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)
   ```
3. Inspect and verify the sample counts:
   ```python
   print("Total rows:", len(df))
   print("Training rows:", len(X_train))
   print("Testing rows:", len(X_test))
   ```
4. Verify that $21 + 7 = 28$.
5. Inspect the test indices:
   ```python
   print("Test indices:", X_test.index.tolist())
   ```

## Expected Output or Observable Behaviour
```text
Total rows: 28
Training rows: 21
Testing rows: 7
Test indices: [9, 25, 8, 21, 0, 12, 17]
```
The sample sizes and index positions match the expected deterministic split exactly.

## Practical Exercises
**Exercise 4.1:** If a dataset has 100 rows and you specify `test_size=0.20`, how many rows will be in `X_train` and how many in `X_test`?
**Exercise 4.2:** What is the danger of setting `test_size=0.80` on a small dataset of 28 rows?
**Exercise 4.3:** Explain why the model must NEVER be trained on `X_test` and `y_test`.

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Unpacking variables in wrong order | Scrambles feature matrices and target arrays, causing `ValueError: inconsistent numbers of samples` | Always use: `X_train, X_test, y_train, y_test = train_test_split(...)` |
| Omitting `random_state` | Results change every time the script runs, making bugs hard to replicate and grading impossible | Always set `random_state=42` (or a designated constant seed) |
| Fitting on the whole dataset `model.fit(X, y)` | Causes data leakage; testing on the same data gives false confidence | Always fit strictly on `X_train, y_train` |

## Best Practices and Security Considerations
- **Strict Data Segregation**: Treat `X_test` and `y_test` as a sealed vault. Never touch them during feature engineering, model selection, or hyperparameter tuning.
- **Reproducible Science**: Always pin pseudo-random seeds in scripts, unit tests, and research publications to ensure peer reproducibility.
- **Representative Split Verification**: On small datasets, verify that both the training and testing sets span the full dynamic range of the target variable.

## Summary
The train/test split is the bedrock of empirical machine learning validation. By dividing our 28 student records into 21 training samples (75%) and 7 test samples (25%) using a fixed seed (`random_state=42`), `main.py` prevents data leakage and guarantees that model evaluation is both honest and perfectly reproducible.

## Knowledge-check Questions
1. What percentage of the data is allocated to the test set with `test_size=0.25`?
2. How many samples from our 28-row dataset go into `X_train` and `X_test`?
3. What is "data leakage" and why does it compromise model evaluation?
4. What is the purpose of setting `random_state=42` in `train_test_split`?
5. In what exact order does `train_test_split()` return its four output arrays?

## References
- scikit-learn `train_test_split` documentation: https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html
- Cross-validation and data splitting: https://scikit-learn.org/stable/modules/cross_validation.html
- Avoiding Data Leakage in Machine Learning: https://en.wikipedia.org/wiki/Leakage_(machine_learning)
