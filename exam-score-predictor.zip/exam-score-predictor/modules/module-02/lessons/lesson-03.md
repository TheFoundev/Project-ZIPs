# Lesson 03: Feature Matrix ($X$) vs. Target Vector ($y$) Structure and Shapes

**Lesson ID:** lesson-03
**Module:** module-02
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why features ($X$) and targets ($y$) are separated prior to modeling
- Understand why pandas double brackets `[["column"]]` produce a 2D DataFrame while single brackets `["column"]` produce a 1D Series
- Verify array shapes and dimensions using Python's `.shape` attribute
- Explain scikit-learn's strict input dimensionality contract for estimators
- Avoid common shape mismatch errors (`ValueError: Expected 2D array, got 1D array instead`)

## Prerequisites
- Completion of Lesson 02
- Basic understanding of 1D arrays vs. 2D matrices

## Concept Explanation

### The Separation of Inputs and Outputs
Machine learning models are mathematical functions: $y = f(X)$. 
To train an estimator in scikit-learn, we must separate our dataset into two distinct entities:
- **Feature Matrix ($X$)**: The table of input observations. Conventionally denoted by an uppercase letter **$X$** because in mathematics, matrices are represented by capital letters.
- **Target Vector ($y$)**: The list of ground-truth outcomes to be predicted. Conventionally denoted by a lowercase letter **$y$** because it is a single-dimensional vector.

In `main.py`, lines 30-31 perform this separation:
```python
X = df[["hours_studied"]]
y = df["exam_score"]
```

### The Double Bracket vs. Single Bracket Distinction in pandas
Notice the crucial syntactical difference between lines 30 and 31:
- `df[["hours_studied"]]` uses **double brackets** (passing a list containing one string).
- `df["exam_score"]` uses **single brackets** (passing a single string).

Why does this matter?
1. **Single Brackets `df["exam_score"]`**:
   - Returns a **pandas Series**.
   - A Series is a one-dimensional array-like object.
   - Its shape is `(28,)`, meaning 28 elements along a single axis.
2. **Double Brackets `df[["hours_studied"]]`**:
   - Returns a **pandas DataFrame**.
   - A DataFrame is a two-dimensional tabular data structure with both rows and columns.
   - Its shape is `(28, 1)`, meaning 28 rows and 1 column.

```
       Series (1D): df['exam_score']         DataFrame (2D): df[['hours_studied']]
       Shape: (28,)                           Shape: (28, 1)
       ┌──────┐                               ┌─────────────────┐
     0 │ 92.1 │                             0 │       9.5       │
     1 │ 66.4 │                             1 │       3.8       │
     2 │ 47.5 │                             2 │       3.3       │
       ...                                    ...
    27 │ 53.7 │                            27 │       2.5       │
       └──────┘                               └─────────────────┘
     1 Dimension (Axis 0 only)               2 Dimensions (Axis 0 = Rows, Axis 1 = Columns)
```

### Why scikit-learn Mandates a 2D Feature Matrix
scikit-learn estimators are designed to support multivariate machine learning—models that take 1, 5, 50, or 1,000 features. To maintain a consistent API across all algorithms, scikit-learn requires that the feature matrix $X$ always have two dimensions:
$$\text{Shape}(X) = (\text{n\_samples}, \text{n\_features})$$

For our project:
- $\text{n\_samples} = 28$
- $\text{n\_features} = 1$
- Expected shape of $X$: `(28, 1)`

If you accidentally pass a 1D Series (`df["hours_studied"]`) to `model.fit()`, scikit-learn will raise a fatal error:
```text
ValueError: Expected 2D array, got 1D array instead:
array=[9.5 3.8 3.3 ...].
Reshape your data either using array.reshape(-1, 1) if your data has a single feature 
or array.reshape(1, -1) if it contains a single sample.
```

By extracting $X$ with double brackets `df[["hours_studied"]]`, pandas preserves the column dimension automatically, satisfying scikit-learn without requiring manual array reshaping!

Meanwhile, the target $y$ represents a single scalar outcome per sample, so scikit-learn expects $y$ to be 1-dimensional with shape `(n_samples,)` or `(28,)`. Single brackets `df["exam_score"]` fulfill this requirement perfectly.

## Relevant Code (from main.py, lines 30-31)
```python
    X = df[["hours_studied"]]
    y = df["exam_score"]
```

### Code explanation
- `df[["hours_studied"]]` wraps the column name in a Python list `["hours_studied"]`, instructing pandas to slice a DataFrame subset with shape `(28, 1)`.
- `df["exam_score"]` extracts the column directly as a Series with shape `(28,)`.

## Worked Example

**Problem:** What happens if you run the following code in Python?
```python
import pandas as pd
df = pd.DataFrame({"hours": [2.0, 4.0, 6.0], "score": [50.0, 60.0, 70.0]})
x_single = df["hours"]
x_double = df[["hours"]]
print("x_single shape:", x_single.shape, "type:", type(x_single))
print("x_double shape:", x_double.shape, "type:", type(x_double))
```
**Solution:**
Output:
```text
x_single shape: (3,) type: <class 'pandas.core.series.Series'>
x_double shape: (3, 1) type: <class 'pandas.core.frame.DataFrame'>
```
Notice that `x_single` has a trailing comma in its shape `(3,)` indicating 1 dimension, whereas `x_double` has two numbers in its shape `(3, 1)` indicating 2 dimensions.

## Step-by-Step Student Instructions
1. Open terminal and run python3:
   ```bash
   python3
   ```
2. Load the project CSV file:
   ```python
   import pandas as pd
   df = pd.read_csv("beginner-projects-main/AI-ML Beginners/projects/06_exam_score/data/exam_scores.csv")
   ```
3. Extract $X$ and $y$ as written in `main.py`:
   ```python
   X = df[["hours_studied"]]
   y = df["exam_score"]
   ```
4. Verify their shapes and types:
   ```python
   print("X shape:", X.shape, "| X type:", type(X))
   print("y shape:", y.shape, "| y type:", type(y))
   ```
5. Confirm that `X.ndim == 2` and `y.ndim == 1`.

## Expected Output or Observable Behaviour
```text
X shape: (28, 1) | X type: <class 'pandas.core.frame.DataFrame'>
y shape: (28,) | y type: <class 'pandas.core.series.Series'>
```
`X.shape` is confirmed as `(28, 1)` (2D) and `y.shape` is confirmed as `(28,)` (1D).

## Practical Exercises
**Exercise 3.1:** What happens if a dataset has three features: `hours_studied`, `attendance`, and `sleep_hours`? How would you write the extraction of $X$ using double brackets?
**Exercise 3.2:** If you have a 1D numpy array `arr = np.array([1.5, 3.8, 4.2])`, what method can you call to transform its shape from `(3,)` to `(3, 1)`?
**Exercise 3.3:** Why is the target variable $y$ represented with a lowercase letter while the feature matrix $X$ is represented with an uppercase letter?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Using single brackets for $X$: `X = df['hours_studied']` | Returns a 1D Series of shape `(28,)`; `LinearRegression.fit()` crashes with `ValueError: Expected 2D array` | Use double brackets: `X = df[['hours_studied']]` |
| Using double brackets for $y$: `y = df[['exam_score']]` | Returns a 2D DataFrame of shape `(28, 1)`; while some functions tolerate it, scikit-learn emits a `DataConversionWarning` | Use single brackets: `y = df['exam_score']` |
| Passing a string instead of list in double brackets | Writing `df["hours_studied", "exam_score"]` raises `KeyError` | Pass a list: `df[["hours_studied", "exam_score"]]` |

## Best Practices and Security Considerations
- **Strict Shape Awareness**: Always check `.shape` after slicing datasets to ensure features match the expected `(n_samples, n_features)` contract.
- **Idiomatic pandas**: Using `df[[col]]` is cleaner and more readable than extracting a Series and calling `.to_numpy().reshape(-1, 1)`.
- **API Consistency**: Adhering to scikit-learn's standard 2D feature matrix format allows your code to scale seamlessly from 1 feature to hundreds of features without rewriting downstream logic.

## Summary
scikit-learn enforces a strict contract: features $X$ must be a two-dimensional matrix of shape `(n_samples, n_features)`, while targets $y$ are typically a one-dimensional vector of shape `(n_samples,)`. In pandas, double brackets `df[["hours_studied"]]` return a 2D DataFrame `(28, 1)` that satisfies this requirement effortlessly.

## Knowledge-check Questions
1. What is the shape of `X` when created with `df[["hours_studied"]]`?
2. What is the shape of `y` when created with `df["exam_score"]`?
3. What Python data type is returned by `df["exam_score"]`?
4. What error does scikit-learn raise if you pass a 1D Series as the feature matrix to `model.fit()`?
5. Why are features traditionally named with an uppercase `X`?

## References
- scikit-learn input shape conventions: https://scikit-learn.org/stable/glossary.html#term-X
- pandas indexing and selecting data: https://pandas.pydata.org/docs/user_guide/indexing.html
- numpy reshape documentation: https://numpy.org/doc/stable/reference/generated/numpy.reshape.html
