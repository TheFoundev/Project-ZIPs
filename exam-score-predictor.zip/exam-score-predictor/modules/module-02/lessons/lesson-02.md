# Lesson 02: Ingesting and Exploring `exam_scores.csv` with pandas

**Lesson ID:** lesson-02
**Module:** module-02
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Load CSV tabular data into a pandas DataFrame using `pd.read_csv()`
- Inspect dataset dimensions, column names, and data types
- Compute and interpret summary statistics (`.describe()`) for student study data
- Understand the distribution and range of `hours_studied` and `exam_score`
- Detect missing values, anomalies, or potential outliers

## Prerequisites
- Completion of Lesson 01
- Basic understanding of tabular spreadsheets (rows and columns)

## Concept Explanation

### Loading Tabular Data with pandas
In data science, Comma-Separated Values (CSV) is the universal format for storing structured datasets. In `main.py`, line 29 loads our dataset:
```python
df = pd.read_csv(DATA / "exam_scores.csv")
```
When `pd.read_csv()` executes, pandas parses the file:
1. It reads the first line as column headers: `hours_studied,exam_score`.
2. It parses each subsequent row into a tabular two-dimensional grid called a **DataFrame**.
3. It automatically infers the data types: both columns contain decimal values and are parsed as 64-bit floating point numbers (`float64`).

### Dataset Dimensions and Overview
Our dataset contains **28 student observations**.
Let's inspect the entire dataset:
```text
hours_studied,exam_score
9.5,92.1   |  3.8,66.4   |  3.3,47.5   |  3.0,46.2
8.1,82.4   |  3.0,52.4   |  8.3,75.1   |  7.6,73.8
4.8,61.3   |  5.4,69.5   |  9.2,78.3   |  8.1,83.9
2.4,50.5   |  7.7,89.2   |  4.6,47.0   |  9.9,88.6
2.9,48.4   |  4.7,69.2   |  9.5,81.7   |  6.2,66.3
7.6,78.8   |  6.4,74.0   |  3.1,54.5   |  1.5,35.4
1.9,55.8   |  4.2,54.1   |  1.8,46.8   |  2.5,53.7
```

### Descriptive Statistics: The `.describe()` Method
Before fitting any machine learning model, a data scientist must explore the statistical distribution of the features and target. Calling `df.describe()` produces:

| Statistic | `hours_studied` | `exam_score` | Interpretation |
|---|---|---|---|
| **count** | 28.0 | 28.0 | Exactly 28 complete records with zero missing values |
| **mean** | 5.39 hours | 65.10 points | Average study time is ~5.4 hours; average score is ~65.1 points |
| **std** | 2.71 hours | 15.84 points | Standard deviation indicates healthy spread across both variables |
| **min** | 1.50 hours | 35.40 points | The minimum study time was 1.5 hours, earning 35.4 points |
| **25%** | 3.00 hours | 51.93 points | 25% of students studied 3.0 hours or less (Q1) |
| **50% (median)**| 4.75 hours | 66.35 points | Half the cohort studied less than 4.75 hours, half studied more |
| **75%** | 7.80 hours | 78.43 points | 75% of students studied 7.8 hours or less (Q3) |
| **max** | 9.90 hours | 92.10 points | Maximum study time was 9.9 hours; maximum score was 92.1 points |

### Key Data Insights
1. **Realistic Student Spectrum**: The dataset covers a realistic variety of students—from crammers studying under 2 hours to dedicated students studying nearly 10 hours.
2. **Score Range**: Scores span from 35.4 (failing grade) to 92.1 (excellent grade). No student scored below 0 or above 100, confirming data integrity.
3. **No Missing Data**: All 28 rows are populated (`count == 28` for both columns). No imputation or deletion of nulls is needed.

## Relevant Code (from main.py, line 29)
```python
def main() -> None:
    df = pd.read_csv(DATA / "exam_scores.csv")
    X = df[["hours_studied"]]
    y = df["exam_score"]
```

### Code explanation
- `pd.read_csv()` seamlessly converts the raw CSV text on disk into a pandas DataFrame in memory.
- The path `DATA / "exam_scores.csv"` combines the base data directory with the specific filename.

## Worked Example

**Problem:** How can you verify programmatically in Python whether `exam_scores.csv` contains any null or missing values?
**Solution:**
Use the pandas `.isna().sum()` method:
```python
import pandas as pd
from pathlib import Path

df = pd.read_csv("beginner-projects-main/AI-ML Beginners/projects/06_exam_score/data/exam_scores.csv")
null_counts = df.isna().sum()
print(null_counts)
```
Output:
```text
hours_studied    0
exam_score       0
dtype: int64
```
Both columns show `0` missing values, confirming that the dataset is clean and ready for machine learning.

## Step-by-Step Student Instructions
1. Open terminal and run python:
   ```bash
   python3
   ```
2. Load the dataset and inspect the first five rows using `.head()`:
   ```python
   import pandas as pd
   df = pd.read_csv("beginner-projects-main/AI-ML Beginners/projects/06_exam_score/data/exam_scores.csv")
   print(df.head())
   ```
3. Check the total number of rows and columns with `.shape`:
   ```python
   print("Shape:", df.shape)
   ```
4. Print the summary statistics table:
   ```python
   print(df.describe())
   ```
5. Observe that the minimum study time is 1.5 hours and the maximum is 9.9 hours.

## Expected Output or Observable Behaviour
```text
   hours_studied  exam_score
0            9.5        92.1
1            3.8        66.4
2            3.3        47.5
3            3.0        46.2
4            8.1        82.4
Shape: (28, 2)
```
The DataFrame displays 28 rows, 2 columns, and matching headers.

## Practical Exercises
**Exercise 2.1:** What is the median study duration in the dataset? Why might a data scientist look at the median (50%) in addition to the mean?
**Exercise 2.2:** What is the highest exam score recorded in `exam_scores.csv`, and how many hours did that student study?
**Exercise 2.3:** Calculate the range (maximum minus minimum) for both `hours_studied` and `exam_score`.

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Misspelling column names | Accessing `df['Hours_Studied']` raises `KeyError` because pandas column lookups are case-sensitive | Use exact column names: `hours_studied` and `exam_score` |
| Calling `.describe` without parentheses | `print(df.describe)` prints the method representation object rather than executing the calculation | Always include parentheses: `df.describe()` |
| Confusing `.shape` with a method | `.shape` is a tuple attribute, not a callable method | Use `df.shape` without parentheses |

## Best Practices and Security Considerations
- **Data Integrity Verification**: Always inspect data types, shapes, and null counts before feeding data into estimators.
- **Exploratory Data Analysis (EDA)**: Understanding feature distributions helps identify skewness, outliers, or scale imbalances early.
- **Defensive Parsing**: In production systems, validate that required column names exist in incoming CSV files before indexing them.

## Summary
The `exam_scores.csv` file provides 28 clean, fully populated records of student study hours and corresponding exam marks. With study hours averaging 5.39 hours and scores averaging 65.10 points across a broad range (1.5 to 9.9 hours), the dataset provides a well-behaved empirical basis for training a linear regression model.

## Knowledge-check Questions
1. How many total rows are in `exam_scores.csv`?
2. What are the names of the two columns in the dataset?
3. What is the minimum and maximum number of study hours recorded?
4. What pandas method computes count, mean, standard deviation, and quartiles?
5. Are there any missing or null values in `exam_scores.csv`?

## References
- pandas `read_csv` documentation: https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html
- pandas DataFrame `describe` method: https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.describe.html
- Summary statistics guide: https://en.wikipedia.org/wiki/Summary_statistics
