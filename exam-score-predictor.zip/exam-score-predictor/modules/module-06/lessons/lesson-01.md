# Lesson 01: End-to-End Execution of `main.py` and Pipeline Flow

**Lesson ID:** lesson-01
**Module:** module-06
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Trace the complete synchronous execution flow of `main.py` from entry point to exit
- Understand the role of the standard Python execution idiom: `if __name__ == "__main__": main()`
- Execute `main.py` from the command line and observe runtime behavior
- Connect the code in `main.py` to the conceptual stages covered in Modules 1 through 5
- Confirm that all data preparation, training, evaluation, and plotting steps run seamlessly

## Prerequisites
- Completion of Modules 01 through 05
- Familiarity with executing Python scripts from a shell

## Concept Explanation

### The Big Picture: Integrating All Components
Throughout Modules 1 through 5, we investigated each component of the Exam Score Predictor individually:
- **Module 1**: Problem formulation, supervised regression, and the linear hypothesis
- **Module 2**: Headless matplotlib configuration, pandas data loading, and train/test splitting
- **Module 3**: OLS algorithm mechanics, line of best fit, slope, and intercept
- **Module 4**: Model training, parameter extraction, and predicting for 6.0 hours
- **Module 5**: Evaluating with MAE and $R^2$, and constructing multi-layer scatter plots

In `main.py`, all these elements coalesce into a single, cohesive 83-line Python script.

### The Entry Point Idiom
At the very bottom of `main.py` (lines 82-83), we find the standard Python execution idiom:
```python
if __name__ == "__main__":
    main()
```
Why is this idiom standard in professional Python development?
1. **Direct Execution**: When you execute `python main.py` directly from the terminal, Python sets the special built-in variable `__name__` to the string `"__main__"`. The `if` condition evaluates to `True`, and the `main()` function is invoked.
2. **Modular Importability**: If another script, unit test, or automated grading harness imports `main.py` (`import main`), Python sets `__name__` to `"main"`. The `if` condition evaluates to `False`, allowing other programs to import helper functions or constants from `main.py` without accidentally triggering the entire training and plotting pipeline!

### Tracing the 8-Stage Execution Flow
When `main()` is invoked, it runs through the pipeline sequentially:

```
[Start Script]
      │
      ▼
1. Path Resolution: BASE, DATA, OUT initialized; outputs/ created
      │
      ▼
2. Data Ingestion: df loaded from data/exam_scores.csv (28 rows)
      │
      ▼
3. Feature Slicing: X = df[["hours_studied"]], y = df["exam_score"]
      │
      ▼
4. Data Partitioning: train_test_split() -> 21 train rows, 7 test rows
      │
      ▼
5. Model Fitting: LinearRegression().fit(X_train, y_train)
      │
      ▼
6. Evaluation & Inference:
   - predictions on X_test -> MAE ≈ 4.3, R² ≈ 0.85
   - single prediction for 6.0 hours -> 67.5 points
      │
      ▼
7. Terminal Reporting: Header, model equation, MAE, R², prediction printed
      │
      ▼
8. Artifact Generation:
   - Matplotlib figure saved: outputs/exam_score_regression.png
   - Metrics text written: outputs/metrics.txt
   - Figure closed with plt.close(fig)
      │
      ▼
[Script Exits with Code 0]
```

## Relevant Code (from main.py, lines 28-36, 82-83)
```python
def main() -> None:
    df = pd.read_csv(DATA / "exam_scores.csv")
    X = df[["hours_studied"]]
    y = df["exam_score"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42
    )

    # ... [Fitting, predicting, plotting, writing] ...

if __name__ == "__main__":
    main()
```

### Code explanation
- The entire workflow is neatly wrapped inside a strongly typed `def main() -> None:` function.
- Execution is synchronous, fast (completing in under 1 second), and produces zero side effects outside of the designated `outputs/` folder.

## Worked Example

**Problem:** How can you measure the execution speed of `main.py` on Linux or macOS to verify its computational efficiency?
**Solution:**
Use the standard shell `time` command:
```bash
cd "beginner-projects-main/AI-ML Beginners/projects/06_exam_score"
time python main.py
```
Output:
```text
============================================================
PREDICT YOUR EXAM SCORE
============================================================
Model: score = 5.28 x hours + 35.85
Mean absolute error: 4.3 points
R-squared: 0.85
Prediction for 6 hours: 67.5 points

Saved: outputs/exam_score_regression.png, outputs/metrics.txt
Try this: collect five real study-hour/score pairs and add them.

real    0m0.428s
user    0m0.375s
sys     0m0.052s
```
The entire pipeline—loading data, fitting OLS, predicting, rendering matplotlib vectors, and saving to disk—completes in less than half a second!

## Step-by-Step Student Instructions
1. Open your terminal and navigate to the project folder:
   ```bash
   cd "beginner-projects-main/AI-ML Beginners/projects/06_exam_score"
   ```
2. Run `main.py`:
   ```bash
   python main.py
   ```
3. Observe the output lines appearing in the console.
4. Verify the exit code of the script using `echo $?`:
   ```bash
   echo $?
   ```
5. Confirm that the exit code is `0` (indicating successful termination without errors).

## Expected Output or Observable Behaviour
```text
============================================================
PREDICT YOUR EXAM SCORE
============================================================
Model: score = 5.28 x hours + 35.85
Mean absolute error: 4.3 points
R-squared: 0.85
Prediction for 6 hours: 67.5 points

Saved: outputs/exam_score_regression.png, outputs/metrics.txt
Try this: collect five real study-hour/score pairs and add them.
```
Exit code `0` confirms clean, error-free execution.

## Practical Exercises
**Exercise 1.1:** What happens if you run `python -c "import main"`? Does the script print the output and save files? Explain why or why not based on `if __name__ == "__main__"`.
**Exercise 1.2:** If someone deletes the `outputs/` folder, does running `main.py` crash? Which line recreates it?
**Exercise 1.3:** What is the very last console message printed by `main.py`? How does it invite students to explore further?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Putting top-level code outside functions | Makes code un-testable and executes unintentionally upon import | Encapsulate pipeline logic inside `def main():` |
| Running from wrong directory without pathlib | Relative paths like `"data/exam_scores.csv"` fail if invoked from elsewhere | Always use `Path(__file__).resolve().parent` |
| Leaving stray `plt.show()` calls | Blocks headless execution on remote servers waiting for user interaction | Use `matplotlib.use("Agg")` and `fig.savefig()`, never `plt.show()` |

## Best Practices and Security Considerations
- **Deterministic Execution**: Always seed pseudo-random components so repeated executions yield byte-for-byte identical results.
- **Fail-Fast Design**: Perform file existence and shape validations early in the pipeline before beginning heavy computation.
- **Zero Global Side Effects**: Write output files strictly to designated, git-ignored output folders.

## Summary
`main.py` integrates data ingestion, feature extraction, train/test splitting, OLS optimization, evaluation, inference, and visualization into a clean, 83-line pipeline. Guarded by the `if __name__ == "__main__":` idiom, the script runs deterministically in less than a second, outputting key academic metrics and saving polished artifacts.

## Knowledge-check Questions
1. What does `if __name__ == "__main__":` do in a Python script?
2. What exit code indicates that a command completed successfully in Linux/Unix?
3. What is the approximate runtime of `main.py`?
4. What invite or suggestion does `main.py` print on its final output line?
5. Which function encapsulates the entire end-to-end execution workflow?

## References
- Python `__main__` module documentation: https://docs.python.org/3/library/__main__.html
- Writing clean CLI scripts in Python: https://realpython.com/python-main-function/
