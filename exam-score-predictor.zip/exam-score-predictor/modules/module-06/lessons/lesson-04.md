# Lesson 04: Model Expansion: Feature Engineering, Multivariate Regression, and Real-World Nuance

**Lesson ID:** lesson-04
**Module:** module-06
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain the real-world limitations of a single-feature linear regression model
- Define **multivariate linear regression** and its mathematical formulation
- Identify high-value additional features for academic score prediction (attendance, sleep, prior GPA)
- Explain the concept of **interaction terms** and non-linear feature engineering
- Evaluate the ethical and practical considerations of deploying student performance models

## Prerequisites
- Completion of Lessons 01, 02, and 03
- Understanding of the simple linear model $\text{score} = 5.28 \times \text{hours} + 35.85$

## Concept Explanation

### The Limitation of Single-Feature Models
Our project achieves a remarkable $R^2 \approx 0.85$ using only a single feature: `hours_studied`.
However, in real educational systems, student performance is multifaceted:
- Two students might both study 6.0 hours, but one attends every lecture while the other skips half the semester.
- One student might study 6 hours after 8 hours of restful sleep, while another studies 6 hours during an all-night cramming session on zero sleep.
- One student enters the course with a strong foundational background, while another is learning the prerequisites on the fly.

A single-feature model attributes all score variation solely to study time, ignoring these critical confounding variables.

### Moving to Multivariate Linear Regression
In **multivariate linear regression**, we expand our feature matrix $X$ from one column to $p$ columns:

$$\hat{y} = w_1 x_1 + w_2 x_2 + w_3 x_3 + \dots + w_p x_p + b$$

Where:
- $x_1$: `hours_studied` (e.g. 6.0)
- $x_2$: `attendance_rate` (e.g. 0.95 for 95% attendance)
- $x_3$: `sleep_hours` (e.g. 8.0)
- $x_4$: `prior_gpa` (e.g. 3.4)
- $w_1, w_2, w_3, w_4$: Learned weights (slopes) for each feature
- $b$: Baseline intercept

Because scikit-learn's `LinearRegression` natively expects a 2D feature matrix `(n_samples, n_features)`, expanding from 1 feature to 4 features requires changing only a single line of data preparation:
```python
# From single feature:
X = df[["hours_studied"]]  # Shape (28, 1)

# To multivariate features:
X = df[["hours_studied", "attendance_rate", "sleep_hours", "prior_gpa"]]  # Shape (28, 4)
```
The exact same `model.fit(X_train, y_train)` and `model.predict(X_test)` methods handle multiple features automatically!

### The Challenge of the 100-Point Ceiling: Polynomial & Sigmoid Models
As discussed in Module 4, simple linear regression continues infinitely, predicting scores above 100 for large study inputs.
To solve this in advanced projects, data scientists use:
1. **Polynomial Features (`PolynomialFeatures`)**:
   Adding quadratic terms ($x^2$) allows the line to curve downward as study hours increase, modeling diminishing returns.
2. **Logistic / Sigmoidal Curves**:
   S-shaped curves naturally asymptote between 0 and 100, ensuring predictions never breach test boundaries.

```
       Exam Score
          ▲
      100 ├─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ Diminishing returns ceiling
          │                               ╭──────
       80 │                         ╭─────╯
          │                   ╭─────╯
       60 │             ╭─────╯
          │       ╭─────╯
       40 │ ╭─────╯
          └─┴─────────┴─────────┴─────────┴─────────► Hours Studied
```

### Ethical AI in Education: Responsible Deployment
When machine learning models are deployed in schools, colleges, and learning platforms, developers have a profound ethical responsibility:
1. **Support, Not Gatekeeping**: Predictive models should be used to provide supportive resources (e.g., offering free tutoring or study planning assistance), never to deny opportunities or track students into lower tracks.
2. **Transparency & Agency**: Students should be shown the model parameters openly. Seeing that "+5.28 points per hour" is achievable empowers student agency.
3. **Data Privacy & Consent**: Student academic histories must be anonymized, encrypted, and governed under strict privacy regulations (FERPA, GDPR).

## Relevant Code (Multivariate Extension Preview)
```python
# Conceptual multivariate expansion:
def train_multivariate_model(df_expanded: pd.DataFrame):
    features = ["hours_studied", "attendance_pct", "sleep_hours"]
    X = df_expanded[features]
    y = df_expanded["exam_score"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42
    )
    model = LinearRegression()
    model.fit(X_train, y_train)

    for feat_name, weight in zip(features, model.coef_):
        print(f"Weight for {feat_name}: {weight:.2f}")
    print(f"Intercept: {model.intercept_:.2f}")
```

### Code explanation
- Iterating over `zip(features, model.coef_)` reveals the relative importance of each feature in predicting exam scores.

## Worked Example

**Problem:** Suppose a multivariate model learns:
$$\text{score} = 4.5 \times \text{hours} + 0.2 \times \text{attendance\_pct} + 1.5 \times \text{sleep} + 20.0$$
Calculate the predicted score for a student who studied 6 hours, attended 90% of classes, and slept 7 hours.
**Solution:**
1. Compute feature contributions:
   - Study time: $4.5 \times 6.0 = 27.0$
   - Attendance: $0.2 \times 90 = 18.0$
   - Sleep: $1.5 \times 7.0 = 10.5$
   - Baseline intercept: $20.0$
2. Sum contributions:
   $$\text{score} = 27.0 + 18.0 + 10.5 + 20.0 = \mathbf{75.5\text{ points}}$$
The student is projected to score a solid 75.5 points (Grade B).

## Step-by-Step Student Instructions
1. Open terminal and run python3:
   ```bash
   python3
   ```
2. Simulate adding a synthetic `attendance` feature to our dataset:
   ```python
   import pandas as pd
   import numpy as np
   from sklearn.linear_model import LinearRegression

   df = pd.read_csv("beginner-projects-main/AI-ML Beginners/projects/06_exam_score/data/exam_scores.csv")
   np.random.seed(42)
   # Simulate attendance between 70% and 100%
   df["attendance"] = np.random.uniform(70, 100, len(df))

   X_multi = df[["hours_studied", "attendance"]]
   y = df["exam_score"]
   multi_model = LinearRegression().fit(X_multi, y)
   print("Hours studied weight:", multi_model.coef_[0])
   print("Attendance weight:   ", multi_model.coef_[1])
   print("Intercept:           ", multi_model.intercept_)
   ```
3. Observe how scikit-learn fits weights for both features simultaneously.

## Expected Output or Observable Behaviour
```text
Hours studied weight: 5.378939768652431
Attendance weight:    0.16972049005953055
Intercept:            20.916124584213756
```
The multivariate model estimates individual weights for both study hours and attendance.

## Practical Exercises
**Exercise 4.1:** What is multicollinearity? What happens if you include two features that measure the exact same thing (e.g. `hours_studied` and `minutes_studied`)?
**Exercise 4.2:** Why might adding too many features (e.g., 50 features on a dataset of only 28 students) cause severe overfitting?
**Exercise 4.3:** Formulate an ethical policy for how a university academic advisor should use predictive model outputs when counseling struggling students.

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Adding features without scaling | If attendance is 0-100 and study hours is 0-10, raw weight sizes cannot be compared directly | Use standardized coefficients or `StandardScaler` when comparing feature importances |
| Overfitting small datasets | Adding 10 features to 28 samples memorizes noise, collapsing generalization | Keep feature count small relative to sample size (rule of thumb: $\ge 10$ samples per feature) |
| Using sensitive demographic features | Features like gender, race, or zip code introduce harmful algorithmic bias | Exclude protected demographic attributes from academic prediction models |

## Best Practices and Security Considerations
- **Parsimony (Occam's Razor)**: Keep models as simple as possible. Only add new features if they demonstrably improve cross-validated performance.
- **Fairness & Algorithmic Bias Auditing**: Audit model predictions across different student subgroups to ensure equitable performance.
- **Actionable Guidance**: Prioritize actionable features (study time, practice questions completed) that students can directly control, rather than fixed background traits.

## Summary
While the single-feature linear model provides a powerful, interpretable baseline ($R^2 \approx 0.85$), real-world academic performance is influenced by multiple factors. By extending the pipeline to multivariate regression and respecting ethical deployment principles, machine learning becomes a transformative tool for proactive educational support.

## Knowledge-check Questions
1. What is the mathematical form of a multivariate linear regression equation?
2. How does the shape of feature matrix $X$ change when moving from 1 feature to 4 features?
3. Name two additional student features that could improve exam score predictions.
4. Why is adding 50 features to a 28-row dataset dangerous?
5. What is the primary ethical goal of deploying predictive analytics in schools?

## References
- Multiple Linear Regression on Wikipedia: https://en.wikipedia.org/wiki/Linear_regression#Simple_and_multiple_linear_regression
- Fairness and Machine Learning (Barocas, Hardt, Narayanan): https://fairmlbook.org/
- scikit-learn preprocessing: PolynomialFeatures: https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.PolynomialFeatures.html
