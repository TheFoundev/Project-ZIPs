# Lesson 02: Reading, Auditing, and Interpreting Console and File Outputs (`metrics.txt`)

**Lesson ID:** lesson-02
**Module:** module-06
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Read, audit, and verify the four lines of terminal console output produced by `main.py`
- Inspect and parse the high-precision key-value pairs in `outputs/metrics.txt`
- Explain why console logs use rounded numbers while persistent files retain full precision
- Reconcile differences in format specifiers (`:.1f`, `:.2f`, `:.4f`) across outputs
- Use terminal commands (`cat`, `diff`, `grep`) to audit machine learning output files

## Prerequisites
- Completion of Lesson 01
- Basic familiarity with text inspection in the terminal

## Concept Explanation

### The Dual-Output Pattern in Production ML
In professional software engineering, machine learning pipelines rarely output data to a single location. Instead, they implement a **dual-output pattern**:
1. **Interactive Human Display (Console / Terminal)**: Short, rounded, user-friendly text designed for fast human scanning during development and operations.
2. **Machine-Readable Storage (Disk Artifacts)**: Detailed, structured, high-precision records designed for downstream ingestion, dashboards, automated testing, or model governance audits.

In `main.py`, this pattern is implemented through:
- Terminal Printouts (lines 47-53)
- Persistent File Writing (lines 72-76)

### Auditing the Console Output
Let's inspect the exact console output produced by `main.py`:

```text
============================================================
PREDICT YOUR EXAM SCORE
============================================================
Model: score = 5.28 x hours + 35.85
Mean absolute error: 4.3 points
R-squared: 0.85
Prediction for 6 hours: 67.5 points
```

Let's audit each line:
- **Line 1-3**: Header banner with 60 equals signs (`"=" * 60`), cleanly delimiting the project output.
- **Line 4 (Model)**: Displays the slope-intercept equation: `5.28` (points per hour) and `35.85` (baseline score).
- **Line 5 (MAE)**: Displays `4.3 points`. Uses `:.1f` because tenths of a point are sufficient for human reading.
- **Line 6 (R-squared)**: Displays `0.85`. Formatted to two decimal places (`:.2f`).
- **Line 7 (Prediction)**: Displays `67.5 points`. The benchmark query prediction for 6.0 hours.

### Auditing `outputs/metrics.txt`
Now let's examine the contents of `outputs/metrics.txt`:
```text
equation: score = 5.2766 * hours + 35.8466
mean absolute error: 4.3208
r2: 0.8486
prediction at 6 hours: 67.51
```

Let's compare the metrics side by side:

| Metric | Console Display (Human) | `metrics.txt` (Audit File) | Raw Float in Memory |
|---|---|---|---|
| **Slope** | `5.28` (`:.2f`) | `5.2766` (`:.4f`) | `5.276603510821103` |
| **Intercept** | `35.85` (`:.2f`) | `35.8466` (`:.4f`) | `35.8465638652725` |
| **MAE** | `4.3 points` (`:.1f`) | `4.3208` (`:.4f`) | `4.320811265689356` |
| **$R^2$** | `0.85` (`:.2f`) | `0.8486` (`:.4f`) | `0.8485838771699904` |
| **6-Hour Pred**| `67.5 points` (`:.1f`) | `67.51` (`:.2f`) | `67.50618493019911` |

### Why Retaining 4 Decimals in `metrics.txt` Matters
Why not simply write the 2-decimal console numbers into `metrics.txt`?
1. **Preventing Error Cascades**: If another automated system reads `5.28` and `35.85` and predicts for multiple students, slight rounding errors compound across large student cohorts.
2. **Automated Testing & Regrading**: Automated testing suites (like pytest or grading autograders) verify model correctness by asserting numerical tolerances. Storing 4 decimal places ensures that assertions with tight tolerances (e.g., `abs(mae - 4.3208) < 0.001`) pass reliably.
3. **Parseable Key-Value Format**: Notice that each line in `metrics.txt` uses the standard format:
   `key: value`
   This allows Python scripts, shell pipelines (`awk`, `grep`), or CI/CD systems to parse metrics with a single split operation: `line.split(": ")`.

## Relevant Code (from main.py, lines 72-76)
```python
    with open(OUT / "metrics.txt", "w", encoding="utf-8") as handle:
        handle.write(f"equation: score = {slope:.4f} * hours + {intercept:.4f}\n")
        handle.write(f"mean absolute error: {mae:.4f}\n")
        handle.write(f"r2: {r2:.4f}\n")
        handle.write(f"prediction at 6 hours: {six_hours:.2f}\n")
```

### Code explanation
- Uses the `with open(...)` context manager, guaranteeing that the file handle is automatically flushed and closed even if an exception occurs.
- Specifies `encoding="utf-8"` explicitly for robust cross-platform text writing.
- Ends each line with a newline character (`\n`).

## Worked Example

**Problem:** Write a 3-line Python snippet to parse `outputs/metrics.txt` into a Python dictionary.
**Solution:**
```python
from pathlib import Path

metrics = {}
with open("outputs/metrics.txt", "r", encoding="utf-8") as f:
    for line in f:
        if ":" in line:
            key, val = line.strip().split(":", 1)
            metrics[key.strip()] = val.strip()

print("Parsed metrics dictionary:")
print(metrics)
```
Output:
```text
Parsed metrics dictionary:
{
  'equation': 'score = 5.2766 * hours + 35.8466',
  'mean absolute error': '4.3208',
  'r2': '0.8486',
  'prediction at 6 hours': '67.51'
}
```

## Step-by-Step Student Instructions
1. Navigate to the project directory:
   ```bash
   cd "beginner-projects-main/AI-ML Beginners/projects/06_exam_score"
   ```
2. Run `main.py` if not already run:
   ```bash
   python main.py
   ```
3. Inspect `metrics.txt` using the terminal `cat` command:
   ```bash
   cat outputs/metrics.txt
   ```
4. Count the lines in `outputs/metrics.txt` using `wc -l`:
   ```bash
   wc -l outputs/metrics.txt
   ```
5. Confirm that the file contains exactly 4 lines.

## Expected Output or Observable Behaviour
```text
equation: score = 5.2766 * hours + 35.8466
mean absolute error: 4.3208
r2: 0.8486
prediction at 6 hours: 67.51
4 outputs/metrics.txt
```
The file contains exactly 4 key-value lines matching the expected values.

## Practical Exercises
**Exercise 2.1:** What happens if `encoding="utf-8"` is omitted on a Windows system with a non-ASCII default locale?
**Exercise 2.2:** Why is the multiplication symbol in `metrics.txt` written as `*` while the console prints `x`?
**Exercise 2.3:** Write a bash one-liner using `grep` and `awk` to extract just the numeric MAE value from `outputs/metrics.txt`.

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Forgetting `\n` in `handle.write()` | All four lines concatenate into a single unreadable run-on sentence | Always append `\n` to each written line |
| Opening file in mode `"a"` (append) | Every run appends duplicate lines, creating an increasingly bloated file | Use mode `"w"` (write/overwrite) to ensure fresh output |
| Comparing rounded console numbers with `metrics.txt` | Fails assertions if a test script compares `4.3` against `4.3208` | Match precision levels when verifying test outputs |

## Best Practices and Security Considerations
- **Context Managers (`with`)**: Always open files using the `with` statement to ensure guaranteed closure and avoid leaking file descriptors.
- **Explicit Text Encoding**: Always specify `encoding="utf-8"` when writing text files to ensure platform independence between Linux, macOS, and Windows.
- **Deterministic Formatting**: Use fixed format specifiers (e.g. `:.4f`) rather than Python's default `str(float)`, which can fluctuate in length.

## Summary
The dual-output pattern balances human readability with machine auditing precision. While the terminal prints rounded, accessible summaries (`4.3 points`, `0.85`, `67.5 points`), `outputs/metrics.txt` preserves 4 decimal places of scientific accuracy in a structured format suitable for automated evaluation.

## Knowledge-check Questions
1. How many lines are written to `outputs/metrics.txt`?
2. What format specifier is used for MAE and R² in `metrics.txt`?
3. What is the value of R² recorded in `outputs/metrics.txt`?
4. Why is `encoding="utf-8"` explicitly specified in `open()`?
5. How can downstream automated scripts parse `metrics.txt`?

## References
- Python file I/O documentation: https://docs.python.org/3/tutorial/inputoutput.html#reading-and-writing-files
- Standardizing Metric Logging: https://12factor.net/logs
