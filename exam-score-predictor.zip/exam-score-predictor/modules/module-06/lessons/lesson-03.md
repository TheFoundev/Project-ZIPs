# Lesson 03: Quality Assurance, Testing Checklists, and Debugging Common Faults

**Lesson ID:** lesson-03
**Module:** module-06
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Formulate a comprehensive Quality Assurance (QA) testing checklist for the regression pipeline
- Diagnose and debug the five most common exceptions encountered in data science scripts
- Verify reproducibility by testing across repeated executions
- Implement programmatic unit assertions to validate model parameters and metrics
- Recognize defensive coding patterns that prevent silent failures

## Prerequisites
- Completion of Lessons 01 and 02
- Familiarity with common Python exceptions (`ValueError`, `FileNotFoundError`, `KeyError`)

## Concept Explanation

### The Philosophy of Quality Assurance in Machine Learning
In traditional software engineering, code either runs or throws a syntax error.
In machine learning, however, **code can run with zero errors while producing completely invalid, broken models!**
Examples of silent failures:
- Accidentally fitting on test data (data leakage)
- Inverting features and targets ($X$ vs $y$)
- Shuffling data without setting `random_state`
- Evaluating on training data instead of test data

To ensure scientific integrity and software reliability, every data science pipeline must be verified against a strict **Quality Assurance Checklist**.

### The 10-Point QA Checklist for Exam Score Predictor

| # | Inspection Item | Verification Method | Expected Result |
|---|---|---|---|
| **1** | Working Directory Portability | Run script from outside directory | No `FileNotFoundError` |
| **2** | Headless Execution | Run in terminal without GUI display | No backend GUI warnings/crashes |
| **3** | Dataset Ingestion | Check `df.shape` | Exactly `(28, 2)` |
| **4** | Feature 2D Dimensionality | Check `X.ndim` and `X.shape` | 2D matrix: `(28, 1)` |
| **5** | Target 1D Dimensionality | Check `y.ndim` and `y.shape` | 1D vector: `(28,)` |
| **6** | Split Partitioning | Check `len(X_train)` and `len(X_test)` | Exactly 21 train, 7 test rows |
| **7** | Reproducibility | Run script twice with seed 42 | Identical metrics and slope |
| **8** | Metric Sanity Bounds | Verify MAE and R² ranges | $4.0 \le \text{MAE} \le 5.0$, $0.80 \le R^2 \le 0.90$ |
| **9** | Artifact Creation | Check disk for PNG and TXT | Both files present, non-zero size |
| **10**| Figure Cleanup | Check for unclosed figures | `plt.close(fig)` invoked |

### Debugging the 5 Most Common Faults

```
                      COMMON FAULT DECISION TREE
                                  │
  ┌───────────────────────────────┼───────────────────────────────┐
  ▼                               ▼                               ▼
FileNotFoundError           ValueError                      AttributeError
"No such file..."           "Expected 2D array..."          "no attribute 'coef_'"
  │                               │                               │
Check Path(__file__)        Used single brackets []         Called coef_ before
and BASE / "data"           Fix: use double brackets [[]]   calling model.fit()
```

#### Fault 1: `FileNotFoundError: [Errno 2] No such file or directory`
- **Cause**: User executed script from their home directory, and the script used a relative string path `"data/exam_scores.csv"`.
- **Solution**: Always resolve paths using `Path(__file__).resolve().parent`.

#### Fault 2: `ValueError: Expected 2D array, got 1D array instead`
- **Cause**: Feature matrix was created with single brackets `X = df["hours_studied"]` (producing a 1D Series).
- **Solution**: Use double brackets `X = df[["hours_studied"]]` to produce a 2D DataFrame.

#### Fault 3: `AttributeError: 'LinearRegression' object has no attribute 'coef_'`
- **Cause**: Accessing parameters before calling `model.fit()`.
- **Solution**: Ensure `model.fit(X_train, y_train)` is executed before inspecting parameters.

#### Fault 4: `KeyError: 'Hours_Studied'`
- **Cause**: Case sensitivity mismatch in column names.
- **Solution**: Match CSV headers exactly (`hours_studied` and `exam_score`).

#### Fault 5: Non-Reproducible Split (Fluctuating Metrics)
- **Cause**: Omitted `random_state=42` in `train_test_split()`.
- **Solution**: Always pin the pseudo-random seed.

## Relevant Code (Testing Script Example)
```python
def test_pipeline_integrity() -> None:
    # 1. Verify data loading
    df = pd.read_csv(DATA / "exam_scores.csv")
    assert df.shape == (28, 2), f"Expected (28, 2), got {df.shape}"

    # 2. Verify feature separation
    X = df[["hours_studied"]]
    y = df["exam_score"]
    assert X.shape == (28, 1), f"X must be 2D, got {X.shape}"
    assert y.shape == (28,), f"y must be 1D, got {y.shape}"

    # 3. Verify train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42
    )
    assert len(X_train) == 21, f"Expected 21 train, got {len(X_train)}"
    assert len(X_test) == 7, f"Expected 7 test, got {len(X_test)}"

    # 4. Verify model fitting & evaluation
    model = LinearRegression().fit(X_train, y_train)
    preds = model.predict(X_test)
    mae = mean_absolute_error(y_test, preds)
    r2 = r2_score(y_test, preds)

    assert abs(mae - 4.3208) < 0.01, f"MAE mismatch: {mae}"
    assert abs(r2 - 0.8486) < 0.01, f"R2 mismatch: {r2}"
    print("All pipeline integrity tests passed successfully!")
```

### Code explanation
- Python `assert` statements form a self-contained unit test suite that can be run in CI/CD to prevent regressions.

## Worked Example

**Problem:** How can you test if `main.py` creates identical output files when run twice in a row?
**Solution:**
In the terminal, run `main.py`, copy the outputs, run `main.py` again, and compare using `diff`:
```bash
python main.py
cp outputs/metrics.txt outputs/metrics_run1.txt
python main.py
diff outputs/metrics.txt outputs/metrics_run1.txt
echo "Diff status: $?"
```
Output:
```text
Diff status: 0
```
An exit code of 0 with no diff output confirms byte-for-byte reproducibility across runs!

## Step-by-Step Student Instructions
1. Open terminal and run a verification python test:
   ```bash
   python3 -c "
   import pandas as pd
   from sklearn.model_selection import train_test_split
   from sklearn.linear_model import LinearRegression
   from sklearn.metrics import mean_absolute_error, r2_score

   df = pd.read_csv('beginner-projects-main/AI-ML Beginners/projects/06_exam_score/data/exam_scores.csv')
   assert df.shape == (28, 2), 'Shape error'
   X_train, X_test, y_train, y_test = train_test_split(df[['hours_studied']], df['exam_score'], test_size=0.25, random_state=42)
   model = LinearRegression().fit(X_train, y_train)
   assert abs(model.coef_[0] - 5.2766) < 0.001, 'Slope error'
   assert abs(model.intercept_ - 35.8466) < 0.001, 'Intercept error'
   print('QA Sanity Check: PASSED!')
   "
   ```
2. Confirm that the terminal prints `QA Sanity Check: PASSED!`.

## Expected Output or Observable Behaviour
```text
QA Sanity Check: PASSED!
```
The assertion suite validates that all parameters and shapes match expected thresholds.

## Practical Exercises
**Exercise 3.1:** What happens if `random_state` is set to `123` instead of `42`? Does the script crash, or do the metrics change? Test and explain.
**Exercise 3.2:** Write an assertion to check that the predicted score for 6 hours is between 67.0 and 68.0 points.
**Exercise 3.3:** How would you test that `outputs/exam_score_regression.png` is not an empty 0-byte file using Python?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Relying only on visual inspection | Easy to miss subtle numerical discrepancies | Use automated assertions (`assert`) for rigorous verification |
| Testing only the happy path | Edge cases (0 hours, missing files) can crash production code | Write tests that verify behavior under abnormal inputs |
| Hardcoding assertion tolerances to 10 decimal places | Different operating system CPU architectures (ARM vs x86) can have minor floating-point jitter | Use `math.isclose()` or `np.allclose()` with reasonable tolerances ($10^{-4}$) |

## Best Practices and Security Considerations
- **Automated Regression Testing**: Include pipeline integrity checks in automated CI/CD workflows (e.g. GitHub Actions).
- **Tolerance-Based Assertions**: Compare floating-point values using tolerances (`abs(a - b) < 1e-4`) rather than exact equality (`==`).
- **Input Sanitization**: Validate dataset structure (column count, types, nulls) before initiating model fitting.

## Summary
Quality assurance separates fragile prototype scripts from robust data science software. By implementing an explicit 10-point checklist and validating dimensions, parameters, reproducibility, and file artifacts with automated assertions, developers guarantee that the regression pipeline operates reliably across all environments.

## Knowledge-check Questions
1. Why is code that executes without syntax errors not necessarily a valid machine learning model?
2. What error occurs when features are sliced with single brackets instead of double brackets?
3. What is the expected test set size for our 28-row dataset?
4. How does `random_state=42` protect scientific reproducibility?
5. What Python statement is used to programmatically assert conditions in test scripts?

## References
- Python `assert` statement documentation: https://docs.python.org/3/reference/simple_stmts.html#the-assert-statement
- Testing Machine Learning Pipelines: https://martinfowler.com/articles/cd4ml.html
