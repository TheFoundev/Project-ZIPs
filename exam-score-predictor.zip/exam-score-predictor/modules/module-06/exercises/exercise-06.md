# Module 6 Exercises: Complete Pipeline, Verification & Extensions

## Exercise 6.1: End-to-End Pipeline Execution & Exit Code Verification (15 min)
**Objective:** Execute `main.py` from the shell and programmatically verify execution success.

**Problem Statement:**
In automated CI/CD pipelines and production environments, scripts are executed headlessly and evaluated via shell exit codes and console output streams. Execute `main.py` and write a bash or Python wrapper to verify successful execution.

**Requirements:**
1. Execute `python main.py` inside `beginner-projects-main/AI-ML Beginners/projects/06_exam_score`.
2. Verify that the exit status code is `0`.
3. Verify that `outputs/exam_score_regression.png` exists and is non-empty.
4. Verify that `outputs/metrics.txt` exists and is non-empty.
5. Record the exact terminal execution output.

**Constraints:** Use standard terminal commands (`python`, `echo $?`, `ls -l`).

**Expected Behaviour:** Exit status `0` and both output files verified on disk.

**Acceptance Criteria:**
- [ ] Exit code confirmed as 0
- [ ] PNG image confirmed on disk
- [ ] `metrics.txt` confirmed on disk
- [ ] Console output matches expected 4-line format

**Hints:**
- Run `python main.py && echo "SUCCESS" || echo "FAILURE"`.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes

---

## Exercise 6.2: Output File Verification & Audit (15 min)
**Objective:** Parse and audit `outputs/metrics.txt` to verify model numerical integrity.

**Problem Statement:**
Write a Python auditing script `audit_metrics.py` that reads `outputs/metrics.txt` and programmatically checks that all four recorded values fall within expected tolerance ranges.

**Requirements:**
1. Open and parse `outputs/metrics.txt`.
2. Extract:
   - Slope (from equation string)
   - Intercept (from equation string)
   - Mean absolute error
   - R-squared
   - 6-hour prediction
3. Assert:
   - `5.27 <= slope <= 5.29`
   - `35.80 <= intercept <= 35.90`
   - `4.30 <= mae <= 4.35`
   - `0.84 <= r2 <= 0.86`
   - `67.4 <= six_hours <= 67.6`
4. Print a validation report indicating that all 5 assertions passed.

**Constraints:** Pure Python script with explicit assertions.

**Expected Behaviour:** The auditing script runs and reports 100% pass status.

**Acceptance Criteria:**
- [ ] Script parses `metrics.txt` cleanly
- [ ] All 5 assertions execute and pass
- [ ] Clear audit report printed to console

**Hints:**
- Use regex or string slicing to extract numbers from the equation line.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 6.3: Building an Interactive Advising CLI (15 min)
**Objective:** Extend `main.py` into an interactive student advising tool that accepts user input.

**Problem Statement:**
Create a student advising script `advising_tool.py` that loads the trained model from `main.py` and allows a user to interactively type in their planned study hours, displaying their predicted score, error confidence range ($\pm 4.3$ points), and advising letter grade.

**Requirements:**
1. Train the `LinearRegression` model on `exam_scores.csv`.
2. Prompt the user: `"Enter planned study hours (or 'quit'): "`.
3. If user enters hours (e.g. `7.5`):
   - Calculate predicted score.
   - Calculate score range: `[pred - 4.3, pred + 4.3]`.
   - Assign letter grade: $\ge 85 \rightarrow \text{A}$, $\ge 75 \rightarrow \text{B}$, $\ge 65 \rightarrow \text{C}$, $\ge 55 \rightarrow \text{D}$, $< 55 \rightarrow \text{F}$.
   - Print formatted advising card.
4. If study hours $> 10$ or $< 1.5$, display an extrapolation warning.

**Constraints:** Interactive loop with `try...except` input validation.

**Expected Behaviour:** User enters hours, receives instant score and grade estimate with confidence bounds.

**Acceptance Criteria:**
- [ ] User input successfully parsed and validated
- [ ] Accurate prediction calculated using trained model
- [ ] Confidence bounds ($\pm 4.3$ points) displayed
- [ ] Extrapolation warnings displayed for extreme inputs

**Hints:**
- Use a `while True:` loop with `input()`.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 6.4: Designing a Multivariate Academic Dataset Schema (15 min)
**Objective:** Design a multivariate data schema and simulate model expansion.

**Problem Statement:**
Design an expanded data schema for an academic counseling department that collects 5 predictive features. Write a simulation script demonstrating how scikit-learn trains on this expanded schema.

**Requirements:**
1. Design a schema with 5 features:
   - `hours_studied` (float, 0 - 15)
   - `attendance_pct` (float, 50 - 100)
   - `assignments_completed` (int, 0 - 10)
   - `sleep_hours_avg` (float, 4 - 10)
   - `prior_gpa` (float, 2.0 - 4.0)
   - `exam_score` (target, float, 0 - 100)
2. Generate a synthetic DataFrame of 50 student records adhering to this schema.
3. Fit `LinearRegression` on the multivariate features.
4. Print each feature's learned coefficient and explain what each coefficient represents.

**Constraints:** Use pandas and scikit-learn.

**Expected Behaviour:** Synthetic dataset created, multivariate model fitted, and individual feature weights printed.

**Acceptance Criteria:**
- [ ] 5 features cleanly defined and generated
- [ ] Shape of feature matrix $X$ is `(50, 5)`
- [ ] Model trains cleanly with 5 coefficients
- [ ] Summary table prints weights and interpretations

**Hints:**
- `model.coef_` will be an array of length 5.

**Difficulty:** Advanced  
**Estimated Completion Time:** 15 minutes
