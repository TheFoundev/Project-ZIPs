# Module 3 Exercises: Linear Regression Algorithm & Math

## Exercise 3.1: Manual Calculation of Line Coordinates (15 min)
**Objective:** Calculate coordinate pairs along the line of best fit and plot them conceptually.

**Problem Statement:**
The Exam Score Predictor learned the regression equation:
$$\text{score} = 5.28 \times \text{hours} + 35.85$$
You must calculate the predicted exam scores for a range of student study durations and verify the rate of change.

**Requirements:**
1. Calculate the predicted score for:
   - $x = 1.0\text{ hours}$
   - $x = 3.0\text{ hours}$
   - $x = 5.0\text{ hours}$
   - $x = 7.0\text{ hours}$
   - $x = 9.0\text{ hours}$
2. Calculate the difference in points between consecutive 2-hour increments (e.g. score at 3 hrs minus score at 1 hr).
3. Confirm that this difference exactly equals $2 \times 5.28 = 10.56\text{ points}$.
4. State the predicted score for a student who studied 0 hours. What parameter does this correspond to?

**Constraints:** Show your mathematical step-by-step arithmetic.

**Expected Behaviour:** A structured table of study hours and corresponding predicted scores.

**Acceptance Criteria:**
- [ ] Correct score at 1 hr ($41.13$), 3 hrs ($51.69$), 5 hrs ($62.25$), 7 hrs ($72.81$), 9 hrs ($83.37$)
- [ ] Consecutive differences verified as exactly $10.56\text{ points}$
- [ ] 0-hour score identified as $35.85\text{ points}$ (the intercept)

**Hints:**
- $\text{score} = 5.28 \times x + 35.85$.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes

---

## Exercise 3.2: Calculating Residuals and Squared Errors (15 min)
**Objective:** Compute residuals and understand the Ordinary Least Squares objective function.

**Problem Statement:**
Given three actual student records from the dataset:
- Student A: studied 3.0 hours, earned 46.2 points
- Student B: studied 4.7 hours, earned 69.2 points
- Student C: studied 8.1 hours, earned 82.4 points

Calculate their predicted scores using the fitted model equation ($\text{score} = 5.28 \times \text{hours} + 35.85$), determine their individual residuals ($e_i = y_i - \hat{y}_i$), and calculate their squared error contributions.

**Requirements:**
1. Calculate the predicted score $\hat{y}$ for Students A, B, and C.
2. Calculate the residual $e_i = y_i - \hat{y}_i$ for each student, preserving sign.
3. Identify which student outperformed the model's expectation and which student underperformed.
4. Calculate the squared residual $e_i^2$ for each student.
5. Compute the sum of squared errors across these three samples.

**Constraints:** Show all intermediate arithmetic rounded to 2 decimal places.

**Expected Behaviour:** Complete calculations showing prediction, signed residual, and squared residual.

**Acceptance Criteria:**
- [ ] Student A prediction: $5.28(3.0) + 35.85 = 51.69$; residual: $46.2 - 51.69 = -5.49$ (underperformed)
- [ ] Student B prediction: $5.28(4.7) + 35.85 = 60.67$; residual: $69.2 - 60.67 = +8.53$ (outperformed)
- [ ] Student C prediction: $5.28(8.1) + 35.85 = 78.62$; residual: $82.4 - 78.62 = +3.78$ (outperformed)
- [ ] Squared errors calculated correctly: $(-5.49)^2 \approx 30.14$, $(8.53)^2 \approx 72.76$, $(3.78)^2 \approx 14.29$
- [ ] Sum of squared errors calculated: $30.14 + 72.76 + 14.29 = 117.19$

**Hints:**
- Positive residual means the actual point is above the line.
- Negative residual means the actual point is below the line.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 3.3: Extracting Model Attributes in scikit-learn (15 min)
**Objective:** Write Python code to instantiate, fit, and extract attributes from `LinearRegression`.

**Problem Statement:**
Write a standalone Python script that trains `LinearRegression` on `X_train` and `y_train` from `exam_scores.csv` and prints the model parameters with full precision and formatted precision.

**Requirements:**
1. Import `LinearRegression` from `sklearn.linear_model`.
2. Load and split the dataset with `test_size=0.25, random_state=42`.
3. Fit `model = LinearRegression()` on the training data.
4. Extract `slope = float(model.coef_[0])` and `intercept = float(model.intercept_)`.
5. Print both variables formatted to 4 decimal places (matching `metrics.txt`) and 2 decimal places (matching the console).
6. Verify that `slope` is approximately $5.2766$ and `intercept` is approximately $35.8466$.

**Constraints:** Use Python 3 and scikit-learn.

**Expected Behaviour:** Python script execution producing exact matching parameters.

**Acceptance Criteria:**
- [ ] Script runs without errors
- [ ] `model.coef_[0]` correctly indexed
- [ ] Output displays both 4-decimal and 2-decimal formatting
- [ ] Values match $5.2766$ and $35.8466$

**Hints:**
- Format strings: `f"{slope:.4f}"` and `f"{slope:.2f}"`.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes

---

## Exercise 3.4: Academic Scenario Planning & Advising (15 min)
**Objective:** Apply the fitted regression equation to solve real-world student advising scenarios.

**Problem Statement:**
A college advisor is using our fitted model ($\text{score} = 5.28 \times \text{hours} + 35.85$) to guide students preparing for their finals. Solve the following three student advising scenarios.

**Requirements:**
1. **Scenario 1 (Target Setting):** A student needs a minimum score of 75.0 points to maintain their scholarship. How many hours of study should the advisor recommend?
2. **Scenario 2 (Marginal Trade-off):** A student is currently planning to study 4.0 hours. They are considering sacrificing 2 hours of leisure time to study 6.0 hours instead. What is their projected score increase, and what are their projected scores at 4.0 and 6.0 hours?
3. **Scenario 3 (Extrapolation Analysis):** An over-anxious student asks what score they would get if they study 15.0 hours. Calculate the model's prediction and explain what advice the counselor should give regarding the validity of that prediction.

**Constraints:** Show all algebraic steps and provide a reasoned advising response.

**Expected Behaviour:** Complete solutions with both algebraic derivation and domain-grounded explanations.

**Acceptance Criteria:**
- [ ] Scenario 1: $75 = 5.28x + 35.85 \rightarrow 5.28x = 39.15 \rightarrow x \approx 7.41\text{ hours}$ (recommend ~7.5 hours)
- [ ] Scenario 2: Gain is $2 \times 5.28 = 10.56\text{ points}$; Score at 4 hrs is $56.97$; Score at 6 hrs is $67.53$
- [ ] Scenario 3: $5.28(15) + 35.85 = 115.05\text{ points}$; Counselor explains that exams cap at 100 points, diminishing returns set in, and fatigue will degrade performance past ~10 hours

**Hints:**
- Solve for $x$: $x = \frac{\text{target} - \text{intercept}}{\text{slope}}$.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes
