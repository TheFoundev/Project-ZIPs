# Lesson 01: The Geometry of the Line of Best Fit ($y = mx + b$)

**Lesson ID:** lesson-01
**Module:** module-03
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Formulate the classical slope-intercept equation of a line: $y = mx + b$
- Map machine learning terms (feature, target, weight, bias) to geometric concepts
- Visualize how a 1D linear model forms a straight line across a 2D scatter plot
- Explain why a single straight line can capture the general trend of noisy data

## Prerequisites
- Basic high school coordinate geometry ($x$-axis, $y$-axis)
- Module 02 (understanding student data distributions)

## Concept Explanation

### Connecting High School Algebra to Machine Learning
In secondary school algebra, you learned that any non-vertical straight line in a two-dimensional Cartesian plane is defined by the **slope-intercept form**:

$$y = m \cdot x + b$$

Where:
- $x$ is the input on the horizontal axis
- $y$ is the output on the vertical axis
- $m$ is the **slope** (steepness or rate of rise over run)
- $b$ is the **y-intercept** (the point where the line crosses the vertical axis at $x = 0$)

In modern machine learning and statistics, we express this exact same mathematical relationship using slightly different notation, but the fundamental concepts are identical:

$$\hat{y} = w \cdot x + b \quad \text{or} \quad \hat{y} = \theta_1 \cdot x + \theta_0$$

| High School Geometry | Machine Learning Term | Project Implementation | Value in `main.py` |
|---|---|---|---|
| Independent variable ($x$) | Feature ($X$) | `hours_studied` | Input (e.g. 6.0) |
| Dependent variable ($y$) | Target outcome ($y$) | `exam_score` | Target (0 - 100) |
| Output along the line ($y$) | Model prediction ($\hat{y}$) | `predictions` / `six_hours` | Estimated score |
| Slope ($m$) | Weight / Coefficient ($w$ or $\text{coef\_}$) | `slope` | $\approx 5.28$ |
| Y-intercept ($b$) | Bias / Intercept ($b$ or $\text{intercept\_}$) | `intercept` | $\approx 35.85$ |

### What Does "Line of Best Fit" Mean?
If we plot our 21 training students on a graph where the horizontal axis represents `hours_studied` and the vertical axis represents `exam_score`, the dots do not line up in a perfect, microscopic row. Real humans are complex:
- One student studied 3.0 hours and scored 46.2.
- Another student studied 3.0 hours and scored 52.4.
- Another student studied 3.8 hours and scored 66.4.

Because real data contains natural variation (differences in student background, sleep, question difficulty, and luck), no single straight line can pass through every single point simultaneously.

The **line of best fit** is the unique straight line that passes as close as possible to all data points simultaneously, summarizing the universal trend while averaging out the individual noise.

## Relevant Code (from main.py, lines 41-42, 50, 55-56)
```python
    slope = float(model.coef_[0])
    intercept = float(model.intercept_)

    print(f"Model: score = {slope:.2f} x hours + {intercept:.2f}")

    line_x = np.linspace(df["hours_studied"].min(), df["hours_studied"].max(), 100)
    line_y = model.predict(pd.DataFrame({"hours_studied": line_x}))
```

### Code explanation
- scikit-learn stores the learned slope in `model.coef_` (an array) and the learned intercept in `model.intercept_` (a scalar).
- Line 50 formats the mathematical equation into human-readable text: `score = 5.28 x hours + 35.85`.
- Lines 55-56 generate 100 coordinates along the line to draw the continuous red line of best fit across the scatter plot.

## Worked Example

**Problem:** Using the learned equation $\text{score} = 5.28 \times \text{hours} + 35.85$, calculate the predicted score $\hat{y}$ for a student who studied 4.0 hours.
**Solution:**
1. Substitute $x = 4.0$ into the equation:
   $$\hat{y} = 5.28 \times 4.0 + 35.85$$
2. Perform multiplication:
   $$5.28 \times 4.0 = 21.12$$
3. Add the intercept:
   $$\hat{y} = 21.12 + 35.85 = 56.97\text{ points}$$
The line of best fit predicts that a student studying 4.0 hours will achieve approximately 57.0 points.

## Step-by-Step Student Instructions
1. Open terminal and run python:
   ```bash
   python3
   ```
2. Import numpy and matplotlib:
   ```python
   import numpy as np
   import matplotlib.pyplot as plt
   ```
3. Define the slope and intercept from `main.py`:
   ```python
   m = 5.2766
   b = 35.8466
   ```
4. Generate x-coordinates from 0 to 10 hours and compute y-values:
   ```python
   x = np.array([0, 2, 4, 6, 8, 10])
   y = m * x + b
   for hours, score in zip(x, y):
       print(f"{hours} hours -> {score:.2f} points")
   ```
5. Confirm that each 2-hour increase adds exactly $2 \times 5.2766 = 10.55\text{ points}$.

## Expected Output or Observable Behaviour
```text
0 hours -> 35.85 points
2 hours -> 46.40 points
4 hours -> 56.95 points
6 hours -> 67.51 points
8 hours -> 78.06 points
10 hours -> 88.61 points
```
The calculated values demonstrate the rigid, predictable progression of a linear equation.

## Practical Exercises
**Exercise 1.1:** If slope $m = 0$, what does the line look like on a graph? What would that imply about the relationship between study hours and exam scores?
**Exercise 1.2:** If slope $m < 0$, what would that indicate about studying?
**Exercise 1.3:** Calculate the predicted score for $x = 8.0$ hours using $m = 5.28$ and $b = 35.85$.

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Confusing $\hat{y}$ with actual $y$ | $y$ is the true ground-truth score in the dataset; $\hat{y}$ is the model's estimate on the line | Use $y$ for actuals and $\hat{y}$ (or `y_pred`) for predictions |
| Swapping slope and intercept | Writing $\text{score} = 35.85 \times \text{hours} + 5.28$ yields impossible results (e.g. 220 points at 6 hours) | Ensure slope multiplies the feature: $m \cdot x + b$ |
| Expecting all training points to lie on the line | Empirical data always exhibits statistical variance | The line represents the expected mean trend, not an exact fit through all points |

## Best Practices and Security Considerations
- **Mathematical Grounding**: Always connect algorithmic code back to the governing mathematical equations to ensure full explainability.
- **Visual Inspection**: Never trust numbers alone; always plot the line over the scatter data to verify that the linear model makes visual sense.
- **Model Explainability**: Linear regression is inherently interpretable, making it suitable for high-stakes domains like education where stakeholders require transparency.

## Summary
The line of best fit translates the high school algebra formula $y = mx + b$ into a predictive engine. By modeling exam scores as $\text{score} = 5.28 \times \text{hours} + 35.85$, the model captures the central trend of the student cohort while smoothing out individual variations.

## Knowledge-check Questions
1. In the equation $y = mx + b$, what do $m$ and $b$ represent?
2. What symbol is commonly used in machine learning to distinguish a predicted value from a true value?
3. What is the value of the slope learned by the model in `main.py`?
4. What is the value of the intercept learned by the model in `main.py`?
5. Why doesn't the line of best fit pass through every single point in the training dataset?

## References
- Khan Academy: Slope-Intercept Form: https://www.khanacademy.org/math/algebra/x2f8bb11595b61c86:linear-equations-graphs
- scikit-learn Linear Regression mathematical formulation: https://scikit-learn.org/stable/modules/linear_model.html#ordinary-least-squares
