# Lesson 03: Interpreting Slope: Marginal Exam Points per Study Hour ($+5.28$)

**Lesson ID:** lesson-03
**Module:** module-03
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define the mathematical meaning of slope in linear regression
- Extract the slope parameter from a fitted scikit-learn model using `model.coef_[0]`
- Interpret the slope value ($\approx 5.28$) in the context of student academic achievement
- Calculate expected score increases over multi-hour study intervals
- Explain the concept of "marginal rate of return" in educational analytics

## Prerequisites
- Completion of Lessons 01 and 02
- Understanding of slopes as rates of change ($\frac{\Delta y}{\Delta x}$)

## Concept Explanation

### The Mathematical Definition of Slope
In calculus and geometry, the slope represents the instantaneous rate of change of the dependent variable with respect to the independent variable:

$$\text{Slope} = \frac{\Delta y}{\Delta x} = \frac{\text{Change in Exam Score}}{\text{Change in Hours Studied}}$$

When we rearrange this formula:
$$\Delta y = \text{Slope} \times \Delta x$$

This means: **For every 1-unit increase in $x$ (1 additional hour studied), the predicted exam score changes by exactly the value of the slope.**

### Extracting Slope in scikit-learn
In scikit-learn, after calling `model.fit(X_train, y_train)`, the learned slopes are stored in the attribute `model.coef_`.
Because scikit-learn supports multiple features ($X_1, X_2, \dots, X_p$), `model.coef_` is always stored as a 1D NumPy array.

In `main.py`, line 41 extracts the slope:
```python
slope = float(model.coef_[0])
```
- `model.coef_`: Returns `array([5.27660351])`
- `[0]`: Extracts the first (and only) coefficient from the array: `5.27660351...`
- `float(...)`: Converts NumPy's `float64` scalar into a standard Python `float`.

When formatted to two decimal places (`f"{slope:.2f}"`), the value is **5.28**.

### Domain Interpretation: What Does 5.28 Mean for a Student?
In machine learning, numbers must never remain abstract—they must be translated into actionable domain insights.

Here is what **$\text{Slope} = 5.28$** means in plain English:
1. **Positive Return on Investment**: The slope is positive ($+5.28 > 0$), mathematically confirming that studying pays off. There is a strong positive return on time invested.
2. **Marginal Rate of Return**: On average across the student cohort, **each additional hour of focused study yields approximately 5.28 additional exam points**.
3. **Compound Study Gains**:
   - Studying **1 extra hour** $\rightarrow +5.28\text{ points}$
   - Studying **2 extra hours** $\rightarrow 2 \times 5.28 = +10.56\text{ points}$ (roughly a full letter grade improvement!)
   - Studying **4 extra hours** $\rightarrow 4 \times 5.28 = +21.12\text{ points}$ (turning a failing 45 into a passing 66!)

```
  ┌─────────────────────────────────────────────────────────────┐
  │              MARGINAL STUDY VALUE CHEAT SHEET               │
  ├───────────────────────┬─────────────────────────────────────┤
  │ Additional Study Time │ Expected Score Improvement          │
  ├───────────────────────┼─────────────────────────────────────┤
  │ +30 minutes (0.5 hr)  │ +2.64 points                        │
  │ +1 hour               │ +5.28 points                        │
  │ +2 hours              │ +10.56 points (1 Full Letter Grade) │
  │ +3 hours              │ +15.84 points                       │
  │ +5 hours              │ +26.40 points (2.5 Letter Grades)   │
  └───────────────────────┴─────────────────────────────────────┘
```

### Academic Advising in Action
Imagine an academic counselor speaking with a student currently scoring around 50 points (failing). The student asks: *"Can I realistically pass this exam with a 65 if I study over the weekend?"*

Thanks to our model's slope:
$$\Delta y = 65 - 50 = +15\text{ points needed}$$
$$\Delta x = \frac{\Delta y}{\text{Slope}} = \frac{15}{5.28} \approx 2.84\text{ hours}$$

The counselor can give evidence-based guidance: *"Yes! If you invest approximately 3 additional hours of focused revision, historical student data shows that a 15-point increase is well within reach."*

## Relevant Code (from main.py, lines 41, 50)
```python
    slope = float(model.coef_[0])
    intercept = float(model.intercept_)

    print(f"Model: score = {slope:.2f} x hours + {intercept:.2f}")
```

### Code explanation
- `model.coef_[0]` extracts the coefficient for `hours_studied`.
- The print statement formats the slope to 2 decimal places (`5.28`), creating an intuitive linear equation.

## Worked Example

**Problem:** Student A plans to study for 3.5 hours. Student B plans to study for 6.5 hours. According to our model's slope of 5.28, how many more points is Student B expected to score compared to Student A?
**Solution:**
1. Calculate the difference in study hours:
   $$\Delta x = 6.5 - 3.5 = 3.0\text{ hours}$$
2. Multiply by the marginal slope:
   $$\Delta y = 3.0 \times 5.28 = 15.84\text{ points}$$
Student B is predicted to score approximately **15.8 points higher** than Student A.

## Step-by-Step Student Instructions
1. Open terminal and run python3:
   ```bash
   python3
   ```
2. Train the model and inspect `coef_`:
   ```python
   import pandas as pd
   from sklearn.model_selection import train_test_split
   from sklearn.linear_model import LinearRegression

   df = pd.read_csv("beginner-projects-main/AI-ML Beginners/projects/06_exam_score/data/exam_scores.csv")
   X = df[["hours_studied"]]
   y = df["exam_score"]
   X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)

   model = LinearRegression()
   model.fit(X_train, y_train)

   print("Type of model.coef_:", type(model.coef_))
   print("Shape of model.coef_:", model.coef_.shape)
   print("Raw slope value:", model.coef_[0])
   print(f"Formatted slope: {model.coef_[0]:.2f}")
   ```
3. Confirm that `model.coef_` is a NumPy ndarray of shape `(1,)`.
4. Confirm that the formatted slope is `5.28`.

## Expected Output or Observable Behaviour
```text
Type of model.coef_: <class 'numpy.ndarray'>
Shape of model.coef_: (1,)
Raw slope value: 5.276603510821103
Formatted slope: 5.28
```
The output confirms the internal structure and numerical precision of the slope parameter.

## Practical Exercises
**Exercise 3.1:** What would a slope of $-3.5$ imply if you were analyzing the relationship between video game hours and exam score?
**Exercise 3.2:** If a student studies 10 hours instead of 5 hours, how many additional exam points does the model project they will gain?
**Exercise 3.3:** Why is `[0]` required when accessing `model.coef_[0]`? What happens if you try `float(model.coef_)`?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Forgetting `[0]` index on `coef_` | `model.coef_` is a 1D NumPy array; writing `float(model.coef_)` raises a `TypeError: only size-1 arrays can be converted to Python scalars` | Always write `model.coef_[0]` |
| Accessing `coef_` before `fit()` | Estimator attributes ending with a trailing underscore `_` only exist after fitting; calling before fit raises `AttributeError` | Call `model.fit(X_train, y_train)` first |
| Misinterpreting slope as total score | Slope is the *rate of change*, not the final score; studying 1 hour does not give 5.28 points total | Add the intercept: $5.28 \times 1 + 35.85 = 41.13\text{ points}$ |

## Best Practices and Security Considerations
- **Trailing Underscore Convention**: In scikit-learn, all attributes estimated from data end with a trailing underscore (e.g. `coef_`, `intercept_`). Attributes without underscores are user-specified hyperparameters.
- **Contextual Communication**: When presenting findings to non-technical educators, communicate the slope as a tangible rate of return (e.g., "+5.3 points per hour") rather than abstract weights.
- **Dimensionality Safety**: Always verify how many features were passed before indexing `coef_`.

## Summary
The slope parameter represents the marginal return of study time. Extracted via `model.coef_[0]`, our model's slope of approximately $+5.28$ indicates that each additional hour of revision is associated with an expected gain of 5.28 exam points. This provides concrete, evidence-based guidance for students planning their revision schedules.

## Knowledge-check Questions
1. What scikit-learn attribute stores the model's learned slope?
2. Why is `[0]` needed when indexing `model.coef_[0]`?
3. What is the value of the slope rounded to two decimal places?
4. If a student increases study time from 2 hours to 4 hours, what is their expected score gain?
5. What does a positive slope value tell us about the relationship between study hours and exam performance?

## References
- scikit-learn LinearRegression attributes: https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html
- Marginal Analysis in Statistics: https://en.wikipedia.org/wiki/Marginal_concepts
