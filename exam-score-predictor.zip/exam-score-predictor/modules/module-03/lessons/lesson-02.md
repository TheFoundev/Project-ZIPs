# Lesson 02: Ordinary Least Squares (OLS) and Minimizing Residuals

**Lesson ID:** lesson-02
**Module:** module-03
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define a **residual** (error) as $e_i = y_i - \hat{y}_i$
- Explain why simple sum of errors cannot be used to find the best line
- Explain why squaring residuals solves the problem of canceling signs and penalizes large errors
- Formulate the Ordinary Least Squares (OLS) objective: $\min \sum (y_i - \hat{y}_i)^2$
- Understand how `LinearRegression()` finds the optimal slope and intercept analytically

## Prerequisites
- Completion of Lesson 01
- Basic understanding of squaring numbers (e.g. $(-3)^2 = +9$)

## Concept Explanation

### What is a Residual?
When we draw candidate lines through our student scatter plot, almost every point will sit slightly above or slightly below the line. 

For any individual student data point $(x_i, y_i)$:
- $y_i$ is the student's **actual** observed score.
- $\hat{y}_i = m x_i + b$ is the score **predicted** by the line at study time $x_i$.

The vertical distance between the actual score and the line is called the **residual** or **prediction error** ($e_i$):

$$e_i = y_i - \hat{y}_i = y_i - (m x_i + b)$$

- If a student scored higher than the line predicts, the point lies above the line, and the residual is **positive** ($e_i > 0$).
- If a student scored lower than the line predicts, the point lies below the line, and the residual is **negative** ($e_i < 0$).
- If the line passes directly through a point, the residual is zero ($e_i = 0$).

```
       Exam Score
          ▲
          │           ● (Actual: y_i = 66.4)
          │           │
          │           │ Residual e_i = +9.4
          │           ▼
          │───────────x───────────── Line of Best Fit: y_hat = 57.0
          │
          │
          └────────────────────────► Hours Studied (x_i = 4.0)
```

### Why Can't We Just Minimize the Sum of Errors?
Suppose a candidate line has two points:
- Student A: actual = 60, predicted = 50 $\rightarrow e_A = +10$
- Student B: actual = 40, predicted = 50 $\rightarrow e_B = -10$

If we simply add the errors together:
$$\text{Sum of Errors} = (+10) + (-10) = 0$$
The sum is zero! A terrible line that misses both students by 10 points would look mathematically "perfect" because positive and negative errors cancel each other out.

### The Ordinary Least Squares (OLS) Solution
To solve this cancellation problem, statisticians square each residual before adding them up. Because the square of any real number is always non-negative ($(-10)^2 = +100$), errors cannot cancel each other out!

The total error across all $n$ training points is called the **Residual Sum of Squares (RSS)**:

$$\text{RSS}(m, b) = \sum_{i=1}^{n} e_i^2 = \sum_{i=1}^{n} (y_i - \hat{y}_i)^2 = \sum_{i=1}^{n} [y_i - (m x_i + b)]^2$$

**Ordinary Least Squares (OLS)** is the mathematical method that finds the exact values of slope ($m$) and intercept ($b$) that make the Residual Sum of Squares as small as physically possible:

$$\min_{m, b} \sum_{i=1}^{n} (y_i - (m x_i + b))^2$$

### Why Squared Errors?
1. **Eliminates Sign Cancellation**: Both $+5$ and $-5$ become $+25$.
2. **Penalizes Severe Outliers**: An error of 2 points produces a squared penalty of $4$, whereas an error of 10 points produces a squared penalty of $100$ ($25\times$ larger!). This forces the line to stay close to all points rather than allowing huge misses.
3. **Smooth Calculus Optimization**: Squaring creates a convex parabola with a single unique global minimum that can be solved instantly using calculus derivatives (the Normal Equation).

When `model.fit(X_train, y_train)` is executed in line 38 of `main.py`, scikit-learn computes this exact mathematical minimum closed-form solution.

## Relevant Code (from main.py, lines 37-38)
```python
    model = LinearRegression()
    model.fit(X_train, y_train)
```

### Code explanation
- `LinearRegression()` is scikit-learn's implementation of Ordinary Least Squares.
- The `.fit()` method takes the 21 training observations and analytically calculates the slope and intercept that minimize the sum of squared residuals.

## Worked Example

**Problem:** Suppose a model predicts scores for three students:
- Student 1: Actual = 70, Predicted = 68
- Student 2: Actual = 50, Predicted = 55
- Student 3: Actual = 80, Predicted = 77
Calculate each residual, the sum of residuals, and the Residual Sum of Squares (RSS).

**Solution:**
1. Residuals:
   - $e_1 = 70 - 68 = +2$
   - $e_2 = 50 - 55 = -5$
   - $e_3 = 80 - 77 = +3$
2. Sum of residuals:
   $$\sum e_i = (+2) + (-5) + (+3) = 0$$
   (Notice the sum is zero, hiding the errors!)
3. Squared residuals:
   - $e_1^2 = (2)^2 = 4$
   - $e_2^2 = (-5)^2 = 25$
   - $e_3^2 = (3)^2 = 9$
4. Residual Sum of Squares (RSS):
   $$\text{RSS} = 4 + 25 + 9 = 38$$
OLS selects the line that minimizes this 38 value.

## Step-by-Step Student Instructions
1. Open terminal and run python:
   ```bash
   python3
   ```
2. Train the model and inspect the training residuals on the 21 training points:
   ```python
   import pandas as pd
   from sklearn.model_selection import train_test_split
   from sklearn.linear_model import LinearRegression

   df = pd.read_csv("beginner-projects-main/AI-ML Beginners/projects/06_exam_score/data/exam_scores.csv")
   X = df[["hours_studied"]]
   y = df["exam_score"]
   X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)

   model = LinearRegression()
   model.fit(X_train, y_train)
   train_preds = model.predict(X_train)
   residuals = y_train - train_preds
   print("Sum of training residuals:", residuals.sum())
   print("Residual Sum of Squares (RSS):", (residuals ** 2).sum())
   ```
3. Notice that the sum of training residuals is practically zero (e.g. $10^{-14}$, computer rounding for 0). This is a mathematical theorem of OLS!

## Expected Output or Observable Behaviour
```text
Sum of training residuals: -7.105427357601002e-15
Residual Sum of Squares (RSS): 818.2573678037307
```
The sum of residuals is zero ($10^{-15}$), and the RSS is minimized at $818.26$.

## Practical Exercises
**Exercise 2.1:** What is the residual of a student who studied 5.4 hours, earned 69.5, if the model predicts 64.34?
**Exercise 2.2:** Why does OLS penalize an error of 8 points much more heavily than two errors of 4 points each?
**Exercise 2.3:** Why is Ordinary Least Squares called "least squares" rather than "least absolute values"?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Calculating residual as $\hat{y} - y$ | Conventional statistics defines residual as actual minus predicted: $y - \hat{y}$ | While squaring yields the same RSS, always use $y - \hat{y}$ for correct directional sign |
| Believing OLS uses trial-and-error guessing | Simple linear regression has an exact closed-form calculus solution | OLS solves the normal equation directly without random iterations |
| Confusing RSS with MAE | RSS is the sum of squared errors; MAE is the average of absolute errors | Remember that RSS squares errors, while MAE averages un-squared distances |

## Best Practices and Security Considerations
- **Convexity & Stability**: OLS has a strictly convex cost surface, guaranteeing that `model.fit()` will never get stuck in local minima.
- **Sensitivity to Outliers**: Because errors are squared, extreme data errors (e.g., someone recording 900 hours instead of 9.0) will aggressively pull the OLS line. Always clean data before fitting.
- **Deterministic Optimization**: With fixed inputs, OLS will always compute the exact same optimal coefficients.

## Summary
Ordinary Least Squares (OLS) is the mathematical engine behind linear regression. By minimizing the sum of squared differences between actual student scores and model predictions ($\sum (y_i - \hat{y}_i)^2$), OLS prevents positive and negative errors from canceling, penalizes large mistakes, and finds the mathematically optimal line of best fit.

## Knowledge-check Questions
1. How is a residual defined mathematically?
2. What problem occurs if you evaluate a line by summing un-squared residuals?
3. What happens to the sign of a residual when it is squared?
4. What mathematical quantity does Ordinary Least Squares minimize?
5. What scikit-learn method executes the OLS optimization algorithm?

## References
- Ordinary Least Squares derivation: https://en.wikipedia.org/wiki/Ordinary_least_squares
- scikit-learn LinearRegression source overview: https://scikit-learn.org/stable/modules/linear_model.html#ordinary-least-squares
- Khan Academy: Minimizing Squared Errors: https://www.khanacademy.org/math/statistics-probability/describing-relationships-quantitative-data/more-on-regression/v/regression-line-example
