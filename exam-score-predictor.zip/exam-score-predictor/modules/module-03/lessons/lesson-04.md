# Lesson 04: Interpreting Intercept: Baseline Performance ($35.85$) and the Governing Equation

**Lesson ID:** lesson-04
**Module:** module-03
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define the mathematical meaning of the $y$-intercept in linear regression
- Extract the intercept parameter from scikit-learn using `model.intercept_`
- Interpret the intercept value ($\approx 35.85$) as baseline academic competence
- Combine slope and intercept into the complete governing prediction equation
- Analyze the validity and limitations of interpreting intercepts at $x = 0$

## Prerequisites
- Completion of Lessons 01, 02, and 03
- Understanding of slope ($5.28$) and linear functions

## Concept Explanation

### The Mathematical Definition of the Y-Intercept
In the equation of a line:
$$\hat{y} = \text{slope} \times x + \text{intercept}$$

If we set the input feature to zero ($x = 0$):
$$\hat{y} = \text{slope} \times 0 + \text{intercept} = \text{intercept}$$

Geometrically, the **$y$-intercept** is the point where the line of best fit crosses the vertical $y$-axis.
In machine learning terminology, the intercept is also called the **bias term** ($b$ or $\theta_0$). It represents the default baseline prediction when all input features are absent or equal to zero.

### Extracting Intercept in scikit-learn
In scikit-learn's `LinearRegression`, the intercept is stored in `model.intercept_`.
Unlike `coef_` (which is an array to support multiple features), `model.intercept_` is a single floating-point number.

In `main.py`, line 42 extracts the intercept:
```python
intercept = float(model.intercept_)
```
- Raw value: `35.8465638652725`
- Formatted to 2 decimal places: `35.85`

### Domain Interpretation: What Does 35.85 Mean?
In the context of examination scoring:
**The intercept of 35.85 represents the estimated baseline exam score for a student who studied zero hours ($x = 0$).**

Does an intercept of ~35.85 make sense in real life?
Yes, remarkably so!
1. **Prior General Knowledge**: Students attend lectures, participate in labs, and accumulate background knowledge over an entire academic term. A student who does zero dedicated revision before the final exam is not starting with total amnesia—they typically recall enough concepts to answer roughly a third of the test correctly.
2. **Multiple-Choice & Partial Credit**: On exams containing multiple-choice questions, guessing yields baseline points (e.g., 25% on a 4-option test). Partial credit on open-ended problems further elevates the floor above zero.
3. **Contrast with Sister Projects**:
   - In our sister project *The Lemonade Stand*, the intercept was **$-10.66$ cups**, which is physically impossible (you cannot sell negative lemonade).
   - In *Exam Score Predictor*, the intercept is **$+35.85$ points**, which is both mathematically valid and intuitively plausible!

### The Complete Governing Equation
Combining our slope ($\approx 5.28$) and intercept ($\approx 35.85$) yields the master equation of the model:

$$\mathbf{\text{exam\_score} = 5.28 \times \text{hours\_studied} + 35.85}$$

Or with 4 decimal places of scientific precision:
$$\text{exam\_score} = 5.2766 \times \text{hours\_studied} + 35.8466$$

```
  Exam Score (y)
     ▲
 100 │                                            ● 9.5 hrs -> 92.1 pts
  90 │                                     /
  80 │                              /
  70 │                       /  ★ 6.0 hrs -> 67.5 pts
  60 │                /
  50 │         /
  40 │  /
  35.85 ─── Intercept (Baseline score at 0 hours)
  20 │
  10 │
   0 └────┬────┬────┬────┬────┬────┬────┬────┬────┬────► Hours Studied (x)
     0    1    2    3    4    5    6    7    8    9   10
```

### Boundary Warning: Extrapolation vs. Interpolation
While an intercept of 35.85 is plausible, notice that the lowest study time in our actual dataset is **1.5 hours** (Row 23: 1.5 hours $\rightarrow$ 35.4 points).
Evaluating the line at $x = 0$ is technically **extrapolation**—predicting outside the boundaries of observed data. Data scientists should always clarify that the intercept is a theoretical mathematical baseline rather than a directly observed sample.

## Relevant Code (from main.py, lines 41-42, 50, 73)
```python
    slope = float(model.coef_[0])
    intercept = float(model.intercept_)

    print(f"Model: score = {slope:.2f} x hours + {intercept:.2f}")

    # Written to metrics.txt:
    handle.write(f"equation: score = {slope:.4f} * hours + {intercept:.4f}\n")
```

### Code explanation
- Line 42 extracts `model.intercept_`.
- Line 50 prints the equation to the terminal with 2 decimals.
- Line 73 saves the high-precision equation to `outputs/metrics.txt` using 4 decimals.

## Worked Example

**Problem:** Using the complete governing equation $\text{score} = 5.2766 \times \text{hours} + 35.8466$, verify the prediction for 6.0 hours of study to 2 decimal places.
**Solution:**
1. Substitute $\text{hours} = 6.0$:
   $$\text{score} = 5.2766 \times 6.0 + 35.8466$$
2. Compute the product:
   $$5.2766 \times 6.0 = 31.6596$$
3. Add the intercept:
   $$\text{score} = 31.6596 + 35.8466 = 67.5062$$
4. Round to 2 decimal places:
   $$\text{score} \approx 67.51\text{ points}$$
5. Compare with `metrics.txt`:
   `prediction at 6 hours: 67.51`
The manual equation evaluation matches the model's prediction down to the exact hundredth of a point!

## Step-by-Step Student Instructions
1. Open terminal and run python3:
   ```bash
   python3
   ```
2. Train the model and inspect `intercept_`:
   ```python
   import pandas as pd
   from sklearn.model_selection import train_test_split
   from sklearn.linear_model import LinearRegression

   df = pd.read_csv("beginner-projects-main/AI-ML Beginners/projects/06_exam_score/data/exam_scores.csv")
   X = df[["hours_studied"]]
   y = df["exam_score"]
   X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)

   model = LinearRegression()
   model.fit(X_train, y_train)

   print("Intercept type:", type(model.intercept_))
   print("Raw intercept:", model.intercept_)
   print(f"Formatted intercept: {model.intercept_:.2f}")
   ```
3. Test predicting for 0 hours using `model.predict`:
   ```python
   zero_hours = pd.DataFrame({"hours_studied": [0.0]})
   zero_pred = model.predict(zero_hours)[0]
   print(f"Prediction for 0 hours: {zero_pred:.4f}")
   ```
4. Confirm that the prediction for 0 hours equals the intercept exactly!

## Expected Output or Observable Behaviour
```text
Intercept type: <class 'numpy.float64'>
Raw intercept: 35.8465638652725
Formatted intercept: 35.85
Prediction for 0 hours: 35.8466
```
The prediction for zero study hours perfectly matches the model's intercept.

## Practical Exercises
**Exercise 4.1:** If an exam had no multiple choice questions and required intense memorization, would you expect the real-world intercept to be higher or lower than 35.85? Why?
**Exercise 4.2:** In some libraries, you can pass `fit_intercept=False` to `LinearRegression()`. What would the equation look like if `fit_intercept=False` were used, and why would that be harmful for this dataset?
**Exercise 4.3:** How does our model's positive intercept (+35.85) compare to the lemonade stand project's negative intercept (-10.66) in terms of physical realism?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Setting `fit_intercept=False` | Forces the line through $(0, 0)$, severely distorting the slope and increasing prediction error | Always keep `fit_intercept=True` (the default) unless theory strictly requires zero at origin |
| Indexing `intercept_` with `[0]` | `model.intercept_` is already a scalar float (not an array like `coef_`); writing `intercept_[0]` may raise an `IndexError` | Access directly as `float(model.intercept_)` |
| Assuming intercept represents a guaranteed grade | Intercept is an average statistical estimate, not a minimum floor | Individual students can still score below 35.85 if they guess poorly |

## Best Practices and Security Considerations
- **Boundary Verification**: Always check whether $x = 0$ is within or near the empirical feature distribution before attaching strong real-world claims to the intercept.
- **Equation Verification**: Always verify that `model.coef_[0] * x + model.intercept_` produces the exact same numerical output as `model.predict()`.
- **Interpretability Reporting**: Transparently report both slope and intercept when explaining model dynamics to non-technical users.

## Summary
The intercept parameter, extracted via `model.intercept_`, establishes the baseline prediction when the feature equals zero. In our project, an intercept of approximately $+35.85$ represents the estimated exam score with zero study hours, reflecting prior classroom exposure and general reasoning ability. Combined with a slope of $+5.28$, it forms the governing prediction equation: $\text{score} = 5.28 \times \text{hours} + 35.85$.

## Knowledge-check Questions
1. What scikit-learn attribute stores the model's learned intercept?
2. What does the intercept value (~35.85) represent in the context of student exam preparation?
3. What is the full governing equation printed by `main.py`?
4. What happens to the prediction if you evaluate the model equation at $\text{hours} = 0$?
5. Why is an intercept of +35.85 more intuitively plausible than the -10.66 intercept in the lemonade stand project?

## References
- scikit-learn LinearRegression documentation: https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html
- The Role of the Intercept in Linear Models: https://statisticsbyjim.com/regression/interpret-constant-y-intercept-regression/
