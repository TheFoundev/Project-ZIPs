# Lesson 02: Understanding Variance Explained with R² Score

**Lesson ID:** lesson-02
**Module:** module-05
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define the Coefficient of Determination ($R^2$) mathematically and conceptually
- Explain the concept of "total variance" versus "residual variance"
- Compare a trained regression model against a naive "mean-only" baseline model
- Calculate $R^2$ in Python using scikit-learn's `r2_score(y_test, predictions)`
- Interpret the project's test $R^2$ score ($\approx 0.85$) in the context of student exam prediction

## Prerequisites
- Completion of Lesson 01 (MAE and test evaluation)
- Basic understanding of statistical variance and proportions

## Concept Explanation

### What Does R-Squared ($R^2$) Measure?
While MAE tells us the average *error distance* in exam points, it does not tell us how much of the variation in student performance is actually explained by study hours alone.

This is where the **Coefficient of Determination ($R^2$)** comes in.
**$R^2$ measures the proportion of the total variance in the dependent target variable ($y$) that is explained by the independent feature(s) ($X$) through the linear model.**

$R^2$ typically ranges from **0 to 1** (or 0% to 100%):
- $R^2 = 1.0$ (100%): Perfect model. 100% of the variance is explained; all data points lie perfectly on the line.
- $R^2 = 0.0$ (0%): The model explains none of the variance; it performs no better than guessing the average score for every student.
- $R^2 < 0$: The model performs *worse* than simply predicting the mean (possible only on test sets if a model overfits terribly).

### The Baseline Model: The Naive Mean
To understand $R^2$, imagine a naive baseline model that knows nothing about study hours. If you ask this baseline to predict any student's score, it simply guesses the mean of all student scores: $\bar{y}$.

The error of this naive baseline is measured by the **Total Sum of Squares (TSS)**:
$$\text{TSS} = \sum_{i=1}^{n} (y_i - \bar{y})^2$$

Now, consider our trained linear regression model, which uses study hours to make predictions. Its remaining unexplained error is the **Residual Sum of Squares (RSS)**:
$$\text{RSS} = \sum_{i=1}^{n} (y_i - \hat{y}_i)^2$$

$R^2$ compares these two quantities:
$$R^2 = 1 - \frac{\text{RSS}}{\text{TSS}} = 1 - \frac{\text{Unexplained Variance}}{\text{Total Baseline Variance}}$$

```
  ┌─────────────────────────────────────────────────────────────┐
  │                 TOTAL VARIANCE IN EXAM SCORES               │
  │                        (TSS = 100%)                         │
  ├──────────────────────────────────────────────┬──────────────┤
  │       VARIANCE EXPLAINED BY STUDY HOURS      │ UNEXPLAINED  │
  │                  (R² ≈ 85%)                  │  (RSS ≈ 15%) │
  │    Due to preparation, practice, revision    │ Sleep, luck, │
  │                                              │ talent, etc. │
  └──────────────────────────────────────────────┴──────────────┘
```

### Interpreting R² ≈ 0.85 in Our Project
In `main.py`, line 52 prints:
`R-squared: 0.85`
And `outputs/metrics.txt` records:
`r2: 0.8486`

What does an $R^2$ of **0.85 (85%)** mean in real-world educational terms?
1. **Dominant Predictive Factor**: Approximately **85% of the differences in exam scores between students can be directly explained by differences in how many hours they studied**.
2. **The Remaining 15%**: The remaining **15% of score variation is due to unmeasured factors**—such as natural subject aptitude, sleep quality the night before, test anxiety, or difficulty of specific questions.
3. **Exceptional Fit for Human Data**: In social sciences and educational psychology, human behavior is notoriously noisy. Achieving an $R^2$ of 0.85 on unseen test data is an exceptionally strong result, proving that study time is the overwhelming determinant of performance in this course.

## Relevant Code (from main.py, lines 19, 39, 44, 52)
```python
from sklearn.metrics import mean_absolute_error, r2_score

# ...
predictions = model.predict(X_test)
# ...
r2 = r2_score(y_test, predictions)

print(f"R-squared: {r2:.2f}")
```

### Code explanation
- `r2_score(y_test, predictions)` computes the coefficient of determination on holdout test data.
- The console prints `r2` formatted to 2 decimal places (`0.85`).

## Worked Example

**Problem:** Suppose for a test set of 4 students:
- Total Sum of Squares (TSS) around the mean is $200.0$.
- Residual Sum of Squares (RSS) of our model is $30.0$.
Calculate $R^2$ and interpret the result.
**Solution:**
$$R^2 = 1 - \frac{\text{RSS}}{\text{TSS}} = 1 - \frac{30.0}{200.0} = 1 - 0.15 = 0.85$$
The model reduces prediction error by 85% compared to simply guessing the cohort mean.

## Step-by-Step Student Instructions
1. Open terminal and run python3:
   ```bash
   python3
   ```
2. Train model and compute $R^2$:
   ```python
   import pandas as pd
   from sklearn.model_selection import train_test_split
   from sklearn.linear_model import LinearRegression
   from sklearn.metrics import r2_score

   df = pd.read_csv("beginner-projects-main/AI-ML Beginners/projects/06_exam_score/data/exam_scores.csv")
   X = df[["hours_studied"]]
   y = df["exam_score"]
   X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)

   model = LinearRegression()
   model.fit(X_train, y_train)
   preds = model.predict(X_test)
   r2 = r2_score(y_test, preds)

   print(f"Raw R2: {r2}")
   print(f"Formatted 2-decimals: {r2:.2f}")
   print(f"Formatted 4-decimals: {r2:.4f}")
   ```
3. Confirm that the formatted outputs display `0.85` and `0.8486`.

## Expected Output or Observable Behaviour
```text
Raw R2: 0.8485838771699904
Formatted 2-decimals: 0.85
Formatted 4-decimals: 0.8486
```
The $R^2$ calculation matches `main.py` console output and `metrics.txt` exactly.

## Practical Exercises
**Exercise 2.1:** What does an $R^2$ of 0.0 indicate about a feature's predictive utility?
**Exercise 2.2:** Can $R^2$ ever be negative? Under what circumstances could this happen on a test set?
**Exercise 2.3:** Why is $R^2$ a dimensionless ratio (between 0 and 1) while MAE has physical units (points)?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Confusing $R^2$ with Pearson correlation ($r$) | $R^2 = r^2$ only on the training set in simple 1D linear regression; on test sets or multivariate models, they differ | Use `r2_score(y_test, predictions)` to evaluate test set performance |
| Believing $R^2$ can never exceed 1.0 | $R^2 = 1.0$ is the theoretical maximum; higher values are mathematically impossible | Check calculations if $R^2 > 1.0$ is reported |
| Using $R^2$ as the sole metric | A high $R^2$ can still hide large absolute point errors if variance is extreme | Always evaluate both scale-free ($R^2$) and scale-dependent (MAE) metrics |

## Best Practices and Security Considerations
- **Complementary Metrics**: Always present MAE and $R^2$ together. MAE communicates operational accuracy in real units, while $R^2$ communicates explanatory power as a percentage.
- **Holdout Evaluation**: Never report training $R^2$ as the primary indicator of model success; training $R^2$ is inherently over-optimistic.
- **Model Context**: A "good" $R^2$ depends on domain context: $R^2 \approx 0.85$ is outstanding for human educational behavior, whereas physical physics models often demand $R^2 > 0.99$.

## Summary
The Coefficient of Determination ($R^2$) quantifies the proportion of target variance explained by the model compared to a naive mean baseline. Evaluated on our 7 holdout test students, our model achieves an $R^2$ of approximately 0.85 (85%), proving that study hours account for the vast majority of student performance variation.

## Knowledge-check Questions
1. What does the $R^2$ metric measure conceptually?
2. What is the baseline model against which $R^2$ compares the regression model?
3. What is the $R^2$ value printed to the console by `main.py`?
4. What percentage of exam score variation remains unexplained by study hours in our model?
5. Why are MAE and $R^2$ complementary evaluation metrics?

## References
- scikit-learn r2_score documentation: https://scikit-learn.org/stable/modules/generated/sklearn.metrics.r2_score.html
- Coefficient of Determination on Wikipedia: https://en.wikipedia.org/wiki/Coefficient_of_determination
