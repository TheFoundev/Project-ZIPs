# Lesson 01: Evaluating Accuracy with Mean Absolute Error (MAE)

**Lesson ID:** lesson-01
**Module:** module-05
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define Mean Absolute Error (MAE) mathematically and conceptually
- Explain why MAE preserves the natural physical units of the target variable (exam points)
- Calculate MAE in Python using scikit-learn's `mean_absolute_error(y_test, predictions)`
- Interpret the project's test MAE ($\approx 4.32\text{ points}$, console: $4.3\text{ points}$) in an educational advising context
- Contrast MAE with Root Mean Squared Error (RMSE)

## Prerequisites
- Module 04 (Model training and generating test predictions)
- Basic understanding of absolute values ($|-5| = +5$)

## Concept Explanation

### Why We Need Evaluation Metrics
Once our model has been trained on `X_train` and evaluated on `X_test`, we obtain 7 test predictions.
Let's look at how the model performed on each student in the test set:

| Test Student | `hours_studied` | Actual Score ($y$) | Predicted Score ($\hat{y}$) | Error ($y - \hat{y}$) | Absolute Error ($|y - \hat{y}|$) |
|---|---|---|---|---|---|
| **Student 9** | 5.4 | 69.5 | 64.34 | $+5.16$ | $5.16$ points |
| **Student 25** | 4.2 | 54.1 | 58.01 | $-3.91$ | $3.91$ points |
| **Student 8** | 4.8 | 61.3 | 61.17 | $+0.13$ | $0.13$ points |
| **Student 21** | 6.4 | 74.0 | 69.62 | $+4.38$ | $4.38$ points |
| **Student 0** | 9.5 | 92.1 | 85.97 | $+6.13$ | $6.13$ points |
| **Student 12** | 2.4 | 50.5 | 48.51 | $+1.99$ | $1.99$ points |
| **Student 17** | 4.7 | 69.2 | 60.65 | $+8.55$ | $8.55$ points |

Looking at a table of 7 individual errors is useful, but stakeholders need a **single summary number** that quantifies the overall accuracy of the model.

### The Mathematical Formula for MAE
**Mean Absolute Error (MAE)** measures the average magnitude of the errors between model predictions and actual ground-truth outcomes, regardless of their direction:

$$\text{MAE} = \frac{1}{n_{\text{test}}} \sum_{i=1}^{n_{\text{test}}} |y_i - \hat{y}_i|$$

Where:
- $n_{\text{test}}$ is the number of test observations ($7$)
- $y_i$ is the actual exam score of student $i$
- $\hat{y}_i$ is the predicted exam score of student $i$
- $|y_i - \hat{y}_i|$ is the absolute distance between actual and prediction

Let's calculate the sum of absolute errors for our 7 test students:
$$\text{Sum} = 5.16 + 3.91 + 0.13 + 4.38 + 6.13 + 1.99 + 8.55 = 30.25$$
$$\text{MAE} = \frac{30.25}{7} \approx \mathbf{4.32\text{ points}}$$

### The Beauty of MAE: Direct Interpretability
The greatest advantage of MAE is that **it is expressed in the exact same physical units as the target variable**.
- If you are predicting house prices in dollars, MAE is in dollars.
- If you are predicting temperature in Celsius, MAE is in degrees Celsius.
- In our project, because the target is `exam_score`, **MAE is expressed in exam points**.

### Educational Interpretation: What Does 4.3 Points Mean?
In `main.py`, line 51 prints:
`Mean absolute error: 4.3 points`
And `outputs/metrics.txt` records:
`mean absolute error: 4.3208`

What does this tell an academic counselor or student?
**"On unseen students, our model's predictions are, on average, within approximately 4.3 points of their true exam scores."**

Considering that exam scores span from 35 to 92 points (a 57-point range), an average miss of only 4.3 points represents high accuracy! For instance, if a student is predicted to score 67.5, their actual score will typically land between $63.2$ and $71.8$—close enough to reliably determine whether the student is on track to pass.

## Relevant Code (from main.py, lines 19, 39, 43, 51)
```python
from sklearn.metrics import mean_absolute_error, r2_score

# ...
predictions = model.predict(X_test)
# ...
mae = mean_absolute_error(y_test, predictions)

print(f"Mean absolute error: {mae:.1f} points")
```

### Code explanation
- `mean_absolute_error(y_test, predictions)` accepts the ground-truth array first (`y_test`), followed by the model's predictions (`predictions`).
- The console prints `mae` formatted to 1 decimal place (`4.3 points`).

## Worked Example

**Problem:** Suppose an alternative model tested on 4 students produces the following results:
- Actual: `[70, 80, 60, 90]`
- Predicted: `[72, 77, 65, 86]`
Calculate the MAE by hand and verify in Python.
**Solution:**
1. Absolute errors:
   - $|70 - 72| = 2$
   - $|80 - 77| = 3$
   - $|60 - 65| = 5$
   - $|90 - 86| = 4$
2. Sum of absolute errors:
   $$2 + 3 + 5 + 4 = 14$$
3. Average error:
   $$\text{MAE} = \frac{14}{4} = 3.5\text{ points}$$
On average, this alternative model misses by 3.5 points.

## Step-by-Step Student Instructions
1. Open terminal and run python3:
   ```bash
   python3
   ```
2. Train model and compute MAE:
   ```python
   import pandas as pd
   from sklearn.model_selection import train_test_split
   from sklearn.linear_model import LinearRegression
   from sklearn.metrics import mean_absolute_error

   df = pd.read_csv("beginner-projects-main/AI-ML Beginners/projects/06_exam_score/data/exam_scores.csv")
   X = df[["hours_studied"]]
   y = df["exam_score"]
   X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)

   model = LinearRegression()
   model.fit(X_train, y_train)
   preds = model.predict(X_test)
   mae = mean_absolute_error(y_test, preds)

   print(f"Raw MAE: {mae}")
   print(f"Formatted 1-decimal: {mae:.1f} points")
   print(f"Formatted 4-decimals: {mae:.4f}")
   ```
3. Confirm that the formatted outputs display `4.3 points` and `4.3208`.

## Expected Output or Observable Behaviour
```text
Raw MAE: 4.320811265689356
Formatted 1-decimal: 4.3 points
Formatted 4-decimals: 4.3208
```
The MAE computation matches `main.py` console output and `metrics.txt` exactly.

## Practical Exercises
**Exercise 1.1:** Why can't MAE ever be a negative number?
**Exercise 1.2:** If a perfect model made predictions that exactly matched all actual test scores, what would its MAE be?
**Exercise 1.3:** What is the difference between MAE and Mean Squared Error (MSE)? Why is MAE easier to explain to school principals and students?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Computing MAE on training data | Evaluating on training data yields optimistic bias (~4.1 points) | Always compute evaluation metrics on holdout test data (`y_test, predictions`) |
| Inverting argument order: `(predictions, y_test)` | While MAE is symmetric, scikit-learn standard convention is `(y_true, y_pred)` | Adhere to convention: `mean_absolute_error(y_test, predictions)` |
| Reporting MAE without units | Stating "MAE is 4.3" lacks context | Always attach units: "4.3 exam points" |

## Best Practices and Security Considerations
- **Intuitive Metrics for Stakeholders**: Use MAE when communicating with non-technical stakeholders because its linear scale aligns directly with human intuition.
- **Robustness to Extreme Outliers**: Unlike squared metrics, MAE does not disproportionately inflate due to a single unusual outlier.
- **Contextual Benchmarking**: Always compare MAE against the target variable's standard deviation or range to assess whether the error is small or large relative to the problem scale.

## Summary
Mean Absolute Error (MAE) measures the average absolute difference between predicted and actual exam scores. Evaluated strictly on the 7 holdout test observations, our model achieves an MAE of approximately 4.32 points (reported as 4.3 points), demonstrating that predictions are reliably within a narrow margin of true student performance.

## Knowledge-check Questions
1. What mathematical formula defines Mean Absolute Error?
2. What physical units does MAE have in this project?
3. What is the value of MAE printed to the console by `main.py`?
4. What is the high-precision MAE value recorded in `outputs/metrics.txt`?
5. Why is MAE preferred over MSE when explaining model performance to non-statisticians?

## References
- scikit-learn MAE documentation: https://scikit-learn.org/stable/modules/generated/sklearn.metrics.mean_absolute_error.html
- Understanding Regression Metrics: https://towardsdatascience.com/regression-metrics-explained-mae-mse-rmse-r2-and-adjusted-r2-2e6f423408a2
