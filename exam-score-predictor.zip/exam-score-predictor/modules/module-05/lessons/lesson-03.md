# Lesson 03: Matplotlib Scatter Plots: Distinguishing Training and Testing Sets

**Lesson ID:** lesson-03
**Module:** module-05
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Construct object-oriented figures and axes using `plt.subplots(figsize=(7, 5))`
- Plot distinct scatter series for training data and testing data
- Differentiate data splits visually using distinct colors, sizes, and marker shapes
- Understand why separating training and test markers provides visual transparency
- Configure axis labels, titles, grids, and legends

## Prerequisites
- Completion of Lessons 01 and 02
- Understanding of Cartesian coordinate plotting in Python

## Concept Explanation

### The Power of Data Visualization
In machine learning, looking at tables of numbers and statistical metrics (like MAE = 4.3, $R^2 = 0.85$) provides rigorous mathematical verification. However, humans are visual learners. A clear, well-composed graphic allows students, educators, and researchers to verify at a glance:
- The overall trajectory and slope of the data
- How tightly points cluster around the trend
- The dispersion and fairness of the train/test split
- How well the fitted model fits both seen and unseen students

### Object-Oriented Matplotlib in main.py
In `main.py`, line 58 initializes the graphic canvas:
```python
fig, ax = plt.subplots(figsize=(7, 5))
```
Why use `plt.subplots()` instead of `plt.scatter()` directly?
- **Stateful (Procedural) Style (`plt.plot`)**: Relies on implicit global state; can cause bugs when multiple figures are open.
- **Object-Oriented Style (`fig, ax`)**: Explicitly creates a `Figure` container object (`fig`) and an `Axes` coordinate space object (`ax`). This is the professional standard for Python data science, giving total control over styling, sizing, and multi-layer rendering.
- `figsize=(7, 5)`: Specifies a width of 7 inches and height of 5 inches, providing an aesthetically pleasing 1.4:1 aspect ratio.

### Visual Encoding: Training vs. Testing Data
In `main.py`, lines 59-60 render the empirical data:
```python
ax.scatter(X_train, y_train, color="#2471a3", s=55, label="training data")
ax.scatter(X_test, y_test, color="#e67e22", s=65, marker="s", label="test data")
```

Notice the thoughtful design decisions:
1. **Training Data**:
   - Color: Steel Blue (`#2471a3`), a calming, neutral tone.
   - Marker: Default circular dots (`"o"`).
   - Size: `s=55`.
   - Represents the 21 historical examples used to fit the line.
2. **Testing Data**:
   - Color: Bright Orange (`#e67e22`), creating immediate, high-contrast visual pop against blue.
   - Marker: Square (`marker="s"`).
   - Size: `s=65` (slightly larger for enhanced visibility).
   - Represents the 7 holdout validation students.

```
       Exam Score
          ▲
      100 │                                    ● (train: blue circle)
          │                             ■ (test: orange square)
       80 │                      ●
          │               ■
       60 │        ●
          │  ■
       40 │
          └────────────────────────────────────────► Hours Studied
```

By encoding training and testing samples with different colors and shapes, the visualization proves transparency: anyone looking at the plot can verify that test points are distributed evenly across the full range of study hours and were not cherry-picked.

## Relevant Code (from main.py, lines 58-60, 63-67)
```python
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.scatter(X_train, y_train, color="#2471a3", s=55, label="training data")
    ax.scatter(X_test, y_test, color="#e67e22", s=65, marker="s", label="test data")
    # ... [line and prediction plotting] ...
    ax.set_xlabel("Hours studied")
    ax.set_ylabel("Exam score")
    ax.set_title("Study hours vs. exam score")
    ax.legend()
    ax.grid(alpha=0.25)
```

### Code explanation
- `ax.scatter` renders the two distinct data partitions.
- `ax.set_xlabel` and `ax.set_ylabel` clearly communicate physical units to the viewer.
- `ax.legend()` automatically collects all `label=` tags into an explanatory legend box.
- `ax.grid(alpha=0.25)` adds faint, unobtrusive gridlines to assist visual coordinate estimation.

## Worked Example

**Problem:** Suppose you want to test whether test points have a higher average score than training points in `main.py`. How can you verify this using pandas?
**Solution:**
```python
import pandas as pd
from sklearn.model_selection import train_test_split

df = pd.read_csv("beginner-projects-main/AI-ML Beginners/projects/06_exam_score/data/exam_scores.csv")
X = df[["hours_studied"]]
y = df["exam_score"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)

print(f"Training mean score: {y_train.mean():.2f}")
print(f"Testing mean score:  {y_test.mean():.2f}")
```
Output:
```text
Training mean score: 64.63
Testing mean score:  66.53
```
Both sets have virtually identical mean scores (~64.6 vs ~66.5), proving that the split is well-balanced.

## Step-by-Step Student Instructions
1. Open terminal and run python3:
   ```bash
   python3
   ```
2. Build and inspect the scatter plot elements:
   ```python
   import matplotlib
   matplotlib.use("Agg")
   import matplotlib.pyplot as plt
   import pandas as pd
   from sklearn.model_selection import train_test_split

   df = pd.read_csv("beginner-projects-main/AI-ML Beginners/projects/06_exam_score/data/exam_scores.csv")
   X = df[["hours_studied"]]
   y = df["exam_score"]
   X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)

   fig, ax = plt.subplots(figsize=(7, 5))
   ax.scatter(X_train, y_train, color="#2471a3", s=55, label="training data")
   ax.scatter(X_test, y_test, color="#e67e22", s=65, marker="s", label="test data")
   ax.set_xlabel("Hours studied")
   ax.set_ylabel("Exam score")
   ax.legend()
   ax.grid(alpha=0.25)
   fig.savefig("test_scatter.png", dpi=100)
   plt.close(fig)
   print("Scatter plot generated successfully.")
   ```
3. Inspect `test_scatter.png` to confirm two distinct marker groups.

## Expected Output or Observable Behaviour
```text
Scatter plot generated successfully.
```
The saved image file contains blue circles for training points and orange squares for test points.

## Practical Exercises
**Exercise 3.1:** What happens if you omit `ax.legend()`? Will the label text passed to `ax.scatter` still be visible on the plot?
**Exercise 3.2:** What does the parameter `alpha=0.25` in `ax.grid(alpha=0.25)` control? Why is faint grid transparency better than solid black lines?
**Exercise 3.3:** How many total data points appear on the scatter plot? (Count training + testing points).

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Forgetting labels in `scatter()` | `ax.legend()` displays an empty box or raises a warning | Always provide `label="training data"` and `label="test data"` |
| Using identical markers for train and test | Viewer cannot tell which points were held out for validation | Use distinct colors and shapes (`marker="s"`) |
| Cluttered grids | Default full-opacity black gridlines distract from data points | Soften grids with `alpha=0.25` or `linestyle="--"` |

## Best Practices and Security Considerations
- **Colorblind-Friendly Palettes**: Using blue circles and orange squares ensures clear accessibility for individuals with red-green color vision deficiency.
- **Explicit Labeling**: Every chart must feature clear axis titles with units of measurement to avoid misinterpretation.
- **Consistent Visual Hierarchy**: Main data trends should be prominent; gridlines and borders should remain understated.

## Summary
Visualizing data is essential for model transparency. By utilizing object-oriented matplotlib methods (`plt.subplots`), `main.py` renders training samples as steel-blue circles and testing samples as orange squares, providing a clear, accessible depiction of data distribution and validation partitioning.

## Knowledge-check Questions
1. What figure dimensions (in inches) are specified in `plt.subplots(figsize=(7, 5))`?
2. What color and marker shape represent the training data in `main.py`?
3. What color and marker shape represent the test data in `main.py`?
4. What matplotlib method adds gridlines with custom transparency?
5. What is the role of `ax.legend()`?

## References
- matplotlib.axes.Axes.scatter reference: https://matplotlib.org/stable/api/_as_gen/matplotlib.axes.Axes.scatter.html
- matplotlib marker styles guide: https://matplotlib.org/stable/api/markers_api.html
