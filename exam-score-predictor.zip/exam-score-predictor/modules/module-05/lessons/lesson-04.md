# Lesson 04: Plotting the Best Fit Line, 6-Hour Prediction Marker, and Figure Export

**Lesson ID:** lesson-04
**Module:** module-05
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Generate smooth, continuous coordinate sequences using `np.linspace()`
- Plot the fitted regression line across the full data range using `ax.plot()`
- Highlight the benchmark 6-hour prediction using an overlaid star marker (`marker="*"`, `zorder=5`)
- Format layout boundaries cleanly with `fig.tight_layout()` and export at 150 DPI with `bbox_inches="tight"`
- Manage system memory properly by calling `plt.close(fig)`

## Prerequisites
- Completion of Lessons 01, 02, and 03
- Understanding of 2D line plotting and model inference

## Concept Explanation

### Drawing the Continuous Line of Best Fit
To plot a straight line across our scatter plot, we need a sequence of coordinate pairs $(x, y)$. 
In `main.py`, lines 55-56 and 61 generate and draw this line:
```python
line_x = np.linspace(df["hours_studied"].min(), df["hours_studied"].max(), 100)
line_y = model.predict(pd.DataFrame({"hours_studied": line_x}))
ax.plot(line_x, line_y, color="#c0392b", linewidth=2.5, label="line of best fit")
```

Let's dissect each step:
1. `np.linspace(min, max, 100)`: Generates 100 evenly spaced numbers starting at the dataset minimum ($1.5$ hours) and ending at the maximum ($9.9$ hours).
2. `pd.DataFrame({"hours_studied": line_x})`: Wraps the 100 coordinates into a 2D DataFrame with the correct column name.
3. `model.predict(...)`: Vectorially evaluates the linear model on all 100 points simultaneously, yielding 100 corresponding score predictions (`line_y`).
4. `ax.plot(...)`: Connects the 100 points into a smooth, continuous solid line:
   - Color: Strong crimson red (`#c0392b`), standing out prominently against the blue and orange scatter points.
   - `linewidth=2.5`: Bold stroke thickness ensuring the line anchors the visual composition.
   - `label="line of best fit"`: Registers the line in the plot legend.

### Highlighting the 6-Hour Scenario: The Prediction Star
In `main.py`, line 62 highlights our benchmark inference query:
```python
ax.scatter([6], [six_hours], color="#111111", marker="*", s=220, zorder=5, label="6-hour prediction")
```
Why are these specific styling parameters used?
- `[6]` and `[six_hours]`: Coordinate lists for the single point $(6.0, 67.51)$.
- `marker="*"`: A five-point star icon, universally recognized as a point of special significance.
- `color="#111111"`: Deep black, ensuring it does not clash with the blue, orange, or red elements.
- `s=220`: Extra-large marker size ($4\times$ larger than standard data points), making it immediately noticeable.
- `zorder=5`: **Layering control**. In matplotlib, elements with higher `zorder` values are drawn on top of elements with lower `zorder` values (default is 2). Setting `zorder=5` guarantees that the star sits on top of the red regression line rather than being cut in half by it.

```
       Exam Score
          ▲                                    / (Red line of best fit)
       80 │                             /
          │                      /
       70 │               ★ (6.0 hrs -> 67.5 pts: Black Star, zorder=5)
          │        /
       50 │ /
          └────────────────────────────────────────► Hours Studied
```

### Clean Export and Memory Management
Lines 68-70 conclude the visualization pipeline:
```python
fig.tight_layout()
fig.savefig(OUT / "exam_score_regression.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```
1. `fig.tight_layout()`: Automatically adjusts subplot padding so that axis labels, tick marks, and titles fit neatly without overlapping or being cut off by the canvas edge.
2. `dpi=150`: Sets output resolution to 150 Dots Per Inch, producing a crisp, publication-quality image (over $1000 \times 750$ pixels) suitable for slides, reports, or printed handouts.
3. `bbox_inches="tight"`: Crops away any remaining extraneous white margin around the figure border.
4. `plt.close(fig)`: **Critical memory cleanup step**. In Python, matplotlib figures remain resident in memory even after being written to disk. In long-running processes, web applications, or test runners, omitting `plt.close()` causes progressive memory leaks. Explicitly closing the figure frees system RAM immediately.

## Relevant Code (from main.py, lines 55-70)
```python
    line_x = np.linspace(df["hours_studied"].min(), df["hours_studied"].max(), 100)
    line_y = model.predict(pd.DataFrame({"hours_studied": line_x}))

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.scatter(X_train, y_train, color="#2471a3", s=55, label="training data")
    ax.scatter(X_test, y_test, color="#e67e22", s=65, marker="s", label="test data")
    ax.plot(line_x, line_y, color="#c0392b", linewidth=2.5, label="line of best fit")
    ax.scatter([6], [six_hours], color="#111111", marker="*", s=220, zorder=5, label="6-hour prediction")
    ax.set_xlabel("Hours studied")
    ax.set_ylabel("Exam score")
    ax.set_title("Study hours vs. exam score")
    ax.legend()
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(OUT / "exam_score_regression.png", dpi=150, bbox_inches="tight")
    plt.close(fig)
```

### Code explanation
- The entire visual artifact is constructed layer by layer: background grid $\rightarrow$ training scatter $\rightarrow$ testing scatter $\rightarrow$ regression line $\rightarrow$ prediction star $\rightarrow$ annotations.
- The resulting graphic tells the complete machine learning story in a single image.

## Worked Example

**Problem:** What happens if `line_x` is created with only 2 points instead of 100 points: `line_x = np.array([1.5, 9.9])`? Does it change the visual appearance of the regression line?
**Solution:**
Because simple linear regression is a strictly straight line ($y = mx + b$), connecting 2 points ($x_{\min}$ and $x_{\max}$) produces the exact same straight line as connecting 100 points!
However, using `np.linspace(..., 100)` is standard professional practice because it generalizes seamlessly to non-linear models (such as polynomial regression or curves) where 100 points are necessary to draw a smooth curve.

## Step-by-Step Student Instructions
1. Navigate to the project directory:
   ```bash
   cd "beginner-projects-main/AI-ML Beginners/projects/06_exam_score"
   ```
2. Run `main.py`:
   ```bash
   python main.py
   ```
3. Verify that the output image was created:
   ```bash
   ls -la outputs/exam_score_regression.png
   ```
4. Verify the file format and size using the `file` command:
   ```bash
   file outputs/exam_score_regression.png
   ```
5. Confirm that the output reports valid PNG image data (typically ~40-60 KB).

## Expected Output or Observable Behaviour
```text
outputs/exam_score_regression.png: PNG image data, 1024 x 724, 8-bit/color RGBA, non-interlaced
```
The graphic file is generated with high resolution and correct dimensions.

## Practical Exercises
**Exercise 4.1:** Why is `zorder=5` necessary when plotting the star marker? What would happen if `zorder` were omitted and the star had default zorder 2 while the line had zorder 3?
**Exercise 4.2:** What does the parameter `dpi=150` do in `fig.savefig()`? How does increasing DPI to 300 affect file size and image sharpness?
**Exercise 4.3:** Why is calling `plt.close(fig)` considered essential software engineering practice in Python visualization pipelines?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Forgetting `plt.close(fig)` | Causes memory leaks and emits `More than 20 figures have been opened` warnings | Always call `plt.close(fig)` immediately after saving |
| Star marker hidden behind the line | Default plotting order draws later elements behind or at equal level with lines | Set `zorder=5` on the marker to force it to the top visual layer |
| Truncated labels in saved image | Plot labels extending outside figure boundaries are clipped | Use `fig.tight_layout()` and `bbox_inches="tight"` in `savefig` |

## Best Practices and Security Considerations
- **Visual Storytelling**: Every chart should contain four essential elements: raw data, modeled pattern, key scenario highlight, and clear explanatory legend.
- **Resource Cleanup**: Always close figures in automated pipelines to prevent memory leaks in production containers.
- **High-DPI Export**: Avoid fuzzy, pixelated images by setting at least 150 DPI for reports and 300 DPI for print publications.

## Summary
The final visualization in `main.py` brings together training points, test points, the continuous red regression line, and a prominent 6-hour prediction star marker. With headless rendering, 150 DPI export, tight layout boundaries, and proper memory cleanup, the resulting `exam_score_regression.png` serves as a complete, publication-ready visual report.

## Knowledge-check Questions
1. What numpy function generates 100 evenly spaced coordinates along the study hours range?
2. What color and thickness are used to draw the line of best fit in `main.py`?
3. What marker style and size are used for the 6-hour prediction marker?
4. What parameter forces the prediction star to be drawn on top of the regression line?
5. Why must `plt.close(fig)` be called after saving the graphic?

## References
- matplotlib savefig documentation: https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.savefig.html
- Understanding Matplotlib Z-order: https://matplotlib.org/stable/gallery/misc/zorder_demo.html
- numpy linspace reference: https://numpy.org/doc/stable/reference/generated/numpy.linspace.html
