# Module 5 Exercises: Model Evaluation & Visualization

## Exercise 5.1: Calculating MAE and R² from Scratch (15 min)
**Objective:** Calculate Mean Absolute Error and R-squared manually using Python arrays to understand their underlying formulas.

**Problem Statement:**
Given the 7 holdout test predictions from our model, calculate MAE and R² using basic Python/NumPy arithmetic and verify that your manual calculations match scikit-learn's metric functions.

**Requirements:**
1. Define test ground-truth array `y_true = np.array([69.5, 54.1, 61.3, 74.0, 92.1, 50.5, 69.2])`.
2. Define model predictions `y_pred = np.array([64.34, 58.01, 61.17, 69.62, 85.97, 48.51, 60.65])`.
3. Compute MAE manually: `np.mean(np.abs(y_true - y_pred))`.
4. Compute R² manually:
   - Compute mean of `y_true`: `y_mean = np.mean(y_true)`
   - Compute Total Sum of Squares: `tss = np.sum((y_true - y_mean) ** 2)`
   - Compute Residual Sum of Squares: `rss = np.sum((y_true - y_pred) ** 2)`
   - Compute $R^2$: `1.0 - (rss / tss)`
5. Verify your manual results against `mean_absolute_error` and `r2_score` from `sklearn.metrics`.

**Constraints:** Use NumPy and verify with scikit-learn.

**Expected Behaviour:** Manual MAE $\approx 4.32$ and $R^2 \approx 0.85$, matching scikit-learn.

**Acceptance Criteria:**
- [ ] Manual MAE calculation verified against `mean_absolute_error`
- [ ] Manual TSS, RSS, and $R^2$ verified against `r2_score`
- [ ] Understanding of formulas demonstrated in written code

**Hints:**
- $\text{MAE} = \frac{1}{n} \sum |y - \hat{y}|$; $R^2 = 1 - \frac{\text{RSS}}{\text{TSS}}$.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 5.2: Multi-Layer Scatter and Line Plotting (15 min)
**Objective:** Replicate the complete matplotlib figure generation pipeline from `main.py`.

**Problem Statement:**
Write a Python script that trains the regression model, generates the line coordinates with `np.linspace`, and renders all four visual layers into a single high-resolution plot.

**Requirements:**
1. Configure `matplotlib.use("Agg")` before importing `pyplot`.
2. Train `LinearRegression` on `X_train, y_train`.
3. Generate 100 points for `line_x` between minimum and maximum hours, and predict `line_y`.
4. Create figure with `fig, ax = plt.subplots(figsize=(7, 5))`.
5. Plot:
   - Training scatter (blue `#2471a3`, circle, size 55)
   - Test scatter (orange `#e67e22`, square, size 65)
   - Regression line (red `#c0392b`, width 2.5)
   - 6-hour prediction (black `#111111`, star, size 220, zorder 5)
6. Add labels, title, legend, grid, tight layout, and save to `my_regression.png` at 150 DPI.
7. Call `plt.close(fig)`.

**Constraints:** Pure Python script matching `main.py` plotting style.

**Expected Behaviour:** Clean script execution generating a verified PNG image.

**Acceptance Criteria:**
- [ ] All four visual elements present on the plot
- [ ] Legend has 4 labeled entries
- [ ] Z-order correctly layers the star on top of the line
- [ ] `plt.close(fig)` called at conclusion

**Hints:**
- Follow `main.py` lines 55-70.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes

---

## Exercise 5.3: Visualizing Model Residuals (15 min)
**Objective:** Create a residual error plot showing vertical distances from actual points to the regression line.

**Problem Statement:**
To visualize where the model over-predicts and under-predicts, create a plot showing vertical lines (residual segments) connecting each test point to the fitted line.

**Requirements:**
1. Train the model and compute predictions on `X_test`.
2. Create a figure with `fig, ax = plt.subplots(figsize=(7, 5))`.
3. Plot the regression line and test scatter points.
4. Loop through each test student $(x_i, y_i, \hat{y}_i)$ and use `ax.vlines(x=x_i, ymin=min(y_i, y_hat_i), ymax=max(y_i, y_hat_i), color="gray", linestyle="--")`.
5. Add labels and save the plot as `residual_plot.png`.

**Constraints:** Use `ax.vlines` or `ax.plot` for residual lines.

**Expected Behaviour:** A plot clearly illustrating the vertical error distances for all 7 test students.

**Acceptance Criteria:**
- [ ] Vertical dotted lines connect each test point to the regression line
- [ ] Positive and negative residuals are visually distinguishable
- [ ] Plot saved and closed cleanly

**Hints:**
- `ax.vlines` draws vertical line segments between two y-coordinates.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 5.4: Automated Report Metric Formatter (15 min)
**Objective:** Write a script that parses model outputs and generates an executive summary report.

**Problem Statement:**
Create a Python script that reads `outputs/metrics.txt` and generates a formatted Markdown report summarizing model performance for an academic dean.

**Requirements:**
1. Open and parse `outputs/metrics.txt` extracting equation, MAE, R², and 6-hour prediction.
2. Calculate the percentage accuracy: $100 \times (1 - \frac{\text{MAE}}{\text{mean score}})$.
3. Generate a Markdown string containing:
   - Executive Summary
   - Model Equation and Parameters
   - Accuracy Evaluation Table
   - Advising Recommendation for 6-hour revision schedule
4. Write the string to `outputs/executive_report.md`.

**Constraints:** Read directly from `outputs/metrics.txt`.

**Expected Behaviour:** Cleanly written markdown file summarizing model metrics.

**Acceptance Criteria:**
- [ ] File `metrics.txt` parsed successfully
- [ ] Executive report written to disk
- [ ] Formatting is clean and professional

**Hints:**
- Use string `.split(":")` to parse key-value lines in `metrics.txt`.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes
