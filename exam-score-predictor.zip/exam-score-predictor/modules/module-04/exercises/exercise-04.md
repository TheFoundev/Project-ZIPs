# Module 4 Exercises: Model Training, Parameter Extraction & Inference

## Exercise 4.1: Estimator Fitting & Attribute Inspection (15 min)
**Objective:** Instantiate, fit, and inspect a scikit-learn `LinearRegression` estimator.

**Problem Statement:**
Write a Python script that loads `data/exam_scores.csv`, performs a 75/25 train/test split with `random_state=42`, and fits a `LinearRegression` model. Inspect the model before and after fitting to verify that the trailing-underscore attributes are created dynamically.

**Requirements:**
1. Instantiate `model = LinearRegression()`.
2. Check `hasattr(model, "coef_")` and `hasattr(model, "intercept_")` before fitting and print the boolean results.
3. Fit the model using `X_train` and `y_train`.
4. Check `hasattr` again after fitting and print the boolean results.
5. Print the type, shape, and value of `model.coef_` and `model.intercept_`.

**Constraints:** Use Python 3 and scikit-learn.

**Expected Behaviour:** Terminal output showing `False` before fitting and `True` after fitting, followed by shape `(1,)` and value `~5.28`.

**Acceptance Criteria:**
- [ ] `hasattr` checks verified before and after fitting
- [ ] `model.fit(X_train, y_train)` called correctly
- [ ] `model.coef_` confirmed as NumPy array of shape `(1,)`
- [ ] `model.intercept_` confirmed as scalar float

**Hints:**
- Attributes ending with `_` are only created during `.fit()`.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes

---

## Exercise 4.2: Constructing Query DataFrames & Inference (15 min)
**Objective:** Perform single-sample and batch inference using properly formatted DataFrames.

**Problem Statement:**
In `main.py`, line 45 queries the model for a 6.0-hour study session. You need to replicate this prediction and expand it to evaluate a table of potential study revision plans.

**Requirements:**
1. Replicate the benchmark query: predict for 6.0 hours using `pd.DataFrame({"hours_studied": [6.0]})`.
2. Format the prediction to 1 decimal place and confirm it yields `67.5 points`.
3. Construct a batch query DataFrame containing 5 different revision schedules: `[2.0, 4.0, 6.0, 8.0, 10.0]`.
4. Call `model.predict()` on the batch DataFrame and print a formatted summary table.
5. Verify that each 2-hour increase in the table produces exactly a $10.55 - 10.56$ point gain.

**Constraints:** Query inputs must be pandas DataFrames with column name `"hours_studied"`.

**Expected Behaviour:** Accurate predictions matching: 2h (~46.4), 4h (~57.0), 6h (~67.5), 8h (~78.1), 10h (~88.6).

**Acceptance Criteria:**
- [ ] 6.0-hour prediction verified as $67.5\text{ points}$
- [ ] Batch DataFrame constructed with correct column name
- [ ] Vectorized prediction runs without warnings
- [ ] Output table printed clearly with study hours and predicted scores

**Hints:**
- Column name must match `"hours_studied"` exactly.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes

---

## Exercise 4.3: Mathematical Verification of Predictions (15 min)
**Objective:** Prove identity between algorithmic predictions and manual equation calculations across 10 random points.

**Problem Statement:**
Prove that `LinearRegression.predict()` is not an uninterpretable black box by verifying that it produces identical outputs to manual algebra.

**Requirements:**
1. Train the model on `X_train, y_train`.
2. Generate 10 random study hour values between 1.5 and 9.9 using `np.random.uniform(1.5, 9.9, 10)`.
3. Compute predictions using `model.predict(pd.DataFrame({"hours_studied": random_hours}))`.
4. Compute manual predictions using `model.coef_[0] * random_hours + model.intercept_`.
5. Compute the absolute difference between algorithmic and manual predictions.
6. Assert that all differences are smaller than $10^{-10}$ using `np.allclose()`.

**Constraints:** Use NumPy and scikit-learn.

**Expected Behaviour:** The assertion passes silently or prints confirmation of mathematical identity.

**Acceptance Criteria:**
- [ ] Random points generated within observed data range ($1.5$ to $9.9$)
- [ ] Algorithmic predictions match manual formula calculations
- [ ] `np.allclose()` confirms tolerance within floating-point precision ($< 10^{-10}$)

**Hints:**
- Use `np.allclose(algo_preds, manual_preds)`.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 4.4: Bounded Prediction Pipeline (Extrapolation Guard) (15 min)
**Objective:** Design a production inference function that defends against unrealistic extrapolation.

**Problem Statement:**
Because linear models continue indefinitely without ceiling or floor boundaries, an advisor needs an inference wrapper function that warns when an input is outside observed data and clamps scores between 0 and 100.

**Requirements:**
1. Define a function `predict_exam_score_guarded(hours: float, model: LinearRegression) -> dict`.
2. In the function:
   - Check if `hours < 1.5` or `hours > 9.9`. If so, set a warning flag: `"extrapolation_warning": True`.
   - Compute the raw prediction using `model.predict()`.
   - Compute a bounded score clamped between 0.0 and 100.0: `max(0.0, min(100.0, raw_score))`.
   - Return a dictionary with: `input_hours`, `raw_prediction`, `bounded_prediction`, and `extrapolation_warning`.
3. Test your function with three inputs: $6.0\text{ hours}$ (normal), $0.5\text{ hours}$ (low extrapolation), and $16.0\text{ hours}$ (high extrapolation with clamp).

**Constraints:** Clean, typed Python function with proper dictionary return structure.

**Expected Behaviour:** 6.0h returns bounded=67.5, warning=False; 16.0h returns raw=120.3, bounded=100.0, warning=True.

**Acceptance Criteria:**
- [ ] Function signature and return dictionary match requirements
- [ ] Safe interpolation recognized without warning (6.0h)
- [ ] Extrapolation warning triggered for inputs outside $[1.5, 9.9]$
- [ ] Scores above 100 correctly clamped to 100.0

**Hints:**
- Python's `min(100.0, val)` caps values at 100.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes
