# Lesson 02: Extracting Parameters and Formatting the Model String

**Lesson ID:** lesson-02
**Module:** module-04
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Access and inspect `model.coef_` and `model.intercept_` attributes
- Convert NumPy array elements and scalars into standard Python `float` primitives
- Construct professional, human-readable model equation strings using Python f-strings
- Distinguish between display formatting (2 decimal places) and persistence formatting (4 decimal places)
- Understand the scikit-learn naming convention of trailing underscores (`_`)

## Prerequisites
- Completion of Lesson 01
- Familiarity with Python string formatting and f-strings

## Concept Explanation

### The Trailing Underscore Convention in scikit-learn
In scikit-learn, any attribute that is **estimated from the training data** during `.fit()` ends with an underscore (`_`).
Examples:
- `model.coef_`: The learned coefficients/slopes
- `model.intercept_`: The learned intercept/bias
- `model.n_features_in_`: The number of features seen during fitting (1)
- `model.feature_names_in_`: The names of features seen during fitting (`['hours_studied']`)

In contrast, hyperparameters set by the user (like `fit_intercept=True` or `copy_X=True`) do not have trailing underscores. This convention allows developers to distinguish between user configuration and learned intelligence at a glance.

### Extracting and Casting Parameters in main.py
In `main.py`, lines 41-42 extract the model parameters:
```python
slope = float(model.coef_[0])
intercept = float(model.intercept_)
```

Why do we wrap both with `float(...)`?
1. **Type Cleanliness**: `model.coef_` is a NumPy array: `array([5.27660351])`. Accessing `model.coef_[0]` returns a `numpy.float64` object. While Python f-strings handle `numpy.float64`, converting it to a native Python `float` ensures compatibility with JSON serializers, text formatters, and downstream standard library functions.
2. **Defensive Extraction**: `float(model.coef_[0])` explicitly extracts the scalar value from the array, preventing accidental multi-element array serialization errors.

### Formatting the Model String
In `main.py`, line 50 displays the model equation to the user:
```python
print(f"Model: score = {slope:.2f} x hours + {intercept:.2f}")
```
Let's analyze the format specifiers:
- `{slope:.2f}`: Formats `5.27660351...` to exactly two decimal places $\rightarrow$ `5.28`
- `{intercept:.2f}`: Formats `35.84656386...` to exactly two decimal places $\rightarrow$ `35.85`
- Resulting string: `"Model: score = 5.28 x hours + 35.85"`

### Display Formatting vs. Storage Formatting
Notice an important professional software pattern in `main.py`:
- In **Console Display** (lines 50-53): Values are rounded to 1 or 2 decimal places (`5.28`, `4.3 points`, `0.85`, `67.5 points`) because human eyes prefer clean, easily digestible numbers.
- In **File Persistence** (`metrics.txt`, lines 73-76): Values are saved with 4 decimal places:
  ```text
  equation: score = 5.2766 * hours + 35.8466
  mean absolute error: 4.3208
  r2: 0.8486
  prediction at 6 hours: 67.51
  ```
Higher precision in stored artifacts prevents cumulative rounding errors when downstream systems or automated grading scripts parse the file.

## Relevant Code (from main.py, lines 41-42, 50, 72-76)
```python
    slope = float(model.coef_[0])
    intercept = float(model.intercept_)

    print(f"Model: score = {slope:.2f} x hours + {intercept:.2f}")

    with open(OUT / "metrics.txt", "w", encoding="utf-8") as handle:
        handle.write(f"equation: score = {slope:.4f} * hours + {intercept:.4f}\n")
        handle.write(f"mean absolute error: {mae:.4f}\n")
        handle.write(f"r2: {r2:.4f}\n")
        handle.write(f"prediction at 6 hours: {six_hours:.2f}\n")
```

### Code explanation
- Python's `float()` cast standardizes numerical types.
- The terminal receives concise 2-decimal summaries.
- The metrics file receives high-precision 4-decimal records using standard multiplication syntax (`*`).

## Worked Example

**Problem:** Suppose a model learns `slope = 5.27660351` and `intercept = 35.84656386`. Write the code to format these into:
1. A LaTeX equation string for academic papers: `\text{score} = 5.28 h + 35.85`
2. A SQL query string: `SELECT 5.2766 * hours_studied + 35.8466 AS predicted_score FROM students`
**Solution:**
```python
slope = 5.27660351
intercept = 35.84656386

latex_str = f"\\text{{score}} = {slope:.2f} h + {intercept:.2f}"
sql_str = f"SELECT {slope:.4f} * hours_studied + {intercept:.4f} AS predicted_score FROM students"

print("LaTeX:", latex_str)
print("SQL:", sql_str)
```

## Step-by-Step Student Instructions
1. Open terminal and run python3:
   ```bash
   python3
   ```
2. Train the model and extract parameters:
   ```python
   import pandas as pd
   from sklearn.model_selection import train_test_split
   from sklearn.linear_model import LinearRegression

   df = pd.read_csv("beginner-projects-main/AI-ML Beginners/projects/06_exam_score/data/exam_scores.csv")
   X = df[["hours_studied"]]
   y = df["exam_score"]
   X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)

   model = LinearRegression()
   model.fit(X_train, y_train)

   slope = float(model.coef_[0])
   intercept = float(model.intercept_)
   ```
3. Test formatting with different precision levels:
   ```python
   print(f"2 decimals: score = {slope:.2f} x hours + {intercept:.2f}")
   print(f"4 decimals: score = {slope:.4f} * hours + {intercept:.4f}")
   ```
4. Verify that the 2-decimal version matches line 50 of `main.py` and the 4-decimal version matches line 73 of `metrics.txt`.

## Expected Output or Observable Behaviour
```text
2 decimals: score = 5.28 x hours + 35.85
4 decimals: score = 5.2766 * hours + 35.8466
```
The formatted strings match both console and disk outputs from `main.py`.

## Practical Exercises
**Exercise 2.1:** What is the difference between `model.coef_` and `model.coef` in scikit-learn? What error occurs if you omit the trailing underscore?
**Exercise 2.2:** What does the format specifier `:.1f` do when applied to the 6-hour prediction `67.5061849`?
**Exercise 2.3:** Why is UTF-8 encoding (`encoding="utf-8"`) explicitly specified when opening `metrics.txt` for writing?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Omitting trailing underscore: `model.coef` | Python raises `AttributeError: 'LinearRegression' object has no attribute 'coef'` | Always include the trailing underscore: `model.coef_` |
| Attempting `model.intercept_[0]` | `model.intercept_` is a scalar float; indexing with `[0]` raises `IndexError: invalid index to scalar variable` | Access directly as `float(model.intercept_)` |
| Using string concatenation instead of f-strings | Writing `"score = " + str(round(slope, 2)) + ...` is verbose and error-prone | Use f-strings: `f"score = {slope:.2f} x hours + {intercept:.2f}"` |

## Best Practices and Security Considerations
- **Auditing Trailing Underscores**: Inspecting trailing underscore attributes is the official way to audit model weights before deploying an AI model into production.
- **Explicit Type Casting**: Converting NumPy scalar data types to native Python floats before saving to JSON or external APIs avoids non-serializable type errors.
- **Standardized Precision**: Maintain consistent rounding conventions across documentation, user interfaces, and automated reports.

## Summary
Extracting model parameters in scikit-learn utilizes the trailing underscore convention (`coef_` and `intercept_`). By casting these parameters to Python floats and formatting them into descriptive strings with controlled decimal precision, `main.py` produces both human-readable console summaries and high-precision persistent records.

## Knowledge-check Questions
1. What do trailing underscores on scikit-learn attributes indicate?
2. What Python type does `model.coef_[0]` return before casting with `float()`?
3. What format specifier formats a float to two decimal places?
4. What is the formatted equation string displayed on the console?
5. Why does `outputs/metrics.txt` record the equation with 4 decimal places instead of 2?

## References
- scikit-learn naming conventions: https://scikit-learn.org/stable/glossary.html#term-attributes
- Python f-string format specifications: https://docs.python.org/3/reference/lexical_analysis.html#formatted-string-literals
