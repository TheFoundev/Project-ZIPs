# Lesson 03: Inference: Constructing Input DataFrames and Predicting for 6 Hours

**Lesson ID:** lesson-03
**Module:** module-04
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Formulate the inference query structure required by scikit-learn's `.predict()` method
- Construct a single-sample query DataFrame using `pd.DataFrame({"hours_studied": [6.0]})`
- Explain why column names in query DataFrames must match training feature names exactly
- Extract and interpret the predicted exam score for 6 hours of study ($\approx 67.5\text{ points}$)
- Compare single-sample inference with batch inference on test sets

## Prerequisites
- Completion of Lessons 01 and 02
- Understanding of 2D feature inputs

## Concept Explanation

### What is Inference?
In machine learning, **inference** (or prediction) is the operational phase where a trained model is supplied with new, unseen feature values and computes estimated target outcomes:

$$\hat{y}_{\text{new}} = \text{model.predict}(X_{\text{new}})$$

While evaluation tests the model on historical test sets, inference uses the model to answer forward-looking questions for real human beings.

### The Benchmark Query: 6 Hours of Study
In `main.py`, line 45 answers the central question of the project:
```python
six_hours = float(model.predict(pd.DataFrame({"hours_studied": [6.0]}))[0])
```
Why is the query constructed this way?
Let's break down each element:
1. `{"hours_studied": [6.0]}`: A Python dictionary where the key matches the training feature name (`"hours_studied"`) and the value is a list containing the single query number `[6.0]`.
2. `pd.DataFrame(...)`: Converts the dictionary into a 2D DataFrame of shape `(1, 1)`.
3. `model.predict(...)`: Executes matrix multiplication:
   $$\hat{y} = 5.27660351 \times 6.0 + 35.84656386 = 67.50618493$$
   It returns a 1D NumPy array: `array([67.50618493])`.
4. `[0]`: Extracts the single scalar element from the array: `67.50618493`.
5. `float(...)`: Casts to a standard Python float.
6. When printed with `f"{six_hours:.1f} points"`, the console displays:
   **`Prediction for 6 hours: 67.5 points`**

### Why Query DataFrames Must Match Training Columns
scikit-learn tracks the feature names seen during `.fit()`.
If you trained the model using a DataFrame with column name `"hours_studied"`, scikit-learn expects incoming inference DataFrames to have the exact same column name:
- If you pass `pd.DataFrame({"study_hours": [6.0]})`, scikit-learn emits a `UserWarning` or `ValueError` stating:
  `The feature names should match those that were passed during fit. Feature names unseen at fit time: - study_hours`
- If you pass an unadorned list like `model.predict([[6.0]])`, scikit-learn accepts the 2D shape but warns that feature names are missing.

Using `pd.DataFrame({"hours_studied": [6.0]})` is the gold standard of defensive data science: it guarantees that column names, data types, and 2D dimensions are 100% compliant.

### Batch Inference vs. Single-Sample Inference
Notice how `main.py` uses `.predict()` in two different modes:
- **Batch Inference** (line 39): `model.predict(X_test)` takes a 7-row DataFrame and returns a 7-element array of predictions for evaluation.
- **Single-Sample Inference** (line 45): `model.predict(pd.DataFrame({"hours_studied": [6.0]}))` takes a 1-row DataFrame and returns a 1-element array for scenario planning.

The underlying estimator handles both identically because both inputs are 2D DataFrames!

## Relevant Code (from main.py, lines 45, 53)
```python
    six_hours = float(model.predict(pd.DataFrame({"hours_studied": [6.0]}))[0])

    print(f"Prediction for 6 hours: {six_hours:.1f} points")
```

### Code explanation
- Line 45 packages the single input 6.0 into a DataFrame and extracts the prediction.
- Line 53 prints the formatted prediction with 1 decimal place (`67.5 points`).

## Worked Example

**Problem:** How would you query the model to predict exam scores for three students at once: one studying 2.5 hours, one studying 5.0 hours, and one studying 7.5 hours?
**Solution:**
Create a multi-row DataFrame:
```python
query_batch = pd.DataFrame({"hours_studied": [2.5, 5.0, 7.5]})
batch_predictions = model.predict(query_batch)
for hours, score in zip([2.5, 5.0, 7.5], batch_predictions):
    print(f"{hours} hours -> {score:.1f} points")
```
Output:
```text
2.5 hours -> 49.0 points
5.0 hours -> 62.2 points
7.5 hours -> 75.4 points
```
The model predicts all three scenarios simultaneously in a vectorized operation.

## Step-by-Step Student Instructions
1. Open terminal and run python3:
   ```bash
   python3
   ```
2. Train the model:
   ```python
   import pandas as pd
   from sklearn.model_selection import train_test_split
   from sklearn.linear_model import LinearRegression

   df = pd.read_csv("beginner-projects-main/AI-ML Beginners/projects/06_exam_score/data/exam_scores.csv")
   X = df[["hours_studied"]]
   y = df["exam_score"]
   X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)
   model = LinearRegression()
   model.fit(X_train, y_train)
   ```
3. Create the 6-hour query DataFrame and predict:
   ```python
   query_df = pd.DataFrame({"hours_studied": [6.0]})
   pred_raw = model.predict(query_df)
   print("Raw prediction array:", pred_raw)
   print("Extracted float:", float(pred_raw[0]))
   print(f"Formatted: {pred_raw[0]:.1f} points")
   ```
4. Verify that the output prints `67.5 points`.

## Expected Output or Observable Behaviour
```text
Raw prediction array: [67.50618493]
Extracted float: 67.50618493019911
Formatted: 67.5 points
```
The output confirms the internal float value ($67.5061...$) and the rounded console display ($67.5$).

## Practical Exercises
**Exercise 3.1:** What happens if you pass `model.predict(6.0)` with a raw scalar number? What error does scikit-learn return?
**Exercise 3.2:** What is the predicted score for a student who studies 8.0 hours?
**Exercise 3.3:** Why is predicting for 6.0 hours considered an example of *interpolation* rather than *extrapolation*?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Passing a scalar: `model.predict(6.0)` | Raises `ValueError: Expected 2D array, got scalar instead` | Wrap in a 2D structure: `pd.DataFrame({"hours_studied": [6.0]})` |
| Misspelling the feature name in query DataFrame | Raises a warning or error about mismatched feature names | Use the exact training column name: `"hours_studied"` |
| Forgetting `[0]` on the prediction array | Attempts to format an array with float formatters: `f"{array:.1f}"` raises `TypeError` | Extract the scalar first: `pred[0]` |

## Best Practices and Security Considerations
- **Feature Name Alignment**: Always use pandas DataFrames with explicit column names when performing inference to maintain self-documenting, safe code.
- **Input Validation**: In web APIs, sanitize and validate that user input study hours are positive numbers within sensible physiological bounds (e.g., $0 \le \text{hours} \le 24$).
- **Vectorized Inference**: Use batch DataFrames rather than looping through individual values with `for` loops to maximize computational speed.

## Summary
Inference is the process of generating predictions for new feature values using a fitted model. By passing a 2D DataFrame with matching feature names (`pd.DataFrame({"hours_studied": [6.0]})`), `main.py` adheres to scikit-learn best practices and predicts an exam score of 67.5 points for a 6-hour revision schedule.

## Knowledge-check Questions
1. What data structure does `main.py` construct to query the model for 6 hours of study?
2. What shape does `pd.DataFrame({"hours_studied": [6.0]})` have?
3. What is the predicted exam score for 6 hours of study (to 1 decimal place)?
4. Why does passing an unadorned list `[[6.0]]` emit a warning in modern scikit-learn?
5. What index is used to extract the single prediction from the returned NumPy array?

## References
- scikit-learn predict method reference: https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html#sklearn.linear_model.LinearRegression.predict
- pandas DataFrame creation from dictionaries: https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.html
