# Lesson 04: Algorithmic Prediction vs. Formulaic Calculation & Extrapolation

**Lesson ID:** lesson-04
**Module:** module-04
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Verify that `model.predict()` produces the exact same numerical result as the algebraic formula: $\text{slope} \times x + \text{intercept}$
- Formulate the critical distinction between **interpolation** and **extrapolation**
- Identify domain danger zones when extrapolating linear models beyond observed ranges
- Explain how non-linear realities (fatigue, 100-point test ceilings) constrain linear predictions

## Prerequisites
- Completion of Lessons 01, 02, and 03
- Understanding of the linear equation $\text{score} = 5.28 \times \text{hours} + 35.85$

## Concept Explanation

### Algorithmic Prediction vs. Formulaic Verification
In machine learning, black-box complex models (like deep neural networks or gradient-boosted trees) make predictions through intricate nested calculations that cannot easily be checked by hand.

Simple linear regression, however, is **100% transparent**.
When you call:
```python
six_hours = float(model.predict(pd.DataFrame({"hours_studied": [6.0]}))[0])
```
scikit-learn is not performing magic. It is simply executing:
$$\hat{y} = \text{slope} \times 6.0 + \text{intercept}$$

Let's verify this mathematically using full floating-point precision:
- $\text{slope} = 5.276603510821103$
- $\text{intercept} = 35.8465638652725$
- $\text{Calculation} = 5.276603510821103 \times 6.0 + 35.8465638652725 = 67.50618493019911$

When we query `model.predict(...)`, it outputs `67.50618493019911`. The agreement is exact to 15 decimal places!
Performing this check builds immense confidence: it proves that the scikit-learn estimator is executing the exact mathematical model we derived.

### Interpolation vs. Extrapolation
A fundamental duty of every data scientist is knowing when a prediction can be trusted and when it is speculative.

```
                  OBSERVED DATA RANGE (1.5 to 9.9 hours)
       ◄─────────────────────────────────────────────────────────────►
  0 hrs           1.5 hrs                    6.0 hrs           9.9 hrs         15.0 hrs
 ───┼────────────────┼──────────────────────────┼─────────────────┼───────────────┼───►
 Extrapolation               INTERPOLATION                  Extrapolation
(Floor risk)              (High Confidence)                (Ceiling violation)
```

1. **Interpolation (Safe & High Confidence)**:
   - Making predictions **inside** the range of observed training data.
   - In our dataset, study hours range from **1.5 hours to 9.9 hours**.
   - Our benchmark prediction of **6.0 hours** is right in the heart of this range ($1.5 \le 6.0 \le 9.9$).
   - Because we have dozens of real student observations surrounding 6.0 hours (e.g. 5.4, 6.2, 6.4, 7.6), we have high empirical confidence in this prediction.

2. **Extrapolation (Risky & Speculative)**:
   - Making predictions **outside** the observed data range ($x < 1.5$ or $x > 9.9$).
   - A straight line continues infinitely in both directions, but real-world phenomena do not!

### The Two Major Extrapolation Hazards in Exam Scoring

#### Hazard 1: The Upper Ceiling Effect ($x > 10\text{ hours}$)
What does our model predict if an ambitious student studies 15 hours?
$$\hat{y} = 5.28 \times 15.0 + 35.85 = 79.20 + 35.85 = \mathbf{115.05\text{ points}}$$
On an exam scored from 0 to 100, a score of 115 is physically impossible!
Why does this happen?
In real education, learning exhibits **diminishing marginal returns**: as you approach 100, each additional point requires vastly more effort. Furthermore, studying 15 or 20 hours consecutively introduces severe cognitive fatigue and sleep deprivation, which actually *reduces* test performance.

#### Hazard 2: The Lower Floor Effect ($x < 1.5\text{ hours}$)
What if a student studies for 0 hours?
The model predicts the intercept: **$35.85\text{ points}$**.
While this is plausible if an exam has multiple-choice guessing, what if the exam is an advanced oral defense in quantum physics? A student with 0 study time might score 0 points. The linear model cannot know this because it has never seen a student with 0 hours.

## Relevant Code (from main.py, lines 45, 50, 53)
```python
    slope = float(model.coef_[0])
    intercept = float(model.intercept_)
    # ...
    six_hours = float(model.predict(pd.DataFrame({"hours_studied": [6.0]}))[0])

    print(f"Model: score = {slope:.2f} x hours + {intercept:.2f}")
    # ...
    print(f"Prediction for 6 hours: {six_hours:.1f} points")
```

### Code explanation
- The output displays both the governing formula and the benchmark prediction, allowing students to verify equivalence manually.

## Worked Example

**Problem:** Verify that the manual equation calculation matches `six_hours` in Python. Then write a function `predict_score_safe(hours)` that clamps predictions to the realistic exam range $[0, 100]$.
**Solution:**
```python
slope = 5.276603510821103
intercept = 35.8465638652725

# Verification
manual_pred = slope * 6.0 + intercept
print(f"Manual: {manual_pred:.4f}")

# Safe bounded prediction function
def predict_score_safe(hours: float) -> float:
    raw_pred = slope * hours + intercept
    return max(0.0, min(100.0, raw_pred))

print("Safe prediction for 6 hrs:", predict_score_safe(6.0))
print("Safe prediction for 15 hrs (clamped):", predict_score_safe(15.0))
```
Output:
```text
Manual: 67.5062
Safe prediction for 6 hrs: 67.50618493019911
Safe prediction for 15 hrs (clamped): 100.0
```

## Step-by-Step Student Instructions
1. Open terminal and run python3:
   ```bash
   python3
   ```
2. Train model and perform the equivalence test:
   ```python
   import pandas as pd
   from sklearn.model_selection import train_test_split
   from sklearn.linear_model import LinearRegression

   df = pd.read_csv("beginner-projects-main/AI-ML Beginners/projects/06_exam_score/data/exam_scores.csv")
   X = df[["hours_studied"]]
   y = df["exam_score"]
   X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)
   model = LinearRegression()
   model.fit(X_train, y_train)

   algo_pred = model.predict(pd.DataFrame({"hours_studied": [6.0]}))[0]
   manual_pred = model.coef_[0] * 6.0 + model.intercept_
   diff = abs(algo_pred - manual_pred)
   print("Difference:", diff)
   ```
3. Confirm that the difference is smaller than $10^{-14}$ (zero).

## Expected Output or Observable Behaviour
```text
Difference: 0.0
```
Machine precision confirms exact identity between model prediction and algebraic formula.

## Practical Exercises
**Exercise 4.1:** Why is predicting for 6 hours considered safe interpolation while predicting for 14 hours is risky extrapolation?
**Exercise 4.2:** At what study duration does the unconstrained linear model project a score of exactly 100 points?
**Exercise 4.3:** How might a data scientist modify the regression algorithm to model diminishing returns near 100 points? (Hint: Polynomial features or logistic curves).

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Trusting linear models for extreme inputs | Linear models will cheerfully predict 250 points or negative points if extreme inputs are passed | Enforce domain boundary checks ($0 \le \hat{y} \le 100$) in post-processing |
| Assuming `model.predict()` does complex deep learning | Simple linear regression executes $mx + b$ | Understand that OLS is a direct linear calculation |
| Treating interpolation and extrapolation with equal confidence | Extrapolation assumes linear trends continue outside observed evidence | Add cautionary disclaimers when reporting predictions outside observed ranges |

## Best Practices and Security Considerations
- **Boundary Clamping**: When deploying predictive tools in consumer-facing education apps, always clamp predictions between minimum and maximum allowable scores ($0$ and $100$).
- **Explainability**: Take advantage of linear regression's transparency to show students the exact formula used to calculate their estimate.
- **Uncertainty Communication**: Provide confidence intervals or error margins ($\pm 4.3$ points) rather than presenting a single point estimate as an absolute truth.

## Summary
Algorithmic prediction with `LinearRegression.predict()` is mathematically identical to evaluating $m \cdot x + b$. While predicting for 6.0 hours represents reliable interpolation within observed bounds ($1.5 \le 6.0 \le 9.9$), data scientists must remain vigilant against the perils of extrapolation, where unconstrained linear models violate physical boundaries like 100-point test ceilings.

## Knowledge-check Questions
1. How does the numerical result of `model.predict()` compare to manually calculating $\text{slope} \times \text{hours} + \text{intercept}$?
2. What is the difference between interpolation and extrapolation?
3. What is the range of study hours observed in `exam_scores.csv`?
4. Why does an unconstrained linear regression model predict impossible scores (>100) for large study inputs?
5. How can developers protect users from impossible extrapolation outputs in production code?

## References
- The Dangers of Extrapolation in Regression: https://statisticsbyjim.com/regression/extrapolation-regression/
- scikit-learn Linear Regression: https://scikit-learn.org/stable/modules/linear_model.html
