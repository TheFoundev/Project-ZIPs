# Lesson 01: Fitting the Model with `model.fit(X_train, y_train)`

**Lesson ID:** lesson-01
**Module:** module-04
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain the role of the estimator instantiation step: `model = LinearRegression()`
- Execute the training process via `model.fit(X_train, y_train)`
- Explain what happens internally inside scikit-learn during `.fit()`
- Recognize that fitting must occur strictly on training data to prevent data leakage
- Identify estimator state before and after calling `.fit()`

## Prerequisites
- Module 02 (Train/test splitting)
- Module 03 (Ordinary Least Squares mathematical principles)

## Concept Explanation

### The scikit-learn Estimator Lifecycle
scikit-learn adopts an elegant, object-oriented design pattern known as the **Estimator API**. 
The lifecycle of any supervised model follows three distinct phases:

```
┌────────────────────────────────────────────────────────┐
│ 1. Instantiation: model = LinearRegression()           │
│    - Configures hyperparameters (e.g. fit_intercept)   │
│    - Model has no learned knowledge yet               │
├────────────────────────────────────────────────────────┤
│ 2. Fitting (Training): model.fit(X_train, y_train)     │
│    - Evaluates the OLS Normal Equation on data         │
│    - Computes and stores coef_ and intercept_          │
├────────────────────────────────────────────────────────┤
│ 3. Inference (Predicting): model.predict(X_test)       │
│    - Uses learned parameters to forecast new values    │
└────────────────────────────────────────────────────────┘
```

### Instantiation in main.py
In `main.py`, line 37 creates the model instance:
```python
model = LinearRegression()
```
At this line, the model is an un-fitted template. It does not know anything about student scores or study hours. If you attempt to access `model.coef_` or `model.predict()` at this stage, Python raises an `AttributeError` or `NotFittedError`.

### Fitting on Training Data: Line 38
In `main.py`, line 38 trains the model:
```python
model.fit(X_train, y_train)
```
During `.fit()`:
1. scikit-learn inspects `X_train` (shape `(21, 1)`) and `y_train` (shape `(21,)`).
2. It validates that both inputs have matching sample counts (21 rows).
3. It validates that `X_train` is 2-dimensional.
4. It sets up the linear algebraic normal equation:
   $$\mathbf{w} = (\mathbf{X}^T \mathbf{X})^{-1} \mathbf{X}^T \mathbf{y}$$
5. It solves for the optimal parameters using LAPACK matrix routines.
6. It attaches the learned values to the model instance as `model.coef_` and `model.intercept_`.

### Why Only X_train and y_train?
Notice that `main.py` passes `X_train` and `y_train`, **never** `X` and `y`, and **never** `X_test` and `y_test`.
- If you pass all data `X, y`, the model memorizes test points, destroying the validity of your evaluation metrics.
- Fitting on training data mirrors the real world: an AI system in a school can only learn from students who have already graduated and completed their exams, not future students currently studying!

## Relevant Code (from main.py, lines 37-38)
```python
    model = LinearRegression()
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
```

### Code explanation
- Line 37 creates the estimator.
- Line 38 fits the estimator exclusively on the 21 training records.
- Line 39 immediately uses the fitted model to generate predictions on the 7 holdout test records.

## Worked Example

**Problem:** What happens if a student attempts to call `model.predict(X_test)` before calling `model.fit()`?
**Solution:**
In Python, run:
```python
from sklearn.linear_model import LinearRegression
import pandas as pd

model = LinearRegression()
try:
    model.predict(pd.DataFrame({"hours_studied": [6.0]}))
except Exception as e:
    print("Caught error:", type(e).__name__, "-", e)
```
Output:
```text
Caught error: NotFittedError - This LinearRegression instance is not fitted yet. Call 'fit' with appropriate arguments before using this estimator.
```
scikit-learn prevents unauthorized inference by raising `NotFittedError`. Fitting is mandatory before prediction can occur.

## Step-by-Step Student Instructions
1. Open terminal and run python3:
   ```bash
   python3
   ```
2. Run data preparation and instantiation:
   ```python
   import pandas as pd
   from sklearn.model_selection import train_test_split
   from sklearn.linear_model import LinearRegression

   df = pd.read_csv("beginner-projects-main/AI-ML Beginners/projects/06_exam_score/data/exam_scores.csv")
   X = df[["hours_studied"]]
   y = df["exam_score"]
   X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)

   model = LinearRegression()
   print("Has coef_ before fit?", hasattr(model, "coef_"))
   ```
3. Fit the model:
   ```python
   model.fit(X_train, y_train)
   print("Has coef_ after fit?", hasattr(model, "coef_"))
   ```
4. Verify that `hasattr(model, "coef_")` changes from `False` to `True`.

## Expected Output or Observable Behaviour
```text
Has coef_ before fit? False
Has coef_ after fit? True
```
The state change proves that fitting populates the learned attributes dynamically.

## Practical Exercises
**Exercise 1.1:** What is the difference between an estimator's parameters (learned during `fit`) and hyperparameters (specified during instantiation)?
**Exercise 1.2:** If you add 5 new student rows to `exam_scores.csv`, do you need to call `model.fit()` again? Explain why.
**Exercise 1.3:** What happens if `X_train` contains 21 rows but `y_train` contains 20 rows? What error is thrown?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Fitting on the whole dataset: `model.fit(X, y)` | Causes data leakage and invalidates test metrics | Always fit strictly on `X_train, y_train` |
| Calling `fit()` twice with different data | Overwrites previously learned parameters | Fit once on the intended training split |
| Passing targets as features: `model.fit(y_train, X_train)` | Reverses the model, predicting study hours from exam scores | Always pass features first, targets second: `model.fit(X_train, y_train)` |

## Best Practices and Security Considerations
- **Consistent API Usage**: All scikit-learn supervised algorithms share the exact same `fit()` and `predict()` syntax, making it easy to swap models later.
- **Strict Data Pipeline Hygiene**: Keep training data strictly isolated from evaluation routines.
- **Check Fitted State**: In production web services, verify `check_is_fitted(model)` before processing user inference requests.

## Summary
Fitting is the core learning step where `LinearRegression` applies Ordinary Least Squares to the training data. By calling `model.fit(X_train, y_train)` exclusively on the 21 training samples, the model calculates optimal parameters without contaminating test evaluation.

## Knowledge-check Questions
1. What scikit-learn method executes model training?
2. What error is raised if `predict()` is called on an un-fitted model?
3. Why shouldn't `model.fit()` be called on the full dataset `X, y`?
4. What happens internally when `model.fit()` is called on a `LinearRegression` instance?
5. How does `hasattr(model, "coef_")` change before and after `fit()`?

## References
- scikit-learn Estimator API conventions: https://scikit-learn.org/stable/developers/develop.html#apis-of-scikit-learn-objects
- scikit-learn LinearRegression fit method: https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html#sklearn.linear_model.LinearRegression.fit
