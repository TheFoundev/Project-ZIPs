# Lesson 01: The Exam Score Prediction Problem & Educational Analytics

**Lesson ID:** lesson-01
**Module:** module-01
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- State the educational and business problem that the Exam Score Predictor solves
- Explain how predictive analytics is applied in modern educational institutions
- Define supervised learning using student study data
- Identify the feature (`hours_studied`) and target (`exam_score`) used throughout the project
- Recognize the benchmark query (predicting exam score for 6 hours of study)

## Prerequisites
- Basic familiarity with school grading scales (0-100 points)
- Curiosity about how data can assist academic decision-making

## Concept Explanation

### The Educational Problem
Every semester, students ask themselves a fundamental question: **"How many hours do I need to study to achieve my target exam score?"** 

Simultaneously, teachers, academic counselors, and university administrators want to identify students at risk of underperforming before finals take place. If an advisor knows that a student has only dedicated 2 hours to revision for a demanding subject, predicting their probable score enables proactive tutoring or study interventions.

The **Predict Your Exam Score** project solves this challenge by analyzing empirical records from 28 students who tracked their study hours and recorded their final examination scores. By applying machine learning, we uncover the mathematical trend connecting preparation time with test outcomes.

### What Makes This "Supervised Learning"?
In machine learning, algorithms learn in different ways depending on the data provided:
- **Supervised Learning**: The algorithm is provided with *labeled training examples*. Each training record consists of both the input characteristics (known as **features**) and the true historical outcome (known as the **label** or **target**). The algorithm's job is to learn a mapping function from input to output.
- **Unsupervised Learning**: The algorithm receives only raw input features without any target labels and must discover latent groupings or clustering patterns on its own.

In this project, our dataset `exam_scores.csv` contains 28 rows with two columns: `hours_studied` and `exam_score`. Because we already know both how long each student studied and the actual score they achieved, this is a quintessential supervised learning problem.

### Identifying Features and Targets
- **Feature ($X$)**: The independent input variable used to make predictions. In our codebase, $X$ is `hours_studied`. It is what we measure or control.
- **Target ($y$)**: The dependent output variable that we seek to forecast. In our codebase, $y$ is `exam_score` (ranging from 0 to 100).

### The Benchmark Prediction Scenario: 6 Hours
In `main.py`, our pipeline concludes by answering a specific, practical query: **"What score would a student achieve if they study for exactly 6 hours?"**
Six hours represents a realistic, moderate preparation schedule for a college exam. By generating a prediction for 6.0 hours (~67.5 points), the project demonstrates how an abstract trained model is deployed to deliver actionable advice to a real student.

## Relevant Code (from main.py, lines 1-8, 45)
```python
\"\"\"Project 06: Predict Your Exam Score (linear regression).

Run:
    python main.py

A tiny study-hours dataset, a line of best fit, and a prediction for six
hours of study.
\"\"\"

# Benchmark prediction query in main.py:
six_hours = float(model.predict(pd.DataFrame({"hours_studied": [6.0]}))[0])
```

### Code explanation
- The module docstring summarizes the three key pillars: a dataset relating study hours to exam scores, fitting a line of best fit, and predicting the score for a 6-hour revision schedule.
- The prediction query creates a single-record query structured as a DataFrame with column `"hours_studied"` containing `[6.0]`. The trained model processes this input and outputs an estimated numeric score.

## Worked Example

**Problem:** Suppose an advisor wants to know why we treat `hours_studied` as the feature and `exam_score` as the target rather than the reverse.
**Solution:**
1. Consider causality and workflow: Students study *before* the exam occurs. Study time is the cause or investment, while the exam score is the downstream effect or outcome.
2. In deployment, a student tells the advisor their study plan (e.g., 6 hours), and the system estimates their score. We do not observe the future exam score to guess how many hours they studied in the past!
3. Therefore:
   - Feature ($X$): `hours_studied` (known before exam)
   - Target ($y$): `exam_score` (predicted outcome)

## Step-by-Step Student Instructions
1. Open terminal and navigate to `beginner-projects-main/AI-ML Beginners/projects/06_exam_score`.
2. Inspect `main.py` using a text editor or terminal pager (`cat main.py` or `less main.py`).
3. Locate lines 1 to 8: read the project docstring and note the stated objective.
4. Locate line 29: observe where `pd.read_csv(DATA / "exam_scores.csv")` loads the student dataset.
5. Locate line 45: find where the model predicts the score for 6.0 hours of study.
6. Reflect: What advice would you give a student who aims for a score of 80 based on this setup?

## Expected Output or Observable Behaviour
When executing `python main.py`, the console outputs:
```text
============================================================
PREDICT YOUR EXAM SCORE
============================================================
Model: score = 5.28 x hours + 35.85
Mean absolute error: 4.3 points
R-squared: 0.85
Prediction for 6 hours: 67.5 points
```
The model clearly states that a student who invests 6 hours of study is predicted to earn approximately 67.5 points.

## Practical Exercises
**Exercise 1.1:** Why is predicting exam scores from study hours considered supervised learning?
**Exercise 1.2:** If a school collected student test scores without recording how many hours each student studied, could this regression model be trained? Explain why or why not.
**Exercise 1.3:** Identify one external factor outside of study hours (e.g., sleep, prior GPA) that could also influence exam scores in a real-world analytics system.

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Confusing feature with target | Predicting hours studied from exam score is backwards for pre-exam planning | Treat `hours_studied` as $X$ and `exam_score` as $y$ |
| Assuming unsupervised learning | Unsupervised models do not use labeled target outputs | Recognize that `exam_score` acts as the ground-truth supervising label |
| Believing 6 hours is arbitrary with no code link | Line 45 explicitly hardcodes `[6.0]` in the prediction DataFrame | Trace the 6-hour query directly to `main.py` line 45 |

## Best Practices and Security Considerations
- **Ethical Academic Analytics**: Predictive models in education should guide supportive coaching and resource allocation, never punish students or set low expectations.
- **Data Privacy**: Academic records (FERPA in the United States, GDPR in Europe) are legally protected personal data. Datasets should be anonymized and stripped of student names and ID numbers.
- **Safe Local Execution**: The project performs all computations locally and does not transmit student data across external networks.

## Summary
The Exam Score Predictor tackles an essential challenge in academic analytics: forecasting continuous exam scores based on study preparation time. By utilizing supervised learning on historical student records, the model learns the relationship between study hours and exam performance, enabling inference for a benchmark 6-hour study scenario.

## Knowledge-check Questions
1. What variable represents the independent feature in this project?
2. What variable represents the dependent target outcome?
3. What makes this task a supervised machine learning problem?
4. What study duration does `main.py` use as its benchmark prediction query?
5. According to the project output, approximately what score does a 6-hour study session yield?

## References
- `main.py` docstring (lines 1-8) and prediction query (line 45)
- Educational Data Mining & Learning Analytics Overview: https://en.wikipedia.org/wiki/Educational_data_mining
- scikit-learn Supervised Learning documentation: https://scikit-learn.org/stable/supervised_learning.html
