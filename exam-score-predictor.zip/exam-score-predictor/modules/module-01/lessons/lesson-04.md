# Lesson 04: Project Architecture, Pipeline Workflow, and Benchmark Prediction

**Lesson ID:** lesson-04
**Module:** module-01
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Map out the 8 architectural stages of the Exam Score Predictor pipeline
- Explain the role and inputs/outputs of each component in `main.py`
- Trace the lifecycle of data from raw CSV to fitted model and exported artifacts
- Understand the significance of the 6-hour benchmark prediction scenario

## Prerequisites
- Completion of Lessons 01, 02, and 03
- Familiarity with the overall purpose of machine learning workflows

## Concept Explanation

### The Anatomy of an Applied ML Pipeline
Professional machine learning projects follow a disciplined sequence of steps to ensure code clarity, experimental reproducibility, and reliable outputs. The Exam Score Predictor implements this end-to-end workflow in a single cohesive script (`main.py`).

The pipeline is organized into 8 distinct sequential stages:

```
┌───────────────────────────────────────────────────────────┐
│ 1. Configuration & Headless Backend Setup                 │
│    - Set matplotlib 'Agg' backend before pyplot import    │
│    - Initialize pathlib Path constants (BASE, DATA, OUT)  │
├───────────────────────────────────────────────────────────┤
│ 2. Data Ingestion                                         │
│    - Read 'data/exam_scores.csv' into pandas DataFrame    │
├───────────────────────────────────────────────────────────┤
│ 3. Feature Matrix & Target Vector Formulation             │
│    - X = df[['hours_studied']] (2D DataFrame, shape 28x1) │
│    - y = df['exam_score']      (1D Series, length 28)     │
├───────────────────────────────────────────────────────────┤
│ 4. Train / Test Data Partitioning                         │
│    - Split 75% train (21 rows), 25% test (7 rows)         │
│    - Seed random_state=42 for deterministic results       │
├───────────────────────────────────────────────────────────┤
│ 5. Model Fitting & Optimization                           │
│    - Fit LinearRegression on training data (X_train, y_t) │
│    - Extract learned slope (5.28) and intercept (35.85)   │
├───────────────────────────────────────────────────────────┤
│ 6. Validation & Scenario Inference                        │
│    - Predict on test set -> Calculate MAE (4.3) and R²    │
│    - Predict on benchmark query: 6.0 hours -> 67.5 points │
├───────────────────────────────────────────────────────────┤
│ 7. Explanatory Visualization Generation                   │
│    - Plot training scatter, test scatter, regression line │
│    - Highlight 6-hour prediction with black star marker   │
├───────────────────────────────────────────────────────────┤
│ 8. Artifact Export & Reporting                            │
│    - Save high-res plot: outputs/exam_score_regression.png│
│    - Save parameters: outputs/metrics.txt                 │
└───────────────────────────────────────────────────────────┘
```

### Why the 6-Hour Benchmark Prediction Matters
In applied machine learning, training and evaluating a model is only half the battle. A model creates real value when it is used for **inference**—answering practical questions for end users.

In `main.py`, line 45 creates a query:
```python
six_hours = float(model.predict(pd.DataFrame({"hours_studied": [6.0]}))[0])
```
Why 6.0 hours?
1. **Realistic Middle-Ground**: In the dataset, study hours range from 1.5 to 9.9 hours with a median of 4.75 hours and a mean of 5.39 hours. A 6-hour study session represents an achievable goal for an ambitious student.
2. **Interpolation Test**: 6.0 hours falls comfortably within the observed training range ($1.5 \le 6.0 \le 9.9$). This represents *interpolation* (predicting within known boundaries), where linear regression is most trustworthy.
3. **Actionable Benchmarking**: An estimated score of 67.5 points clearly indicates to a student that 6 hours provides a solid passing grade (typically a C+ or B- in academic scales), showing that pushing to 8 hours would be required to break into the 78+ range.

## Relevant Code (from main.py, lines 22-25, 45, 58-76)
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)

# ... [Data loading, split, fit] ...

six_hours = float(model.predict(pd.DataFrame({"hours_studied": [6.0]}))[0])

# Plotting the prediction marker
ax.scatter([6], [six_hours], color="#111111", marker="*", s=220, zorder=5, label="6-hour prediction")

# Saving outputs
fig.savefig(OUT / "exam_score_regression.png", dpi=150, bbox_inches="tight")
with open(OUT / "metrics.txt", "w", encoding="utf-8") as handle:
    handle.write(f"equation: score = {slope:.4f} * hours + {intercept:.4f}\\n")
    handle.write(f"mean absolute error: {mae:.4f}\\n")
    handle.write(f"r2: {r2:.4f}\\n")
    handle.write(f"prediction at 6 hours: {six_hours:.2f}\\n")
```

### Code explanation
- Path setup uses `pathlib.Path` relative to `__file__`, guaranteeing that output paths resolve correctly regardless of the shell's active directory.
- `OUT.mkdir(exist_ok=True)` safely creates the destination folder if it doesn't already exist.
- The 6-hour prediction is highlighted on the regression line using a prominent star marker (`marker="*"`, `s=220`, `zorder=5`).
- The pipeline persists both a visual PNG artifact and an easily parseable `metrics.txt` record containing 4 decimal places of mathematical precision.

## Worked Example

**Problem:** Trace the shape and type of the data structure holding the 6-hour prediction query across lines 45 and 62.
**Solution:**
1. In line 45: `pd.DataFrame({"hours_studied": [6.0]})` creates a DataFrame with shape `(1, 1)` and columns `['hours_studied']`.
2. `model.predict(...)` takes this `(1, 1)` DataFrame and returns a 1D numpy array `array([67.50618493])` of shape `(1,)`.
3. Indexing with `[0]` extracts the scalar float `67.50618493`.
4. Wrapping with `float(...)` ensures a native Python float is stored in `six_hours`.
5. In line 62: `ax.scatter([6], [six_hours])` receives `[6]` as the x-coordinate list and `[67.50618493]` as the y-coordinate list to place the star marker on the graph.

## Step-by-Step Student Instructions
1. Navigate to the project root in your shell:
   ```bash
   cd "beginner-projects-main/AI-ML Beginners/projects/06_exam_score"
   ```
2. Run `main.py` and inspect the generated directory:
   ```bash
   python main.py
   ls -la outputs/
   ```
3. Read the contents of `outputs/metrics.txt`:
   ```bash
   cat outputs/metrics.txt
   ```
4. Verify that `metrics.txt` contains exactly 4 lines: equation, mean absolute error, r2, and prediction at 6 hours.
5. Confirm that the numbers match the console printout.

## Expected Output or Observable Behaviour
```text
equation: score = 5.2766 * hours + 35.8466
mean absolute error: 4.3208
r2: 0.8486
prediction at 6 hours: 67.51
```
The file `metrics.txt` confirms high-precision calculation matching the rounded console display.

## Practical Exercises
**Exercise 4.1:** What happens if `outputs/` does not exist before running the script? How does `main.py` prevent an error?
**Exercise 4.2:** In line 62, why is `zorder=5` used when plotting the 6-hour prediction marker? (Hint: What happens if a line is drawn across a marker with lower zorder?)
**Exercise 4.3:** How many output files are created when `main.py` finishes running, and what are their file formats?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Hardcoding output paths like `"outputs/plot.png"` | Fails if the user executes the script from outside the project directory | Always use `OUT = BASE / "outputs"` derived from `Path(__file__)` |
| Omitting `exist_ok=True` in `mkdir()` | Crashes with `FileExistsError` on the second run | Always specify `exist_ok=True` when creating directories |
| Forgetting `plt.close(fig)` | Leaves figure objects open in memory, triggering warnings during batch runs | Always call `plt.close(fig)` immediately after `fig.savefig()` |

## Best Practices and Security Considerations
- **Separation of Concerns**: Keep data ingestion, model fitting, metric calculation, and reporting cleanly compartmentalized within functions or pipeline steps.
- **Defensive Directory Creation**: Never assume output folders exist; create them programmatically with error suppression.
- **Resource Cleanup**: Always close matplotlib figures to prevent memory leaks in automated or production environments.

## Summary
The Exam Score Predictor follows an 8-stage architecture typical of production data science pipelines. From headless matplotlib configuration to deterministic train/test splitting, OLS fitting, 6-hour benchmark querying, and persistent artifact generation, each component is engineered for reliability, reproducibility, and clarity.

## Knowledge-check Questions
1. What are the two files generated in the `outputs/` directory?
2. Why is `matplotlib.use("Agg")` called before importing `pyplot`?
3. How does `Path(__file__).resolve().parent` make the pipeline robust to execution from different working directories?
4. What study duration is used for the benchmark prediction scenario?
5. What visual marker style is used on the regression plot to represent the 6-hour prediction?

## References
- Python `pathlib` documentation: https://docs.python.org/3/library/pathlib.html
- Matplotlib headless rendering guide: https://matplotlib.org/stable/users/explain/backends.html
- scikit-learn model evaluation metrics: https://scikit-learn.org/stable/modules/model_evaluation.html
