# Lesson 02: Regression vs. Classification in Academic Scoring

**Lesson ID:** lesson-02
**Module:** module-01
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Formulate the fundamental distinction between regression and classification tasks
- Explain why exam score prediction is modeled as a continuous regression problem
- Contrast continuous point scoring with categorical grading (e.g., Pass/Fail or Letter Grades)
- Identify appropriate machine learning algorithms and evaluation metrics for each problem type

## Prerequisites
- Completion of Lesson 01 (Problem formulation and supervised learning)
- Understanding of continuous numbers versus discrete categories

## Concept Explanation

### The Two Pillars of Supervised Learning
Supervised machine learning is broadly divided into two primary categories depending on the nature of the target variable $y$:

```
                 Supervised Learning
                         │
         ┌───────────────┴───────────────┐
         ▼                               ▼
    Regression                     Classification
(Continuous Numbers)            (Discrete Categories)
- Exam score (e.g. 74.2 pts)   - Pass vs. Fail
- House price ($450,000)       - Grade (A, B, C, D, F)
- Temperature (32.4°C)         - Spam vs. Not Spam
```

### Regression: Continuous Numeric Prediction
In a **regression** problem, the target variable $y$ is a continuous numerical value that can fall anywhere along a continuous scale or interval. 
- In our project, student scores in `exam_scores.csv` include values like `92.1`, `66.4`, `47.5`, and `35.4`.
- Because the score can take any real number (e.g., a student could score 67.5, 67.6, or 68.1), our model must output continuous numbers.
- When you ask "How much?" or "What numerical score?", you need a regression algorithm like `LinearRegression`.

### Classification: Discrete Category Prediction
In a **classification** problem, the target variable $y$ is a discrete class label or categorical bucket.
- If the educational goal was simply to predict whether a student will **Pass** ($\ge 60$) or **Fail** ($< 60$), the target would be binary ($0$ or $1$, or `"Pass"` / `"Fail"`).
- If the goal was to predict a letter grade (`A`, `B`, `C`, `D`, `F`), it would be a multiclass classification task.
- Classification models use decision boundaries to separate classes and output probability distributions over discrete categories (using algorithms like `LogisticRegression` or `DecisionTreeClassifier`).

### Why Regression Is Superior for Exam Scoring
Modeling exam performance as a continuous regression problem preserves critical nuance:
1. **Granularity**: Predicting that a student will earn 59.5 points provides fundamentally different insight than predicting 25.0 points, even though both represent a "Fail" grade in binary classification. A student with 59.5 points needs only a tiny nudge to pass.
2. **Margin of Improvement**: Regression allows an advisor to say: "Every additional hour you study adds approximately 5.28 points to your score." Classification cannot express marginal numerical rates of return directly.
3. **Flexible Post-Processing**: Once you have a continuous score prediction (e.g., 67.5), you can easily map it to any letter grade system or cutoff threshold downstream. The reverse is impossible.

## Relevant Code (from main.py, lines 18, 37-39)
```python
from sklearn.linear_model import LinearRegression

# Instantiate regression model
model = LinearRegression()
model.fit(X_train, y_train)
predictions = model.predict(X_test)
```

### Code explanation
- The import `from sklearn.linear_model import LinearRegression` explicitly selects a regression estimator, not a classifier.
- `model.predict(X_test)` produces an array of continuous floating-point numbers (e.g., `[64.3, 58.0, 61.2, ...]`), which is the signature output of a regression model.

## Worked Example

**Problem:** A school board requests two different models:
1. Model A: Predicts whether an applicant will be Admitted or Rejected.
2. Model B: Predicts the student's final percentage mark on the entrance exam (0.0% to 100.0%).
Classify each task and state which one corresponds to the algorithm used in our Exam Score Predictor.

**Solution:**
- **Model A** is a **Classification** task because the target variable is a discrete category (Binary: Admitted vs. Rejected).
- **Model B** is a **Regression** task because the target variable is a continuous numerical percentage.
- The **Exam Score Predictor** uses the same regression paradigm as Model B, predicting continuous exam points.

## Step-by-Step Student Instructions
1. Open Python in interactive mode or run a quick test script:
   ```bash
   python3
   ```
2. Import pandas and load the exam score data:
   ```python
   import pandas as pd
   df = pd.read_csv("data/exam_scores.csv")
   print(df["exam_score"].dtype)
   print(df["exam_score"].head())
   ```
3. Observe that `df["exam_score"]` has data type `float64`.
4. Verify that the values have decimal fractions (e.g., `92.1`, `66.4`).
5. Confirm that floating-point continuous values necessitate regression rather than classification.

## Expected Output or Observable Behaviour
```text
float64
0    92.1
1    66.4
2    47.5
3    46.2
4    82.4
Name: exam_score, dtype: float64
```
The data type `float64` and continuous decimal values confirm that this is a regression problem.

## Practical Exercises
**Exercise 2.1:** If exam scores were rounded to whole integers (e.g., 66, 47, 82), would this still be considered a regression problem? Explain why.
**Exercise 2.2:** Suppose you convert `exam_score` into a new column `status = df['exam_score'].apply(lambda s: 'High' if s >= 75 else 'Low')`. What type of machine learning problem would predicting `status` be?
**Exercise 2.3:** Name two standard evaluation metrics used for regression problems and explain why accuracy percentage (e.g., 90% correct) is not used for continuous regression.

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Evaluating regression with accuracy score | Continuous predictions will almost never equal continuous targets down to the exact decimal, yielding 0% accuracy | Use distance-based metrics like Mean Absolute Error (MAE) or R-squared ($R^2$) |
| Using `LogisticRegression` for exam score | Logistic regression is a classification algorithm despite having "regression" in its name | Use `LinearRegression` for continuous numeric targets |
| Treating student letter grades as regression | Letter grades (`A`, `B`, `C`) are categorical strings, not continuous quantities | Use classification for letter grades, or predict numeric score first and convert |

## Best Practices and Security Considerations
- **Algorithm Alignment**: Always inspect the data type and distribution of your target variable before selecting an algorithm family.
- **Metric Selection**: Never use classification metrics (`confusion_matrix`, `accuracy_score`, `precision`, `recall`) on continuous regression models.
- **Fairness**: Continuous predictions allow setting equitable and transparent support thresholds rather than arbitrary binary cutoffs.

## Summary
The nature of the target variable dictates the choice of machine learning task. Because exam scores represent continuous numerical performance along a 0-100 scale, our project implements linear regression. Regression gives granular insights into marginal score improvements per study hour that categorical classification cannot provide.

## Knowledge-check Questions
1. What defines a machine learning problem as regression rather than classification?
2. What is the target data type of `df['exam_score']` in our dataset?
3. Why is standard classification accuracy inappropriate for evaluating continuous exam score predictions?
4. If an educational app predicts whether a student passes or fails, which task family is being used?
5. Why is predicting continuous scores more informative for student coaching than binary pass/fail predictions?

## References
- scikit-learn Regression vs Classification overview: https://scikit-learn.org/stable/supervised_learning.html
- Python pandas Series data types: https://pandas.pydata.org/docs/reference/api/pandas.Series.dtype.html
