# Lesson 03: Why Study Hours Predict Performance — The Linear Hypothesis

**Lesson ID:** lesson-03
**Module:** module-01
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain the cognitive and pedagogical rationale for why study hours predict exam scores
- Define the "Linear Hypothesis" in machine learning
- Explain the real-world meaning of positive correlation between variables
- Identify the assumptions and theoretical boundaries of simple linear regression

## Prerequisites
- Completion of Lesson 02 (Regression vs. Classification)
- Intuitive understanding of cause, effect, and scatter relationships

## Concept Explanation

### The Pedagogical Foundation: Time on Task
In educational psychology, the **"Time-on-Task" principle** (originally formalized by John Carroll in the Model of School Learning) posits that academic achievement is directly related to the amount of active, concentrated time a learner spends engaged with learning material.
When students dedicate hours to studying:
1. They consolidate concepts from short-term to long-term memory through spaced repetition.
2. They identify knowledge gaps and misunderstandings through practice problems.
3. They automate problem-solving procedures, reducing cognitive load during the timed exam.

Therefore, we have strong theoretical grounding to hypothesize that preparation time is a reliable predictor of test performance.

### The Linear Hypothesis
In machine learning, before we fit a model, we must make an assumption about the mathematical functional form connecting input $X$ to output $y$. 

The **Linear Hypothesis** states that the relationship between the independent variable ($X$, study hours) and the dependent variable ($y$, exam score) can be reasonably approximated by a straight line:

$$\text{exam\_score} \approx \text{slope} \times \text{hours\_studied} + \text{intercept}$$

This hypothesis assumes:
1. **Monotonicity**: As study hours increase, exam scores generally increase (a positive relationship).
2. **Constant Marginal Returns**: Every additional hour of study produces approximately the same increment in test points across the typical study range.
3. **Linearity**: The rate of score gain does not radically bend or oscillate within the observed range of 1.5 to 9.9 hours.

### Positive Correlation in the Data
When we look at the raw data in `exam_scores.csv`, we observe this positive trend immediately:
- A student studying **1.5 hours** earned **35.4 points**.
- A student studying **4.7 hours** earned **69.2 points**.
- A student studying **9.5 hours** earned **92.1 points**.
- A student studying **9.9 hours** earned **88.6 points**.

While individual variation exists (e.g., student ability, prior knowledge, exam anxiety), the overall direction is unmistakable: more hours correlate with higher scores.

### Real-World Boundaries of the Linear Model
While a straight line fits remarkably well across our dataset ($R^2 \approx 0.85$), every data scientist must understand the boundaries of the linear hypothesis:
- **Floor Effect**: Even if a student studies 0 hours, they might still score some points through basic reasoning or guessing (represented by our model's positive intercept $\approx 35.85$).
- **Ceiling Effect**: An exam is capped at 100 points. A linear model that predicts 5.28 points per hour would theoretically predict $5.28 \times 20 + 35.85 = 141.45$ points for 20 hours of study! In reality, diminishing returns set in near 100 points.
- **Fatigue & Sleep Deprivation**: Studying 30 hours continuously would cause cognitive exhaustion, leading to worse performance. Linear regression does not model exhaustion unless non-linear or polynomial features are introduced.

For the normal study range of 1 to 10 hours, however, the linear model provides an exceptionally accurate and interpretable representation.

## Relevant Code (from main.py, lines 50, 55-56)
```python
# The learned linear relationship printed to console:
print(f"Model: score = {slope:.2f} x hours + {intercept:.2f}")

# Generating points along the straight line across the full data range:
line_x = np.linspace(df["hours_studied"].min(), df["hours_studied"].max(), 100)
line_y = model.predict(pd.DataFrame({"hours_studied": line_x}))
```

### Code explanation
- The model expresses its learned knowledge as a linear formula: `score = slope * hours + intercept`.
- In `main.py`, `np.linspace` generates 100 evenly spaced points from the minimum observed hours (1.5) to the maximum (9.9). Evaluating `model.predict` on these points traces a straight line across the scatter plot, illustrating the linear hypothesis visually.

## Worked Example

**Problem:** Using our model's learned parameters ($\text{slope} = 5.28$, $\text{intercept} = 35.85$), calculate the predicted score for:
1. A student who studies 2 hours.
2. A student who studies 7 hours.
Verify that the difference between the two predictions equals $(7 - 2) \times 5.28$.

**Solution:**
1. For 2 hours:
   $$\text{score}_2 = 5.28 \times 2 + 35.85 = 10.56 + 35.85 = 46.41\text{ points}$$
2. For 7 hours:
   $$\text{score}_7 = 5.28 \times 7 + 35.85 = 36.96 + 35.85 = 72.81\text{ points}$$
3. Difference check:
   $$\text{score}_7 - \text{score}_2 = 72.81 - 46.41 = 26.40\text{ points}$$
   $$(7 - 2) \times 5.28 = 5 \times 5.28 = 26.40\text{ points}$$
The linear hypothesis ensures that every extra hour yields an identical 5.28 point gain regardless of starting point.

## Step-by-Step Student Instructions
1. Open terminal and calculate the Pearson correlation between study hours and exam scores using python:
   ```bash
   python3 -c "import pandas as pd; df = pd.read_csv('beginner-projects-main/AI-ML Beginners/projects/06_exam_score/data/exam_scores.csv'); print('Correlation:', df['hours_studied'].corr(df['exam_score']))"
   ```
2. Observe the correlation value: approximately `0.923`.
3. Note that a correlation near $+1.0$ confirms a strong positive linear relationship.
4. Reflect on how this strong correlation justifies using linear regression as our modeling algorithm.

## Expected Output or Observable Behaviour
```text
Correlation: 0.9234914104276708
```
A correlation coefficient of $+0.923$ represents a very strong positive linear association, confirming the linear hypothesis.

## Practical Exercises
**Exercise 3.1:** What is the difference between positive correlation and negative correlation? Give an example of a variable that would likely have negative correlation with exam score.
**Exercise 3.2:** If a student studies 0 hours, what does the linear model predict? Is this prediction realistic?
**Exercise 3.3:** Why would a linear regression model fail if applied to a student studying 40 hours for a 100-point exam?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Assuming correlation equals strict causation | High correlation does not prove study hours alone caused the score (prior knowledge and motivation also matter) | Treat the model as an empirical estimation tool while acknowledging confounding factors |
| Blind extrapolation past 100 points | A linear model has no built-in ceiling and will predict impossible scores (>100) for huge inputs | Bound predictions within logical real-world limits ($0 \le \text{score} \le 100$) |
| Assuming non-linear complexity is always needed | For simple single-feature relationships with $r > 0.9$, a linear model is often more robust than complex polynomials | Start with simple linear models before adding complexity |

## Best Practices and Security Considerations
- **Occam's Razor in Machine Learning**: Prefer the simplest model that explains the data adequately. Simple linear regression is transparent, interpretable, and resistant to overfitting on small datasets.
- **Recognizing Model Limitations**: Always verify model behavior at boundary extremes (0 hours, 10+ hours) to prevent flawed recommendations.
- **Transparent Communication**: Communicate to students that predicted scores are estimates based on average trends, not guaranteed outcomes.

## Summary
The linear hypothesis assumes that the relationship between study hours and exam scores can be described by a straight line with a constant marginal rate of return. Empirical data strongly validates this assumption, with a correlation of $+0.923$. While real-world ceilings exist at 100 points, simple linear regression provides an accurate, interpretable model across typical study schedules.

## Knowledge-check Questions
1. What does a Pearson correlation of $+0.923$ indicate about study hours and exam scores?
2. What does the "Linear Hypothesis" assume about the rate of score gain per additional hour studied?
3. What is the theoretical score predicted by our linear model for zero study hours?
4. What is a "ceiling effect" in educational testing?
5. Why is simple linear regression preferred over complex deep neural networks for this small dataset?

## References
- Carroll, J. B. (1963). "A Model of School Learning". Teachers College Record.
- Pearson Correlation Coefficient: https://en.wikipedia.org/wiki/Pearson_correlation_coefficient
- scikit-learn Linear Models: https://scikit-learn.org/stable/modules/linear_model.html
