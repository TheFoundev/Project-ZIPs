# Module 1 Exercises: Problem Understanding & Pipeline Architecture

## Exercise 1.1: Problem Formulation & Learning Paradigm (10 min)
**Objective:** Distinguish supervised regression from classification and unsupervised learning in an educational analytics context.

**Problem Statement:** 
A university's academic counseling center wants to predict student performance. They have access to records of historical students that record both how many hours they revised and what grade percentage (0.0 to 100.0) they received on the final exam. You must explain to the counseling board why this is a supervised regression problem rather than classification or unsupervised clustering.

**Requirements:**
1. Define supervised learning and explain why having historical pairs of `(hours_studied, exam_score)` fits this definition.
2. Define regression and explain why predicting continuous numerical points (like 67.5) makes this a regression task.
3. Define classification and describe what kind of target variable would convert this into a classification problem.
4. Explain why unsupervised learning would not be suitable for this prediction goal.

**Constraints:** Base your justification on the data structure and variables in `exam_scores.csv`.

**Expected Behaviour:** A written explanation (1-2 paragraphs) addressing all four requirements with clear, unambiguous terminology.

**Acceptance Criteria:**
- [ ] Supervised learning is correctly defined in terms of labeled input-output pairs
- [ ] Regression is correctly identified based on the continuous numeric nature of `exam_score`
- [ ] Classification is contrasted using a discrete target example (e.g., Pass/Fail or Letter Grade)
- [ ] Unsupervised learning is correctly identified as lacking target labels
- [ ] Connection to the `hours_studied` and `exam_score` columns is explicit

**Hints:**
- Consider whether `67.5` is a category or a point on a continuous number line.
- Remember that labeled data means the correct answers are already known during training.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes

---

## Exercise 1.2: Feature and Target Identification (10 min)
**Objective:** Correctly identify feature ($X$) and target ($y$) variables and understand their causal/temporal sequence.

**Problem Statement:**
Examine `beginner-projects-main/AI-ML Beginners/projects/06_exam_score/main.py` lines 29-31:
```python
df = pd.read_csv(DATA / "exam_scores.csv")
X = df[["hours_studied"]]
y = df["exam_score"]
```
Explain the role of each variable and why the code uses double brackets for $X$ but single brackets for $y$.

**Requirements:**
1. Identify the feature variable and the target variable by name.
2. Explain the temporal relationship: Why is `hours_studied` measured before `exam_score`?
3. State the python data types and dimensionality:
   - What data structure does `df[["hours_studied"]]` produce? What is its shape?
   - What data structure does `df["exam_score"]` produce? What is its shape?
4. Explain why scikit-learn requires $X$ to have 2 dimensions while $y$ can be 1 dimension.

**Constraints:** Verify your answers using the Python interactive interpreter on the actual CSV file.

**Expected Behaviour:** Terminal verification showing shapes and data types matching the theoretical explanation.

**Acceptance Criteria:**
- [ ] `hours_studied` identified as feature ($X$); `exam_score` identified as target ($y$)
- [ ] Double brackets `[[]]` identified as returning a 2D pandas DataFrame
- [ ] Single brackets `[]` identified as returning a 1D pandas Series
- [ ] Dimensionality stated correctly: $X$ is `(28, 1)` and $y$ is `(28,)`
- [ ] scikit-learn's `(n_samples, n_features)` requirement for $X$ is articulated

**Hints:**
- Test `type(df[["hours_studied"]])` versus `type(df["hours_studied"])` in Python.
- Check `df[["hours_studied"]].shape` versus `df["exam_score"].shape`.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 10 minutes

---

## Exercise 1.3: Analyzing the Linear Hypothesis (15 min)
**Objective:** Calculate manual predictions using the learned linear model parameters and analyze edge cases.

**Problem Statement:**
The Exam Score Predictor outputs the fitted line equation:
$$\text{exam\_score} = 5.28 \times \text{hours\_studied} + 35.85$$
You must calculate manual predictions for various study schedules and analyze where the linear model breaks down in real life.

**Requirements:**
1. Manually calculate the predicted exam score for:
   - 0 hours of study
   - 3.5 hours of study
   - 6.0 hours of study (verify against the project benchmark)
   - 10.0 hours of study
   - 15.0 hours of study
2. Calculate the difference in points between 3 hours of study and 4 hours of study. What does this number represent?
3. Explain the "ceiling effect": Why is the prediction for 15.0 hours unrealistic for a real-world examination?
4. Propose a logical boundary condition to handle extreme study inputs.

**Constraints:** Show all mathematical step calculations.

**Expected Behaviour:** Step-by-step arithmetic calculations and a thoughtful 3-4 sentence paragraph discussing real-world test ceilings.

**Acceptance Criteria:**
- [ ] Prediction for 0 hours calculated as $35.85\text{ points}$ (the intercept)
- [ ] Prediction for 6.0 hours calculated as $5.28 \times 6 + 35.85 = 31.68 + 35.85 = 67.53 \approx 67.5\text{ points}$
- [ ] Prediction for 15.0 hours calculated as $5.28 \times 15 + 35.85 = 115.05\text{ points}$
- [ ] Identification that scores above 100 are impossible on standard exams (ceiling effect)
- [ ] Distinction between mathematical models and real-world domain constraints clearly explained

**Hints:**
- Remember $\text{score} = \text{slope} \times \text{hours} + \text{intercept}$.
- Standard exams cannot exceed 100 points.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes

---

## Exercise 1.4: Pipeline Execution & Artifact Verification (15 min)
**Objective:** Execute `main.py`, observe terminal output, and verify generated output artifacts.

**Problem Statement:**
Execute the project script `main.py` in your local environment, locate the generated files in `outputs/`, and inspect their contents.

**Requirements:**
1. Navigate to `beginner-projects-main/AI-ML Beginners/projects/06_exam_score` and run `python main.py`.
2. Record the exact console output lines.
3. Verify that `outputs/exam_score_regression.png` exists and has a non-zero file size.
4. Verify that `outputs/metrics.txt` exists and read its contents.
5. Compare the values in `outputs/metrics.txt` with the console printout and explain why `metrics.txt` has more decimal places.

**Constraints:** Must execute `main.py` in the official workspace.

**Expected Behaviour:** Successful shell execution with both output files verified on disk.

**Acceptance Criteria:**
- [ ] Script executes with zero errors (exit code 0)
- [ ] Console shows: equation, MAE ($4.3\text{ points}$), R² ($0.85$), and 6-hour prediction ($67.5\text{ points}$)
- [ ] `outputs/exam_score_regression.png` confirmed as a valid PNG image
- [ ] `outputs/metrics.txt` confirmed to contain equation, MAE, R², and 6-hour prediction
- [ ] Explanation notes that console output is rounded for human readability (`:.1f` and `:.2f`) while `metrics.txt` preserves 4 decimal places (`:.4f`) for reporting precision

**Hints:**
- Use `ls -l outputs/` to check file sizes.
- Use `cat outputs/metrics.txt` to read the text output.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes
