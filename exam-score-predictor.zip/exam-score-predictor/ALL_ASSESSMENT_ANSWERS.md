# All Correct Answers for Assessments
Project: Exam Score Predictor
---

## Module 01: Foundations & Architecture
**q1-01.** In the Exam Score Predictor project, what is the primary target variable (y) that the model predicts?
   **Correct Answer:** b. The student's numerical exam score
   *Explanation:* The project's goal is to predict a student's final exam score (exam_score) based on how many hours they studied. Therefore, exam_score is the target variable (y).

**q1-02.** Which CSV file contains the historical student dataset used by main.py?
   **Correct Answer:** b. data/exam_scores.csv
   *Explanation:* main.py line 29 loads the dataset from DATA / 'exam_scores.csv', which contains the 28 recorded pairs of study hours and exam scores.

**q1-03.** Why is this project classified as a supervised learning task?
   **Correct Answer:** b. Because the model learns from historical records containing both known inputs (study hours) and known outputs (exam scores)
   *Explanation:* Supervised learning means training an algorithm on labeled historical data where both the input features (hours_studied) and ground-truth targets (exam_score) are known, enabling the model to learn the mathematical mapping between them.

**q1-04.** Why is predicting exam scores formulated as a regression problem rather than a classification problem?
   **Correct Answer:** a. Because exam score is a continuous numerical value along a scale, not a discrete categorical class
   *Explanation:* Regression is specifically used when predicting continuous numerical quantities (like points on a 0-100 scale). Classification is used when predicting discrete classes or categories (like pass/fail or letter grades).

**q1-05.** In main.py, how is the feature matrix X extracted from the pandas DataFrame df?
   **Correct Answer:** b. X = df[["hours_studied"]]
   *Explanation:* In main.py line 30, X is created using double brackets: X = df[['hours_studied']]. This produces a 2D pandas DataFrame required by scikit-learn.

**q1-06.** Why does main.py use double brackets `df[["hours_studied"]]` instead of single brackets when defining X?
   **Correct Answer:** b. scikit-learn estimators mandate that input features X have a 2D shape (n_samples, n_features), which double brackets provide by returning a DataFrame
   *Explanation:* scikit-learn estimators expect feature matrices to be 2-dimensional with shape (n_samples, n_features). Using double brackets df[['hours_studied']] returns a DataFrame of shape (28, 1), whereas single brackets return a 1D Series of shape (28,), which causes a ValueError during fitting.

**q1-07.** What specific study duration does main.py use as its benchmark query for practical prediction?
   **Correct Answer:** b. 6.0 hours
   *Explanation:* main.py line 45 creates a prediction query specifically for 6.0 hours: six_hours = float(model.predict(pd.DataFrame({'hours_studied': [6.0]}))[0]).

**q1-08.** The linear hypothesis in this project assumes which of the following regarding study hours and exam scores?
   **Correct Answer:** c. There is a positive linear trend where each additional hour studied is associated with a constant marginal gain in exam points
   *Explanation:* The linear hypothesis posits that study hours and exam scores exhibit a positive linear relationship, where each additional hour studied yields a constant marginal increase in exam points (the slope of the line).

**q1-09.** What is a known domain limitation of using simple linear regression for exam score prediction at extreme values of study hours?
   **Correct Answer:** b. The model has no ceiling and will predict impossible scores (>100 points) for very large study durations
   *Explanation:* Simple linear regression extends infinitely in both directions without a saturation ceiling. For extreme study hours (e.g. 15 hours), the linear equation calculates scores above 100 points (115+), which violates the physical constraints of a 100-point test.

**q1-10.** Why is `matplotlib.use("Agg")` called on line 14 of main.py before importing `pyplot`?
   **Correct Answer:** b. To configure a headless, non-interactive backend that writes plots directly to disk without requiring a GUI window or display server
   *Explanation:* matplotlib.use('Agg') configures the Anti-Grain Geometry (Agg) backend. This is a non-interactive backend that writes image files directly to disk without attempting to connect to a desktop window manager or graphical display server (such as X11 or Wayland), making it ideal for servers, scripts, and automated grading.

## Module 02: Data Ingestion & Train/Test Partitioning
**q2-01.** What is the total number of student observations (rows) in data/exam_scores.csv?
   **Correct Answer:** b. 28
   *Explanation:* The dataset data/exam_scores.csv contains exactly 28 data rows (lines 2-29 in the CSV file, excluding the header row).

**q2-02.** Why is `matplotlib.use("Agg")` positioned before importing `matplotlib.pyplot` in main.py?
   **Correct Answer:** b. It enables non-interactive file rendering before pyplot binds to a default GUI backend
   *Explanation:* matplotlib.use('Agg') configures the headless Anti-Grain Geometry backend. It must be called before importing pyplot because pyplot binds to a default backend on import, which can crash on servers without an active GUI display server.

**q2-03.** What is the primary benefit of defining paths using `Path(__file__).resolve().parent`?
   **Correct Answer:** b. It ensures paths resolve relative to the script location regardless of the current working directory
   *Explanation:* Path(__file__).resolve().parent calculates the absolute path of the directory containing main.py. This guarantees that relative references like DATA and OUT work correctly regardless of the user's current shell working directory.

**q2-04.** What is the shape of the feature matrix X created by `X = df[["hours_studied"]]`?
   **Correct Answer:** b. (28, 1)
   *Explanation:* Double brackets df[['hours_studied']] instruct pandas to return a 2D DataFrame. With 28 rows and 1 column, the shape is (28, 1).

**q2-05.** What error occurs if you pass a 1D pandas Series `df["hours_studied"]` as the feature matrix to `LinearRegression.fit()`?
   **Correct Answer:** b. ValueError: Expected 2D array, got 1D array instead
   *Explanation:* scikit-learn estimators mandate that the feature matrix X be 2-dimensional (n_samples, n_features). If a 1D Series is provided, fit() raises 'ValueError: Expected 2D array, got 1D array instead'.

**q2-06.** When calling `train_test_split(X, y, test_size=0.25, random_state=42)` on our 28-row dataset, how many samples are assigned to the test set?
   **Correct Answer:** b. 7
   *Explanation:* With test_size=0.25 on 28 rows, exactly 25% of the data is allocated to the test set: 28 * 0.25 = 7 test samples (and 21 training samples).

**q2-07.** What is the primary role of `random_state=42` in `train_test_split`?
   **Correct Answer:** b. It ensures the pseudo-random split is deterministic and reproducible across runs
   *Explanation:* random_state initializes the pseudo-random number generator to a fixed seed (42), ensuring that the random shuffle and split produce identical training and testing sets on every run.

**q2-08.** What is 'data leakage' in a machine learning workflow?
   **Correct Answer:** b. When information from the test set is improperly shared with the training set, causing overly optimistic evaluation
   *Explanation:* Data leakage occurs when information from outside the training dataset (such as the holdout test set) leaks into the model training pipeline, resulting in artificially high performance that fails to generalize.

**q2-09.** According to the dataset summary statistics, what is the approximate mean value of `hours_studied` in `exam_scores.csv`?
   **Correct Answer:** b. 5.39 hours
   *Explanation:* Calling df.describe() on exam_scores.csv reveals that the mean of hours_studied is approximately 5.39 hours (5.392857).

**q2-10.** If `OUT = BASE / 'outputs'`, why is `OUT.mkdir(exist_ok=True)` preferred over `OUT.mkdir()` without parameters?
   **Correct Answer:** a. Because without exist_ok=True, the call crashes with FileExistsError if the directory already exists
   *Explanation:* By default, Path.mkdir() raises FileExistsError if the target folder already exists on disk. Specifying exist_ok=True safely suppresses this error, making the script idempotent.

## Module 03: Linear Regression Fitting & Mathematics
**q3-01.** In the standard linear equation y = mx + b, which parameter corresponds to the machine learning 'slope' (or weight)?
   **Correct Answer:** b. m
   *Explanation:* In the classical equation y = mx + b, m represents the slope (rate of change / weight) that multiplies the independent feature x.

**q3-02.** How is a statistical residual defined for an individual student observation?
   **Correct Answer:** b. The difference between the student's actual exam score and the model's predicted score (y - y_hat)
   *Explanation:* A residual is defined as the vertical difference between the actual observed value y and the model's predicted value y_hat: e = y - y_hat.

**q3-03.** In scikit-learn's LinearRegression, which attribute stores the learned slope(s) after calling fit()?
   **Correct Answer:** b. model.coef_
   *Explanation:* scikit-learn stores the learned regression slopes in the model.coef_ attribute (short for coefficients).

**q3-04.** What does our model's learned slope value of approximately 5.28 mean in educational terms?
   **Correct Answer:** b. Each additional hour of study is associated with an expected increase of approximately 5.28 exam points
   *Explanation:* The slope is the rate of change: for every additional 1 hour of study, the model estimates that a student will gain approximately 5.28 exam points.

**q3-05.** Why does Ordinary Least Squares (OLS) square the residuals before summing them?
   **Correct Answer:** b. To prevent positive and negative errors from canceling each other out and to penalize large errors more heavily
   *Explanation:* Squaring residuals ensures that positive and negative errors cannot cancel out to zero, and it quadratically penalizes large errors, forcing the fitted line to remain close to all data points.

**q3-06.** In scikit-learn, why is `model.coef_[0]` indexed with `[0]` to obtain the slope for `hours_studied`?
   **Correct Answer:** b. Because model.coef_ is an array designed to hold coefficients for multiple features, and hours_studied is the first feature
   *Explanation:* scikit-learn supports multiple linear regression with p features, so model.coef_ is an array of length p. For our single feature (hours_studied), the coefficient is stored at index 0: model.coef_[0].

**q3-07.** What does our model's learned intercept of approximately 35.85 represent?
   **Correct Answer:** b. The estimated baseline exam score for a student who studied zero hours (hours_studied = 0)
   *Explanation:* In linear regression, the intercept is the predicted value of y when x = 0. Here, it represents the estimated baseline exam score (35.85 points) for a student who studied zero hours.

**q3-08.** If a student increases their study time by 3.0 hours, what is their expected score gain based on the slope of 5.28?
   **Correct Answer:** c. 15.84 points
   *Explanation:* Change in score equals slope multiplied by change in hours: Δy = 5.28 * 3.0 = 15.84 points.

**q3-09.** Why is evaluating the linear regression equation at hours = 0 considered 'extrapolation' in our project?
   **Correct Answer:** b. Because the lowest observed study duration in exam_scores.csv is 1.5 hours, meaning 0 lies outside the range of observed data
   *Explanation:* Extrapolation occurs when evaluating a model outside the range of observed training data. In exam_scores.csv, observed study hours range from 1.5 to 9.9 hours. Evaluating at 0 hours is outside this range.

**q3-10.** What is the complete governing equation printed by main.py for predicting exam scores?
   **Correct Answer:** b. score = 5.28 x hours + 35.85
   *Explanation:* main.py line 50 prints: 'Model: score = 5.28 x hours + 35.85', reflecting the learned slope (5.28) and intercept (35.85).

## Module 04: Evaluation Metrics (MAE & R²)
**q4-01.** Which scikit-learn method is called to execute model training?
   **Correct Answer:** b. model.fit()
   *Explanation:* In scikit-learn's standard API, the fit() method trains the estimator on the provided data.

**q4-02.** What happens if you attempt to call `model.predict()` on a LinearRegression instance before calling `model.fit()`?
   **Correct Answer:** b. scikit-learn raises a NotFittedError
   *Explanation:* Calling predict() on an un-fitted scikit-learn estimator raises a NotFittedError (a subclass of ValueError and AttributeError) informing the user that fit() must be called first.

**q4-03.** In scikit-learn, what does a trailing underscore in an attribute name (e.g. `model.coef_`) indicate?
   **Correct Answer:** b. The attribute was estimated from data during the fit() method
   *Explanation:* In scikit-learn conventions, all attributes that are estimated or learned from data during fit() end with a trailing underscore (e.g. coef_, intercept_, n_features_in_).

**q4-04.** In main.py, how is the prediction query for 6 hours of study constructed?
   **Correct Answer:** c. model.predict(pd.DataFrame({"hours_studied": [6.0]}))
   *Explanation:* main.py line 45 creates a single-row DataFrame matching the training column name: pd.DataFrame({'hours_studied': [6.0]}), satisfying the 2D requirement.

**q4-05.** What is the predicted exam score for 6.0 hours of study printed by main.py?
   **Correct Answer:** c. 67.5 points
   *Explanation:* main.py line 53 prints: 'Prediction for 6 hours: 67.5 points'. Evaluating the fitted equation yields 5.2766 * 6.0 + 35.8466 = 67.5061, which rounds to 67.5 points.

**q4-06.** Why does wrapping `float(model.predict(...)[0])` use `[0]`?
   **Correct Answer:** b. Because predict() returns a 1D NumPy array of predictions, and [0] extracts the first (and only) prediction scalar
   *Explanation:* model.predict() always returns an array of predictions (one per input sample). For a 1-row input, it returns a 1-element array, so [0] indexes the single predicted scalar value.

**q4-07.** Why should the column name in a query DataFrame match the feature name used during training (`"hours_studied"`)?
   **Correct Answer:** a. scikit-learn tracks feature names from fit() and warns or errors if inference feature names do not match
   *Explanation:* scikit-learn stores feature_names_in_ during fit(). If inference DataFrames have different column names, scikit-learn emits a warning or error about unseen feature names.

**q4-08.** How does the prediction from `model.predict(pd.DataFrame({"hours_studied": [6.0]}))[0]` compare to calculating `slope * 6.0 + intercept`?
   **Correct Answer:** b. They are mathematically identical because LinearRegression evaluates that exact linear equation
   *Explanation:* model.predict() directly computes the dot product of weights and features plus bias (slope * x + intercept). Both approaches yield the exact same numerical result.

**q4-09.** Why is predicting for 6.0 hours considered 'interpolation' rather than 'extrapolation'?
   **Correct Answer:** b. Because 6.0 lies comfortably within the observed dataset range of 1.5 to 9.9 hours
   *Explanation:* Interpolation refers to predicting within the range of observed training data. Since the dataset contains study hours from 1.5 to 9.9, 6.0 hours falls comfortably within this range.

**q4-10.** If a user queries the model with 16.0 hours of study, what is a major domain limitation of simple linear regression?
   **Correct Answer:** b. The unconstrained linear model will predict an impossible score above 100 points (~120 points), failing to reflect exam ceilings and diminishing returns
   *Explanation:* Linear regression has no saturation ceiling and will extrapolate infinitely: 5.28 * 16 + 35.85 = ~120.3 points. In reality, exams cap at 100 points, diminishing returns set in, and extreme study causes fatigue.

## Module 05: Target Point Inference (6-Hour Prediction)
**q5-01.** What does Mean Absolute Error (MAE) measure in this project?
   **Correct Answer:** b. The average absolute difference between predicted exam scores and true exam scores, measured in exam points
   *Explanation:* Mean Absolute Error computes the average absolute distance between actual test scores and predicted test scores, measuring average error magnitude directly in exam points.

**q5-02.** What is the approximate Mean Absolute Error (MAE) on the test set reported by main.py?
   **Correct Answer:** b. 4.3 points (exact: 4.3208 points)
   *Explanation:* main.py line 51 prints: 'Mean absolute error: 4.3 points', and line 74 saves 'mean absolute error: 4.3208' to metrics.txt.

**q5-03.** In what physical units is Mean Absolute Error (MAE) expressed in our project?
   **Correct Answer:** b. Exam points
   *Explanation:* MAE preserves the exact scale and units of the target variable. Since y is measured in exam points, MAE is expressed in exam points.

**q5-04.** What does our model's test R² score of approximately 0.85 indicate?
   **Correct Answer:** b. Approximately 85% of the variance in student exam scores is explained by study hours through the linear model
   *Explanation:* R² measures the fraction of total variance in the target variable explained by the feature. R² = 0.85 means 85% of exam score variation is explained by study hours.

**q5-05.** How is R² calculated relative to the naive mean baseline model?
   **Correct Answer:** b. R² = 1 - (RSS / TSS)
   *Explanation:* R² is defined as 1 minus the ratio of Residual Sum of Squares (RSS) to Total Sum of Squares (TSS): R² = 1 - (RSS / TSS).

**q5-06.** In main.py, how are the training data and testing data visually distinguished on the scatter plot?
   **Correct Answer:** b. Training data are blue circles (#2471a3); testing data are orange squares (#e67e22, marker='s')
   *Explanation:* main.py lines 59-60 plot training points as blue circles (color='#2471a3', s=55) and test points as orange squares (color='#e67e22', marker='s', s=65).

**q5-07.** Why does main.py use `np.linspace(df['hours_studied'].min(), df['hours_studied'].max(), 100)` when generating the line of best fit?
   **Correct Answer:** b. To generate 100 evenly spaced x-coordinates spanning the observed data range to draw a smooth, continuous regression line
   *Explanation:* np.linspace generates 100 evenly spaced values between the minimum (1.5) and maximum (9.9) study hours so that model.predict can evaluate and plot a smooth line across the full data range.

**q5-08.** What visual marker is used on the regression plot to highlight the 6-hour prediction scenario?
   **Correct Answer:** b. A prominent black star (color='#111111', marker='*', s=220, zorder=5)
   *Explanation:* main.py line 62 plots the 6-hour prediction using a prominent black star marker: ax.scatter([6], [six_hours], color='#111111', marker='*', s=220, zorder=5, label='6-hour prediction').

**q5-09.** Why is `zorder=5` specified when plotting the 6-hour prediction star marker?
   **Correct Answer:** b. To ensure the star is layered on top of the regression line rather than being obscured beneath it
   *Explanation:* In matplotlib, higher zorder values are drawn on top of lower zorder layers. Setting zorder=5 on the star marker ensures it is drawn on top of the red regression line (default zorder 2).

**q5-10.** Why is `plt.close(fig)` called at line 70 immediately after saving the plot?
   **Correct Answer:** b. To free up system RAM and prevent memory leaks from accumulated unclosed figures in memory
   *Explanation:* plt.close(fig) destroys the figure object and releases its associated memory. Failing to close figures causes memory leaks in batch scripts or automated pipelines.

## Module 06: Visualizing the Best-Fit Line & Exporting Metrics
**q6-01.** What is the primary role of the `if __name__ == '__main__':` block at the bottom of main.py?
   **Correct Answer:** a. It ensures the main() function executes only when the script is run directly, allowing safe modular imports without executing the pipeline
   *Explanation:* The if __name__ == '__main__': idiom checks whether the script is being executed directly as the main program. This allows other scripts, test suites, or modules to import functions from main.py without accidentally triggering the training and plotting pipeline.

**q6-02.** What are the two persistent artifact files generated in the outputs/ directory by main.py?
   **Correct Answer:** b. exam_score_regression.png and metrics.txt
   *Explanation:* main.py generates two output files in outputs/: the high-resolution regression plot (outputs/exam_score_regression.png) and the numerical metrics summary (outputs/metrics.txt).

**q6-03.** What shell command exit status indicates that main.py completed execution without any errors?
   **Correct Answer:** a. 0
   *Explanation:* In Unix, Linux, and Windows command environments, an exit code of 0 universally indicates that the process completed successfully without errors.

**q6-04.** Why do the values in outputs/metrics.txt use 4 decimal places while the console output uses 1 or 2 decimal places?
   **Correct Answer:** b. Console logs prioritize clean human readability, while persistent files preserve higher precision to prevent rounding errors in downstream systems and autograders
   *Explanation:* This implements the dual-output pattern: console logs are rounded (:.1f, :.2f) for human readability, while metrics.txt preserves 4 decimal places (:.4f) to prevent compounding rounding errors in downstream software and autograders.

**q6-05.** What causes the error `ValueError: Expected 2D array, got 1D array instead` when calling model.fit()?
   **Correct Answer:** b. The feature matrix was extracted using single brackets df['hours_studied'] (yielding a 1D Series) instead of double brackets df[['hours_studied']] (yielding a 2D DataFrame)
   *Explanation:* scikit-learn estimators mandate that the feature matrix X have 2 dimensions (n_samples, n_features). Single brackets df['hours_studied'] return a 1D Series of shape (28,), causing ValueError. Double brackets df[['hours_studied']] return a 2D DataFrame of shape (28, 1).

**q6-06.** What happens if random_state=42 is omitted from the train_test_split() call?
   **Correct Answer:** b. The split becomes non-deterministic, causing the learned slope, intercept, MAE, and R² to fluctuate on every execution
   *Explanation:* train_test_split randomly shuffles rows. Without a fixed random_state seed, a different pseudo-random split is generated on each execution, causing learned parameters and evaluation metrics to fluctuate unpredictably.

**q6-07.** In a multivariate linear regression model, what does each learned coefficient (slope) represent?
   **Correct Answer:** b. The expected change in exam score for a one-unit increase in that specific feature, holding all other features constant
   *Explanation:* In multiple linear regression, each coefficient w_j represents the partial derivative: the expected change in the target variable for a 1-unit increase in feature x_j, holding all other features constant (ceteris paribus).

**q6-08.** What is the primary risk of adding 50 new features to a small dataset of only 28 students?
   **Correct Answer:** b. Severe overfitting, where the model memorizes idiosyncratic noise in the training set and fails completely on unseen students
   *Explanation:* When the number of features p exceeds or approaches the number of samples n (p > n), linear models suffer from severe overfitting and multicollinearity, memorizing spurious noise and losing all generalizability.

**q6-09.** What is the primary ethical guideline when deploying student performance prediction models in educational institutions?
   **Correct Answer:** b. Use predictions proactively to offer supportive academic interventions, advising, and tutoring, while protecting student privacy
   *Explanation:* Ethical learning analytics requires using predictions proactively to offer personalized tutoring, academic coaching, and resources to help students succeed, while strictly protecting student privacy.

**q6-10.** How can a developer protect users from unrealistic extrapolation outputs (e.g. predicting a score of 120 points for 16 study hours)?
   **Correct Answer:** b. Implement a post-processing guard function that warns when inputs lie outside observed boundaries and clamps predictions between 0 and 100
   *Explanation:* Defensive machine learning deployment involves creating guard functions that warn when inputs require risky extrapolation outside observed bounds and clamp outputs within valid domain ranges (such as [0, 100] for an exam).
