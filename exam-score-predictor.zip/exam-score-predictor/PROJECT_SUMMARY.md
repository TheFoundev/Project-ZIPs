# Project Summary: Predict Your Exam Score

## Executive Overview
The **Predict Your Exam Score** project is a foundational machine learning educational package designed to teach the fundamentals of **Supervised Simple Linear Regression**. Using empirical student study records from `data/exam_scores.csv` located in `beginner-projects-main/AI-ML Beginners/projects/06_exam_score/`, students learn how to formulate an applied predictive analytics problem, manipulate tabular data, train a regression model using scikit-learn, evaluate its real-world generalization, and create clear explanatory data visualizations.

## Educational Objectives
- Formulate regression problems and distinguish continuous numerical prediction from classification.
- Understand the Ordinary Least Squares (OLS) algorithm and the mathematical equation of a line ($y = mx + b$).
- Master the mechanical nuances of data science in Python: 2D feature matrix shapes, train-test splitting, and headless plotting.
- Interpret regression coefficients in domain terms: understanding baseline scores (intercept) and marginal performance gains per hour (slope).
- Quantify prediction error with Mean Absolute Error (MAE) and explain variance with R-squared ($R^2$).
- Deploy a trained model for forward-looking inference on unseen scenarios (predicting score for 6.0 hours of study).

## Real-World Educational Analytics Context
In higher education and secondary schooling, academic advisors and students frequently grapple with time management and preparation strategies. Predicting performance based on dedicated study time enables students to set realistic goals, gauge required revision hours, and allow institutions to provide proactive academic support before examinations occur.

## Implemented Architecture & Pipeline
1. **Data Ingestion**: Loads 28 student records containing `hours_studied` and `exam_score`.
2. **Feature Separation**: Isolates `hours_studied` as a 2D DataFrame $X$ of shape `(28, 1)` and `exam_score` as a 1D Series $y$ of shape `(28,)`.
3. **Reproducible Split**: Splits records using `train_test_split(X, y, test_size=0.25, random_state=42)` yielding 21 training observations and 7 holdout testing observations.
4. **Model Fitting**: Optimizes `LinearRegression()` on the training set, extracting a slope of $\approx 5.28$ and an intercept of $\approx 35.85$.
5. **Model Evaluation**: Generates predictions on the 7 test observations, calculating a Mean Absolute Error of $\approx 4.32\text{ points}$ and an $R^2$ of $\approx 0.85$.
6. **Scenario Inference**: Passes a single-row DataFrame representing 6.0 hours of study into `.predict()`, yielding a predicted exam mark of $\approx 67.51\text{ points}$.
7. **Visualization**: Employs matplotlib to plot training points (blue circles), test points (orange squares), the continuous regression line (red solid line), and the 6-hour prediction (black star marker).
8. **Artifact Persistence**: Generates `outputs/exam_score_regression.png` and `outputs/metrics.txt`.

## Key Quantitative Results
- **Model Equation**: $\text{score} = 5.2766 \times \text{hours} + 35.8466$
- **Console Slope & Intercept**: $\text{score} = 5.28 \times \text{hours} + 35.85$
- **Mean Absolute Error (MAE)**: $4.3208\text{ points}$ (Console: $4.3\text{ points}$)
- **Coefficient of Determination ($R^2$)**: $0.8486$ (Console: $0.85$)
- **Prediction for 6.0 Hours**: $67.5061\text{ points}$ (Console: $67.5\text{ points}$, metrics.txt: $67.51$)

## Project Structure
```text
06_exam_score/
├── main.py
├── data/
│   └── exam_scores.csv
└── outputs/
    ├── exam_score_regression.png
    └── metrics.txt
```

## Security & Reliability Profile
- Safe local execution with zero network requirements and zero hardcoded credentials.
- Headless matplotlib configuration prevents GUI server crashes across containerized, remote, or CI/CD environments.
- Strict path encapsulation via Python's `pathlib.Path` ensures platform neutrality across Linux, macOS, and Windows.
