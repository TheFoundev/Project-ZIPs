# Final Project Requirements

## Project Objective

Reproduce the complete Exam Score Predictor from scratch, following `main.py` exactly. Your implementation should load the dataset (`data/exam_scores.csv`), train an ordinary least squares linear regression model using scikit-learn, evaluate its performance on an unseen test set using Mean Absolute Error (MAE) and the coefficient of determination ($R^2$), predict the expected exam score for a student studying exactly 6.0 hours, and produce both a publication-quality scatter plot with regression trend line (`outputs/exam_score_regression.png`) and an automated metrics text report (`outputs/metrics.txt`). Finally, you will submit a structured analysis report interpreting the statistical findings, identifying model assumptions, and proposing methodological enhancements.

## Functional Requirements

1. **Imports and Environment Setup**
   - Configure the non-interactive matplotlib `Agg` backend before importing `matplotlib.pyplot` to guarantee headless server execution without graphical display errors.
   - Import `Path` from `pathlib`, `numpy`, `pandas`, `matplotlib.pyplot`, and scikit-learn modules: `LinearRegression` from `sklearn.linear_model`, `mean_absolute_error` and `r2_score` from `sklearn.metrics`, and `train_test_split` from `sklearn.model_selection`.
   - Define project directory anchors (`BASE = Path(__file__).resolve().parent`, `DATA = BASE / "data"`, `OUT = BASE / "outputs"`).
   - Ensure target outputs directory exists using `OUT.mkdir(exist_ok=True)`.

2. **Data Ingestion**
   - Ingest `data/exam_scores.csv` using `pd.read_csv()`.
   - Confirm dataset dimensions are exactly 28 rows and 2 columns: `hours_studied` (float) and `exam_score` (float).
   - Confirm absence of missing values or incompatible data types.

3. **Feature and Target Isolation**
   - Isolate independent feature matrix $X$ using double-bracket indexing: `X = df[["hours_studied"]]` (yielding a 2-dimensional pandas DataFrame of shape `(28, 1)`).
   - Isolate dependent target vector $y$ using single-bracket indexing: `y = df["exam_score"]` (yielding a 1-dimensional pandas Series of shape `(28,)`).

4. **Holdout Train/Test Split**
   - Partition data into training and evaluation sets using:
     ```python
     X_train, X_test, y_train, y_test = train_test_split(
         X, y, test_size=0.25, random_state=42
     )
     ```
   - Verify partitioning ratios: Training partition contains exactly 21 rows (75%); Test partition contains exactly 7 rows (25%).

5. **Model Instantiation and Fitting**
   - Instantiate `LinearRegression()` from `sklearn.linear_model`.
   - Train the estimator strictly on the training subset: `model.fit(X_train, y_train)`.
   - Strictly prevent data leakage: Ensure `X_test` and `y_test` are never exposed to `model.fit()`.

6. **Parameter and Coefficient Extraction**
   - Extract the learned regression slope: `slope = float(model.coef_[0])` (expected $\approx 5.2766$).
   - Extract the learned vertical intercept: `intercept = float(model.intercept_)` (expected $\approx 35.8466$).
   - Formulate the predictive model equation: $\text{score} = \beta_1 \cdot \text{hours} + \beta_0$.

7. **Out-of-Sample Model Evaluation**
   - Generate test set predictions using: `predictions = model.predict(X_test)`.
   - Compute Mean Absolute Error: `mae = mean_absolute_error(y_test, predictions)` (expected $\approx 4.3208$ points).
   - Compute Coefficient of Determination: `r2 = r2_score(y_test, predictions)` (expected $\approx 0.8486$).

8. **Target Point Inference (6.0 Hours)**
   - Construct a dedicated 2D DataFrame for inference: `pd.DataFrame({"hours_studied": [6.0]})`.
   - Execute model inference and unpack the scalar float: `six_hours = float(model.predict(...)[0])` (expected $\approx 67.5062$ points).

9. **Terminal Console Reporting**
   - Print banner and metrics matching `main.py` formatting:
     ```text
     ============================================================
     PREDICT YOUR EXAM SCORE
     ============================================================
     Model: score = 5.28 x hours + 35.85
     Mean absolute error: 4.3 points
     R-squared: 0.85
     Prediction for 6 hours: 67.5 points
     ```
   - Followed by save confirmations and extension recommendations.

10. **Data Visualization**
    - Generate continuous grid of 100 points: `line_x = np.linspace(df["hours_studied"].min(), df["hours_studied"].max(), 100)` and compute fitted regression predictions `line_y`.
    - Instantiate single figure and axes: `fig, ax = plt.subplots(figsize=(7, 5))`.
    - Plot training observations as blue circular markers (`color="#2471a3"`, `s=55`, `label="training data"`).
    - Plot test observations as orange square markers (`color="#e67e22"`, `s=65`, `marker="s"`, `label="test data"`).
    - Plot continuous fitted regression line in crimson red (`color="#c0392b"`, `linewidth=2.5`, `label="line of best fit"`).
    - Plot the 6-hour predicted inference point as a prominent black star (`color="#111111"`, `marker="*"`, `s=220`, `zorder=5`, `label="6-hour prediction"`).
    - Configure axes labels (`"Hours studied"`, `"Exam score"`), plot title (`"Study hours vs. exam score"`), legend, and grid (`alpha=0.25`).

11. **Artifact Generation and Resource Cleanup**
    - Apply `fig.tight_layout()` to prevent margin clipping.
    - Save figure to `outputs/exam_score_regression.png` with `dpi=150` and `bbox_inches="tight"`.
    - Explicitly release GUI/memory resources: `plt.close(fig)`.
    - Write text metrics file `outputs/metrics.txt` containing 4 formatted lines:
      ```text
      equation: score = 5.2766 * hours + 35.8466
      mean absolute error: 4.3208
      r2: 0.8486
      prediction at 6 hours: 67.51
      ```

## Non-Functional Requirements

- **Strict Reproducibility**: Using `random_state=42` guarantees deterministic partitioning across systems. Any rerun must yield identical values.
- **Numerical Integrity**: Mathematical verification must hold: $\text{slope} \times 6.0 + \text{intercept} \approx \text{prediction}$ within standard floating-point precision.
- **Cross-Platform Compatibility**: Use `pathlib.Path` exclusively; do not hardcode POSIX (`/`) or Windows (`\`) string separators.
- **Headless Execution**: `matplotlib.use("Agg")` must execute prior to pyplot importing to ensure error-free runs on remote servers and containerized CI/CD runners.
- **Memory Safety**: Every generated figure must be closed via `plt.close(fig)` to avert memory accumulation warnings.

## Implementation Milestones

| Milestone | Deliverable | Verification Check |
|---|---|---|
| **1: Environment Initialization** | Import statements & backend configuration | Zero warnings or import errors |
| **2: Data Ingestion** | Raw DataFrame ingestion | `df.shape == (28, 2)` |
| **3: Feature/Target Separation** | Matrix $X$ (2D) & vector $y$ (1D) | `X.shape == (28, 1)`, `y.shape == (28,)` |
| **4: Train/Test Partitioning** | 4 sub-arrays (`X_train`, `X_test`, `y_train`, `y_test`) | `len(X_train) == 21`, `len(X_test) == 7` |
| **5: Model Estimation** | Trained `LinearRegression` model | `model.coef_` and `model.intercept_` fitted |
| **6: Evaluation Metrics** | Computed MAE and $R^2$ values | MAE $\approx 4.32$, $R^2 \approx 0.85$ |
| **7: 6.0-Hour Inference** | Target scalar score prediction | `six_hours` $\approx 67.51$ points |
| **8: Scatter Plot Visualization** | Saved graphic `exam_score_regression.png` | 4 graphical layers, 150 DPI, valid PNG |
| **9: Automated Metrics Export** | Generated `outputs/metrics.txt` | Exactly 4 formatted metric lines |
| **10: End-to-End Execution** | Full script run via terminal | Clean execution, exact console banner output |

## Expected Deliverables

- [ ] **Python Source Script** (`main.py` or `final_exam_score.py`) implementing complete workflow.
- [ ] **Standard Console Output**:
  ```text
  ============================================================
  PREDICT YOUR EXAM SCORE
  ============================================================
  Model: score = 5.28 x hours + 35.85
  Mean absolute error: 4.3 points
  R-squared: 0.85
  Prediction for 6 hours: 67.5 points

  Saved: outputs/exam_score_regression.png, outputs/metrics.txt
  Try this: collect five real study-hour/score pairs and add them.
  ```
- [ ] **Artifact `outputs/exam_score_regression.png`**: High-resolution visualization with blue training circles, orange test squares, crimson regression trend line, and black prediction star.
- [ ] **Artifact `outputs/metrics.txt`**: 4-line text record with 4 decimal places for model parameters and 2 decimal places for prediction.
- [ ] **1-Page Analytical Summary Report** addressing:
  1. Parameter interpretation: Baseline score ($\beta_0 \approx 35.85$) and marginal study return ($\beta_1 \approx 5.28$ points/hr).
  2. Model goodness of fit: Substantive meaning of MAE ($4.3$ points) and $R^2$ ($84.9\%$ variance explained).
  3. Actionable inference: Practical utility and certainty of the $67.5$-point prediction for 6 hours of study.
  4. Core limitations: Boundary conditions (scores cannot exceed 100), diminishing marginal returns, omitted variables (sleep, prior knowledge).
  5. Recommended improvements: Polynomial feature modeling, multivariate regression, and k-fold cross-validation.

## Acceptance Criteria

- [ ] Script runs cleanly via command line: `python main.py` with return code 0.
- [ ] No warnings regarding deprecated features or unclosed GUI figures.
- [ ] Training partition size is exactly 21 samples; evaluation partition is exactly 7 samples.
- [ ] MAE evaluated on test set is between $4.1$ and $4.5$ points.
- [ ] $R^2$ evaluated on test set is between $0.82$ and $0.88$.
- [ ] 6-hour prediction is between $67.0$ and $68.0$ points.
- [ ] Linear equation identity check: $\text{abs}((5.27660351 \times 6.0 + 35.8465638) - 67.506184) < 10^{-4}$.
- [ ] Plot contains all 4 designated visual elements with distinct colors, marker styles, and legend tags.
- [ ] `outputs/metrics.txt` contains exactly 4 lines with identical keys (`equation:`, `mean absolute error:`, `r2:`, `prediction at 6 hours:`).

## Testing Checklist

- [ ] Confirm Python 3.10+ installation: `python3 --version`.
- [ ] Verify core dependencies: `python3 -c "import numpy, pandas, matplotlib, sklearn; print('All installed')"`
- [ ] Confirm raw dataset existence: `test -f data/exam_scores.csv && echo "Dataset exists"`
- [ ] Execute script: `python3 main.py`.
- [ ] Confirm console output matches required format and numerical values.
- [ ] Validate graphic file creation and size: `test -s outputs/exam_score_regression.png && file outputs/exam_score_regression.png`.
- [ ] Validate metrics text content: `cat outputs/metrics.txt`.
- [ ] Test deterministic repeatability by running twice and confirming zero git diff on generated output files.

## Expected Output Values Reference

| Parameter / Metric | Exact Internal Float | Console Formatted | Metrics File Formatted |
|---|---|---|---|
| Slope ($\beta_1$) | `5.27660351...` | `5.28` | `5.2766` |
| Intercept ($\beta_0$) | `35.8465638...` | `35.85` | `35.8466` |
| Test Set MAE | `4.32081123...` | `4.3 points` | `4.3208` |
| Test Set $R^2$ | `0.84858348...` | `0.85` | `0.8486` |
| 6-Hour Prediction | `67.5061848...` | `67.5 points` | `67.51` |

## Troubleshooting Matrix

| Symptom / Error | Root Cause | Resolution |
|---|---|---|
| `ModuleNotFoundError: No module named 'sklearn'` | Scikit-learn not installed in active environment | Execute `pip install scikit-learn` |
| `FileNotFoundError: exam_scores.csv` | Relative path evaluated from wrong current working directory | Anchor path using `Path(__file__).resolve().parent / "data" / "exam_scores.csv"` |
| `ValueError: Expected 2D array, got 1D array instead` | Feature matrix extracted using single brackets (`df['hours_studied']`) | Extract with double brackets: `df[['hours_studied']]` |
| `AttributeError: 'LinearRegression' object has no attribute 'coef_'` | Attempting to access coefficients before fitting estimator | Ensure `model.fit(X_train, y_train)` precedes coefficient access |
| `KeyError: 'hours_studied'` | Misspelled column header during DataFrame indexing | Verify spelling against `df.columns` (`hours_studied`, `exam_score`) |
| Matplotlib GUI freeze or `UserWarning: Matplotlib is currently using agg...` | Backend set after importing pyplot | Place `matplotlib.use('Agg')` strictly before `import matplotlib.pyplot as plt` |
| Legend missing markers or overlapping text | Missing labels in scatter/plot calls or omitted `tight_layout()` | Ensure every `scatter` and `plot` call has `label=...` and invoke `fig.tight_layout()` |

## Optional Extension Challenges

1. **Upper Ceiling Clamping**: Implement post-processing logic to ensure model predictions cannot mathematically exceed 100 points, or explore logistic/sigmoid saturation modeling.
2. **Diminishing Returns (Polynomial Regression)**: Implement `PolynomialFeatures(degree=2)` from `sklearn.preprocessing` to model realistic fatigue where studying beyond 8 hours yields decreasing marginal score gains.
3. **K-Fold Cross-Validation**: Replace single train/test split with 5-fold cross-validation using `cross_val_score(model, X, y, cv=5, scoring='neg_mean_absolute_error')` to assess stability across all 28 observations.
4. **Statistical Inference & p-values**: Use `statsmodels.api.OLS` to calculate formal t-statistics, p-values, and 95% confidence intervals for both slope and intercept.
5. **Interactive Prediction CLI**: Add an interactive loop prompting the student for study hours and warning if hours fall outside the sample domain ($[1.5, 9.9]$ hours) to deter hazardous extrapolation.
