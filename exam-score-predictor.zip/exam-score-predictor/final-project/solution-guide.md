# Mentor Solution Guide: Exam Score Predictor

## Overview

This guide provides mentors and evaluators with comprehensive verification standards, checkpoint-by-checkpoint code analysis, common conceptual pitfalls, and diagnostic criteria for the **Exam Score Predictor** AI-ML project. Students should implement an end-to-end regression pipeline mirroring `main.py` using scikit-learn, pandas, numpy, and matplotlib.

## Checkpoint-by-Checkpoint Architecture Verification

### Checkpoint 1: Backend and Imports (lines 10-20)
```python
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split
```

**Mentor Verification Checklist:**
- `matplotlib.use("Agg")` is executed **strictly before** `import matplotlib.pyplot as plt`. This is critical for headless Linux/CI execution.
- Imports are clean and organized according to PEP 8 standards (standard library `pathlib`, third-party packages, specific sklearn submodules).
- No extraneous or unneeded packages are imported.

**Common Student Traps:**
- Placing `matplotlib.use("Agg")` after `plt` import, which issues a runtime warning or fails to override the interactive GUI backend.
- Importing `LinearRegression` from `sklearn.linear_models` (plural) or `sklearn.regression`, causing `ModuleNotFoundError`.

---

### Checkpoint 2: Path Anchor Configuration (lines 22-25)
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)
```

**Mentor Verification Checklist:**
- `BASE` utilizes `Path(__file__).resolve().parent` to decouple execution from the user's terminal working directory.
- `OUT.mkdir(exist_ok=True)` is called prior to file I/O operations to guarantee the target directory exists.
- Paths are composed using the modern `/` operator.

**Common Student Traps:**
- Using raw string paths like `"data/exam_scores.csv"` which fail when executing from outside the project directory.
- Omitting `exist_ok=True`, causing `FileExistsError` on repeated runs.

---

### Checkpoint 3: Data Ingestion and Verification (lines 28-31)
```python
df = pd.read_csv(DATA / "exam_scores.csv")
X = df[["hours_studied"]]
y = df["exam_score"]
```

**Mentor Verification Checklist:**
- Ingested DataFrame has shape `(28, 2)` with columns `hours_studied` and `exam_score`.
- `X` is extracted using double brackets `df[["hours_studied"]]`, producing a 2D `pd.DataFrame` of shape `(28, 1)`.
- `y` is extracted using single brackets `df["exam_score"]`, producing a 1D `pd.Series` of shape `(28,)`.

**Common Student Traps:**
- Single brackets for `X`: `X = df["hours_studied"]` produces a 1D Series. When passed to `model.fit()`, scikit-learn raises:
  `ValueError: Expected 2D array, got 1D array instead`.
- Misspelling column names (`hours` instead of `hours_studied`, `score` instead of `exam_score`).

---

### Checkpoint 4: Train/Test Partitioning (lines 33-35)
```python
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)
```

**Mentor Verification Checklist:**
- `test_size=0.25` allocates $25\%$ of data to test.
- Total samples = 28. Therefore, `len(X_train) == 21` ($75\%$) and `len(X_test) == 7` ($25\%$).
- `random_state=42` is set to ensure exact numerical reproducibility.
- Unpacking order is preserved: `X_train, X_test, y_train, y_test`.

**Common Student Traps:**
- Omitting `random_state=42`, causing random splits and fluctuating evaluation metrics on each run.
- Inverting the unpacking variables (e.g., `y_train, y_test, X_train, X_test`), causing shape mismatch during fitting.

---

### Checkpoint 5: Model Fitting and Data Leakage Prevention (lines 37-38)
```python
model = LinearRegression()
model.fit(X_train, y_train)
```

**Mentor Verification Checklist:**
- Model instance created from `LinearRegression`.
- `model.fit()` is called **only on training data** (`X_train, y_train`).
- No evaluation data (`X_test, y_test`) or whole-dataset objects (`X, y`) are passed to `fit()`.

**Common Student Traps:**
- Calling `model.fit(X, y)` — catastrophic data leakage; invalidates out-of-sample evaluation.
- Calling `model.fit(X_test, y_test)` — fitting on test set.
- Attempting to inspect `model.coef_` prior to calling `fit()`, triggering `AttributeError`.

---

### Checkpoint 6: Test Inference & Parameter Extraction (lines 39-42)
```python
predictions = model.predict(X_test)

slope = float(model.coef_[0])
intercept = float(model.intercept_)
```

**Mentor Verification Checklist:**
- `predictions` generated on unseen `X_test`.
- `model.coef_` is a 1D numpy array of shape `(1,)`; student must index `[0]` to retrieve the scalar weight.
- `float()` casts both slope and intercept to native Python floats for clean string interpolation.
- Numerical checks:
  - $\text{Slope } \beta_1 \approx 5.2766$ (console format: `5.28`)
  - $\text{Intercept } \beta_0 \approx 35.8466$ (console format: `35.85`)

**Common Student Traps:**
- `slope = float(model.coef_)` raises `TypeError: only size-1 arrays can be converted to Python scalars` if shape isn't indexed properly in some NumPy versions.
- Predicting on `X_train` instead of `X_test`, contaminating holdout validation metrics.

---

### Checkpoint 7: Metric Computation (lines 43-44)
```python
mae = mean_absolute_error(y_test, predictions)
r2 = r2_score(y_test, predictions)
```

**Mentor Verification Checklist:**
- `y_test` (ground truth) is passed as the first argument, `predictions` (estimates) as the second.
- Numerical checks on test set ($n=7$):
  - $\text{MAE} \approx 4.320811$ points (console format: `4.3 points`, metrics file: `4.3208`)
  - $R^2 \approx 0.848583$ (console format: `0.85`, metrics file: `0.8486`)

**Common Student Traps:**
- Passing `y_train` instead of `y_test`, yielding overly optimistic training metrics (Training MAE is lower, $\approx 3.2$ points).
- Attempting to compute classification metrics like `accuracy_score` on continuous regression outputs, raising continuous target errors.

---

### Checkpoint 8: 6.0-Hour Inference (line 45)
```python
six_hours = float(model.predict(pd.DataFrame({"hours_studied": [6.0]}))[0])
```

**Mentor Verification Checklist:**
- Inference input is wrapped in a 2D DataFrame with matching column name `"hours_studied"`.
- Prediction output array is indexed `[0]` and converted to `float`.
- Numerical check:
  - $\text{six\_hours} = 5.27660351 \times 6.0 + 35.8465638 = 67.506184...$ points (console: `67.5 points`, metrics file: `67.51`).

**Common Student Traps:**
- Passing raw scalar `model.predict(6.0)` or 1D list `model.predict([6.0])`, raising `ValueError: Expected 2D array, got scalar instead`.
- Passing DataFrame with mismatched column name (e.g. `{"hours": [6.0]}`), triggering scikit-learn feature name mismatch warnings.

---

### Checkpoint 9: Console Output Formatting (lines 47-53)
```python
print("=" * 60)
print("PREDICT YOUR EXAM SCORE")
print("=" * 60)
print(f"Model: score = {slope:.2f} x hours + {intercept:.2f}")
print(f"Mean absolute error: {mae:.1f} points")
print(f"R-squared: {r2:.2f}")
print(f"Prediction for 6 hours: {six_hours:.1f} points")
```

**Mentor Verification Checklist:**
- Banner length is exactly 60 characters: `"=" * 60`.
- Formatting specs match `main.py`:
  - Slope and intercept formatted with `:.2f` (`5.28` and `35.85`).
  - MAE formatted with `:.1f` (`4.3 points`).
  - $R^2$ formatted with `:.2f` (`0.85`).
  - 6-hour prediction formatted with `:.1f` (`67.5 points`).

---

### Checkpoint 10: Matplotlib Visualization Architecture (lines 55-70)
```python
line_x = np.linspace(df["hours_studied"].min(), df["hours_studied"].max(), 100)
line_y = model.predict(pd.DataFrame({"hours_studied": line_x}))

fig, ax = plt.subplots(figsize=(7, 5))
ax.scatter(X_train, y_train, color="#2471a3", s=55, label="training data")
ax.scatter(X_test, y_test, color="#e67e22", s=65, marker="s", label="test data")
ax.plot(line_x, line_y, color="#c0392b", linewidth=2.5, label="line of best fit")
ax.scatter([6], [six_hours], color="#111111", marker="*", s=220, zorder=5, label="6-hour prediction")
ax.set_xlabel("Hours studied")
ax.set_ylabel("Exam score")
ax.set_title("Study hours vs. exam score")
ax.legend()
ax.grid(alpha=0.25)
fig.tight_layout()
fig.savefig(OUT / "exam_score_regression.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```

**Mentor Verification Checklist:**
- `line_x` generated using `np.linspace` across data bounds with 100 evaluation points.
- Training observations: Blue `#2471a3`, circular markers, size 55.
- Test observations: Orange `#e67e22`, square markers `marker="s"`, size 65.
- Regression trend line: Crimson `#c0392b`, line width 2.5.
- Target prediction: Pitch black `#111111`, star marker `marker="*"`, size 220, `zorder=5` (guaranteeing it renders above the line).
- Figure saved to `outputs/exam_score_regression.png` with `dpi=150` and `bbox_inches="tight"`.
- `plt.close(fig)` called immediately after saving.

**Common Student Traps:**
- Omitting `zorder=5`, causing the 6-hour star marker to be partially hidden underneath the regression line.
- Forgetting `plt.close(fig)`, leaving figures open in memory.

---

### Checkpoint 11: File Output Generation (lines 72-76)
```python
with open(OUT / "metrics.txt", "w", encoding="utf-8") as handle:
    handle.write(f"equation: score = {slope:.4f} * hours + {intercept:.4f}\n")
    handle.write(f"mean absolute error: {mae:.4f}\n")
    handle.write(f"r2: {r2:.4f}\n")
    handle.write(f"prediction at 6 hours: {six_hours:.2f}\n")
```

**Mentor Verification Checklist:**
- Output written to `outputs/metrics.txt` using UTF-8 encoding.
- Exactly 4 lines present in the file.
- Precision specifications match:
  - Slope: `:.4f` (`5.2766`)
  - Intercept: `:.4f` (`35.8466`)
  - MAE: `:.4f` (`4.3208`)
  - $R^2$: `:.4f` (`0.8486`)
  - Prediction: `:.2f` (`67.51`)

---

## Benchmark Master Key

Mentors should evaluate student results against these exact benchmark values:

| Target Property | Exact Mathematical Value | Expected Student Output | Tolerance Window |
|---|---|---|---|
| Total Samples ($N$) | 28 | `28` | Exact |
| Training Partition ($N_{train}$) | 21 | `21` | Exact |
| Testing Partition ($N_{test}$) | 7 | `7` | Exact |
| Model Slope ($\beta_1$) | `5.27660351...` | `5.28` (console), `5.2766` (file) | $[5.27, 5.29]$ |
| Model Intercept ($\beta_0$) | `35.8465638...` | `35.85` (console), `35.8466` (file) | $[35.80, 35.90]$ |
| Test Set MAE | `4.32081123...` | `4.3 points` (console), `4.3208` (file) | $[4.25, 4.40]$ |
| Test Set $R^2$ | `0.84858348...` | `0.85` (console), `0.8486` (file) | $[0.84, 0.86]$ |
| 6-Hour Prediction | `67.5061848...` | `67.5 points` (console), `67.51` (file) | $[67.40, 67.60]$ |

---

## Grading Rubric Matrix (105 Total Points)

Mentors should use the following scoring rubric:

| Milestone / Component | Max Points | 100% Exemplary Criteria | Deductions / Common Deficiencies |
|---|---|---|---|
| **Data Loading & Prep** | 15 | Correct path, 2D DataFrame for X, 1D Series for y, no missing values | -5 for hardcoded path; -10 for 1D feature array |
| **Train/Test Split** | 10 | `test_size=0.25`, `random_state=42`, correct row split (21 / 7) | -5 for missing `random_state`; -5 for wrong split ratio |
| **Model Training** | 15 | `LinearRegression` fit strictly on `X_train, y_train` | -15 for fitting on all data (leakage); -10 for fitting on test set |
| **Evaluation & Metrics** | 15 | `predict(X_test)`, MAE and $R^2$ correctly computed and matched | -5 for inverted argument order; -10 for evaluating on training set |
| **6-Hour Prediction** | 10 | DataFrame input, scalar extraction, value $\approx 67.5$ | -5 for improper input formatting; -5 for calculation error |
| **Console Output** | 10 | Exact header banner, formatted numbers matching spec | -2 per missing line or incorrectly formatted decimal |
| **Visualization** | 15 | 4 distinct layers, proper hex colors, marker sizes, labels, grid | -3 for missing star zorder; -3 for missing legend/grid |
| **File Outputs** | 10 | Valid PNG (150 DPI), 4-line `metrics.txt` with correct precisions | -5 for missing metrics file; -5 for missing plot file |
| **Analysis Report** | 5 | Thoughtful interpretation of slope, intercept, metrics, and limitations | -2 for generic explanations lacking domain context |

---

## Student Pitfall Diagnosis Guide

When troubleshooting student submissions during office hours or review sessions:

1. **"My R-squared is 0.89 instead of 0.85!"**
   - *Diagnostic*: Student calculated $R^2$ on the training set (`y_train, model.predict(X_train)`), not the test set.
   - *Fix*: Emphasize that model evaluation metrics must reflect generalizability on `y_test, predictions`.

2. **"My graph only shows a red line and orange points, where is the star?"**
   - *Diagnostic*: The black star was plotted with default `zorder=1` or `2`, causing the thick red trend line or data points to render directly on top of it.
   - *Fix*: Add `zorder=5` to the star's `ax.scatter()` call.

3. **"Why does my slope have brackets like `[5.27660351]`?"**
   - *Diagnostic*: Student accessed `model.coef_` without indexing `[0]`. In scikit-learn, `coef_` is always an array because multivariate models have multiple weights.
   - *Fix*: Use `float(model.coef_[0])`.
