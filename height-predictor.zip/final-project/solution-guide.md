# Mentor Solution Guide: How Tall Will You Be?

## Overview
This guide provides mentors and evaluators with the authoritative reference implementation, expected numerical outputs, visual benchmarks, and pedagogical discussion points for the Height Predictor project.

## Implementation Checkpoints

### Checkpoint 1: Headless Configuration and Imports
```python
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split
```
**Mentor Verification Checklist:**
- `matplotlib.use("Agg")` must execute before `import matplotlib.pyplot as plt`.
- `pathlib.Path` is used for robust path anchoring.
- All dependencies are imported from standard library and primary data science libraries.

### Checkpoint 2: Directory Setup and Data Loading
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)

df = pd.read_csv(DATA / "heights.csv")
```
**Mentor Verification Checklist:**
- `OUT.mkdir(exist_ok=True)` avoids race conditions or exceptions if the output folder exists.
- `df.shape` must be `(60, 3)` with columns `mother_cm`, `father_cm`, `child_cm`.

### Checkpoint 3: Feature Engineering
```python
df["midparent_cm"] = (df["mother_cm"] + df["father_cm"]) / 2
X = df[["midparent_cm"]]
y = df["child_cm"]
```
**Common Student Errors:**
- Single brackets: `X = df["midparent_cm"]` creates a 1D Series, causing a shape ValueError in scikit-learn estimators.
- Incorrect formula: Adding without dividing by 2 or averaging child height into the feature.

### Checkpoint 4: Splitting and Fitting
```python
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)

model = LinearRegression()
model.fit(X_train, y_train)
```
**Mentor Verification Checklist:**
- Split sizes: 45 training samples, 15 testing samples.
- Model is strictly fitted on `(X_train, y_train)`. Fitting on the entire dataset constitutes data leakage.

### Checkpoint 5: Parameters and Metrics
```python
predictions = model.predict(X_test)
mae = mean_absolute_error(y_test, predictions)
r2 = r2_score(y_test, predictions)
slope = float(model.coef_[0])
intercept = float(model.intercept_)
example = float(model.predict(pd.DataFrame({"midparent_cm": [170.0]}))[0])
```
**Expected Exact Values:**
- Slope $\beta_1 = 0.884705\dots \approx 0.88$
- Intercept $\beta_0 = 21.174719\dots \approx 21.17$
- Mean Absolute Error $\approx 3.081$ cm (reported as $3.1$ cm)
- R-squared score $\approx 0.5362$ (reported as $0.54$)
- Benchmark query at $170.0$ cm: $171.58$ cm (reported as $171.6$ cm)

### Checkpoint 6: Visualization
```python
line_x = np.linspace(df["midparent_cm"].min(), df["midparent_cm"].max(), 100)
line_y = model.predict(pd.DataFrame({"midparent_cm": line_x}))

fig, ax = plt.subplots(figsize=(7, 5))
ax.scatter(X_train, y_train, color="#8e44ad", s=50, alpha=0.8, label="training families")
ax.scatter(X_test, y_test, color="#16a085", s=60, marker="s", label="test families")
ax.plot(line_x, line_y, color="#c0392b", linewidth=2.5, label="trend line")
ax.scatter([170], [example], color="#111111", marker="*", s=220, zorder=5, label="170 cm example")
ax.set_xlabel("Midparent height (cm)")
ax.set_ylabel("Child height (cm)")
ax.set_title("Parent height vs. child height")
ax.legend()
ax.grid(alpha=0.25)
fig.tight_layout()
fig.savefig(OUT / "height_regression.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```

## Key Pedagogical Discussion Points for Mentors

1. **Why is the slope less than 1.0?**
   - The slope of $0.88$ is the mathematical manifestation of *regression to the mean*. Extremely tall parents have children whose heights regress downwards toward the population average; unusually short parents have children whose heights regress upwards.
2. **Why is $R^2 \approx 0.54$ considered good?**
   - In physics or engineering, $R^2 > 0.95$ is expected because physical laws have minimal noise. In human biology, hundreds of genetic alleles, nutrition, childhood illness, sleep, and random developmental variation create noise. An $R^2$ of $0.54$ means parental height explains over half of offspring height variance—a substantial biological effect!
3. **The Medical Disclaimer**
   - Students must articulate that this model does not consider sex differences, puberty timing, endocrine disorders, or clinical growth charts. Deploying such a model in a pediatric clinic would risk missed diagnoses of growth-hormone deficiencies.
