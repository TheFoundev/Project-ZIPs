# Final Project Requirements: How Tall Will You Be?

## Project Objective
Reproduce the complete **Height Predictor** machine learning workflow from scratch following `main.py` precisely. Your script must ingest biological family height data, perform feature engineering to compute midparent stature, partition the data reproducibly, train a linear regression model, evaluate error and goodness-of-fit, predict stature for a benchmark test family, and render both visual and textual artifacts. Finally, you will provide an analytical report explaining regression to the mean and why this model is strictly an educational tool.

## Functional Requirements

### 1. Environment and Non-Interactive Backend Setup
- Configure matplotlib to use the headless `"Agg"` backend prior to importing `matplotlib.pyplot`.
- Import `Path` from `pathlib`, `numpy`, `pandas`, `matplotlib.pyplot`, and scikit-learn modules: `LinearRegression`, `mean_absolute_error`, `r2_score`, `train_test_split`.
- Construct `BASE`, `DATA`, and `OUT` path objects using `Path(__file__).resolve().parent`.
- Create the `outputs/` directory dynamically using `OUT.mkdir(exist_ok=True)`.

### 2. Data Loading & Feature Engineering
- Load `data/heights.csv` using `pd.read_csv()`.
- Validate that the raw dataset contains 60 rows and 3 columns: `mother_cm`, `father_cm`, `child_cm`.
- Engineer the derived feature:
  `df["midparent_cm"] = (df["mother_cm"] + df["father_cm"]) / 2`
- Verify that `midparent_cm` represents the mathematical average of both parental statures.

### 3. Feature and Target Matrix Preparation
- Separate features: create `X = df[["midparent_cm"]]` as a 2D pandas DataFrame (double brackets).
- Separate target: create `y = df["child_cm"]` as a 1D pandas Series (single brackets).
- Ensure `X.shape` is `(60, 1)` and `y.shape` is `(60,)`.

### 4. Deterministic Train/Test Splitting
- Split data using `train_test_split(X, y, test_size=0.25, random_state=42)`.
- Confirm shapes: `X_train` has 45 rows, and `X_test` has 15 rows.

### 5. Model Training & Parameter Extraction
- Instantiate `model = LinearRegression()`.
- Fit the model strictly on `X_train` and `y_train` (`model.fit(X_train, y_train)`).
- Extract the slope: `slope = float(model.coef_[0])`.
- Extract the intercept: `intercept = float(model.intercept_)`.
- Confirm slope is approximately $0.88$ (less than $1.0$) and intercept is approximately $21.17$ cm.

### 6. Model Evaluation
- Generate predictions on the test set: `predictions = model.predict(X_test)`.
- Compute Mean Absolute Error: `mae = mean_absolute_error(y_test, predictions)` (expected $\approx 3.1$ cm).
- Compute $R^2$ score: `r2 = r2_score(y_test, predictions)` (expected $\approx 0.54$).

### 7. Benchmark Out-of-Sample Prediction
- Create a query DataFrame for parents with average stature 170.0 cm:
  `query = pd.DataFrame({"midparent_cm": [170.0]})`
- Predict expected child stature: `example = float(model.predict(query)[0])` (expected $\approx 171.6$ cm).

### 8. Console Reporting
- Print a formatted banner and model metrics matching `main.py`:
  - Learned equation: `child height = {slope:.2f} x midparent height + {intercept:.2f}`
  - MAE formatted to 1 decimal place (`{mae:.1f} cm`)
  - R-squared formatted to 2 decimal places (`{r2:.2f}`)
  - Benchmark prediction formatted to 1 decimal place (`{example:.1f} cm`)
  - Medical disclaimer reminder: `"Remember: nutrition, health, sleep, and chance also matter."`

### 9. Multi-Layer Visualization Plot
- Generate a figure using `fig, ax = plt.subplots(figsize=(7, 5))`.
- Plot training families as purple scatter dots (`color="#8e44ad"`, `s=50`, `alpha=0.8`, `label="training families"`).
- Plot test families as teal squares (`color="#16a085"`, `s=60`, `marker="s"`, `label="test families"`).
- Generate a 100-point interpolation line across `midparent_cm` range using `np.linspace` and plot trend line (`color="#c0392b"`, `linewidth=2.5`, `label="trend line"`).
- Plot the 170 cm benchmark prediction as a prominent black star (`color="#111111"`, `marker="*"`, `s=220`, `zorder=5`, `label="170 cm example"`).
- Set axis labels: `Midparent height (cm)` and `Child height (cm)`.
- Set title: `Parent height vs. child height`.
- Add legend and subtle grid (`alpha=0.25`).
- Export figure to `outputs/height_regression.png` with `dpi=150` and `bbox_inches="tight"`.
- Close the figure cleanly using `plt.close(fig)`.

### 10. Metric File Export
- Write `outputs/metrics.txt` containing the equation, MAE, R², and benchmark prediction.

### 11. Student Written Analysis Report
- Submit a written analysis (1 to 2 pages) answering:
  1. What is regression to the mean and how does the learned slope ($0.88 < 1.0$) demonstrate it?
  2. Why is $R^2 \approx 0.54$ normal and expected for biological height data, whereas physical or synthetic problems often exceed $0.90$?
  3. Why must this model never be used as a medical diagnosis or growth hormone decision tool?
