# How Tall Will You Be? (Height Predictor)

## Overview
This project uses **Linear Regression with Feature Engineering** to predict an adult child's height based on the heights of their biological parents. Using the dataset `data/heights.csv` from `beginner-projects-main/AI-ML Beginners/projects/09_height_predictor/`, you will learn how to engineer a combined feature (`midparent_cm`), fit a linear regression line, interpret biological noise (lower $R^2$), and observe the historical phenomenon of **regression to the mean**.

> [!IMPORTANT]
> **Teaching Model Disclaimer:** This is strictly an educational teaching model, NOT a clinical or medical prediction tool. Human height is polygenic, influenced by hundreds of genetic variants and complex environmental factors (nutrition, health, sleep, puberty timing).

## Real-World Use Case
Understanding how parental traits correlate with offspring characteristics is a foundational topic in biostatistics, quantitative genetics, and machine learning feature engineering. It demonstrates how machine learning models can capture meaningful macro trends even when individual data points contain substantial natural variance.

## Features (Implemented)
- Load parental and child height data from CSV (`mother_cm`, `father_cm`, `child_cm`)
- Feature Engineering: calculate `midparent_cm = (mother_cm + father_cm) / 2`
- Split data into training and testing sets (75% train / 25% test)
- Train a `LinearRegression` model using scikit-learn
- Evaluate model performance with Mean Absolute Error (MAE ≈ 3.1 cm) and $R^2$ (≈ 0.54)
- Observe regression to the mean: learned slope < 1.0 (slope ≈ 0.88, intercept ≈ 21.17 cm)
- Run inference for a benchmark family: predict child height for midparent height of 170.0 cm (predicted: 171.6 cm)
- Generate a multi-layered scatter plot showing training families, test families, regression line, and prediction marker
- Save metrics to `outputs/metrics.txt` and visualization to `outputs/height_regression.png`

## Technology Stack
- Python 3.8+
- pandas (Data manipulation and feature engineering)
- numpy (Numeric array operations and grid generation)
- scikit-learn (LinearRegression, train_test_split, MAE, R²)
- matplotlib (Agg non-interactive visualization)

## System Requirements
- Python 3.8 or higher
- pip package installer
- Linux, macOS, or Windows

## Installation Instructions
```bash
cd beginner-projects-main/AI-ML\ Beginners/projects/09_height_predictor
pip install pandas numpy matplotlib scikit-learn
python main.py
```

## Project Structure (Actual)
```
09_height_predictor/
├── main.py
├── data/
│   └── heights.csv
└── outputs/
    ├── height_regression.png
    └── metrics.txt
```

## How It Works
1. Loads `data/heights.csv` containing 60 family height records (`mother_cm`, `father_cm`, `child_cm`).
2. Engineers a single input feature: `df["midparent_cm"] = (df["mother_cm"] + df["father_cm"]) / 2`.
3. Defines feature matrix `X = df[["midparent_cm"]]` (2D) and target vector `y = df["child_cm"]` (1D).
4. Splits families into train and test sets using `train_test_split(X, y, test_size=0.25, random_state=42)` (45 train, 15 test).
5. Fits `LinearRegression()` on the training set to estimate slope and intercept.
6. Evaluates predictions on the test set using MAE and $R^2$.
7. Predicts child height for a midparent height of 170.0 cm.
8. Produces `outputs/height_regression.png` visualizing train/test scatter and trend line, and writes `outputs/metrics.txt`.

## Expected Output
```
============================================================
HOW TALL WILL YOU BE?
============================================================
Model: child height = 0.88 x midparent height + 21.17
Mean absolute error: 3.1 cm
R-squared: 0.54
Prediction for midparent height 170 cm: 171.6 cm

Remember: nutrition, health, sleep, and chance also matter.

Saved: outputs/height_regression.png, outputs/metrics.txt
Try this: add mother and father as separate features and compare.
```

## Security & Ethics Considerations
- **No Private Healthcare Data:** The dataset contains synthetic/anonymized height observations in centimeters.
- **Ethical Boundary:** Do not use this model to make medical or growth-hormone decisions.
- **Local Execution:** Operates entirely locally with no network calls or external credential requirements.

## Troubleshooting
- Missing libraries: `pip install pandas numpy matplotlib scikit-learn`
- FileNotFoundError: verify execution from within `09_height_predictor` or ensure `Path(__file__).resolve().parent` resolves correctly.
- Display errors: matplotlib uses the `"Agg"` non-interactive backend, allowing safe execution in headless server environments.
