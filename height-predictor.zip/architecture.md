# Architecture

## Pipeline (from main.py)
1. **Environment Setup & Headless Configuration**
   - Configures `matplotlib.use("Agg")` prior to importing `pyplot` to allow headless chart generation.
   - Leverages `pathlib.Path` to anchor paths relative to `__file__`.
   - Creates the `outputs/` folder safely with `exist_ok=True`.

2. **Data Ingestion**
   - Reads `data/heights.csv` (60 rows) with headers `mother_cm`, `father_cm`, `child_cm`.

3. **Feature Engineering**
   - Computes derived feature: `df["midparent_cm"] = (df["mother_cm"] + df["father_cm"]) / 2`.
   - Compresses two independent biological signals into one representative parental stature index.

4. **Matrix Structuring**
   - Isolates feature matrix `X = df[["midparent_cm"]]` as a 2D pandas DataFrame.
   - Isolates target vector `y = df["child_cm"]` as a 1D pandas Series.

5. **Train / Test Partitioning**
   - Uses `train_test_split(X, y, test_size=0.25, random_state=42)`.
   - Yields 45 training families and 15 test families.

6. **Model Estimation (OLS Regression)**
   - Fits `LinearRegression()` on `X_train` and `y_train`.
   - Extracts slope $\beta_1 = 0.8847$ and intercept $\beta_0 = 21.1747$.

7. **Evaluation**
   - Computes predictions on `X_test`.
   - Evaluates Mean Absolute Error (MAE $\approx 3.1$ cm) and coefficient of determination ($R^2 \approx 0.54$).

8. **Inference Execution**
   - Queries model with `pd.DataFrame({"midparent_cm": [170.0]})`.
   - Obtains predicted height: $171.58$ cm (rounded to $171.6$ cm).

9. **Multi-Layer Visualization**
   - Plots training scatter points (purple circles: `#8e44ad`).
   - Plots test scatter points (teal squares: `#16a085`).
   - Generates 100 interpolation points via `np.linspace` to draw red trend line (`#c0392b`).
   - Highlights benchmark query at 170 cm with a large dark star marker (`#111111`, `zorder=5`).

10. **Persistence & Reporting**
    - Exports figure to `outputs/height_regression.png` at 150 DPI.
    - Writes metrics report to `outputs/metrics.txt`.

## Key Components
- **Data Source**: 60 biological family records with mother, father, and adult child heights.
- **Engineered Feature**: Midparent height representing combined parental genetics.
- **Model Engine**: Ordinary Least Squares (scikit-learn `LinearRegression`).
- **Core Phenomena**: Biological noise ($R^2 \approx 0.54$) and regression to the mean (slope $< 1.0$).
- **Artifacts**: Console report, PNG plot, and TXT metrics file.

## Data Flow Diagram
```
heights.csv (mother_cm, father_cm, child_cm)
      │
      ▼
Feature Engineering: midparent_cm = (mother_cm + father_cm) / 2
      │
      ▼
Feature Extraction: X (midparent_cm) [2D], y (child_cm) [1D]
      │
      ▼
train_test_split (75% train / 25% test, random_state=42)
      │
      ├───► X_train, y_train ──► LinearRegression.fit() ──► Model Parameters (Slope: 0.88, Intercept: 21.17)
      │                                                           │
      └───► X_test, y_test ────► model.predict() ─────────► Evaluation (MAE: 3.1 cm, R²: 0.54)
                                                                  │
pd.DataFrame({"midparent_cm": [170.0]}) ─► model.predict() ──────► Benchmark Prediction (171.6 cm)
                                                                  │
                                                                  ▼
Outputs: outputs/height_regression.png & outputs/metrics.txt
```
