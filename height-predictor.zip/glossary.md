# Glossary

| Term | Definition |
|---|---|
| **Linear Regression** | A supervised learning algorithm that models the linear relationship between one or more independent features and a continuous target variable. |
| **Feature Engineering** | The process of using domain knowledge to transform, combine, or create new input features from raw data to improve machine learning model performance. |
| **Midparent Height** | The arithmetic mean of the mother's and father's heights (`(mother_cm + father_cm) / 2`), introduced by Francis Galton to summarize parental stature. |
| **Regression to the Mean** | The statistical tendency for extreme parental traits to be followed by offspring traits that are closer to the overall population average (manifested as slope < 1.0). |
| **Biological Noise** | Natural variability and unaccounted factors (such as polygenic inheritance, nutrition, and epigenetics) that prevent deterministic predictions in living organisms. |
| **Feature (X)** | The input variable(s) provided to a machine learning model to generate a prediction (in this project, `midparent_cm`). |
| **Target (y)** | The ground-truth output quantity that the model learns to predict (in this project, adult `child_cm`). |
| **Train/Test Split** | The methodology of dividing a dataset into a training subset (used for fitting) and an unseen testing subset (used to evaluate generalization). |
| **Slope (coef_)** | The rate of change in the target variable per unit change in the feature (in this project, approximately $0.88$ cm of child height per $1$ cm of midparent height). |
| **Intercept (intercept_)** | The expected value of the target when the feature is zero (in this project, approximately $21.17$ cm). |
| **Mean Absolute Error (MAE)** | The average magnitude of absolute prediction errors across test samples, expressed in the same physical units as the target variable (here, centimeters). |
| **R-squared ($R^2$)** | The coefficient of determination, measuring the proportion of variance in the target variable explained by the model (here, $\approx 0.54$). |
| **Teaching Model** | A simplified, illustrative model designed to demonstrate educational statistical principles rather than provide real-world medical or diagnostic utility. |
| **Agg Backend** | A non-interactive matplotlib backend that renders image files directly to disk without requiring a graphical display server. |
| **Random State** | A pseudo-random number generator seed that ensures reproducible dataset splits and consistent model evaluation across different runs. |
