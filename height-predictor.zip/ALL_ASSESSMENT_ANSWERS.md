# All Correct Answers for Assessments
Project: How Tall Will You Be?
---

## Module 01: Project Overview & Historical Origins of Regression
**q1-01.** In the Height Predictor project, what is the machine learning task type and what is the target variable?
   **Correct Answer:** b. Supervised regression predicting adult child height in centimeters
   *Explanation:* The project uses labeled historical data (parental and child heights) to predict a continuous numeric measurement (height in centimeters). This precisely defines supervised regression.

**q1-02.** Why does main.py explicitly state that this is a 'teaching model, not a medical prediction'?
   **Correct Answer:** c. Because clinical pediatric evaluation requires bone age, sex adjustments, hormone tests, and large growth standards that simple 60-row regression models omit
   *Explanation:* Clinical growth evaluation in medicine requires comprehensive multi-factorial assessments including radiographic bone age, longitudinal standardized growth curves, endocrinological hormone panels, and sex adjustments. A simple 60-family educational regression model lacks these diagnostic capabilities.

**q1-03.** Who first coined the statistical term 'regression' in his 1886 study of family stature?
   **Correct Answer:** b. Sir Francis Galton
   *Explanation:* Sir Francis Galton coined the term 'regression' in his 1886 paper 'Regression Towards Mediocrity in Hereditary Stature' when analyzing how human stature passes between generations.

**q1-04.** What does the statistical phenomenon 'regression to the mean' describe in the context of human stature?
   **Correct Answer:** b. Extreme parental traits tend to be followed by offspring traits that are closer to the population average
   *Explanation:* Regression to the mean describes how offspring of parents with extreme traits (very tall or very short) tend to have traits closer to the population average than their parents.

**q1-05.** In the learned linear regression model equation (child = 0.88 * midparent + 21.17), what mathematical feature directly indicates regression to the mean?
   **Correct Answer:** b. The slope (0.88) is strictly less than 1.0
   *Explanation:* A regression slope of 0.88 (< 1.0) means that for every 1 cm a parent deviates from average, the child only deviates by 0.88 cm, pulling offspring predictions closer to the mean.

**q1-06.** How is the engineered feature 'midparent_cm' defined in main.py?
   **Correct Answer:** b. (df['mother_cm'] + df['father_cm']) / 2
   *Explanation:* In main.py line 30, the midparent height is computed as the arithmetic average of maternal and paternal statures: df['midparent_cm'] = (df['mother_cm'] + df['father_cm']) / 2.

**q1-07.** What is a primary advantage of engineering 'midparent_cm' rather than keeping mother and father heights separate in this introductory project?
   **Correct Answer:** b. It synthesizes parental genetics into a single dimension, simplifying visualization of trend lines and regression to the mean
   *Explanation:* Combining two parent features into a single midparent metric reduces feature dimensionality to 1D, enabling intuitive 2D scatter and line plots while avoiding multi-collinearity.

**q1-08.** Why must feature matrix X be constructed as df[['midparent_cm']] with double brackets?
   **Correct Answer:** b. Double brackets create a 2D DataFrame of shape (N, 1) expected by scikit-learn estimators
   *Explanation:* Scikit-learn estimators mandate that the feature matrix X have a 2-dimensional shape (n_samples, n_features). Using double brackets df[['midparent_cm']] returns a 2D DataFrame of shape (60, 1).

**q1-09.** In a dataset of 60 families, what is the training and testing sample allocation when using test_size=0.25?
   **Correct Answer:** b. 45 training families and 15 testing families
   *Explanation:* With 60 total rows and test_size=0.25, 25% of 60 is exactly 15 rows for testing, leaving 60 - 15 = 45 rows for training.

**q1-10.** If a future model iteration resulted in a slope of 1.25 between midparent height and child height, what would this imply biologically and statistically?
   **Correct Answer:** b. Divergence away from the mean, where children of tall parents become progressively taller and children of short parents become progressively shorter over generations
   *Explanation:* A regression slope greater than 1.0 (such as 1.25) implies that children deviate from the population average even more than their parents, creating evolutionary divergence into extreme statures.


## Module 02: Data & Feature Engineering
**q2-01.** What are the three column names in the raw data/heights.csv file?
   **Correct Answer:** b. mother_cm, father_cm, child_cm
   *Explanation:* The raw heights.csv header row contains exactly mother_cm, father_cm, and child_cm, representing maternal, paternal, and offspring heights in metric centimeters.

**q2-02.** How many total family observations (rows) are in data/heights.csv?
   **Correct Answer:** b. 60
   *Explanation:* The dataset contains exactly 60 data rows corresponding to 60 distinct family records, plus 1 header row (total 61 lines in the file).

**q2-03.** What physical unit of measurement is used for heights in this dataset?
   **Correct Answer:** c. Centimeters
   *Explanation:* All column names explicitly include the suffix _cm (mother_cm, father_cm, child_cm), indicating that heights are recorded in centimeters.

**q2-04.** What is 'feature engineering' in machine learning?
   **Correct Answer:** b. The process of creating, combining, or transforming raw input variables into more informative representations using domain knowledge
   *Explanation:* Feature engineering is the process of using domain knowledge to create new derived features or combine existing variables to improve machine learning model performance and interpretability.

**q2-05.** Why do we combine mother_cm and father_cm into midparent_cm instead of using only the father's height?
   **Correct Answer:** b. Because children inherit approximately 50% of autosomal genetics from each parent, so both contribute to height potential
   *Explanation:* Offspring inherit 50% of their autosomal genetic makeup from each biological parent. Combining both parents into an average captures this shared biological inheritance.

**q2-06.** If a student mistakenly writes `df['midparent_cm'] = df['mother_cm'] + df['father_cm'] / 2`, what will happen?
   **Correct Answer:** b. Division executes first due to operator precedence, producing absurdly large numbers around 250 cm
   *Explanation:* In Python, division has higher precedence than addition. Without parentheses, father_cm is divided by 2 first, and then added to mother_cm, creating invalid heights around 250 cm.

**q2-07.** What is the result of computing midparent_cm for a family where the mother is 162.0 cm and the father is 182.0 cm?
   **Correct Answer:** b. 172.0 cm
   *Explanation:* Computing the unweighted average: (162.0 + 182.0) / 2 = 344.0 / 2 = 172.0 cm.

**q2-08.** Why is vectorized pandas series arithmetic preferred over iterating with a Python 'for' loop?
   **Correct Answer:** b. Vectorized operations run optimized compiled C/NumPy code across memory blocks, making them significantly faster and more concise
   *Explanation:* Vectorized operations leverage pre-compiled C and SIMD instructions under NumPy and pandas, processing arrays in contiguous memory blocks orders of magnitude faster than Python bytecode loops.

**q2-09.** Why is the standard deviation of midparent_cm (~3.71 cm) noticeably smaller than the standard deviations of mother_cm (~4.92 cm) and father_cm (~5.15 cm)?
   **Correct Answer:** b. Because taking the arithmetic average of two random variables reduces overall statistical variance (dispersion)
   *Explanation:* Averaging two random variables reduces overall variance because the random fluctuations of the two individual variables partially cancel each other out: Var((X+Y)/2) < Var(X).

**q2-10.** In exploratory data analysis, the correlation between midparent_cm and child_cm is approximately 0.73, whereas individual parent correlations are approximately 0.54. What does this demonstrate?
   **Correct Answer:** b. That combining both parental measurements captures more shared genetic variance, creating a stronger linear predictor than either parent alone
   *Explanation:* The Pearson correlation rises from 0.54 for single parents to 0.73 for the midparent because combining both parents captures the joint genetic baseline while smoothing individual variation.


## Module 03: Linear Regression on Noisy Biological Data
**q3-01.** Why do biological traits like human height exhibit natural scatter (noise) around a regression line?
   **Correct Answer:** b. Because human height is polygenic and influenced by nutrition, health, sleep, and random genetic assortment
   *Explanation:* Human height is a classic polygenic trait influenced by thousands of genetic loci along with non-genetic variables like childhood diet, sleep habits, illness, and random developmental assortment.

**q3-02.** What is the approximate R-squared (R²) score achieved by the Height Predictor model on the test dataset?
   **Correct Answer:** b. 0.54
   *Explanation:* The Height Predictor script calculates r2_score on the test set, outputting approximately 0.54 (specifically 0.5362 rounded to two decimal places).

**q3-03.** What does an R-squared score of 0.54 signify in the context of this project?
   **Correct Answer:** b. Approximately 54% of the variance in adult child height is explained by parental midparent height
   *Explanation:* R-squared measures the proportion of variance in the dependent variable explained by the independent feature. An R² of 0.54 means 54% of offspring height variation is accounted for by midparent stature.

**q3-04.** Why is an R² of approximately 0.54 considered a strong and respectable result in human genetics?
   **Correct Answer:** b. Because explaining over half the variance in a complex polygenic trait using a single predictor is a substantial biological effect
   *Explanation:* In quantitative genetics, human height is polygenic and subject to environmental diversity. Explaining 54% of variance with a single composite variable represents a massive biological heritability signal.

**q3-05.** What is the learned slope in main.py, and what does its magnitude indicate?
   **Correct Answer:** b. Slope = 0.88, indicating regression to the mean because it is less than 1.0
   *Explanation:* The learned slope in main.py is approximately 0.88 (specifically 0.8847). Because 0.88 is strictly less than 1.0, extreme parental deviations are compressed, embodying regression to the mean.

**q3-06.** What vital mathematical role does the positive intercept (+21.17 cm) play in the model equation (child = 0.88 * midparent + 21.17)?
   **Correct Answer:** b. It provides a baseline upward shift that prevents offspring heights from collapsing downward under a slope < 1.0
   *Explanation:* Because the slope of 0.88 compresses inputs, a positive intercept (+21.17 cm) shifts the regression line upward, ensuring that children of shorter parents regress upward toward the population mean.

**q3-07.** Why did the Lemonade Stand Fortune Teller achieve an R² of ~0.90 while the Height Predictor achieved an R² of ~0.54?
   **Correct Answer:** b. Lemonade sales have a direct physical relationship with temperature with minimal unmeasured noise, whereas height is governed by thousands of genetic and environmental variables
   *Explanation:* Lemonade sales are driven by direct physical thermodynamics and thirst during summer days, producing clean trends. Height is governed by complex polygenic assortment and lifestyle factors, creating natural biological noise.

**q3-08.** How does the feature input used in the Height Predictor differ from that in the Lemonade Stand project?
   **Correct Answer:** b. Height Predictor used an engineered composite feature (midparent_cm); Lemonade Stand used a single raw feature (temperature_c)
   *Explanation:* The Height Predictor explicitly engineers midparent_cm from mother_cm and father_cm before training, whereas Lemonade Stand directly consumed the single raw column temperature_c.

**q3-09.** If a machine learning practitioner evaluates model quality solely by requiring R² > 0.90 across all projects, what error are they committing?
   **Correct Answer:** b. They are ignoring domain-specific variance, wrongly dismissing valid, high-impact models in noisy domains like biology and social sciences
   *Explanation:* Requiring R² > 0.90 universally ignores that natural systems (biology, economics, psychology) have irreducible natural noise. Dismissing an R² of 0.54 in genetics discards valuable, scientifically rigorous insights.

**q3-10.** Mathematically, at what midparent height would the model predict a child to have the EXACT same height as their midparent stature (the crossover point)?
   **Correct Answer:** b. Approximately 183.6 cm (solving x = 0.8847x + 21.1747)
   *Explanation:* Setting child = midparent = x gives x = 0.8847x + 21.1747, which simplifies to (1 - 0.8847)x = 21.1747, yielding x = 21.1747 / 0.1153 ≈ 183.6 cm.


## Module 04: Model Training & Prediction
**q4-01.** In scikit-learn, why does X_train have shape (45, 1) while y_train has shape (45,)?
   **Correct Answer:** b. Estimators require feature matrix X to be 2-dimensional (samples, features), while target y is a 1-dimensional array of scalar outcomes
   *Explanation:* Scikit-learn estimators mandate that input features have a 2-dimensional shape (n_samples, n_features) to support multiple features, while target y is 1-dimensional (n_samples,) representing a single target quantity per sample.

**q4-02.** What does setting `random_state=42` achieve in train_test_split?
   **Correct Answer:** b. It guarantees that the random data partitioning is deterministic and reproducible across different executions
   *Explanation:* Setting random_state to a fixed integer (such as 42) initializes the pseudo-random number generator, ensuring that the train/test partitioning produces the identical set of indices on every execution run.

**q4-03.** What mathematical criterion does scikit-learn's LinearRegression minimize when fitting the model?
   **Correct Answer:** b. The sum of squared residuals (differences between actual and predicted target values)
   *Explanation:* Ordinary Least Squares (OLS) regression analytically minimizes the Sum of Squared Residuals (SSR), which is the sum of squared differences between actual y values and predicted values along the line.

**q4-04.** Why must model.fit() be called exclusively on (X_train, y_train) rather than the entire dataset (X, y)?
   **Correct Answer:** b. To prevent data leakage, ensuring that the model is evaluated on unseen families it was not trained on
   *Explanation:* Fitting exclusively on the training partition prevents data leakage, allowing the held-out test partition to provide an honest, unbiased evaluation of how the model generalizes to new families.

**q4-05.** How do you correctly access the learned slope of the single feature in a fitted LinearRegression model?
   **Correct Answer:** b. float(model.coef_[0])
   *Explanation:* In scikit-learn, learned coefficients are stored in model.coef_ as a 1D NumPy array. For a single feature, model.coef_[0] retrieves the slope, and float() converts it to a standard Python scalar.

**q4-06.** What is the physical interpretation of the learned slope (0.88) in this model?
   **Correct Answer:** b. Each additional 1 cm increase in parental midparent height is associated with an expected 0.88 cm increase in child height
   *Explanation:* The slope of 0.88 represents the rate of change in the target per unit change in the feature: each additional 1 cm in midparent stature is associated with an expected 0.88 cm increase in adult child height.

**q4-07.** Why is the intercept (+21.17 cm) considered a mathematical anchor rather than a biological reality?
   **Correct Answer:** a. Because adult humans cannot have a midparent height of 0 cm, so evaluating the line at x=0 is a pure mathematical extrapolation
   *Explanation:* Adult humans cannot measure 0 cm, so evaluating the regression line at x=0 is a mathematical extrapolation. The intercept acts as an algebraic baseline anchor to position the line within the realistic biological domain.

**q4-08.** In main.py, what is the predicted adult child height for parents with a midparent height of 170.0 cm?
   **Correct Answer:** c. 171.6 cm
   *Explanation:* Plugging 170.0 cm into the learned equation: 0.884705 * 170.0 + 21.1747 = 150.3998 + 21.1747 = 171.5745 cm, which rounds to exactly 171.6 cm.

**q4-09.** What happens if a student attempts inference by writing `model.predict(170.0)` with a bare scalar float?
   **Correct Answer:** b. Scikit-learn raises a ValueError stating that a 2D array was expected but a scalar was provided
   *Explanation:* Scikit-learn's predict() method strictly expects a 2D array-like input of shape (n_samples, n_features). Passing a bare scalar float raises a ValueError with an explicit error message.

**q4-10.** Why does a midparent height of 170.0 cm result in a predicted child height of 171.6 cm (taller than parents), whereas a midparent height of 188.0 cm results in a predicted child height of ~187.5 cm (shorter than parents)?
   **Correct Answer:** b. Because the regression line has a slope < 1.0 combined with a positive intercept, pulling predictions from both directions toward the population mean
   *Explanation:* Because the slope is less than 1.0 (0.88) and the intercept is positive (+21.17 cm), predictions for below-average parents shift upward and predictions for above-average parents shift downward toward the population center.


## Module 05: Evaluation & Visualization
**q5-01.** What does Mean Absolute Error (MAE) measure in a regression model?
   **Correct Answer:** b. The average magnitude of errors between predicted values and actual values, expressed in the target variable's physical units
   *Explanation:* Mean Absolute Error calculates the average absolute magnitude of prediction errors: (1/N) * sum(|y_true - y_pred|), maintaining the exact physical units of the target (centimeters).

**q5-02.** What is the Mean Absolute Error (MAE) reported by main.py on the test families?
   **Correct Answer:** b. 3.1 cm
   *Explanation:* In main.py line 52, the Mean Absolute Error on the test set is formatted to one decimal place as 3.1 cm (raw calculated value is 3.0810 cm).

**q5-03.** What two output files are created in the outputs/ directory when running main.py?
   **Correct Answer:** b. height_regression.png and metrics.txt
   *Explanation:* In main.py lines 71 and 74, outputs are explicitly saved to outputs/height_regression.png (visualization) and outputs/metrics.txt (text metrics summary).

**q5-04.** Why is MAE often easier to explain to non-technical stakeholders than Mean Squared Error (MSE)?
   **Correct Answer:** b. Because MAE is expressed in the same physical units as the original data (e.g. centimeters) rather than squared units (centimeters squared)
   *Explanation:* MAE preserves the original physical measurement units (centimeters), making it directly intuitive. In contrast, MSE produces squared units (cm²), which have no direct intuitive physical meaning.

**q5-05.** If training R² is 0.534 and testing R² is 0.536, what does this demonstrate about the model?
   **Correct Answer:** b. The model generalizes exceptionally well to unseen data with no signs of overfitting
   *Explanation:* When training R² (~0.534) and testing R² (~0.536) are almost identical, it proves that the model generalizes robustly to unseen data without overfitting or memorizing training quirks.

**q5-06.** Why does main.py call `matplotlib.use('Agg')` before importing `pyplot`?
   **Correct Answer:** b. To configure a non-interactive backend that generates image files cleanly in headless environments without requiring a GUI display server
   *Explanation:* The Agg backend is a non-interactive raster renderer that outputs images directly to files in memory, preventing crashes on headless Linux servers or CI/CD pipelines lacking a desktop display.

**q5-07.** In main.py, how is the smooth regression line generated across the plot?
   **Correct Answer:** b. By generating 100 evenly spaced points with np.linspace across midparent range and predicting heights along that grid
   *Explanation:* In main.py line 57, np.linspace generates 100 points across the range of midparent_cm, and line 58 predicts heights along that grid, creating a continuous smooth trend line.

**q5-08.** What visual marker and styling is used in main.py to highlight the 170 cm benchmark prediction on the scatter plot?
   **Correct Answer:** b. A large dark star marker (color='#111111', marker='*', s=220) with zorder=5
   *Explanation:* In main.py line 64, ax.scatter([170], [example], color='#111111', marker='*', s=220, zorder=5) plots a prominent black star of size 220 at the 170 cm prediction point.

**q5-09.** Why is `zorder=5` specified when plotting the 170 cm prediction star marker?
   **Correct Answer:** b. To ensure the star is rendered on a higher drawing layer so it is never hidden beneath scatter points or lines
   *Explanation:* The zorder parameter specifies the drawing order (depth layer) of graphical artists. Setting zorder=5 ensures the prediction star is drawn on top of scatter points (zorder=2) and lines (zorder=2.5).

**q5-10.** Why is calling `plt.close(fig)` considered essential after executing `fig.savefig(...)`?
   **Correct Answer:** b. Matplotlib keeps figure canvases in memory until explicitly closed, so calling close() releases memory and prevents leaks
   *Explanation:* Matplotlib retains all figure canvases and artist references in internal state until explicitly closed. In data pipelines, omitting plt.close(fig) causes accumulated memory leaks.


## Module 06: Complete Pipeline, Running & Extensions
**q6-01.** When main.py is executed end-to-end, in what order do the core machine learning pipeline stages execute?
   **Correct Answer:** b. Data loading -> Feature engineering -> Train/test split -> Model fitting -> Evaluation -> Visualization & saving
   *Explanation:* The end-to-end pipeline executes sequentially: loading data from CSV, computing the engineered midparent feature, splitting into 75/25 train and test sets, fitting LinearRegression on training data, evaluating MAE and R² on test data, and finally rendering and persisting plots and metrics.

**q6-02.** What Python construct in main.py ensures that main() executes only when the file is run directly from the command line, rather than when imported as a module?
   **Correct Answer:** b. if __name__ == '__main__':
   *Explanation:* The 'if __name__ == "__main__":' idiom is the standard Python guard that checks whether the script is being executed directly by the interpreter as the top-level program, preventing unintended execution upon import.

**q6-03.** What two specific artifact files are created in the outputs/ directory when main.py executes successfully?
   **Correct Answer:** b. height_regression.png and metrics.txt
   *Explanation:* When main.py completes, it writes outputs/height_regression.png (the 4-layer regression visualization) and outputs/metrics.txt (the formatted text summary of equation and error metrics).

**q6-04.** In the generated scatter plot outputs/height_regression.png, how are the held-out test families visually distinguished from the training families?
   **Correct Answer:** b. Test families are rendered as teal squares (marker='s'), while training families are purple circles
   *Explanation:* In main.py lines 61–62, training families are rendered as purple circles (color='#8e44ad', s=50, alpha=0.8), while held-out test families are rendered as teal squares (color='#16a085', s=60, marker='s').

**q6-05.** Why does outputs/metrics.txt record the model equation and metrics to 4 decimal places (e.g., slope = 0.8847, MAE = 3.0809 cm), while the terminal prints rounded values (e.g., 0.88, 3.1 cm)?
   **Correct Answer:** b. To preserve high-precision numerical fidelity for automated validation and scientific reproducibility while keeping terminal output cognitively simple for humans
   *Explanation:* High-precision logging (4 decimal places) preserves exact numeric values for regression testing, CI/CD audits, and downstream automated checks, while rounded console outputs reduce cognitive load for human operators.

**q6-06.** Which critical physiological factor that creates an average height difference of approximately 13 cm in adult humans is completely absent from main.py's feature matrix?
   **Correct Answer:** b. The biological sex of the child
   *Explanation:* Adult males are on average approximately 13 cm taller than adult females. Because main.py predicts child_cm without knowing the biological sex of the child, this entire source of variation remains unaccounted for in the model residuals.

**q6-07.** Why would deploying main.py as a consumer mobile application to advise parents on pediatric growth hormone treatments violate ethical and medical regulations?
   **Correct Answer:** b. Because clinical pediatric evaluation qualifies as Software as a Medical Device (SaMD) requiring radiographic bone age, hormonal assays, and clinical validation that this 60-family educational model lacks
   *Explanation:* Clinical growth assessment requires specialized diagnostic criteria including radiographic bone age, endocrinological hormone panels, longitudinal growth charts, and SaMD medical certification. A simple 60-family educational script lacks diagnostic validity.

**q6-08.** When extending main.py to use mother_cm and father_cm as separate features (X in R^(60x2)), what mathematical relationship is observed between the two new slope coefficients and the baseline midparent slope (~0.885)?
   **Correct Answer:** b. The sum beta_mother + beta_father approximates the baseline slope (~0.885), with each parent contributing roughly equal weight (~0.43 to ~0.45)
   *Explanation:* Fitting separate features mother_cm and father_cm yields coefficients beta_mother ~ 0.43 and beta_father ~ 0.45. Their sum (~0.885) approximates the single midparent slope, demonstrating that both parents contribute roughly equally.

**q6-09.** If the dataset were expanded to include a binary indicator variable is_male (1 for male, 0 for female) alongside midparent_cm, what geometric and statistical change occurs to the regression model?
   **Correct Answer:** b. The model fits two parallel regression lines separated vertically by the sex coefficient (~ +13 cm), substantially boosting R² by capturing sexual dimorphism
   *Explanation:* A binary indicator feature acts as an intercept shifter. It produces two parallel regression lines (one for females with is_male=0, and one for males with is_male=1 shifted upward by beta_sex ~ 13 cm), explaining dimorphism and significantly improving R².

**q6-10.** Why did the baseline main.py implementation choose an engineered single feature (midparent_cm) over keeping mother_cm and father_cm as two separate features, given that both models achieve virtually identical test MAE (~3.1 cm) and R² (~0.54)?
   **Correct Answer:** b. Because midparent_cm adheres to the principle of parsimony (Occam's razor), captures symmetric genetics, and enables direct 2D scatter and trend line plotting on a Cartesian plane
   *Explanation:* The midparent feature synthesizes two inputs into one based on biological symmetry. It satisfies Occam's razor (achieving the same test MAE and R² with fewer parameters) and uniquely allows clean 2D visualization with a single trend line on a Cartesian graph.

