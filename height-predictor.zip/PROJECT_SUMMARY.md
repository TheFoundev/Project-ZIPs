# How Tall Will You Be? (Height Predictor)

## Overview
This project applies **Linear Regression with Feature Engineering** to biological family data to forecast adult offspring height from maternal and paternal stature. By creating a single synthetic feature—the midparent average—students explore the mathematical concepts first introduced by Sir Francis Galton in 1886: **regression to the mean**.

## Real-World Use Case
In quantitative genetics and anthropometry, parents' traits offer a baseline prediction for offspring attributes. However, because biological systems exhibit natural variation (noise), real-world data rarely yields near-perfect correlation. This project teaches students how to model noisy real-world data where $R^2 \approx 0.54$ is considered informative rather than defective.

## Features (Implemented)
- CSV parsing of 60 multi-generation height records (`data/heights.csv`)
- Pandas vectorized feature engineering: `midparent_cm = (mother_cm + father_cm) / 2`
- Feature matrix $X$ (2D DataFrame) and target vector $y$ (1D Series) extraction
- Deterministic data splitting with `train_test_split(test_size=0.25, random_state=42)`
- Ordinary Least Squares regression fitting via scikit-learn `LinearRegression`
- Mathematical verification of regression to the mean: slope < 1.0 (slope $\approx 0.88$, intercept $\approx 21.17$)
- Performance benchmarking using Mean Absolute Error (MAE $\approx 3.1$ cm) and coefficient of determination ($R^2 \approx 0.54$)
- Out-of-sample query inference: predicting child height for midparent stature of 170.0 cm (output: 171.6 cm)
- Visualization output: high-resolution scatter plot with regression trend line (`outputs/height_regression.png`)
- Metric persistence: structured text summary (`outputs/metrics.txt`)

## Technology Stack
- **Language**: Python 3.8+
- **Data Engineering**: pandas 2.x
- **Numerical Computing**: numpy 1.2x
- **Machine Learning**: scikit-learn 1.x
- **Plotting & Visualization**: matplotlib (headless Agg engine)

## System Requirements
- Operating System: Linux, macOS, or Windows 10/11
- Python Runtime: Python 3.8 to 3.12+
- Disk Space: < 10 MB for code, data, and output artifacts

## Installation Instructions
```bash
cd beginner-projects-main/AI-ML\ Beginners/projects/09_height_predictor
pip install pandas numpy matplotlib scikit-learn
python main.py
```

## Project Structure (Actual)
```
09_height_predictor/
├── main.py
├── data/
│   └── heights.csv
└── outputs/
    ├── height_regression.png
    └── metrics.txt
```

## How It Works
1. **Data Ingestion**: Reads `data/heights.csv` containing `mother_cm`, `father_cm`, and `child_cm`.
2. **Feature Engineering**: Combines maternal and paternal height into an average parental stature:
   $$\text{midparent\_cm} = \frac{\text{mother\_cm} + \text{father\_cm}}{2}$$
3. **Array Formatting**: Constructs 2D feature matrix `X = df[["midparent_cm"]]` and target `y = df["child_cm"]`.
4. **Data Partitioning**: Allocates 75% (45 families) for training and 25% (15 families) for evaluation using random seed 42.
5. **Model Estimation**: Solves normal equations to find slope $\beta_1 = 0.8847$ and intercept $\beta_0 = 21.1747$.
6. **Error Profiling**: Computes MAE ($3.08$ cm) and $R^2$ ($0.536$) on the unseen test set.
7. **Point Prediction**: Feeds `pd.DataFrame({"midparent_cm": [170.0]})` into the model to predict 171.6 cm.
8. **Artifact Generation**: Renders `outputs/height_regression.png` and exports `outputs/metrics.txt`.

## Expected Output
- **Console Summary**:
  ```
  ============================================================
  HOW TALL WILL YOU BE?
  ============================================================
  Model: child height = 0.88 x midparent height + 21.17
  Mean absolute error: 3.1 cm
  R-squared: 0.54
  Prediction for midparent height 170 cm: 171.6 cm

  Remember: nutrition, health, sleep, and chance also matter.

  Saved: outputs/height_regression.png, outputs/metrics.txt
  Try this: add mother and father as separate features and compare.
  ```
- **Visual Artifact**: `outputs/height_regression.png`
- **Text Summary**: `outputs/metrics.txt`

## Security Considerations
- Local processing: No external API keys or remote endpoints.
- Path safety: Pathlib ensures platform-independent directory resolution.
- Ethical boundary: Explicitly disclaimed as a teaching model, preventing misuse as medical advice.

## Troubleshooting
- **ModuleNotFoundError**: Ensure dependencies are installed in the active virtual environment.
- **FileNotFoundError for heights.csv**: Verify you are launching from within the project directory or using script-relative paths.
- **Headless GUI errors**: The script sets `matplotlib.use("Agg")` prior to importing `pyplot`, preventing GUI backend failures in server environments.

## Further Learning
- Polygenic inheritance and genomic risk scores
- Multiple linear regression with distinct `mother_cm` and `father_cm` features
- Sex-adjusted pediatric target height equations (Tanner formulas)
