# Setup Guide

## Step 1: Navigate to the Project Directory
Open your terminal or command prompt and change directory to the project folder:
```bash
cd beginner-projects-main/AI-ML\ Beginners/projects/09_height_predictor
```

## Step 2: Set Up Virtual Environment (Recommended)
Creating an isolated virtual environment prevents library version conflicts:
```bash
python3 -m venv venv
source venv/bin/activate  # On Windows use: venv\Scripts\activate
```

## Step 3: Install Required Dependencies
Install the required packages using `pip`:
```bash
pip install pandas numpy matplotlib scikit-learn
```

Or verify with:
```bash
python -c "import pandas, numpy, matplotlib, sklearn; print('All libraries installed successfully!')"
```

## Step 4: Inspect the Dataset
Verify the presence of `data/heights.csv` and inspect the initial lines:
```bash
head -n 5 data/heights.csv
```
You should observe the three columns: `mother_cm`, `father_cm`, `child_cm`.

## Step 5: Execute the Script
Run the main script:
```bash
python main.py
```

## Step 6: Verify the Generated Outputs
Upon completion, verify that the console logs metrics and that two files are created in the `outputs/` folder:
- `outputs/height_regression.png`: Scatter plot with regression line and benchmark prediction.
- `outputs/metrics.txt`: Text file recording the learned equation, MAE, R², and benchmark query.
