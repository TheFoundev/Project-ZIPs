# Prerequisites

## Skills Required
- **Basic Python Programming**: Variables, arithmetic operations, functions, and imports.
- **Working with Tabular Data**: Understanding rows, columns, and reading CSV files.
- **Basic Mathematical Literacy**: Concept of an arithmetic mean (average), Cartesian coordinates ($x, y$), and the equation of a straight line ($y = mx + c$).
- **Command Line Navigation**: Changing directories and executing Python scripts.

## Tools Required
- **Python Runtime**: Python 3.8 or higher.
- **Package Manager**: `pip`.
- **Code Editor / IDE**: VS Code, PyCharm, or any standard text editor.

## Python Packages Required
- `pandas` (for CSV handling and feature engineering)
- `numpy` (for numerical linear interpolation)
- `scikit-learn` (for LinearRegression, train_test_split, MAE, and R²)
- `matplotlib` (for non-interactive figure rendering)

## Knowledge to Review Before Starting
- What is a feature (independent variable) vs a target (dependent variable)?
- Why do we split data into training and test sets?
- What does an average (arithmetic mean) represent?
- Why do biological measurements have natural spread and noise?
