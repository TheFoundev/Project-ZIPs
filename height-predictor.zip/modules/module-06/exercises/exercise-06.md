# Module 6 Exercises: Complete Pipeline, Running & Extensions

## Exercise 6.1: End-to-End Pipeline Execution & Artifact Verification (10 min)
**Objective:** Execute `main.py` from the command line, verify the creation of output artifacts, and validate the console logging output.
**Problem Statement:** You have been provided with the complete `main.py` script. You must run the script end-to-end and write a Python verification snippet that confirms both `outputs/height_regression.png` and `outputs/metrics.txt` exist, are non-empty, and contain the expected metrics.

**Requirements:**
1. Execute `python main.py` in your terminal.
2. Confirm the printed console output contains the equation, MAE, $R^2$, benchmark prediction, and ethical reminders.
3. Write a small Python script using `pathlib.Path` to assert that:
   - `outputs/height_regression.png` exists and its file size exceeds 20 KB.
   - `outputs/metrics.txt` exists and contains four lines.
4. Verify that the script executes cleanly without any uncaught exceptions or GUI warning errors.

**Constraints:** Use standard Python and `pathlib.Path`.

**Expected Behaviour:** Terminal execution logs followed by successful automated assertion of artifact existence and file sizes.

**Acceptance Criteria:**
- [ ] `main.py` executes successfully to completion with exit code 0.
- [ ] Console logs match expected values (slope ~0.88, intercept ~21.17, MAE ~3.1 cm, R² ~0.54).
- [ ] `outputs/height_regression.png` is generated and confirmed non-empty (>20 KB).
- [ ] `outputs/metrics.txt` is generated with 4 lines of text.

**Hints:**
- Use `Path("outputs/height_regression.png").stat().st_size` to check byte size.
- Use `with open("outputs/metrics.txt") as f: lines = f.readlines()`.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes  

---

## Exercise 6.2: Output Artifact Inspection & Metric Auditing (15 min)
**Objective:** Programmatically audit `outputs/metrics.txt` and verify consistency with the model's test predictions.
**Problem Statement:** As a data engineer auditing model artifacts, you need to read the generated `outputs/metrics.txt`, extract the linear equation parameters, and verify that evaluating the formula at $170.0$ cm mathematically equals the recorded prediction.

**Requirements:**
1. Open and parse `outputs/metrics.txt`.
2. Extract the slope ($0.8847$) and intercept ($21.1747$) from the first line using string parsing or regular expressions.
3. Compute the predicted height for midparent stature $170.0$ cm:
   $$\hat{y}_{170} = \text{slope} \times 170.0 + \text{intercept}$$
4. Compare your calculated result with the value recorded on line 4 of `metrics.txt` (`171.58 cm`) using `abs(calculated - recorded) < 0.01`.
5. Extract the recorded MAE and $R^2$ values and verify they match expectations ($3.0809$ cm and $0.5360$).

**Constraints:** Perform parsing in Python without modifying `metrics.txt`.

**Expected Behaviour:** A Python script prints the parsed equation, step-by-step arithmetic verification, and an audit confirmation message: `AUDIT PASSED: Metric consistency confirmed.`

**Acceptance Criteria:**
- [ ] Parses slope, intercept, MAE, R², and benchmark prediction cleanly from `metrics.txt`.
- [ ] Calculates $\hat{y}_{170} = 0.8847 \times 170.0 + 21.1747 = 171.5737 \approx 171.58$ cm.
- [ ] Confirms calculated prediction matches persisted benchmark prediction within 0.01 cm.
- [ ] Confirms high-precision MAE (3.0809 cm) and R² (0.5360) are preserved.

**Hints:**
- Look at line splitting: `line.split(":")[1].strip()`.
- Use `float()` to convert parsed string numbers into numeric floats.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 6.3: Ethical Boundary Memo: SaMD vs. Educational Models (10 min)
**Objective:** Compose a professional data ethics review evaluating why the Height Predictor cannot be used in clinical pediatrics.
**Problem Statement:** A healthcare technology company wants to integrate `main.py` into a consumer health app that advises parents on whether their child needs hormone therapy. You must write an ethical and regulatory review rejecting this proposal.

**Requirements:**
1. Cite the explicit disclaimer from `main.py` lines 6–8 and line 55.
2. Identify at least four critical clinical diagnostic inputs used in pediatric endocrinology that are absent from `main.py` (e.g., bone age radiographs, Tanner pubertal staging, sex adjustment, hormonal assays).
3. Explain why the model's omission of the child's biological sex creates severe systematic prediction bias.
4. Explain the legal regulatory classification of Software as a Medical Device (SaMD) and the consequences of deploying uncertified algorithms for diagnostic purposes.

**Constraints:** Base your analysis on medical growth standards and machine learning ethics principles covered in Lesson 03.

**Expected Behaviour:** A structured 3-to-4 paragraph technical memo clearly establishing the clinical, biological, and legal boundaries.

**Acceptance Criteria:**
- [ ] Quotes or references `main.py` lines 6–8 and line 55.
- [ ] Identifies 4+ clinical pediatric factors (bone age, Tanner staging, hormonal panels, sex-adjusted target height).
- [ ] Notes that human sexual dimorphism (~13 cm) causes systematic error when sex is omitted.
- [ ] Defines SaMD regulatory standards and consequences of non-compliance.

**Hints:**
- Recall Tanner's target height formula: boys are adjusted by $+13$ cm (or mother $+13$), girls by $-13$ cm (or father $-13$).
- Consider what could happen if parents panic due to an inaccurate prediction.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes  

---

## Exercise 6.4: Implementing the Separate Parents Extension (20 min)
**Objective:** Implement the extension suggested in `main.py` line 80 by fitting multiple linear regression on separate maternal and paternal features.
**Problem Statement:** Extend the Height Predictor pipeline to use both `mother_cm` and `father_cm` as independent input features ($X \in \mathbb{R}^{60 \times 2}$), train a scikit-learn `LinearRegression` model, extract both slope coefficients, and compare performance with the baseline midparent model.

**Requirements:**
1. Load `data/heights.csv` using pandas.
2. Define the multi-feature matrix $X = \text{df}[[\text{"mother\_cm"},\ \text{"father\_cm"}]]$ and target $y = \text{df}[\text{"child\_cm"}]$.
3. Partition the dataset using `train_test_split(X, y, test_size=0.25, random_state=42)`.
4. Instantiate and fit `LinearRegression()` on the training set.
5. Extract $\beta_{\text{mother}} = \text{model.coef\_}[0]$, $\beta_{\text{father}} = \text{model.coef\_}[1]$, and $\beta_0 = \text{model.intercept\_}$.
6. Verify that $\beta_{\text{mother}} + \beta_{\text{father}}$ approximates the baseline slope ($0.8847 \pm 0.02$).
7. Generate test set predictions, calculate MAE and $R^2$, and compare against the baseline metrics ($3.08$ cm and $0.54$).
8. Predict child height for a mother of $165.0$ cm and a father of $175.0$ cm, comparing with the midparent prediction for $170.0$ cm ($171.6$ cm).

**Constraints:** Maintain identical `random_state=42` and `test_size=0.25` for direct scientific comparability.

**Expected Behaviour:** Python script prints the multi-feature regression equation, sum of parental coefficients, comparative test metrics, and benchmark inference.

**Acceptance Criteria:**
- [ ] Successfully constructs 2D feature matrix of shape `(60, 2)`.
- [ ] Discovers $\beta_{\text{mother}} \approx 0.43$ and $\beta_{\text{father}} \approx 0.45$.
- [ ] Confirms the sum of coefficients ($\approx 0.885$) matches the baseline midparent slope.
- [ ] Confirms test MAE ($\approx 3.09$ cm) and R² ($\approx 0.535$) remain comparable to baseline.
- [ ] Predicts approximately $171.6$ cm for the test scenario (mother: 165 cm, father: 175 cm).

**Hints:**
- Use double brackets: `df[["mother_cm", "father_cm"]]`.
- Query DataFrame format: `pd.DataFrame({"mother_cm": [165.0], "father_cm": [175.0]})`.

**Difficulty:** Advanced  
**Estimated Completion Time:** 20 minutes  
