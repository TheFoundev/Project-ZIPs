# Lesson 02: Reading Outputs: Interpreting height_regression.png and metrics.txt

**Lesson ID:** lesson-02  
**Module:** module-06  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Dissect and interpret each visual layer of `outputs/height_regression.png`.
- Distinguish training data points, test data points, regression trend lines, and prediction markers by color, shape, and visual hierarchy.
- Read and parse `outputs/metrics.txt`, understanding the importance of high-precision logging.
- Contrast human-facing rounded terminal outputs with audit-ready persisted metric files.
- Critically evaluate model performance and biological variance through visual residuals.

## Prerequisites
- Completion of Module 05 (Evaluation & Visualization).
- Understanding of Cartesian coordinate systems, scatter plots, and linear slopes.

## Concept Explanation

### The Principle of Dual Artifact Logging
In production machine learning systems, simply printing results to a terminal screen is insufficient. Terminal sessions close, console buffers scroll off-screen, and standard output is rarely preserved indefinitely. Professional data science pipelines adhere to the **Dual Artifact Logging** standard:
1. **Visual Artifacts (`.png` / `.svg`):** Human-interpretable graphical plots that allow data scientists, stakeholders, and reviewers to qualitatively inspect data spread, identify visual outliers, verify linear fit, and spot non-linear patterns or heteroscedasticity.
2. **Textual Artifacts (`.txt` / `.json`):** Machine-parsable, high-precision records of parameters, loss functions, and evaluation metrics that allow downstream software pipelines, model registries, and automated auditing harnesses to track model performance over time.

In the Height Predictor project, these two roles are fulfilled by `outputs/height_regression.png` and `outputs/metrics.txt`.

```
                       ┌───────────────────────────────┐
                       │   Executed Pipeline: main.py   │
                       └───────────────┬───────────────┘
                                       │
                ┌──────────────────────┴──────────────────────┐
                ▼                                             ▼
  ┌───────────────────────────┐                 ┌───────────────────────────┐
  │ outputs/height_regression │                 │    outputs/metrics.txt    │
  │          (.png)           │                 │           (.txt)          │
  ├───────────────────────────┤                 ├───────────────────────────┤
  │ Qualitative Inspection:   │                 │ Quantitative Precision:   │
  │ • 45 purple train dots    │                 │ • 4-decimal equation      │
  │ • 15 teal test squares    │                 │ • High-precision MAE (cm) │
  │ • Crimson OLS trend line  │                 │ • Test set R² variance    │
  │ • Black star benchmark    │                 │ • Benchmark query output  │
  └───────────────────────────┘                 └───────────────────────────┘
```

### Anatomical Breakdown of `height_regression.png`
When opening `outputs/height_regression.png`, you observe four distinct visual layers plotted on a Cartesian plane:

1. **Training Families (Purple Circles):**
   - **Visual Encoding:** Rendered with `color="#8e44ad"` (rich amethyst purple), circular markers, point size $s=50$, and transparency `alpha=0.8`.
   - **Quantity:** Exactly $45$ points ($75\%$ of the 60 total families).
   - **Meaning:** These are the ground-truth observations seen by the algorithm during the `model.fit()` optimization phase. The transparency (`alpha=0.8`) allows overlapping points to appear darker, visually communicating data density.

2. **Test Families (Teal Squares):**
   - **Visual Encoding:** Rendered with `color="#16a085"` (vibrant sea green/teal), square markers (`marker="s"`), and size $s=60$.
   - **Quantity:** Exactly $15$ points ($25\%$ of the total families).
   - **Meaning:** These families were strictly quarantined during training. Their vertical distance from the crimson trend line represents the true out-of-sample generalization errors used to compute MAE and $R^2$.

3. **Ordinary Least Squares Trend Line (Crimson Solid Line):**
   - **Visual Encoding:** Rendered with `color="#c0392b"` (deep crimson red), linewidth $2.5$.
   - **Domain:** Spans continuously from $\min(\text{midparent}) \approx 162.75$ cm to $\max(\text{midparent}) \approx 183.35$ cm across 100 evenly spaced synthetic points.
   - **Meaning:** This line graphically represents the mathematical hypothesis function:
     $$\hat{y} = 0.8847 \cdot x + 21.1747$$
     Its positive slope ($+0.88$) demonstrates that taller parents have taller children, while its sub-unity value ($< 1.0$) illustrates Galton's regression to the mean.

4. **Benchmark Inference Point (Black Star Marker):**
   - **Visual Encoding:** Rendered at coordinates $(170.0, 171.58)$ using `color="#111111"`, star marker (`marker="*"`), prominent size $s=220$, and drawing priority `zorder=5`.
   - **Meaning:** Graphically demonstrates an out-of-sample prediction scenario. A user considering parents whose average height is $170$ cm can find $170$ on the horizontal axis and trace up to this prominent star at approximately $171.6$ cm on the vertical axis. The high `zorder=5` ensures the star renders on top of the regression line and scatter dots rather than being obscured.

### Anatomical Breakdown of `metrics.txt`
Inspecting `outputs/metrics.txt` reveals three cleanly structured lines:
```text
equation: child = 0.8847 * midparent + 21.1747
MAE: 3.0809 cm
R2: 0.5360
prediction at midparent 170 cm: 171.58 cm
```

Why does `metrics.txt` display four decimal places while the console output prints only one or two?
- **Console Output:** Tailored for human scanning. People reading terminal screens want rapid cognitive clarity: `3.1 cm`, `0.54`, `171.6 cm`.
- **Metrics File:** Tailored for automated validation, regression testing, and scientific precision. Storing `3.0809` and `0.5360` enables automated test suites to assert that newly trained models match historical baselines without rounding distortion.

## Relevant Code (from main.py, lines 57-78)
```python
    line_x = np.linspace(df["midparent_cm"].min(), df["midparent_cm"].max(), 100)
    line_y = model.predict(pd.DataFrame({"midparent_cm": line_x}))

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.scatter(X_train, y_train, color="#8e44ad", s=50, alpha=0.8, label="training families")
    ax.scatter(X_test, y_test, color="#16a085", s=60, marker="s", label="test families")
    ax.plot(line_x, line_y, color="#c0392b", linewidth=2.5, label="trend line")
    ax.scatter([170], [example], color="#111111", marker="*", s=220, zorder=5, label="170 cm example")
    ax.set_xlabel("Midparent height (cm)")
    ax.set_ylabel("Child height (cm)")
    ax.set_title("Parent height vs. child height")
    ax.legend()
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(OUT / "height_regression.png", dpi=150, bbox_inches="tight")
    plt.close(fig)

    with open(OUT / "metrics.txt", "w", encoding="utf-8") as handle:
        handle.write(f"equation: child = {slope:.4f} * midparent + {intercept:.4f}\n")
        handle.write(f"MAE: {mae:.4f} cm\nR2: {r2:.4f}\n")
        handle.write(f"prediction at midparent 170 cm: {example:.2f} cm\n")
```

## Code Explanation & Walkthrough
Let us examine the critical visualization and logging statements:
1. **Continuous Range Generation (`np.linspace`):**
   `line_x = np.linspace(df["midparent_cm"].min(), df["midparent_cm"].max(), 100)`
   Instead of drawing line segments between arbitrary scatter points, the script generates 100 evenly spaced values spanning the empirical data range. Passing these values through `model.predict(...)` yields a perfectly smooth, straight line across the entire plot domain.
2. **Layering with `zorder`:**
   Matplotlib renders plot elements in the order they are called by default. By specifying `zorder=5` on the benchmark star, the script guarantees that this critical summary point draws on top of all other graphical primitives, preventing visual clutter from hiding the example prediction.
3. **Subplot Geometry and Resolution:**
   `figsize=(7, 5)` creates a canvas with a standard $7:5$ aspect ratio. Coupled with `dpi=150` in `savefig`, the final image measures $1050 \times 750$ pixels—optimal for inclusion in slide decks, technical reports, and web dashboards.
4. **Context Managed File Output:**
   Opening `OUT / "metrics.txt"` with encoding `"utf-8"` guarantees cross-platform text fidelity across Linux, macOS, and Windows operating systems.

## Worked Example
Suppose an automated QA script inspects the generated artifacts after pipeline execution:
1. **Visual Check:** The QA engineer opens `outputs/height_regression.png` and confirms:
   - Are both training (circles) and test points (squares) visible? Yes.
   - Does the crimson line pass through the center of the point cloud? Yes.
   - Does the star align with $x = 170$ and $y \approx 171.6$? Yes.
2. **Text Metric Assertion:** The automated test reads `outputs/metrics.txt` and parses:
   ```python
   with open("outputs/metrics.txt") as f:
       lines = f.readlines()
   # line 0: equation: child = 0.8847 * midparent + 21.1747
   # line 1: MAE: 3.0809 cm
   # line 2: R2: 0.5360
   # line 3: prediction at midparent 170 cm: 171.58 cm
   ```
   The test asserts:
   - `0.85 < slope < 0.90` (confirms regression to the mean).
   - `2.5 < MAE < 3.5` (confirms expected error scale in centimeters).
   - `0.50 < R2 < 0.60` (confirms typical biological variance explained).

## Step-by-Step Student Instructions
1. Execute `main.py` if you have not already:
   ```bash
   python main.py
   ```
2. Check that the output directory contains the generated files:
   ```bash
   ls -lh outputs/
   ```
3. View the text metrics in your terminal:
   ```bash
   cat outputs/metrics.txt
   ```
4. Compare the numerical values in `metrics.txt` with the printed console values:
   - Console: `Model: child height = 0.88 x midparent height + 21.17`
   - File: `equation: child = 0.8847 * midparent + 21.1747`
   - Console: `Mean absolute error: 3.1 cm`
   - File: `MAE: 3.0809 cm`
   - Console: `R-squared: 0.54`
   - File: `R2: 0.5360`
5. Open `outputs/height_regression.png` using your environment's image viewer (e.g., `xdg-open outputs/height_regression.png` or by inspecting the image file in your file explorer).
6. Locate each visual element:
   - Count a few purple training circles and teal test squares.
   - Trace the crimson trend line from left to right.
   - Find the large black star at coordinate $(170, 171.6)$.

## Expected Output or Observable Behaviour
When viewing `outputs/metrics.txt`, the content is:
```
equation: child = 0.8847 * midparent + 21.1747
MAE: 3.0809 cm
R2: 0.5360
prediction at midparent 170 cm: 171.58 cm
```

When inspecting `outputs/height_regression.png`:
- The background grid is subtle (25% opacity).
- The legend in the upper-left or lower-right clearly labels:
  - "training families" (purple circle)
  - "test families" (teal square)
  - "trend line" (red line)
  - "170 cm example" (black star)
- Horizontal axis ranges roughly from $162$ cm to $184$ cm.
- Vertical axis ranges roughly from $160$ cm to $185$ cm.

## Practical Exercises
- **Exercise 2.1:** What is the vertical distance (residual) between a test point at $(175.5, 173.9)$ and the regression line? Use the equation in `metrics.txt` to calculate it.
- **Exercise 2.2:** Why is `bbox_inches="tight"` used when saving the plot? Test removing it in a scratch script and observe what happens to axis labels near the edge of the image.
- **Exercise 2.3:** Why are training families and test families plotted with different colors and shapes rather than identical markers?

## Common Mistakes and Debugging
| Mistake | Why It Is Wrong | Proper Understanding |
|---|---|---|
| Relying only on console printouts | Console logs are ephemeral and lost after terminal sessions disconnect | Persisting `metrics.txt` and PNG plots ensures auditable project outputs |
| Plotting line segments directly through unsorted test data | Results in a jagged, zig-zagging line connecting points out of order | Use `np.linspace` across the feature range to generate a clean monotonic line |
| Omitting `zorder` on key markers | The benchmark star can be drawn underneath dense clusters of scatter points | Set `zorder=5` (or higher) to force critical markers to the forefront |
| Confusing rounded display with underlying precision | Assuming the model only knows parameters to 2 decimal places | Scikit-learn stores 64-bit IEEE floating-point coefficients; rounding is for display |

## Best Practices and Security Considerations
- **Separation of Presentation and Persistence:** Provide clean, readable summaries for human users while writing high-precision metrics to disk for automated tracking.
- **Visual Accessibility:** Use distinct marker shapes (circles vs. squares vs. stars) in addition to colors so plots remain readable when printed in grayscale or viewed by color-blind users.
- **Artifact Verification:** Always check that output files exist and are non-empty after running an ML pipeline.

## Summary
The Height Predictor produces complementary outputs: `outputs/height_regression.png` renders a rich, four-layer visualization of the training data, test data, regression trend line, and benchmark prediction, while `outputs/metrics.txt` preserves high-precision mathematical parameters and evaluation metrics for automated evaluation and record keeping.

## Knowledge-check Questions
1. How many total scatter points appear in `height_regression.png`, and how are they divided between training and testing?
2. Which visual properties distinguish training families from test families in the generated plot?
3. What is the purpose of the black star marker at midparent coordinate 170 cm?
4. Why does `metrics.txt` store values to 4 decimal places while terminal output prints to 1 or 2 decimal places?

## References
- `main.py` lines 57–78: Plot generation and metrics writing.
- Matplotlib Pyplot Scatter Documentation: https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.scatter.html
- Matplotlib Z-order Demo: https://matplotlib.org/stable/gallery/misc/zorder_demo.html
