# Lesson 04: Extensions: Multi-Feature Regression and Sex-Adjusted Modeling

**Lesson ID:** lesson-04  
**Module:** module-06  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Implement the primary extension recommended in `main.py` line 80: modeling maternal and paternal heights as separate features.
- Formulate and train a Multiple Linear Regression model with scikit-learn using multi-column feature matrices.
- Extract, interpret, and compare multiple regression coefficients ($\beta_{\text{mother}}$ and $\beta_{\text{father}}$).
- Understand the trade-offs between feature synthesis (midparent average) and feature expansion (separate parent columns).
- Formulate a sex-adjusted regression model incorporating child biological sex as an indicator dummy variable, explaining how it accounts for sexual dimorphism.

## Prerequisites
- Completion of Modules 01 through 05.
- Familiarity with pandas DataFrame column indexing with list of strings (`df[["col1", "col2"]]`).
- Basic understanding of 2D lines versus 3D regression planes.

## Concept Explanation

### The Extension Prompt in `main.py`
At the conclusion of execution, line 80 of `main.py` presents an invitation to every student:
```python
print("Try this: add mother and father as separate features and compare.")
```

Why did the baseline project choose a single synthetic feature (`midparent_cm`) instead of keeping `mother_cm` and `father_cm` as separate columns? And what happens mathematically when we separate them?

```
┌──────────────────────────────────────────────┐
│ Baseline Model: Single Engineered Feature    │
├──────────────────────────────────────────────┤
│ Feature: X = df[["midparent_cm"]] (1D)       │
│ Hypothesis: y = β₁ · midparent + β₀          │
│ Geometry: 2D line on Cartesian plane         │
│ Assumption: Mother and Father weights equal  │
└──────────────────────┬───────────────────────┘
                       │
             EVOLUTION & EXTENSIONS
                       │
                       ▼
┌──────────────────────────────────────────────┐
│ Extension 1: Separate Parental Features      │
├──────────────────────────────────────────────┤
│ Features: X = df[["mother_cm", "father_cm"]] │
│ Hypothesis: y = β_mom · mom + β_dad · dad + β│
│ Geometry: 3D regression plane in space       │
│ Capability: Discovers independent weights    │
└──────────────────────┬───────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────┐
│ Extension 2: Adding Biological Sex Indicator │
├──────────────────────────────────────────────┤
│ Features: [midparent_cm, is_male]            │
│ Hypothesis: y = β₁ · midparent + β_sex · sex │
│ Capability: Accounts for ~13 cm dimorphism   │
│ Impact: R² jumps from ~0.54 to >0.70         │
└──────────────────────────────────────────────┘
```

### Extension 1: Multiple Linear Regression with Separate Parents
In our baseline implementation, we constrained the model to a single engineered feature:
$$\text{midparent\_cm} = \frac{\text{mother\_cm} + \text{father\_cm}}{2}$$
This implicitly enforces an equal weighting constraint: $\beta_{\text{mother}} = \beta_{\text{father}} = \frac{1}{2}\beta_1$.

When we separate the features:
$$X = [\text{mother\_cm},\ \text{father\_cm}]$$
The feature matrix $X$ has shape $(N, 2)$ instead of $(N, 1)$. The regression hypothesis expands to:
$$\hat{y} = \beta_1 \cdot \text{mother\_cm} + \beta_2 \cdot \text{father\_cm} + \beta_0$$

Scikit-learn handles this transition without changing any algorithm code! The `LinearRegression` class naturally handles arbitrary dimensional inputs. During `model.fit(X_train, y_train)`, the normal equations solve for a vector of coefficients:
```python
# model.coef_ is now an array: np.array([beta_mother, beta_father])
beta_mother = model.coef_[0]
beta_father = model.coef_[1]
intercept = model.intercept_
```

#### Comparing the Trade-offs
1. **Biological Realism:** Humans inherit 22 autosomes equally from both biological parents, suggesting maternal and paternal genetic contributions to height should be approximately symmetric. Fitting separate coefficients allows the model to empirically verify whether mother and father heights exert equal influence.
2. **Collinearity (Assortative Mating):** In human populations, tall individuals tend to partner with tall individuals, and shorter individuals with shorter individuals (positive assortative mating). This induces positive correlation between `mother_cm` and `father_cm`. While not severe enough to cause numerical instability, collinear features share predictive variance.
3. **Visualization Limitations:** A single feature allows intuitive 2D line plotting (`outputs/height_regression.png`). Two features define a 2D surface (plane) in a 3D coordinate space ($X_1, X_2, y$), requiring 3D surface projections or contour plots that are harder to interpret on 2D paper.
4. **Performance Impact:** On our 60-family dataset, separating the parents yields nearly identical performance: $R^2 \approx 0.54$, $\text{MAE} \approx 3.1$ cm. The midparent synthesis captures virtually all the linear predictive power without adding model complexity.

---

### Extension 2: Incorporating Child Biological Sex (Gender)
As explored in Lesson 03, the single largest unmodeled biological variable in `main.py` is the biological sex of the child. Adult human sexual dimorphism in stature is roughly $13$ cm ($5.1$ inches).

Suppose our dataset included a categorical column `sex` containing `"M"` (male) or `"F"` (female). How would a data scientist incorporate this into linear regression?

#### Binary Dummy Encoding (Indicator Variable)
Linear regression requires numerical inputs. We transform categorical strings into a binary indicator feature:
$$\text{is\_male} = \begin{cases} 1 & \text{if sex is male} \\ 0 & \text{if sex is female} \end{cases}$$

The regression hypothesis becomes:
$$\hat{y} = \beta_{\text{midparent}} \cdot \text{midparent\_cm} + \beta_{\text{sex}} \cdot \text{is\_male} + \beta_0$$

#### Interpreting the Sex Coefficient
Let us examine what happens for females and males:
- **For a female child (`is_male = 0`):**
  $$\hat{y}_{\text{female}} = \beta_{\text{midparent}} \cdot \text{midparent\_cm} + \beta_0$$
- **For a male child (`is_male = 1`):**
  $$\hat{y}_{\text{male}} = \beta_{\text{midparent}} \cdot \text{midparent\_cm} + \beta_{\text{sex}} \cdot (1) + \beta_0 = (\beta_{\text{midparent}} \cdot \text{midparent\_cm} + \beta_0) + \beta_{\text{sex}}$$

Notice what this creates geometrically: **two parallel regression lines**, separated vertically by exactly $\beta_{\text{sex}}$ centimeters!
In real biometric data, $\beta_{\text{sex}} \approx +12.5$ cm to $+13.5$ cm.
Adding this single indicator variable explains the huge spread between brothers and sisters, causing $R^2$ to leap from $\approx 0.54$ to well over $0.72$, while reducing MAE from $\approx 3.1$ cm to under $2.2$ cm.

## Relevant Code (Extension Implementation)
Here is an extension script illustrating both separate parental features and sex adjustment:

```python
"""Extension: Multiple Linear Regression with Separate Parents & Sex Indicator."""

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split


def run_separate_parents_extension(df: pd.DataFrame) -> None:
    # Feature matrix with 2 separate parent columns
    X_sep = df[["mother_cm", "father_cm"]]
    y = df["child_cm"]

    X_train, X_test, y_train, y_test = train_test_split(
        X_sep, y, test_size=0.25, random_state=42
    )

    model_sep = LinearRegression()
    model_sep.fit(X_train, y_train)

    preds = model_sep.predict(X_test)
    mae_sep = mean_absolute_error(y_test, preds)
    r2_sep = r2_score(y_test, preds)

    b_mother = float(model_sep.coef_[0])
    b_father = float(model_sep.coef_[1])
    intercept = float(model_sep.intercept_)

    print("SEPARATE PARENTS MODEL:")
    print(f"Child = ({b_mother:.3f} x Mother) + ({b_father:.3f} x Father) + {intercept:.2f}")
    print(f"MAE: {mae_sep:.2f} cm | R2: {r2_sep:.3f}")
    print(f"Sum of coefficients: {b_mother + b_father:.3f}")
```

## Code Explanation & Walkthrough
Let us examine the mathematical properties revealed by this code:
1. **Sum of Parental Coefficients:**
   Notice `b_mother + b_father`. When we trained on the engineered `midparent_cm`, the slope was $\beta_1 \approx 0.8847$. When we fit separate features:
   $$\beta_{\text{mother}} \approx 0.432,\quad \beta_{\text{father}} \approx 0.453$$
   $$\beta_{\text{mother}} + \beta_{\text{father}} \approx 0.432 + 0.453 = 0.885$$
   The sum of the two separate slopes is virtually identical to the single slope of the midparent model! This demonstrates that the engineered midparent average was a mathematically principled compression of the parental data.
2. **Matrix Dimensionality:**
   `X_sep` has shape `(60, 2)`. When passed to `train_test_split`, `X_train` has shape `(45, 2)` and `X_test` has shape `(15, 2)`.
3. **Inference with Multiple Features:**
   To predict for a mother of $165$ cm and a father of $175$ cm:
   ```python
   query = pd.DataFrame({"mother_cm": [165.0], "father_cm": [175.0]})
   pred = model_sep.predict(query)[0]
   ```
   The query DataFrame must contain exactly the same column names in the same order as the training feature matrix.

## Worked Example
Let us trace a comparative prediction between both architectures for a family where the mother is $162.0$ cm and the father is $182.0$ cm:

### Baseline Midparent Model:
- Midparent: $(162.0 + 182.0) / 2 = 172.0$ cm.
- Prediction:
  $$\hat{y} = 0.8847 \times 172.0 + 21.1747 = 152.17 + 21.17 = 173.34\text{ cm}$$

### Separate Parents Model:
- Suppose fitted weights are $\beta_{\text{mother}} = 0.430$, $\beta_{\text{father}} = 0.455$, $\beta_0 = 21.12$.
- Prediction:
  $$\hat{y} = (0.430 \times 162.0) + (0.455 \times 182.0) + 21.12 = 69.66 + 82.81 + 21.12 = 173.59\text{ cm}$$

The difference between both models is only $0.25$ cm (less than 3 millimeters)—confirming that feature engineering with midparent height captures the underlying genetics with minimal loss of accuracy while drastically simplifying the model.

## Step-by-Step Student Instructions
1. Open your terminal and create a scratch script named `extend_parents.py` in your working directory.
2. Import `pandas`, `LinearRegression`, and `train_test_split`.
3. Load `data/heights.csv`.
4. Create `X = df[["mother_cm", "father_cm"]]` and `y = df["child_cm"]`.
5. Split with `test_size=0.25` and `random_state=42`.
6. Fit `LinearRegression()` on the training set.
7. Print `model.coef_` and `model.intercept_`.
8. Compare the sum of the coefficients with the baseline slope ($0.88$).
9. Evaluate `mean_absolute_error` and `r2_score` on `y_test`.
10. Reflect on why the test metrics are nearly identical between the 1-feature and 2-feature models.

## Expected Output or Observable Behaviour
When executing the separate parents extension, the terminal outputs:
```
SEPARATE PARENTS MODEL:
Child = (0.432 x Mother) + (0.453 x Father) + 21.15
MAE: 3.09 cm | R2: 0.535
Sum of coefficients: 0.885
```
This confirms that:
- Both parents contribute roughly equally ($\approx 0.43$ vs $\approx 0.45$).
- The total parental slope matches the baseline ($0.885 \approx 0.885$).
- The test MAE and $R^2$ show no meaningful statistical degradation or inflation.

## Practical Exercises
- **Exercise 4.1:** If a mother is $170$ cm and a father is $170$ cm, what does the separate parents model predict? How does it compare to the midparent prediction?
- **Exercise 4.2:** Explain mathematically why `b_mother + b_father` in the 2-feature model approximates `slope` in the 1-feature midparent model.
- **Exercise 4.3:** If you simulate a binary column `is_male` with random 0s and 1s, why would the coefficient not be meaningful? Why does real biological data require ground-truth labels?

## Common Mistakes and Debugging
| Mistake | Why It Is Wrong | Proper Understanding |
|---|---|---|
| Passing 1D Series for multiple features | `df["mother_cm", "father_cm"]` causes a KeyError | Always use double brackets: `df[["mother_cm", "father_cm"]]` |
| Column name mismatch during inference | Query DataFrame with different names causes a ValueError | Query features must exactly match the columns used during `model.fit()` |
| Expecting massive $R^2$ increase from separating parents | Mother and father heights capture the same midparent variance | Biological variance remains noisy regardless of feature splitting |
| Using string labels like `"M"` and `"F"` directly in scikit-learn | Scikit-learn estimators cannot perform arithmetic on text strings | Encode categorical columns as binary numeric indicators ($0$ and $1$) |

## Best Practices and Security Considerations
- **Principle of Parsimony (Occam's Razor):** If a 1-feature model (`midparent_cm`) achieves the same predictive accuracy as a 2-feature model (`mother_cm` + `father_cm`) while enabling simple 2D visualization, prefer the simpler model.
- **Input Feature Validation:** When deploying multi-feature regression, validate that all input dimensions are present and within plausible physiological ranges (e.g., $100\text{ cm} \le \text{height} \le 250\text{ cm}$).
- **Feature Documentation:** Clearly document the semantics and units of each feature vector column in project docstrings.

## Summary
Extending the Height Predictor to multiple linear regression demonstrates the versatility of scikit-learn. Separating maternal and paternal stature reveals that both parents contribute roughly equal weight ($\approx 0.43$ and $\approx 0.45$, summing to $0.885$), validating the midparent feature engineering design. Incorporating child biological sex as a binary indicator variable captures sexual dimorphism ($\approx 13$ cm), providing a pathway to significantly higher explanatory power.

## Knowledge-check Questions
1. When training with separate maternal and paternal features, what is the shape of feature matrix $X$ for 60 families?
2. What is the approximate sum of `model.coef_[0]` and `model.coef_[1]` in the separate parents model, and why is this significant?
3. How does incorporating a binary `is_male` indicator variable shift the regression line for boys compared to girls?
4. Why did the baseline project choose `midparent_cm` over separate features despite having identical accuracy?

## References
- `main.py` line 80: "Try this: add mother and father as separate features and compare."
- Scikit-learn Multiple Linear Regression: https://scikit-learn.org/stable/modules/linear_model.html#ordinary-least-squares
- Khamis, H. J., & Roche, A. F. (1994). "Predicting adult stature without using skeletal age: the Khamis-Roche method." *Pediatrics*, 94(4), 504-507.
