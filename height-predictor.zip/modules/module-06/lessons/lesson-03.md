# Lesson 03: Teaching Models vs. Medical Predictions: Ethics and Limitations

**Lesson ID:** lesson-03  
**Module:** module-06  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why educational machine learning models must carry prominent non-medical disclaimers.
- Contrast the inputs, protocols, and diagnostic rigor of clinical pediatric endocrinology with simple educational regression models.
- Identify the biological, environmental, and demographic factors omitted by `main.py` (e.g., biological sex, bone age, nutrition, puberty staging).
- Understand the concept of Software as a Medical Device (SaMD) and the legal, ethical, and regulatory boundaries governing clinical AI.
- Recognize the danger of algorithmic automation bias and advocate for ethical humility in data science.

## Prerequisites
- Completion of Module 01 (Project Overview & Medical Disclaimer) and Module 03 (Linear Regression on Noisy Biological Data).
- Basic understanding of statistical correlation versus biological causation.

## Concept Explanation

### The Temptation of Algorithmic Hubris
When students build their first supervised machine learning models, an intoxicating sensation often occurs: you feed in a CSV file, invoke `model.fit()`, receive an equation ($\hat{y} = 0.88x + 21.17$), and see a line cutting neatly through data points. It is tempting to believe that you have uncovered a universal law of nature—and that this mathematical formula can be deployed in the real world to advise parents or predict an infant's adult stature.

This cognitive trap is known as **algorithmic hubris**: the mistaken belief that statistical associations discovered on small, simplified datasets can substitute for specialized domain expertise and clinical diagnostic science.

In `main.py`, lines 6–8 and line 55 explicitly guard against this hubris:
```python
# This is a teaching model, not a medical prediction.  It shows how a
# relationship with plenty of natural noise can still produce a useful trend.
...
print("\nRemember: nutrition, health, sleep, and chance also matter.")
```

```
┌───────────────────────────────────────────────┐
│              Teaching Regression              │
│                 (main.py)                     │
├───────────────────────────────────────────────┤
│ • 60 family records                           │
│ • Single engineered feature (midparent_cm)    │
│ • No child biological sex indicator           │
│ • No bone age or hormonal panels              │
│ • Purpose: Pedagogical exploration of ML      │
└───────────────────────┬───────────────────────┘
                        │
         NEVER VALID FOR CLINICAL ADVICE
                        │
                        ▼
┌───────────────────────────────────────────────┐
│        Clinical Pediatric Endocrinology       │
│              (Medical Diagnostic)             │
├───────────────────────────────────────────────┤
│ • WHO / CDC standardized growth percentiles   │
│ • Radiographic skeletal bone age (wrist X-ray)│
│ • Pubertal Tanner staging (I - V)             │
│ • Sex-adjusted Midparental Target Height      │
│ • Endocrine assays (GH, IGF-1, TSH, Free T4)  │
│ • Clinical diagnosis of metabolic pathology   │
└───────────────────────────────────────────────┘
```

### What Clinical Pediatric Endocrinology Actually Involves
In pediatric medicine, evaluating a child's growth and adult height potential is a comprehensive, multi-year clinical specialty. When a pediatric endocrinologist evaluates a child, they examine a battery of clinical diagnostic signals:

1. **Longitudinal Growth Trajectories:**
   Rather than evaluating a single static moment, physicians plot heights across years on standardized World Health Organization (WHO) or Centers for Disease Control and Prevention (CDC) growth charts. These charts are constructed from hundreds of thousands of longitudinal measurements across diverse, healthy populations. A child crossing percentiles downwards (e.g., dropping from the 50th percentile to the 5th) triggers diagnostic investigation for conditions such as growth hormone deficiency, celiac disease, or Turner syndrome.

2. **Radiographic Skeletal Bone Age:**
   Chronological age (years since birth) frequently diverges from biological maturity. Clinicians obtain an X-ray of the child's left wrist and hand, comparing the ossification centers of the carpal bones and epiphyses against standardized atlases (such as the Greulich-Pyle or Tanner-Whitehouse TW3 methods). A 12-year-old child with a bone age of 10 has two additional years of open growth plates before epiphyseal fusion occurs, substantially elevating their adult height potential compared to a child with an advanced bone age of 14.

3. **Sex Adjustments (Sexual Dimorphism):**
   Adult human males are on average approximately $13$ cm (about $5$ inches) taller than adult females due to hormonal differences during puberty and differences in growth spurt timing. Clinical target height equations (the Tanner Midparental Height method) explicitly account for this:
   $$\text{Target Height (Boy)} = \frac{\text{father\_height} + (\text{mother\_height} + 13\text{ cm})}{2} \pm 8.5\text{ cm}$$
   $$\text{Target Height (Girl)} = \frac{(\text{father\_height} - 13\text{ cm}) + \text{mother\_height}}{2} \pm 8.5\text{ cm}$$
   Notice that `main.py` does not even know the biological sex of the child! By pooling boys and girls together into a single column `child_cm`, the educational model introduces roughly $\pm 6.5$ cm of unmodeled sexual dimorphism into its residuals.

4. **Biochemical and Hormonal Assays:**
   Physicians evaluate pituitary and thyroid function through blood tests measuring Growth Hormone (GH), Insulin-Like Growth Factor 1 (IGF-1), Thyroid-Stimulating Hormone (TSH), and free Thyroxine (T4).

5. **Environmental, Epigenetic, and Stochastic Realities:**
   As line 55 emphasizes: *"nutrition, health, sleep, and chance also matter."* Deep slow-wave sleep is when the pituitary gland releases pulsatile growth hormone surges. Childhood chronic illnesses, severe emotional stress (psychosocial dwarfism), systemic inflammation, and caloric/micronutrient deficiencies (e.g., zinc, protein, vitamin D) profoundly alter genetic potential.

### The Dangers of Misapplication and Automation Bias
Why must an AI engineer care so deeply about these disclaimers?
- **Automation Bias:** Parents and non-technical users exhibit an innate tendency to trust computerized or algorithmic predictions over human skepticism. If a parent inputs their measurements into an uncertified web tool and receives a predicted child height of $160$ cm, they may experience profound anxiety, seek unprescribed supplements or illicit growth hormone therapies online, or wrongly blame their child's diet.
- **Regulatory and Legal Classification:** In modern software law, algorithms that provide diagnostic or prognostic recommendations regarding human health are classified by the FDA and European Union as **Software as a Medical Device (SaMD)**. Deploying an uncertified machine learning model for medical guidance violates healthcare regulations, exposing creators to strict legal liability.
- **Small Sample Bias:** Our educational dataset consists of only 60 families from a specific demographic cohort. It cannot generalize to varied ethnic backgrounds, geographic regions, or nutritional profiles across the globe.

## Relevant Code (from main.py, lines 6-8, 55)
```python
# Lines 6-8:
This is a teaching model, not a medical prediction.  It shows how a
relationship with plenty of natural noise can still produce a useful trend.

...

# Line 55:
print("\nRemember: nutrition, health, sleep, and chance also matter.")
```

## Code Explanation & Walkthrough
Notice the intentional placement of these statements:
- **Module Docstring (Lines 6–8):** Placed at the very top of `main.py` before any imports or executable logic. Any developer inspecting or contributing to the codebase encounters the disclaimer immediately.
- **Console Message (Line 55):** Placed directly below the printed numerical prediction. By positioning this message adjacent to the quantitative output, the script ensures that any user reading the prediction (`171.6 cm`) immediately encounters the qualitative reminder that biological traits are non-deterministic and shaped by holistic lifestyle factors.

## Worked Example
Consider an anxious father ($185$ cm) and mother ($170$ cm) who evaluate their 10-year-old daughter.
- The midparent height is $(185 + 170) / 2 = 177.5$ cm.
- Feeding $177.5$ cm into `main.py`:
  $$\hat{y} = 0.8847 \times 177.5 + 21.1747 = 178.2\text{ cm}$$
- The family assumes their daughter will reach $178.2$ cm.
- However, because the child is a biological female, clinical pediatric target height calculates:
  $$\text{Target} = \frac{(185 - 13) + 170}{2} = \frac{172 + 170}{2} = 171.0\text{ cm} \pm 8.5\text{ cm}$$
- The educational model overestimated her expected stature by over $7$ cm because it lacked sex adjustments!
- Furthermore, if the daughter enters puberty early (advanced bone age), her growth plates may close at age 13, resulting in an adult stature of $164$ cm. A doctor monitoring bone age would anticipate this; a naive 1-feature linear regression model would be oblivious.

## Step-by-Step Student Instructions
1. Open `main.py` in your text editor.
2. Read the header comment on lines 6–8. Note the emphasis on "plenty of natural noise."
3. Locate line 55 and observe how the reminder is displayed in the terminal during execution.
4. Compare the model's MAE ($3.1$ cm) with the known sexual dimorphism of human height ($13$ cm).
5. In your notes, list five medical diagnostic tools used by pediatricians that are absent from `main.py`.
6. Draft an ethical use policy for deploying AI models trained on personal biological data.

## Expected Output or Observable Behaviour
When running `python main.py`, the terminal explicitly reinforces the model's limitations:
```
============================================================
HOW TALL WILL YOU BE?
============================================================
Model: child height = 0.88 x midparent height + 21.17
Mean absolute error: 3.1 cm
R-squared: 0.54
Prediction for midparent height 170 cm: 171.6 cm

Remember: nutrition, health, sleep, and chance also matter.
```
This visible reminder serves as a benchmark for responsible AI engineering: never present statistical predictions without clear domain caveats.

## Practical Exercises
- **Exercise 3.1:** What is "Software as a Medical Device" (SaMD), and why does `main.py` deliberately not qualify as one?
- **Exercise 3.2:** A healthcare startup proposes embedding `main.py` into a mobile app that advises parents whether to inject growth hormones. Write a one-paragraph technical memo explaining why this is medically dangerous and legally non-compliant.
- **Exercise 3.3:** How does omitting the child's biological sex affect the model's prediction accuracy for boys versus girls?

## Common Mistakes and Debugging
| Mistake | Why It Is Wrong | Proper Understanding |
|---|---|---|
| Assuming high $R^2$ makes a model clinically valid | Statistical correlation does not equal medical diagnostic accuracy | Clinical validity requires biological validation, bone age, and endocrine testing |
| Omitting disclaimers in client-facing ML tools | Users assume algorithmic outputs are infallible medical facts | Always provide transparent disclaimers regarding model scope and limitations |
| Extrapolating a 60-family model to all populations | Small localized samples do not represent global genetic and nutritional diversity | Models are constrained by the demographic boundaries of their training data |
| Ignoring sexual dimorphism in stature | Adult males and females differ by ~13 cm on average | Single-target models without sex features conflate distinct biological distributions |

## Best Practices and Security Considerations
- **Transparent Model Scope:** Always include ethical disclaimers in both source code docstrings and interactive user interfaces.
- **Domain Humility:** Machine learning models find empirical associations; they do not understand human endocrinology or developmental biology.
- **Regulatory Awareness:** Comply with healthcare software regulations (FDA SaMD, EU MDR) whenever handling physiological data.

## Summary
The Height Predictor is an educational model created to teach linear regression, feature engineering, and Galton's regression to the mean. It is deliberately distinct from clinical pediatric diagnostic tools. Understanding the gap between simplified educational models and rigorous medical endocrinology is a foundational responsibility for ethical AI practitioners.

## Knowledge-check Questions
1. Why does `main.py` state that it is a teaching model and not a medical prediction?
2. What is sexual dimorphism in human height, and how much does it average in adult populations?
3. Name two clinical tests that pediatricians use to evaluate child growth that are completely absent from `main.py`.
4. What is automation bias, and how can it harm families who misunderstand machine learning predictions?

## References
- `main.py` lines 6–8, 55: Ethical disclaimer and lifestyle factor notices.
- World Health Organization Child Growth Standards: https://www.who.int/tools/child-growth-standards
- U.S. FDA Software as a Medical Device (SaMD): https://www.fda.gov/medical-devices/digital-health-center-excellence/software-medical-device-samd
- Tanner, J. M., et al. (1970). "Standards from birth to maturity for height, weight, height velocity, and weight velocity." *Archives of Disease in Childhood*.
