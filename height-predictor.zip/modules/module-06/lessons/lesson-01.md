# Lesson 01: Running main.py End-to-End: Complete Pipeline Walkthrough

**Lesson ID:** lesson-01  
**Module:** module-06  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Trace the complete execution flow of `main.py` from top to bottom across all eight distinct pipeline stages.
- Execute the project script from the terminal and observe standard console output.
- Understand how each component—path anchoring, data ingestion, feature synthesis, splitting, fitting, evaluation, inference, and visualization—interlocks into a coherent machine learning system.
- Verify that runtime artifacts are generated correctly in the designated output directory without side effects or unhandled exceptions.

## Prerequisites
- Completion of Modules 01 through 05 covering data ingestion, feature engineering, statistical theory, scikit-learn model fitting, and visualization.
- Basic terminal command execution skills (`cd`, `python main.py`, `ls`).

## Concept Explanation

### The Architecture of an End-to-End Machine Learning Script
In production machine learning and research, individual functions or notebook cells are frequently chained together into an end-to-end runnable pipeline. A robust machine learning script must be:
1. **Self-contained and Reproducible:** Given a fixed random seed (`random_state=42`) and source data (`heights.csv`), every execution produces identical numerical parameters and artifacts.
2. **Headless-Safe:** It must operate without requiring an attached graphical desktop environment, enabling automation in continuous integration (CI) runners, Docker containers, and remote cloud compute instances.
3. **Transparent and Informative:** The script logs human-readable summaries to stdout while persisting structured metrics and visualizations to durable disk storage.

The `main.py` script of the Height Predictor implements an end-to-end pipeline structured into eight sequential phases:

```
[ Phase 1: Environment & Headless Setup ]
                 │
                 ▼
[ Phase 2: Path Anchoring & Output Directory Creation ]
                 │
                 ▼
[ Phase 3: Data Ingestion & Feature Engineering ]
                 │
                 ▼
[ Phase 4: Train / Test Partitioning ]
                 │
                 ▼
[ Phase 5: Ordinary Least Squares Model Fitting ]
                 │
                 ▼
[ Phase 6: Metric Evaluation & Out-of-Sample Inference ]
                 │
                 ▼
[ Phase 7: Matplotlib Plot Generation & Rendering ]
                 │
                 ▼
[ Phase 8: Artifact Persistence & Console Reporting ]
```

### Deconstructing the Eight Execution Stages
1. **Headless Matplotlib Initialization (Lines 12–15):** The script executes `matplotlib.use("Agg")` prior to importing `pyplot`. This configures the Anti-Grain Geometry backend, decoupling rendering from GUI display servers like X11 or Wayland.
2. **Path Resolution (Lines 22–25):** Using `pathlib.Path(__file__).resolve().parent`, the script constructs absolute anchors for `BASE`, `DATA`, and `OUT`. It calls `OUT.mkdir(exist_ok=True)` to create the `outputs/` folder dynamically if it does not already exist.
3. **Ingestion & Feature Synthesis (Lines 29–32):** `pd.read_csv(DATA / "heights.csv")` ingests the 60 family records. The script creates the engineered feature `df["midparent_cm"] = (df["mother_cm"] + df["father_cm"]) / 2`, and extracts feature matrix `X = df[["midparent_cm"]]` (shape: `(60, 1)`) and target vector `y = df["child_cm"]` (shape: `(60,)`).
4. **Partitioning (Lines 34–36):** `train_test_split(X, y, test_size=0.25, random_state=42)` splits the dataset into 45 training families ($75\%$) and 15 testing families ($25\%$).
5. **Model Fitting (Lines 38–39):** `LinearRegression().fit(X_train, y_train)` fits the line minimizing the sum of squared residuals, estimating slope $\beta_1 \approx 0.8847$ and intercept $\beta_0 \approx 21.1747$.
6. **Evaluation & Inference (Lines 40–46):** Generates test set predictions via `model.predict(X_test)`, calculates Mean Absolute Error (`mae = mean_absolute_error(y_test, predictions)`) and $R^2$ (`r2 = r2_score(y_test, predictions)`), and predicts child stature for a benchmark test family with midparent height $170.0$ cm.
7. **Visualization (Lines 57–72):** Evaluates trend line points across 100 synthetic coordinates, renders training scatter dots (purple circles), test scatter points (teal squares), trend line (crimson line), and benchmark prediction marker (black star), before saving to `outputs/height_regression.png` and closing the figure.
8. **Logging & Artifact Export (Lines 48–56, 74–80):** Prints formatted console output, saves `outputs/metrics.txt`, and concludes with actionable extension advice.

## Relevant Code (from main.py, lines 22-84)
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)


def main() -> None:
    df = pd.read_csv(DATA / "heights.csv")
    df["midparent_cm"] = (df["mother_cm"] + df["father_cm"]) / 2
    X = df[["midparent_cm"]]
    y = df["child_cm"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42
    )

    model = LinearRegression()
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    mae = mean_absolute_error(y_test, predictions)
    r2 = r2_score(y_test, predictions)
    slope = float(model.coef_[0])
    intercept = float(model.intercept_)
    example = float(model.predict(pd.DataFrame({"midparent_cm": [170.0]}))[0])

    print("=" * 60)
    print("HOW TALL WILL YOU BE?")
    print("=" * 60)
    print(f"Model: child height = {slope:.2f} x midparent height + {intercept:.2f}")
    print(f"Mean absolute error: {mae:.1f} cm")
    print(f"R-squared: {r2:.2f}")
    print(f"Prediction for midparent height 170 cm: {example:.1f} cm")
    print("\nRemember: nutrition, health, sleep, and chance also matter.")

    line_x = np.linspace(df["midparent_cm"].min(), df["midparent_cm"].max(), 100)
    line_y = model.predict(pd.DataFrame({"midparent_cm": line_x}))

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.scatter(X_train, y_train, color="#8e44ad", s=50, alpha=0.8, label="training families")
    ax.scatter(X_test, y_test, color="#16a085", s=60, marker="s", label="test families")
    ax.plot(line_x, line_y, color="#c0392b", linewidth=2.5, label="trend line")
    ax.scatter([170], [example], color="#111111", marker="*", s=220, zorder=5, label="170 cm example")
    ax.set_xlabel("Midparent height (cm)")
    ax.set_ylabel("Child height (cm)")
    ax.set_title("Parent height vs. child height")
    ax.legend()
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(OUT / "height_regression.png", dpi=150, bbox_inches="tight")
    plt.close(fig)

    with open(OUT / "metrics.txt", "w", encoding="utf-8") as handle:
        handle.write(f"equation: child = {slope:.4f} * midparent + {intercept:.4f}\n")
        handle.write(f"MAE: {mae:.4f} cm\nR2: {r2:.4f}\n")
        handle.write(f"prediction at midparent 170 cm: {example:.2f} cm\n")

    print("\nSaved: outputs/height_regression.png, outputs/metrics.txt")
    print("Try this: add mother and father as separate features and compare.")


if __name__ == "__main__":
    main()
```

## Code Explanation & Walkthrough
The design follows clean Python conventions:
- **`if __name__ == "__main__": main()` Idiom:** This construct prevents `main()` from automatically executing if another script imports functions or variables from `main.py`. It guarantees that execution occurs strictly when the script is directly invoked via the command line (`python main.py`).
- **Memory Safety:** Notice `plt.close(fig)` on line 72. Matplotlib holds graphical objects in global memory even after saving them to disk. Explicitly closing the figure frees memory immediately, preventing resource leaks in batch systems.
- **Context Manager (`with open(...) as handle:`):** The metrics file is opened within a context manager. This ensures that the file descriptor is flushed and closed cleanly, even if an unexpected error occurs during writing.
- **DPI and Bounding Box Formatting:** `fig.savefig(..., dpi=150, bbox_inches="tight")` ensures crisp resolution ($150$ dots per inch) and crops extraneous canvas padding so that labels and legends are perfectly framed.

## Worked Example
Let us trace what occurs internally during an execution run with concrete values:
1. `df` loads 60 records.
2. `df["midparent_cm"]` creates values ranging from $162.75$ cm to $183.35$ cm.
3. The 45 training rows fit Ordinary Least Squares regression:
   $$\beta_1 = 0.8847,\quad \beta_0 = 21.1747$$
4. A test family with midparent height $175.5$ cm is evaluated:
   $$\hat{y} = 0.8847 \times 175.5 + 21.1747 = 176.44\text{ cm}$$
   If the true observed height $y$ is $173.9$ cm, the absolute error is:
   $$|173.9 - 176.44| = 2.54\text{ cm}$$
5. Across all 15 test families, the average error calculates to $3.08$ cm (printed as `3.1 cm`).
6. The synthetic query for $170.0$ cm yields:
   $$\hat{y}_{170} = 0.8847 \times 170.0 + 21.1747 = 171.58\text{ cm (printed as 171.6 cm)}$$

## Step-by-Step Student Instructions
1. Open your terminal emulator.
2. Navigate to the project directory:
   ```bash
   cd "/home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/09_height_predictor"
   ```
3. Verify the files present in the directory:
   ```bash
   ls -la
   ```
   You should see `main.py` and the `data/` folder containing `heights.csv`.
4. Execute `main.py` using Python:
   ```bash
   python main.py
   ```
5. Observe the console output displayed on your screen.
6. Verify the contents of the newly created `outputs/` folder:
   ```bash
   ls -la outputs/
   ```
   Confirm that both `height_regression.png` and `metrics.txt` exist.
7. Inspect the generated metrics file:
   ```bash
   cat outputs/metrics.txt
   ```

## Expected Output or Observable Behaviour
When you run `python main.py`, your terminal will display:
```
============================================================
HOW TALL WILL YOU BE?
============================================================
Model: child height = 0.88 x midparent height + 21.17
Mean absolute error: 3.1 cm
R-squared: 0.54
Prediction for midparent height 170 cm: 171.6 cm

Remember: nutrition, health, sleep, and chance also matter.

Saved: outputs/height_regression.png, outputs/metrics.txt
Try this: add mother and father as separate features and compare.
```
Simultaneously, `outputs/height_regression.png` (a 7x5 inch graphic at 150 DPI) and `outputs/metrics.txt` (a 3-line text summary) will be created in the `outputs/` directory.

## Practical Exercises
- **Exercise 1.1:** Execute `python main.py` twice consecutively. Does the second run overwrite or append to `outputs/metrics.txt`? (Inspect the open mode `"w"` on line 74 to explain why).
- **Exercise 1.2:** What error occurs if you delete `data/heights.csv` before running `main.py`? Re-create or restore the file after observing the exception.
- **Exercise 1.3:** Modify line 46 in a scratch copy to evaluate a midparent stature of $180.0$ cm. What is the predicted child height?

## Common Mistakes and Debugging
| Mistake | Why It Is Wrong | Proper Understanding |
|---|---|---|
| Executing from the wrong working directory | Relative path assumptions (`"data/heights.csv"`) fail if launched elsewhere | `main.py` uses `Path(__file__).resolve().parent` to anchor paths reliably |
| Forgetting `plt.close(fig)` | Figure stays active in memory, accumulating RAM overhead in recurring loops | Explicitly close figures after saving with `plt.close(fig)` |
| Using append mode (`"a"`) for `metrics.txt` | Multiple script runs append redundant text blocks, polluting metric logs | Write mode (`"w"`) ensures every execution refreshes metrics cleanly |
| Opening GUI windows on headless servers | Calling `plt.show()` without an X server causes `TclError` or crashes | Headless configuration with `matplotlib.use("Agg")` avoids display server requirements |

## Best Practices and Security Considerations
- **Deterministic Pipeline Execution:** Always fix `random_state` so experimental results can be reproduced by peers, mentors, and automated grading harnesses.
- **Script Modularity:** Organize scripts into logical functions (`main()`) protected by `if __name__ == "__main__":` entry guards.
- **Sanitized Path Handling:** Use `pathlib.Path` instead of raw string concatenation or OS-specific separators (`/` vs `\`).

## Summary
The `main.py` script serves as a complete, self-contained educational pipeline. In fewer than 85 lines of clean Python code, it ingests multi-generation biometric data, derives engineered features, trains an Ordinary Least Squares regression model, verifies regression to the mean, evaluates generalization error on hold-out families, and generates both high-resolution visual and textual artifacts.

## Knowledge-check Questions
1. What design pattern in Python ensures that `main()` runs only when `main.py` is invoked directly from the terminal?
2. Which backend does the script assign to matplotlib, and why is this critical for server environments?
3. What file mode is used to open `outputs/metrics.txt`, and what happens to previous contents when the script runs again?
4. What are the two specific files created in the `outputs/` directory by the script?

## References
- `main.py` lines 22–84: Full end-to-end execution pipeline.
- Python Standard Library `pathlib`: https://docs.python.org/3/library/pathlib.html
- Scikit-learn Linear Regression: https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html
