# Lesson 01: Biological Variation vs Deterministic Physical Relationships

**Lesson ID:** lesson-01
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why biological systems exhibit far greater variation (noise) than physical or engineering systems.
- Identify the genetic and environmental contributors to human height variation.
- Differentiate between irreducible biological noise and measurement error.
- Understand why machine learning models in biology seek trends rather than exact deterministic predictions.

## Prerequisites
- Completion of Module 01 and Module 02.
- Basic understanding of linear models and scatter plots.

## Concept Explanation

### Deterministic vs Stochastic Systems
In classical physics, many fundamental relationships are virtually **deterministic**. For example, Newton's second law ($F = m \cdot a$) or Ohm's law ($V = I \cdot R$) describe clean, mathematical relationships. If you measure the current through a known resistor in a controlled lab, you can predict the voltage drop with near $99.9\%$ accuracy. Any slight discrepancy is typically minor measurement error caused by your voltmeter.

In living biological organisms, relationships are **stochastic** (probabilistic and noisy). When two parents have three biological children:
- Do all three siblings grow up to be the exact same adult height?
- Of course not! Even non-twin siblings sharing the same biological mother and father often differ in adult height by $5$ to $12$ cm!

This natural spread is not a defect in our measuring tape. It is **irreducible biological variation**.

### Where Does Biological Noise Come From?
Human height is one of the most thoroughly studied traits in human quantitative genetics. It is governed by a combination of complex mechanisms:

1. **Polygenic Inheritance:** Adult height is influenced by thousands of distinct genetic variants across the genome. When a child is conceived, parental chromosomes undergo genetic recombination and independent assortment. Each child receives a unique combination of height-promoting and height-neutral alleles.
2. **Environmental and Nutritional Factors:** A child's growth depends on protein intake, micronutrients (calcium, zinc, vitamin D), access to clean water, and childhood illnesses.
3. **Sleep and Hormonal Pulses:** Growth hormone (GH) is secreted primarily in nocturnal pulses during deep (slow-wave) sleep. Chronic sleep deprivation, high stress (cortisol), or childhood chronic illness can suppress growth velocity.
4. **Epigenetics and Developmental Stochasticity:** Even identical twins (who share $100\%$ of DNA sequence) can differ in adult height by $1$ to $2$ centimeters due to subtle intrauterine conditions and post-natal epigenetic modifications.

### What This Means for Machine Learning
When an algorithm tries to predict adult child height from parental stature alone, it is attempting to estimate a trait with thousands of inputs using only **one combined input** (`midparent_cm`).

As a result, no linear regression model can ever achieve a perfect straight line through all points. In `main.py`, lines 6–7 state:
> *"This is a teaching model, not a medical prediction. It shows how a relationship with plenty of natural noise can still produce a useful trend."*

The goal of biological machine learning is to discover the underlying macroscopic trend despite the presence of natural microscopic noise.

## Relevant Code (from main.py, lines 6-8, 55)
```python
# From module docstring:
# This is a teaching model, not a medical prediction.  It shows how a
# relationship with plenty of natural noise can still produce a useful trend.

# From console printout (line 55):
print("
Remember: nutrition, health, sleep, and chance also matter.")
```

## Code Explanation & Walkthrough
Notice the deliberate inclusion of line 55 in `main.py`. The console output does not just spit out a numerical prediction; it explicitly reminds the user of the biological reality: "nutrition, health, sleep, and chance also matter." 

From a machine learning perspective, everything not captured by `midparent_cm` (nutrition, health, sleep, genetic recombination) is lumped into the statistical **residual** (the unexplained error term $\epsilon$).

## Worked Example
Consider two families in our dataset with identical midparent heights of $172.5$ cm:
- Family A: `midparent_cm` = $172.5$, actual `child_cm` = $176.8$ cm.
- Family B: `midparent_cm` = $172.5$, actual `child_cm` = $169.2$ cm.

Our linear model will output the exact same prediction for both families:
$$\hat{y} = 0.8847 \times 172.5 + 21.1747 = 173.79\text{ cm}$$

- Residual for Family A: $176.8 - 173.79 = +3.01$ cm (taller than predicted).
- Residual for Family B: $169.2 - 173.79 = -4.59$ cm (shorter than predicted).

Both families are valid biological realities. The $+3.01$ cm and $-4.59$ cm residuals reflect biological noise, not model failure.

## Step-by-Step Student Instructions
1. Open `main.py` and inspect lines 6–8 and line 55.
2. Note the explicit factors mentioned: nutrition, health, sleep, and chance.
3. Contrast a physical system (e.g., calculating travel time from distance / speed) with biological height prediction.
4. Explain why two biological siblings with identical parents can have different adult heights.
5. In your notes, define the statistical residual $\epsilon_i = y_i - \hat{y}_i$ as the mathematical container for biological noise.

## Expected Output or Observable Behaviour
When plotting parental height versus child height, data points do not lie neatly on a straight line. Instead, they form a cloud or "swarm" of points clustered around the central trend line. The vertical distance between each point and the line represents biological variation.

## Practical Exercises
- **Exercise 1.1:** What is the difference between deterministic relationships and stochastic biological relationships?
- **Exercise 1.2:** Name four distinct biological or environmental factors that cause siblings with the same parents to reach different adult heights.
- **Exercise 1.3:** If a machine learning model achieved 100% accuracy ($R^2 = 1.0$) on human adult height using only midparent height, why would a geneticist immediately suspect data fraud or severe overfitting?

## Common Mistakes and Debugging
| Mistake | Why It Is Wrong | Proper Understanding |
|---|---|---|
| Assuming scatter indicates bad data | In biology, scatter is the authentic expression of genetic and environmental diversity | Natural scatter is expected and healthy in biological datasets |
| Expecting complex algorithms to eliminate noise | Deep neural networks cannot predict random allele recombination or unmeasured nutrition | Irreducible error cannot be eliminated without measuring every biological factor |
| Confusing measurement error with biological noise | Measurement error is using a faulty ruler; biological noise is real genetic variation | Biological noise represents genuine phenotypic differences |

## Best Practices and Security Considerations
- **Transparent Uncertainty:** Always present biological predictions with confidence intervals or error margins rather than single rigid numbers.
- **Holistic Context:** Never reduce a human being's developmental trajectory to a single mathematical score.

## Summary
Biological systems are governed by polygenic inheritance and environmental variation, producing substantial natural noise that contrasts sharply with deterministic physical laws. In the Height Predictor project, machine learning captures the macro population trend while respecting the reality of biological variation.

## Knowledge-check Questions
1. Why do non-twin siblings from the same parents often differ in adult height?
2. What are the four primary drivers of human height variation?
3. What is the mathematical term for the vertical difference between an observed height and the model's prediction?
4. Why is an $R^2$ of 1.0 impossible in real-world human height modeling?

## References
- Visscher, P. M., et al. (2010). "Heritability in the genomics era—concepts and misconceptions." *Nature Reviews Genetics*.
- Scikit-learn Linear Regression: https://scikit-learn.org/stable/modules/linear_model.html
