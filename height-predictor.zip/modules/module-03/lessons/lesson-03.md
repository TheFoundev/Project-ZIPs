# Lesson 03: Mathematical Mechanics of Regression to the Mean (Slope < 1.0)

**Lesson ID:** lesson-03
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Analyze the mathematical formula of the trained model: $\text{child} = 0.88 \times \text{midparent} + 21.17$.
- Explain how a slope strictly less than $1.0$ produces regression to the mean.
- Demonstrate how the positive intercept ($+21.17$ cm) provides compensation for shorter parents.
- Calculate the "crossover point" (fixed point) where predicted child height equals midparent height.

## Prerequisites
- Completion of Lesson 02 (Interpreting R-squared in Noisy Natural Domains).
- Ability to solve a basic single-variable linear equation ($y = mx + c$).

## Concept Explanation

### The Learned Equation
When `main.py` fits a linear regression model to the 45 training families, it extracts two parameters:
$$\text{slope } (\beta_1) = 0.8847 \approx 0.88$$
$$\text{intercept } (\beta_0) = 21.1747 \approx 21.17$$

The model equation is:
$$\text{child\_height} = 0.88 \times \text{midparent\_height} + 21.17$$

### Why Slope < 1.0 Compresses Extremes
Let us dissect the mathematical behavior of this linear equation:

1. **If Slope Were Exactly 1.0 (with Intercept 0):**
   $$\text{child} = 1.0 \times \text{midparent}$$
   In this scenario, a child whose parents are $10$ cm taller than average would be predicted to be exactly $10$ cm taller than average. A child whose parents are $10$ cm shorter than average would be predicted to be exactly $10$ cm shorter than average. Variation would never compress.

2. **When Slope is 0.88 (< 1.0):**
   $$\Delta \text{child} = 0.88 \times \Delta \text{parents}$$
   For every additional centimeter of parental height above average, the child is predicted to gain only **$0.88$ cm**!
   - Parental deviation: $+10$ cm
   - Predicted child deviation: $+8.8$ cm (closer to the mean by $1.2$ cm!)
   - Parental deviation: $-10$ cm
   - Predicted child deviation: $-8.8$ cm (closer to the mean by $1.2$ cm!)

The slope of $0.88$ acts as a statistical "gravity", gently pulling the predictions of extreme families inward toward the center!

### The Role of the Positive Intercept (+21.17 cm)
If the slope is $0.88$, multiplying a number by $0.88$ makes it smaller. How do children avoid becoming tiny?
That is the critical role of the **positive intercept** ($+21.17$ cm)!

The intercept provides a baseline upward shift. It ensures that when parents are below average, the $+21.17$ cm offset compensates, making the child **taller** than their parents!

### Finding the Crossover Point (Fixed Point)
At what parental stature does the predicted child height equal the parental stature exactly?
We can solve for this fixed point by setting $\text{child} = \text{midparent} = x$:
$$x = 0.8847 \cdot x + 21.1747$$
$$x - 0.8847 \cdot x = 21.1747$$
$$0.1153 \cdot x = 21.1747$$
$$x = \frac{21.1747}{0.1153} \approx 183.6\text{ cm}$$

At approximately $183.6$ cm:
- Parents with midparent height below $183.6$ cm produce children predicted to be taller than their midparent baseline.
- Parents with midparent height above $183.6$ cm produce children predicted to be shorter than their midparent baseline.

Because average adult male height in the dataset is $\approx 180$ cm and females $\approx 165$ cm, this crossover behavior ensures that the vast majority of the population regresses safely toward the biological average.

## Relevant Code (from main.py, lines 44-51)
```python
    slope = float(model.coef_[0])
    intercept = float(model.intercept_)
    example = float(model.predict(pd.DataFrame({"midparent_cm": [170.0]}))[0])

    print("=" * 60)
    print("HOW TALL WILL YOU BE?")
    print("=" * 60)
    print(f"Model: child height = {slope:.2f} x midparent height + {intercept:.2f}")
```

## Code Explanation & Walkthrough
- `model.coef_[0]`: In scikit-learn, `coef_` is a NumPy array containing the feature weights. Since we have one feature, `model.coef_[0]` contains our slope $\beta_1$.
- `model.intercept_`: Contains the scalar bias term $\beta_0$.
- `float()`: Explicitly converts NumPy 64-bit floats into standard Python floating-point scalars for clean formatting.
- Line 51 formats both numbers to two decimal places (`:.2f`), producing `0.88` and `21.17`.

## Worked Example
Let us trace three families through the formula $\hat{y} = 0.8847 \cdot x + 21.1747$:

1. **Short Parents ($160.0$ cm):**
   $$\hat{y} = 0.8847(160.0) + 21.1747 = 141.55 + 21.17 = 162.72\text{ cm}$$
   Result: Child is $+2.72$ cm **taller** than parents (regressing up toward average).
2. **Average Parents ($173.0$ cm):**
   $$\hat{y} = 0.8847(173.0) + 21.1747 = 153.05 + 21.17 = 174.22\text{ cm}$$
   Result: Child is $+1.22$ cm relative to midparent.
3. **Very Tall Parents ($190.0$ cm):**
   $$\hat{y} = 0.8847(190.0) + 21.1747 = 168.09 + 21.17 = 189.26\text{ cm}$$
   Result: Child is $-0.74$ cm **shorter** than parents (regressing down toward average).

Notice the beauty of the mathematics: in all cases, the prediction moves toward the population center.

## Step-by-Step Student Instructions
1. In your Python environment, extract the slope and intercept using `model.coef_[0]` and `model.intercept_`.
2. Write down the full equation on paper.
3. Test the equation for input values of $150$ cm, $170$ cm, and $190$ cm.
4. Calculate the difference $(\hat{y} - x)$ for each case.
5. Confirm that $(\hat{y} - x)$ is positive for short parents and negative for very tall parents.

## Expected Output or Observable Behaviour
Output in the console:
```
Model: child height = 0.88 x midparent height + 21.17
```
The slope of $0.88$ visually flattens the trend line on the scatter plot relative to a 45-degree ($1.0$ slope) diagonal.

## Practical Exercises
- **Exercise 3.1:** What is the value of the slope and intercept in `main.py`?
- **Exercise 3.2:** If parents have a midparent height of $165.0$ cm, what is the child's predicted height? Is the child predicted to be taller or shorter than the midparent?
- **Exercise 3.3:** Why is the intercept positive ($+21.17$ cm) rather than zero?

## Common Mistakes and Debugging
| Mistake | Why It Is Wrong | Proper Understanding |
|---|---|---|
| Forgetting float() conversion | Leaves variables as 1-element numpy arrays, causing formatting warnings | Always cast `float(model.coef_[0])` |
| Assuming slope < 1 means children are shrinking | The positive intercept prevents shrinking and provides balance | Slope < 1 flattens the line, while intercept shifts it up |
| Thinking the intercept represents a real baby at 0 cm | 0 cm midparent is an extrapolation far outside biological data | Intercept is an algebraic anchor, not a physically meaningful parent |

## Best Practices and Security Considerations
- **Avoid Extreme Extrapolation:** Never evaluate the model for nonsensical inputs (e.g. 0 cm or 500 cm). Linear models are only valid within observed training ranges (~150 cm to ~195 cm).
- **Format Precision:** Always format regression coefficients to 2 decimal places to prevent messy floating-point outputs like `0.884705128374`.

## Summary
The mathematical mechanics of regression to the mean are encoded directly in the linear parameters: a slope below $1.0$ ($0.88$) compresses trait extremes, while a positive intercept ($21.17$ cm) balances the scale, ensuring that offspring stature regresses toward the population center.

## Knowledge-check Questions
1. What is the value of the slope extracted from the fitted model?
2. How does a slope of 0.88 affect offspring predictions for parents who are 10 cm above average?
3. What is the biological function of the positive intercept in this equation?
4. At approximately what parental height does the child's predicted height equal the parental height?

## References
- Stigler, S. M. (1997). "Galton's Law of Universal Regression." *Regression Toward the Mean*.
- Scikit-learn LinearRegression Attributes (coef_, intercept_): https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html
