# Lesson 02: Interpreting R-squared in Noisy Natural Domains

**Lesson ID:** lesson-02
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define the coefficient of determination ($R^2$) mathematically and conceptually.
- Interpret the Height Predictor model's $R^2$ score of approximately $0.54$.
- Contrast acceptable $R^2$ benchmarks in physical sciences, social sciences, and biology.
- Explain why an $R^2$ of $0.54$ represents a strong biological signal rather than a weak model.

## Prerequisites
- Completion of Lesson 01 (Biological Variation vs Deterministic Physical Relationships).
- Basic understanding of total variance and explained variance.

## Concept Explanation

### What is R-squared ($R^2$)?
In regression analysis, the coefficient of determination—denoted $R^2$ (pronounced "R-squared")—quantifies the proportion of variance in the target variable that is explained by the independent features in the model.

Mathematically, $R^2$ is defined as:
$$R^2 = 1 - \frac{\text{SS}_{\text{res}}}{\text{SS}_{\text{tot}}}$$
Where:
- $\text{SS}_{\text{res}} = \sum (y_i - \hat{y}_i)^2$: Sum of squared residuals (the variance left unexplained by the line).
- $\text{SS}_{\text{tot}} = \sum (y_i - \bar{y})^2$: Total sum of squares (the total variance of the data around the simple mean).

In simple terms:
- If a model predicts no better than simply guessing the mean height for everyone, $R^2 = 0.0$.
- If a model predicts every data point with zero error, $R^2 = 1.0$.

### Interpreting $R^2 = 0.54$ in the Height Predictor
When running `main.py`, scikit-learn computes the $R^2$ score on the 15 held-out test families:
```
R-squared: 0.54
```
What does $0.54$ mean?
It means that **$54\%$ of the variation in adult child height is directly explained by parental midparent height**! The remaining **$46\%$** of variation is driven by genetic recombination, environmental differences (diet, sleep, health), and unmodeled factors (such as child sex).

### Domain-Specific $R^2$ Expectations
Beginner students often make the mistake of evaluating $R^2$ by an arbitrary grading scale:
- "In school, 54% is an F, so this model must be terrible!"

This intuition is completely wrong in data science! Acceptable $R^2$ thresholds depend entirely on the **scientific domain**:

| Domain | Typical $R^2$ Range | Rationale |
|---|---|---|
| **Physics / Engineering** | $0.95 - 0.999$ | Highly controlled systems governed by exact physical conservation laws. |
| **Retail Demand Forecasting** | $0.80 - 0.95$ | Strong seasonal drivers (e.g., hot weather directly drives lemonade consumption). |
| **Human Quantitative Genetics** | **$0.40 - 0.65$** | **Polygenic traits with hundreds of genetic variants and environmental factors.** |
| **Social Sciences / Psychology** | $0.15 - 0.35$ | Human behavior is extraordinarily complex, noisy, and influenced by hundreds of social variables. |

In human genetics, explaining **$54\%$ of phenotypic variance** with a single engineered feature (`midparent_cm`) is a massive effect size! It confirms that parental genetics is the dominant biological foundation of stature, while leaving room for the natural diversity of life.

## Relevant Code (from main.py, lines 43, 53)
```python
    r2 = r2_score(y_test, predictions)
    ...
    print(f"R-squared: {r2:.2f}")
```

## Code Explanation & Walkthrough
In line 43, `r2_score(y_test, predictions)` compares the ground truth test heights (`y_test`) against our model's predictions (`predictions`). 

Notice that `r2_score` is evaluated strictly on the **test set** (15 families). Computing $R^2$ on the test set proves that our model explains over half the variance in families it has never seen before, demonstrating genuine generalization rather than memorization.

## Worked Example
Suppose the total variance of child heights in the test set is $\text{SS}_{\text{tot}} = 300.0$.
If our regression line produces residuals with sum of squares $\text{SS}_{\text{res}} = 138.0$, then:
$$R^2 = 1 - \frac{138.0}{300.0} = 1 - 0.46 = 0.54$$

This shows that out of 300 units of variation, the regression line successfully accounts for $162$ units ($54\%$), leaving only $138$ units ($46\%$) as residual scatter.

## Step-by-Step Student Instructions
1. Open `main.py` and locate line 43 where `r2_score` is calculated.
2. Run `python main.py` and inspect the terminal output: `R-squared: 0.54`.
3. In your notebook, calculate $1.0 - 0.54 = 0.46$ and write a sentence explaining what the 46% represents.
4. Contrast this $0.54$ biological score with the $0.90$ score from the Lemonade Stand project.
5. Explain to a peer why a score of $0.54$ in human genetics is considered a strong scientific finding.

## Expected Output or Observable Behaviour
Console printout:
```
R-squared: 0.54
```
Students understand that this metric reflects genuine biological heritability rather than model deficiency.

## Practical Exercises
- **Exercise 2.1:** What is the formal definition of $R^2$?
- **Exercise 2.2:** What does an $R^2$ of $0.54$ tell us about the relationship between parental height and offspring height?
- **Exercise 2.3:** Why is an $R^2$ of $0.54$ considered strong in biology, whereas an $R^2$ of $0.54$ would be considered poor in an electrical engineering circuit model?

## Common Mistakes and Debugging
| Mistake | Why It Is Wrong | Proper Understanding |
|---|---|---|
| Expecting R² > 0.90 in human biology | Ignores polygenic recombination, nutrition, and environmental variation | Biology is inherently noisy; 0.54 is a strong, meaningful effect size |
| Computing R² on training data only | Training R² can be inflated by overfitting | Always compute R² on held-out test data for unbiased evaluation |
| Thinking R² = 0.54 means 46% error rate | R² measures proportion of variance, not classification error percentage | 46% is the proportion of height variance not explained by midparent stature |

## Best Practices and Security Considerations
- **Contextual Evaluation:** Never interpret an $R^2$ score in isolation without considering domain benchmarks.
- **Reporting Units:** Remember that $R^2$ is unitless (ranging from $-\infty$ to $1.0$), unlike MAE which is expressed in centimeters.

## Summary
The coefficient of determination ($R^2 \approx 0.54$) reveals that midparent height explains more than half the variation in adult child stature. In biological and human sciences, this represents a powerful statistical relationship that successfully captures heritable trends despite natural environmental and genetic noise.

## Knowledge-check Questions
1. What does the mathematical formula $1 - (\text{SS}_{\text{res}} / \text{SS}_{\text{tot}})$ represent?
2. What proportion of height variation is explained by the Height Predictor model?
3. What proportion of height variation remains unexplained biological noise?
4. Why do physical models typically have higher $R^2$ scores than biological models?

## References
- Scikit-learn r2_score Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.metrics.r2_score.html
- Cohen, J. (1988). *Statistical Power Analysis for the Behavioral Sciences*. Lawrence Erlbaum Associates.
