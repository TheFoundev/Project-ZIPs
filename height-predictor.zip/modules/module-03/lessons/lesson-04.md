# Lesson 04: Contrast: Height Predictor vs Lemonade Stand Dynamics

**Lesson ID:** lesson-04
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Compare and contrast the Height Predictor project with the Lemonade Stand Fortune Teller project.
- Contrast physical/business demand modeling with biological trait inheritance.
- Compare dataset sizes, feature types, $R^2$ scores, and error magnitudes between the two projects.
- Synthesize why different machine learning problems require different evaluation expectations.

## Prerequisites
- Completion of Lessons 01, 02, and 03.
- Familiarity with the Lemonade Stand Fortune Teller project (`02_lemonade_stand`).

## Concept Explanation

### A Tale of Two Regression Models
To truly master machine learning, a student must compare different regression tasks across different domains. In this curriculum, you have encountered two core linear regression projects:
1. **The Lemonade Stand Fortune Teller (`02_lemonade_stand`):** Predicting cups of lemonade sold based on daily temperature in Celsius.
2. **How Tall Will You Be? (`09_height_predictor`):** Predicting adult child height based on parental heights.

Both projects use ordinary least squares linear regression from `scikit-learn`. Both split data into training and test sets using `test_size=0.25, random_state=42`. Yet their scientific dynamics, data structures, and performance profiles are radically different!

### Side-by-Side Comparison Matrix

| Dimension | Lemonade Stand Fortune Teller | Height Predictor |
|---|---|---|
| **Problem Domain** | Business Demand / Microeconomics | Biometrics / Quantitative Genetics |
| **Dataset File** | `lemonade_days.csv` (16 rows) | `heights.csv` (60 rows) |
| **Input Feature (X)** | `temperature_c` (raw physical measurement) | `midparent_cm` (**engineered composite feature**) |
| **Target Variable (y)**| `cups_sold` (inventory count) | `child_cm` (biological stature) |
| **Slope ($\beta_1$)** | $\approx 1.58$ cups per $1^\circ\text{C}$ | $\approx 0.88$ cm per $1$ cm midparent |
| **Intercept ($\beta_0$)** | $\approx -10.66$ cups | $\approx +21.17$ cm |
| **Goodness of Fit ($R^2$)**| **$\approx 0.90$** | **$\approx 0.54$** |
| **Mean Absolute Error** | $\approx 2.16$ cups | $\approx 3.08$ cm |
| **Noise Level** | Low noise (thermodynamics & human thirst) | **High biological noise** (polygenic & environmental) |
| **Core Phenomenon** | Direct proportional demand scaling | **Regression to the mean (slope < 1.0)** |

### Why Did Lemonade Stand Achieve $R^2 = 0.90$ While Height Achieved $R^2 = 0.54$?
This is the single most important conceptual question for beginner data scientists:

1. **In Lemonade Stand:** Temperature is the primary physical driver of thirst. When ambient temperature rises from $20^\circ\text{C}$ to $35^\circ\text{C}$, human physiological need for hydration increases predictably. The relationship is strong, clean, and direct. Few other variables dramatically altered the 16 recorded summer days.
2. **In Height Predictor:** Even though midparent height is the single strongest predictor of child height, it only accounts for parental genetic baseline. It cannot account for:
   - Which specific alleles were recombined during meiosis.
   - Childhood nutrition and illness episodes.
   - Sleep quality and growth hormone surges.
   - The biological sex of the child.

Therefore, an $R^2$ of $0.54$ in biology is just as impressive and scientifically valid as an $R^2$ of $0.90$ in beverage demand forecasting!

## Relevant Code (Comparing main.py Across Both Projects)
```python
# Lemonade Stand (02_lemonade_stand):
# X = df[["temperature_c"]]  # Raw single feature
# cups = 1.58 * temp + (-10.66)
# R² ≈ 0.90

# Height Predictor (09_height_predictor):
# df["midparent_cm"] = (df["mother_cm"] + df["father_cm"]) / 2  # Engineered feature
# X = df[["midparent_cm"]]
# child = 0.88 * midparent + 21.17
# R² ≈ 0.54
```

## Code Explanation & Walkthrough
Notice the architectural difference:
- In Lemonade Stand, the feature was already present in the CSV (`temperature_c`). No feature engineering was required.
- In Height Predictor, feature engineering was required upfront to combine two parent columns into `midparent_cm`.
- Furthermore, the slopes tell completely different stories:
  - Lemonade slope ($1.58 > 1.0$) reflects compounding demand on hot days.
  - Height slope ($0.88 < 1.0$) reflects regression to the mean!

## Worked Example
Let us compare what a 10% change in input means for both models:
- In Lemonade Stand: Increasing temperature by $+5^\circ\text{C}$ yields $1.58 \times 5 = +7.9$ additional cups sold.
- In Height Predictor: Increasing midparent stature by $+5$ cm yields $0.88 \times 5 = +4.4$ cm of child height.
Notice how the height model dampens the increase ($4.4 < 5.0$), pulling the offspring back toward the population center.

## Step-by-Step Student Instructions
1. Review the comparison matrix above.
2. Note that both projects use scikit-learn's `LinearRegression` class.
3. Observe how the same mathematical algorithm adapts to completely different real-world phenomena.
4. Reflect on how domain knowledge (economics vs genetics) dictates the interpretation of slope, intercept, and $R^2$.
5. Write down a paragraph explaining why $R^2$ alone does not define whether a model is "good" or "bad".

## Expected Output or Observable Behaviour
When comparing the plots of both projects:
- `lemonade_regression.png`: Data points lie tightly clustered along the green regression line.
- `height_regression.png`: Data points form a wider, more scattered cloud around the red trend line, clearly displaying natural biological dispersion.

## Practical Exercises
- **Exercise 4.1:** Contrast the $R^2$ score of Lemonade Stand ($0.90$) with Height Predictor ($0.54$). Why is the difference expected?
- **Exercise 4.2:** In which project was feature engineering applied, and what formula was used?
- **Exercise 4.3:** How does the physical meaning of the intercept differ between the two projects?

## Common Mistakes and Debugging
| Mistake | Why It Is Wrong | Proper Understanding |
|---|---|---|
| Believing higher R² always means a better data scientist | R² reflects the nature of the domain, not the coder's skill | Biology is intrinsically noisier than simple commercial systems |
| Ignoring feature engineering in Lemonade Stand comparisons | Lemonade used a raw column; Height engineered a new composite column | Feature engineering transforms raw columns using domain logic |
| Applying identical evaluation standards across all industries | Medical, financial, and physical systems have fundamentally different noise profiles | Always evaluate models against domain-specific baselines |

## Best Practices and Security Considerations
- **Comparative Reflection:** Regularly contrast newly trained models with previous projects to broaden your algorithmic intuition.
- **Contextual Metric Selection:** Combine relative metrics ($R^2$) with physical absolute metrics (MAE in centimeters or cups) to gain a complete picture of performance.

## Summary
Comparing the Height Predictor with the Lemonade Stand Fortune Teller reveals the breadth of supervised linear regression. While clean physical and business relationships often yield high $R^2$ scores ($0.90$), biological traits naturally exhibit higher noise ($R^2 \approx 0.54$). Recognizing that domain realities dictate expected metrics is a hallmark of mature machine learning engineering.

## Knowledge-check Questions
1. Why does the Lemonade Stand project have a higher $R^2$ score than the Height Predictor?
2. Which project required feature engineering before model fitting?
3. What is the key difference in what the slope represents in the two projects?
4. Why is an $R^2$ of 0.54 considered successful in human biometrics?

## References
- Main script comparisons: `02_lemonade_stand/main.py` vs `09_height_predictor/main.py`.
- James, G., et al. (2021). *An Introduction to Statistical Learning with Applications in Python*. Springer.
