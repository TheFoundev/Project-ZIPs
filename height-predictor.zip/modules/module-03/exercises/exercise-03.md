# Module 3 Exercises: Linear Regression on Noisy Biological Data

## Exercise 3.1: Identifying Sources of Biological Noise (10 min)
**Objective:** Distinguish between reducible measurement error and irreducible biological noise in anthropometric modeling.
**Problem Statement:** In the Height Predictor, child height exhibits substantial scatter around the regression line. You must analyze the origins of this variation and explain why machine learning cannot reduce it to zero.

**Requirements:**
1. Define the difference between measurement error and irreducible biological noise.
2. List 3 specific biological mechanisms that introduce noise into human height.
3. List 2 environmental mechanisms that introduce noise into human height.
4. Explain why collecting 10,000 families would still not produce an $R^2$ of 1.0 using midparent height alone.

**Constraints:** Base your answers on the biological principles established in Module 03.

**Expected Behaviour:** A structured 1-page written response clearly delineating reducible error from irreducible biological variance.

**Acceptance Criteria:**
- [ ] Measurement error correctly distinguished from biological phenotypic variation.
- [ ] Correctly lists biological factors: genetic recombination, polygenic variance, epigenetics.
- [ ] Correctly lists environmental factors: childhood nutrition, illness, sleep, stress.
- [ ] Explains that parental stature alone lacks data on individual allele assortment and environment.

**Hints:**
- Consider whether identical twins have the exact same height.
- Think about what happens during meiosis when eggs and sperm are formed.

**Difficulty:** Basic
**Estimated Completion Time:** 10 minutes

---

## Exercise 3.2: Deconstructing R-squared in Biological Genetics (15 min)
**Objective:** Calculate and interpret $R^2$ using sum of squared residuals and total sum of squares.
**Problem Statement:** You are evaluating a test set of family height predictions. Given total variance and residual variance, calculate $R^2$ and interpret the result.

**Requirements:**
1. Given: Total sum of squares $\text{SS}_{\text{tot}} = 250.0$, Sum of squared residuals $\text{SS}_{\text{res}} = 115.0$.
2. Compute the exact $R^2$ score using $R^2 = 1 - (\text{SS}_{\text{res}} / \text{SS}_{\text{tot}})$.
3. State the percentage of variance explained by the model.
4. State the percentage of variance that remains unexplained noise.
5. Justify whether this score is acceptable for human height prediction.

**Constraints:** Show all intermediate arithmetic steps.

**Expected Behaviour:** Mathematical calculation followed by a 2–3 sentence biological interpretation.

**Acceptance Criteria:**
- [ ] $R^2$ calculation correctly yields $1 - (115.0 / 250.0) = 1 - 0.46 = 0.54$.
- [ ] Percentage explained correctly stated as 54%.
- [ ] Percentage unexplained correctly stated as 46%.
- [ ] Domain justification accurately references human polygenic heritability standards.

**Hints:**
- $115 / 250 = 23 / 50 = 0.46$.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 3.3: Mathematical Verification of Regression to the Mean (15 min)
**Objective:** Calculate predicted heights for three family tiers and prove that the slope < 1.0 causes regression to the mean.
**Problem Statement:** Using the equation $\text{child} = 0.8847 \times \text{midparent} + 21.1747$, calculate predictions for short, average, and tall parents, and verify the direction of shift relative to the population mean (~173 cm).

**Requirements:**
1. Tier 1 (Short): `midparent_cm` = $162.0$ cm.
2. Tier 2 (Average): `midparent_cm` = $173.0$ cm.
3. Tier 3 (Tall): `midparent_cm` = $186.0$ cm.
4. For each tier, compute predicted height $\hat{y}$ and the difference $\hat{y} - \text{midparent}$.
5. Confirm that Tier 1 shifts upward ($+$), Tier 3 shifts downward ($-$), and Tier 2 remains close to midpoint.

**Constraints:** Round intermediate calculations to 2 decimal places.

**Expected Behaviour:** A comparison table displaying input midparent, predicted child height, and net directional shift.

**Acceptance Criteria:**
- [ ] Tier 1 calculation: $0.8847(162) + 21.1747 \approx 143.32 + 21.17 = 164.50$ cm (shift: $+2.50$ cm).
- [ ] Tier 2 calculation: $0.8847(173) + 21.1747 \approx 153.05 + 21.17 = 174.22$ cm (shift: $+1.22$ cm).
- [ ] Tier 3 calculation: $0.8847(186) + 21.1747 \approx 164.55 + 21.17 = 185.73$ cm (shift: $-0.27$ cm).
- [ ] Analytical conclusion correctly explains how the slope of 0.88 compresses extremes toward the center.

**Hints:**
- Notice how the shift changes from positive to negative as parental height increases.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 3.4: Comparative Case Study: Lemonade vs Height Predictor (20 min)
**Objective:** Conduct a systematic comparative analysis between the Lemonade Stand and Height Predictor projects.
**Problem Statement:** Prepare a comparison report evaluating the differences in problem formulation, data characteristics, feature engineering, and model metrics between Project 02 and Project 09.

**Requirements:**
1. Construct a comparison table covering: Domain, Sample Size, Features, Target, R², MAE, and Slope.
2. Explain why Lemonade Stand has a higher R² ($0.90$) than Height Predictor ($0.54$).
3. Contrast the meaning of the slope in both projects ($1.58$ cups/°C vs $0.88$ cm/cm).
4. Summarize the role of domain knowledge in interpreting machine learning results.

**Constraints:** Draw facts strictly from the project codebases and reference documentation.

**Expected Behaviour:** A structured comparative study table accompanied by analytical commentary.

**Acceptance Criteria:**
- [ ] Table accurately populated with correct metrics for both projects.
- [ ] Narrative accurately explains physiological thermodynamics (lemonade) vs polygenic biological noise (height).
- [ ] Slope interpretation clearly contrasts demand acceleration ($1.58 > 1$) with regression to the mean ($0.88 < 1$).
- [ ] Conclusion emphasizes that machine learning metrics must always be interpreted in domain context.

**Hints:**
- Review the comparative matrix in Lesson 04.

**Difficulty:** Advanced
**Estimated Completion Time:** 20 minutes
