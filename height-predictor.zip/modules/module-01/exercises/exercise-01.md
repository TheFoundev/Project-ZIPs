# Module 1 Exercises: Project Overview & Historical Origins of Regression

## Exercise 1.1: Problem Type & Ethical Boundary Classification (10 min)
**Objective:** Correctly classify the machine learning task type of the Height Predictor and justify its mandatory educational disclaimer.
**Problem Statement:** You have been provided with `main.py` which predicts adult child height in centimeters from parental measurements. You must determine the machine learning task category and explain why this project includes a non-medical teaching disclaimer.

**Requirements:**
1. Define supervised regression and explain why predicting `child_cm` qualifies as regression rather than classification.
2. Identify the target variable and feature variable in the project.
3. Articulate two clear reasons why this model cannot be deployed in a pediatric clinic to diagnose growth disorders.

**Constraints:** Base your justification strictly on the project docstring, code logic, and principles of biological modeling.

**Expected Behaviour:** A structured 4–6 sentence written response accurately addressing all requirements.

**Acceptance Criteria:**
- [ ] Stature prediction is correctly identified as continuous supervised regression.
- [ ] Target (`child_cm`) and engineered feature (`midparent_cm`) are explicitly named.
- [ ] The non-medical teaching disclaimer is justified citing lack of clinical factors (bone age, hormonal levels, sex adjustment, pediatric growth standards).
- [ ] No claim that the model can be used for clinical healthcare decisions.

**Hints:**
- Consider the difference between predicting a category (e.g., tall/short) versus a numeric measurement (e.g., 176.4 cm).
- Review lines 6–7 in `main.py`.

**Difficulty:** Basic
**Estimated Completion Time:** 10 minutes

---

## Exercise 1.2: Exploring Galton's Regression to the Mean (15 min)
**Objective:** Calculate offspring height expectations and mathematically demonstrate regression to the mean.
**Problem Statement:** Sir Francis Galton discovered that children of extreme parents regress toward the population average. Using the learned model equation from `main.py` ($\text{child} = 0.88 \times \text{midparent} + 21.17$), calculate predictions for extreme parental statures and analyze whether the outputs exhibit regression to the mean.

**Requirements:**
1. Calculate the predicted child height for very tall parents with `midparent_cm = 188.0` cm.
2. Calculate the predicted child height for short parents with `midparent_cm = 155.0` cm.
3. Compare each prediction to the parental midparent height and determine if the child moved closer to the overall mean (assume mean $\approx 173$ cm).
4. Explain what would happen to human heights across multiple generations if the slope were $1.2$ instead of $0.88$.

**Constraints:** Perform the calculations using the exact coefficients rounded to two decimal places: slope = 0.88, intercept = 21.17.

**Expected Behaviour:** Complete arithmetic calculations showing the input midparent height, predicted child height, and a concise narrative analyzing the directional shift toward the mean.

**Acceptance Criteria:**
- [ ] Calculation for 188.0 cm correctly yields approximately 186.61 cm (shorter than parents).
- [ ] Calculation for 155.0 cm correctly yields approximately 157.57 cm (taller than parents).
- [ ] Narrative accurately explains how both cases move closer to the population center.
- [ ] Analysis correctly explains that a slope > 1.0 would cause divergence into extreme giants and dwarfs.

**Hints:**
- Plug the numbers into $\hat{y} = 0.88 \times x + 21.17$.
- Compare $\hat{y} - x$ for each scenario.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 1.3: Manual Midparent Feature Engineering (10 min)
**Objective:** Compute the `midparent_cm` feature manually and explain why feature engineering is valuable.
**Problem Statement:** Given raw measurements of maternal and paternal heights, compute the engineered midparent feature and explain the benefits of feature engineering.

**Requirements:**
1. Given: Mother height = $162.4$ cm, Father height = $181.8$ cm. Compute the unweighted `midparent_cm`.
2. Given: Mother height = $171.0$ cm, Father height = $171.0$ cm. Compute the unweighted `midparent_cm`.
3. Explain why combining two columns into one is beneficial for linear regression visualization and model complexity.

**Constraints:** Use standard floating-point arithmetic.

**Expected Behaviour:** Show formulas, intermediate arithmetic, and final rounded midparent values.

**Acceptance Criteria:**
- [ ] First calculation yields exactly $(162.4 + 181.8) / 2 = 172.1$ cm.
- [ ] Second calculation yields exactly $171.0$ cm.
- [ ] Written explanation highlights dimensional reduction, collinearity mitigation, and 2D visualization capability.

**Hints:**
- Remember parentheses: `(mother + father) / 2`.
- Consider how a 2D line plot ($X$ vs $y$) differs from a 3D plane plot ($X_1, X_2$ vs $y$).

**Difficulty:** Basic
**Estimated Completion Time:** 10 minutes

---

## Exercise 1.4: Pipeline Architecture Trace (15 min)
**Objective:** Diagram and verify the flow of data through the machine learning pipeline in `main.py`.
**Problem Statement:** Map each stage of the Height Predictor workflow from the raw CSV file to the exported outputs, identifying the data shapes at each stage.

**Requirements:**
1. List the 5 sequential data transformation stages in `main.py`.
2. State the shape of `df` immediately after loading.
3. State the shape of `X` and `y` after feature engineering and matrix extraction.
4. State the shape of `X_train`, `X_test`, `y_train`, and `y_test` after the 75/25 train/test split.
5. Explain why `X` must have two dimensions while `y` can have one dimension in scikit-learn.

**Constraints:** Base shapes on the actual dataset size of 60 rows in `data/heights.csv`.

**Expected Behaviour:** A cleanly formatted table or numbered list displaying each stage, its corresponding code line, and the resulting tensor/matrix dimensions.

**Acceptance Criteria:**
- [ ] Raw DataFrame shape correctly identified as `(60, 3)`.
- [ ] `X` shape correctly identified as `(60, 1)` and `y` as `(60,)`.
- [ ] `X_train` shape correctly identified as `(45, 1)` and `X_test` as `(15, 1)`.
- [ ] `y_train` shape correctly identified as `(45,)` and `y_test` as `(15,)`.
- [ ] 2D input requirement of scikit-learn estimators clearly explained.

**Hints:**
- Total rows $N = 60$. With `test_size=0.25`, $60 \times 0.25 = 15$ test rows and $60 - 15 = 45$ training rows.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes
