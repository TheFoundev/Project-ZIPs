# Lesson 04: Supervised Regression with Engineered Features

**Lesson ID:** lesson-04
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Formulate an end-to-end machine learning pipeline that integrates feature engineering with supervised regression.
- Trace how data flows from raw CSV rows through pandas transformations into scikit-learn models.
- Explain the role of the training/testing split in biological modeling.
- Understand the complete architectural pipeline implemented in `main.py`.

## Prerequisites
- Completion of Lessons 01, 02, and 03.
- Basic understanding of machine learning training vs testing concepts.

## Concept Explanation

### The Supervised Learning Workflow
In supervised learning, an algorithm learns a mapping function from labeled historical training examples:
$$y = f(X)$$
In our Height Predictor project:
- $X$ is the feature matrix containing our engineered variable: `midparent_cm`.
- $y$ is the target vector containing the ground-truth outcomes: `child_cm`.

Because the target variable is a continuous measurement in centimeters, the task belongs to the family of **regression** algorithms.

### Integrating Feature Engineering into the Pipeline
In classic machine learning, models rarely ingest raw data without preprocessing. Raw data must often be cleaned, normalized, or engineered into more predictive representations. In `main.py`, feature engineering occurs immediately after data loading:

```
[ Raw CSV: mother_cm, father_cm, child_cm ]
                    │
                    ▼
[ Feature Engineering: midparent_cm = (mother + father)/2 ]
                    │
                    ▼
[ Matrix Separation: X = [[midparent_cm]], y = [child_cm] ]
                    │
                    ▼
[ Train/Test Split: 75% Training (45), 25% Testing (15) ]
                    │
                    ▼
[ Model Fitting: LinearRegression.fit(X_train, y_train) ]
                    │
                    ▼
[ Evaluation & Artifacts: MAE, R², Plot, Metrics File ]
```

### Why We Split Biological Data
A common question asked by beginners is: "If we only have 60 families in our dataset, why don't we train the model on all 60 to make it as smart as possible?"

The answer lies in the fundamental rule of machine learning: **never evaluate a model on the same data it was trained on**. If a model merely memorizes the specific heights of training families, it might appear accurate while failing to generalize to new, unseen families. By holding out 25% of the data (15 families) as a test set, we simulate how the model will perform when confronted with brand-new parents in the real world.

## Relevant Code (from main.py, lines 28-42)
```python
def main() -> None:
    df = pd.read_csv(DATA / "heights.csv")
    df["midparent_cm"] = (df["mother_cm"] + df["father_cm"]) / 2
    X = df[["midparent_cm"]]
    y = df["child_cm"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42
    )

    model = LinearRegression()
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
```

## Code Explanation & Walkthrough
Let us examine the operational mechanics of each line:
1. `df = pd.read_csv(...)`: Loads the 60 records into memory.
2. `df["midparent_cm"] = ...`: Performs the feature engineering calculation.
3. `X = df[["midparent_cm"]]`: Creates the 2D feature DataFrame of shape `(60, 1)`.
4. `y = df["child_cm"]`: Creates the 1D target Series of shape `(60,)`.
5. `train_test_split(..., test_size=0.25, random_state=42)`: Randomly shuffles and splits the indices using fixed seed 42. This guarantees 45 families in `X_train`/`y_train` and 15 families in `X_test`/`y_test`.
6. `model = LinearRegression()`: Initializes the Ordinary Least Squares estimator.
7. `model.fit(X_train, y_train)`: Fits the regression line by minimizing the sum of squared residuals strictly on the 45 training families.
8. `predictions = model.predict(X_test)`: Generates predictions for the 15 held-out test families for unbiased evaluation.

## Worked Example
Suppose our 15 test families have an actual average height of $174.2$ cm. 
When we pass `X_test` into `model.predict()`, the model produces 15 corresponding estimates based on each family's `midparent_cm`.
- For a test family with `midparent_cm` = $175.5$ cm:
  $$\hat{y} = 0.8847 \times 175.5 + 21.1747 = 176.44\text{ cm}$$
  If the actual child height in the CSV was $176.9$ cm, the absolute error is:
  $$|176.9 - 176.44| = 0.46\text{ cm}$$
By computing this absolute error across all 15 test families, we obtain our Mean Absolute Error (MAE $\approx 3.1$ cm).

## Step-by-Step Student Instructions
1. Trace the complete execution pipeline in `main.py` from line 28 to line 42.
2. Verify the shapes of `X_train` (`(45, 1)`) and `X_test` (`(15, 1)`).
3. Confirm that the model is fitted exclusively on `(X_train, y_train)`.
4. Identify where feature engineering fits into the broader supervised learning life cycle.
5. Reflect on why evaluating on unseen data is essential for biological models.

## Expected Output or Observable Behaviour
When executed, the pipeline processes the data in fractions of a second, demonstrating the efficiency of vectorized pandas and scikit-learn:
- 60 raw rows loaded.
- 1 engineered feature created.
- Model trained on 45 samples.
- Model evaluated on 15 test samples.
- Clean metrics generated and saved.

## Practical Exercises
- **Exercise 4.1:** What is the split ratio in `main.py`? How many samples are in train versus test?
- **Exercise 4.2:** Why is `random_state=42` used during the split?
- **Exercise 4.3:** What would happen if we called `model.fit(X, y)` before `train_test_split()`? What is this mistake called?

## Common Mistakes and Debugging
| Mistake | Why It Is Wrong | Proper Understanding |
|---|---|---|
| Data Leakage (fitting on all data) | Evaluates the model on examples it has already memorized, artificially deflating error | Always split data first, and call `fit()` only on `X_train` |
| Swapping X and y in train_test_split | Assigns the target to features and vice-versa | Always pass `(X, y)` and unpack into `(X_train, X_test, y_train, y_test)` |
| Omitting random_state in splits | Produces non-reproducible splits where metrics vary on every execution run | Provide an explicit integer seed like `random_state=42` |

## Best Practices and Security Considerations
- **Strict Data Partitioning:** Never allow test set information to contaminate model fitting or feature scaling.
- **Deterministic Experiments:** Always set random seeds in stochastic steps (`train_test_split`) to ensure reproducibility.

## Summary
The Height Predictor project demonstrates a classic supervised learning workflow enriched with domain-specific feature engineering. By transforming maternal and paternal stature into a composite midparent feature and strictly partitioning data into training and test sets, the pipeline models biological trends while guarding against data leakage and overfitting.

## Knowledge-check Questions
1. What does supervised learning require during model training?
2. Why is feature engineering performed before feeding data into the learning algorithm?
3. How many families are allocated to training and testing in a 60-row dataset with `test_size=0.25`?
4. What is data leakage, and how does train/test splitting prevent it?

## References
- Scikit-learn User Guide on Cross-Validation and Data Splitting: https://scikit-learn.org/stable/modules/cross_validation.html
- Raschka, S. (2018). *Model Evaluation, Model Selection, and Algorithm Selection in Machine Learning*. arXiv:1811.12808.
