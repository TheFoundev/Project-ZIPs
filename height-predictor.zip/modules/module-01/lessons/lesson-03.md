# Lesson 03: The Midparent Concept in Human Genetics

**Lesson ID:** lesson-03
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define the "midparent" height concept and explain why it is used in genetics and modeling.
- Understand the biological rationale for combining maternal and paternal heights.
- Differentiate between raw multidimensional inputs and engineered composite features.
- Explain why simple averaging provides a robust baseline for offspring height modeling.

## Prerequisites
- Completion of Lesson 02 (Francis Galton and the Historical Origins of Regression).
- Basic understanding of arithmetic means: $(a + b) / 2$.

## Concept Explanation

### The Problem of Two Parental Heights
When modeling human height, our raw dataset gives us two distinct numbers for each family:
1. `mother_cm`: The height of the biological mother.
2. `father_cm`: The height of the biological father.

A child inherits 50% of their autosomal genetic material from their biological mother and 50% from their biological father. If we want to predict the child's height, we could attempt to treat mother's height and father's height as two separate features. However, in biostatistics, combining both parents into a single representative metric provides substantial advantages:
- It condenses the joint genetic baseline of the household into a single explanatory scale.
- It reduces model complexity and prevents collinearity issues (since tall women often partner with tall men).
- It allows straightforward two-dimensional visualization where parental stature is on the horizontal $X$-axis and child stature is on the vertical $y$-axis.

### Galton's Solution: The Midparent Average
To solve this, Francis Galton introduced the concept of the **midparent**. In its simplest and most intuitive form, midparent height is calculated as the arithmetic average of the two parents:
$$\text{midparent\_cm} = \frac{\text{mother\_cm} + \text{father\_cm}}{2}$$

In `main.py`, line 30 implements this exact feature engineering step:
```python
df["midparent_cm"] = (df["mother_cm"] + df["father_cm"]) / 2
```

### Why Midparenting Works as an Engineered Feature
Feature engineering is the process of creating new informative variables from existing raw data. By creating `midparent_cm`, we transform two columns (`mother_cm` and `father_cm`) into a single synthesized feature that directly represents the mid-point genetic potential of the parents. 

While advanced quantitative genetics sometimes scales the mother's height by a factor of $1.08$ to account for sexual dimorphism (since adult men are on average $\approx 8\%$ taller than adult women), the unweighted average $(mother + father) / 2$ provides a clean, easily interpretable, and mathematically sound baseline for beginner machine learning students.

## Relevant Code (from main.py, lines 29-32)
```python
    df = pd.read_csv(DATA / "heights.csv")
    df["midparent_cm"] = (df["mother_cm"] + df["father_cm"]) / 2
    X = df[["midparent_cm"]]
    y = df["child_cm"]
```

## Code Explanation & Walkthrough
- Line 29 loads the raw CSV data into a pandas DataFrame.
- Line 30 applies vector arithmetic across all 60 rows simultaneously: each row's `mother_cm` and `father_cm` are summed and divided by $2$, creating the new column `midparent_cm`.
- Line 31 isolates the engineered column into our feature matrix `X`. Notice the double brackets `[["midparent_cm"]]`, which preserve a 2D DataFrame structure required by scikit-learn.
- Line 32 isolates the target column `child_cm` as a 1D Series `y`.

## Worked Example
Let us compute `midparent_cm` for three sample families from `data/heights.csv`:

| Family | Mother Height (`mother_cm`) | Father Height (`father_cm`) | Calculation | `midparent_cm` |
|---|---|---|---|---|
| Family 1 | $165.4$ cm | $185.6$ cm | $(165.4 + 185.6) / 2 = 351.0 / 2$ | $175.5$ cm |
| Family 2 | $166.7$ cm | $170.6$ cm | $(166.7 + 170.6) / 2 = 337.3 / 2$ | $168.65$ cm |
| Family 3 | $157.7$ cm | $189.1$ cm | $(157.7 + 189.1) / 2 = 346.8 / 2$ | $173.4$ cm |

Notice how Family 3 has a relatively short mother ($157.7$ cm) but a very tall father ($189.1$ cm). The `midparent_cm` value ($173.4$ cm) captures the combined genetic balance of the pair in a single number.

## Step-by-Step Student Instructions
1. Open the Python interpreter or a Jupyter notebook.
2. Create a test DataFrame with `mother_cm = [160, 170]` and `father_cm = [180, 185]`.
3. Compute `(df["mother_cm"] + df["father_cm"]) / 2` and verify the output series.
4. Explain to a peer why using `midparent_cm` allows us to plot a single 2D line graph rather than needing a 3D surface plot.
5. Identify any potential nuances lost when collapsing two numbers into one average (e.g., whether parent sex differences matter).

## Expected Output or Observable Behaviour
When pandas computes the column, every row receives a floating-point number representing the parental midpoint:
```python
>>> df[["mother_cm", "father_cm", "midparent_cm"]].head(2)
   mother_cm  father_cm  midparent_cm
0      165.4      185.6        175.50
1      166.7      170.6        168.65
```
This new column becomes the sole predictor feature `X` fed into `LinearRegression()`.

## Practical Exercises
- **Exercise 3.1:** Calculate the midparent height for a mother of $162.0$ cm and a father of $178.0$ cm.
- **Exercise 3.2:** What is the dimensionality of `X` when using `midparent_cm` versus using both `mother_cm` and `father_cm`?
- **Exercise 3.3:** Why is dimensionality reduction through feature engineering helpful for visualizing relationships?

## Common Mistakes and Debugging
| Mistake | Why It Is Wrong | Proper Understanding |
|---|---|---|
| Forgetting parentheses: `mother + father / 2` | Due to operator precedence, division occurs before addition: $mother + (father / 2)$ | Always write `(df["mother_cm"] + df["father_cm"]) / 2` |
| Using single brackets for `X`: `X = df["midparent_cm"]` | Returns a 1D Series of shape `(N,)`, which breaks scikit-learn's 2D input expectation | Use double brackets `X = df[["midparent_cm"]]` to produce shape `(N, 1)` |
| Overwriting raw data columns | Destroys original maternal and paternal measurements | Create a new descriptive column name: `df["midparent_cm"]` |

## Best Practices and Security Considerations
- **Non-Destructive Feature Engineering:** Always preserve the raw columns in your DataFrame so you can revisit, validate, or engineer alternative features later.
- **Explicit Parentheses:** Always use explicit grouping parentheses in algebraic column operations to guarantee intended calculation order.

## Summary
The midparent concept synthesizes maternal and paternal stature into a single representative metric. As an engineered feature, `midparent_cm` captures the shared biological inheritance of offspring while simplifying the regression problem into a 2D line fitting task suitable for clear interpretation and visualization.

## Knowledge-check Questions
1. What is the mathematical formula for unweighted midparent height?
2. What are two advantages of combining two parental heights into a single feature?
3. Why must we use double brackets `df[["midparent_cm"]]` when creating `X`?
4. How does operator precedence affect the calculation if parentheses are omitted?

## References
- Galton, F. (1886). "Family Likeness in Stature." Proceedings of the Royal Society of London.
- Pandas Documentation on Series Vectorized Arithmetic: https://pandas.pydata.org/docs/user_guide/dsintro.html
