# Lesson 02: Francis Galton and the Historical Origins of Regression

**Lesson ID:** lesson-02
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Trace the historical origins of linear regression to Sir Francis Galton's 1886 study of hereditary stature.
- Explain the concept of "regression to the mean" (originally termed "regression towards mediocrity").
- Understand why extreme parental traits typically result in less extreme offspring traits.
- Connect historical biometrics to modern machine learning regression models.

## Prerequisites
- Completion of Lesson 01 (The Height Prediction Problem & Medical Disclaimer).
- Understanding of basic arithmetic averages and Cartesian coordinates.

## Concept Explanation

### The Birth of the Term "Regression"
Today, every machine learning practitioner uses terms like "logistic regression", "polynomial regression", and "linear regression". But few realize that the word **regression** entered the vocabulary of mathematics specifically because of the study of human height!

In 1886, British polymath Sir Francis Galton published a landmark paper titled *"Regression Towards Mediocrity in Hereditary Stature"*. Galton wanted to understand how physical traits were transmitted across generations. He collected heights from hundreds of parents and their adult children. 

### What Did Galton Discover?
Galton noticed a remarkable pattern:
- Parents who were exceptionally tall tended to have children who were tall, but **not quite as tall** as their parents.
- Parents who were exceptionally short tended to have children who were short, but **not quite as short** as their parents.
- The heights of the offspring tended to move ("regress") back toward the average ("mediocrity", meaning the median or mean) of the population!

If tall parents produced children who were even taller, and short parents produced children who were even shorter, human heights would rapidly diverge over generations into giants and dwarfs. Instead, population height distributions remain stable over time because offspring stature regresses toward the population center.

### Mathematical Manifestation: Slope Less Than 1.0
In a purely hereditary world where children perfectly mirrored parental deviations, the relationship between parental stature and offspring stature would have a slope of exactly $1.0$:
$$\Delta \text{child} = 1.0 \times \Delta \text{parents}$$

However, Galton discovered that when plotting offspring height against parental height, the slope of the best-fit line was significantly less than $1.0$ (typically around $0.6$ to $0.88$ depending on data standardization and gender corrections). A slope less than $1.0$ means that for every additional centimeter a parent is above the population average, the child is only predicted to be a fraction of a centimeter above average!

## Relevant Code (from main.py, lines 44-53)
```python
    slope = float(model.coef_[0])
    intercept = float(model.intercept_)
    example = float(model.predict(pd.DataFrame({"midparent_cm": [170.0]}))[0])

    print("=" * 60)
    print("HOW TALL WILL YOU BE?")
    print("=" * 60)
    print(f"Model: child height = {slope:.2f} x midparent height + {intercept:.2f}")
    print(f"Mean absolute error: {mae:.1f} cm")
    print(f"R-squared: {r2:.2f}")
```

## Code Explanation & Walkthrough
When you run `main.py`, scikit-learn computes the Ordinary Least Squares line through our dataset. The resulting slope is:
$$\text{slope} = 0.88$$
And the intercept is:
$$\text{intercept} = 21.17$$

Because the slope ($0.88$) is strictly less than $1.0$, our trained model directly exhibits Galton's regression to the mean! The positive intercept ($+21.17$ cm) provides the upward counterbalance that lifts the offspring of shorter parents, while the slope below $1.0$ compresses the offspring of tall parents down toward the overall mean.

## Worked Example
Let us examine what this slope of $0.88$ and intercept of $21.17$ does across two contrasting families:

1. **Very Tall Parents:** Midparent height = $185.0$ cm (well above average).
   $$\text{Child} = 0.8847 \times 185.0 + 21.1747 = 163.67 + 21.17 = 184.84\text{ cm}$$
   The child is predicted to be tall ($184.8$ cm), but slightly closer to the population average than the $185.0$ cm parents.

2. **Shorter Parents:** Midparent height = $160.0$ cm (well below average).
   $$\text{Child} = 0.8847 \times 160.0 + 21.1747 = 141.55 + 21.17 = 162.72\text{ cm}$$
   The child is predicted to be taller ($162.7$ cm) than the parents ($160.0$ cm), pulling back upward toward the average!

This is the living mathematical definition of regression to the mean.

## Step-by-Step Student Instructions
1. Review Galton's 1886 findings on parental and child heights.
2. Note that the word "regression" in statistics originated from Galton's paper.
3. Open `main.py` and inspect lines 44–45 where `model.coef_[0]` and `model.intercept_` are extracted.
4. Calculate manually what a slope of $1.0$ would imply versus a slope of $0.88$.
5. Verify why human height distributions remain stable rather than splitting into extreme extremes over generations.

## Expected Output or Observable Behaviour
When observing the output of `main.py`:
```
Model: child height = 0.88 x midparent height + 21.17
```
Students can verify that the slope ($0.88$) is less than $1.0$, mathematically proving that the model captures regression to the mean rather than divergence.

## Practical Exercises
- **Exercise 2.1:** What historical biometric phenomenon inspired the term "regression" in statistics?
- **Exercise 2.2:** If a regression line had a slope of $1.3$, would that represent regression to the mean or divergence from the mean? Explain.
- **Exercise 2.3:** Calculate the predicted height of a child whose midparent height is $190$ cm using $0.88 \times 190 + 21.17$. Is the child taller or shorter than the parents?

## Common Mistakes and Debugging
| Mistake | Why It Is Wrong | Proper Understanding |
|---|---|---|
| Assuming slope must equal 1.0 for biological traits | A slope of 1.0 ignores polygenic mixing and environmental regression | Slopes < 1.0 are universal in polygenic biological trait inheritance |
| Believing "regression to mediocrity" means becoming inferior | Galton used "mediocrity" in its 19th-century meaning of the arithmetic median/middle | It simply means moving closer to the population average |
| Expecting every individual child to match the trend line | Individual outcomes vary due to genetic recombination and lifestyle | Regression lines describe the expected average trend across populations |

## Best Practices and Security Considerations
- **Historical Context:** Appreciate that historical scientific terms often have specific historical meanings that differ from modern colloquial slang.
- **Interpretability:** In linear models, always inspect whether the learned slope aligns with established domain theory (such as biometrics).

## Summary
Sir Francis Galton founded regression analysis in 1886 by observing that adult children's heights regress toward the population mean. In machine learning, this biological phenomenon is reflected whenever the regression slope is less than $1.0$, ensuring that extreme parental traits produce moderate, balanced offspring estimates.

## Knowledge-check Questions
1. Who published the 1886 paper that introduced the term "regression" to mathematics?
2. What happens to the predicted height of children born to exceptionally tall parents?
3. What mathematical condition on the slope indicates regression to the mean?
4. Why don't human heights diverge into extremes over successive generations?

## References
- Galton, F. (1886). "Regression Towards Mediocrity in Hereditary Stature." Journal of the Anthropological Institute.
- Stigler, S. M. (1986). *The History of Statistics: The Measurement of Uncertainty before 1900*. Harvard University Press.
