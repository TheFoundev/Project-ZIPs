# Module 2 Exercises: Data & Feature Engineering

## Exercise 2.1: Dataset Structure and Metadata Inspection (10 min)
**Objective:** Programmatically audit `data/heights.csv` to verify data types, row counts, and absence of missing values.
**Problem Statement:** You have been tasked with validating the integrity of the raw input file before any model training begins. Write a script to load `data/heights.csv` and report essential dataset properties.

**Requirements:**
1. Load `data/heights.csv` using pandas.
2. Verify that the DataFrame has exactly 60 rows and 3 columns.
3. Check that there are zero missing (`NaN`) values in all columns.
4. Print the data types of all columns.

**Constraints:** Use pandas methods (`shape`, `isna()`, `dtypes`). Do not modify the original CSV file.

**Expected Behaviour:** Printout confirming row count, column count, zero missing values, and float64 data types.

**Acceptance Criteria:**
- [ ] Confirms exact shape is `(60, 3)`.
- [ ] Confirms `df.isna().sum().sum() == 0`.
- [ ] Confirms all three columns have dtype `float64`.
- [ ] Uses Pathlib for path handling.

**Hints:**
- Use `df.isna().sum()` to count nulls per column.

**Difficulty:** Basic
**Estimated Completion Time:** 10 minutes

---

## Exercise 2.2: Implementing Vectorized Feature Engineering (15 min)
**Objective:** Compute the `midparent_cm` column using vectorized pandas arithmetic and verify calculation bounds.
**Problem Statement:** Engineer the `midparent_cm` feature by averaging maternal and paternal statures, and implement a logical check confirming that each value falls between the parents' heights.

**Requirements:**
1. Add a new column `df["midparent_cm"] = (df["mother_cm"] + df["father_cm"]) / 2`.
2. Verify that the new column exists and that the DataFrame shape is now `(60, 4)`.
3. Assert that for every row, `midparent_cm` is greater than or equal to the minimum of the two parents and less than or equal to the maximum.

**Constraints:** Use vectorized Series operations. Do not use Python `for` loops or `.iterrows()`.

**Expected Behaviour:** A clean pandas script that creates the column and prints an assertion confirmation.

**Acceptance Criteria:**
- [ ] Uses explicit grouping parentheses in `(df["mother_cm"] + df["father_cm"]) / 2`.
- [ ] Validates that all 60 rows satisfy the between-parents condition.
- [ ] Verifies the column name is exactly `"midparent_cm"`.

**Hints:**
- You can find the row-wise min using `df[["mother_cm", "father_cm"]].min(axis=1)`.

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 2.3: Computing Summary Statistics and Variance Comparison (15 min)
**Objective:** Compare the standard deviation of raw parent columns with the engineered midparent column.
**Problem Statement:** Calculate descriptive statistics for `mother_cm`, `father_cm`, and `midparent_cm`. Explain mathematically why the standard deviation of the average is lower than the individual parents.

**Requirements:**
1. Compute the mean and standard deviation for `mother_cm`, `father_cm`, and `midparent_cm`.
2. Compare the standard deviation of `midparent_cm` (~3.71 cm) to the parents (~4.92 cm and ~5.15 cm).
3. Write a 2–3 sentence explanation explaining why averaging two independent or weakly correlated variables reduces variance.

**Constraints:** Use `df.describe()` or `.std()`.

**Expected Behaviour:** A table of means and standard deviations followed by a concise mathematical explanation.

**Acceptance Criteria:**
- [ ] Accurately reports means: Mother ~164.79 cm, Father ~179.95 cm, Midparent ~172.37 cm.
- [ ] Accurately reports standard deviations: Mother ~4.92 cm, Father ~5.15 cm, Midparent ~3.71 cm.
- [ ] Correctly identifies variance reduction from averaging random variables.

**Hints:**
- $\text{Var}((X+Y)/2) = (\text{Var}(X) + \text{Var}(Y) + 2\text{Cov}(X,Y)) / 4$.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 2.4: Correlation Analysis of Engineered vs Raw Features (20 min)
**Objective:** Compute the correlation matrix and demonstrate that feature engineering increased the correlation with the target.
**Problem Statement:** Evaluate whether combining `mother_cm` and `father_cm` into `midparent_cm` produced a feature with a stronger linear correlation to `child_cm` than the raw parental features.

**Requirements:**
1. Calculate the Pearson correlation matrix using `df.corr()`.
2. Extract the correlation of `mother_cm` with `child_cm` ($r_1$).
3. Extract the correlation of `father_cm` with `child_cm` ($r_2$).
4. Extract the correlation of `midparent_cm` with `child_cm` ($r_3$).
5. Compare $r_3$ to $r_1$ and $r_2$, and explain why feature engineering produced a superior predictor.

**Constraints:** Use `df.corr()`. Round correlation values to 2 decimal places.

**Expected Behaviour:** Programmatic output displaying the three correlation values and an analytical conclusion.

**Acceptance Criteria:**
- [ ] Mother-child correlation correctly identified as approximately 0.54.
- [ ] Father-child correlation correctly identified as approximately 0.54.
- [ ] Midparent-child correlation correctly identified as approximately 0.73.
- [ ] Explanation notes that combining both genetic contributors reduces independent noise and enhances predictive signal.

**Hints:**
- Look at the `child_cm` column in the correlation matrix.

**Difficulty:** Intermediate
**Estimated Completion Time:** 20 minutes
