# Lesson 01: Inspecting heights.csv and Dataset Structure

**Lesson ID:** lesson-01
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Navigate and inspect the raw structure of `data/heights.csv`.
- Identify the three primary numerical columns: `mother_cm`, `father_cm`, and `child_cm`.
- Verify row counts, missing values, and data types using pandas.
- Understand the physical units and measurement integrity of the dataset.

## Prerequisites
- Basic familiarity with CSV (comma-separated values) files.
- Understanding of Python file paths and pandas `read_csv()`.

## Concept Explanation

### The Raw Dataset: heights.csv
Every machine learning project begins with data ingestion and audit. In `09_height_predictor`, our data lives in `data/heights.csv`. Before fitting any mathematical model or computing derived features, a practitioner must inspect the raw file to answer critical questions:
- What delimiter separates values (commas, tabs, semicolons)?
- Is there a header row specifying column names?
- How many family observations exist?
- What physical units are used (inches, feet, meters, centimeters)?
- Are there missing, corrupted, or biologically impossible values?

Opening `data/heights.csv` reveals a clean, standardized format:
```csv
mother_cm,father_cm,child_cm
165.4,185.6,176.9
166.7,170.6,168.4
157.7,189.1,174.3
...
```

### Column Definitions
1. **`mother_cm`**: Floating-point value recording the standing height of the biological mother in centimeters. Typically ranges between $150$ cm and $175$ cm.
2. **`father_cm`**: Floating-point value recording the standing height of the biological father in centimeters. Typically ranges between $168$ cm and $192$ cm.
3. **`child_cm`**: Floating-point value recording the adult standing height of their child in centimeters. Typically ranges between $162$ cm and $184$ cm.

### Data Dimensions and Integrity
The dataset contains exactly 60 rows of family measurements (plus the header row, making 61 lines total). Sixty observations represent a small, focused teaching dataset. In large-scale genomic studies, researchers might study hundreds of thousands of individuals, but a 60-family dataset provides an ideal sandbox for learning the fundamentals of feature engineering and linear regression without overwhelming computing resources.

All values are recorded in metric centimeters (`cm`). Using metric centimeters provides significant advantages over imperial units (feet and inches) because it avoids awkward base-12 fractions and provides a continuous decimal scale where $1$ mm corresponds to $0.1$ cm.

## Relevant Code (from main.py, lines 22-29)
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)


def main() -> None:
    df = pd.read_csv(DATA / "heights.csv")
```

## Code Explanation & Walkthrough
In lines 22–24, `Path(__file__).resolve().parent` establishes the absolute directory containing `main.py`. This ensures that `DATA / "heights.csv"` resolves reliably regardless of which directory the user was located in when invoking `python main.py`.

Inside `main()`, `pd.read_csv()` reads the file into a pandas DataFrame object named `df`. Pandas automatically parses the header row, infers that all three columns contain 64-bit floating point numbers (`float64`), and indexes the 60 rows from index `0` to index `59`.

## Worked Example
Let us load the dataset using a Python snippet and verify its metadata:
```python
import pandas as pd
from pathlib import Path

df = pd.read_csv("data/heights.csv")

print("Dataset shape:", df.shape)
print("
First 3 rows:")
print(df.head(3))
print("
Column Data Types:")
print(df.dtypes)
```

**Output:**
```
Dataset shape: (60, 3)

First 3 rows:
   mother_cm  father_cm  child_cm
0      165.4      185.6     176.9
1      166.7      170.6     168.4
2      157.7      189.1     174.3

Column Data Types:
mother_cm    float64
father_cm    float64
child_cm     float64
dtype: object
```
Notice that `df.shape` returns a tuple `(60, 3)`: 60 sample records and 3 features. There are no null or non-numeric entries.

## Step-by-Step Student Instructions
1. Open a terminal and navigate to the project directory.
2. View the first 10 lines of the dataset using `head -n 10 data/heights.csv`.
3. Launch an interactive Python session and import pandas.
4. Load the dataset with `df = pd.read_csv("data/heights.csv")`.
5. Check `df.info()` to verify non-null counts and memory usage.
6. Verify that all values are positive numbers within realistic biological human ranges (between $140$ cm and $210$ cm).

## Expected Output or Observable Behaviour
Calling `df.describe()` produces summary statistics for all three columns:
```
       mother_cm  father_cm   child_cm
count  60.000000  60.000000  60.000000
mean  164.788333 179.948333 173.811667
std     4.921382   5.153406   4.631899
min   151.100000 168.500000 162.200000
max   174.900000 191.800000 183.700000
```
This confirms that average mothers are $\approx 164.8$ cm, average fathers are $\approx 179.9$ cm, and average offspring are $\approx 173.8$ cm.

## Practical Exercises
- **Exercise 1.1:** How many total data rows are in `heights.csv` excluding the header?
- **Exercise 1.2:** What are the exact column names present in the raw CSV?
- **Exercise 1.3:** If one of the rows had a `child_cm` value of $450.0$, what kind of data issue would that represent and how should a data scientist address it?

## Common Mistakes and Debugging
| Mistake | Why It Is Wrong | Proper Understanding |
|---|---|---|
| Hardcoding string paths: `"data/heights.csv"` | Fails with FileNotFoundError if executed from another folder | Use `Path(__file__).resolve().parent / "data" / "heights.csv"` |
| Forgetting to check data types | Non-numeric characters (e.g. "175cm") force object type and crash regression | Always inspect `df.dtypes` to confirm numeric types |
| Assuming rows represent individual unrelated people | Each row represents an interrelated family unit (mother, father, child) | Tabular rows capture paired genetic relationships |

## Best Practices and Security Considerations
- **Data Validation at Ingestion:** Always check row counts and missing value counts (`df.isna().sum()`) before proceeding.
- **Explicit Encoding:** Specify `encoding="utf-8"` when reading text and CSV files on platforms with non-standard defaults.

## Summary
The `heights.csv` file provides 60 clean, consistent family height observations measured in centimeters. Each record pairs the standing heights of a biological mother and father with their adult child, establishing the foundation for feature engineering and regression modeling.

## Knowledge-check Questions
1. How many columns are in `data/heights.csv` upon initial loading?
2. What physical unit of measurement is used for all height variables?
3. What pandas method reports the number of rows and columns as a tuple?
4. What is the average height of fathers in this dataset?

## References
- Pandas CSV Parsing Documentation: https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html
- Python pathlib Module Reference: https://docs.python.org/3/library/pathlib.html
