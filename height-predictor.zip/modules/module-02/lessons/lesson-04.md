# Lesson 04: Exploratory Data Analysis & Summary Distributions

**Lesson ID:** lesson-04
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Perform exploratory data analysis (EDA) on the family height dataset.
- Calculate and interpret descriptive statistics: mean, standard deviation, minimum, and maximum.
- Analyze the correlation between parental stature and offspring height.
- Identify distribution patterns and biological spread in biometric data.

## Prerequisites
- Completion of Lessons 01, 02, and 03.
- Familiarity with basic descriptive statistics (mean and standard deviation).

## Concept Explanation

### The Purpose of Exploratory Data Analysis
Before fitting any predictive machine learning model, a data scientist must explore the dataset's statistical properties. Exploratory Data Analysis (EDA) answers fundamental questions:
- What is the central tendency (mean and median) of our features and target?
- What is the dispersion or spread (standard deviation and interquartile range)?
- Are there obvious outliers or data collection errors?
- How strongly are the predictor feature and target correlated?

### Summary Statistics of heights.csv
When we load `data/heights.csv` and compute `midparent_cm`, we can compute descriptive statistics using `df.describe()`:

| Metric | `mother_cm` | `father_cm` | `midparent_cm` | `child_cm` |
|---|---|---|---|---|
| **Count** | $60.0$ | $60.0$ | $60.0$ | $60.0$ |
| **Mean** | $164.79$ cm | $179.95$ cm | $172.37$ cm | $173.81$ cm |
| **Std Dev** | $4.92$ cm | $5.15$ cm | $3.71$ cm | $4.63$ cm |
| **Min** | $151.10$ cm | $168.50$ cm | $164.30$ cm | $162.20$ cm |
| **25%** | $162.28$ cm | $176.42$ cm | $169.80$ cm | $170.58$ cm |
| **50% (Median)**| $165.20$ cm | $180.60$ cm | $172.48$ cm | $173.90$ cm |
| **75%** | $168.08$ cm | $183.70$ cm | $175.11$ cm | $177.10$ cm |
| **Max** | $174.90$ cm | $191.80$ cm | $180.85$ cm | $183.70$ cm |

### Key Observations from the Distributions
Several critical biological insights emerge from this statistical profile:
1. **Sexual Dimorphism in Parents:** The mean father height ($179.95$ cm) is approximately $15.16$ cm taller than the mean mother height ($164.79$ cm). This represents the natural biological difference in adult stature between sexes.
2. **Variance Reduction in the Average:** Notice the standard deviation:
   - Mother std dev: $4.92$ cm
   - Father std dev: $5.15$ cm
   - Midparent std dev: **$3.71$ cm**!
   Averaging two random variables reduces their overall standard deviation:
   $$\sigma_{\text{average}} \approx \frac{\sigma}{\sqrt{2}}$$
   This statistical smoothing stabilizes our predictor feature.
3. **Alignment of Means:** The mean midparent height ($172.37$ cm) and the mean child height ($173.81$ cm) are remarkably close (within $1.44$ cm). This tells us that the generations have roughly comparable population averages.

### Correlation Analysis
Using `df.corr()`, we can measure the Pearson correlation coefficient between `midparent_cm` and `child_cm`:
$$r \approx 0.73$$
A correlation of $+0.73$ indicates a strong, positive, linear relationship: taller parents generally have taller children. When squared ($r^2 = 0.73^2 \approx 0.533$), it gives an immediate preview of the $R^2$ score our regression model will achieve!

## Relevant Code (from main.py, lines 29-33)
```python
def main() -> None:
    df = pd.read_csv(DATA / "heights.csv")
    df["midparent_cm"] = (df["mother_cm"] + df["father_cm"]) / 2
    X = df[["midparent_cm"]]
    y = df["child_cm"]
```

## Code Explanation & Walkthrough
While `main.py` proceeds directly from data preparation to model fitting, exploring the dataset interactively is crucial for understanding why linear regression succeeds. The strong positive Pearson correlation ($r \approx 0.73$) mathematically justifies fitting a straight line through the data points.

## Worked Example
Let us compute the correlation matrix across all four columns:
```python
import pandas as pd

df = pd.read_csv("data/heights.csv")
df["midparent_cm"] = (df["mother_cm"] + df["father_cm"]) / 2

print("Correlation Matrix:")
print(df.corr().round(2))
```

**Output:**
```
Correlation Matrix:
              mother_cm  father_cm  child_cm  midparent_cm
mother_cm          1.00       0.11      0.54          0.74
father_cm          0.11       1.00      0.54          0.74
child_cm           0.54       0.54      1.00          0.73
midparent_cm       0.74       0.74      0.73          1.00
```
Notice that individually, `mother_cm` and `father_cm` each have a correlation of $0.54$ with `child_cm`. But when combined into `midparent_cm`, the correlation with `child_cm` jumps to **$0.73$**! This provides mathematical proof that our feature engineering created a stronger predictor than either individual parent alone.

## Step-by-Step Student Instructions
1. Load the dataset and create the `midparent_cm` column.
2. Call `df.describe()` and examine the mean, std, min, and max for each column.
3. Compute the correlation matrix with `df.corr()`.
4. Compare the correlation of `mother_cm` vs `child_cm` ($0.54$) and `father_cm` vs `child_cm` ($0.54$) against `midparent_cm` vs `child_cm` ($0.73$).
5. Document why feature engineering boosted the correlation with the target.

## Expected Output or Observable Behaviour
Students observe that `midparent_cm` exhibits a higher correlation with `child_cm` than either parent individually. This demonstrates that combining multiple noisy indicators of a latent biological trait (parental genetics) reduces measurement noise and enhances predictive signal.

## Practical Exercises
- **Exercise 4.1:** Why is the standard deviation of `midparent_cm` ($3.71$ cm) smaller than that of `mother_cm` ($4.92$ cm) and `father_cm` ($5.15$ cm)?
- **Exercise 4.2:** What is the Pearson correlation between `midparent_cm` and `child_cm`?
- **Exercise 4.3:** If mother and father heights had a correlation of $0.90$ with each other, what real-world phenomenon would that describe?

## Common Mistakes and Debugging
| Mistake | Why It Is Wrong | Proper Understanding |
|---|---|---|
| Skipping EDA and jumping straight to model training | Leaves data anomalies, extreme outliers, or unit errors unnoticed | Always inspect distributions and correlations before training |
| Confusing correlation with causation | A correlation of 0.73 shows association, not complete causal determination | Height is influenced by many unmeasured environmental factors |
| Expecting R² to be 1.0 because correlation is positive | Correlation < 1.0 means residuals will exist around the line | Real biological data has variance that linear lines cannot fully capture |

## Best Practices and Security Considerations
- **Summary Validation:** Always check that minimums and maximums are biologically reasonable before proceeding to modeling.
- **Correlation Inspection:** Verify that predictor features actually correlate with the target variable before attempting regression.

## Summary
Exploratory data analysis demonstrates that maternal and paternal heights exhibit clear sexual dimorphism, and that averaging them into `midparent_cm` reduces variance while increasing correlation with child height ($r \approx 0.73$). This empirical evidence confirms the value of feature engineering prior to linear regression.

## Knowledge-check Questions
1. What is the approximate mean height for mothers and fathers in `heights.csv`?
2. Why is the standard deviation of midparent height smaller than the standard deviation of either parent alone?
3. What is the correlation between `midparent_cm` and `child_cm`?
4. How does the correlation of the engineered feature compare to the raw parental correlations?

## References
- Tukey, J. W. (1977). *Exploratory Data Analysis*. Addison-Wesley.
- Pandas DataFrame.describe Documentation: https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.describe.html
