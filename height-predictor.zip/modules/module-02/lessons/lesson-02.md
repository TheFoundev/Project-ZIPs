# Lesson 02: Principles of Feature Engineering in Machine Learning

**Lesson ID:** lesson-02
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define feature engineering and distinguish it from raw data collection.
- Explain why combining features using domain knowledge improves model simplicity and interpretability.
- Understand the biological and mathematical motivations for synthesizing parental heights into a single metric.
- Contrast automated feature learning with domain-driven manual feature engineering.

## Prerequisites
- Completion of Lesson 01 (Inspecting heights.csv and Dataset Structure).
- Conceptual understanding of features and model complexity.

## Concept Explanation

### What is Feature Engineering?
In raw machine learning workflows, algorithms receive data in whatever format it was recorded. However, raw data is rarely optimal for linear models. **Feature engineering** is the art and science of transforming raw features, combining multiple variables, or deriving new representations using domain knowledge to help learning algorithms uncover meaningful patterns.

Renowned machine learning scientist Andrew Ng frequently noted:
> "Coming up with features is difficult, time-consuming, requires expert knowledge. 'Applied machine learning' is basically feature engineering."

### Why Combine Mother and Father Heights?
In `heights.csv`, we are provided with two raw features: `mother_cm` and `father_cm`. Why not simply throw both raw features into a multiple linear regression model?

While multiple regression (using two separate features $X_1 = \text{mother}$ and $X_2 = \text{father}$) is entirely valid, engineering a single combined feature provides distinct advantages in beginner data science:

1. **Biological Symmetry:** Mendelian genetics tells us that an offspring receives 50% of autosomal chromosomes from the mother and 50% from the father. Treating them as an equal average reflects this foundational biological symmetry.
2. **Collinearity Mitigation:** In human societies, assortative mating often occurs (taller individuals frequently marry taller partners). When two predictor features are correlated, multiple regression models can suffer from multicollinearity, making individual slope weights unstable. Combining them into one metric stabilizes the estimate.
3. **Simplicity and Interpretability:** A single composite predictor allows us to plot a standard 2D Cartesian graph with parent height on the $X$-axis and child height on the $y$-axis. Visualizing a 2D line is far more intuitive than visualizing a 3D regression plane.

### The Midparent Synthesis
By taking the arithmetic average of both parents:
$$\text{midparent} = \frac{\text{mother} + \text{father}}{2}$$
we distill two numbers into a single representative index of the household's genetic stature. We have compressed dimensionality from $2$ dimensions to $1$ dimension while preserving the essential biological signal!

## Relevant Code (from main.py, lines 29-31)
```python
    df = pd.read_csv(DATA / "heights.csv")
    df["midparent_cm"] = (df["mother_cm"] + df["father_cm"]) / 2
    X = df[["midparent_cm"]]
```

## Code Explanation & Walkthrough
In line 30, feature engineering is accomplished in a single vectorized statement. We do not write a slow Python `for` loop over the rows. Instead, pandas performs column-wise vector addition between `df["mother_cm"]` and `df["father_cm"]`, then divides every sum by $2$. 

Immediately after this transformation, line 31 selects only `midparent_cm` into `X`. Notice what happened: although the raw CSV had two parent columns, our machine learning model will never see `mother_cm` or `father_cm` directly! The model operates strictly on our newly engineered feature.

## Worked Example
Let us trace what happens to two families with different individual parent statures:

- **Family Alpha:** Mother = $160$ cm, Father = $180$ cm.
  $$\text{midparent} = (160 + 180) / 2 = 170.0\text{ cm}$$
- **Family Beta:** Mother = $170$ cm, Father = $170$ cm.
  $$\text{midparent} = (170 + 170) / 2 = 170.0\text{ cm}$$

Notice that both families have identical midparent stature ($170.0$ cm). Under our engineered feature assumption, both families provide the exact same baseline genetic signal to their offspring. This illustrates the simplifying assumption of feature engineering: minor discrepancies between individual parental heights are smoothed into an overall parental mean.

## Step-by-Step Student Instructions
1. Consider the difference between raw features (directly observed) and engineered features (derived through computation).
2. Write down three examples of feature engineering from daily life (e.g., calculating Body Mass Index from height and weight, calculating speed from distance and time).
3. Review line 30 of `main.py` and identify which columns are combined.
4. Reflect on how feature engineering leverages biological domain knowledge.
5. Consider the trade-off: what information is lost when we combine mother and father heights into a single average?

## Expected Output or Observable Behaviour
When feature engineering is executed, the DataFrame schema expands from 3 columns to 4 columns:
```python
>>> df.columns.tolist()
['mother_cm', 'father_cm', 'child_cm', 'midparent_cm']
```
The original columns remain intact for inspection, while the new engineered column is ready for modeling.

## Practical Exercises
- **Exercise 2.1:** Define feature engineering in your own words.
- **Exercise 2.2:** What biological rationale justifies giving equal weight (50% and 50%) to mother and father heights?
- **Exercise 2.3:** Give an example of a situation where combining two features into one might lose valuable information.

## Common Mistakes and Debugging
| Mistake | Why It Is Wrong | Proper Understanding |
|---|---|---|
| Dropping raw columns immediately | Prevents error checking or comparing engineered models with raw models | Keep raw columns in the DataFrame; select only desired features into `X` |
| Calling feature engineering "data cleaning" | Cleaning fixes errors/nulls; engineering creates new informative signals | Feature engineering adds new derived features from clean data |
| Feeding both raw features AND midparent into X | Introduces perfect collinearity ($X_3 = (X_1 + X_2)/2$), destabilizing regression | Use either the engineered feature OR the raw features, not both simultaneously |

## Best Practices and Security Considerations
- **Domain-Driven Design:** Always base feature engineering decisions on domain logic (e.g., genetics, physics, economics) rather than arbitrary mathematical combinations.
- **Preserve Source Data:** Never overwrite or mutate raw input columns during feature engineering.

## Summary
Feature engineering allows practitioners to transform raw measurements into more powerful, interpretable representations. In the Height Predictor project, synthesizing maternal and paternal heights into `midparent_cm` condenses parental genetics into a single, intuitive dimension suitable for 2D visualization and linear regression.

## Knowledge-check Questions
1. What is the formal definition of feature engineering?
2. Why is midparent height considered an engineered feature rather than a raw feature?
3. What biological principle justifies an equal 50/50 average between parents?
4. What happens if you include mother_cm, father_cm, and midparent_cm simultaneously in linear regression?

## References
- Zheng, A., & Casari, A. (2018). *Feature Engineering for Machine Learning*. O'Reilly Media.
- Scikit-learn Feature Extraction Guide: https://scikit-learn.org/stable/modules/feature_extraction.html
