# Lesson 03: Computing midparent_cm with pandas Series Operations

**Lesson ID:** lesson-03
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Write vectorized pandas arithmetic expressions to compute derived columns.
- Explain the performance advantages of vectorized operations over Python iterative loops.
- Avoid common mathematical operator precedence bugs in column transformations.
- Verify the numerical accuracy of engineered features.

## Prerequisites
- Completion of Lesson 02 (Principles of Feature Engineering in Machine Learning).
- Basic understanding of Python operator precedence (`+` vs `/`).

## Concept Explanation

### Vectorized Arithmetic in Pandas
In standard Python, if you have two lists of numbers and wish to calculate their pairwise average, you must write a list comprehension or a `for` loop:
```python
# Slow Python loop approach
midparent = []
for m, f in zip(mothers, fathers):
    midparent.append((m + f) / 2)
```

While functional for 60 numbers, this iterative approach is slow and unidiomatic in data science. Pandas operates on entire **Series** using vectorized C/NumPy implementations under the hood. When you write:
```python
df["midparent_cm"] = (df["mother_cm"] + df["father_cm"]) / 2
```
Pandas executes the operation across the entire contiguous memory block simultaneously.

### The Importance of Operator Precedence
A classic programming trap in arithmetic calculations involves operator precedence (often remembered by the acronym PEMDAS: Parentheses, Exponents, Multiplication/Division, Addition/Subtraction).

In Python:
- Division (`/`) has higher precedence than addition (`+`).
- If a programmer mistakenly writes:
  ```python
  # BUG: Division happens before addition!
  df["midparent_cm"] = df["mother_cm"] + df["father_cm"] / 2
  ```
  Python will divide `df["father_cm"]` by $2$ first, and then add `df["mother_cm"]` to the result!

Let us see the disastrous effect on Family 1 ($mother = 165.4$, $father = 185.6$):
- **Correct with Parentheses:** $(165.4 + 185.6) / 2 = 351.0 / 2 = 175.5$ cm.
- **Incorrect without Parentheses:** $165.4 + (185.6 / 2) = 165.4 + 92.8 = 258.2$ cm!

A midparent height of $258.2$ cm ($8$ feet $5$ inches) is biologically impossible and would completely ruin any regression model. Explicit grouping parentheses are mandatory.

## Relevant Code (from main.py, line 30)
```python
    df["midparent_cm"] = (df["mother_cm"] + df["father_cm"]) / 2
```

## Code Explanation & Walkthrough
Line 30 is concise yet powerful:
1. `df["mother_cm"] + df["father_cm"]`: Creates an intermediate temporary Series where each row contains the sum of the parents' heights.
2. `(...) / 2`: Divides every element in that temporary Series by the scalar floating point value `2.0`.
3. `df["midparent_cm"] = ...`: Assigns the resulting Series back to the DataFrame under the new key `"midparent_cm"`. If the key does not exist, pandas creates the new column automatically.

## Worked Example
Let us execute the vectorized code and inspect before and after:
```python
import pandas as pd

data = {
    "mother_cm": [165.4, 166.7, 157.7],
    "father_cm": [185.6, 170.6, 189.1],
    "child_cm": [176.9, 168.4, 174.3]
}
df = pd.DataFrame(data)

# Compute midparent column
df["midparent_cm"] = (df["mother_cm"] + df["father_cm"]) / 2

for idx, row in df.iterrows():
    print(f"Family {idx}: Mother={row['mother_cm']} + Father={row['father_cm']} -> Midparent={row['midparent_cm']}")
```

**Output:**
```
Family 0: Mother=165.4 + Father=185.6 -> Midparent=175.5
Family 1: Mother=166.7 + Father=170.6 -> Midparent=168.65
Family 2: Mother=157.7 + Father=189.1 -> Midparent=173.4
```
All calculations are exact, fast, and numerically verified.

## Step-by-Step Student Instructions
1. Load `data/heights.csv` in Python.
2. Execute the column assignment: `df["midparent_cm"] = (df["mother_cm"] + df["father_cm"]) / 2`.
3. Verify that the new column was appended by printing `df.head()`.
4. Run a sanity check: verify that every `midparent_cm` value lies strictly between the mother's height and father's height for each row.
5. Test what happens if parentheses are accidentally omitted, and observe the error in output magnitude.

## Expected Output or Observable Behaviour
When verifying the sanity check:
```python
is_between = (df["midparent_cm"] >= df[["mother_cm", "father_cm"]].min(axis=1)) &              (df["midparent_cm"] <= df[["mother_cm", "father_cm"]].max(axis=1))
print("All midparent values lie between parents?", is_between.all())
```
The output must display:
```
All midparent values lie between parents? True
```
This mathematically confirms that the average never falls outside the bounds of the two input numbers.

## Practical Exercises
- **Exercise 3.1:** Write the pandas code to compute midparent height if paternal height is given 60% weight and maternal height 40% weight.
- **Exercise 3.2:** What is the result of `160.0 + 180.0 / 2` versus `(160.0 + 180.0) / 2` in Python?
- **Exercise 3.3:** How do vectorized pandas operations compare in execution speed to iterative Python loops when processing 1,000,000 rows?

## Common Mistakes and Debugging
| Mistake | Why It Is Wrong | Proper Understanding |
|---|---|---|
| Omitting parentheses in `(mother + father) / 2` | Causes division to bind first, producing biologically impossible numbers (~250 cm) | Always wrap addition in parentheses before dividing by 2 |
| Using `.apply(lambda row: ...)` for simple arithmetic | Much slower than native vectorized arithmetic | Use native Series arithmetic: `(df["a"] + df["b"]) / 2` |
| Dividing by integer 2 without checking float support | In Python 2 this caused integer truncation; Python 3 uses float division | Python 3 `/` operator yields exact floats; still good practice to know |

## Best Practices and Security Considerations
- **Vectorized Performance:** Always prioritize vectorized pandas/NumPy column expressions over iterative loops.
- **Sanity Assertions:** Use assert statements or boolean series checks to confirm that derived columns fall within logically valid domains.

## Summary
Computing `midparent_cm` via pandas vectorized series arithmetic demonstrates how data scientists implement mathematical feature transformations cleanly and efficiently. Paying strict attention to operator precedence prevents critical calculation bugs and ensures robust feature engineering.

## Knowledge-check Questions
1. Why does Python evaluate `df["a"] + df["b"] / 2` differently from `(df["a"] + df["b"]) / 2`?
2. What are the benefits of vectorized column operations over Python loops?
3. How can you verify that an arithmetic average lies between the two original numbers?
4. What data type is the resulting `midparent_cm` Series?

## References
- Python Operator Precedence Documentation: https://docs.python.org/3/reference/expressions.html#operator-precedence
- Pandas Series Operations: https://pandas.pydata.org/docs/reference/series.html
