# Module 4 Exercises: Model Training & Prediction

## Exercise 4.1: Feature Extraction and Matrix Dimensions (10 min)
**Objective:** Correctly extract the feature matrix and target vector, confirming their 2D and 1D dimensionality.
**Problem Statement:** Prepare the dataset for scikit-learn model training by isolating `midparent_cm` into a 2D DataFrame $X$ and `child_cm` into a 1D Series $y$.

**Requirements:**
1. Extract `X = df[["midparent_cm"]]` and verify its shape is `(60, 1)`.
2. Extract `y = df["child_cm"]` and verify its shape is `(60,)`.
3. Test what happens if you extract `X_bad = df["midparent_cm"]` with single brackets. State the shape and explain why scikit-learn would reject it.

**Constraints:** Write clean Python code without syntax errors.

**Expected Behaviour:** Printout confirming shapes of $X$, $y$, and the single-bracket alternative.

**Acceptance Criteria:**
- [ ] Confirms `X.shape == (60, 1)`.
- [ ] Confirms `y.shape == (60,)`.
- [ ] Identifies `X_bad.shape == (60,)` and explains scikit-learn's 2D input mandate.

**Hints:**
- Double brackets preserve DataFrame structure; single brackets yield a Series.

**Difficulty:** Basic
**Estimated Completion Time:** 10 minutes

---

## Exercise 4.2: Train/Test Split Reproducibility (15 min)
**Objective:** Implement reproducible data partitioning with `train_test_split` and verify subset counts.
**Problem Statement:** Partition the 60 families into training and testing sets with a 75/25 split ratio and seed 42. Verify that repeated runs produce identical sample sets.

**Requirements:**
1. Call `train_test_split(X, y, test_size=0.25, random_state=42)`.
2. Verify that `len(X_train) == 45` and `len(X_test) == 15`.
3. Run the split twice in separate scripts and verify that `X_train.index` is identical across both executions.
4. Explain why reproducibility is critical in scientific machine learning workflows.

**Constraints:** Use `random_state=42` and `test_size=0.25`.

**Expected Behaviour:** Python verification script confirming exact row counts and identical index sequences across runs.

**Acceptance Criteria:**
- [ ] Training count verified as 45.
- [ ] Testing count verified as 15.
- [ ] Index sequence verified identical across runs.
- [ ] Clear written explanation of why random seeds are mandatory.

**Hints:**
- Check `(X_train.index == X_train_run2.index).all()`.

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 4.3: Model Fitting and Parameter Extraction (15 min)
**Objective:** Fit `LinearRegression` on training families and extract the slope and intercept.
**Problem Statement:** Instantiate and fit scikit-learn's `LinearRegression` model. Extract and format the learned slope and intercept.

**Requirements:**
1. Instantiate `model = LinearRegression()`.
2. Fit the model exclusively on `X_train` and `y_train`.
3. Extract `slope = float(model.coef_[0])` and `intercept = float(model.intercept_)`.
4. Print the regression equation formatted to two decimal places: `child = {slope:.2f} * midparent + {intercept:.2f}`.
5. Confirm that the slope is approximately $0.88$ and intercept is approximately $21.17$.

**Constraints:** Model must be trained strictly on training data (no data leakage).

**Expected Behaviour:** Python code that fits the model and prints the formatted equation.

**Acceptance Criteria:**
- [ ] Fits model strictly on `(X_train, y_train)`.
- [ ] Slope extracted with `float(model.coef_[0])` (~0.88).
- [ ] Intercept extracted with `float(model.intercept_)` (~21.17).
- [ ] Output string matches the format in `main.py`.

**Hints:**
- Don't forget `[0]` when accessing `model.coef_`.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 4.4: Multi-Family Inference Batch (20 min)
**Objective:** Run inference across a batch of diverse family statures and analyze predicted child heights.
**Problem Statement:** Construct a query DataFrame representing four different family scenarios and compute predicted child heights for each.

**Requirements:**
1. Create a query DataFrame with four midparent values:
   - Family 1: $160.0$ cm (short parents)
   - Family 2: $170.0$ cm (benchmark parents)
   - Family 3: $175.0$ cm (above-average parents)
   - Family 4: $188.0$ cm (tall parents)
2. Run `model.predict(query_df)` and extract predictions.
3. Print each midparent input alongside its predicted child height formatted to 1 decimal place.
4. Calculate the net shift $(\hat{y} - \text{midparent})$ for each family and confirm regression to the mean across the batch.

**Constraints:** Query input must be a pandas DataFrame with column name `"midparent_cm"`.

**Expected Behaviour:** A formatted table displaying Family, Input Midparent, Predicted Child Height, and Shift.

**Acceptance Criteria:**
- [ ] Query DataFrame correctly constructed with column name `"midparent_cm"`.
- [ ] Family 2 (170.0 cm) predicts approximately 171.6 cm.
- [ ] Short parents (160.0 cm) predict taller child (~162.7 cm, positive shift).
- [ ] Tall parents (188.0 cm) predict shorter child (~187.5 cm, negative shift).
- [ ] Analysis accurately explains the shift toward the population average.

**Hints:**
- Construct with `pd.DataFrame({"midparent_cm": [160.0, 170.0, 175.0, 188.0]})`.

**Difficulty:** Intermediate
**Estimated Completion Time:** 20 minutes
