# Lesson 01: Feature Matrix and Target Splitting with train_test_split

**Lesson ID:** lesson-01
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Separate tabular data into a 2D feature matrix ($X$) and a 1D target vector ($y$).
- Implement train/test splitting using scikit-learn's `train_test_split`.
- Configure `test_size=0.25` and `random_state=42` to guarantee reproducible partitions.
- Verify array shapes and prevent data leakage in supervised learning.

## Prerequisites
- Completion of Module 01, 02, and 03.
- Understanding of pandas slicing and DataFrame structure.

## Concept Explanation

### The Separation of Inputs ($X$) and Outputs ($y$)
In scikit-learn, machine learning algorithms expect a strict separation between what the model receives as input (features) and what the model is tasked with predicting (target).

In our project:
- **Feature Matrix ($X$):** The engineered variable `midparent_cm`.
- **Target Vector ($y$):** The observed adult height `child_cm`.

### Why $X$ Must Be 2D and $y$ 1D
A critical distinction in pandas syntax dictates the dimensionality of these structures:
```python
X = df[["midparent_cm"]]  # Double brackets -> pandas DataFrame (2D)
y = df["child_cm"]        # Single brackets -> pandas Series (1D)
```
Scikit-learn models are designed to accept multiple features simultaneously. Even if our model uses only one single feature, scikit-learn mandates that the input matrix has two dimensions: `(n_samples, n_features)`. For our 60 families, `X.shape` is `(60, 1)`. In contrast, the target variable $y$ is a single scalar outcome per sample, so a 1D Series of shape `(60,)` is expected.

### Train/Test Splitting Strategy
Why do we split our 60 families into training and testing partitions?
If we trained our regression line on all 60 families and evaluated its performance on those exact same 60 families, we would commit the cardinal sin of machine learning: **training on test data** (or data leakage). The model could potentially fit peculiar statistical flukes of our specific 60 families, creating an illusion of high accuracy while failing when applied to families outside the dataset.

In `main.py`, lines 34–36 partition the data:
```python
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)
```

- `test_size=0.25`: Allocates $25\%$ of the data to the test set ($0.25 \times 60 = 15$ families) and $75\%$ to the training set ($45$ families).
- `random_state=42`: Seeds the pseudo-random number generator so that the random shuffle produces the exact same split every time the script runs. Without a fixed seed, results would fluctuate across runs, making debugging and grading impossible.

## Relevant Code (from main.py, lines 31-36)
```python
    X = df[["midparent_cm"]]
    y = df["child_cm"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42
    )
```

## Code Explanation & Walkthrough
Let us trace the execution:
1. Line 31 extracts `midparent_cm` into DataFrame `X` with shape `(60, 1)`.
2. Line 32 extracts `child_cm` into Series `y` with shape `(60,)`.
3. Lines 34–36 pass `X` and `y` into `train_test_split()`.
4. The function shuffles the 60 row indices deterministically using seed 42, slices the first 45 rows for training and the remaining 15 rows for testing, and returns four distinct objects unpacked into `X_train`, `X_test`, `y_train`, and `y_test`.

## Worked Example
Let us verify the shapes and sample counts in Python:
```python
import pandas as pd
from sklearn.model_selection import train_test_split

df = pd.read_csv("data/heights.csv")
df["midparent_cm"] = (df["mother_cm"] + df["father_cm"]) / 2

X = df[["midparent_cm"]]
y = df["child_cm"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)

print(f"Total dataset: {len(df)} rows")
print(f"X_train shape: {X_train.shape} (45 training families)")
print(f"X_test shape:  {X_test.shape}  (15 testing families)")
print(f"y_train shape: {y_train.shape}")
print(f"y_test shape:  {y_test.shape}")
```

**Output:**
```
Total dataset: 60 rows
X_train shape: (45, 1) (45 training families)
X_test shape:  (15, 1)  (15 testing families)
y_train shape: (45,)
y_test shape:  (15,)
```
The dimensions match scikit-learn requirements perfectly.

## Step-by-Step Student Instructions
1. Load `heights.csv` and compute `midparent_cm`.
2. Extract `X = df[["midparent_cm"]]` and `y = df["child_cm"]`.
3. Check `X.ndim` (must equal 2) and `y.ndim` (must equal 1).
4. Run `train_test_split` with `test_size=0.25` and `random_state=42`.
5. Verify that `len(X_train) == 45` and `len(X_test) == 15`.
6. Inspect the indices of `X_train` and `X_test` to confirm that the split randomly sampled families across the dataset.

## Expected Output or Observable Behaviour
When checking the training indices:
```python
print("First 5 train indices:", X_train.index[:5].tolist())
```
The output shows randomly shuffled indices (e.g., `[48, 26, 25, 32, 19]`), demonstrating that families were randomly distributed between subsets rather than taking the first 45 contiguous rows.

## Practical Exercises
- **Exercise 1.1:** Why must `X` have shape `(N, 1)` rather than `(N,)` when training scikit-learn models?
- **Exercise 1.2:** If `test_size=0.20` had been used on 60 rows, how many samples would be in the training and testing sets?
- **Exercise 1.3:** What would happen to model reproducibility if `random_state` was omitted?

## Common Mistakes and Debugging
| Mistake | Why It Is Wrong | Proper Understanding |
|---|---|---|
| Unpacking order mismatch: `X_train, y_train, X_test, y_test` | Swaps testing features with training targets | Scikit-learn always returns `(X_train, X_test, y_train, y_test)` |
| Single brackets for X: `X = df["midparent_cm"]` | Yields 1D Series of shape `(60,)`; crashes `model.fit()` with ValueError | Always use double brackets `df[["midparent_cm"]]` for 2D DataFrame |
| Splitting after fitting | Fits the model on all data before evaluating, causing severe data leakage | Always split data into train/test BEFORE calling `model.fit()` |

## Best Practices and Security Considerations
- **Immutable Random Seed:** Always fix `random_state` during development and educational assignments to enable peer grading and deterministic unit tests.
- **Leakage Prevention:** Ensure that preprocessing transformations (scaling, imputation) are fitted strictly on `X_train` and then applied to `X_test`.

## Summary
Proper data preparation requires isolating features into a 2D matrix ($X$) and the target into a 1D vector ($y$). Applying `train_test_split(test_size=0.25, random_state=42)` cleanly partitions the 60 families into 45 training samples and 15 testing samples, establishing an airtight defense against data leakage.

## Knowledge-check Questions
1. What is the shape of `X_train` in the Height Predictor project?
2. What is the shape of `y_test`?
3. What is the purpose of setting `random_state=42`?
4. How many families are reserved for testing when `test_size=0.25` on 60 rows?

## References
- Scikit-learn train_test_split: https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html
- Python Data Science Handbook: Model Validation: https://jakevdp.github.io/PythonDataScienceHandbook/05.03-hyperparameters-and-model-validation.html
