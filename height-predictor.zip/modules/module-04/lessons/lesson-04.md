# Lesson 04: Inference: Predicting Child Height for Midparent 170 cm

**Lesson ID:** lesson-04
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Construct a query DataFrame formatted for scikit-learn's `predict()` method.
- Execute out-of-sample inference for a benchmark family with midparent stature of $170.0$ cm.
- Extract, convert, and format predicted values to one decimal place (`171.6` cm).
- Provide a clear, actionable interpretation of model predictions for families.

## Prerequisites
- Completion of Lesson 03 (Extracting and Interpreting the Learned Model Parameters).
- Understanding of pandas DataFrame constructor syntax: `pd.DataFrame({"col": [val]})`.

## Concept Explanation

### The Goal of Inference
The ultimate objective of training any machine learning model is **inference**: deploying the trained mathematical function to make predictions on brand-new, previously unseen inputs.

In the Height Predictor project, we want to answer a concrete practical question:
> *"If a mother and father have an average height of 170.0 cm, how tall is their adult child predicted to be?"*

### Why 170 cm?
The value $170.0$ cm was selected as the benchmark scenario because:
1. It represents a very typical human height in modern global populations ($170$ cm $\approx 5$ feet $7$ inches).
2. For example, a mother of $162.0$ cm ($5'4"$) and a father of $178.0$ cm ($5'10"$) have an exact midparent average of $(162 + 178) / 2 = 170.0$ cm.
3. It lies comfortably near the center of our training data distribution, avoiding dangerous edge extrapolation.

### Structuring the Query Input for `predict()`
A very common mistake made by beginner Python programmers is attempting to pass a bare scalar number into `model.predict()`:
```python
# BUG: Raises ValueError!
prediction = model.predict(170.0)
```
Scikit-learn estimators are strictly designed for batch processing. The `predict()` method mandates that input data must have the exact same shape and feature schema as the training matrix `X_train`. Because `X_train` was a 2D pandas DataFrame with column name `"midparent_cm"`, the query must also be structured as a 2D DataFrame:
```python
query_df = pd.DataFrame({"midparent_cm": [170.0]})
prediction = model.predict(query_df)
```
Passing a DataFrame preserves column names and silences scikit-learn feature name validation warnings.

## Relevant Code (from main.py, lines 46, 54)
```python
    example = float(model.predict(pd.DataFrame({"midparent_cm": [170.0]}))[0])
    ...
    print(f"Prediction for midparent height 170 cm: {example:.1f} cm")
```

## Code Explanation & Walkthrough
Let us dissect line 46:
1. `pd.DataFrame({"midparent_cm": [170.0]})`: Creates a single-row DataFrame with the exact column name used during training.
2. `model.predict(...)`: Executes matrix multiplication $\hat{y} = X \beta + \beta_0$, returning a 1D NumPy array `array([171.57459174])`.
3. `[0]`: Extracts the first (and only) predicted value from the array.
4. `float(...)`: Converts the scalar NumPy float into a native Python float.
5. Line 54 formats the result to one decimal place (`:.1f`), displaying:
   `Prediction for midparent height 170 cm: 171.6 cm`.

## Worked Example
Let us compute the prediction by hand using our learned equation to verify scikit-learn's output:
$$\text{child} = 0.88470513 \times 170.0 + 21.17471928$$
$$\text{child} = 150.399872 + 21.174719 = 171.574591\text{ cm}$$

Rounding to one decimal place:
$$171.574591 \approx 171.6\text{ cm}$$

Notice that the child is predicted to be **$171.6$ cm**, which is **$1.6$ cm taller** than the parents' $170.0$ cm average! 
Why is the child predicted to be taller?
Because $170.0$ cm is slightly below the population average of fathers ($~180$ cm) and overall adult offspring ($~173.8$ cm). The model gently pulls the prediction upward toward the population mean!

## Step-by-Step Student Instructions
1. Ensure your model has been fitted on `X_train` and `y_train`.
2. Construct the single-sample query: `query = pd.DataFrame({"midparent_cm": [170.0]})`.
3. Call `pred_array = model.predict(query)`.
4. Extract the scalar: `example = float(pred_array[0])`.
5. Print the formatted result: `print(f"{example:.1f} cm")`.
6. Experiment with other parent combinations:
   - What if mother is $155$ cm and father is $175$ cm (midparent $165$ cm)?
   - What if mother is $172$ cm and father is $188$ cm (midparent $180$ cm)?

## Expected Output or Observable Behaviour
When executing `main.py`, the terminal outputs:
```
Prediction for midparent height 170 cm: 171.6 cm
```
On the visual scatter plot, this prediction is highlighted with a prominent black star marker at coordinates $(170.0, 171.6)$.

## Practical Exercises
- **Exercise 4.1:** Predict the child height for a midparent height of $175.0$ cm using the learned equation.
- **Exercise 4.2:** Why does passing `pd.DataFrame({"midparent_cm": [170.0]})` avoid scikit-learn feature name warnings compared to passing `[[170.0]]`?
- **Exercise 4.3:** If parents with midparent $170.0$ cm ask whether their child is guaranteed to be $171.6$ cm tall, how should you answer based on the model's MAE (~$3.1$ cm)?

## Common Mistakes and Debugging
| Mistake | Why It Is Wrong | Proper Understanding |
|---|---|---|
| Passing a scalar: `model.predict(170.0)` | Raises ValueError: `Expected 2D array, got scalar array instead` | Always pass a 2D structure: `pd.DataFrame({"midparent_cm": [170.0]})` |
| Using the wrong column name: `pd.DataFrame({"parent": [170.0]})` | Raises ValueError: feature names do not match training features | Query DataFrame columns must match training column names exactly |
| Forgetting `[0]` on the prediction result | Leaves prediction as a 1D array `array([171.57])`, complicating string formatting | Use `float(model.predict(...)[0])` to extract scalar |

## Best Practices and Security Considerations
- **Feature Name Alignment:** Always use pandas DataFrames with explicit column names for inference to guarantee feature order and alignment.
- **Communicate Uncertainty:** Always communicate that $171.6$ cm is an expected average, with a typical individual deviation of $\pm 3$ to $5$ cm.

## Summary
Inference applies the trained linear regression line to generate predictions for new families. In `main.py`, constructing a 2D query DataFrame for a midparent height of $170.0$ cm produces an estimated adult child height of $171.6$ cm, neatly illustrating statistical regression toward the population mean.

## Knowledge-check Questions
1. What data structure must be passed to `model.predict()` in scikit-learn?
2. What is the predicted adult child height for a midparent height of 170.0 cm?
3. Why is the predicted child height (171.6 cm) taller than the parents' 170.0 cm midparent height?
4. What happens if you pass a bare floating-point number into `model.predict()`?

## References
- Scikit-learn Predict Method Reference: https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html#sklearn.linear_model.LinearRegression.predict
- Pandas DataFrame Construction: https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.html
