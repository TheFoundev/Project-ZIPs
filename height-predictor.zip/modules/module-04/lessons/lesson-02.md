# Lesson 02: Fitting LinearRegression on Training Families

**Lesson ID:** lesson-02
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Instantiate and configure scikit-learn's `LinearRegression` estimator.
- Explain the Ordinary Least Squares (OLS) optimization objective.
- Execute `model.fit(X_train, y_train)` strictly on the training partition.
- Understand how scikit-learn finds the optimal slope and intercept in closed form.

## Prerequisites
- Completion of Lesson 01 (Feature Matrix and Target Splitting with train_test_split).
- Basic understanding of lines, slope, and intercept.

## Concept Explanation

### What is Ordinary Least Squares (OLS)?
The `LinearRegression` class in scikit-learn implements **Ordinary Least Squares (OLS)** regression. 

When we ask the algorithm to fit a straight line:
$$\hat{y}_i = \beta_1 \cdot x_i + \beta_0$$
there are infinitely many straight lines that could be drawn through the 45 training data points. How does scikit-learn choose the "best" line?

It minimizes the **Sum of Squared Residuals (SSR)**:
$$\text{SSR} = \sum_{i=1}^{N} (y_i - \hat{y}_i)^2 = \sum_{i=1}^{N} \big(y_i - (\beta_1 x_i + \beta_0)\big)^2$$

Where:
- $y_i$ is the actual adult height of child $i$.
- $\hat{y}_i$ is the model's predicted height for child $i$.
- $(y_i - \hat{y}_i)$ is the vertical residual (error).

By squaring each residual, two things happen:
1. Negative errors and positive errors do not cancel each other out.
2. Large errors are penalized much more heavily than small errors (e.g., an error of 4 cm adds 16 to SSR, while an error of 2 cm adds only 4).

### The Closed-Form Normal Equation
Unlike iterative deep learning algorithms that use gradient descent with learning rates and epochs, simple linear regression has an exact, analytical closed-form solution known as the **Normal Equation**:
$$\beta = (X^T X)^{-1} X^T y$$

When you call `model.fit(X_train, y_train)`, scikit-learn performs this matrix multiplication in C/Fortran LAPACK routines in a fraction of a millisecond. It finds the globally optimal slope and intercept that minimizes SSR without any trial and error!

## Relevant Code (from main.py, lines 38-39)
```python
    model = LinearRegression()
    model.fit(X_train, y_train)
```

## Code Explanation & Walkthrough
The implementation in `main.py` represents the quintessential scikit-learn two-step estimator pattern:
1. `model = LinearRegression()`: Instantiates the estimator object with default parameters (including `fit_intercept=True`, which ensures that the line is not forced through the origin $(0, 0)$).
2. `model.fit(X_train, y_train)`: Fits the model parameters strictly using the 45 training families. 
   - Notice that `X_test` and `y_test` are **never** passed into `fit()`. 
   - The estimator computes the optimal slope and intercept, storing them internally in attributes ending with an underscore: `model.coef_` and `model.intercept_`.

## Worked Example
Let us observe how `model.fit()` executes and verify that the fitted attributes are populated:
```python
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

df = pd.read_csv("data/heights.csv")
df["midparent_cm"] = (df["mother_cm"] + df["father_cm"]) / 2

X = df[["midparent_cm"]]
y = df["child_cm"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)

model = LinearRegression()

# Before fitting: attributes do not exist
print("Has model been fitted?", hasattr(model, "coef_"))

# Fit the model on training data
model.fit(X_train, y_train)

# After fitting: attributes exist
print("Has model been fitted?", hasattr(model, "coef_"))
print("Raw coef_ array:", model.coef_)
print("Raw intercept_:", model.intercept_)
```

**Output:**
```
Has model been fitted? False
Has model been fitted? True
Raw coef_ array: [0.88470513]
Raw intercept_: 21.174719283742887
```
Once fitted, the model object is primed and ready to generate predictions.

## Step-by-Step Student Instructions
1. Import `LinearRegression` from `sklearn.linear_model`.
2. Instantiate `model = LinearRegression()`.
3. Call `model.fit(X_train, y_train)`.
4. Verify that the call executes silently without raising exceptions.
5. Confirm that `model.coef_` and `model.intercept_` now exist as attributes on the `model` object.
6. Verify that `X_test` was not touched during the fitting step.

## Expected Output or Observable Behaviour
The fitting step executes virtually instantaneously (under $5$ milliseconds) because solving the normal equation for a $45 \times 1$ matrix is computationally trivial. The model instance transitions from an uninitialized estimator to a fully parameterized regression model.

## Practical Exercises
- **Exercise 2.1:** What mathematical quantity does Ordinary Least Squares minimize?
- **Exercise 2.2:** Why do we square the residuals in OLS instead of simply summing them up?
- **Exercise 2.3:** What naming convention does scikit-learn use for attributes learned during `fit()`?

## Common Mistakes and Debugging
| Mistake | Why It Is Wrong | Proper Understanding |
|---|---|---|
| Calling fit on all data: `model.fit(X, y)` | Contaminates the model with test data, preventing honest evaluation | Always call `fit()` exclusively on `(X_train, y_train)` |
| Trying to access `model.coef_` before `fit()` | Raises `NotFittedError: This LinearRegression instance is not fitted yet` | You must call `model.fit()` before inspecting coefficients |
| Setting `fit_intercept=False` | Forces the line through (0, 0), which would predict 0 cm child height for 0 cm parents | Always keep `fit_intercept=True` (the default) for biometric modeling |

## Best Practices and Security Considerations
- **API Consistency:** Scikit-learn's `fit()` pattern is universal across all estimators (RandomForest, SVM, LinearRegression). Mastering it here equips you for all machine learning algorithms.
- **Stateless Instantiation:** Instantiate clean model objects for distinct experiments rather than repeatedly re-fitting the same instance across different data subsets.

## Summary
Fitting a `LinearRegression` model executes Ordinary Least Squares optimization on the training data. In `main.py`, calling `model.fit(X_train, y_train)` analytically determines the line that minimizes the sum of squared vertical residuals across the 45 training families, capturing the optimal slope and intercept.

## Knowledge-check Questions
1. Which module in scikit-learn provides the `LinearRegression` class?
2. What does OLS stand for?
3. What happens to the sign of negative residuals when they are squared?
4. What suffix does scikit-learn append to parameter names learned during fitting?

## References
- Scikit-learn LinearRegression API Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html
- Hastie, T., Tibshirani, R., & Friedman, J. (2009). *The Elements of Statistical Learning*. Springer.
