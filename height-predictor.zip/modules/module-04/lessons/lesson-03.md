# Lesson 03: Extracting and Interpreting the Learned Model Parameters

**Lesson ID:** lesson-03
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Access and extract `model.coef_` and `model.intercept_` from a fitted scikit-learn model.
- Cast NumPy arrays to standard Python floats for clean display and formatting.
- State the complete mathematical regression equation for the Height Predictor.
- Interpret the physical and biological meaning of the slope ($0.88$) and intercept ($21.17$ cm).

## Prerequisites
- Completion of Lesson 02 (Fitting LinearRegression on Training Families).
- Basic Python string formatting (`f"{value:.2f}"`).

## Concept Explanation

### Accessing Scikit-Learn Parameters
After `model.fit(X_train, y_train)` completes, the learned parameters are stored inside the model instance:
- **`model.coef_`**: A 1D NumPy array containing the feature slopes (weights). Because we have only one feature (`midparent_cm`), `model.coef_` contains a single element at index `0`.
- **`model.intercept_`**: A floating-point scalar containing the $y$-intercept $\beta_0$.

In `main.py`, lines 44–45 extract and cast these parameters:
```python
slope = float(model.coef_[0])
intercept = float(model.intercept_)
```

### Why Use `float(...)` Conversion?
By default, `model.coef_[0]` has the type `numpy.float64`. While NumPy floats print cleanly in many contexts, casting to Python's built-in `float` guarantees:
1. Compatibility with standard Python serializes (JSON, SQLite).
2. Clean string formatting without NumPy container annotations.
3. Fast execution without overhead.

### The Concrete Equation
Plugging in our extracted numbers:
$$\text{child\_height} = 0.8847 \times \text{midparent\_height} + 21.1747$$
Rounded for presentation in console outputs:
$$\text{child\_height} = 0.88 \times \text{midparent\_height} + 21.17$$

### Interpreting the Slope ($0.88$)
In linear regression, the slope represents the expected change in the target variable for a one-unit change in the feature:
- For every **$1.0$ cm increase** in midparent height, the adult child's height is expected to increase by approximately **$0.88$ cm**.
- Notice that the return is less than $1:1$! If midparent height increases by $10$ cm, the child's height is predicted to increase by only $8.8$ cm. This is the direct manifestation of **regression to the mean**.

### Interpreting the Intercept ($21.17$ cm)
Mathematically, the intercept represents the predicted value of the target when the feature is zero:
- If `midparent_cm = 0.0`, the equation predicts a child height of $21.17$ cm.
- **Physical Interpretation Caution:** Does a midparent height of $0$ cm make any biological sense? Of course not! Living adult humans never measure $0$ cm. 
- In machine learning, the intercept often serves as an **algebraic anchor**. It exists to position the line at the correct height within the realistic data range ($150$ to $195$ cm). It prevents the slope of $0.88$ from shrinking children downward, ensuring that shorter parents have children who regress upward toward the population mean.

## Relevant Code (from main.py, lines 44-51)
```python
    slope = float(model.coef_[0])
    intercept = float(model.intercept_)
    example = float(model.predict(pd.DataFrame({"midparent_cm": [170.0]}))[0])

    print("=" * 60)
    print("HOW TALL WILL YOU BE?")
    print("=" * 60)
    print(f"Model: child height = {slope:.2f} x midparent height + {intercept:.2f}")
```

## Code Explanation & Walkthrough
- `float(model.coef_[0])`: Extracts the first coefficient as a pure Python float.
- `float(model.intercept_)`: Extracts the intercept as a pure Python float.
- Line 51 uses an f-string with format specifier `:.2f` to round both floating-point numbers to two decimal places:
  `{slope:.2f}` displays as `0.88`
  `{intercept:.2f}` displays as `21.17`

This produces a clean, professional output suitable for end users and documentation.

## Worked Example
Let us write a small test script to inspect the types and formatting:
```python
from sklearn.linear_model import LinearRegression
import numpy as np

# Mock fit
X = np.array([[160.0], [170.0], [180.0]])
y = np.array([162.0, 171.0, 180.0])

model = LinearRegression().fit(X, y)

slope = float(model.coef_[0])
intercept = float(model.intercept_)

print(f"Type of slope: {type(slope)}")
print(f"Equation: y = {slope:.2f}x + {intercept:.2f}")
```

**Output:**
```
Type of slope: <class 'float'>
Equation: y = 0.90x + 18.00
```
This confirms that type conversion and string formatting operate cleanly.

## Step-by-Step Student Instructions
1. Fit the model on `X_train` and `y_train`.
2. Extract the slope using `slope = float(model.coef_[0])`.
3. Extract the intercept using `intercept = float(model.intercept_)`.
4. Print both variables using standard Python print statements.
5. Write out the human-readable sentence: "For every 1 cm increase in parental average height, child height increases by 0.88 cm."
6. Reflect on why the intercept at $x = 0$ is a mathematical convenience rather than a biological observation.

## Expected Output or Observable Behaviour
Console printout:
```
Model: child height = 0.88 x midparent height + 21.17
```
Both coefficients are clearly visible and match the project requirements.

## Practical Exercises
- **Exercise 3.1:** What is the exact value of `model.coef_[0]` in `main.py` before rounding?
- **Exercise 3.2:** What is the physical unit of the slope? (Hint: units of y divided by units of x).
- **Exercise 3.3:** Why is it dangerous to interpret the intercept as the height of a child born to parents of 0 cm height?

## Common Mistakes and Debugging
| Mistake | Why It Is Wrong | Proper Understanding |
|---|---|---|
| Indexing error: `model.coef_` without `[0]` | `model.coef_` is a NumPy array `[0.8847]`, formatting it with `:.2f` raises a TypeError | Always extract the scalar element at index `0`: `model.coef_[0]` |
| Assuming intercept is a biological reality | Adult parents cannot measure 0 cm | The intercept is a mathematical anchor within the OLS formulation |
| Confusing slope with correlation | Slope depends on units of measurement; correlation is dimensionless (-1 to +1) | Slope is $\Delta y / \Delta x$; Pearson $r$ is standardized covariance |

## Best Practices and Security Considerations
- **Clean Formatting:** Never present unrounded floats like `0.8847051283742` to non-technical stakeholders. Use `:.2f` or `:.1f`.
- **Domain Sanity Checks:** Ensure that the slope has the correct expected sign ($+$ for height) and reasonable biological magnitude ($0.5$ to $1.0$).

## Summary
Model parameter extraction uncovers the mathematical core of the Height Predictor. The slope of $0.88$ captures the rate of trait transmission while embodying regression to the mean, and the positive intercept of $21.17$ cm establishes the necessary baseline compensation across the biological spectrum.

## Knowledge-check Questions
1. In scikit-learn, what attribute contains the learned feature slope?
2. Why must we use `[0]` when accessing `model.coef_`?
3. What is the unit of the slope in this project?
4. What is the predicted child height if midparent height is 0 cm?

## References
- Python String Formatting Syntax: https://docs.python.org/3/library/string.html#format-specification-mini-language
- Gelman, A., & Hill, J. (2006). *Data Analysis Using Regression and Multilevel/Hierarchical Models*. Cambridge University Press.
