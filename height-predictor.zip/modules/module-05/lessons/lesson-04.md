# Lesson 04: Annotating Benchmark Predictions and Exporting Artifacts

**Lesson ID:** lesson-04
**Module:** module-05
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Annotate specific scenario predictions on a matplotlib figure using custom markers and `zorder`.
- Export publication-quality graphics using `dpi=150` and `bbox_inches="tight"`.
- Cleanly release memory by invoking `plt.close(fig)`.
- Persist structured text metrics and equations to disk using Python file I/O.

## Prerequisites
- Completion of Lesson 03 (Building Multi-Layer Matplotlib Regression Plots).
- Basic understanding of Python file writing (`open()`, `write()`).

## Concept Explanation

### Highlighting Key Predictions with zorder
When plotting multiple visual elements on a single canvas, elements are drawn in the order they are called. If a marker is drawn early, later scatter points or lines might draw over it, partially obscuring it.

To ensure that our benchmark prediction ($170$ cm midparent $\rightarrow 171.6$ cm child) stands out boldly:
```python
ax.scatter([170], [example], color="#111111", marker="*", s=220, zorder=5, label="170 cm example")
```

The parameter **`zorder`** controls the drawing hierarchy:
- Default scatter points have `zorder=2`.
- Lines typically have `zorder=2` or `3`.
- By assigning `zorder=5`, our black star is guaranteed to be rendered on top of all other points and lines, ensuring maximum visual prominence!

### Exporting High-Resolution Graphics
In professional data science, visual artifacts must be saved to disk at print-ready resolution. In `main.py`, line 71 exports the plot:
```python
fig.tight_layout()
fig.savefig(OUT / "height_regression.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```

- `fig.tight_layout()`: Automatically adjusts subplots so that titles, axis labels, and tick marks do not overlap or get clipped.
- `dpi=150`: Dots Per Inch. Standard web images use 72 or 96 DPI; 150 DPI provides sharp, crisp text and clean lines suitable for reports.
- `bbox_inches="tight"`: Crops excess whitespace around the canvas.
- `plt.close(fig)`: Crucial for memory hygiene! Matplotlib keeps figure objects in memory until explicitly closed. In long-running pipelines, omitting `plt.close()` causes progressive memory leaks.

### Persisting Structured Metrics to `outputs/metrics.txt`
In addition to visual images, automated machine learning pipelines must write machine-readable or plain-text metric logs for auditing, benchmarking, and continuous integration.

In `main.py`, lines 74–77 persist the numerical results:
```python
with open(OUT / "metrics.txt", "w", encoding="utf-8") as handle:
    handle.write(f"equation: child = {slope:.4f} * midparent + {intercept:.4f}
")
    handle.write(f"MAE: {mae:.4f} cm
R2: {r2:.4f}
")
    handle.write(f"prediction at midparent 170 cm: {example:.2f} cm
")
```

Notice that while console outputs are rounded to 1 or 2 decimal places for human readability, the metrics file records parameters to 4 decimal places, preserving precision for downstream tools.

## Relevant Code (from main.py, lines 64, 70-78)
```python
    ax.scatter([170], [example], color="#111111", marker="*", s=220, zorder=5, label="170 cm example")
    ...
    fig.tight_layout()
    fig.savefig(OUT / "height_regression.png", dpi=150, bbox_inches="tight")
    plt.close(fig)

    with open(OUT / "metrics.txt", "w", encoding="utf-8") as handle:
        handle.write(f"equation: child = {slope:.4f} * midparent + {intercept:.4f}
")
        handle.write(f"MAE: {mae:.4f} cm
R2: {r2:.4f}
")
        handle.write(f"prediction at midparent 170 cm: {example:.2f} cm
")
```

## Code Explanation & Walkthrough
Let us examine the file persistence operations:
1. `OUT / "height_regression.png"`: Resolves the destination path in the `outputs/` folder.
2. `OUT.mkdir(exist_ok=True)`: Executed earlier in line 25, ensuring that the folder exists prior to file creation.
3. `encoding="utf-8"`: Guarantees cross-platform character encoding compatibility between Linux, macOS, and Windows.
4. `with open(...) as handle`: Context manager ensures that the file handle is automatically flushed and closed even if an exception occurs.

## Worked Example
Let us inspect the exact text contents of `outputs/metrics.txt`:
```
equation: child = 0.8847 * midparent + 21.1747
MAE: 3.0810 cm
R2: 0.5362
prediction at midparent 170 cm: 171.57 cm
```
This file provides a permanent, auditable record of the training run.

## Step-by-Step Student Instructions
1. Run `python main.py` in your terminal.
2. Verify that the `outputs/` folder contains two files: `height_regression.png` and `metrics.txt`.
3. Open `outputs/metrics.txt` using a text editor or `cat outputs/metrics.txt` and verify its lines.
4. Open `outputs/height_regression.png` in an image viewer and locate the large black star marker.
5. Confirm that the star is positioned at $X = 170.0$ and $y = 171.6$.
6. Check the resolution and sharpness of the generated image.

## Expected Output or Observable Behaviour
Console output confirms file generation:
```
Saved: outputs/height_regression.png, outputs/metrics.txt
Try this: add mother and father as separate features and compare.
```
The file system contains both the visual chart and the text metrics file.

## Practical Exercises
- **Exercise 4.1:** What is the role of `zorder=5` when plotting the benchmark prediction star?
- **Exercise 4.2:** Why is `plt.close(fig)` important in automated data science scripts?
- **Exercise 4.3:** How does the precision of the numbers in `outputs/metrics.txt` compare to the terminal printout?

## Common Mistakes and Debugging
| Mistake | Why It Is Wrong | Proper Understanding |
|---|---|---|
| Omitting `OUT.mkdir(exist_ok=True)` | Crashes with FileNotFoundError if `outputs/` directory does not exist | Always ensure destination directories exist before saving |
| Forgetting `plt.close(fig)` | Leaves figure canvas in memory, causing memory leaks in iterative pipelines | Always close figures explicitly after saving |
| Omitting `encoding="utf-8"` | May cause encoding bugs on Windows systems with non-UTF-8 defaults | Always specify `encoding="utf-8"` when writing text files |

## Best Practices and Security Considerations
- **Resource Management:** Always use `with open(...)` context managers to guarantee clean file closure.
- **Directory Isolation:** Direct all generated outputs to an isolated `outputs/` folder rather than cluttering the project root.

## Summary
Exporting structured visual and text artifacts completes the machine learning pipeline. Using high-resolution rendering parameters, `zorder` layering, explicit context managers, and memory cleanup ensures that model outputs are publication-ready, auditable, and production-grade.

## Knowledge-check Questions
1. What does the parameter `zorder=5` do?
2. What two output files are generated by `main.py` in the `outputs/` folder?
3. What DPI setting is used when saving `height_regression.png`?
4. Why should you always call `plt.close(fig)` after saving a plot?

## References
- Matplotlib Figure Saving Documentation: https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.savefig.html
- Python Context Managers and File I/O: https://docs.python.org/3/tutorial/inputoutput.html#reading-and-writing-files
