# Lesson 01: Measuring Model Error with MAE in Centimeters

**Lesson ID:** lesson-01
**Module:** module-05
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define Mean Absolute Error (MAE) and compute it using scikit-learn.
- Explain why MAE is expressed in the exact physical units of the target variable (centimeters).
- Contrast MAE with Mean Squared Error (MSE) and Root Mean Squared Error (RMSE).
- Interpret what an MAE of approximately $3.1$ cm means for families and practitioners.

## Prerequisites
- Completion of Module 04 (Model Training & Prediction).
- Basic understanding of absolute values ($|x|$).

## Concept Explanation

### The Need for Concrete Error Metrics
When presenting a machine learning model to parents, doctors, or researchers, dimensionless metrics like $R^2 = 0.54$ can feel abstract. A family does not ask, "What percentage of variance does your algorithm capture?" They ask a practical question:
> *"When your model makes a prediction, how far off is it typically in real life?"*

To answer this question, we calculate **Mean Absolute Error (MAE)**.

### Mathematical Definition of MAE
Mean Absolute Error measures the average magnitude of the errors between predicted values ($\hat{y}_i$) and actual observed values ($y_i$), without considering their direction:
$$\text{MAE} = \frac{1}{N} \sum_{i=1}^{N} |y_i - \hat{y}_i|$$

Where:
- $N$ is the number of test families ($15$ in our project).
- $y_i$ is the actual adult height of child $i$.
- $\hat{y}_i$ is the model's predicted height for child $i$.
- $|y_i - \hat{y}_i|$ is the absolute deviation (error magnitude).

### Key Properties of MAE
1. **Preserves Physical Units:** If the target is in centimeters, MAE is expressed directly in centimeters. In our project:
   $$\text{MAE} \approx 3.1\text{ cm}$$
   This tells us: on average, the model's prediction differs from the true adult height of the child by about **$3.1$ centimeters** (roughly $1.2$ inches).
2. **Linear Penalization:** Unlike Mean Squared Error (MSE), which squares errors and is disproportionately influenced by extreme outliers, MAE treats all error magnitudes linearly. A $6$ cm error is penalized exactly twice as much as a $3$ cm error.
3. **Intuitive Interpretability:** A non-technical person immediately understands what "within $3.1$ cm on average" means.

## Relevant Code (from main.py, lines 40-42, 52)
```python
    predictions = model.predict(X_test)

    mae = mean_absolute_error(y_test, predictions)
    ...
    print(f"Mean absolute error: {mae:.1f} cm")
```

## Code Explanation & Walkthrough
In line 40, `model.predict(X_test)` generates 15 predicted heights for the held-out test families.
In line 42, `mean_absolute_error(y_test, predictions)` computes the absolute difference for each test family and returns the arithmetic mean.
In line 52, `{mae:.1f} cm` formats the floating-point result to one decimal place, appending the unit `"cm"`:
```
Mean absolute error: 3.1 cm
```

## Worked Example
Let us compute MAE manually for three sample test families:

| Test Family | Actual Height ($y$) | Predicted Height ($\hat{y}$) | Error ($y - \hat{y}$) | Absolute Error ($|y - \hat{y}|$) |
|---|---|---|---|---|
| Family 1 | $176.9$ cm | $175.4$ cm | $+1.5$ cm | $1.5$ cm |
| Family 2 | $168.4$ cm | $172.1$ cm | $-3.7$ cm | $3.7$ cm |
| Family 3 | $174.3$ cm | $170.2$ cm | $+4.1$ cm | $4.1$ cm |

Sum of absolute errors:
$$1.5 + 3.7 + 4.1 = 9.3\text{ cm}$$
Mean Absolute Error:
$$\text{MAE} = \frac{9.3}{3} = 3.1\text{ cm}$$

Notice that negative errors (such as $-3.7$ cm for Family 2) do not cancel out positive errors because the absolute value converts all deviations to positive magnitudes.

## Step-by-Step Student Instructions
1. Run `predictions = model.predict(X_test)`.
2. Compute `mae = mean_absolute_error(y_test, predictions)`.
3. Print `mae` to inspect its raw floating-point value ($pprox 3.081$ cm).
4. Print formatted with one decimal place: `print(f"{mae:.1f} cm")`.
5. Compare this error to standard human growth expectations: is $3.1$ cm small or large relative to an adult height of $175$ cm? (Hint: $3.1 / 175 \approx 1.8\%$ error).

## Expected Output or Observable Behaviour
Terminal output:
```
Mean absolute error: 3.1 cm
```
The output confirms that across the held-out test families, the model's typical deviation from reality is approximately $3.1$ centimeters.

## Practical Exercises
- **Exercise 1.1:** What is the formula for Mean Absolute Error?
- **Exercise 1.2:** Why is MAE preferred over MSE when communicating results to non-technical stakeholders?
- **Exercise 1.3:** If a test family has an actual height of $180.0$ cm and a predicted height of $174.5$ cm, what is the absolute error for this family?

## Common Mistakes and Debugging
| Mistake | Why It Is Wrong | Proper Understanding |
|---|---|---|
| Omitting absolute value in manual error sum | Positive and negative errors cancel each other out, falsely suggesting zero error | Always take the absolute value $|y - \hat{y}|$ before averaging |
| Evaluating MAE on training data | Training error underestimates true generalization error | Always compute MAE on the unseen test set (`y_test`) |
| Reporting MAE without physical units | A number like "3.1" is meaningless without stating whether it is inches, cm, or meters | Always report units: `3.1 cm` |

## Best Practices and Security Considerations
- **Pair Metrics:** Always report MAE alongside $R^2$. MAE provides physical scale; $R^2$ provides relative variance explained.
- **Unit Consistency:** Verify that feature engineering and target columns share identical units (centimeters) throughout the pipeline.

## Summary
Mean Absolute Error (MAE) provides an intuitive, physically grounded measure of model accuracy. In the Height Predictor, an MAE of approximately $3.1$ cm demonstrates that parental midparent stature predicts adult child height within a typical margin of about $3$ centimeters.

## Knowledge-check Questions
1. In what physical units is MAE expressed in this project?
2. What is the approximate MAE achieved by the model on the test dataset?
3. How does MAE differ from Mean Squared Error (MSE)?
4. Why do we compute MAE on `y_test` rather than `y_train`?

## References
- Scikit-learn mean_absolute_error: https://scikit-learn.org/stable/modules/generated/sklearn.metrics.mean_absolute_error.html
- Willmott, C. J., & Matsuura, K. (2005). "Advantages of the mean absolute error (MAE) over the root mean squared error (RMSE) in assessing average model performance." *Climate Research*.
