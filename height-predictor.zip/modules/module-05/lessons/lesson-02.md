# Lesson 02: Evaluating Test Set Goodness of Fit with R-squared

**Lesson ID:** lesson-02
**Module:** module-05
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Compute $R^2$ using scikit-learn's `r2_score` function on test data.
- Explain the mathematical relationship between Pearson correlation ($r$) and $R^2$ in bivariate regression.
- Contrast training $R^2$ with testing $R^2$ to assess model overfitting.
- Defend why $R^2 \approx 0.54$ is an expected and sound outcome for biological data.

## Prerequisites
- Completion of Lesson 01 (Measuring Model Error with MAE in Centimeters).
- Understanding of the concept of variance.

## Concept Explanation

### The Role of $R^2$ in Evaluation
While Mean Absolute Error (MAE) tells us the average physical error in centimeters, it does not tell us how much of the underlying phenomenon our model actually captured. A model could have a low MAE simply because the target data has very narrow spread.

The coefficient of determination ($R^2$) fills this gap by comparing the model's errors against a simple "baseline model" that predicts the mean height ($\bar{y}$) for every family:
$$R^2 = 1 - \frac{\sum (y_i - \hat{y}_i)^2}{\sum (y_i - \bar{y})^2}$$

- If the regression line offers zero improvement over guessing the mean, $R^2 = 0$.
- If the regression line captures some of the variation, $R^2 > 0$.
- In our project, $R^2 \approx 0.54$.

### Mathematical Link to Pearson Correlation
In simple bivariate linear regression (one feature $X$ and one target $y$), an elegant mathematical equivalence holds:
$$R^2 = r^2$$
Where $r$ is the Pearson correlation coefficient between $X$ and $y$.

In Module 02 Lesson 04, we saw that the Pearson correlation between `midparent_cm` and `child_cm` is:
$$r \approx 0.732$$
Squaring this correlation:
$$r^2 = (0.732)^2 = 0.536 \approx 0.54$$

This confirms the mathematical harmony of linear algebra: the proportion of variance explained by a single-variable regression line equals the square of the linear correlation between the feature and the target!

### Checking for Overfitting: Train $R^2$ vs Test $R^2$
A key evaluation step in professional machine learning is comparing performance on the training partition versus the testing partition:
- If training $R^2$ is much higher than test $R^2$ (e.g., $0.95$ vs $0.40$), the model has **overfitted** (memorized training noise).
- In our linear model:
  - Training $R^2 \approx 0.53$
  - Testing $R^2 \approx 0.54$
The fact that training and testing $R^2$ are virtually identical ($~0.54$) proves that our model has zero overfitting! It has learned a stable, generalizable biological trend that transfers cleanly to unseen families.

## Relevant Code (from main.py, lines 43, 53)
```python
    r2 = r2_score(y_test, predictions)
    ...
    print(f"R-squared: {r2:.2f}")
```

## Code Explanation & Walkthrough
Line 43 passes `y_test` (ground truth) and `predictions` into `r2_score`. 
Notice that `r2_score` takes `(y_true, y_pred)` in that order. Passing predictions first will not change the numerical value of $R^2$, but adhering to scikit-learn's standard `(y_true, y_pred)` convention is essential across all evaluation metrics.

Line 53 formats the score to two decimal places:
```
R-squared: 0.54
```

## Worked Example
Let us compute both train and test $R^2$ in Python to demonstrate the absence of overfitting:
```python
from sklearn.metrics import r2_score

# Compute predictions on both partitions
train_preds = model.predict(X_train)
test_preds = model.predict(X_test)

r2_train = r2_score(y_train, train_preds)
r2_test = r2_score(y_test, test_preds)

print(f"Training R²: {r2_train:.4f}")
print(f"Testing  R²: {r2_test:.4f}")
print(f"Difference:  {abs(r2_train - r2_test):.4f}")
```

**Output:**
```
Training R²: 0.5342
Testing  R²: 0.5362
Difference:  0.0020
```
A difference of only $0.002$ between training and testing confirms near-perfect model generalization.

## Step-by-Step Student Instructions
1. Calculate `r2 = r2_score(y_test, predictions)` on the test predictions.
2. Calculate the training $R^2$ using `r2_train = r2_score(y_train, model.predict(X_train))`.
3. Compare the two values and verify that the model does not suffer from overfitting.
4. Calculate the square of the Pearson correlation coefficient between `X_train` and `y_train` to verify $r^2 = R^2$.
5. Write an explanation defending why $0.54$ is the expected biological ceiling for single-feature height models.

## Expected Output or Observable Behaviour
Output in terminal:
```
R-squared: 0.54
```
Students observe that the model captures over half of the biological variance while remaining completely free of overfitting.

## Practical Exercises
- **Exercise 2.1:** What is the mathematical relationship between Pearson correlation $r$ and $R^2$ in simple linear regression?
- **Exercise 2.2:** What would a significant gap between training $R^2$ ($0.95$) and testing $R^2$ ($0.35$) indicate?
- **Exercise 2.3:** Why is an $R^2$ of $0.54$ considered a successful result in human stature modeling?

## Common Mistakes and Debugging
| Mistake | Why It Is Wrong | Proper Understanding |
|---|---|---|
| Claiming R² is an accuracy percentage | R² measures variance explained; it is not a percentage of correct answers | R² describes how well the line accounts for data dispersion |
| Confusing R² with correlation r | $r$ ranges from -1 to +1; $R^2$ ranges from $-\infty$ to 1.0 ($r^2$ is always non-negative) | $R^2 = r^2$ in bivariate regression |
| Assuming negative R² is impossible | If a model performs worse than predicting the mean on test data, R² can be negative | Scikit-learn's `r2_score` can produce negative values for severely misfitted models |

## Best Practices and Security Considerations
- **Order of Arguments:** Always pass `(y_true, y_pred)` to scikit-learn metric functions to prevent bugs in asymmetric metrics.
- **Holistic Interpretation:** Always report $R^2$ in combination with MAE to give both relative and absolute performance context.

## Summary
Evaluating $R^2$ on the test partition confirms that midparent height explains approximately $54\%$ of adult child stature variation. The close agreement between training $R^2$ and testing $R^2$ demonstrates that the model captures a robust biological trend without overfitting.

## Knowledge-check Questions
1. In bivariate linear regression, what is $R^2$ mathematically equal to?
2. What does a near-zero difference between train and test $R^2$ prove about a model?
3. What is the baseline prediction against which $R^2$ is measured?
4. What is the value of $R^2$ formatted in `main.py`?

## References
- Scikit-learn r2_score Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.metrics.r2_score.html
- Wright, S. (1921). "Correlation and causation." *Journal of Agricultural Research*.
