# Lesson 03: Building Multi-Layer Matplotlib Regression Plots

**Lesson ID:** lesson-03
**Module:** module-05
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Configure matplotlib to use the non-interactive `"Agg"` backend for headless execution.
- Construct a multi-layered Cartesian plot visualizing training points, test points, and trend lines.
- Generate a continuous interpolation grid across feature ranges using `np.linspace`.
- Style visual elements with distinct colors, alpha transparency, marker styles, and labels.

## Prerequisites
- Completion of Lesson 02 (Evaluating Test Set Goodness of Fit with R-squared).
- Basic understanding of matplotlib `pyplot` and Cartesian scatter plots.

## Concept Explanation

### The Importance of Visualization in Regression
Numbers like slope $= 0.88$, MAE $= 3.1$ cm, and $R^2 = 0.54$ describe the model analytically. But human beings understand relationships best through visual representations. A well-designed regression plot communicates four critical insights at a single glance:
1. The distribution and spread of training families.
2. The location and scatter of held-out test families.
3. The fitted linear regression trend line.
4. Specific point predictions (such as the 170 cm benchmark family).

### Headless Architecture with the Agg Backend
In automated machine learning pipelines, scripts often run on headless remote servers, Docker containers, or automated grading environments where no graphical desktop display (such as X11 or Wayland) is available. If a script attempts to open a GUI window with `plt.show()`, it crashes with a `TclError` or display failure.

In `main.py`, lines 12–14 configure matplotlib to use the **Agg backend**:
```python
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
```
The Agg (Anti-Grain Geometry) backend renders raster images directly into file buffers in memory without requiring any graphical display server.

### The 4 Layers of the Height Regression Plot
The visualization in `main.py` builds four distinct visual layers on a single axis:
1. **Layer 1: Training Families:** Plotted as purple circular dots (`#8e44ad`, size 50, alpha 0.8) to represent the 45 fitting examples.
2. **Layer 2: Test Families:** Plotted as teal squares (`#16a085`, size 60, marker `'s'`) to represent the 15 evaluation examples.
3. **Layer 3: Trend Line:** Plotted as a solid dark red line (`#c0392b`, linewidth 2.5) representing model predictions across the continuous domain.
4. **Layer 4: Benchmark Prediction:** Plotted as a prominent black star (`#111111`, marker `'*'`, size 220) to highlight the prediction for parents of 170 cm stature.

## Relevant Code (from main.py, lines 12-15, 57-69)
```python
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
...
    line_x = np.linspace(df["midparent_cm"].min(), df["midparent_cm"].max(), 100)
    line_y = model.predict(pd.DataFrame({"midparent_cm": line_x}))

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.scatter(X_train, y_train, color="#8e44ad", s=50, alpha=0.8, label="training families")
    ax.scatter(X_test, y_test, color="#16a085", s=60, marker="s", label="test families")
    ax.plot(line_x, line_y, color="#c0392b", linewidth=2.5, label="trend line")
    ax.scatter([170], [example], color="#111111", marker="*", s=220, zorder=5, label="170 cm example")
    ax.set_xlabel("Midparent height (cm)")
    ax.set_ylabel("Child height (cm)")
    ax.set_title("Parent height vs. child height")
    ax.legend()
    ax.grid(alpha=0.25)
```

## Code Explanation & Walkthrough
Let us trace each plotting step:
- `np.linspace(df["midparent_cm"].min(), df["midparent_cm"].max(), 100)`: Generates 100 evenly spaced numbers between the minimum observed midparent height (~$164.3$ cm) and the maximum (~$180.8$ cm).
- `line_y = model.predict(...)`: Evaluates the regression model at each of those 100 points, producing a perfectly smooth line.
- `fig, ax = plt.subplots(figsize=(7, 5))`: Initializes a 7x5 inch figure canvas.
- `ax.scatter(..., color="#8e44ad", alpha=0.8)`: Uses semi-transparency (`alpha=0.8`) so overlapping data points remain visible.
- `ax.set_xlabel`, `ax.set_ylabel`, `ax.set_title`: Provide complete, informative labels with physical units.
- `ax.grid(alpha=0.25)`: Adds a subtle background grid for easy coordinate reading.

## Worked Example
Let us execute the plotting logic and inspect the resulting canvas properties:
```python
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# Verify Agg backend is active
print("Active backend:", matplotlib.get_backend())

# Verify linspace range
min_val = 164.3
max_val = 180.8
grid = np.linspace(min_val, max_val, 5)
print("Linspace sample points:", grid.round(2))
```

**Output:**
```
Active backend: agg
Linspace sample points: [164.3  168.42 172.55 176.67 180.8 ]
```
The Agg backend is confirmed active, and `linspace` generates an evenly distributed grid across the feature domain.

## Step-by-Step Student Instructions
1. Ensure `matplotlib.use("Agg")` is placed **before** `import matplotlib.pyplot as plt`.
2. Generate 100 interpolation points using `np.linspace(df["midparent_cm"].min(), df["midparent_cm"].max(), 100)`.
3. Wrap `line_x` in a pandas DataFrame: `pd.DataFrame({"midparent_cm": line_x})`.
4. Predict heights along the grid: `line_y = model.predict(...)`.
5. Call `plt.subplots(figsize=(7, 5))`.
6. Plot the training points (purple circles), test points (teal squares), and line (red).
7. Apply labels, title, legend, and subtle grid.

## Expected Output or Observable Behaviour
When the plot is rendered, the visualization clearly presents:
- Purple circles scattered around the trend line.
- Teal squares showing test family spread.
- A clean red line cutting through the data points with a slope of $0.88$.
- A prominent black star at $(170.0, 171.6)$.

## Practical Exercises
- **Exercise 3.1:** Why must `matplotlib.use("Agg")` be executed before importing `matplotlib.pyplot`?
- **Exercise 3.2:** What is the purpose of using `np.linspace` instead of plotting only the training points?
- **Exercise 3.3:** How does setting `alpha=0.8` improve scatter plot clarity?

## Common Mistakes and Debugging
| Mistake | Why It Is Wrong | Proper Understanding |
|---|---|---|
| Calling `plt.show()` in a headless environment | Crashes with display/TclError on servers without graphical desktop | Use `fig.savefig(...)` with the Agg backend |
| Setting `matplotlib.use("Agg")` after importing pyplot | Matplotlib issues a warning; the backend cannot be switched once initialized | Always configure the backend BEFORE importing pyplot |
| Plotting test points without marker differentiation | Observers cannot distinguish training samples from unseen evaluation samples | Use distinct shapes and colors (e.g. circles vs squares) |

## Best Practices and Security Considerations
- **Non-Interactive First:** Always design plotting code to run non-interactively using file export by default.
- **Accessible Contrast:** Choose colors with strong visual contrast (purple `#8e44ad`, teal `#16a085`, dark red `#c0392b`).

## Summary
Matplotlib's Agg backend enables robust, headless figure generation. By combining training scatter, test scatter, and a continuous regression trend line generated via `np.linspace`, the visualization provides an immediate, intuitive view of model behavior and biological variance.

## Knowledge-check Questions
1. Which matplotlib backend allows headless rendering without a graphical display server?
2. What colors and markers are used for training families versus test families?
3. How many points are generated by `np.linspace` to draw the regression line?
4. Why is `pd.DataFrame` used when generating predictions for `line_x`?

## References
- Matplotlib Backends Guide: https://matplotlib.org/stable/users/explain/backends.html
- Matplotlib Scatter Plot Reference: https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.scatter.html
