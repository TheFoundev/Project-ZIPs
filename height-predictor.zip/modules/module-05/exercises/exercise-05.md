# Module 5 Exercises: Evaluation & Visualization

## Exercise 5.1: Computing MAE and Physical Unit Interpretation (10 min)
**Objective:** Calculate Mean Absolute Error in centimeters using scikit-learn and interpret the result.
**Problem Statement:** Evaluate the test set predictions of the Height Predictor model using `mean_absolute_error` and formulate a non-technical explanation of the error magnitude.

**Requirements:**
1. Generate test predictions using `predictions = model.predict(X_test)`.
2. Compute `mae = mean_absolute_error(y_test, predictions)`.
3. Format MAE to 1 decimal place with units (`3.1 cm`).
4. Write a 2-sentence explanation of what this error means for a family consulting the model.

**Constraints:** Use scikit-learn's `mean_absolute_error`.

**Expected Behaviour:** Python printout of the formatted MAE and an interpretation statement.

**Acceptance Criteria:**
- [ ] Correctly calculates MAE as approximately 3.1 cm (3.081 cm).
- [ ] Explicitly includes physical units ("cm").
- [ ] Explanation notes that typical prediction deviation is ~3.1 cm.

**Hints:**
- Format string: `f"{mae:.1f} cm"`.

**Difficulty:** Basic
**Estimated Completion Time:** 10 minutes

---

## Exercise 5.2: Comparing Training and Testing R-squared (15 min)
**Objective:** Compute $R^2$ on both training and testing sets to evaluate model generalization.
**Problem Statement:** Determine whether the Height Predictor suffers from overfitting by calculating and comparing $R^2$ scores across training and testing partitions.

**Requirements:**
1. Compute `r2_train = r2_score(y_train, model.predict(X_train))`.
2. Compute `r2_test = r2_score(y_test, model.predict(X_test))`.
3. Compute the absolute difference `abs(r2_train - r2_test)`.
4. Determine whether the model exhibits overfitting or strong generalization.

**Constraints:** Use `r2_score` from `sklearn.metrics`.

**Expected Behaviour:** Program output displaying train R², test R², difference, and an evaluation verdict.

**Acceptance Criteria:**
- [ ] Reports train R² (~0.53) and test R² (~0.54).
- [ ] Confirms the difference is less than 0.01.
- [ ] Concludes that the model generalizes robustly without overfitting.

**Hints:**
- Overfitting typically produces a large drop from training to testing R².

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 5.3: Constructing the Multi-Layer Regression Plot (15 min)
**Objective:** Replicate the 4-layer visualization of `main.py` using matplotlib.
**Problem Statement:** Write a Python function to construct the scatter plot showing training families (purple circles), test families (teal squares), trend line (red line), and the 170 cm benchmark prediction (black star).

**Requirements:**
1. Configure `matplotlib.use("Agg")` before importing pyplot.
2. Generate 100 interpolation points between min and max midparent stature using `np.linspace`.
3. Plot training points (`#8e44ad`, circles), test points (`#16a085`, squares), line (`#c0392b`), and star (`#111111`, `zorder=5`).
4. Add axis labels with units, plot title, legend, and subtle grid (`alpha=0.25`).
5. Save figure to `outputs/height_regression.png` with `dpi=150` and `bbox_inches="tight"`.

**Constraints:** Use matplotlib object-oriented API (`fig, ax = plt.subplots()`).

**Expected Behaviour:** Python script that executes headless and writes `outputs/height_regression.png`.

**Acceptance Criteria:**
- [ ] Correctly uses headless Agg backend.
- [ ] All 4 visual layers present with specified colors and markers.
- [ ] Benchmark prediction has `zorder=5`.
- [ ] Image saved at 150 DPI and figure closed cleanly with `plt.close(fig)`.

**Hints:**
- Review lines 57–72 in `main.py`.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 5.4: Automated Artifact Logging Pipeline (20 min)
**Objective:** Implement structured file logging for regression metrics and parameter exports.
**Problem Statement:** Implement the file export logic in `main.py` that writes `outputs/metrics.txt` with equation, MAE, R², and benchmark query.

**Requirements:**
1. Ensure the `outputs/` directory exists using `Path.mkdir(exist_ok=True)`.
2. Format the learned equation with slope and intercept to 4 decimal places.
3. Format MAE and R² to 4 decimal places.
4. Format the 170 cm prediction to 2 decimal places.
5. Write the file with UTF-8 encoding and verify that the file exists and is non-empty.

**Constraints:** Use `with open(..., "w", encoding="utf-8")` context manager.

**Expected Behaviour:** Complete file writing script and automated assertion check confirming file presence and line counts.

**Acceptance Criteria:**
- [ ] Creates `outputs/metrics.txt` cleanly.
- [ ] Contains all 4 required lines with exact metric labels.
- [ ] Uses 4 decimal places for parameters and metrics.
- [ ] Verifies file presence using `Path.exists()`.

**Hints:**
- Review lines 74–77 in `main.py`.

**Difficulty:** Basic
**Estimated Completion Time:** 20 minutes
