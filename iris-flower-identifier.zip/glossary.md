# Glossary

| Term | Definition |
|---|---|
| **Classification** | Supervised learning task where the target output consists of discrete categorical classes rather than continuous numbers. |
| **Decision Tree** | A non-parametric supervised learning algorithm that partitions data through a series of hierarchical binary if-then questions based on feature thresholds. |
| **Gini Impurity** | A metric measuring the frequency with which a randomly chosen element from a node would be incorrectly labeled; values range from 0 (pure node) to 0.5 (equal split in binary cases). |
| **max_depth** | A hyperparameter controlling the maximum length of the longest path from the tree's root node to any leaf node; limits tree complexity and prevents overfitting. |
| **Feature (X)** | Input attributes used by the model to make predictions. In this project: `sepal_length`, `sepal_width`, `petal_length`, and `petal_width`. |
| **Target (y)** | The outcome label to be predicted. In this project: `species` (`setosa`, `versicolor`, or `virginica`). |
| **Stratified Split** | A train/test partition technique (`stratify=y`) ensuring both training and testing sets maintain the exact same proportion of each target class as the original dataset. |
| **Root Node** | The top node of a decision tree where the very first feature threshold test is performed on the entire training set. |
| **Leaf Node (Terminal Node)** | An end node that contains no further split conditions and outputs a predicted class label or class probability distribution. |
| **export_text** | A scikit-learn function that converts a trained tree model into an ASCII-formatted hierarchy of logical rules. |
| **plot_tree** | A scikit-learn function using matplotlib to draw colored, boxed nodes illustrating split conditions, sample counts, and class majorities. |
| **Overfitting** | When a model learns noise, anomalies, and idiosyncrasies of the training data so closely that its performance degrades on unseen test data. |
| **Underfitting** | When a model is too simplistic to capture the underlying structure of the data, resulting in poor performance on both training and test sets. |
| **Confusion Matrix** | A square matrix showing actual class labels versus predicted class labels, highlighting exactly where the model confuses one category with another. |
| **Precision** | The proportion of positive predictions that were correct: True Positives / (True Positives + False Positives). |
| **Recall (Sensitivity)** | The proportion of actual category instances correctly identified: True Positives / (True Positives + False Negatives). |
| **F1-Score** | The harmonic mean of precision and recall: 2 * (Precision * Recall) / (Precision + Recall). |
| **Sepal** | The outer botanical structure that protects the flower bud before opening; usually green, though colorful in irises. |
| **Petal** | The inner, typically colorful leaves of a flower that attract pollinators; in irises, petals provide superior class separability. |
| **White-Box Model** | A transparent machine learning model whose internal logic and decision paths can be directly inspected, audited, and understood by humans. |
