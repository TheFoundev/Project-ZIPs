# Final Project Requirements: The Iris Flower Identifier

## Project Objective
Reconstruct the complete **Iris Flower Identifier** pipeline from scratch. You will load the 150-row Iris dataset, separate features and target, perform a stratified train/test split, train and compare decision trees across three depths (`max_depth=2`, `max_depth=3`, `max_depth=None`), evaluate performance with classification metrics, visualize the tree and confusion matrix, and predict the species of a new flower sample.

---

## Detailed Functional Specifications

### 1. Script Architecture & Setup
- Set the Matplotlib backend to non-interactive mode using `matplotlib.use("Agg")` **before** importing `matplotlib.pyplot`.
- Define filesystem paths relative to the script location using `pathlib.Path(__file__).resolve().parent`.
- Automatically create the destination directory `outputs/` using `.mkdir(exist_ok=True)`.
- Define the feature list constant: `FEATURES = ["sepal_length", "sepal_width", "petal_length", "petal_width"]`.

### 2. Data Loading & Feature Preparation
- Load `data/iris.csv` into a pandas DataFrame.
- Verify the dataset contains 150 rows and 5 columns.
- Separate the input feature matrix $X$ using `df[FEATURES]`.
- Separate the target vector $y$ using `df["species"]`.

### 3. Stratified Partitioning
- Split the dataset into training and testing sets using `train_test_split()`.
- Set `test_size=0.25` (38 test samples, 112 training samples).
- Set `random_state=42` to ensure reproducible data shuffling.
- Set `stratify=y` to guarantee identical species ratios in both train and test splits.

### 4. Depth Hyperparameter Tuning
- Compare three specific tree depths: `2`, `3`, and `None` (unlimited).
- For each depth:
  - Instantiate `DecisionTreeClassifier(max_depth=depth, random_state=42)`.
  - Train the tree on `X_train` and `y_train`.
  - Generate predictions on `X_test`.
  - Compute accuracy using `accuracy_score(y_test, predictions)`.
  - Store `(model, predictions, accuracy)` in a dictionary keyed by depth.
  - Print the formatted accuracy for each depth.
- Programmatically determine the best depth using `max(models, key=lambda d: models[d][2])`.

### 5. Rule Extraction & Text Reporting
- Generate text rules using `export_text(model, feature_names=FEATURES)`.
- Print learned rules for the winning model to the console.
- Generate and print the complete classification report using `classification_report(y_test, predictions, zero_division=0)`.

### 6. Novel Sample Inference
- Construct a single-row pandas DataFrame `new_flower` with measurements:
  - `sepal_length`: 5.8
  - `sepal_width`: 2.7
  - `petal_length`: 4.1
  - `petal_width`: 1.0
- Execute `model.predict(new_flower)` and print the resulting species classification (`versicolor`).

### 7. Visualization & File Exports
- **Tree Visualization**:
  - Create a figure with `figsize=(16, 8)`.
  - Render the tree with `plot_tree(model, feature_names=FEATURES, class_names=list(model.classes_), filled=True, rounded=True, fontsize=8)`.
  - Save to `outputs/iris_tree.png` with `dpi=150` and `bbox_inches="tight"`.
- **Confusion Matrix**:
  - Compute `confusion_matrix(y_test, predictions, labels=labels)`.
  - Render with `ConfusionMatrixDisplay` using colormap `"Greens"`.
  - Save to `outputs/confusion_matrix.png` with `dpi=150` and `bbox_inches="tight"`.
- **Rules Documentation**:
  - Write depth accuracies, best depth, text rules, novel prediction, and classification report to `outputs/rules.txt`.

---

## Acceptance Criteria
- [ ] Script runs without errors: `python main.py` exits with code 0.
- [ ] Console output matches expected depth comparison:
  - `max_depth=2`: 92.1%
  - `max_depth=3`: 89.5%
  - `max_depth=unlimited`: 89.5%
- [ ] Best tree selected is `max_depth=2`.
- [ ] Prediction for `new_flower` correctly outputs `versicolor`.
- [ ] All 3 output files created in `outputs/`: `iris_tree.png`, `confusion_matrix.png`, `rules.txt`.
- [ ] Analysis accurately explains why `max_depth=2` outperforms `max_depth=None` on the test set.
