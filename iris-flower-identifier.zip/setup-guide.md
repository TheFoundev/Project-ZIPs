# Setup Guide

This guide walks you through setting up the environment, installing dependencies, running the Iris Flower Identifier project, and reviewing the generated outputs.

---

## Step 1: Navigate to the Source Project
Open your terminal and navigate to the project root directory:

```bash
cd "/home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/14_iris_identifier"
```

Verify that the project structure contains the source code and data directory:

```bash
ls -la
# Expected contents:
# main.py
# data/iris.csv
```

---

## Step 2: Set Up Python Environment & Dependencies
Ensure your Python environment is active and install the required machine learning packages:

```bash
pip install pandas matplotlib scikit-learn
```

To verify the installation:

```bash
python -c "import pandas, matplotlib, sklearn; print('All libraries imported successfully!')"
```

---

## Step 3: Inspect the Dataset
Examine the raw Iris dataset before executing the model:

```bash
head -n 5 data/iris.csv
```

Expected output:
```csv
sepal_length,sepal_width,petal_length,petal_width,species
5.1,3.5,1.4,0.2,setosa
4.9,3.0,1.4,0.2,setosa
4.7,3.2,1.3,0.2,setosa
4.6,3.1,1.5,0.2,setosa
```

Check the total number of lines:
```bash
wc -l data/iris.csv
# Outputs 151 (header + 150 flower records)
```

---

## Step 4: Run the Machine Learning Pipeline
Execute the main script:

```bash
python main.py
```

---

## Step 5: Check Console Output
Upon successful execution, the terminal will print:
1. Tree depth comparison across `max_depth=2`, `max_depth=3`, and `max_depth=unlimited`
2. Identification of the best tree (`max_depth=2` with 92.1% accuracy)
3. Text-based rules learned by the optimal tree
4. A full multi-class classification report
5. The species prediction for a novel flower (`[5.8, 2.7, 4.1, 1.0]` -> `versicolor`)
6. Confirmation that graphics and text rules were written to disk

---

## Step 6: Verify Generated Artifacts
Check the `outputs/` folder:

```bash
ls -la outputs/
```

You should see:
- `iris_tree.png`: Graphical tree diagram showing split criteria and class colors
- `confusion_matrix.png`: Heatmap showing true vs. predicted species
- `rules.txt`: Saved text rules, depth accuracies, and evaluation summary
