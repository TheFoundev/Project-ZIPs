# The Iris Flower Identifier

An educational machine learning project demonstrating multi-class classification, hyperparameter tuning, model interpretability, and the bias-variance tradeoff using Decision Trees on Ronald Fisher's historic 1936 Iris dataset.

---

## Project Overview

In 1936, British statistician and biologist Ronald Fisher published a landmark paper introducing the Iris dataset. Today, it remains the quintessential benchmark in machine learning education.

The Iris dataset contains 150 observations of three iris flower species:
- *Iris setosa* (50 samples)
- *Iris versicolor* (50 samples)
- *Iris virginica* (50 samples)

For each flower, four physical dimensions were recorded: sepal length, sepal width, petal length, and petal width (all measured in centimeters).

This project trains and compares multiple **Decision Tree Classifiers** to automatically identify species based on these measurements. Unlike "black-box" models (such as deep neural networks), decision trees generate human-readable rules that can be audited, visualized, and traced step by step.

---

## Real-World Relevance

Decision trees and their rule-based representations are widely used in:
- **Medical Diagnostics**: Creating transparent clinical decision protocols (e.g., triage decision trees based on patient vitals).
- **Credit Scoring & Underwriting**: Providing transparent loan approvals where legal regulations mandate explainable decisions.
- **Ecological & Agricultural Sensing**: Sorting produce or identifying botanical species using automated optical measurements.

---

## Core Machine Learning Concepts Covered

1. **Multi-Class Supervised Classification**: Distinguishing between three classes rather than two.
2. **Feature Discrimination**: Understanding why petal dimensions separate species far better than sepal dimensions.
3. **Stratified Sampling**: Ensuring train and test partitions preserve identical species distributions.
4. **Hyperparameter Tuning (`max_depth`)**: Comparing shallow trees (`max_depth=2`) with deeper architectures (`max_depth=3`, `max_depth=None`).
5. **The Overfitting Trap**: Witnessing firsthand why a simpler tree (`max_depth=2`, 92.1% accuracy) outperforms deeper trees (89.5% accuracy) on unseen test data.
6. **White-Box Model Interpretability**: Reading tree logic with `export_text` and visualizing tree structures with `plot_tree`.
7. **Multi-Class Evaluation**: Diagnosing classification confusion with precision, recall, F1-scores, and confusion matrices.

---

## Project Structure

```
14_iris_identifier/
├── main.py                     # Main execution script
├── data/
│   └── iris.csv                # 150-row botanical dataset
└── outputs/
    ├── iris_tree.png           # Rendered decision tree diagram
    ├── confusion_matrix.png    # 3x3 species confusion matrix heatmap
    └── rules.txt               # Plain-text rules and evaluation summary
```

---

## How It Works

1. **Loads Data**: Reads `data/iris.csv` into a pandas DataFrame.
2. **Separates Variables**: Defines feature matrix $X$ using 4 measurements and target vector $y$ as `species`.
3. **Splits Data**: Divides data 75/25 into training (112 flowers) and testing (38 flowers) sets using `stratify=y`.
4. **Tunes Depth**: Fits three decision trees with `max_depth=2`, `max_depth=3`, and `max_depth=None`.
5. **Selects Optimal Model**: Evaluates test accuracy and selects the best performer (`max_depth=2` at 92.1%).
6. **Exports Rules**: Prints the learned decision thresholds using scikit-learn's `export_text`.
7. **Predicts New Sample**: Feeds a new flower observation (`[5.8, 2.7, 4.1, 1.0]`) into the model, identifying it as `versicolor`.
8. **Visualizes & Saves**: Saves `iris_tree.png`, `confusion_matrix.png`, and `rules.txt`.
