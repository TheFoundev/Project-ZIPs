# Project Summary: The Iris Flower Identifier

## Executive Summary
The **Iris Flower Identifier** is a beginner-level educational project designed to teach supervised multi-class classification, hyperparameter tuning, model evaluation, and machine learning interpretability using scikit-learn and pandas.

By working through the classic 150-row Iris botanical benchmark, learners discover how decision trees partition feature space using intuitive threshold rules, how to visually trace classification paths, and why simpler models frequently outperform deeper, overfitted alternatives on unseen test data.

---

## Key Project Specifications

| Attribute | Specification |
|---|---|
| **Project Title** | The Iris Flower Identifier |
| **Project Slug** | `iris-flower-identifier` |
| **Domain** | Supervised Machine Learning (Multi-Class Classification) |
| **Algorithm** | Decision Tree Classifier (`DecisionTreeClassifier`) |
| **Dataset** | `data/iris.csv` (150 rows, 5 columns: 4 numerical features, 1 categorical target) |
| **Features** | `sepal_length`, `sepal_width`, `petal_length`, `petal_width` |
| **Target Variable** | `species` (`setosa`, `versicolor`, `virginica`) |
| **Data Partition** | 75% Training (112 samples), 25% Testing (38 samples), `random_state=42`, `stratify=y` |
| **Hyperparameter Comparison** | `max_depth=2`, `max_depth=3`, `max_depth=None` (unlimited) |
| **Winning Model** | `max_depth=2` (Accuracy: 92.1% on test set) |
| **Learned Split Rules** | Rule 1: `petal_length <= 2.45` -> `setosa`<br>Rule 2: `petal_length > 2.45` and `petal_length <= 4.85` -> `versicolor`<br>Rule 3: `petal_length > 4.85` -> `virginica` |
| **Novel Sample Prediction** | `[5.8, 2.7, 4.1, 1.0]` -> `versicolor` |
| **Output Files** | `outputs/iris_tree.png`, `outputs/confusion_matrix.png`, `outputs/rules.txt` |

---

## Pedagogical Insights

1. **Why Decision Trees?**
   Decision trees represent "white-box" algorithms. Learners can directly inspect the exact mathematical thresholds used to separate categories. In this dataset, the decision tree discovers that `petal_length <= 2.45 cm` isolates 100% of the *setosa* flowers with zero error.

2. **The Power of Hyperparameter Tuning & Overfitting**:
   When `max_depth=None`, the decision tree grows until every single training sample is classified with 100% training accuracy. However, when tested on unseen test data, accuracy drops to 89.5%. In contrast, the restricted tree (`max_depth=2`) achieves 92.1% test accuracy. This demonstrates the core ML principle: **higher complexity on training data does not guarantee better generalization**.

3. **Multi-Class Evaluation**:
   Unlike binary classification, evaluating 3 classes requires understanding multi-class confusion matrices, macro/weighted averages, and per-class precision/recall. In our test set, `setosa` is identified with perfect 1.00 precision and recall, while subtle boundary overlap exists between `versicolor` and `virginica`.
