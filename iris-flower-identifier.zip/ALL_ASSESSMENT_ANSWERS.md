# Comprehensive Assessment Answer Key and Explanations

**Project:** Iris Flower Identifier (Machine Learning for Beginners)
**Total Modules:** 6
**Total Questions:** 60 Multiple-Choice Questions (10 per module)
**Question Breakdown per Module:** 3 Basic, 5 Intermediate, 2 Advanced

---

## Table of Contents

- [Module 01: Project Overview: The Iris Dataset & Decision Trees](#module-01)
- [Module 02: Data Ingestion, Feature Inspection & Stratification](#module-02)
- [Module 03: Decision Tree Depth Tuning & Hyperparameter Optimization](#module-03)
- [Module 04: Visualizing Trees & Reading Decision Rules](#module-04)
- [Module 05: Comprehensive Evaluation: Metrics, Classification Report & Confusion Matrix](#module-05)
- [Module 06: Pipeline Execution, Flower Prediction & The Overfitting Lesson](#module-06)
- [Master Answer Matrix](#master-answer-matrix)

---

<a id="module-01"></a>
## Module 01: Project Overview: The Iris Dataset & Decision Trees

### Question 1: What type of machine learning problem does the Iris Flower Identifier project solve?

- **Question ID:** `q1-01`
- **Difficulty:** Basic
- **Target Lesson:** `lesson-03`
- **Learning Objective:** Differentiate multi-class classification from binary classification and regression
- **Core Concept:** Supervised multi-class classification definition
- **Reference:** main.py lines 1-8 docstring and DecisionTreeClassifier

**Options:**
- `A)` Unsupervised clustering
- `B)` Supervised multi-class classification
- `C)` Supervised linear regression
- `D)` Reinforcement learning

**Correct Answer:** `B` — Supervised multi-class classification

**Explanation:** The Iris Flower Identifier predicts categorical species (setosa, versicolor, virginica) from labeled continuous measurements, which defines supervised multi-class classification.

**Distractor Analysis:**
- `A` (Unsupervised clustering): Unsupervised clustering groups data without known target labels; this project uses labeled species data.
- `C` (Supervised linear regression): Linear regression predicts continuous numeric values; here we predict categorical species names.
- `D` (Reinforcement learning): Reinforcement learning learns via agents receiving rewards in an interactive environment, not static tabular data.

---

### Question 2: Who published the famous Iris dataset in a 1936 statistical biology paper?

- **Question ID:** `q1-02`
- **Difficulty:** Basic
- **Target Lesson:** `lesson-01`
- **Learning Objective:** Understand the historical significance of Ronald Fisher's 1936 Iris benchmark dataset
- **Core Concept:** Historical origin of the Iris benchmark
- **Reference:** Lesson 01 Concept Explanation: Fisher (1936)

**Options:**
- `A)` Alan Turing
- `B)` Ronald A. Fisher
- `C)` Ada Lovelace
- `D)` Geoffrey Hinton

**Correct Answer:** `B` — Ronald A. Fisher

**Explanation:** Ronald A. Fisher introduced the dataset in his 1936 paper 'The use of multiple measurements in taxonomic problems'.

**Distractor Analysis:**
- `A` (Alan Turing): Alan Turing was the father of theoretical computer science and cryptography, not the author of the 1936 Iris paper.
- `C` (Ada Lovelace): Ada Lovelace wrote the first computer algorithm for Babbage's Analytical Engine in the 1840s.
- `D` (Geoffrey Hinton): Geoffrey Hinton is known for deep learning and neural network research starting in the 1980s.

---

### Question 3: How many total flower samples and species are in the classic Iris dataset?

- **Question ID:** `q1-03`
- **Difficulty:** Basic
- **Target Lesson:** `lesson-01`
- **Learning Objective:** Understand the historical significance of Ronald Fisher's 1936 Iris benchmark dataset
- **Core Concept:** Dataset dimensions and class counts
- **Reference:** main.py docstring line 6: 'The classic 150-row Iris dataset'

**Options:**
- `A)` 100 samples across 2 species
- `B)` 150 samples across 3 species
- `C)` 300 samples across 3 species
- `D)` 1500 samples across 10 species

**Correct Answer:** `B` — 150 samples across 3 species

**Explanation:** The Iris dataset contains exactly 150 rows of data spanning 3 distinct species (50 samples per species).

**Distractor Analysis:**
- `A` (100 samples across 2 species): 100 samples across 2 species would be incomplete; there are 150 samples across 3 species.
- `C` (300 samples across 3 species): 300 samples is twice the actual size; there are 150 records.
- `D` (1500 samples across 10 species): 1500 samples across 10 species is incorrect; Iris is a compact 150-sample dataset.

---

### Question 4: What is the botanical function of an iris sepal?

- **Question ID:** `q1-04`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-02`
- **Learning Objective:** Distinguish botanical flower structures between sepals and petals across 4 physical dimensions
- **Core Concept:** Botanical morphology of sepals vs petals
- **Reference:** Lesson 02 Concept Explanation: Botanical Morphology

**Options:**
- `A)` It serves as the reproductive pollen grain
- `B)` It is the root system that absorbs water
- `C)` It forms the outer whorl that protects the developing flower bud
- `D)` It produces fruit after seed fertilization

**Correct Answer:** `C` — It forms the outer whorl that protects the developing flower bud

**Explanation:** Botanically, sepals form the outermost floral whorl, protecting the flower bud before it opens into bloom.

**Distractor Analysis:**
- `A` (It serves as the reproductive pollen grain): Pollen is produced by the male stamen/anther, not the sepal.
- `B` (It is the root system that absorbs water): Roots absorb water from soil; sepals are aerial floral organs.
- `D` (It produces fruit after seed fertilization): Ovaries/carpels develop into fruit after fertilization, not sepals.

---

### Question 5: Which list correctly names all three species in the dataset?

- **Question ID:** `q1-05`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-03`
- **Learning Objective:** Differentiate multi-class classification from binary classification and regression
- **Core Concept:** Iris target species names
- **Reference:** main.py lines 32 and 70: classes_ in model

**Options:**
- `A)` setosa, versicolor, virginica
- `B)` robusta, arabica, excelsa
- `C)` monarch, viceroy, swallowtail
- `D)` indica, japonica, sativa

**Correct Answer:** `A` — setosa, versicolor, virginica

**Explanation:** The three iris species in the dataset are Iris setosa, Iris versicolor, and Iris virginica.

**Distractor Analysis:**
- `B` (robusta, arabica, excelsa): Robusta, arabica, and excelsa are species of coffee plants (Coffea), not irises.
- `C` (monarch, viceroy, swallowtail): Monarch, viceroy, and swallowtail are butterfly species.
- `D` (indica, japonica, sativa): Indica, japonica, and sativa are subspecies of rice or cannabis, not irises.

---

### Question 6: Why are decision trees characterized as 'white-box' machine learning models?

- **Question ID:** `q1-06`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-04`
- **Learning Objective:** Explain how decision trees formulate human-readable, transparent rule hierarchies
- **Core Concept:** White-box interpretability vs black-box opacity
- **Reference:** Lesson 04 Concept Explanation: Black-Box vs. White-Box Models

**Options:**
- `A)` They only process grayscale black-and-white image files
- `B)` Their internal if-then decision thresholds are transparent and interpretable by humans
- `C)` They do not consume computer memory during training
- `D)` They cannot make prediction errors

**Correct Answer:** `B` — Their internal if-then decision thresholds are transparent and interpretable by humans

**Explanation:** White-box models are transparent; humans can inspect every decision node and follow the exact if-then thresholds that led to a prediction.

**Distractor Analysis:**
- `A` (They only process grayscale black-and-white image files): White-box has nothing to do with image color or grayscale palettes.
- `C` (They do not consume computer memory during training): Decision trees definitely consume computer memory like any data structure.
- `D` (They cannot make prediction errors): Decision trees can still make errors; interpretability does not equal 100% accuracy.

---

### Question 7: What are the four physical features measured in centimeters in `main.py`?

- **Question ID:** `q1-07`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-02`
- **Learning Objective:** Distinguish botanical flower structures between sepals and petals across 4 physical dimensions
- **Core Concept:** Exact feature names in project code
- **Reference:** main.py line 26: FEATURES = ['sepal_length', 'sepal_width', 'petal_length', 'petal_width']

**Options:**
- `A)` stem_length, stem_width, leaf_count, flower_weight
- `B)` sepal_length, sepal_width, petal_length, petal_width
- `C)` petal_color, sepal_color, root_depth, petal_area
- `D)` temperature, rainfall, soil_ph, sunlight_hours

**Correct Answer:** `B` — sepal_length, sepal_width, petal_length, petal_width

**Explanation:** The four features defined in main.py line 26 are sepal_length, sepal_width, petal_length, and petal_width.

**Distractor Analysis:**
- `A` (stem_length, stem_width, leaf_count, flower_weight): Stems, leaves, and weights were not recorded in the Iris dataset.
- `C` (petal_color, sepal_color, root_depth, petal_area): Color, root depth, and area are not columns in data/iris.csv.
- `D` (temperature, rainfall, soil_ph, sunlight_hours): Temperature, rainfall, and soil pH are weather and agronomic variables, not plant measurements.

---

### Question 8: What is the primary difference between binary and multi-class classification?

- **Question ID:** `q1-08`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-03`
- **Learning Objective:** Differentiate multi-class classification from binary classification and regression
- **Core Concept:** Binary vs multi-class classification differences
- **Reference:** Lesson 03 Concept Explanation: Machine Learning Task Hierarchy

**Options:**
- `A)` Binary uses continuous values while multi-class uses text
- `B)` Binary classifies between 2 categories while multi-class classifies among 3 or more
- `C)` Binary runs only on CPUs while multi-class requires GPUs
- `D)` Binary is unsupervised while multi-class is supervised

**Correct Answer:** `B` — Binary classifies between 2 categories while multi-class classifies among 3 or more

**Explanation:** Binary classification chooses between exactly 2 discrete categories; multi-class classification chooses among 3 or more discrete categories.

**Distractor Analysis:**
- `A` (Binary uses continuous values while multi-class uses text): Both binary and multi-class classification predict discrete categorical labels, not continuous numbers.
- `C` (Binary runs only on CPUs while multi-class requires GPUs): Hardware requirements (CPU vs GPU) do not define binary vs multi-class problems.
- `D` (Binary is unsupervised while multi-class is supervised): Both binary and multi-class classification are supervised learning paradigms when trained on labeled data.

---

### Question 9: If a botanist used this data to predict the numerical petal length in cm from the other three measurements, what task type would this be?

- **Question ID:** `q1-09`
- **Difficulty:** Advanced
- **Target Lesson:** `lesson-03`
- **Learning Objective:** Differentiate multi-class classification from binary classification and regression
- **Core Concept:** Distinguishing regression from classification
- **Reference:** Lesson 03 Concept Explanation: Regression vs Classification

**Options:**
- `A)` Multi-class classification
- `B)` Regression
- `C)` Clustering
- `D)` Binary classification

**Correct Answer:** `B` — Regression

**Explanation:** Predicting a continuous numerical value like petal length in centimeters is the definition of regression, not classification.

**Distractor Analysis:**
- `A` (Multi-class classification): Multi-class classification predicts categorical classes, not continuous lengths.
- `C` (Clustering): Clustering finds groupings in unlabeled data without a target.
- `D` (Binary classification): Binary classification predicts between two categories, not a continuous float.

---

### Question 10: In `main.py`, the optimal tree uses rule `petal_length <= 2.45` -> `setosa`. What makes this rule mathematically notable?

- **Question ID:** `q1-10`
- **Difficulty:** Advanced
- **Target Lesson:** `lesson-04`
- **Learning Objective:** Explain how decision trees formulate human-readable, transparent rule hierarchies
- **Core Concept:** Node purity and linear separability of setosa
- **Reference:** main.py lines 55-56 export_text output

**Options:**
- `A)` It isolates 100% of the setosa specimens with zero misclassifications (pure node)
- `B)` It randomly guesses setosa half of the time
- `C)` It requires calculating negative probabilities
- `D)` It proves that sepal width is always identical to petal length

**Correct Answer:** `A` — It isolates 100% of the setosa specimens with zero misclassifications (pure node)

**Explanation:** In the Iris dataset, petal_length <= 2.45 cm perfectly separates all 50 setosa samples from versicolor and virginica with zero errors, creating a pure node.

**Distractor Analysis:**
- `B` (It randomly guesses setosa half of the time): The rule does not guess randomly; it achieves 100% precision and recall for setosa.
- `C` (It requires calculating negative probabilities): Probabilities in decision trees are strictly between 0.0 and 1.0; negative probabilities are impossible.
- `D` (It proves that sepal width is always identical to petal length): The rule tests petal length, not sepal width.

---

<a id="module-02"></a>
## Module 02: Data Ingestion, Feature Inspection & Stratification

### Question 1: Which pandas function is used in `main.py` to ingest the dataset from disk?

- **Question ID:** `q2-01`
- **Difficulty:** Basic
- **Target Lesson:** `lesson-01`
- **Learning Objective:** Load and inspect iris.csv using pandas methods
- **Core Concept:** Pandas CSV ingestion syntax
- **Reference:** main.py line 30: df = pd.read_csv(DATA / 'iris.csv')

**Options:**
- `A)` pd.read_excel()
- `B)` pd.read_csv()
- `C)` pd.read_sql()
- `D)` pd.read_json()

**Correct Answer:** `B` — pd.read_csv()

**Explanation:** In main.py line 30, pd.read_csv(DATA / 'iris.csv') loads the comma-separated data into a pandas DataFrame.

**Distractor Analysis:**
- `A` (pd.read_excel()): pd.read_excel() is for Microsoft Excel .xlsx spreadsheets, not CSV files.
- `C` (pd.read_sql()): pd.read_sql() queries relational SQL databases.
- `D` (pd.read_json()): pd.read_json() parses JSON strings or files.

---

### Question 2: What are the exact dimensional shapes of feature matrix X and target vector y before splitting?

- **Question ID:** `q2-02`
- **Difficulty:** Basic
- **Target Lesson:** `lesson-02`
- **Learning Objective:** Separate multi-feature inputs (X) from categorical class targets (y)
- **Core Concept:** Feature matrix and target vector shapes
- **Reference:** main.py lines 31-32: X = df[FEATURES], y = df['species']

**Options:**
- `A)` X is (150, 5) and y is (150, 1)
- `B)` X is (150, 4) and y is (150,)
- `C)` X is (112, 4) and y is (38,)
- `D)` X is (4, 150) and y is (1, 150)

**Correct Answer:** `B` — X is (150, 4) and y is (150,)

**Explanation:** X contains the 4 measurement features across all 150 rows, shape (150, 4); y contains the 1D target column across all 150 rows, shape (150,).

**Distractor Analysis:**
- `A` (X is (150, 5) and y is (150, 1)): X cannot have 5 columns because species is excluded; y is a 1D Series of shape (150,), not (150, 1).
- `C` (X is (112, 4) and y is (38,)): (112, 4) and (38,) are the partition shapes after train_test_split, not before.
- `D` (X is (4, 150) and y is (1, 150)): (4, 150) would be transposed row-major format, not standard pandas tabular format.

---

### Question 3: In `train_test_split`, what does `test_size=0.25` specify?

- **Question ID:** `q2-03`
- **Difficulty:** Basic
- **Target Lesson:** `lesson-03`
- **Learning Objective:** Explain why stratified splitting (stratify=y) is essential for balanced multi-class datasets
- **Core Concept:** Interpretation of test_size proportion parameter
- **Reference:** main.py line 35: test_size=0.25

**Options:**
- `A)` 25 rows are reserved for testing
- `B)` 25% of the total dataset (38 samples) is allocated for testing
- `C)` The model will be evaluated with 25% precision
- `D)` The split is repeated 25 times

**Correct Answer:** `B` — 25% of the total dataset (38 samples) is allocated for testing

**Explanation:** test_size=0.25 specifies that 25% of the 150 total records (38 samples) are allocated to the holdout test set.

**Distractor Analysis:**
- `A` (25 rows are reserved for testing): 0.25 is a proportion (fraction of 1.0), not an absolute count of 25 rows.
- `C` (The model will be evaluated with 25% precision): test_size has nothing to do with precision metrics.
- `D` (The split is repeated 25 times): Data splitting is performed once, not repeated 25 times.

---

### Question 4: What happens if you accidentally include `species` inside the `FEATURES` list?

- **Question ID:** `q2-04`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-02`
- **Learning Objective:** Separate multi-feature inputs (X) from categorical class targets (y)
- **Core Concept:** Target leakage and feature list definition
- **Reference:** Lesson 02 Concept Explanation: Target Leakage

**Options:**
- `A)` The code runs normally with no change in accuracy
- `B)` Target leakage occurs: the model trivially uses the target answer to predict itself
- `C)` The CSV file on disk is deleted
- `D)` Matplotlib crashes immediately

**Correct Answer:** `B` — Target leakage occurs: the model trivially uses the target answer to predict itself

**Explanation:** Including the target column inside input features creates target leakage: the model learns to simply read the species column rather than learning patterns from measurements.

**Distractor Analysis:**
- `A` (The code runs normally with no change in accuracy): Accuracy would trivially jump to 100% during training, but the model would be completely useless on real unseen flowers.
- `C` (The CSV file on disk is deleted): Target leakage does not modify or delete files on disk.
- `D` (Matplotlib crashes immediately): Matplotlib is used for plotting; it is not triggered by feature definitions.

---

### Question 5: Why is `stratify=y` passed into `train_test_split`?

- **Question ID:** `q2-05`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-03`
- **Learning Objective:** Explain why stratified splitting (stratify=y) is essential for balanced multi-class datasets
- **Core Concept:** Purpose of stratified splitting in classification
- **Reference:** main.py line 35: stratify=y

**Options:**
- `A)` To sort the DataFrame alphabetically by species name
- `B)` To ensure both training and testing sets maintain the same species proportions as the original data
- `C)` To remove duplicate flower records from memory
- `D)` To convert string class labels into floating point numbers

**Correct Answer:** `B` — To ensure both training and testing sets maintain the same species proportions as the original data

**Explanation:** Passing stratify=y forces train_test_split to mirror the exact class ratio of y across both the training set and testing set.

**Distractor Analysis:**
- `A` (To sort the DataFrame alphabetically by species name): Stratification preserves statistical proportions; it does not sort the DataFrame rows alphabetically.
- `C` (To remove duplicate flower records from memory): Stratification does not deduplicate data.
- `D` (To convert string class labels into floating point numbers): Stratification does not encode string labels into floats.

---

### Question 6: What is the primary role of `random_state=42` in data splitting?

- **Question ID:** `q2-06`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-03`
- **Learning Objective:** Explain why stratified splitting (stratify=y) is essential for balanced multi-class datasets
- **Core Concept:** Reproducibility and random seeding in scikit-learn
- **Reference:** main.py line 35: random_state=42

**Options:**
- `A)` It sets the accuracy of the model to 42%
- `B)` It seeds the pseudorandom generator to guarantee reproducible, deterministic train/test splits
- `C)` It limits the maximum tree depth to 42 nodes
- `D)` It specifies that 42 features are used

**Correct Answer:** `B` — It seeds the pseudorandom generator to guarantee reproducible, deterministic train/test splits

**Explanation:** Setting random_state=42 seeds the pseudorandom number generator, ensuring identical train/test splits across runs for scientific reproducibility.

**Distractor Analysis:**
- `A` (It sets the accuracy of the model to 42%): random_state has no bearing on model accuracy; accuracy is determined by the data and model.
- `C` (It limits the maximum tree depth to 42 nodes): Tree depth is controlled by max_depth, not random_state.
- `D` (It specifies that 42 features are used): The number of features is fixed by FEATURES (4 features), not random_state.

---

### Question 7: Why are petal measurements (`petal_length`, `petal_width`) more discriminative than sepal measurements in this dataset?

- **Question ID:** `q2-07`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-04`
- **Learning Objective:** Demonstrate why petal dimensions exhibit higher discriminative power than sepal dimensions
- **Core Concept:** Feature discrimination and variance between sepals and petals
- **Reference:** Lesson 04 Concept Explanation: Comparing Sepals and Petals

**Options:**
- `A)` Petal dimensions were measured with higher optical laser precision
- `B)` Petal dimensions exhibit distinct clustering with large non-overlapping gaps between species
- `C)` Sepal measurements were stored as strings instead of numbers
- `D)` Sepals only exist on setosa flowers

**Correct Answer:** `B` — Petal dimensions exhibit distinct clustering with large non-overlapping gaps between species

**Explanation:** Petal length and petal width cluster tightly within species and exhibit large non-overlapping gaps between species, providing high discriminative power.

**Distractor Analysis:**
- `A` (Petal dimensions were measured with higher optical laser precision): Anderson measured all four traits using manual calipers, not optical lasers.
- `C` (Sepal measurements were stored as strings instead of numbers): All four features in iris.csv are stored as float64 numbers.
- `D` (Sepals only exist on setosa flowers): All angiosperm iris flowers possess both sepals and petals.

---

### Question 8: How many total samples are placed into the training set (`X_train`) and testing set (`X_test`) by `train_test_split`?

- **Question ID:** `q2-08`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-03`
- **Learning Objective:** Explain why stratified splitting (stratify=y) is essential for balanced multi-class datasets
- **Core Concept:** Calculating exact sample counts from test_size
- **Reference:** main.py lines 34-36: train_test_split

**Options:**
- `A)` 75 training samples, 75 testing samples
- `B)` 112 training samples, 38 testing samples
- `C)` 100 training samples, 50 testing samples
- `D)` 120 training samples, 30 testing samples

**Correct Answer:** `B` — 112 training samples, 38 testing samples

**Explanation:** With 150 rows and test_size=0.25, 25% corresponds to 38 samples in X_test and the remaining 75% corresponds to 112 samples in X_train.

**Distractor Analysis:**
- `A` (75 training samples, 75 testing samples): 75/75 would be a 50/50 split (test_size=0.50).
- `C` (100 training samples, 50 testing samples): 100/50 would be a 66.7/33.3 split (test_size=0.333).
- `D` (120 training samples, 30 testing samples): 120/30 would be an 80/20 split (test_size=0.20).

---

### Question 9: What botanical property allows a single threshold (`petal_length <= 2.45`) to achieve 100% accuracy for *Iris setosa*?

- **Question ID:** `q2-09`
- **Difficulty:** Advanced
- **Target Lesson:** `lesson-04`
- **Learning Objective:** Demonstrate why petal dimensions exhibit higher discriminative power than sepal dimensions
- **Core Concept:** Linear separability of Iris setosa
- **Reference:** Lesson 04 Concept Explanation: Linear Separability

**Options:**
- `A)` Iris setosa is linearly separable from the other two species in petal length space
- `B)` Iris setosa flowers have zero petals
- `C)` Iris setosa petals change color in sunlight
- `D)` Iris setosa has identical measurements to versicolor

**Correct Answer:** `A` — Iris setosa is linearly separable from the other two species in petal length space

**Explanation:** Because all setosa petal lengths are <= 1.9 cm and all versicolor/virginica petal lengths are >= 3.0 cm, setosa is linearly separable in 1D space, enabling a perfect split.

**Distractor Analysis:**
- `B` (Iris setosa flowers have zero petals): Iris setosa flowers possess clear, measurable petals averaging 1.46 cm.
- `C` (Iris setosa petals change color in sunlight): Flower color changes in sunlight do not affect physical caliper measurements.
- `D` (Iris setosa has identical measurements to versicolor): Iris setosa measurements are significantly smaller than versicolor, not identical.

---

### Question 10: If `stratify=y` is omitted on a small dataset with rare classes, what is the greatest risk to model evaluation?

- **Question ID:** `q2-10`
- **Difficulty:** Advanced
- **Target Lesson:** `lesson-03`
- **Learning Objective:** Explain why stratified splitting (stratify=y) is essential for balanced multi-class datasets
- **Core Concept:** Risks of unstratified splits on class distributions
- **Reference:** Lesson 03 Concept Explanation: The Power of Stratification

**Options:**
- `A)` The test set might contain zero samples of the rare class, producing unrepresentative and misleading metrics
- `B)` The computer processor will overheat
- `C)` The pandas library will throw a SyntaxError
- `D)` The dataset will automatically duplicate itself

**Correct Answer:** `A` — The test set might contain zero samples of the rare class, producing unrepresentative and misleading metrics

**Explanation:** Without stratification, random partitioning can draw an unrepresentative test split that starves or omits minority classes, distorting evaluation metrics.

**Distractor Analysis:**
- `B` (The computer processor will overheat): Hardware thermal throttling is unrelated to random sampling logic.
- `C` (The pandas library will throw a SyntaxError): Pandas does not raise a SyntaxError when stratification is omitted.
- `D` (The dataset will automatically duplicate itself): Omitting stratification does not duplicate rows in the dataset.

---

<a id="module-03"></a>
## Module 03: Decision Tree Depth Tuning & Hyperparameter Optimization

### Question 1: What does a Gini Impurity of 0.0 in a decision tree node indicate?

- **Question ID:** `q3-01`
- **Difficulty:** Basic
- **Target Lesson:** `lesson-01`
- **Learning Objective:** Understand how decision trees determine split thresholds using impurity criteria (Gini impurity)
- **Core Concept:** Interpretation of Gini impurity = 0.0
- **Reference:** Lesson 01 Concept Explanation: Case 1: A Completely Pure Node

**Options:**
- `A)` The node is empty with zero samples
- `B)` The node is 100% pure; all samples belong to the exact same class
- `C)` The node contains an equal number of all three species
- `D)` The computer ran out of memory

**Correct Answer:** `B` — The node is 100% pure; all samples belong to the exact same class

**Explanation:** A Gini impurity of 0.0 indicates a perfectly pure node where 100% of the observations belong to a single class.

**Distractor Analysis:**
- `A` (The node is empty with zero samples): An empty node would not be formed by standard decision tree split logic.
- `C` (The node contains an equal number of all three species): An equal mix of three classes has a Gini impurity of 0.667, not 0.0.
- `D` (The computer ran out of memory): Gini impurity is a mathematical purity metric, not an operating system memory error.

---

### Question 2: What does the `max_depth` hyperparameter in `DecisionTreeClassifier` control?

- **Question ID:** `q3-02`
- **Difficulty:** Basic
- **Target Lesson:** `lesson-02`
- **Learning Objective:** Configure and constrain tree growth using the max_depth hyperparameter
- **Core Concept:** Definition of max_depth hyperparameter
- **Reference:** Lesson 02 Concept Explanation: What is Tree Depth?

**Options:**
- `A)` The maximum number of rows in the CSV file
- `B)` The maximum length of the path from the root node to any leaf node
- `C)` The color brightness of the tree plot
- `D)` The random seed used for data splitting

**Correct Answer:** `B` — The maximum length of the path from the root node to any leaf node

**Explanation:** max_depth controls tree height: the maximum number of decision steps along any branch from the root to a leaf node.

**Distractor Analysis:**
- `A` (The maximum number of rows in the CSV file): Dataset row count is fixed by the CSV file, not max_depth.
- `C` (The color brightness of the tree plot): Tree plot colors are controlled by plot_tree arguments (e.g. filled=True), not max_depth.
- `D` (The random seed used for data splitting): Random seed is set by random_state, not max_depth.

---

### Question 3: In `main.py`, which depth achieved the highest accuracy on the test set?

- **Question ID:** `q3-03`
- **Difficulty:** Basic
- **Target Lesson:** `lesson-04`
- **Learning Objective:** Analyze the overfitting trap: explain why max_depth=2 achieves 92.1% test accuracy while deeper trees drop to 89.5%
- **Core Concept:** Optimal depth selection in main.py
- **Reference:** main.py lines 50-54 console output

**Options:**
- `A)` max_depth=None (unlimited)
- `B)` max_depth=3
- `C)` max_depth=2
- `D)` All depths achieved identical 100% accuracy

**Correct Answer:** `C` — max_depth=2

**Explanation:** max_depth=2 achieved 92.1% accuracy on the test set, outperforming max_depth=3 (89.5%) and max_depth=unlimited (89.5%).

**Distractor Analysis:**
- `A` (max_depth=None (unlimited)): max_depth=None achieved 89.5%, which is lower than max_depth=2.
- `B` (max_depth=3): max_depth=3 achieved 89.5%, which is lower than max_depth=2.
- `D` (All depths achieved identical 100% accuracy): Accuracies differed across depths; they were not all 100%.

---

### Question 4: Why do Decision Trees not require feature scaling like `StandardScaler`?

- **Question ID:** `q3-04`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-01`
- **Learning Objective:** Understand how decision trees determine split thresholds using impurity criteria (Gini impurity)
- **Core Concept:** Invariance of decision trees to feature scaling
- **Reference:** Lesson 01 Concept Explanation: Why Decision Trees Require No Feature Scaling

**Options:**
- `A)` Because they only evaluate one feature at a time along individual axes, making splits invariant to monotonic scaling
- `B)` Because Python automatically scales all variables to 0 and 1 behind the scenes
- `C)` Because decision trees cannot process numbers greater than 10
- `D)` Because feature scaling is illegal in scikit-learn

**Correct Answer:** `A` — Because they only evaluate one feature at a time along individual axes, making splits invariant to monotonic scaling

**Explanation:** Decision trees evaluate one feature at a time using orthogonal cuts (e.g., petal_length <= 2.45), meaning feature scale has zero impact on split decisions.

**Distractor Analysis:**
- `B` (Because Python automatically scales all variables to 0 and 1 behind the scenes): Python does not scale variables automatically; algorithms requiring scaling must use tools like StandardScaler.
- `C` (Because decision trees cannot process numbers greater than 10): Decision trees can process arbitrary numbers from negative infinity to positive infinity.
- `D` (Because feature scaling is illegal in scikit-learn): Feature scaling is supported in scikit-learn, but unnecessary for trees.

---

### Question 5: What does passing `max_depth=None` instruct scikit-learn to do?

- **Question ID:** `q3-05`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-02`
- **Learning Objective:** Configure and constrain tree growth using the max_depth hyperparameter
- **Core Concept:** Behavior of max_depth=None in scikit-learn
- **Reference:** scikit-learn DecisionTreeClassifier documentation: max_depth=None

**Options:**
- `A)` Delete the tree model immediately
- `B)` Grow nodes until all leaves are 100% pure or contain fewer than min_samples_split samples
- `C)` Restrict the tree to a single root split
- `D)` Randomly choose a depth between 1 and 100

**Correct Answer:** `B` — Grow nodes until all leaves are 100% pure or contain fewer than min_samples_split samples

**Explanation:** In scikit-learn, max_depth=None allows trees to expand unconstrained until all leaves are pure or contain fewer than min_samples_split.

**Distractor Analysis:**
- `A` (Delete the tree model immediately): max_depth=None does not delete models.
- `C` (Restrict the tree to a single root split): Restricting to a single split is max_depth=1 (decision stump).
- `D` (Randomly choose a depth between 1 and 100): scikit-learn does not pick a random depth.

---

### Question 6: In the line `best_depth = max(models, key=lambda depth: models[depth][2])`, what does `models[depth][2]` access?

- **Question ID:** `q3-06`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-03`
- **Learning Objective:** Implement programmatic hyperparameter evaluation loops storing models and metrics in dictionaries
- **Core Concept:** Tuple indexing inside programmatic comparison dictionaries
- **Reference:** main.py line 48: models[depth] = (model, predictions, accuracy)

**Options:**
- `A)` The tree model instance
- `B)` The array of predicted test labels
- `C)` The test accuracy score float
- `D)` The number of flower samples

**Correct Answer:** `C` — The test accuracy score float

**Explanation:** In main.py line 48, models[depth] stores (model, predictions, accuracy). Index 2 accesses the accuracy float used by max() to find the best model.

**Distractor Analysis:**
- `A` (The tree model instance): The model instance is at index 0: models[depth][0].
- `B` (The array of predicted test labels): The predictions array is at index 1: models[depth][1].
- `D` (The number of flower samples): Sample count is not stored in the tuple.

---

### Question 7: What is the phenomenon where a model scores 100% on training data but performs worse on unseen test data?

- **Question ID:** `q3-07`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-04`
- **Learning Objective:** Analyze the overfitting trap: explain why max_depth=2 achieves 92.1% test accuracy while deeper trees drop to 89.5%
- **Core Concept:** Overfitting definition and characteristics
- **Reference:** Lesson 04 Concept Explanation: Memorization vs Generalization

**Options:**
- `A)` Underfitting
- `B)` Overfitting
- `C)` Data imputation
- `D)` Hyperparameter collapse

**Correct Answer:** `B` — Overfitting

**Explanation:** Overfitting occurs when a model learns the training data too closely (memorizing noise), resulting in high training score but degraded test generalization.

**Distractor Analysis:**
- `A` (Underfitting): Underfitting occurs when a model is too simple to capture even the training patterns.
- `C` (Data imputation): Data imputation is replacing missing values with estimates.
- `D` (Hyperparameter collapse): Hyperparameter collapse is not an established machine learning term.

---

### Question 8: How many total test samples did the winning model (`max_depth=2`) classify correctly out of 38?

- **Question ID:** `q3-08`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-03`
- **Learning Objective:** Implement programmatic hyperparameter evaluation loops storing models and metrics in dictionaries
- **Core Concept:** Exact test count calculation from accuracy percentage
- **Reference:** main.py lines 50-51 accuracy calculations

**Options:**
- `A)` 30 correct
- `B)` 34 correct
- `C)` 35 correct
- `D)` 38 correct

**Correct Answer:** `C` — 35 correct

**Explanation:** With 38 test samples, 92.1% accuracy corresponds to 35 correct predictions (35 / 38 = 0.92105). Depths 3 and None got 34 correct (34 / 38 = 0.8947).

**Distractor Analysis:**
- `A` (30 correct): 30 correct would be 30/38 = 78.9% accuracy.
- `B` (34 correct): 34 correct is 89.5% accuracy, which was achieved by max_depth=3 and max_depth=None.
- `D` (38 correct): 38 correct would be 100% accuracy.

---

### Question 9: Why did `max_depth=None` achieve lower test accuracy (89.5%) than `max_depth=2` (92.1%)?

- **Question ID:** `q3-09`
- **Difficulty:** Advanced
- **Target Lesson:** `lesson-04`
- **Learning Objective:** Analyze the overfitting trap: explain why max_depth=2 achieves 92.1% test accuracy while deeper trees drop to 89.5%
- **Core Concept:** Mechanism of overfitting in unconstrained decision trees
- **Reference:** Lesson 04 Concept Explanation: Deconstructing the Iris Depth Results

**Options:**
- `A)` The deeper tree ran out of CPU cycles during testing
- `B)` The deeper tree created hyper-specific rules memorizing training set outliers that misclassified normal test flowers
- `C)` Scikit-learn applies an automatic penalty to trees with None depth
- `D)` The test set labels were shuffled accidentally

**Correct Answer:** `B` — The deeper tree created hyper-specific rules memorizing training set outliers that misclassified normal test flowers

**Explanation:** max_depth=None memorized noise and outliers in the training set by creating extra fragile decision splits, leading to misclassifications on normal test flowers.

**Distractor Analysis:**
- `A` (The deeper tree ran out of CPU cycles during testing): Decision tree inference takes microseconds; CPU cycles are not exhausted.
- `C` (Scikit-learn applies an automatic penalty to trees with None depth): scikit-learn does not apply artificial score penalties to max_depth=None.
- `D` (The test set labels were shuffled accidentally): Test labels were preserved deterministically via random_state=42.

---

### Question 10: A node has 20 samples: 10 *versicolor* and 10 *virginica*. What is its Gini impurity?

- **Question ID:** `q3-10`
- **Difficulty:** Advanced
- **Target Lesson:** `lesson-01`
- **Learning Objective:** Understand how decision trees determine split thresholds using impurity criteria (Gini impurity)
- **Core Concept:** Mathematical calculation of binary Gini impurity
- **Reference:** Lesson 01 Concept Explanation: Gini Impurity formula

**Options:**
- `A)` 0.0
- `B)` 0.25
- `C)` 0.50
- `D)` 1.0

**Correct Answer:** `C` — 0.50

**Explanation:** For an equal 50/50 split across 2 classes, Gini = 1 - (0.5^2 + 0.5^2) = 1 - (0.25 + 0.25) = 1 - 0.50 = 0.50.

**Distractor Analysis:**
- `A` (0.0): 0.0 is the Gini impurity of a pure node.
- `B` (0.25): 0.25 would correspond to a much more unequal class distribution (e.g. ~85/15).
- `D` (1.0): Gini impurity for binary classes can never exceed 0.50.

---

<a id="module-04"></a>
## Module 04: Visualizing Trees & Reading Decision Rules

### Question 1: Which scikit-learn function prints an ASCII text hierarchy of a decision tree's rules?

- **Question ID:** `q4-01`
- **Difficulty:** Basic
- **Target Lesson:** `lesson-01`
- **Learning Objective:** Extract human-readable ASCII decision rules using scikit-learn's export_text()
- **Core Concept:** Utility function for extracting text decision rules
- **Reference:** main.py line 56: export_text(model, feature_names=FEATURES)

**Options:**
- `A)` export_graphviz
- `B)` export_text
- `C)` tree_to_code
- `D)` print_rules

**Correct Answer:** `B` — export_text

**Explanation:** In scikit-learn, export_text() extracts a tree's decision rules into formatted plain ASCII text.

**Distractor Analysis:**
- `A` (export_graphviz): export_graphviz() exports trees to Graphviz DOT format, not plain ASCII text.
- `C` (tree_to_code): tree_to_code is not a standard built-in scikit-learn function.
- `D` (print_rules): print_rules is not a scikit-learn function.

---

### Question 2: What does the `filled=True` parameter in `plot_tree()` do?

- **Question ID:** `q4-02`
- **Difficulty:** Basic
- **Target Lesson:** `lesson-02`
- **Learning Objective:** Render high-resolution graphical tree diagrams using plot_tree() and Matplotlib
- **Core Concept:** Styling arguments in plot_tree
- **Reference:** main.py line 71: filled=True

**Options:**
- `A)` Fills missing values in the dataset automatically
- `B)` Colors each node box according to its majority class, with saturation reflecting purity
- `C)` Fills the entire screen with terminal text
- `D)` Fills all leaf nodes with random numbers

**Correct Answer:** `B` — Colors each node box according to its majority class, with saturation reflecting purity

**Explanation:** filled=True colors node boxes based on their dominant class, using color saturation to indicate purity.

**Distractor Analysis:**
- `A` (Fills missing values in the dataset automatically): Missing values must be handled prior to fitting; plot_tree does not impute data.
- `C` (Fills the entire screen with terminal text): plot_tree generates a Matplotlib graphical axes object, not terminal text.
- `D` (Fills all leaf nodes with random numbers): plot_tree visualizes actual fitted node statistics, not random numbers.

---

### Question 3: What species was predicted for `new_flower` (`[5.8, 2.7, 4.1, 1.0]`) in `main.py`?

- **Question ID:** `q4-03`
- **Difficulty:** Basic
- **Target Lesson:** `lesson-03`
- **Learning Objective:** Trace unseen flower observations step-by-step through decision nodes to terminal leaves
- **Core Concept:** Prediction inference for the new_flower sample
- **Reference:** main.py line 63: New flower -> versicolor

**Options:**
- `A)` setosa
- `B)` versicolor
- `C)` virginica
- `D)` Unknown species

**Correct Answer:** `B` — versicolor

**Explanation:** With petal_length=4.1, new_flower satisfies petal_length > 2.45 and petal_length <= 4.85, classifying it as versicolor.

**Distractor Analysis:**
- `A` (setosa): Setosa requires petal_length <= 2.45; 4.1 is much larger.
- `C` (virginica): Virginica requires petal_length > 4.85; 4.1 is smaller than 4.85.
- `D` (Unknown species): The model has 3 known target classes and assigned it to versicolor.

---

### Question 4: What does passing `feature_names=FEATURES` into `export_text()` accomplish?

- **Question ID:** `q4-04`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-01`
- **Learning Objective:** Extract human-readable ASCII decision rules using scikit-learn's export_text()
- **Core Concept:** Purpose of feature_names parameter in export_text
- **Reference:** Lesson 01 Concept Explanation: Passing feature_names=FEATURES

**Options:**
- `A)` It renames the columns inside the CSV file on disk
- `B)` It replaces generic labels like 'feature_0' with descriptive column names like 'petal_length'
- `C)` It limits the tree to only 4 leaf nodes
- `D)` It converts all features to uppercase strings

**Correct Answer:** `B` — It replaces generic labels like 'feature_0' with descriptive column names like 'petal_length'

**Explanation:** feature_names=FEATURES replaces default generic labels (feature_0, feature_2) with column strings (sepal_length, petal_length).

**Distractor Analysis:**
- `A` (It renames the columns inside the CSV file on disk): export_text does not modify files on disk.
- `C` (It limits the tree to only 4 leaf nodes): Leaf count is controlled by max_depth and data splits, not feature_names.
- `D` (It converts all features to uppercase strings): Feature names are displayed in their original casing.

---

### Question 5: In `outputs/iris_tree.png`, what does the line `value = [0, 35, 1]` inside a node indicate?

- **Question ID:** `q4-05`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-04`
- **Learning Objective:** Interpret node attributes: Gini impurity, sample counts, class distributions, and dominant classes
- **Core Concept:** Interpreting class distribution array in decision nodes
- **Reference:** Lesson 04 Concept Explanation: Reading Inside the Box

**Options:**
- `A)` The coordinates (x=0, y=35, z=1) on the plot
- `B)` The node contains 0 setosa, 35 versicolor, and 1 virginica training samples
- `C)` The model made 35 prediction errors
- `D)` The tree depth is 35

**Correct Answer:** `B` — The node contains 0 setosa, 35 versicolor, and 1 virginica training samples

**Explanation:** In scikit-learn, value displays class counts in alphabetical order: [setosa, versicolor, virginica]. [0, 35, 1] means 0 setosa, 35 versicolor, and 1 virginica.

**Distractor Analysis:**
- `A` (The coordinates (x=0, y=35, z=1) on the plot): value has nothing to do with Cartesian spatial coordinates.
- `C` (The model made 35 prediction errors): It indicates training sample distribution, not test errors.
- `D` (The tree depth is 35): Tree depth is 2, not 35.

---

### Question 6: Why must `plt.close(fig)` be called after saving the tree diagram with `fig.savefig()`?

- **Question ID:** `q4-06`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-02`
- **Learning Objective:** Render high-resolution graphical tree diagrams using plot_tree() and Matplotlib
- **Core Concept:** Resource management and figure cleanup in Matplotlib
- **Reference:** main.py line 79: plt.close(fig)

**Options:**
- `A)` To close the operating system terminal window
- `B)` To free memory resources allocated by Matplotlib and prevent figure accumulation leaks
- `C)` To encrypt the image file on disk
- `D)` To restart the Python interpreter

**Correct Answer:** `B` — To free memory resources allocated by Matplotlib and prevent figure accumulation leaks

**Explanation:** plt.close(fig) deallocates memory occupied by the Matplotlib figure canvas, preventing memory leaks in iterative scripts.

**Distractor Analysis:**
- `A` (To close the operating system terminal window): plt.close(fig) closes the figure object in memory; it does not shut down the terminal.
- `C` (To encrypt the image file on disk): It does not apply disk encryption.
- `D` (To restart the Python interpreter): It does not reboot or restart Python.

---

### Question 7: What is the Big-O time complexity of classifying a single sample using a decision tree with depth $d$?

- **Question ID:** `q4-07`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-03`
- **Learning Objective:** Trace unseen flower observations step-by-step through decision nodes to terminal leaves
- **Core Concept:** Big-O inference time complexity of decision trees
- **Reference:** Lesson 03 Concept Explanation: Computational Efficiency

**Options:**
- `A)` O(N^2) where N is dataset size
- `B)` O(d) where d is tree depth
- `C)` O(2^d) exponential time
- `D)` O(N * log N)

**Correct Answer:** `B` — O(d) where d is tree depth

**Explanation:** Classifying a sample in a binary tree traverses at most d decision nodes from root to leaf, requiring O(d) numerical comparisons.

**Distractor Analysis:**
- `A` (O(N^2) where N is dataset size): O(N^2) would be quadratic, far slower than tree traversal.
- `C` (O(2^d) exponential time): O(2^d) is the maximum number of leaves, not the traversal path length.
- `D` (O(N * log N)): O(N log N) is typical of sorting algorithms or tree building, not single-sample inference.

---

### Question 8: How does a non-pure leaf node determine which class label to predict for incoming samples?

- **Question ID:** `q4-08`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-04`
- **Learning Objective:** Interpret node attributes: Gini impurity, sample counts, class distributions, and dominant classes
- **Core Concept:** Majority voting mechanism in impure leaf nodes
- **Reference:** Lesson 04 Concept Explanation: Majority Voting and Leaf Purity

**Options:**
- `A)` It generates a random guess
- `B)` It uses majority voting: predicting the class with the highest sample count in that leaf
- `C)` It always predicts the first class alphabetically
- `D)` It refuses to issue a prediction and raises an error

**Correct Answer:** `B` — It uses majority voting: predicting the class with the highest sample count in that leaf

**Explanation:** Decision trees use majority voting: a terminal leaf predicts the class that had the highest number of training samples inside that leaf.

**Distractor Analysis:**
- `A` (It generates a random guess): Decision tree predictions are deterministic, not random.
- `C` (It always predicts the first class alphabetically): Predictions depend on empirical majority counts, not alphabetical rank.
- `D` (It refuses to issue a prediction and raises an error): Scikit-learn classifies samples in impure leaves without raising errors.

---

### Question 9: A flower has `petal_length = 4.85 cm`. According to the rule `petal_length <= 4.85`, which branch does it follow?

- **Question ID:** `q4-09`
- **Difficulty:** Advanced
- **Target Lesson:** `lesson-03`
- **Learning Objective:** Trace unseen flower observations step-by-step through decision nodes to terminal leaves
- **Core Concept:** Boundary equality operator behavior in decision tree splits
- **Reference:** main.py lines 56 and export_text output

**Options:**
- `A)` The True branch (evaluating to True because 4.85 is less than or equal to 4.85)
- `B)` The False branch (evaluating to False because it is not strictly less)
- `C)` It splits into both branches simultaneously
- `D)` The program crashes on exact equality

**Correct Answer:** `A` — The True branch (evaluating to True because 4.85 is less than or equal to 4.85)

**Explanation:** Decision tree inequalities use <= (less than or equal to). Since 4.85 <= 4.85 is True, the sample follows the True branch.

**Distractor Analysis:**
- `B` (The False branch (evaluating to False because it is not strictly less)): The condition tests <=, not strict <, so equality evaluates to True.
- `C` (It splits into both branches simultaneously): Inference in decision trees is strictly binary; samples follow exactly one branch.
- `D` (The program crashes on exact equality): Equality comparisons on floats execute cleanly without program crashes.

---

### Question 10: If a leaf node has `value = [0, 35, 1]`, what probability does `model.predict_proba()` assign to *versicolor*?

- **Question ID:** `q4-10`
- **Difficulty:** Advanced
- **Target Lesson:** `lesson-04`
- **Learning Objective:** Interpret node attributes: Gini impurity, sample counts, class distributions, and dominant classes
- **Core Concept:** Calculating predict_proba from node class counts
- **Reference:** Lesson 04 Concept Explanation: Predicting Class Probabilities

**Options:**
- `A)` 50.0%
- `B)` 97.2% (35 / 36)
- `C)` 100.0%
- `D)` 35.0%

**Correct Answer:** `B` — 97.2% (35 / 36)

**Explanation:** Total samples in leaf = 0 + 35 + 1 = 36. Probability of versicolor = 35 / 36 = 0.9722 (97.2%).

**Distractor Analysis:**
- `A` (50.0%): 50% would indicate equal counts between classes.
- `C` (100.0%): 100% would require 0 virginica samples (a completely pure leaf).
- `D` (35.0%): 35 is the absolute sample count, not the percentage (35 / 36).

---

<a id="module-05"></a>
## Module 05: Comprehensive Evaluation: Metrics, Classification Report & Confusion Matrix

### Question 1: What test accuracy did the winning tree (`max_depth=2`) achieve in `main.py`?

- **Question ID:** `q5-01`
- **Difficulty:** Basic
- **Target Lesson:** `lesson-01`
- **Learning Objective:** Evaluate classification performance across multiple tree depths using accuracy_score
- **Core Concept:** Optimal depth test accuracy
- **Reference:** main.py lines 50-54: max_depth=2 accuracy=92.1%

**Options:**
- `A)` 85.0%
- `B)` 89.5%
- `C)` 92.1%
- `D)` 100.0%

**Correct Answer:** `C` — 92.1%

**Explanation:** In main.py lines 50-54, max_depth=2 achieved an accuracy of 92.1% on the 38 test flowers (35 of 38 correct).

**Distractor Analysis:**
- `A` (85.0%): 85.0% is lower than any depth tested.
- `B` (89.5%): 89.5% was achieved by max_depth=3 and max_depth=None.
- `D` (100.0%): 100.0% was achieved on the training set by unlimited depth, but not on the test set.

---

### Question 2: What do the numbers along the main diagonal of a confusion matrix represent?

- **Question ID:** `q5-02`
- **Difficulty:** Basic
- **Target Lesson:** `lesson-03`
- **Learning Objective:** Analyze confusion matrices to identify exact cross-species misclassifications using ConfusionMatrixDisplay
- **Core Concept:** Interpretation of confusion matrix main diagonal
- **Reference:** Lesson 03 Concept Explanation: Diagnostic Tool: The Confusion Matrix

**Options:**
- `A)` The number of correct classifications where actual class equals predicted class
- `B)` The number of classification errors
- `C)` The memory size of the tree nodes in bytes
- `D)` The random seeds used during training

**Correct Answer:** `A` — The number of correct classifications where actual class equals predicted class

**Explanation:** The main diagonal represents true positive hits for each class where the true actual label equals the model's predicted label.

**Distractor Analysis:**
- `B` (The number of classification errors): Errors and misclassifications appear in the off-diagonal cells.
- `C` (The memory size of the tree nodes in bytes): Memory sizes are not represented in confusion matrices.
- `D` (The random seeds used during training): Random seeds are hyperparameters set during initialization, not matrix cells.

---

### Question 3: Which output file stores the depth comparison, best depth, decision rules, and classification report in plain text?

- **Question ID:** `q5-03`
- **Difficulty:** Basic
- **Target Lesson:** `lesson-04`
- **Learning Objective:** Persist comprehensive model evaluations and decision rules to disk in outputs/rules.txt
- **Core Concept:** Identification of plain-text evaluation artifact file
- **Reference:** main.py lines 91-98: open(OUT / 'rules.txt', 'w')

**Options:**
- `A)` outputs/iris_tree.png
- `B)` outputs/rules.txt
- `C)` outputs/confusion_matrix.png
- `D)` data/iris.csv

**Correct Answer:** `B` — outputs/rules.txt

**Explanation:** main.py lines 91-98 write all text evaluation summaries, depth accuracies, and learned rules to outputs/rules.txt.

**Distractor Analysis:**
- `A` (outputs/iris_tree.png): iris_tree.png is a PNG graphical flowchart of the decision tree.
- `C` (outputs/confusion_matrix.png): confusion_matrix.png is a PNG image of the confusion matrix heatmap.
- `D` (data/iris.csv): data/iris.csv is the raw input dataset.

---

### Question 4: What is the mathematical definition of Precision for a class in a classification report?

- **Question ID:** `q5-04`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-02`
- **Learning Objective:** Interpret multi-class precision, recall, and F1-score from scikit-learn's classification_report
- **Core Concept:** Mathematical definition of precision
- **Reference:** Lesson 02 Concept Explanation: Mathematical Definitions

**Options:**
- `A)` True Positives / (True Positives + False Positives)
- `B)` True Positives / (True Positives + False Negatives)
- `C)` Total Predictions / Total Samples
- `D)` (Precision + Recall) / 2

**Correct Answer:** `A` — True Positives / (True Positives + False Positives)

**Explanation:** Precision is defined as True Positives divided by total positive predictions (TP + FP).

**Distractor Analysis:**
- `B` (True Positives / (True Positives + False Negatives)): TP / (TP + FN) is the definition of Recall (Sensitivity).
- `C` (Total Predictions / Total Samples): Total Predictions / Total Samples is not a standard ML metric.
- `D` ((Precision + Recall) / 2): (P + R) / 2 is the simple arithmetic mean, not Precision.

---

### Question 5: How many total misclassifications were made by the optimal model on the 38-sample test set?

- **Question ID:** `q5-05`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-03`
- **Learning Objective:** Analyze confusion matrices to identify exact cross-species misclassifications using ConfusionMatrixDisplay
- **Core Concept:** Total count of test set misclassifications
- **Reference:** main.py lines 82-89 confusion matrix counts

**Options:**
- `A)` 0 misclassifications
- `B)` 3 misclassifications (1 versicolor and 2 virginica)
- `C)` 8 misclassifications
- `D)` 12 misclassifications

**Correct Answer:** `B` — 3 misclassifications (1 versicolor and 2 virginica)

**Explanation:** Out of 38 test flowers, 35 were correct and exactly 3 were misclassified (1 versicolor mistaken for virginica, and 2 virginica mistaken for versicolor).

**Distractor Analysis:**
- `A` (0 misclassifications): 0 misclassifications would mean 100% accuracy, which was not achieved.
- `C` (8 misclassifications): 8 misclassifications would correspond to ~79% accuracy.
- `D` (12 misclassifications): 12 misclassifications would be over 30% error rate.

---

### Question 6: Why did *Iris setosa* achieve a perfect 1.00 score across Precision, Recall, and F1-score?

- **Question ID:** `q5-06`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-02`
- **Learning Objective:** Interpret multi-class precision, recall, and F1-score from scikit-learn's classification_report
- **Core Concept:** Linear separability explaining perfect setosa classification
- **Reference:** Lesson 02 Concept Explanation: Reading the Actual Project Classification Report

**Options:**
- `A)` Because setosa flowers were excluded from the test set
- `B)` Because setosa is linearly separable in petal length space, resulting in zero false positives and zero false negatives
- `C)` Because the model was hardcoded to only predict setosa
- `D)` Because setosa had 100 times more data than the other species

**Correct Answer:** `B` — Because setosa is linearly separable in petal length space, resulting in zero false positives and zero false negatives

**Explanation:** Iris setosa is cleanly linearly separable in petal length (all <= 1.9 cm), resulting in 12/12 correct predictions and 0 false alarms, yielding perfect 1.00 scores.

**Distractor Analysis:**
- `A` (Because setosa flowers were excluded from the test set): Setosa was included in the test set (12 samples in support).
- `C` (Because the model was hardcoded to only predict setosa): The model was trained dynamically using DecisionTreeClassifier, not hardcoded.
- `D` (Because setosa had 100 times more data than the other species): The dataset was perfectly balanced with 50 samples per class.

---

### Question 7: What does passing `zero_division=0` to `classification_report()` do?

- **Question ID:** `q5-07`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-02`
- **Learning Objective:** Interpret multi-class precision, recall, and F1-score from scikit-learn's classification_report
- **Core Concept:** Role of zero_division parameter in classification_report
- **Reference:** main.py line 57: zero_division=0

**Options:**
- `A)` Prevents runtime division-by-zero warnings if a class receives zero predictions, returning 0.0 instead
- `B)` Removes all zeros from the confusion matrix
- `C)` Divides all accuracy scores by zero
- `D)` Forces the computer to round all scores to zero

**Correct Answer:** `A` — Prevents runtime division-by-zero warnings if a class receives zero predictions, returning 0.0 instead

**Explanation:** zero_division=0 instructs scikit-learn to return 0.0 for precision or recall if a class has zero positive predictions, suppressing runtime warnings.

**Distractor Analysis:**
- `B` (Removes all zeros from the confusion matrix): zero_division does not edit or remove matrix cells.
- `C` (Divides all accuracy scores by zero): Dividing by zero is mathematically undefined; scikit-learn suppresses the error.
- `D` (Forces the computer to round all scores to zero): It only applies to cases with zero positive predictions, not all scores.

---

### Question 8: In `outputs/confusion_matrix.png`, between which two species did all misclassifications occur?

- **Question ID:** `q5-08`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-03`
- **Learning Objective:** Analyze confusion matrices to identify exact cross-species misclassifications using ConfusionMatrixDisplay
- **Core Concept:** Diagnosing cross-species confusion pairs
- **Reference:** Lesson 03 Concept Explanation: Biological Takeaway

**Options:**
- `A)` Between setosa and versicolor
- `B)` Between setosa and virginica
- `C)` Between versicolor and virginica
- `D)` Between weeds and irises

**Correct Answer:** `C` — Between versicolor and virginica

**Explanation:** All 3 misclassifications occurred strictly between versicolor and virginica due to subtle biological feature overlap along their decision boundary.

**Distractor Analysis:**
- `A` (Between setosa and versicolor): Setosa had 0 errors and was never confused with versicolor.
- `B` (Between setosa and virginica): Setosa had 0 errors and was never confused with virginica.
- `D` (Between weeds and irises): The dataset contains only three iris species; weeds were not present.

---

### Question 9: If a model predicts 14 flowers are *versicolor*, and 12 are truly *versicolor* while 2 are *virginica*, what is the Precision for *versicolor*?

- **Question ID:** `q5-09`
- **Difficulty:** Advanced
- **Target Lesson:** `lesson-02`
- **Learning Objective:** Interpret multi-class precision, recall, and F1-score from scikit-learn's classification_report
- **Core Concept:** Mathematical calculation of precision from TP and FP
- **Reference:** Lesson 02 Worked Example: Versicolor Precision calculation

**Options:**
- `A)` 12 / 14 = 0.857 (~86%)
- `B)` 12 / 13 = 0.923 (~92%)
- `C)` 2 / 14 = 0.143 (~14%)
- `D)` 14 / 12 = 1.167

**Correct Answer:** `A` — 12 / 14 = 0.857 (~86%)

**Explanation:** Precision = TP / (TP + FP) = 12 / (12 + 2) = 12 / 14 = 0.857, which rounds to 0.86 in the report.

**Distractor Analysis:**
- `B` (12 / 13 = 0.923 (~92%)): 12 / 13 = 0.923 is the Recall for versicolor (TP / (TP + FN)).
- `C` (2 / 14 = 0.143 (~14%)): 2 / 14 is the false discovery rate, not precision.
- `D` (14 / 12 = 1.167): Precision cannot exceed 1.0 (100%).

---

### Question 10: Why is the F1-score computed as the harmonic mean rather than the simple arithmetic mean of precision and recall?

- **Question ID:** `q5-10`
- **Difficulty:** Advanced
- **Target Lesson:** `lesson-02`
- **Learning Objective:** Interpret multi-class precision, recall, and F1-score from scikit-learn's classification_report
- **Core Concept:** Purpose of harmonic mean in F1-score
- **Reference:** Lesson 02 Concept Explanation: F1-Score formula

**Options:**
- `A)` Because the arithmetic mean cannot be calculated on decimal numbers
- `B)` Because the harmonic mean severely penalizes extreme imbalances where one metric is high and the other is near zero
- `C)` Because harmonic means always produce scores greater than 1.0
- `D)` Because scikit-learn does not support arithmetic addition

**Correct Answer:** `B` — Because the harmonic mean severely penalizes extreme imbalances where one metric is high and the other is near zero

**Explanation:** The harmonic mean approaches zero if either precision or recall approaches zero, heavily penalizing models with severe metric trade-offs.

**Distractor Analysis:**
- `A` (Because the arithmetic mean cannot be calculated on decimal numbers): Arithmetic means can be calculated on any floating point numbers.
- `C` (Because harmonic means always produce scores greater than 1.0): Harmonic means of numbers in [0, 1] are strictly bounded within [0, 1].
- `D` (Because scikit-learn does not support arithmetic addition): Scikit-learn utilizes standard Python arithmetic throughout.

---

<a id="module-06"></a>
## Module 06: Pipeline Execution, Flower Prediction & The Overfitting Lesson

### Question 1: What species was predicted for `new_flower` (`[5.8, 2.7, 4.1, 1.0]`) when executing `main.py`?

- **Question ID:** `q6-01`
- **Difficulty:** Basic
- **Target Lesson:** `lesson-02`
- **Learning Objective:** Deploy the fitted model for real-time inference on new flower measurements
- **Core Concept:** Inference output for new_flower sample
- **Reference:** main.py line 63: New flower -> versicolor

**Options:**
- `A)` setosa
- `B)` versicolor
- `C)` virginica
- `D)` cactus

**Correct Answer:** `B` — versicolor

**Explanation:** In main.py line 63, the fitted model evaluated new_flower ([5.8, 2.7, 4.1, 1.0]) and outputted 'versicolor'.

**Distractor Analysis:**
- `A` (setosa): Setosa requires petal_length <= 2.45; 4.1 cm is too large.
- `C` (virginica): Virginica requires petal_length > 4.85; 4.1 cm is too small.
- `D` (cactus): Cactus is not a class in the Iris dataset.

---

### Question 2: Which backend is configured in `main.py` to allow headless image saving without GUI crashes?

- **Question ID:** `q6-02`
- **Difficulty:** Basic
- **Target Lesson:** `lesson-01`
- **Learning Objective:** Execute the complete Python machine learning script from end to end and verify output artifacts
- **Core Concept:** Headless backend configuration in Matplotlib
- **Reference:** main.py line 14: matplotlib.use('Agg')

**Options:**
- `A)` TkAgg
- `B)` Qt5Agg
- `C)` Agg
- `D)` MacOSX

**Correct Answer:** `C` — Agg

**Explanation:** matplotlib.use('Agg') configures the headless Anti-Grain Geometry raster engine, enabling diagram generation without GUI displays.

**Distractor Analysis:**
- `A` (TkAgg): TkAgg requires a Tkinter GUI display window.
- `B` (Qt5Agg): Qt5Agg requires a PyQt5 graphical windowing environment.
- `D` (MacOSX): MacOSX backend requires native macOS graphical windowing.

---

### Question 3: What is the primary architectural takeaway from comparing tree depths in this project?

- **Question ID:** `q6-03`
- **Difficulty:** Basic
- **Target Lesson:** `lesson-03`
- **Learning Objective:** Synthesize the central machine learning takeaway: model simplicity beats overfitted complexity
- **Core Concept:** Core machine learning takeaway: simplicity vs complexity
- **Reference:** Lesson 03 Concept Explanation: Occam's Razor in Machine Learning

**Options:**
- `A)` Deeper trees are always superior in every machine learning problem
- `B)` Simpler, regularized trees often generalize better to unseen data than unconstrained, overfitted trees
- `C)` Decision trees can only classify binary problems
- `D)` Training accuracy is the only metric that matters

**Correct Answer:** `B` — Simpler, regularized trees often generalize better to unseen data than unconstrained, overfitted trees

**Explanation:** The central ML lesson is that simpler regularized models (depth 2, 92.1%) often generalize better than complex overfitted models (depth None, 89.5%).

**Distractor Analysis:**
- `A` (Deeper trees are always superior in every machine learning problem): Deeper trees overfit to training noise and regularly score lower on test data.
- `C` (Decision trees can only classify binary problems): Decision trees natively handle multi-class problems with 3 or more classes.
- `D` (Training accuracy is the only metric that matters): Training accuracy reflects memorization; test generalization is what matters.

---

### Question 4: Why must single-sample inference inputs (like `new_flower`) be passed as a 2D DataFrame rather than a 1D list?

- **Question ID:** `q6-04`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-02`
- **Learning Objective:** Deploy the fitted model for real-time inference on new flower measurements
- **Core Concept:** Input dimensionality requirements for scikit-learn inference
- **Reference:** Lesson 02 Concept Explanation: Anatomy of an Inference Request

**Options:**
- `A)` Scikit-learn estimators are designed for tabular matrix inputs of shape (n_samples, n_features)
- `B)` Python syntax disallows passing lists to functions
- `C)` To reduce the file size of the Python script
- `D)` Because 1D lists can only hold integers

**Correct Answer:** `A` — Scikit-learn estimators are designed for tabular matrix inputs of shape (n_samples, n_features)

**Explanation:** Scikit-learn estimators mandate 2D inputs of shape (n_samples, n_features). A single sample DataFrame has shape (1, 4).

**Distractor Analysis:**
- `B` (Python syntax disallows passing lists to functions): Python functions accept lists freely, but scikit-learn estimators validate array dimensions.
- `C` (To reduce the file size of the Python script): DataFrame wrappers have negligible impact on script file size.
- `D` (Because 1D lists can only hold integers): 1D Python lists can store arbitrary objects, including floats and strings.

---

### Question 5: What happens when an unconstrained decision tree (`max_depth=None`) is trained on noisy real-world data?

- **Question ID:** `q6-05`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-03`
- **Learning Objective:** Synthesize the central machine learning takeaway: model simplicity beats overfitted complexity
- **Core Concept:** Mechanism of unconstrained tree overfitting
- **Reference:** Lesson 03 Concept Explanation: The Mechanism of Overfitting

**Options:**
- `A)` It automatically prunes itself down to depth 1
- `B)` It creates hyper-specific branches memorizing training outliers, degrading generalization performance on unseen test data
- `C)` It raises a MemoryOverflowError
- `D)` It converts all features into strings

**Correct Answer:** `B` — It creates hyper-specific branches memorizing training outliers, degrading generalization performance on unseen test data

**Explanation:** An unconstrained decision tree continues splitting until all training leaves are pure, memorizing noise and outlier points at the expense of test generalization.

**Distractor Analysis:**
- `A` (It automatically prunes itself down to depth 1): Unconstrained trees do not prune themselves; pruning requires explicit parameters.
- `C` (It raises a MemoryOverflowError): A 150-row dataset consumes negligible memory; no overflow occurs.
- `D` (It converts all features into strings): Decision trees do not modify feature types.

---

### Question 6: How does a Random Forest improve upon a single Decision Tree?

- **Question ID:** `q6-06`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-04`
- **Learning Objective:** Formulate practical extension experiments including Random Forests, feature importances, and cross-validation
- **Core Concept:** Ensemble learning principles of Random Forests
- **Reference:** Lesson 04 Concept Explanation: The Evolution to Random Forests

**Options:**
- `A)` It trains an ensemble of diverse trees using bootstrap aggregating (bagging) and votes on the final class, reducing variance
- `B)` It converts all data into images before training
- `C)` It eliminates the need for computer RAM
- `D)` It guarantees 100% test accuracy on any dataset

**Correct Answer:** `A` — It trains an ensemble of diverse trees using bootstrap aggregating (bagging) and votes on the final class, reducing variance

**Explanation:** Random Forests combine multiple trees trained on bootstrap samples with random feature subsets, voting on the outcome to reduce variance.

**Distractor Analysis:**
- `B` (It converts all data into images before training): Random Forests operate directly on tabular feature matrices, not image conversions.
- `C` (It eliminates the need for computer RAM): Random Forests consume more RAM than single trees because they store 100+ trees.
- `D` (It guarantees 100% test accuracy on any dataset): No machine learning algorithm can guarantee 100% test accuracy on noisy real-world data.

---

### Question 7: What does the `feature_importances_` attribute in a tree model represent?

- **Question ID:** `q6-07`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-04`
- **Learning Objective:** Formulate practical extension experiments including Random Forests, feature importances, and cross-validation
- **Core Concept:** Definition and calculation of Gini feature importances
- **Reference:** Lesson 04 Concept Explanation: Measuring Feature Importance

**Options:**
- `A)` The price of collecting each feature in dollars
- `B)` The normalized total reduction in Gini impurity brought by each feature across all tree splits
- `C)` The alphabetical rank of the column headers
- `D)` The number of missing values in each feature

**Correct Answer:** `B` — The normalized total reduction in Gini impurity brought by each feature across all tree splits

**Explanation:** feature_importances_ calculates the normalized fraction of total Gini impurity reduction contributed by each feature across all tree splits.

**Distractor Analysis:**
- `A` (The price of collecting each feature in dollars): Financial data collection costs are not tracked by scikit-learn models.
- `C` (The alphabetical rank of the column headers): Feature importances are mathematical scores between 0.0 and 1.0, not alphabetical ranks.
- `D` (The number of missing values in each feature): Missing values are handled prior to training, not recorded in importance scores.

---

### Question 8: Why did `max_depth=2` assign 100% of its feature importance to `petal_length`?

- **Question ID:** `q6-08`
- **Difficulty:** Intermediate
- **Target Lesson:** `lesson-04`
- **Learning Objective:** Formulate practical extension experiments including Random Forests, feature importances, and cross-validation
- **Core Concept:** Connecting tree split rules to feature importance attribution
- **Reference:** Lesson 04 Concept Explanation: Feature Importance in depth-2 tree

**Options:**
- `A)` The other three features were corrupted during loading
- `B)` Because both of the decision splits in the depth-2 tree evaluated petal_length exclusively
- `C)` Because petal_length was the first column in the CSV file
- `D)` Because scikit-learn only calculates importance for one feature

**Correct Answer:** `B` — Because both of the decision splits in the depth-2 tree evaluated petal_length exclusively

**Explanation:** In main.py, max_depth=2 produced exactly two decision splits, and both evaluated petal_length. Since other features were never used in splits, their importance is 0.0.

**Distractor Analysis:**
- `A` (The other three features were corrupted during loading): All 4 features were loaded cleanly with zero corruption.
- `C` (Because petal_length was the first column in the CSV file): The first column in iris.csv is sepal_length, not petal_length.
- `D` (Because scikit-learn only calculates importance for one feature): Scikit-learn computes importance across all features; if multiple features split, multiple importances are non-zero.

---

### Question 9: How does K-Fold Cross-Validation provide a more dependable estimate of model generalization than a single train/test split?

- **Question ID:** `q6-09`
- **Difficulty:** Advanced
- **Target Lesson:** `lesson-04`
- **Learning Objective:** Formulate practical extension experiments including Random Forests, feature importances, and cross-validation
- **Core Concept:** Advantages of K-fold cross-validation over single train/test split
- **Reference:** Lesson 04 Concept Explanation: K-Fold Cross-Validation

**Options:**
- `A)` By evaluating the model across K non-overlapping holdout folds and averaging the scores, mitigating luck from a single random split
- `B)` By training the model K times on the entire dataset simultaneously
- `C)` By increasing the number of features by K times
- `D)` By removing 50% of the data permanently

**Correct Answer:** `A` — By evaluating the model across K non-overlapping holdout folds and averaging the scores, mitigating luck from a single random split

**Explanation:** K-Fold Cross-Validation rotates holdout validation folds K times and averages scores, preventing sampling bias from an unrepresentative single split.

**Distractor Analysis:**
- `B` (By training the model K times on the entire dataset simultaneously): Each fold trains on K-1 folds and tests on the remaining 1 fold; it does not train on the entire dataset simultaneously.
- `C` (By increasing the number of features by K times): Cross-validation partitions samples (rows), not features (columns).
- `D` (By removing 50% of the data permanently): Cross-validation evaluates all data; it does not delete rows permanently.

---

### Question 10: In the bias-variance tradeoff, what problem arises when tree depth is severely constrained to `max_depth=1` on the Iris dataset?

- **Question ID:** `q6-10`
- **Difficulty:** Advanced
- **Target Lesson:** `lesson-03`
- **Learning Objective:** Synthesize the central machine learning takeaway: model simplicity beats overfitted complexity
- **Core Concept:** Underfitting and high bias in overly constrained decision stumps
- **Reference:** Lesson 03 Concept Explanation: The Bias-Variance Tradeoff

**Options:**
- `A)` High variance (severe overfitting)
- `B)` High bias (underfitting), because a single split can only separate 2 classes, failing to represent 3 distinct species
- `C)` Zero error across all classes
- `D)` Memory exhaustion

**Correct Answer:** `B` — High bias (underfitting), because a single split can only separate 2 classes, failing to represent 3 distinct species

**Explanation:** max_depth=1 (a decision stump) can produce at most 2 leaves. Since Iris has 3 species, a stump suffers from high bias (underfitting), unable to represent all classes.

**Distractor Analysis:**
- `A` (High variance (severe overfitting)): max_depth=1 has minimal variance; its failure mode is high bias.
- `C` (Zero error across all classes): A decision stump cannot achieve zero error on a 3-class problem.
- `D` (Memory exhaustion): A 1-split tree uses minimal memory.

---

## Master Answer Matrix

| Question ID | Module | Lesson | Difficulty | Correct Answer |
| :--- | :--- | :--- | :--- | :--- |
| `q1-01` | Module 01 | `lesson-03` | Basic | **B** |
| `q1-02` | Module 01 | `lesson-01` | Basic | **B** |
| `q1-03` | Module 01 | `lesson-01` | Basic | **B** |
| `q1-04` | Module 01 | `lesson-02` | Intermediate | **C** |
| `q1-05` | Module 01 | `lesson-03` | Intermediate | **A** |
| `q1-06` | Module 01 | `lesson-04` | Intermediate | **B** |
| `q1-07` | Module 01 | `lesson-02` | Intermediate | **B** |
| `q1-08` | Module 01 | `lesson-03` | Intermediate | **B** |
| `q1-09` | Module 01 | `lesson-03` | Advanced | **B** |
| `q1-10` | Module 01 | `lesson-04` | Advanced | **A** |
| `q2-01` | Module 02 | `lesson-01` | Basic | **B** |
| `q2-02` | Module 02 | `lesson-02` | Basic | **B** |
| `q2-03` | Module 02 | `lesson-03` | Basic | **B** |
| `q2-04` | Module 02 | `lesson-02` | Intermediate | **B** |
| `q2-05` | Module 02 | `lesson-03` | Intermediate | **B** |
| `q2-06` | Module 02 | `lesson-03` | Intermediate | **B** |
| `q2-07` | Module 02 | `lesson-04` | Intermediate | **B** |
| `q2-08` | Module 02 | `lesson-03` | Intermediate | **B** |
| `q2-09` | Module 02 | `lesson-04` | Advanced | **A** |
| `q2-10` | Module 02 | `lesson-03` | Advanced | **A** |
| `q3-01` | Module 03 | `lesson-01` | Basic | **B** |
| `q3-02` | Module 03 | `lesson-02` | Basic | **B** |
| `q3-03` | Module 03 | `lesson-04` | Basic | **C** |
| `q3-04` | Module 03 | `lesson-01` | Intermediate | **A** |
| `q3-05` | Module 03 | `lesson-02` | Intermediate | **B** |
| `q3-06` | Module 03 | `lesson-03` | Intermediate | **C** |
| `q3-07` | Module 03 | `lesson-04` | Intermediate | **B** |
| `q3-08` | Module 03 | `lesson-03` | Intermediate | **C** |
| `q3-09` | Module 03 | `lesson-04` | Advanced | **B** |
| `q3-10` | Module 03 | `lesson-01` | Advanced | **C** |
| `q4-01` | Module 04 | `lesson-01` | Basic | **B** |
| `q4-02` | Module 04 | `lesson-02` | Basic | **B** |
| `q4-03` | Module 04 | `lesson-03` | Basic | **B** |
| `q4-04` | Module 04 | `lesson-01` | Intermediate | **B** |
| `q4-05` | Module 04 | `lesson-04` | Intermediate | **B** |
| `q4-06` | Module 04 | `lesson-02` | Intermediate | **B** |
| `q4-07` | Module 04 | `lesson-03` | Intermediate | **B** |
| `q4-08` | Module 04 | `lesson-04` | Intermediate | **B** |
| `q4-09` | Module 04 | `lesson-03` | Advanced | **A** |
| `q4-10` | Module 04 | `lesson-04` | Advanced | **B** |
| `q5-01` | Module 05 | `lesson-01` | Basic | **C** |
| `q5-02` | Module 05 | `lesson-03` | Basic | **A** |
| `q5-03` | Module 05 | `lesson-04` | Basic | **B** |
| `q5-04` | Module 05 | `lesson-02` | Intermediate | **A** |
| `q5-05` | Module 05 | `lesson-03` | Intermediate | **B** |
| `q5-06` | Module 05 | `lesson-02` | Intermediate | **B** |
| `q5-07` | Module 05 | `lesson-02` | Intermediate | **A** |
| `q5-08` | Module 05 | `lesson-03` | Intermediate | **C** |
| `q5-09` | Module 05 | `lesson-02` | Advanced | **A** |
| `q5-10` | Module 05 | `lesson-02` | Advanced | **B** |
| `q6-01` | Module 06 | `lesson-02` | Basic | **B** |
| `q6-02` | Module 06 | `lesson-01` | Basic | **C** |
| `q6-03` | Module 06 | `lesson-03` | Basic | **B** |
| `q6-04` | Module 06 | `lesson-02` | Intermediate | **A** |
| `q6-05` | Module 06 | `lesson-03` | Intermediate | **B** |
| `q6-06` | Module 06 | `lesson-04` | Intermediate | **A** |
| `q6-07` | Module 06 | `lesson-04` | Intermediate | **B** |
| `q6-08` | Module 06 | `lesson-04` | Intermediate | **B** |
| `q6-09` | Module 06 | `lesson-04` | Advanced | **A** |
| `q6-10` | Module 06 | `lesson-03` | Advanced | **B** |

