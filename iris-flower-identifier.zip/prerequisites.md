# Prerequisites

## Skills Required
- **Python Fundamentals**: Variables, dictionaries, loops, functions, and list/dict comprehensions
- **Basic pandas**: Reading CSV files, selecting column subsets, inspecting DataFrame shapes and column headers
- **Basic Data Concepts**: Understanding the difference between input features ($X$) and target outcomes ($y$), and between numeric continuous variables and categorical labels
- **Command Line Literacy**: Running scripts via terminal (`python main.py`) and inspecting file outputs

## Tools Required
- **Python 3.8+** (Python 3.9, 3.10, 3.11, or 3.12 recommended)
- **pip** package installer
- **Code Editor**: Visual Studio Code, Cursor, PyCharm, or any text editor with syntax highlighting
- **Image Viewer**: Any tool capable of opening PNG diagrams (`iris_tree.png`, `confusion_matrix.png`)

## Required Packages
- `pandas` (for CSV loading and tabular data manipulation)
- `numpy` (underlying scikit-learn numerical computations)
- `matplotlib` (for non-interactive chart and tree rendering)
- `scikit-learn` (for `DecisionTreeClassifier`, `train_test_split`, `export_text`, `plot_tree`, and evaluation metrics)

## Key Concepts to Review Before Starting
1. **What is supervised classification?** Unlike regression (predicting a numeric quantity like price or temperature), classification assigns samples into predefined discrete buckets or classes.
2. **Multi-class vs. Binary classification**: Binary has 2 classes (yes/no, spam/ham). The Iris problem has 3 classes (`setosa`, `versicolor`, `virginica`), requiring multi-class logic.
3. **Train-Test Splitting**: Why we never evaluate a model on the exact data it was trained on, and how overfitting misleads developers if validation data is not kept strictly isolated.
