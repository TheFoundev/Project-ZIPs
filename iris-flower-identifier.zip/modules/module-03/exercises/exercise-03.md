# Module 3 Exercises: Decision Tree Depth Tuning & Overfitting Analysis

## Exercise 3.1: Manual Calculation of Gini Impurity (15 min)
**Objective:** Calculate Gini impurity by hand for candidate node splits.
**Problem Statement:** A decision tree node contains 40 samples from the training set: 0 *setosa*, 28 *versicolor*, and 12 *virginica*. Calculate the exact Gini impurity of this node.

**Requirements:**
1. State the formula for Gini Impurity across $K=3$ classes.
2. Calculate the proportion $p_k$ for each species in the node.
3. Square each proportion and compute the sum of squared proportions.
4. Subtract the sum from 1.0 to arrive at the final Gini impurity.
5. State whether this node is pure, moderately pure, or completely mixed.

**Constraints:** Show all fractional and decimal steps to 4 decimal places.

**Expected Behaviour:** Written calculation with explicit steps.

**Acceptance Criteria:**
- [ ] Formula stated correctly: $I_G = 1 - \sum p_k^2$
- [ ] Proportions calculated: $p_{\text{setosa}} = 0.0$, $p_{\text{versicolor}} = 28/40 = 0.70$, $p_{\text{virginica}} = 12/40 = 0.30$
- [ ] Sum of squares: $0.70^2 + 0.30^2 = 0.49 + 0.09 = 0.58$
- [ ] Gini computed: $1.0 - 0.58 = 0.4200$
- [ ] Concludes node is moderately impure with a versicolor majority

**Hints:**
- $28/40 = 0.7$
- $12/40 = 0.3$

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 3.2: Replicating the Depth Comparison Loop (15 min)
**Objective:** Implement lines 42-51 of `main.py` independently.
**Problem Statement:** Write a standalone Python script that partitions the Iris data, trains decision trees across depths `(2, 3, None)`, and stores results in a dictionary.

**Requirements:**
1. Split `data/iris.csv` with `test_size=0.25, random_state=42, stratify=y`.
2. Iterate through depths `(2, 3, None)`.
3. Train `DecisionTreeClassifier(max_depth=depth, random_state=42)`.
4. Store `(model, predictions, accuracy)` in dictionary `models`.
5. Print formatted output matching `main.py`.

**Constraints:** Ensure `random_state=42` is passed to both split and classifier.

**Expected Behaviour:** Terminal output displaying formatted accuracy percentages.

**Acceptance Criteria:**
- [ ] Dictionary `models` contains 3 entries
- [ ] Formatted output displays:
  - `max_depth=2         accuracy=92.1%`
  - `max_depth=3         accuracy=89.5%`
  - `max_depth=unlimited accuracy=89.5%`
- [ ] Best depth programmatically extracted as `2`

**Hints:**
- Use string formatting: `f"  max_depth={label:9s} accuracy={accuracy:.1%}"`.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 3.3: Quantifying the Overfitting Gap (15 min)
**Objective:** Calculate train accuracy versus test accuracy to measure the overfitting gap.
**Problem Statement:** Overfitting is mathematically defined as a large divergence between training performance and generalization performance. Quantify this divergence across all three depths.

**Requirements:**
1. For each depth `(2, 3, None)`, calculate `train_acc = accuracy_score(y_train, model.predict(X_train))`.
2. Retrieve `test_acc` on `X_test`.
3. Compute the Overfitting Gap: $\text{Gap} = \text{train\_acc} - \text{test\_acc}$.
4. Tabulate your findings and identify which model exhibits the largest gap.

**Constraints:** Use the 112-sample training set and 38-sample testing set from `main.py`.

**Expected Behaviour:** A comparative table showing train accuracy, test accuracy, and the gap for each depth.

**Acceptance Criteria:**
- [ ] Depth 2 shows train ~95.5%, test 92.1%, gap ~3.4%
- [ ] Depth 3 shows train ~98.2%, test 89.5%, gap ~8.7%
- [ ] Depth None shows train 100.0%, test 89.5%, gap 10.5%
- [ ] Accurately concludes that `max_depth=None` exhibits the highest overfitting gap

**Hints:**
- Call `model.predict(X_train)` to get training predictions.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 3.4: Dynamic Model Selection with Lambda (10 min)
**Objective:** Master Python's `max()` function with custom key extractors.
**Problem Statement:** Explain how `best_depth = max(models, key=lambda depth: models[depth][2])` works under the hood and adapt it to select the model with the minimum depth among top performers.

**Requirements:**
1. Break down the execution of `max(models, key=lambda depth: models[depth][2])` step by step.
2. Explain what `models[depth][2]` references.
3. Write an alternative snippet that would select the model with lowest training error.

**Constraints:** Reference the exact dictionary structure created in `main.py`.

**Expected Behaviour:** Written explanation and code example demonstrating custom key functions.

**Acceptance Criteria:**
- [ ] Explains that `max()` iterates over dictionary keys
- [ ] Identifies index `2` as the accuracy float
- [ ] Explains how the lambda transforms each key into a comparable numeric score
- [ ] Demonstrates understanding of key functions in Python

**Hints:**
- The dictionary keys are `2`, `3`, and `None`.

**Difficulty:** Advanced
**Estimated Completion Time:** 10 minutes
