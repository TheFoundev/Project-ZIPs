# Lesson 04: The Overfitting Trap: Why Simpler Trees Win on Test Data

**Lesson ID:** lesson-04
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define **overfitting** and **underfitting** in supervised machine learning
- Explain why 100% training accuracy is often a dangerous red flag rather than a victory
- Analyze why `max_depth=2` (92.1% accuracy) outperforms `max_depth=None` (89.5% accuracy) on the Iris test set
- Understand the foundational **bias-variance tradeoff** that governs all predictive modeling

## Prerequisites
- Completion of Lessons 01, 02, and 03
- Understanding of training sets versus holdout testing sets

## Concept Explanation
### The Intuition: Memorization vs. Generalization
Consider a student preparing for a biology exam:
- **Student A (The Memorizer)**: Memorizes every single word, typo, and diagram placement in practice exams. If a question changes by one word, they fail.
- **Student B (The Concept Master)**: Learns the general rules of botany. They miss a tiny trick question on the practice exam, but ace the final exam because they understand the core principles.

In machine learning:
- An **overfitted model** is Student A. It learns both the underlying signal AND the random statistical noise in the training set.
- A **well-regularized model** is Student B. It captures the true signal while ignoring noisy fluctuations.

```
       Error Rate vs. Model Complexity
       
  High  ^
        |     Training Error (drops continuously)
  Error |   \  Test Error (U-shaped curve!)
        |    \         /
        |     \  Optimum
        |      \___/   <-- Overfitting Zone
  Low   +-------------------------------------->
        Simple (Underfitting)       Complex (Overfitting)
```

### Deconstructing the Iris Depth Results
Let us look at what actually happens inside our models:

| Metric | `max_depth=2` | `max_depth=3` | `max_depth=None` (Unlimited) |
|---|---|---|---|
| **Training Accuracy** | 95.5% (107/112) | 98.2% (110/112) | **100.0% (112/112)** |
| **Test Accuracy** | **92.1% (35/38)** | 89.5% (34/38) | 89.5% (34/38) |
| **Number of Decision Splits** | 2 | 4 | 6 |
| **Model Status** | **Optimal Regularization** | Slight Overfitting | Severe Overfitting |

Look closely at the table:
- On the training data, `max_depth=None` looks "perfect" (100% accuracy). It classified every single training flower without a single mistake.
- But on the unseen test data, `max_depth=None` **loses an entire flower**, falling to 89.5%!
- In contrast, `max_depth=2` made 5 training mistakes, but achieved **92.1%** on the test set!

### The Bias-Variance Tradeoff
This dynamic is governed by the universal mathematical principle known as the **bias-variance tradeoff**:
1. **Bias (Underfitting)**: Error caused by overly simplistic assumptions. If we set `max_depth=1`, the model assumes only 2 species exist, creating high bias.
2. **Variance (Overfitting)**: Error caused by extreme sensitivity to small fluctuations in the training set. An unconstrained tree (`max_depth=None`) builds hyper-specific rules to isolate a single atypical flower, creating high variance.
3. **The Sweet Spot**: `max_depth=2` balances bias and variance perfectly for the Iris dataset. It captures the fundamental morphological differences without memorizing noise.

## Relevant Code
In `main.py` (lines 50-54 and line 100):
```python
    print(f"  max_depth={label:9s} accuracy={accuracy:.1%}")

    best_depth = max(models, key=lambda depth: models[depth][2])
    model, predictions, accuracy = models[best_depth]
    print(f"\nBest tree: max_depth={best_depth}")

    # Closing suggestion:
    print("Try this: set max_depth=2 and compare the simpler tree with the deeper one.")
```

## Code Explanation
Line 50 reveals the test accuracies. Line 52 automatically identifies `best_depth = 2`. Line 100 provides a pedagogical challenge to the user: compare the simpler tree with the deeper one to experience why Occam's Razor—the principle that simpler explanations are generally better than complex ones—reigns supreme in data science.

## Worked Example
Why did `max_depth=None` make an error on the test set that `max_depth=2` avoided?
In the training data, there was an atypical *versicolor* flower with petal length 4.8 cm and petal width 1.8 cm. Most *versicolor* flowers have petal width <= 1.5 cm.
- To achieve 100% training accuracy, `max_depth=None` added a split: `petal_width <= 1.75`.
- In the test set, a normal *virginica* flower had petal length 4.9 cm and petal width 1.7 cm.
- Because 1.7 is less than 1.75, the overfitted rule misclassified this legitimate *virginica* flower as a *versicolor*!
- `max_depth=2` never created that fragile petal-width rule; it evaluated only petal length (4.9 > 4.85), classifying the flower as *virginica* correctly!

## Step-by-Step Student Instructions
1. Run `python main.py`.
2. Observe the terminal output showing `max_depth=2` winning with 92.1%.
3. In terminal, run a training accuracy check script:
   ```bash
   python -c "
   import pandas as pd
   from sklearn.model_selection import train_test_split
   from sklearn.tree import DecisionTreeClassifier

   df = pd.read_csv('data/iris.csv')
   X, y = df[['sepal_length', 'sepal_width', 'petal_length', 'petal_width']], df['species']
   X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)
   for d in (2, None):
       m = DecisionTreeClassifier(max_depth=d, random_state=42).fit(X_train, y_train)
       print(f'depth={d} -> Train Acc: {m.score(X_train, y_train):.1%}, Test Acc: {m.score(X_test, y_test):.1%}')
   "
   ```
4. Confirm that `max_depth=None` gets 100% on train, but drops on test.

## Expected Output or Observable Behaviour
The command outputs:
```
depth=2 -> Train Acc: 95.5%, Test Acc: 92.1%
depth=None -> Train Acc: 100.0%, Test Acc: 89.5%
```
This directly demonstrates the classic hallmark of overfitting: rising training accuracy accompanied by declining test accuracy.

## Practical Exercises
- **Exercise 4.1**: What is the training accuracy of `max_depth=None` on our dataset?
- **Exercise 4.2**: Why is a 100% training accuracy score often misleading?
- **Exercise 4.3**: State Occam's Razor in the context of machine learning model selection.

## Common Mistakes and Debugging
| Mistake | Why It Happens | Solution |
|---|---|---|
| Selecting models based on training score | Failing to evaluate on holdout test set | Never use training accuracy to choose production hyperparameters. |
| Assuming overfitting only happens in deep learning | Believing simple models cannot overfit | Unconstrained decision trees are notorious for severe overfitting. |
| Pruning too aggressively | Setting `max_depth=1` | Extremely shallow trees underfit; tune hyperparameters across a validation curve. |

## Best Practices and Security Considerations
- **Occam's Razor**: Given two models with comparable performance, always select the simpler, shallower architecture.
- **Cross-Validation**: For mission-critical deployments, perform K-fold cross-validation to ensure hyperparameter rankings are stable across multiple data folds.
- **Model Monitoring**: In production, track prediction drift over time; overfitted models degrade rapidly when live data distributions drift slightly.

## Summary
Overfitting occurs when a model memorizes idiosyncrasies of training data at the expense of generalization. While an unconstrained decision tree (`max_depth=None`) achieves 100% training accuracy by carving intricate boundaries around training outliers, it drops to 89.5% on test data. Constraining depth to `max_depth=2` achieves 92.1% test accuracy, embodying the fundamental ML lesson that simplicity and regularization produce superior real-world performance.

## Knowledge-check Questions
1. What is the definition of overfitting in supervised learning?
2. What training accuracy did `max_depth=None` achieve, and what was its test accuracy?
3. Why did `max_depth=2` achieve higher test accuracy than `max_depth=None`?
4. What are the two opposing forces in the bias-variance tradeoff?
5. What philosophical principle advises choosing the simpler model when predictive power is equal?

## References
- scikit-learn Overfitting and regularization guide (https://scikit-learn.org/stable/auto_examples/model_selection/plot_underfitting_overfitting.html).
- Domingos, P. (2012). *A few useful things to know about machine learning*. Communications of the ACM, 55(10), 78-87.
