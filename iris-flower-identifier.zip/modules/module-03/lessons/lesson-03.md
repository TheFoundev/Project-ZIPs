# Lesson 03: Comparing Models Programmatically: Loops, Dictionaries, and accuracy_score

**Lesson ID:** lesson-03
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Implement programmatic hyperparameter comparison loops in Python
- Store trained models, predictions, and evaluation metrics in structured dictionaries
- Use `sklearn.metrics.accuracy_score` to quantify classification performance
- Select the best performing model programmatically using Python's `max()` function with a custom lambda key

## Prerequisites
- Completion of Lesson 01 and Lesson 02
- Familiarity with Python tuples, dictionaries, and lambda functions

## Concept Explanation
### The Anti-Pattern: Manual Copy-Pasting
Beginner programmers often test machine learning models by writing repetitive, error-prone code:
```python
# The messy, manual way:
model2 = DecisionTreeClassifier(max_depth=2)
model2.fit(X_train, y_train)
acc2 = accuracy_score(y_test, model2.predict(X_test))

model3 = DecisionTreeClassifier(max_depth=3)
model3.fit(X_train, y_train)
acc3 = accuracy_score(y_test, model3.predict(X_test))
```
This violates the DRY (Don't Repeat Yourself) principle. If you want to test 10 depths, you would have to copy-paste 40 lines of code.

### The Professional Pattern: Programmatic Iteration
In `main.py`, lines 42-53 demonstrate a clean, idiomatic design pattern:
1. Initialize an empty dictionary: `models = {}`.
2. Iterate through a collection of hyperparameter values: `for depth in (2, 3, None):`.
3. Inside the loop, instantiate, train, predict, and score.
4. Store the tuple `(model, predictions, accuracy)` inside the dictionary keyed by `depth`.

```
     models dictionary structure:
     {
       2:    (DecisionTreeClassifier(max_depth=2), array([...]), 0.9211),
       3:    (DecisionTreeClassifier(max_depth=3), array([...]), 0.8947),
       None: (DecisionTreeClassifier(max_depth=None), array([...]), 0.8947)
     }
```

### Quantifying Performance with accuracy_score
The metric used to compare depths is **classification accuracy**:
$$\text{Accuracy} = \frac{\text{Number of Correct Predictions}}{\text{Total Number of Predictions}} = \frac{1}{N} \sum_{i=1}^{N} \mathbb{I}(y_i = \hat{y}_i)$$
In scikit-learn, `accuracy_score(y_test, predictions)` compares each actual species string in `y_test` with the model's predicted string in `predictions`. For our 38 test samples:
- At `max_depth=2`: 35 correct out of 38 $ightarrow 35/38 = 0.92105 \approx 92.1\%$
- At `max_depth=3`: 34 correct out of 38 $ightarrow 34/38 = 0.89474 \approx 89.5\%$
- At `max_depth=None`: 34 correct out of 38 $ightarrow 34/38 = 0.89474 \approx 89.5\%$

### Selecting the Winner: max() with lambda Key
How do we extract the winning model from our dictionary without hardcoding?
```python
best_depth = max(models, key=lambda depth: models[depth][2])
model, predictions, accuracy = models[best_depth]
```
- `max(models, ...)` iterates over the dictionary keys (`2`, `3`, `None`).
- The key function `lambda depth: models[depth][2]` extracts index `2` of the value tuple—which is the `accuracy` float!
- `max()` compares the accuracy values and returns the key corresponding to the highest accuracy: `2`.
- We then unpack the winning tuple into `model`, `predictions`, and `accuracy`.

## Relevant Code
In `main.py` (lines 42-54):
```python
    models = {}
    for depth in (2, 3, None):
        model = DecisionTreeClassifier(max_depth=depth, random_state=42)
        model.fit(X_train, y_train)
        predictions = model.predict(X_test)
        accuracy = accuracy_score(y_test, predictions)
        models[depth] = (model, predictions, accuracy)
        label = "unlimited" if depth is None else str(depth)
        print(f"  max_depth={label:9s} accuracy={accuracy:.1%}")

    best_depth = max(models, key=lambda depth: models[depth][2])
    model, predictions, accuracy = models[best_depth]
    print(f"\nBest tree: max_depth={best_depth}")
```

## Code Explanation
This snippet encapsulates the entire hyperparameter tuning loop. By decoupling the evaluation loop from hardcoded variable names, adding new depths (e.g. `(1, 2, 3, 4, 5, None)`) requires modifying only a single tuple! The `max()` call ensures that whatever depth performs best is automatically selected for downstream plotting and export.

## Worked Example
Suppose an engineer wants to test depths 1 through 5:
```python
depths_to_test = (1, 2, 3, 4, 5, None)
results = {}

for d in depths_to_test:
    m = DecisionTreeClassifier(max_depth=d, random_state=42).fit(X_train, y_train)
    acc = accuracy_score(y_test, m.predict(X_test))
    results[d] = acc

for d, acc in results.items():
    print(f"Depth {str(d):5s} -> Accuracy: {acc:.2%}")
```
Output:
```
Depth 1     -> Accuracy: 65.79%
Depth 2     -> Accuracy: 92.11%
Depth 3     -> Accuracy: 89.47%
Depth 4     -> Accuracy: 89.47%
Depth 5     -> Accuracy: 89.47%
Depth None  -> Accuracy: 89.47%
```
Notice: Depth 1 underfits badly (65.8%). Depth 2 peaks at 92.1%. Depths 3 through None plateau and overfit at 89.5%.

## Step-by-Step Student Instructions
1. Inspect lines 42-54 of `main.py`.
2. Locate the dictionary definition `models = {}`.
3. Trace what elements are stored in the 3-element value tuple: `(model, predictions, accuracy)`.
4. Observe how `best_depth` is selected using `max(models, key=...)`.
5. Run the code and verify `Best tree: max_depth=2` prints to the terminal.

## Expected Output or Observable Behaviour
Console output:
```
Comparing tree depths:

  max_depth=2         accuracy=92.1%
  max_depth=3         accuracy=89.5%
  max_depth=unlimited accuracy=89.5%

Best tree: max_depth=2
```
This confirms that the loop accurately recorded and compared all three depths and selected depth 2.

## Practical Exercises
- **Exercise 3.1**: Write a lambda function that extracts the first element (the model instance) from the tuple stored in `models[depth]`.
- **Exercise 3.2**: If two depths achieve the exact same accuracy, which depth does `max()` return? (In Python, `max()` returns the first key encountered with the maximal value).
- **Exercise 3.3**: Why is storing predictions in the dictionary useful for downstream evaluation?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Solution |
|---|---|---|
| Forgetting lambda key | Running `max(models)` without a key | `max(models)` compares the keys (`2`, `3`, `None`), which raises a `TypeError` comparing `int` and `NoneType`. |
| Overwriting model variable | Reusing the name `model` inside the loop | Storing models in `models[depth]` preserves access to every trained instance. |
| Inverting `accuracy_score` arguments | Calling `accuracy_score(predictions, y_test)` | While symmetric in accuracy, conventional order is `(y_true, y_pred)`. |

## Best Practices and Security Considerations
- **Structured Metric Storage**: Store artifacts in structured dictionaries or pandas DataFrames to make logging, visualization, and tabular reporting trivial.
- **Dynamic Selection**: Never hardcode `best_model = models[2]`; always let programmatic comparison select the optimal hyperparameter based on objective validation metrics.
- **Extensibility**: Designing loops around tuples or lists makes scaling to grid searches or randomized searches seamless.

## Summary
Programmatic iteration using Python loops and dictionaries enables clean, automated hyperparameter comparison without code duplication. `accuracy_score` provides an objective quantitative benchmark across depths. Python's `max()` function paired with a custom lambda key dynamically identifies the optimal model, ensuring robust, automated model selection.

## Knowledge-check Questions
1. Why is comparing hyperparameters inside a loop preferred over manual copy-pasted code blocks?
2. What three items are stored in each tuple in the `models` dictionary?
3. What is the mathematical definition of classification accuracy?
4. How many correct predictions out of 38 did `max_depth=2` make?
5. Why does `max(models)` fail if no custom `key` argument is supplied?

## References
- scikit-learn accuracy_score documentation (https://scikit-learn.org/stable/modules/generated/sklearn.metrics.accuracy_score.html).
- Python Built-in Functions: max (https://docs.python.org/3/library/functions.html#max).
