# Lesson 02: Controlling Model Complexity with max_depth (2, 3, and None)

**Lesson ID:** lesson-02
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define the `max_depth` hyperparameter in `DecisionTreeClassifier`
- Explain the physical and geometric meaning of tree depth (number of decision layers)
- Contrast shallow constrained trees (`max_depth=2`, `max_depth=3`) with unconstrained trees (`max_depth=None`)
- Describe the theoretical relationship between tree depth and decision boundary complexity

## Prerequisites
- Completion of Lesson 01 (Gini Impurity and Splits)
- Basic understanding of binary trees and tree height in computer science

## Concept Explanation
### What is Tree Depth?
In graph theory and computer science, the **depth** of a tree is the length of the longest path from the root node to any leaf node. In a decision tree classifier:
- A tree of **depth 1** (a "decision stump") asks exactly 1 question, producing at most 2 leaf nodes.
- A tree of **depth 2** asks 1 question at the root and up to 2 subsequent questions, producing at most 4 leaf nodes ($2^2 = 4$).
- A tree of **depth 3** can create up to 8 leaf nodes ($2^3 = 8$).
- A tree of **depth $d$** can partition feature space into at most $2^d$ distinct hyper-rectangles.

```
       max_depth = 2
            [ Root Split ]           <-- Depth 0
             /          \
      (Leaf: setosa)   [ Split 2 ]   <-- Depth 1
                        /       \
             (Leaf: versicolor) (Leaf: virginica)  <-- Depth 2
```

### The Three Configurations in main.py
In `main.py`, lines 43-51 compare three distinct depth levels:
1. `max_depth=2`: A shallow, highly constrained architecture. It permits at most 2 sequential decision steps. This forces the model to capture only the broadest, most dominant patterns in the data.
2. `max_depth=3`: A moderately deep tree. It allows up to 3 sequential decisions, permitting finer subdivisions of the feature space to resolve difficult boundary specimens.
3. `max_depth=None`: The unconstrained, unlimited architecture. In scikit-learn, setting `max_depth=None` instructs the tree to continue growing until **every single leaf is 100% pure** (Gini = 0.0) or contains fewer than `min_samples_split` samples.

### Geometric Interpretation: Decision Boundaries
Decision trees carve feature space into rectangular decision regions parallel to the feature axes:
- At `max_depth=2`, the boundary consists of two straight perpendicular cuts across the feature space.
- At `max_depth=None`, the tree carves intricate, stair-stepped, jagged islands around individual outlier data points in the training set.

```
     max_depth=2 (Smooth Cuts)         max_depth=None (Jagged Islands)
  Petal Width                        Petal Width
     ^                                  ^
     | +++++++++++ virginica            | +++++++  vir  +++++++
     | -----------                      | ----+  vir  +--------
     | *********** versicolor           | ****|       |********
     | ===================              | ====+  ver  +========
     | ########### setosa               | #####################
     +----------------------->          +----------------------->
            Petal Length                       Petal Length
```

While jagged boundaries may achieve 100% accuracy on the specific training coordinates, they often capture random noise that fails to generalize to new specimens.

## Relevant Code
In `main.py` (lines 42-50):
```python
    models = {}
    for depth in (2, 3, None):
        model = DecisionTreeClassifier(max_depth=depth, random_state=42)
        model.fit(X_train, y_train)
        predictions = model.predict(X_test)
        accuracy = accuracy_score(y_test, predictions)
        models[depth] = (model, predictions, accuracy)
        label = "unlimited" if depth is None else str(depth)
        print(f"  max_depth={label:9s} accuracy={accuracy:.1%}")
```

## Code Explanation
Line 43 defines a tuple of depths: `(2, 3, None)`. For each depth, a new `DecisionTreeClassifier` is initialized. Line 44 sets `max_depth=depth` and enforces reproducibility with `random_state=42`. Line 45 fits the tree on the 112 training samples. Line 46 predicts on the 38 test samples. Line 49 formats `None` into the readable string `"unlimited"`, and line 50 displays the formatted percentage.

## Worked Example
Let us trace what happens when `max_depth=None` fits the training set:
In `X_train` (112 samples), there are 37 *versicolor* and 37 *virginica*. In nature, one or two atypical *versicolor* flowers have unusually large petals (e.g. `petal_length=5.1`, `petal_width=1.8`), while an atypical *virginica* has smaller petals.
- With `max_depth=2`, the tree ignores these single outliers and draws a clean cut at 4.85 cm.
- With `max_depth=None`, the tree refuses to tolerate a single training error. It creates extra microscopic branches testing `petal_width <= 1.75`, `sepal_length <= 4.95`, etc., purely to isolate those two weird training flowers!
On the training set, `max_depth=None` scores 100%. But on the 38 test flowers, those microscopic cuts misclassify normal specimens, dropping test accuracy!

## Step-by-Step Student Instructions
1. Open `main.py` in your editor.
2. Locate the loop starting at line 43.
3. Run `python main.py` in your terminal.
4. Compare the printed accuracies:
   - `max_depth=2`: 92.1%
   - `max_depth=3`: 89.5%
   - `max_depth=unlimited`: 89.5%
5. Note how the simplest tree beats both deeper models!

## Expected Output or Observable Behaviour
The terminal outputs:
```
============================================================
THE IRIS FLOWER IDENTIFIER
============================================================
Comparing tree depths:

  max_depth=2         accuracy=92.1%
  max_depth=3         accuracy=89.5%
  max_depth=unlimited accuracy=89.5%
```
This confirms that increasing depth beyond 2 harms test set performance.

## Practical Exercises
- **Exercise 2.1**: What is the maximum number of leaf nodes possible in a binary tree of depth 3? ($2^3 = 8$).
- **Exercise 2.2**: If you set `max_depth=1`, what is such a model commonly called in machine learning literature? (A "decision stump").
- **Exercise 2.3**: What does passing `max_depth=None` instruct scikit-learn to do?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Solution |
|---|---|---|
| Passing string `"None"` instead of `None` | Typing quotes around `None` | Pass Python's built-in `None` object, not the string `"None"`. |
| Assuming deeper trees always win | Confusing training performance with test performance | Evaluate on test data; constrained depths regularly beat unconstrained trees. |
| Forgetting `random_state=42` | Omitting seed parameter | When splits have tie-break candidates, random_state ensures deterministic tree growth. |

## Best Practices and Security Considerations
- **Hyperparameter Regularization**: Always constrain tree depth via `max_depth`, `min_samples_split`, or `min_samples_leaf` to prevent uninhibited tree memorization.
- **Explainability Budget**: In human-facing domains, restrict `max_depth` to 2 or 3 so domain specialists can hold the entire decision tree in their mental working memory.
- **Computational Footprint**: Deep trees consume more memory and CPU cycles during inference; shallow trees execute in microseconds.

## Summary
The `max_depth` hyperparameter governs the vertical growth and structural complexity of a decision tree. While `max_depth=None` builds an unconstrained tree that memorizes training nuances, shallow trees (`max_depth=2`) restrict the model to macroscopic, robust decision boundaries. In this project, `max_depth=2` achieves 92.1% test accuracy, proving that simpler models often yield superior real-world generalization.

## Knowledge-check Questions
1. What does the `max_depth` hyperparameter control?
2. What happens when `max_depth=None` is passed to `DecisionTreeClassifier`?
3. How many leaf nodes can a binary tree of depth 2 produce at most?
4. What test accuracy was achieved by `max_depth=2` versus `max_depth=unlimited`?
5. Why are shallow trees preferred for model interpretability?

## References
- scikit-learn DecisionTreeClassifier API reference (https://scikit-learn.org/stable/modules/generated/sklearn.tree.DecisionTreeClassifier.html).
- James, G., Witten, D., Hastie, T., & Tibshirani, R. (2021). *An Introduction to Statistical Learning*. Springer. Chapter 8: Tree-Based Methods.
