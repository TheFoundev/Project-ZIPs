# Lesson 01: How Decision Trees Split: Thresholds, Information Gain, and Gini Impurity

**Lesson ID:** lesson-01
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain how a decision tree selects the best feature and numeric split threshold
- Define **Gini Impurity** and calculate its value for completely pure and evenly mixed nodes
- Explain the concept of "impurity reduction" (information gain) during tree training
- Understand why decision trees do not require feature scaling or normalization

## Prerequisites
- Completion of Module 01 and Module 02
- Basic understanding of fractions, squaring numbers, and probabilities

## Concept Explanation
### The Core Challenge: How Does a Tree Decide Where to Cut?
A decision tree does not guess thresholds randomly. Given continuous numerical features, there are hundreds of possible split points. How does `DecisionTreeClassifier` choose to split on `petal_length <= 2.45` rather than `sepal_length <= 5.5`?

The algorithm uses a greedy search:
1. For every feature in $X$, it sorts the unique values observed in the training data.
2. It considers candidate thresholds midway between adjacent sorted values.
3. For each candidate threshold, it splits the training samples into two child nodes (Left: condition True, Right: condition False).
4. It measures the **purity** of the child nodes using a mathematical metric called **Gini Impurity**.
5. It selects the feature and threshold that yields the greatest reduction in impurity.

### What is Gini Impurity?
Gini impurity measures the statistical probability that a randomly chosen element from a node would be incorrectly labeled if it were randomly classified according to the distribution of labels in that node.

For $K$ classes, the Gini impurity $I_G$ of node $m$ is defined as:
$$I_G(m) = 1 - \sum_{k=1}^{K} p_{mk}^2$$
where $p_{mk}$ is the proportion of samples at node $m$ belonging to class $k$.

#### Case 1: A Completely Pure Node
Suppose a leaf node contains 38 samples, and all 38 belong to *Iris setosa* ($p_{\text{setosa}} = 1.0, p_{\text{versicolor}} = 0.0, p_{\text{virginica}} = 0.0$):
$$I_G = 1 - (1.0^2 + 0.0^2 + 0.0^2) = 1 - 1.0 = 0.0$$
A Gini impurity of **0.0** represents a **pure node**. There is zero uncertainty; the model can issue a prediction with 100% confidence.

#### Case 2: An Evenly Mixed Node
Suppose a node contains an equal mix of 10 *setosa*, 10 *versicolor*, and 10 *virginica* ($p_k = 1/3$ for each):
$$I_G = 1 - \left(\left(\frac{1}{3}\right)^2 + \left(\frac{1}{3}\right)^2 + \left(\frac{1}{3}\right)^2\right) = 1 - 3\left(\frac{1}{9}\right) = 1 - 0.333 = 0.667$$
A Gini impurity of **0.667** represents maximum confusion for a 3-class problem.

```
       Root Node: 112 samples (38 setosa, 37 versicolor, 37 virginica)
       Gini = 0.667 (High Impurity)
                         |
           [petal_length <= 2.45 cm]
                 /               \
            True                   False
             v                       v
    Left Child Node:         Right Child Node:
    38 samples               74 samples
    (38 setosa, 0, 0)        (0 setosa, 37 versicolor, 37 virginica)
    Gini = 0.0 (PURE!)       Gini = 0.500 (Moderate Impurity)
```

### Why Decision Trees Require No Feature Scaling
Algorithms like K-Nearest Neighbors, Support Vector Machines, and Neural Networks calculate Euclidean distances or dot products between features. If one feature is measured in meters (0-2) and another in grams (0-5000), the larger scale dominates the distance calculation.

Decision trees, however, evaluate features **one at a time along individual axes**. Because the split condition `petal_length <= 2.45` only compares petal length against other petal lengths, changing the units from centimeters to millimeters (24.5 mm) has zero mathematical effect on the split. Decision trees are completely invariant to monotonic feature scaling!

## Relevant Code
In `main.py` (lines 43-45):
```python
    models = {}
    for depth in (2, 3, None):
        model = DecisionTreeClassifier(max_depth=depth, random_state=42)
        model.fit(X_train, y_train)
```

## Code Explanation
When `DecisionTreeClassifier()` is instantiated, its default split criterion is `criterion="gini"`. During `model.fit(X_train, y_train)`, scikit-learn's underlying optimized Cython engine computes the Gini impurity for all candidate thresholds and recursively builds the tree until the stopping criteria are reached.

## Worked Example
Let us compute the Gini reduction for the root split in `main.py`:
- Root node: $N = 112$ samples, 38 setosa, 37 versicolor, 37 virginica.
  $$I_G(\text{Root}) = 1 - \left[\left(\frac{38}{112}\right)^2 + \left(\frac{37}{112}\right)^2 + \left(\frac{37}{112}\right)^2\right] \approx 0.6664$$
- Left split (`petal_length <= 2.45`): $N_L = 38$ samples, all 38 setosa.
  $$I_G(\text{Left}) = 1 - (1.0^2) = 0.0$$
- Right split (`petal_length > 2.45`): $N_R = 74$ samples, 0 setosa, 37 versicolor, 37 virginica.
  $$I_G(\text{Right}) = 1 - \left[0^2 + \left(\frac{37}{74}\right)^2 + \left(\frac{37}{74}\right)^2\right] = 1 - (0.25 + 0.25) = 0.500$$
- Weighted Child Impurity:
  $$I_G(\text{Children}) = \frac{38}{112}(0.0) + \frac{74}{112}(0.500) = 0 + 0.3304 = 0.3304$$
- Impurity Reduction (Information Gain):
  $$\Delta I_G = 0.6664 - 0.3304 = 0.3360$$
No other feature or threshold in the dataset produces an impurity reduction higher than 0.3360 at the root!

## Step-by-Step Student Instructions
1. Open `main.py` and inspect the loop on line 43.
2. Note that `DecisionTreeClassifier` is imported from `sklearn.tree`.
3. Check the documentation for default parameters: `criterion='gini'` is the default.
4. Verify why the root split chooses 2.45 cm: the largest setosa in training has petal length 1.9 cm and the smallest versicolor has 3.0 cm; 2.45 is the optimal midpoint threshold.

## Expected Output or Observable Behaviour
When inspecting the tree diagram in `outputs/iris_tree.png`, the root node displays:
```
petal_length <= 2.45
gini = 0.666
samples = 112
value = [38, 37, 37]
class = setosa
```
This confirms our exact manual Gini calculations.

## Practical Exercises
- **Exercise 1.1**: Calculate the Gini impurity for a node containing 50 *versicolor* and 0 *virginica*.
- **Exercise 1.2**: Calculate the Gini impurity for a binary node containing 25 *versicolor* and 25 *virginica*. (Hint: $1 - (0.5^2 + 0.5^2)$).
- **Exercise 1.3**: Why do decision trees not require standardization (e.g. `StandardScaler`) prior to training?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Solution |
|---|---|---|
| Scaling features unnecessarily | Applying `StandardScaler` out of habit | Decision trees do not need scaling; skipping it preserves original units (cm) in rules. |
| Confusing Gini impurity with Gini coefficient | Similar naming in economics | In ML, Gini impurity measures classification node purity between 0.0 and 1 - 1/K. |
| Thinking splits can only be 50/50 | Expecting equal sample division | Splits partition based on purity, not equal sample counts (e.g., 38 left, 74 right). |

## Best Practices and Security Considerations
- **Criterion Selection**: Gini impurity is computationally faster than entropy (which requires logarithmic calculations) and produces virtually identical trees in practice.
- **Floating Point Stability**: Scikit-learn computes split midpoints using double precision to prevent numerical edge-case errors.
- **Unit Preservation**: Keeping data in original biological units (cm) ensures extracted text rules remain directly interpretable by subject-matter domain experts.

## Summary
Decision trees recursively partition feature space by selecting the feature and threshold that maximizes impurity reduction. Gini impurity measures node heterogeneity, dropping from 0.667 (equal mix) to 0.0 (pure node). The split `petal_length <= 2.45` isolates 38 *setosa* samples into an immaculate zero-impurity leaf. Because splits evaluate features independently, decision trees require no feature scaling.

## Knowledge-check Questions
1. What does a Gini impurity of 0.0 indicate about a decision tree node?
2. What is the mathematical formula for Gini impurity across $K$ classes?
3. What was the Gini impurity of the root node containing 38 setosa, 37 versicolor, and 37 virginica?
4. Why does changing measurements from centimeters to millimeters not alter a decision tree's structure?
5. Which scikit-learn criterion is the default in `DecisionTreeClassifier`?

## References
- Breiman, L., Friedman, J., Stone, C. J., & Olshen, R. A. (1984). *Classification and Regression Trees*. CRC Press.
- scikit-learn Decision Trees User Guide (https://scikit-learn.org/stable/modules/tree.html).
