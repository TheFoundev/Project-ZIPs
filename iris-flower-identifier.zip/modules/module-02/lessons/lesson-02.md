# Lesson 02: Feature Matrix X vs. Target Vector y: Slicing Tabular Data

**Lesson ID:** lesson-02
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain the fundamental mathematical distinction between feature matrix $X$ and target vector $y$
- Extract a subset of columns into a 2D DataFrame using column name lists
- Extract the 1D target Series using standard pandas bracket indexing
- Verify the structural shapes of $X$ and $y$ required by scikit-learn estimators

## Prerequisites
- Completion of Lesson 01 (Loading iris.csv)
- Basic understanding of 1D arrays vs. 2D matrices

## Concept Explanation
### The Supervised Learning Convention: X and y
In supervised machine learning, models learn a mathematical mapping:
$$f(X) pprox y$$
To enforce clear mathematical semantics, the Python community strictly observes naming conventions:
- **Capital $X$ (Feature Matrix)**: A 2-dimensional structure of shape `(n_samples, n_features)`. In linear algebra, matrices are denoted with capital letters. Here, $X$ has 150 rows and 4 columns.
- **Lowercase $y$ (Target Vector)**: A 1-dimensional structure of shape `(n_samples,)`. In linear algebra, vectors are denoted with lowercase letters. Here, $y$ has 150 elements.

```
       Feature Matrix X (150, 4)           Target Vector y (150,)
   sepal_len  sepal_wid  petal_len  petal_wid         species
0 [   5.1        3.5        1.4        0.2   ]  0 [  setosa      ]
1 [   4.9        3.0        1.4        0.2   ]  1 [  setosa      ]
2 [   4.7        3.2        1.3        0.2   ]  2 [  setosa      ]
...                                             ...
149 [ 5.9        3.0        5.1        1.8   ]  149 [ virginica   ]
```

### Slicing Features with Column Lists
In `main.py`, features are isolated using a predefined constant list:
```python
FEATURES = ["sepal_length", "sepal_width", "petal_length", "petal_width"]
X = df[FEATURES]
```
Passing a list of strings (`df[FEATURES]`) instructs pandas to return a **2D DataFrame** containing only those four named columns. If you mistakenly pass a single string without brackets (e.g., `df["sepal_length"]`), pandas returns a 1D Series, which violates scikit-learn's requirement for 2D feature inputs.

### Isolating the Target Vector
The target column is isolated with:
```python
y = df["species"]
```
Because there is only one target label per sample, single-bracket indexing extracts a **1D pandas Series**. Scikit-learn's `.fit()` method expects $y$ to have shape `(n_samples,)`, perfectly matching this 1D Series format.

## Relevant Code
In `main.py` (lines 26 and lines 31-32):
```python
FEATURES = ["sepal_length", "sepal_width", "petal_length", "petal_width"]

def main() -> None:
    df = pd.read_csv(DATA / "iris.csv")
    X = df[FEATURES]
    y = df["species"]
```

## Code Explanation
Line 26 defines `FEATURES` as a module-level constant. In line 31, `df[FEATURES]` filters the DataFrame, creating `X` with shape `(150, 4)`. In line 32, `df["species"]` extracts the target column into `y` with shape `(150,)`. Separating inputs from outputs is the foundational prerequisite before calling any train/test split or training algorithm.

## Worked Example
Let us examine the shapes and types programmatically:
```python
import pandas as pd

df = pd.read_csv("data/iris.csv")
FEATURES = ["sepal_length", "sepal_width", "petal_length", "petal_width"]

X = df[FEATURES]
y = df["species"]

print("Type of X:", type(X))
print("Shape of X:", X.shape)
print("Type of y:", type(y))
print("Shape of y:", y.shape)
```
Output:
```
Type of X: <class 'pandas.core.frame.DataFrame'>
Shape of X: (150, 4)
Type of y: <class 'pandas.core.series.Series'>
Shape of y: (150,)
```
The shapes match scikit-learn's expectations: 2D for features, 1D for target.

## Step-by-Step Student Instructions
1. Open terminal and start python.
2. Load the dataset and extract `X` and `y` using lines 26, 31, and 32 of `main.py`.
3. Check `X.ndim` and `y.ndim`: verify `X` has 2 dimensions and `y` has 1 dimension.
4. Attempt `df["species"].shape` and observe `(150,)`.
5. Check `X.columns.tolist()` to confirm all 4 feature names are present.

## Expected Output or Observable Behaviour
When checking dimensions:
```python
>>> X.ndim
2
>>> y.ndim
1
>>> X.shape
(150, 4)
>>> y.shape
(150,)
```
This confirms that the feature matrix and target vector are properly prepared for scikit-learn.

## Practical Exercises
- **Exercise 2.1**: What happens if you include `"species"` in the `FEATURES` list? Why would this ruin model evaluation? (The model would achieve 100% trivial accuracy by copying the answer from features, learning zero real patterns).
- **Exercise 2.2**: If you only wanted to train on petal measurements, how would you define `X_petals`?
- **Exercise 2.3**: Why is $X$ capitalized while $y$ is lowercase in standard machine learning code?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Solution |
|---|---|---|
| Target leakage | Accidentally leaving `species` inside `FEATURES` | Double check that `FEATURES` contains only the 4 numeric predictor variables. |
| Dimension mismatch | Creating $X$ as a 1D Series using `df["petal_length"]` | Use double brackets `df[["petal_length"]]` or a feature list `df[FEATURES]`. |
| Misspelling feature names | Typo like `"petal_lenght"` | Use exact column strings matching `df.columns`. |

## Best Practices and Security Considerations
- **Explicit Feature Lists**: Define features in an explicit list (`FEATURES = [...]`) rather than dropping columns (`df.drop(columns=["species"])`). Explicit lists prevent accidental inclusion of unvetted columns.
- **Leakage Prevention**: Always audit feature lists to ensure no future information or target proxies leak into input matrix $X$.
- **Type Uniformity**: Ensure all columns in $X$ are strictly numeric (`float` or `int`).

## Summary
In supervised learning, datasets are divided into a 2D feature matrix $X$ (`n_samples, n_features`) and a 1D target vector $y$ (`n_samples,`). In the Iris Flower Identifier, $X$ contains the 4 morphological measurements of shape `(150, 4)` and $y$ contains the categorical species strings of shape `(150,)`. Preserving these dimensional structures ensures seamless compatibility with scikit-learn.

## Knowledge-check Questions
1. Why is $X$ capitalized while $y$ is lowercase in machine learning conventions?
2. What are the dimensional shapes of $X$ and $y$ in this project?
3. How many dimensions does a pandas DataFrame have versus a pandas Series?
4. What is "target leakage" and how does isolating $X$ and $y$ correctly prevent it?
5. What error occurs if you pass a 1D array as the feature matrix to `DecisionTreeClassifier.fit()`?

## References
- scikit-learn API design principles (https://scikit-learn.org/stable/developers/develop.html).
- McKinney, W. (2022). *Python for Data Analysis*, 3rd Edition. O'Reilly Media. Chapter 5: Getting Started with pandas.
