# Lesson 04: Feature Discrimination: Why Petals Separate Species Far Better than Sepals

**Lesson ID:** lesson-04
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define "feature discrimination" and feature separability in classification problems
- Compare the variance and class separability of petal dimensions versus sepal dimensions
- Explain why *Iris setosa* is linearly separable using a single petal measurement
- Understand why decision trees naturally prioritize high-information features like `petal_length`

## Prerequisites
- Completion of Lessons 01, 02, and 03
- Familiarity with scatter plots and spatial clustering

## Concept Explanation
### What Makes a Feature "Discriminative"?
In machine learning, not all features provide equal predictive value:
- **Low-Discriminative Feature**: A feature whose values overlap heavily across different classes. Knowing this value gives little information about the true class.
- **High-Discriminative Feature**: A feature whose values cluster tightly within each class and show wide gaps between classes. Knowing this value allows an algorithm to make confident predictions with minimal error.

### Comparing Sepals and Petals
If we examine the mean measurements across the three species:

| Feature | *setosa* Mean | *versicolor* Mean | *virginica* Mean | Overlap Degree |
|---|---|---|---|---|
| `sepal_length` | 5.01 cm | 5.94 cm | 6.59 cm | Moderate overlap |
| `sepal_width` | 3.43 cm | 2.77 cm | 2.97 cm | Heavy overlap |
| `petal_length` | **1.46 cm** | **4.26 cm** | **5.55 cm** | **Minimal overlap** |
| `petal_width` | **0.25 cm** | **1.33 cm** | **2.03 cm** | **Minimal overlap** |

Notice that `sepal_width` for *versicolor* (2.77 cm) and *virginica* (2.97 cm) are nearly identical, with wide standard deviations that blend into each other.

In stark contrast, `petal_length` exhibits vast daylight between species:
- Every single *setosa* has `petal_length <= 1.9` cm.
- Every single *versicolor* has `petal_length >= 3.0` cm.
There is a massive 1.1 cm "empty gap" between *setosa* and all other species!

```
          Petal Length Distribution (cm)
          
  setosa       [ 1.0 - 1.9 ]
                    <--- GAP (1.1 cm) --->
  versicolor                               [ 3.0 --- 5.1 ]
  virginica                                     [ 4.5 ------ 6.9 ]
  +----+----+----+----+----+----+----+----+----+----+----+----+----+
  0    1    2    3    4    5    6    7    8
```

### The Linear Separability of Iris setosa
Because no *setosa* sample has a `petal_length` greater than 1.9 cm, and no *versicolor* or *virginica* sample has a `petal_length` less than 3.0 cm, *Iris setosa* is **linearly separable** from the other two classes. Any threshold chosen between 2.0 and 2.9 cm (such as 2.45 cm) achieves 100% classification accuracy for *setosa* in a single question.

### Why Decision Trees Love Petals
When a decision tree evaluates potential split points, it calculates the reduction in impurity (e.g., Gini impurity or entropy) for each candidate threshold across all 4 features. Because splitting on `petal_length` or `petal_width` creates virtually pure subsets immediately, the algorithm naturally selects petal measurements at the root node, often ignoring sepal measurements entirely.

## Relevant Code
In `main.py` (lines 55-56 and lines 95):
```python
print("\nLearned rules for the best tree:\n")
print(export_text(model, feature_names=FEATURES))
```
Output produced:
```
|--- petal_length <= 2.45
|   |--- class: setosa
|--- petal_length >  2.45
|   |--- petal_length <= 4.85
|   |   |--- class: versicolor
|   |--- petal_length >  4.85
|   |   |--- class: virginica
```

## Code Explanation
Notice that even though `main.py` provided all four features (`sepal_length`, `sepal_width`, `petal_length`, `petal_width`) to the training process, the optimal tree (`max_depth=2`) used **only `petal_length`** for both of its decision splits! The algorithm automatically determined that `petal_length` provided all the discriminative power required to reach 92.1% accuracy, rendering sepal measurements mathematically redundant at depth 2.

## Worked Example
Let us compute the min and max petal lengths for each species:
```python
import pandas as pd

df = pd.read_csv("data/iris.csv")
grouped = df.groupby("species")["petal_length"].agg(["min", "max", "mean"])
print(grouped)
```
Output:
```
             min  max   mean
species                     
setosa       1.0  1.9  1.462
versicolor   3.0  5.1  4.260
virginica    4.5  6.9  5.552
```
Between *setosa* max (1.9) and *versicolor* min (3.0), any threshold like 2.45 cm creates an infallible decision boundary.

## Step-by-Step Student Instructions
1. Run `python main.py` in your terminal.
2. Examine the printed decision rules.
3. Observe that both split thresholds (2.45 and 4.85) evaluate `petal_length`.
4. Run a quick groupby check in python to observe the sepal overlap:
   ```bash
   python -c "import pandas as pd; df=pd.read_csv('data/iris.csv'); print(df.groupby('species')['sepal_width'].agg(['min', 'max']))"
   ```
5. Confirm that sepal width ranges overlap heavily across all three species.

## Expected Output or Observable Behaviour
Checking sepal width shows:
```
            min  max
species             
setosa      2.3  4.4
versicolor  2.0  3.4
virginica   2.2  3.8
```
All three species span the 2.3 to 3.4 range, proving why `sepal_width` is a poor individual discriminator.

## Practical Exercises
- **Exercise 4.1**: Which single feature provides the greatest visual separation between all three species?
- **Exercise 4.2**: What is the threshold value chosen by the decision tree in `main.py` to isolate *setosa*?
- **Exercise 4.3**: Why is `sepal_width` never used by the optimal decision tree at `max_depth=2`?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Solution |
|---|---|---|
| Assuming all features are equally useful | Treating all tabular columns identically | Conduct exploratory feature analysis; remove or de-prioritize noisy, uninformative features. |
| Forcing models to use every feature | Believing more features always equals better models | Trust decision trees to select high-gain features and prune irrelevant inputs. |
| Ignoring feature overlap | Assuming classes never overlap in real biology | Recognize that natural variation causes overlap between related species (*versicolor* vs *virginica*). |

## Best Practices and Security Considerations
- **Feature Selection**: Prioritize features with high signal-to-noise ratios. Fewer, higher-quality features produce simpler, more robust, and more interpretable models.
- **Dimensionality Reduction**: In high-dimensional datasets, understanding feature discriminative power helps eliminate redundant features and reduce compute costs.
- **Fairness & Proxies**: In real-world data, ensure high-discriminative features are not subtle proxies for sensitive or legally protected categories.

## Summary
Feature discrimination measures how effectively an attribute separates distinct target classes. In the Iris dataset, petal dimensions (`petal_length` and `petal_width`) offer vastly superior discriminative power compared to sepal dimensions. *Iris setosa* is completely linearly separable using `petal_length <= 2.45 cm`. Consequently, scikit-learn's decision tree automatically prioritizes petal length, achieving 92.1% test accuracy without needing sepal measurements.

## Knowledge-check Questions
1. What does it mean for a feature to be "discriminative"?
2. Which feature provides the cleanest separation between *Iris setosa* and the other two species?
3. What is the numerical threshold used in `main.py` to isolate *setosa*?
4. Why does `sepal_width` perform poorly as an individual species classifier?
5. How does a decision tree algorithm automatically determine which features to split on?

## References
- scikit-learn Feature importances documentation (https://scikit-learn.org/stable/modules/ensemble.html#feature-importance-evaluation).
- Fisher, R. A. (1936). *The use of multiple measurements in taxonomic problems*. Annals of Eugenics.
