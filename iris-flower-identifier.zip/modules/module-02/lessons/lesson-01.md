# Lesson 01: Loading iris.csv and Exploratory Data Inspection with pandas

**Lesson ID:** lesson-01
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Use `pandas.read_csv()` to ingest `data/iris.csv` into a DataFrame
- Inspect DataFrame dimensions using `.shape` and verify column headers
- Check for missing values (`NaN`) and data types with `.info()`
- Compute summary statistics (mean, std, min, max, quartiles) using `.describe()`

## Prerequisites
- Completion of Module 01
- Basic understanding of Python file paths and tabular data

## Concept Explanation
### Ingesting Tabular Data with pandas
In modern Python data science, `pandas` is the primary library for data wrangling. When working with tabular comma-separated values (`.csv`), `pd.read_csv()` reads the file from disk, parses the header row into column labels, converts numeric text entries into 64-bit floating point numbers, and loads everything into a 2-dimensional `DataFrame`.

In `main.py`, the file path is constructed cleanly using Python's standard `pathlib.Path`:
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
df = pd.read_csv(DATA / "iris.csv")
```
Using `pathlib` guarantees that regardless of where the terminal command is executed, the script resolves the relative path to `data/iris.csv` accurately without path errors.

### Verifying Data Sanity: Shape, Types, and Nulls
Before feeding raw data into machine learning algorithms, every competent engineer conducts an exploratory data audit:
1. **Dimensions (`df.shape`)**: The Iris dataset contains exactly 150 rows and 5 columns: `(150, 5)`.
2. **Missing Values (`df.isnull().sum()`)**: The historical Iris dataset is pristine; it contains 0 missing values. If missing values were present, scikit-learn estimators would throw a runtime `ValueError`.
3. **Data Types (`df.dtypes`)**: The 4 measurements (`sepal_length`, `sepal_width`, `petal_length`, `petal_width`) must be `float64`, while the target column `species` is `object` (string).

### Summary Statistics
Calling `df.describe()` yields summary statistics across the 150 observations:
- `sepal_length`: Mean 5.84 cm (range: 4.3 to 7.9 cm)
- `sepal_width`: Mean 3.06 cm (range: 2.0 to 4.4 cm)
- `petal_length`: Mean 3.76 cm (range: 1.0 to 6.9 cm)
- `petal_width`: Mean 1.20 cm (range: 0.1 to 2.5 cm)

Notice the wide spread in `petal_length` (1.0 to 6.9 cm, standard deviation 1.76 cm) compared to `sepal_width` (standard deviation 0.44 cm). This hints that petal dimensions provide greater variation across species.

## Relevant Code
In `main.py` (lines 21-22 and line 30):
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"

def main() -> None:
    df = pd.read_csv(DATA / "iris.csv")
```

## Code Explanation
Line 21 establishes `BASE` as an absolute `Path` object pointing to the directory containing `main.py`. Line 22 creates `DATA` using the slash operator `/`. In line 30, `pd.read_csv(DATA / "iris.csv")` loads the CSV file into DataFrame `df`. This ensures cross-platform compatibility across Linux, macOS, and Windows.

## Worked Example
Suppose an engineer writes a quick inspection script `inspect_iris.py`:
```python
import pandas as pd
from pathlib import Path

DATA = Path("data")
df = pd.read_csv(DATA / "iris.csv")

print("Dataset Shape:", df.shape)
print("\nMissing values per column:\n", df.isnull().sum())
print("\nSpecies distribution:\n", df["species"].value_counts())
```
Output:
```
Dataset Shape: (150, 5)

Missing values per column:
sepal_length    0
sepal_width     0
petal_length    0
petal_width     0
species         0
dtype: int64

Species distribution:
setosa        50
versicolor    50
virginica     50
Name: species, dtype: int64
```
This demonstrates that the data is clean, complete, and perfectly balanced.

## Step-by-Step Student Instructions
1. Open a terminal in the project directory.
2. Launch Python interactive mode or run a one-line command:
   ```bash
   python -c "import pandas as pd; df=pd.read_csv('data/iris.csv'); print(df.info())"
   ```
3. Verify that 150 non-null entries exist for each of the 5 columns.
4. Run `df.describe()` to see the mean and standard deviation for each feature.

## Expected Output or Observable Behaviour
The command outputs:
```
<class 'pandas.core.frame.DataFrame'>
RangeIndex: 150 entries, 0 to 149
Data columns (total 5 columns):
 #   Column        Non-Null Count  Dtype  
---  ------        --------------  -----  
 0   sepal_length  150 non-null    float64
 1   sepal_width   150 non-null    float64
 2   petal_length  150 non-null    float64
 3   petal_width   150 non-null    float64
 4   species       150 non-null    object 
dtypes: float64(4), object(1)
memory usage: 6.0+ KB
```
This confirms proper data ingestion with zero missing values.

## Practical Exercises
- **Exercise 1.1**: What is the output of `len(df)`?
- **Exercise 1.2**: Write the pandas command to check the minimum value of `petal_width` across all flowers.
- **Exercise 1.3**: Why is it advantageous to use `pathlib.Path` over simple string paths like `"data/iris.csv"`?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Solution |
|---|---|---|
| `FileNotFoundError` | Running the script from a different folder than the project root | Use `Path(__file__).resolve().parent` to anchor paths to the script location. |
| Forgetting `import pandas as pd` | Missing package import | Ensure pandas is imported before calling `pd.read_csv()`. |
| Assuming index column is a feature | Confusing row numbers (0-149) with measurements | Pandas adds an integer RangeIndex automatically; do not include it as a feature. |

## Best Practices and Security Considerations
- **Path Resolution**: Never hardcode machine-specific paths like `/home/user/...`. Always use relative paths anchored by `pathlib.Path(__file__)`.
- **Pre-flight Data Audits**: Always verify `.isnull().sum()` and `.shape` before initiating training to prevent silent algorithmic corruption.
- **Memory Efficiency**: While 150 rows consume negligible memory (<10 KB), larger datasets should be inspected with `df.info(memory_usage='deep')`.

## Summary
Ingesting `data/iris.csv` with `pandas.read_csv()` converts raw text into a 150x5 DataFrame. Exploratory auditing confirms 150 records, 4 continuous `float64` features, 1 `object` target column, and zero missing values. Robust path handling with `pathlib.Path` prevents `FileNotFoundError` across different operating systems and execution directories.

## Knowledge-check Questions
1. What does the tuple returned by `df.shape` represent?
2. How many total columns are in `iris.csv`, and how many are numerical features?
3. Which pandas method provides summary statistics like mean, standard deviation, and quartiles?
4. What happens if a dataset contains missing values when passed to `DecisionTreeClassifier.fit()`?
5. Why is `pathlib.Path(__file__).resolve().parent` superior to hardcoding string paths?

## References
- pandas read_csv documentation (https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html).
- Python pathlib documentation (https://docs.python.org/3/library/pathlib.html).
