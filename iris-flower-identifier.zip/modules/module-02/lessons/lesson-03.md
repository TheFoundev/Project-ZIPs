# Lesson 03: Stratified Train-Test Splitting: Preserving Class Distributions with stratify=y

**Lesson ID:** lesson-03
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why datasets must be split into training and testing partitions
- Define `test_size=0.25` and calculate the resulting sample counts (112 train, 38 test)
- Explain the role of `random_state=42` in ensuring scientific reproducibility
- Explain the critical purpose of `stratify=y` in maintaining identical class proportions across splits

## Prerequisites
- Completion of Lesson 01 and Lesson 02
- Basic understanding of random sampling and ratios

## Concept Explanation
### The Golden Rule of Machine Learning: Never Test on Training Data
If you train a student on a specific set of exam questions and test them on those exact same questions, their score reflects **memorization**, not **understanding**. In machine learning, evaluating a model on the data it trained on is catastrophic: complex models will memorize noise and achieve 100% training accuracy, while failing completely when deployed on new real-world data.

To measure true **generalization**, we partition data into two non-overlapping subsets:
1. **Training Set (`X_train, y_train`)**: Used exclusively by the model during the `.fit()` phase to learn patterns.
2. **Testing Set (`X_test, y_test`)**: Held out in strict isolation. Used only during evaluation (`.predict()`) to measure how well the model generalizes to unseen observations.

### Quantifying the Split: test_size=0.25
In `main.py`, the split is configured as:
```python
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)
```
- Total dataset size: 150 rows
- Test proportion: $150 	imes 0.25 = 37.5 ightarrow 38$ samples
- Training proportion: $150 - 38 = 112$ samples
- Split ratio: 74.67% training, 25.33% testing.

### Why random_state=42?
Computer random number generators are pseudorandom; they compute deterministic sequences from an initial seed value. Specifying `random_state=42` ensures that every student, researcher, or automated test script will partition the exact same rows into the training set and testing set. This reproducibility is vital for debugging and comparing model benchmarks.

### The Power of Stratification: stratify=y
What happens during simple random sampling without stratification? You could randomly draw an unrepresentative test split—for instance, 20 *setosa*, 15 *versicolor*, and only 3 *virginica*. An evaluation on such a skewed test set would yield distorted accuracy metrics.

By passing `stratify=y`, scikit-learn uses **stratified sampling**:
- Total set: 50 *setosa*, 50 *versicolor*, 50 *virginica* (Ratio 1:1:1)
- Training set (112 samples): 38 *setosa*, 37 *versicolor*, 37 *virginica*
- Test set (38 samples): 12 *setosa*, 13 *versicolor*, 13 *virginica*

Both partitions preserve the exact balanced distribution of the original dataset.

## Relevant Code
In `main.py` (lines 34-36):
```python
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
```

## Code Explanation
`train_test_split` is imported from `sklearn.model_selection`. It accepts feature matrix `X` and target vector `y`, shuffles the indices according to `random_state=42`, stratifies according to class labels in `y`, and unpacks into four variables: `X_train`, `X_test`, `y_train`, and `y_test`.

## Worked Example
Let us verify the exact class counts in both partitions:
```python
import pandas as pd
from sklearn.model_selection import train_test_split

df = pd.read_csv("data/iris.csv")
X = df[["sepal_length", "sepal_width", "petal_length", "petal_width"]]
y = df["species"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

print("Training Class Counts:\n", y_train.value_counts())
print("\nTesting Class Counts:\n", y_test.value_counts())
```
Output:
```
Training Class Counts:
setosa        38
versicolor    37
virginica     37
Name: species, dtype: int64

Testing Class Counts:
versicolor    13
virginica     13
setosa        12
Name: species, dtype: int64
```
Because 50 cannot be split into exact 75%/25% integers (50 * 0.25 = 12.5), scikit-learn balances the partitions as closely as mathematically possible: 12, 13, and 13 in the test set.

## Step-by-Step Student Instructions
1. Run a quick script to inspect the shapes of `X_train` and `X_test`.
2. Verify `X_train.shape` is `(112, 4)`.
3. Verify `X_test.shape` is `(38, 4)`.
4. Run `y_test.value_counts()` and confirm the test set contains 12 setosa, 13 versicolor, and 13 virginica.

## Expected Output or Observable Behaviour
Verifying shapes and counts confirms:
- Total samples = 112 + 38 = 150
- Features preserved = 4 columns
- Balanced target representation in both sets

## Practical Exercises
- **Exercise 3.1**: What would the test set size be if `test_size=0.20` was used instead of 0.25? (150 * 0.20 = 30 samples).
- **Exercise 3.2**: Explain why omitting `stratify=y` is especially dangerous in small or imbalanced datasets.
- **Exercise 3.3**: Why must `random_state` be fixed when benchmarking different machine learning models against each other?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Solution |
|---|---|---|
| Omitting `stratify=y` | Forgetting the parameter | Always pass `stratify=y` in classification problems to avoid sampling bias. |
| Inverting unpack order | Typing `X_train, y_train, X_test, y_test` | Remember the order: `X_train, X_test, y_train, y_test`. |
| Evaluating on training set | Calling `model.predict(X_train)` for reporting | Always evaluate test generalization on `X_test` and `y_test`. |

## Best Practices and Security Considerations
- **Data Leakage Hygiene**: Never perform scaling, imputation, or feature engineering on the combined dataset prior to splitting. Always fit preprocessors on `X_train` only.
- **Seed Transparency**: Document `random_state` explicitly in production code for auditability.
- **Stratification Default**: Make stratified splitting your standard default practice for any classification task.

## Summary
`train_test_split` partitions the 150 Iris observations into 112 training samples and 38 testing samples (`test_size=0.25`). Using `random_state=42` ensures perfect reproducibility, while `stratify=y` guarantees that both splits maintain equal representation across *setosa*, *versicolor*, and *virginica*. Isolating the test set prevents data leakage and ensures unbiased evaluation of model generalization.

## Knowledge-check Questions
1. Why must machine learning models be evaluated on a holdout test set rather than the training set?
2. How many samples are in the training set and test set in this project?
3. What is the role of `random_state=42`?
4. What problem does `stratify=y` solve in multi-class classification?
5. How many samples of each species appear in the 38-sample test set?

## References
- scikit-learn train_test_split documentation (https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html).
- Kohavi, R. (1995). *A study of cross-validation and bootstrap for accuracy estimation and model selection*. IJCAI.
