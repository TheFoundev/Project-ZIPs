# Module 2 Exercises: Data Loading, Feature Inspection & Stratification

## Exercise 2.1: CSV Inspection and Dimensional Audit (10 min)
**Objective:** Load and verify the structural characteristics of `data/iris.csv`.
**Problem Statement:** You are initializing a machine learning pipeline and must verify that the dataset matches expected data integrity standards.

**Requirements:**
1. Load `data/iris.csv` into a DataFrame named `df`.
2. Print the shape of `df` and confirm the exact number of rows and columns.
3. Verify that there are zero missing values across all columns.
4. Print the memory usage of the DataFrame.

**Constraints:** Use pandas and `pathlib.Path`.

**Expected Behaviour:** A short script or interactive terminal session printing shape, null counts, and memory usage.

**Acceptance Criteria:**
- [ ] Shape verified as `(150, 5)`
- [ ] All 5 columns show 0 null values
- [ ] 4 numerical columns identified as `float64`, target as `object`
- [ ] Script uses `pathlib.Path` to locate `data/iris.csv`

**Hints:**
- Use `df.shape`, `df.isnull().sum()`, and `df.info()`.

**Difficulty:** Basic
**Estimated Completion Time:** 10 minutes

---

## Exercise 2.2: Feature/Target Separation and Dimension Checking (10 min)
**Objective:** Separate features ($X$) and target ($y$) with correct dimensional shapes.
**Problem Statement:** Implement lines 26, 31, and 32 of `main.py` and programmatically verify that $X$ and $y$ satisfy scikit-learn shape requirements.

**Requirements:**
1. Define `FEATURES = ["sepal_length", "sepal_width", "petal_length", "petal_width"]`.
2. Extract $X$ as `df[FEATURES]` and $y$ as `df["species"]`.
3. Assert that `X.shape == (150, 4)` and `y.shape == (150,)`.
4. Assert that `X.ndim == 2` and `y.ndim == 1`.

**Constraints:** Follow the exact variable naming in `main.py`.

**Expected Behaviour:** Python code verifying shapes and assertions without throwing `AssertionError`.

**Acceptance Criteria:**
- [ ] `X` extracted as 2D DataFrame with shape `(150, 4)`
- [ ] `y` extracted as 1D Series with shape `(150,)`
- [ ] Both assertions pass cleanly
- [ ] Clear explanation of why $X$ must be 2D for scikit-learn

**Hints:**
- Use Python's built-in `assert` statement.
- Check `X.ndim` and `y.ndim`.

**Difficulty:** Basic
**Estimated Completion Time:** 10 minutes

---

## Exercise 2.3: Stratified Partitioning Validation (15 min)
**Objective:** Prove that `stratify=y` preserves class balance across training and testing sets.
**Problem Statement:** Perform a train/test split on the Iris dataset with and without `stratify=y` and compare the class proportions in the test set.

**Requirements:**
1. Split using `train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)`.
2. Count the occurrences of each species in `y_test`.
3. Verify that `y_test` contains 12 setosa, 13 versicolor, and 13 virginica.
4. Calculate the percentage of each species in `y_test` (should be ~31.6% setosa, 34.2% versicolor, 34.2% virginica).

**Constraints:** Use `random_state=42` and `test_size=0.25`.

**Expected Behaviour:** Terminal output displaying the exact value counts for `y_test`.

**Acceptance Criteria:**
- [ ] Test set total size is 38
- [ ] Class counts match: `setosa: 12`, `versicolor: 13`, `virginica: 13`
- [ ] Written explanation of why 50 cannot be split into exact 25% integer counts

**Hints:**
- Use `y_test.value_counts()`.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 2.4: Feature Discrimination Analysis (15 min)
**Objective:** Calculate the separability gap between species for petal length versus sepal width.
**Problem Statement:** Prove mathematically why the decision tree split on `petal_length` rather than `sepal_width`.

**Requirements:**
1. For `petal_length`: find maximum value for *setosa* and minimum value for *versicolor*.
2. Calculate the difference (gap = min_versicolor - max_setosa).
3. For `sepal_width`: find minimum and maximum values for *setosa*, *versicolor*, and *virginica*.
4. Determine whether an overlap exists in `sepal_width`.
5. Conclude why `petal_length` allows a clean binary split while `sepal_width` does not.

**Constraints:** Calculate metrics directly using pandas groupby operations on `df`.

**Expected Behaviour:** A written comparative analysis supported by numerical ranges from the data.

**Acceptance Criteria:**
- [ ] Correctly identifies *setosa* max petal length is 1.9 cm
- [ ] Correctly identifies *versicolor* min petal length is 3.0 cm
- [ ] Computes positive separation gap of 1.1 cm for petal length
- [ ] Demonstrates heavy range overlap in sepal width (ranges 2.0 to 4.4 cm overlap across species)
- [ ] Concludes that petal length enables 100% pure initial separation for setosa

**Hints:**
- Use `df.groupby("species")["petal_length"].agg(["min", "max"])`.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes
