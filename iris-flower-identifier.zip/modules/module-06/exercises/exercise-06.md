# Module 6 Exercises: Running, Flower Prediction & ML Generalization

## Exercise 6.1: Full Pipeline Verification and Output Auditing (15 min)
**Objective:** Execute `main.py` end-to-end and audit the generated artifacts.
**Problem Statement:** You have completed the educational modules and must verify that the full implementation runs cleanly and produces all expected outputs.

**Requirements:**
1. Navigate to the project root and execute `python main.py`.
2. Verify that the exit status code is 0.
3. Check that `outputs/iris_tree.png` exists and is greater than 50 KB.
4. Check that `outputs/confusion_matrix.png` exists.
5. Check that `outputs/rules.txt` exists and contains 25 lines.

**Constraints:** Run in the terminal without modifying `main.py`.

**Expected Behaviour:** Terminal script verifying exit code and file sizes.

**Acceptance Criteria:**
- [ ] `main.py` exits with status 0
- [ ] All 3 files present in `outputs/`
- [ ] Console output matches expected benchmark accuracies
- [ ] `new_flower` correctly prints `versicolor`

**Hints:**
- Use `python main.py && ls -la outputs/`.

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 6.2: Custom Botanical Prediction Lab (15 min)
**Objective:** Write an inference script to classify three custom flower observations.
**Problem Statement:** A greenhouse manager sends you caliper measurements for three mystery flowers and wants automated species predictions and confidence scores.

**Requirements:**
1. Mystery Flower 1: `sepal_length=4.9, sepal_width=3.1, petal_length=1.5, petal_width=0.1`
2. Mystery Flower 2: `sepal_length=6.3, sepal_width=3.3, petal_length=4.7, petal_width=1.6`
3. Mystery Flower 3: `sepal_length=7.7, sepal_width=3.8, petal_length=6.7, petal_width=2.2`
4. Construct a 3-row pandas DataFrame containing all three flowers.
5. Train `DecisionTreeClassifier(max_depth=2, random_state=42)` and call `model.predict()` and `model.predict_proba()`.
6. Print the predicted species and confidence percentage for each flower.

**Constraints:** Input DataFrame columns must match `FEATURES`.

**Expected Behaviour:** Formatted output displaying species and confidence for all 3 flowers.

**Acceptance Criteria:**
- [ ] Flower 1 predicted as `setosa` with 100.0% confidence
- [ ] Flower 2 predicted as `versicolor` with 97.2% confidence
- [ ] Flower 3 predicted as `virginica` with 94.7% confidence
- [ ] Input constructed as a valid 3-row DataFrame

**Hints:**
- Look at how `new_flower` was created in `main.py` line 59.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 6.3: Comparing Single Trees with Random Forests (15 min)
**Objective:** Implement a Random Forest classifier and compare test accuracy.
**Problem Statement:** Test whether an ensemble of 100 trees outperforms our single decision tree on the holdout test set.

**Requirements:**
1. Import `RandomForestClassifier` from `sklearn.ensemble`.
2. Instantiate `RandomForestClassifier(n_estimators=100, random_state=42)`.
3. Train on `X_train, y_train`.
4. Predict on `X_test` and calculate `accuracy_score`.
5. Compare the Random Forest test accuracy with the decision tree's 92.1%.
6. Extract and print `rf.feature_importances_` across all 4 features.

**Constraints:** Use identical train/test splits (`test_size=0.25, random_state=42, stratify=y`).

**Expected Behaviour:** Python script outputting test accuracy and feature importances.

**Acceptance Criteria:**
- [ ] Random Forest test accuracy computed (typically 92.1% to 94.7%)
- [ ] Feature importances show petal length and petal width dominating (>80% combined)
- [ ] Written reflection on why ensembles reduce prediction variance

**Hints:**
- Use `rf = RandomForestClassifier(n_estimators=100, random_state=42)`.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 6.4: Synthesis Report: The Bias-Variance Tradeoff (15 min)
**Objective:** Write an architectural post-mortem explaining the bias-variance tradeoff in this project.
**Problem Statement:** Prepare a 1-page summary explaining why depth-2 defeated depth-None to present to engineering leadership.

**Requirements:**
1. Define Bias and Variance in the context of decision trees.
2. Explain the training and test metrics observed for `max_depth=2`, `max_depth=3`, and `max_depth=None`.
3. Explain why `max_depth=None` suffered from high variance.
4. Explain how tree depth constraints act as regularization.
5. Provide actionable recommendations for deploying decision trees in production.

**Constraints:** Ground all arguments in empirical data from `main.py`.

**Expected Behaviour:** A structured markdown report answering all 5 points.

**Acceptance Criteria:**
- [ ] Accurate definitions of bias (underfitting) and variance (overfitting)
- [ ] Cites exact empirical numbers (Train 100% vs Test 89.5% for None; Train 95.5% vs Test 92.1% for 2)
- [ ] Explains that constraining depth prunes noisy splits and preserves generalization
- [ ] Cites Occam's Razor

**Hints:**
- Review Lesson 03 of Module 06.

**Difficulty:** Advanced
**Estimated Completion Time:** 15 minutes
