# Lesson 01: Executing the Full Pipeline and Managing File Outputs

**Lesson ID:** lesson-01
**Module:** module-06
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Execute `main.py` from the command line and monitor its step-by-step console stream
- Verify the creation and integrity of all three output files in `outputs/`
- Explain the role of headless rendering with `matplotlib.use("Agg")` in automated execution
- Trace the lifecycle of data from CSV ingestion through model persistence

## Prerequisites
- Completion of Modules 01 through 05
- Familiarity with shell commands (`cd`, `python`, `ls`)

## Concept Explanation
### The Complete End-to-End Execution Flow
In `main.py`, the entire data science lifecycle is orchestrated in approximately 100 lines of clean, modular Python. When you execute `python main.py`, the interpreter performs a sequence of synchronized operations:
1. **Module Import & Headless Setup**: Loads libraries and configures Matplotlib's Agg backend.
2. **Filesystem Preparation**: Anchors relative paths to the script's directory and ensures `outputs/` exists.
3. **Data Ingestion**: Reads `data/iris.csv` into memory.
4. **Feature & Target Separation**: Slices $X$ and $y$.
5. **Stratified Partitioning**: Divides data into 112 training samples and 38 testing samples.
6. **Hyperparameter Grid Loop**: Fits and scores three trees (depths 2, 3, and None).
7. **Best Model Selection**: Dynamically identifies `max_depth=2` as the winner.
8. **Rule Extraction**: Formats ASCII rules with `export_text`.
9. **Evaluation Reporting**: Computes multi-class precision, recall, and F1 metrics.
10. **Novel Inference**: Classifies the unobserved specimen `new_flower` as `versicolor`.
11. **Visual Plotting**: Generates and saves `iris_tree.png` and `confusion_matrix.png`.
12. **Text Documentation**: Persists all benchmark results and rules to `rules.txt`.

```
                    The Iris Identifier Execution Pipeline
                    
  [data/iris.csv] ---> [pandas DataFrame] ---> [train_test_split (stratify=y)]
                                                        |
                         +------------------------------+
                         |
                         v
              [Loop: depths 2, 3, None]
                         |
                         v
               [Select Best: depth 2]
                         |
       +-----------------+-----------------+
       |                 |                 |
       v                 v                 v
[export_text]     [new_flower]    [plot_tree & confusion_matrix]
       |                 |                 |
       +-----------------+-----------------+
                         |
                         v
            [outputs/iris_tree.png]
            [outputs/confusion_matrix.png]
            [outputs/rules.txt]
```

### Headless Environments: Why matplotlib.use("Agg") Matters
In cloud containers, headless Docker environments, continuous integration (CI) runners, and remote SSH terminal sessions, there is no graphical monitor or X11 window server. If a script attempts to open an interactive GUI window via `plt.show()`, the process crashes with a `TclError: no display name and no $DISPLAY environment variable`.

Calling `matplotlib.use("Agg")` instructs Matplotlib to write raster pixel arrays directly into PNG files on disk using the Anti-Grain Geometry (Agg) rendering engine, requiring zero GUI hardware.

## Relevant Code
In `main.py` (lines 12-15 and lines 99-100):
```python
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ... execution steps ...

    print("\nSaved: outputs/iris_tree.png, outputs/confusion_matrix.png, outputs/rules.txt")
    print("Try this: set max_depth=2 and compare the simpler tree with the deeper one.")
```

## Code Explanation
Line 14 configures the Agg backend prior to importing `pyplot` on line 15. At the conclusion of `main()`, lines 99-100 print a clear confirmation message listing all three saved artifacts, assuring the user that the pipeline executed to 100% completion without silent errors.

## Worked Example
Let us run the script from the command line and verify the exit code:
```bash
python main.py
echo "Exit Code: $?"
```
Terminal Output:
```
============================================================
THE IRIS FLOWER IDENTIFIER
============================================================
Comparing tree depths:

  max_depth=2         accuracy=92.1%
  max_depth=3         accuracy=89.5%
  max_depth=unlimited accuracy=89.5%

Best tree: max_depth=2

Learned rules for the best tree:

|--- petal_length <= 2.45
|   |--- class: setosa
|--- petal_length >  2.45
|   |--- petal_length <= 4.85
|   |   |--- class: versicolor
|   |--- petal_length >  4.85
|   |   |--- class: virginica

              precision    recall  f1-score   support

      setosa       1.00      1.00      1.00        12
  versicolor       0.86      0.92      0.89        13
   virginica       0.92      0.85      0.88        13

    accuracy                           0.92        38
   macro avg       0.92      0.92      0.92        38
weighted avg       0.92      0.92      0.92        38

New flower -> versicolor

Saved: outputs/iris_tree.png, outputs/confusion_matrix.png, outputs/rules.txt
Try this: set max_depth=2 and compare the simpler tree with the deeper one.
Exit Code: 0
```
An exit code of `0` indicates flawless execution.

## Step-by-Step Student Instructions
1. Open your terminal and navigate to the project root directory.
2. Run `python main.py`.
3. Check the file modification timestamps:
   ```bash
   ls -lt outputs/
   ```
4. Verify that all three files (`iris_tree.png`, `confusion_matrix.png`, `rules.txt`) show current timestamps.
5. Verify that `iris_tree.png` has a non-zero file size (> 50 KB).

## Expected Output or Observable Behaviour
Listing the output directory shows:
```
-rw-r--r-- 1 user group 145230 Oct 27 12:00 iris_tree.png
-rw-r--r-- 1 user group  32450 Oct 27 12:00 confusion_matrix.png
-rw-r--r-- 1 user group    720 Oct 27 12:00 rules.txt
```
All three files were created cleanly.

## Practical Exercises
- **Exercise 1.1**: What happens if you delete the `outputs/` directory and run `python main.py`? (The script creates `outputs/` automatically using `OUT.mkdir(exist_ok=True)`).
- **Exercise 1.2**: Why is `matplotlib.use("Agg")` critical for running machine learning code in Docker or cloud servers?
- **Exercise 1.3**: How long did `main.py` take to execute? (Typically under 1 second).

## Common Mistakes and Debugging
| Mistake | Why It Happens | Solution |
|---|---|---|
| `TclError: no display name` | Omitting `matplotlib.use("Agg")` in headless environments | Set backend to `"Agg"` before importing `pyplot`. |
| Script fails on repeated runs | Missing `exist_ok=True` on `mkdir()` | Use `Path.mkdir(exist_ok=True)` so existing directories do not raise errors. |
| Looking for outputs in wrong folder | Running `python main.py` from a different working directory | Paths anchored with `Path(__file__).resolve().parent` always write to the correct project folder. |

## Best Practices and Security Considerations
- **Non-Interactive Defaults**: Build production machine learning code to execute headlessly by default, saving visual outputs to disk rather than popping up windows.
- **Graceful Directory Handling**: Always use `exist_ok=True` when creating output and cache directories.
- **Exit Codes**: Ensure pipelines terminate with status code 0 on success and non-zero codes on error to facilitate CI/CD alerting.

## Summary
Executing `main.py` orchestrates the complete machine learning workflow from raw CSV ingestion to model evaluation and visualization. Configuring Matplotlib's Agg backend ensures seamless execution across headless cloud runners. Verifying file timestamps confirms that `iris_tree.png`, `confusion_matrix.png`, and `rules.txt` were produced accurately and reproducibly.

## Knowledge-check Questions
1. What three output files are created in the `outputs/` directory by `main.py`?
2. What error occurs if `matplotlib.use("Agg")` is omitted in a headless server environment?
3. What method ensures directory creation does not fail if the directory already exists?
4. What exit status code indicates successful script termination in Linux/Unix?
5. Approximately how many seconds does the complete pipeline take to execute?

## References
- Matplotlib Backends guide (https://matplotlib.org/stable/users/explain/backends.html).
- Python standard library subprocess and exit codes (https://docs.python.org/3/library/sys.html#sys.exit).
