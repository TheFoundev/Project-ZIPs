# Lesson 02: Real-Time Flower Inference: The new_flower Prediction Workflow

**Lesson ID:** lesson-02
**Module:** module-06
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Construct well-formed input DataFrames for real-time model inference
- Execute `model.predict()` on novel, unobserved feature measurements
- Extract predicted class labels and probability vectors
- Design a reusable inference helper function for production deployment

## Prerequisites
- Completion of Module 04 (Inference Tracing) and Lesson 01
- Basic understanding of Python dictionaries and pandas DataFrames

## Concept Explanation
### Moving from Training to Serving
In machine learning engineering, building and training a model is only the first half of the journey. The ultimate goal is **serving**: taking real-world inputs from users, sensors, or mobile cameras and delivering instantaneous, accurate classifications.

In `main.py`, lines 59-63 simulate this production inference workflow:
```python
new_flower = pd.DataFrame(
    [{"sepal_length": 5.8, "sepal_width": 2.7, "petal_length": 4.1, "petal_width": 1.0}]
)
new_species = model.predict(new_flower)[0]
print(f"New flower -> {new_species}")
```

```
               Real-Time Prediction Pipeline
               
  [User Caliper Measurements]
    sepal_length: 5.8 cm
    sepal_width:  2.7 cm
    petal_length: 4.1 cm
    petal_width:  1.0 cm
             |
             v
  [pandas DataFrame: (1, 4)]
             |
             v
  [model.predict()]  ---> [Decision Tree Nodes]
                                   |
             +---------------------+
             |
             v
  Predicted Label: "versicolor"
  Confidence:      97.2%
```

### Anatomy of an Inference Request
Notice three crucial technical details about `new_flower`:
1. **Column Name Consistency**: The keys in the dictionary (`"sepal_length"`, `"sepal_width"`, etc.) match the exact names and casing defined in `FEATURES`.
2. **Tabular 2D Shape**: Even though we are classifying only a single flower, the input must be formatted as a 2D tabular structure (shape `(1, 4)`). Scikit-learn estimators are designed for batch processing and reject raw 1D scalar lists.
3. **Data Types**: All measurements are continuous numeric floats (`float64`).

### Extracting Probabilities with predict_proba
While `.predict()` returns the discrete winning class string (`'versicolor'`), calling `.predict_proba()` returns the probability distribution across all three classes:
```python
probabilities = model.predict_proba(new_flower)[0]
# probabilities -> [0.0, 0.9722, 0.0278]
```
Mapping these numbers to `model.classes_`:
- $P(	ext{setosa}) = 0.0\%$
- $P(	ext{versicolor}) = 97.2\%$
- $P(	ext{virginica}) = 2.8\%$

This allows a production system to provide both the answer and an associated **confidence score** to end users.

## Relevant Code
In `main.py` (lines 59-63):
```python
    new_flower = pd.DataFrame(
        [{"sepal_length": 5.8, "sepal_width": 2.7, "petal_length": 4.1, "petal_width": 1.0}]
    )
    new_species = model.predict(new_flower)[0]
    print(f"New flower -> {new_species}")
```

## Code Explanation
Line 59 instantiates a DataFrame from a list of one dictionary. Line 62 passes this DataFrame to `model.predict()`, which evaluates the tree splits and returns an array of length 1: `array(['versicolor'], dtype=object)`. The `[0]` index unwraps the array into the Python string `'versicolor'`. Line 63 prints the prediction.

## Worked Example
Let us build a general-purpose prediction helper function suitable for a web application API:
```python
import pandas as pd

def predict_iris_species(model, sepal_len: float, sepal_wid: float, petal_len: float, petal_wid: float) -> dict:
    """Predicts species and confidence for a flower observation."""
    input_df = pd.DataFrame([{
        "sepal_length": sepal_len,
        "sepal_width": sepal_wid,
        "petal_length": petal_len,
        "petal_width": petal_wid
    }])
    
    predicted_class = model.predict(input_df)[0]
    probs = model.predict_proba(input_df)[0]
    confidence = max(probs)
    
    return {
        "species": predicted_class,
        "confidence": round(confidence * 100, 2),
        "all_probabilities": {cls: round(p, 4) for cls, p in zip(model.classes_, probs)}
    }
```
Testing the function:
```python
result = predict_iris_species(model, 5.8, 2.7, 4.1, 1.0)
print(result)
```
Output:
```json
{
  "species": "versicolor",
  "confidence": 97.22,
  "all_probabilities": {
    "setosa": 0.0,
    "versicolor": 0.9722,
    "virginica": 0.0278
  }
}
```
This demonstrates how clean decision tree models integrate into real-time REST APIs or mobile backends.

## Step-by-Step Student Instructions
1. Open `main.py` in your code editor.
2. Examine lines 59-63.
3. In terminal, test creating a novel setosa flower in Python:
   ```bash
   python -c "
   import pandas as pd
   from sklearn.tree import DecisionTreeClassifier

   # Quick test
   flower = pd.DataFrame([{'sepal_length': 5.0, 'sepal_width': 3.5, 'petal_length': 1.4, 'petal_width': 0.2}])
   print('Novel test flower shape:', flower.shape)
   "
   ```
4. Confirm the DataFrame shape is `(1, 4)`.

## Expected Output or Observable Behaviour
When `main.py` executes, line 63 outputs:
```
New flower -> versicolor
```
This confirms that the model classified the sample as *Iris versicolor*.

## Practical Exercises
- **Exercise 2.1**: Predict the species for a flower with `petal_length = 5.2` and `petal_width = 2.0`. Which class does the model assign? (*virginica*).
- **Exercise 2.2**: Why does `model.predict(new_flower)` return an array rather than a single string? (Because scikit-learn is designed for batch predictions on multiple rows).
- **Exercise 2.3**: Write the pandas syntax to create a batch DataFrame containing 3 flowers simultaneously.

## Common Mistakes and Debugging
| Mistake | Why It Happens | Solution |
|---|---|---|
| Passing dictionary directly | Calling `model.predict({"sepal_length": 5.8, ...})` | Wrap dictionary inside `pd.DataFrame([dict])`. |
| Missing feature column | Passing 3 features instead of 4 | Ensure input DataFrame contains all 4 columns defined in `FEATURES`. |
| Forgetting `[0]` index | Treating returned array as a string | Use `[0]` to unwrap the single string prediction from the NumPy array. |

## Best Practices and Security Considerations
- **Input Sanitization**: Validate that incoming numeric dimensions fall within biologically plausible ranges (e.g. Rejecting negative numbers or values > 50 cm).
- **Feature Order Resilience**: Passing a DataFrame with named columns prevents bugs caused by accidental feature column swapping.
- **Microsecond Latency**: Decision tree inference is so fast that no caching or GPU acceleration is necessary for real-time mobile apps.

## Summary
The real-time prediction workflow takes raw physical measurements, wraps them in a properly named 1-row DataFrame, and queries `model.predict()` and `model.predict_proba()`. For `new_flower` (`petal_length = 4.1 cm`), the model outputs `versicolor` with 97.2% confidence. Packaging this logic into clean helper functions makes deploying decision trees into web APIs or mobile backends straightforward.

## Knowledge-check Questions
1. What species did `main.py` predict for `new_flower`?
2. What was the petal length of `new_flower`?
3. What data structure must be passed into `model.predict()`?
4. How do you extract class confidence probabilities from a trained decision tree?
5. Why does `model.predict()` return a 1D NumPy array rather than a simple string?

## References
- scikit-learn model persistence and deployment guidelines (https://scikit-learn.org/stable/model_persistence.html).
- FastAPI: Building Production ML Inference APIs (https://fastapi.tiangolo.com).
