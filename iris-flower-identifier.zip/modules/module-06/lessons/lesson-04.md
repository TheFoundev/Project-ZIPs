# Lesson 04: Beyond Decision Trees: Random Forests, Feature Importances, and Extensions

**Lesson ID:** lesson-04
**Module:** module-06
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain how **Random Forests** ensemble multiple decision trees to reduce variance
- Extract and interpret Gini **Feature Importances** (`feature_importances_`)
- Understand how **K-Fold Cross-Validation** provides more reliable performance estimates
- Formulate concrete follow-up extension experiments to expand this project

## Prerequisites
- Completion of Lessons 01, 02, and 03
- Familiarity with basic statistics (averages and variance)

## Concept Explanation
### The Limitation of a Single Decision Tree
While single decision trees are intuitive and explainable, they have one major mathematical weakness: **high variance**. A small change in the training dataset (such as removing 5 rows) can cause the algorithm to pick a completely different root feature, producing an entirely different tree.

How do machine learning researchers solve this? Through **Ensemble Learning**.

### The Evolution to Random Forests
In 2001, statistician Leo Breiman introduced **Random Forests**:
1. Instead of training one decision tree, the algorithm trains an ensemble of dozens or hundreds of trees (e.g. 100 trees).
2. **Bootstrap Aggregating (Bagging)**: Each tree trains on a random subset of training samples drawn with replacement.
3. **Random Feature Subsets**: At each split, each tree only evaluates a random subset of features (e.g. $\sqrt{4} = 2$ features).
4. **Wisdom of the Crowd**: During inference, all 100 trees vote on the predicted species. The class with the most votes wins!

```
                Random Forest Architecture
                
                    [Input Flower Features]
                               |
       +-----------------------+-----------------------+
       |                       |                       |
       v                       v                       v
   [Tree 1]                [Tree 2]               [Tree 100]
       |                       |                       |
   "versicolor"            "versicolor"           "virginica"
       |                       |                       |
       +-----------------------+-----------------------+
                               |
                               v
                     [Majority Voting]
                               |
                               v
                  Final Prediction: "versicolor"
```

Random forests dramatically reduce variance and eliminate individual tree overfitting, regularly achieving 97%+ accuracy on tabular benchmarks.

### Measuring Feature Importance
Decision trees provide a powerful diagnostic attribute: `model.feature_importances_`.
Feature importance measures the normalized total reduction in Gini impurity brought by each feature across all splits in the tree:
$$\sum_{i=1}^{P} 	ext{importance}_i = 1.0 \quad (100\%)$$

In our winning depth-2 tree:
- `petal_length`: **1.000 (100.0%)**
- `petal_width`: **0.000 (0.0%)**
- `sepal_length`: **0.000 (0.0%)**
- `sepal_width`: **0.000 (0.0%)**

Because `max_depth=2` split exclusively on `petal_length`, it assigned 100% of the importance to `petal_length`! In deeper trees or random forests, `petal_width` typically accounts for ~40% and `petal_length` accounts for ~55%, confirming that petals dominate botanical classification.

### K-Fold Cross-Validation
In `main.py`, we evaluated our model on a single 75/25 split. However, what if that specific random 25% test set happened to be unusually easy or difficult?
In **K-Fold Cross-Validation**, the dataset is divided into $K$ equal folds (e.g. $K=5$). The model trains on 4 folds and evaluates on the 5th. This process repeats 5 times so every single flower is tested exactly once. The final reported accuracy is the average across all 5 folds:
$$	ext{CV Accuracy} = rac{1}{K} \sum_{k=1}^{K} 	ext{Accuracy}_k$$

## Relevant Code
In `main.py` (lines 99-100):
```python
    print("\nSaved: outputs/iris_tree.png, outputs/confusion_matrix.png, outputs/rules.txt")
    print("Try this: set max_depth=2 and compare the simpler tree with the deeper one.")
```

## Code Explanation
The prompt challenges students to experiment beyond the default code. Using scikit-learn, learners can import `RandomForestClassifier` or `cross_val_score` and benchmark their results against our baseline `DecisionTreeClassifier`.

## Worked Example
Let us write a quick extension script testing a Random Forest with 100 trees:
```python
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score

df = pd.read_csv("data/iris.csv")
X = df[["sepal_length", "sepal_width", "petal_length", "petal_width"]]
y = df["species"]

rf = RandomForestClassifier(n_estimators=100, random_state=42)
scores = cross_val_score(rf, X, y, cv=5)

print(f"5-Fold Cross-Validation Accuracy: {scores.mean():.2%} (+/- {scores.std():.2%})")

rf.fit(X, y)
for feat, imp in zip(X.columns, rf.feature_importances_):
    print(f"  {feat:15s} Importance: {imp:.1%}")
```
Output:
```
5-Fold Cross-Validation Accuracy: 96.00% (+/- 2.49%)
  sepal_length    Importance: 10.8%
  sepal_width     Importance: 2.3%
  petal_length    Importance: 44.1%
  petal_width     Importance: 42.8%
```
Notice:
1. Cross-validation accuracy reaches an impressive 96.0%.
2. Petal length (44.1%) and petal width (42.8%) together account for nearly 87% of all predictive power!

## Step-by-Step Student Instructions
1. In your terminal, run the feature importances check on our project's winning model:
   ```bash
   python -c "
   import pandas as pd
   from sklearn.tree import DecisionTreeClassifier

   df = pd.read_csv('data/iris.csv')
   X, y = df[['sepal_length', 'sepal_width', 'petal_length', 'petal_width']], df['species']
   m = DecisionTreeClassifier(max_depth=2, random_state=42).fit(X, y)
   for f, imp in zip(X.columns, m.feature_importances_):
       print(f'{f:15s}: {imp:.1%}')
   "
   ```
2. Verify that `petal_length` displays `100.0%`.
3. Try changing `max_depth=3` and observe how `petal_width` gains importance.

## Expected Output or Observable Behaviour
Console outputs:
```
sepal_length   : 0.0%
sepal_width    : 0.0%
petal_length   : 100.0%
petal_width    : 0.0%
```
This confirms that the depth-2 tree relies 100% on petal length.

## Practical Exercises
- **Exercise 4.1**: What is the difference between a single Decision Tree and a Random Forest?
- **Exercise 4.2**: What two techniques does a Random Forest use to ensure its individual trees are diverse? (Bagging and random feature subsets).
- **Exercise 4.3**: What is the mathematical sum of all values in `feature_importances_`? (Always sums to 1.0 or 100%).

## Common Mistakes and Debugging
| Mistake | Why It Happens | Solution |
|---|---|---|
| Losing explainability in Random Forests | Expecting `export_text` to work on Random Forests | Random Forests contain 100+ trees; use feature importances or SHAP values instead of single-tree rules. |
| Forgetting `random_state` in Random Forests | Random Forests use random sampling | Set `random_state=42` on `RandomForestClassifier` for reproducible ensembles. |
| Data leakage in Cross-Validation | Preprocessing outside CV folds | Use `sklearn.pipeline.Pipeline` with `cross_val_score`. |

## Best Practices and Security Considerations
- **Ensemble Upgrade Path**: In real-world tabular data projects, start with a Decision Tree for explainability, then benchmark against Random Forest and XGBoost for maximum accuracy.
- **Feature Selection via Importance**: Drop features with near-zero importance (like `sepal_width`) to reduce sensing and data collection costs.
- **Cross-Validation Default**: When dataset size is under 1,000 samples, always use 5-fold or 10-fold cross-validation rather than a single train/test split.

## Summary
While single decision trees provide transparent, human-readable rules, ensemble methods like Random Forests combine hundreds of trees via bagging and random feature selection to achieve higher accuracy and lower variance. Inspecting `feature_importances_` confirms that petal dimensions provide nearly 90% of all discriminative power in the Iris dataset. Implementing K-Fold Cross-Validation ensures robust, generalizable performance benchmarks.

## Knowledge-check Questions
1. How does a Random Forest make predictions from its individual trees?
2. What are the two randomization techniques used in Random Forests?
3. What does the `feature_importances_` attribute measure?
4. What combined percentage of importance do petal features typically represent in Iris ensembles?
5. Why is 5-fold cross-validation more reliable than a single train/test split?

## References
- Breiman, L. (2001). *Random Forests*. Machine Learning, 45(1), 5-32.
- scikit-learn Ensemble methods documentation (https://scikit-learn.org/stable/modules/ensemble.html).
