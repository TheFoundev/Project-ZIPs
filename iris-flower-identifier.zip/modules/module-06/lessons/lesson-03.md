# Lesson 03: The Foundational Lesson: Why Unlimited Depth Overfits

**Lesson ID:** lesson-03
**Module:** module-06
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Articulate the central machine learning takeaway of this project: simplicity beats unconstrained complexity
- Explain the mechanism by which unlimited depth memorizes training noise
- Contrast training accuracy with generalization accuracy across depth models
- Apply Occam's Razor to hyperparameter selection and model pruning

## Prerequisites
- Completion of Modules 03, 04, and 05
- Understanding of the bias-variance tradeoff

## Concept Explanation
### The Seduction of 100% Training Accuracy
When beginners train their first machine learning model, they often believe that achieving 100% accuracy is the ultimate goal. When they set `max_depth=None`, scikit-learn obligingly builds a tree that achieves **100.0% training accuracy** (112 out of 112 training flowers classified perfectly).

However, this 100% score is an illusion. The model did not discover a profound biological truth; it simply memorized the specific random coordinates of the 112 training specimens.

```
       Training Set vs. Holdout Test Set Performance
       
  Score |
  100%  |                  [Train: 100%]
   95%  |   [Train: 95.5%]
   92%  |   [Test: 92.1%]  <-- WINNER: max_depth=2
   89%  |                                  [Test: 89.5%] <-- OVERFIT!
    0%  +------------------------------------------------------------
                 max_depth=2                 max_depth=None
```

### The Mechanism of Overfitting in Decision Trees
Why does an unconstrained decision tree fail to generalize?
Because decision trees are **non-parametric**: they do not assume a fixed mathematical shape (like a straight line). If allowed to grow without constraint, a decision tree will create extra decision splits to isolate a single outlier sample.

Consider the training split:
- In `X_train`, there was an anomalous *versicolor* flower with unusually large petals (`petal_length = 4.8`, `petal_width = 1.8`).
- To achieve 100% training accuracy, `max_depth=None` created an intricate split: `petal_width <= 1.75`.
- In the test set, a normal *virginica* flower had `petal_length = 4.9` and `petal_width = 1.7`.
- Because 1.7 is less than 1.75, the overfitted rule misclassified this legitimate *virginica* flower as a *versicolor*!
- `max_depth=2` never created that fragile petal-width rule; it drew a clean cut at `petal_length <= 4.85`, correctly identifying the flower as *virginica*!

### Occam's Razor in Machine Learning
Occam's Razor states: *"Entities should not be multiplied beyond necessity."*
In data science, this translates directly to: **Among competing models with comparable predictive power, always choose the simpler model.**

Comparing the two models:
- `max_depth=2`: 2 decision splits, 3 leaf nodes, tests 1 feature (`petal_length`), achieves **92.1% test accuracy**.
- `max_depth=None`: 6 decision splits, 7 leaf nodes, tests multiple features, achieves **89.5% test accuracy**.

The simpler model is:
1. **More Accurate**: Generalizes better on unseen data (+2.6%).
2. **More Interpretable**: Can be written on a napkin or audited in 10 seconds.
3. **Faster**: Executes in 2 comparisons instead of 6.
4. **More Robust**: Immune to measurement jitter and sensor noise.

## Relevant Code
In `main.py` (lines 50-54 and line 100):
```python
        label = "unlimited" if depth is None else str(depth)
        print(f"  max_depth={label:9s} accuracy={accuracy:.1%}")

    best_depth = max(models, key=lambda depth: models[depth][2])
    model, predictions, accuracy = models[best_depth]
    print(f"\nBest tree: max_depth={best_depth}")

    # The pedagogical lesson:
    print("Try this: set max_depth=2 and compare the simpler tree with the deeper one.")
```

## Code Explanation
Line 50 displays the empirical evidence: depth 2 scores 92.1%, while unlimited depth scores 89.5%. Line 54 crowns `max_depth=2` as the best tree. Line 100 serves as the parting lesson of the project: encouraging learners to compare the simpler tree with the deeper one to experience the power of regularization firsthand.

## Worked Example
Let us quantify the structural complexity of both trees:
```python
from sklearn.tree import DecisionTreeClassifier

tree_simple = DecisionTreeClassifier(max_depth=2, random_state=42).fit(X_train, y_train)
tree_deep = DecisionTreeClassifier(max_depth=None, random_state=42).fit(X_train, y_train)

print(f"Depth 2    -> Node count: {tree_simple.tree_.node_count}, Leaves: {tree_simple.get_n_leaves()}")
print(f"Depth None -> Node count: {tree_deep.tree_.node_count}, Leaves: {tree_deep.get_n_leaves()}")
```
Output:
```
Depth 2    -> Node count: 5, Leaves: 3
Depth None -> Node count: 17, Leaves: 9
```
Notice: `max_depth=None` created **17 nodes and 9 leaves**—more than triple the complexity—only to perform *worse* on real-world test flowers!

## Step-by-Step Student Instructions
1. Run `python main.py` in your terminal.
2. Note the final console line: `Try this: set max_depth=2 and compare the simpler tree with the deeper one.`
3. Reflect on the difference: Depth 2 has 3 leaves; Depth None has 9 leaves.
4. Verify why simpler rules generalize better: they capture broad population trends rather than idiosyncratic sample noise.

## Expected Output or Observable Behaviour
The terminal output demonstrates that `max_depth=2` is selected as the winning model over unlimited depth.

## Practical Exercises
- **Exercise 3.1**: What is the difference between training error and generalization error?
- **Exercise 3.2**: Why did `max_depth=None` achieve 100% on the training set but drop on the test set?
- **Exercise 3.3**: State two distinct advantages of a tree with 3 leaves over a tree with 9 leaves in a production setting.

## Common Mistakes and Debugging
| Mistake | Why It Happens | Solution |
|---|---|---|
| Equating training accuracy with model quality | Looking only at training metrics | Always evaluate on holdout test data; never trust 100% training scores. |
| Over-parameterizing models | Believing complex models are inherently superior | Start with the simplest possible baseline; only add complexity if validated on test sets. |
| Pruning arbitrarily without validation | Guessing hyperparameters | Use validation sets or cross-validation to find the empirical performance peak. |

## Best Practices and Security Considerations
- **Pre-Pruning**: Always configure early stopping hyperparameters (`max_depth`, `min_samples_leaf`, `max_leaf_nodes`) when deploying decision trees.
- **Regularization Discipline**: Treat model complexity as a cost; demand significant, measurable test set improvements before accepting deeper architectures.
- **Robustness Against Adversarial Noise**: Deep, overfitted trees are easily fooled by minor input perturbations; shallow regularized trees are inherently robust.

## Summary
The central machine learning lesson of the Iris Flower Identifier is that model simplicity regularly defeats unconstrained complexity on unseen data. While `max_depth=None` builds a 17-node tree that scores 100% on training data by memorizing noise, it falls to 89.5% on the test set. By constraining growth to `max_depth=2`, a 5-node tree achieves 92.1% test accuracy, proving Occam's Razor in data science.

## Knowledge-check Questions
1. What training accuracy did `max_depth=None` achieve versus its test accuracy?
2. How many nodes did the unconstrained tree create compared to the depth-2 tree?
3. How did the depth-2 tree perform on the holdout test set compared to the unconstrained tree?
4. What is Occam's Razor and how does it apply to machine learning?
5. Why are shallow trees more robust against measurement noise than deep trees?

## References
- Breiman, L. (2001). *Statistical Modeling: The Two Cultures*. Statistical Science, 16(3), 199-231.
- Goodfellow, I., Bengio, Y., & Courville, A. (2016). *Deep Learning*. MIT Press. Chapter 5: Machine Learning Basics (Generalization, Overfitting, Underfitting).
