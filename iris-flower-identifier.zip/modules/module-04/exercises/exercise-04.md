# Module 4 Exercises: Tree Rules, Visualization & Inference Tracing

## Exercise 4.1: Generating and Parsing export_text Rules (15 min)
**Objective:** Extract text rules with and without feature names and analyze differences.
**Problem Statement:** You need to audit the learned rules of the optimal decision tree programmatically.

**Requirements:**
1. Train `DecisionTreeClassifier(max_depth=2, random_state=42)` on `X_train, y_train`.
2. Generate rules using `export_text(model)`.
3. Generate rules using `export_text(model, feature_names=FEATURES)`.
4. Contrast the two outputs and explain why `feature_names` is vital for non-technical stakeholders.

**Constraints:** Follow the implementation in `main.py`.

**Expected Behaviour:** Terminal script printing both rule sets.

**Acceptance Criteria:**
- [ ] First rule set prints `feature_2 <= 2.45`
- [ ] Second rule set prints `petal_length <= 2.45`
- [ ] Clear written explanation of why `feature_names` is necessary for interpretability

**Hints:**
- Import `from sklearn.tree import export_text`.

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 4.2: High-Resolution Tree Rendering (15 min)
**Objective:** Render and save a customized decision tree diagram using Matplotlib.
**Problem Statement:** Recreate lines 66-79 of `main.py` and modify styling parameters to observe visual effects.

**Requirements:**
1. Create a figure with `figsize=(16, 8)`.
2. Call `plot_tree()` with `filled=True, rounded=True, fontsize=8`.
3. Set title to `"Iris decision tree"`.
4. Save the figure to `outputs/iris_tree.png` with `dpi=150, bbox_inches="tight"`.
5. Call `plt.close(fig)`.

**Constraints:** Matplotlib must use `"Agg"` backend.

**Expected Behaviour:** A sharp PNG diagram saved at `outputs/iris_tree.png`.

**Acceptance Criteria:**
- [ ] PNG file exists on disk
- [ ] Image dimensions are approximately 2400x1200 pixels
- [ ] All boxes are readable with no overlapping text
- [ ] Node colors reflect class identities (orange, green, purple)

**Hints:**
- Use `matplotlib.use("Agg")` before importing `pyplot`.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 4.3: Manual Tracing of Three Custom Specimens (15 min)
**Objective:** Manually trace three botanical specimens through the decision tree logic.
**Problem Statement:** Given the learned tree logic, determine the traversal path and predicted class for three new flower specimens.

**Requirements:**
1. Specimen A: `sepal_length=5.1, sepal_width=3.5, petal_length=1.4, petal_width=0.2`
2. Specimen B: `sepal_length=6.0, sepal_width=2.9, petal_length=4.5, petal_width=1.5`
3. Specimen C: `sepal_length=6.9, sepal_width=3.1, petal_length=5.4, petal_width=2.1`
4. For each specimen, write down the path: (e.g., Root -> True -> Leaf: setosa).
5. State the predicted class and calculated probability for each specimen.

**Constraints:** Rely strictly on the rules learned by `max_depth=2`.

**Expected Behaviour:** Step-by-step written walkthrough for all three specimens.

**Acceptance Criteria:**
- [ ] Specimen A: Root (1.4 <= 2.45 True) -> `setosa` (Probability: 100%)
- [ ] Specimen B: Root (4.5 <= 2.45 False) -> Node 2 (4.5 <= 4.85 True) -> `versicolor` (Probability: 35/36 = 97.2%)
- [ ] Specimen C: Root (5.4 <= 2.45 False) -> Node 2 (5.4 <= 4.85 False) -> `virginica` (Probability: 36/38 = 94.7%)

**Hints:**
- Check only `petal_length` for each specimen.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 4.4: Decoding Node Attributes and Calculating Impurity (15 min)
**Objective:** Audit the sample breakdown and Gini impurity of the terminal leaves.
**Problem Statement:** Inspect the bottom-right leaf node of `outputs/iris_tree.png` and verify all its internal metrics mathematically.

**Requirements:**
1. Extract the `value` array from the bottom-right leaf box (`value = [0, 2, 36]`).
2. Calculate the total number of training samples in this leaf ($N = 38$).
3. Calculate the percentage distribution across all three species.
4. Calculate the Gini impurity mathematically and compare with the printed `gini = 0.105`.
5. Explain why the leaf predicts `virginica` despite containing 2 *versicolor* flowers.

**Constraints:** Show all arithmetic steps to 3 decimal places.

**Expected Behaviour:** Complete mathematical derivation of Gini impurity and majority vote justification.

**Acceptance Criteria:**
- [ ] Proportions calculated: $p_{\text{setosa}} = 0.0$, $p_{\text{versicolor}} = 2/38 \approx 0.0526$, $p_{\text{virginica}} = 36/38 \approx 0.9474$
- [ ] Sum of squares: $0.0526^2 + 0.9474^2 \approx 0.0028 + 0.8976 = 0.9004$
- [ ] Gini computed: $1.0 - 0.9004 = 0.0996 \approx 0.100-0.105$
- [ ] Majority voting principle correctly explained ($36 > 2$)

**Hints:**
- Remember $36/38 \approx 0.947$.

**Difficulty:** Advanced
**Estimated Completion Time:** 15 minutes
