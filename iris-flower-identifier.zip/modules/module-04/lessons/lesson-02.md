# Lesson 02: Visualizing Hierarchical Decision Trees with plot_tree()

**Lesson ID:** lesson-02
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Use `sklearn.tree.plot_tree` to render graphical flowchart diagrams of decision trees
- Configure visual styling options: `filled=True`, `rounded=True`, and `fontsize`
- Decode visual cues: node colors, color saturation, and class representation
- Save high-resolution diagrams to disk using Matplotlib's `savefig()`

## Prerequisites
- Completion of Lesson 01
- Basic understanding of Matplotlib figure creation (`plt.subplots`)

## Concept Explanation
### Graphical Flowcharts: Moving Beyond Text
While `export_text()` provides clean ASCII rules, graphical flowcharts offer immediate visual comprehension of tree topology, sample distributions, and node purity. Scikit-learn includes `plot_tree()`, which leverages Matplotlib to draw colored, annotated rectangular boxes interconnected by branch arrows.

```
       plot_tree Visual Layout
       
                 +--------------------------+
                 | petal_length <= 2.45 cm  |
                 | gini = 0.666             |
                 | samples = 112            |
                 | value = [38, 37, 37]     |
                 | class = setosa           |
                 +--------------------------+
                    /                      \
           True   /                          \   False
                v                              v
     +--------------------+          +--------------------------+
     | gini = 0.0         |          | petal_length <= 4.85 cm  |
     | samples = 38       |          | gini = 0.500             |
     | value = [38, 0, 0] |          | samples = 74             |
     | class = setosa     |          | value = [0, 37, 37]      |
     | (Solid Orange Box) |          | class = versicolor       |
     +--------------------+          +--------------------------+
                                        /                      \
                               True   /                          \   False
                                    v                              v
                         +--------------------+          +--------------------+
                         | gini = 0.053       |          | gini = 0.105       |
                         | samples = 36       |          | samples = 38       |
                         | value = [0, 35, 1] |          | value = [0, 2, 36] |
                         | class = versicolor |          | class = virginica  |
                         | (Solid Green Box)  |          | (Solid Purple Box) |
                         +--------------------+          +--------------------+
```

### Visual Styling Parameters in plot_tree
In `main.py`, lines 66-79 configure the visual appearance:
1. `feature_names=FEATURES`: Labels split thresholds with actual feature names.
2. `class_names=list(model.classes_)`: Labels predicted class majorities with species names (`setosa`, `versicolor`, `virginica`).
3. `filled=True`: Colors nodes according to the majority class. Node color intensity reflects purity—nodes with high purity appear vibrant and solid, while mixed nodes appear pale or pastel.
4. `rounded=True`: Draws rounded corners on bounding boxes for a modern aesthetic.
5. `fontsize=8`: Adjusts text size so all five lines of node metrics fit comfortably inside the box without clipping.

### Understanding the Color Palette
When `filled=True` is enabled, scikit-learn assigns distinct hue families to each target class:
- **Orange**: *Iris setosa*
- **Green**: *Iris versicolor*
- **Purple**: *Iris virginica*

The left leaf node containing 38 *setosa* and 0 of other species appears as a vibrant, deep orange. The root node, which contains an almost equal mix of all three classes, appears virtually white (diluted pastel).

## Relevant Code
In `main.py` (lines 66-79):
```python
    # ---- Draw the tree -------------------------------------------------
    fig, ax = plt.subplots(figsize=(16, 8))
    plot_tree(
        model,
        feature_names=FEATURES,
        class_names=list(model.classes_),
        filled=True,
        rounded=True,
        fontsize=8,
        ax=ax,
    )
    ax.set_title("Iris decision tree")
    fig.tight_layout()
    fig.savefig(OUT / "iris_tree.png", dpi=150, bbox_inches="tight")
    plt.close(fig)
```

## Code Explanation
Line 66 creates a wide canvas: `figsize=(16, 8)` ensures that wide multi-branch trees have sufficient horizontal room to prevent overlapping text boxes. Lines 67-75 call `plot_tree()` targeting the axes `ax`. Line 76 sets the title. Line 77 applies `tight_layout()` to minimize margins. Line 78 saves the graphic at 150 DPI resolution with `bbox_inches="tight"`. Line 79 closes the figure with `plt.close(fig)` to reclaim memory.

## Worked Example
What happens if you omit `figsize=(16, 8)` and use Matplotlib's default `figsize=(6.4, 4.8)`?
On a standard canvas, node boxes become squeezed together. Text strings like `petal_length <= 2.45` collide with adjacent boxes, rendering the diagram unreadable. Specifying `figsize=(16, 8)` along with `dpi=150` produces a crisp, publication-quality image with 2400x1200 pixels.

## Step-by-Step Student Instructions
1. Run `python main.py` in your terminal.
2. Open the newly generated file `outputs/iris_tree.png` using an image viewer or VS Code preview.
3. Locate the root node at the top center.
4. Follow the left branch (True condition) downward to the orange leaf box.
5. Follow the right branch (False condition) downward to the second decision split.
6. Verify the colors of the two bottom leaves: green on the left, purple on the right.

## Expected Output or Observable Behaviour
Opening `outputs/iris_tree.png` shows:
- Top node: pastel box with split condition `petal_length <= 2.45`.
- Bottom-left leaf: vibrant orange box labeled `class = setosa`.
- Bottom-middle leaf: vibrant green box labeled `class = versicolor`.
- Bottom-right leaf: vibrant purple box labeled `class = virginica`.

## Practical Exercises
- **Exercise 2.1**: What visual property indicates that a node is 100% pure when `filled=True` is set? (The node color is completely saturated/opaque).
- **Exercise 2.2**: Why is `plt.close(fig)` called immediately after `fig.savefig()`? (To free memory and prevent Matplotlib figure leaks).
- **Exercise 2.3**: What is the purpose of passing `bbox_inches="tight"` to `savefig()`?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Solution |
|---|---|---|
| Overlapping text boxes | Default figure size is too small for tree width | Set `figsize=(16, 8)` and reduce `fontsize` to 8 or 9. |
| Blank saved image | Calling `plt.savefig()` after `plt.close()` | Always invoke `savefig()` before calling `plt.close()`. |
| Missing colors | Omitting `filled=True` in `plot_tree()` | Pass `filled=True` to enable class-based hue shading. |

## Best Practices and Security Considerations
- **Resolution Standards**: Use `dpi=150` or `dpi=300` for diagrams intended for documentation, presentations, or printed academic reports.
- **Resource Cleanup**: Always call `plt.close(fig)` in server pipelines or loops to prevent memory leaks from accumulated figures.
- **Colorblind Accessibility**: Scikit-learn's default colormap provides good contrast, but for sensitive production dashboards, consider verifying contrast with colorblind simulation tools.

## Summary
`sklearn.tree.plot_tree` converts decision trees into rich graphical flowcharts rendered via Matplotlib. Configuring `filled=True`, `rounded=True`, and `class_names` creates an intuitive visual diagram where node color and saturation signify class identity and purity. Saving the figure to `outputs/iris_tree.png` with wide dimensions (`16, 8`) and 150 DPI produces a clean, professional visual artifact for non-technical stakeholders.

## Knowledge-check Questions
1. Which function renders graphical decision tree flowcharts in scikit-learn?
2. What does the `filled=True` argument do in `plot_tree()`?
3. What color family is assigned to *Iris setosa* by default in scikit-learn?
4. What figure dimensions (`figsize`) are used in `main.py` to ensure readable node boxes?
5. Why must `fig.savefig()` be executed before `plt.close(fig)`?

## References
- scikit-learn plot_tree documentation (https://scikit-learn.org/stable/modules/generated/sklearn.tree.plot_tree.html).
- Hunter, J. D. (2007). *Matplotlib: A 2D Graphics Environment*. Computing in Science & Engineering, 9(3), 90-95.
