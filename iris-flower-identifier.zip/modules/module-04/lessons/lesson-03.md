# Lesson 03: Step-by-Step Inference: Manually Tracing Samples Through Decision Nodes

**Lesson ID:** lesson-03
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Trace an unseen flower observation step-by-step through a decision tree
- Explain the binary branching logic: True branches branch left, False branches branch right
- Walk through the exact prediction for the `new_flower` defined in `main.py`
- Verify that inference speed in decision trees is $O(\text{depth})$, requiring only a handful of numeric comparisons

## Prerequisites
- Completion of Lesson 01 and Lesson 02
- Basic understanding of flowchart navigation

## Concept Explanation
### How Inference Works: The Falling Ball Metaphor
Making a prediction with a decision tree is like dropping a ball through a pachinko machine or Galton board. At every peg (decision node), the ball evaluates a condition. If the condition is True, it rolls left. If False, it rolls right. When the ball lands in a bin at the bottom (leaf node), the label on that bin is the prediction.

```
                  [ Root Node: petal_length <= 2.45 ]
                               /         \
                        True  /           \  False
                             v             v
                     (Leaf: setosa)    [ Node 2: petal_length <= 4.85 ]
                                            /         \
                                     True  /           \  False
                                          v             v
                                 (Leaf: versicolor)  (Leaf: virginica)
```

### The New Flower in main.py
In line 59 of `main.py`, a new, previously unobserved flower specimen is introduced:
```python
new_flower = pd.DataFrame(
    [{"sepal_length": 5.8, "sepal_width": 2.7, "petal_length": 4.1, "petal_width": 1.0}]
)
```
Let us trace this specimen manually:
- **Attribute Checklist**:
  - `sepal_length` = 5.8 cm
  - `sepal_width` = 2.7 cm
  - `petal_length` = 4.1 cm
  - `petal_width` = 1.0 cm

### Step-by-Step Execution Trace
1. **Node 0 (Root)**:
   - Condition: `petal_length <= 2.45`
   - Evaluation: Is $4.1 \le 2.45$?
   - Result: **False**
   - Action: Follow the **False** branch to the right child (Node 2).
2. **Node 2 (Intermediate Split)**:
   - Condition: `petal_length <= 4.85`
   - Evaluation: Is $4.1 \le 4.85$?
   - Result: **True**
   - Action: Follow the **True** branch to the left child (Node 3).
3. **Node 3 (Terminal Leaf)**:
   - Node Type: Leaf node (no further conditions)
   - Assigned Class: `versicolor`
   - Confidence: 35 versicolor vs. 1 virginica ($35/36 \approx 97.2\%$)
   - Final Prediction: **`versicolor`**

### Computational Efficiency of Tree Inference
Notice that to classify this flower, the computer performed exactly **two numeric comparison operations** (`4.1 <= 2.45` and `4.1 <= 4.85`).
In a decision tree of depth $d$, inference requires at most $d$ comparison operations:
$$\text{Time Complexity} = O(d)$$
For `max_depth=2`, $d=2$. The computer resolves the classification in a fraction of a microsecond ($< 0.000001$ seconds)! This lightning-fast inference makes decision trees ideal for high-throughput edge devices, sensor networks, and real-time financial trading systems.

## Relevant Code
In `main.py` (lines 59-63):
```python
    new_flower = pd.DataFrame(
        [{"sepal_length": 5.8, "sepal_width": 2.7, "petal_length": 4.1, "petal_width": 1.0}]
    )
    new_species = model.predict(new_flower)[0]
    print(f"New flower -> {new_species}")
```

## Code Explanation
Line 59 constructs `new_flower` as a 1-row pandas DataFrame. It provides all four features matching `FEATURES` to adhere strictly to scikit-learn's tabular input expectations. Line 62 invokes `model.predict(new_flower)`. Because `.predict()` returns a 1D NumPy array of predictions, `[0]` extracts the single predicted string label, storing it in `new_species`. Line 63 prints `New flower -> versicolor`.

## Worked Example
Let us trace two more hypothetical specimens:

#### Flower X: `[6.5, 3.0, 5.5, 1.8]`
1. Root: Is `petal_length (5.5) <= 2.45`? False. Go right.
2. Node 2: Is `petal_length (5.5) <= 4.85`? False. Go right.
3. Leaf: Arrive at `virginica`.
4. Prediction: **`virginica`**.

#### Flower Y: `[4.8, 3.4, 1.2, 0.2]`
1. Root: Is `petal_length (1.2) <= 2.45`? True. Go left.
2. Leaf: Arrive at `setosa`.
3. Prediction: **`setosa`**.

## Step-by-Step Student Instructions
1. Run `python main.py` in your terminal.
2. Locate the line: `New flower -> versicolor`.
3. Compare the measurements in line 60 with the rules in `outputs/rules.txt`.
4. Verify why the model predicted `versicolor`: because $2.45 < 4.1 \le 4.85$.
5. Test what happens if you change `petal_length` to 5.2 in a test script.

## Expected Output or Observable Behaviour
Console output confirms:
```
New flower -> versicolor
```
This demonstrates that our manual trace matches scikit-learn's programmatic inference engine exactly.

## Practical Exercises
- **Exercise 3.1**: What would the model predict if a flower had `petal_length = 2.45`?
- **Exercise 3.2**: What would the model predict if a flower had `sepal_length = 10.0, sepal_width = 1.0, petal_length = 1.5, petal_width = 3.0`? (Hint: Does sepal length affect the outcome at depth 2?).
- **Exercise 3.3**: Why must `new_flower` be formatted as a 2D DataFrame or 2D array rather than a simple 1D list `[5.8, 2.7, 4.1, 1.0]`?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Solution |
|---|---|---|
| Passing 1D list to `model.predict` | Typing `model.predict([5.8, 2.7, 4.1, 1.0])` | Pass a 2D structure: `pd.DataFrame([...])` or `[[5.8, 2.7, 4.1, 1.0]]`. |
| Missing feature names warning | Passing raw NumPy array after training on DataFrame | Pass a DataFrame with matching column names to eliminate scikit-learn warnings. |
| Forgetting `[0]` index | Printing `model.predict(new_flower)` directly | `.predict()` returns an array `array(['versicolor'])`; use `[0]` to get the string `'versicolor'`. |

## Best Practices and Security Considerations
- **Schema Validation**: In production APIs, validate incoming prediction requests against an explicit schema (e.g. Pydantic) to ensure all required feature keys are present and numeric.
- **Batch Inference**: When predicting thousands of flowers, pass a DataFrame with thousands of rows in a single `model.predict()` call rather than looping row by row.
- **Deterministic Inference**: Decision tree inference is completely deterministic and stateless; parallel threads can safely share a single trained model object for inference without race conditions.

## Summary
Inference in a decision tree consists of traversing a sequence of binary inequalities from the root node to a terminal leaf. Evaluating `new_flower` (`petal_length = 4.1 cm`) navigates False at the root (`> 2.45`) and True at Node 2 (`<= 4.85`), landing in the `versicolor` leaf. With a time complexity of $O(\text{depth})$, decision tree inference requires only two comparison operations, delivering near-instantaneous classifications.

## Knowledge-check Questions
1. What species did the model predict for `new_flower` in `main.py`?
2. What was the `petal_length` of `new_flower`?
3. How many decision node comparisons were evaluated to classify `new_flower`?
4. What is the Big-O time complexity of inference in a decision tree of depth $d$?
5. Why does passing a 1D list to `model.predict()` trigger a ValueError or warning in modern scikit-learn?

## References
- scikit-learn DecisionTreeClassifier predict API (https://scikit-learn.org/stable/modules/generated/sklearn.tree.DecisionTreeClassifier.html#sklearn.tree.DecisionTreeClassifier.predict).
- Cormen, T. H., Leiserson, C. E., Rivest, R. L., & Stein, C. (2009). *Introduction to Algorithms*, 3rd Edition. MIT Press. Chapter 12: Binary Search Trees.
