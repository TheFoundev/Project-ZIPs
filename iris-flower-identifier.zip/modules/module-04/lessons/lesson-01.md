# Lesson 01: Extracting Human-Readable Text Rules with export_text

**Lesson ID:** lesson-01
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Use `sklearn.tree.export_text` to extract ASCII decision rules from a trained model
- Explain the role of the `feature_names` argument in producing interpretable rule labels
- Parse hierarchical indentations representing tree depth and branch conditions
- Understand how software engineers integrate text rules into auditing logs and microservices

## Prerequisites
- Completion of Module 03
- Familiarity with ASCII hierarchy formatting and string manipulation

## Concept Explanation
### The Need for Auditable Rules
When an AI system makes a decision—whether approving an insurance claim or classifying a plant species—stakeholders demand an explanation. Deep neural networks provide millions of weight parameters that no human can interpret. In contrast, scikit-learn's `DecisionTreeClassifier` stores its entire internal decision logic as an explicit binary search tree.

To extract this logic in a clean format, scikit-learn provides `export_text()`. It traverses the tree structure using pre-order depth-first search and formats every decision condition into a readable text tree.

```
+-------------------------------------------------------------+
|                export_text Structure Anatomy                |
+-------------------------------------------------------------+
|  |--- petal_length <= 2.45        <-- Root Decision Split   |
|  |   |--- class: setosa           <-- Left Leaf (Terminal)  |
|  |--- petal_length >  2.45        <-- Right Branch (Else)   |
|  |   |--- petal_length <= 4.85    <-- Depth 1 Decision Split|
|  |   |   |--- class: versicolor   <-- Depth 2 Left Leaf     |
|  |   |--- petal_length >  4.85    <-- Depth 2 Right Branch  |
|  |   |   |--- class: virginica    <-- Depth 2 Right Leaf    |
+-------------------------------------------------------------+
```

### Passing feature_names=FEATURES
By default, if you invoke `export_text(model)` without specifying feature names, scikit-learn uses generic placeholders:
```
|--- feature_2 <= 2.45
|   |--- class: setosa
|--- feature_2 >  2.45
...
```
While mathematically valid, `feature_2` forces the reader to look up column indices manually. Passing `feature_names=FEATURES` replaces the placeholder with `"petal_length"`, converting obscure indexing into immediate biological insight.

### Indentation and Hierarchy
In `export_text` output:
- Each vertical pipe symbol `|` denotes one level of tree depth.
- `|---` introduces a decision rule or leaf class.
- Indented blocks under a rule represent child nodes evaluated only when that parent rule's condition is met.
- The top-level block tests the root condition; indented sub-blocks test subsequent conditions.

## Relevant Code
In `main.py` (lines 55-56 and line 95):
```python
    print("\nLearned rules for the best tree:\n")
    print(export_text(model, feature_names=FEATURES))

    # Writing to output file:
    with open(OUT / "rules.txt", "w", encoding="utf-8") as handle:
        # ...
        handle.write(export_text(model, feature_names=FEATURES))
```

## Code Explanation
Line 56 calls `export_text(model, feature_names=FEATURES)` and prints the output directly to standard output. Line 95 writes the exact same formatted string into `outputs/rules.txt`. This creates an immutable, version-controlled text record of the model's logic that can be reviewed by domain experts without running Python.

## Worked Example
Suppose you want to convert the `export_text` output into an executable Python function for a lightweight embedded microcontroller that cannot run scikit-learn:
```python
def classify_flower(petal_length: float) -> str:
    """Hardcoded decision tree logic extracted from export_text."""
    if petal_length <= 2.45:
        return "setosa"
    else:
        if petal_length <= 4.85:
            return "versicolor"
        else:
            return "virginica"
```
Because the decision tree produces simple thresholds, you can deploy the model as a 10-line Python function with zero external dependencies!

## Step-by-Step Student Instructions
1. Run `python main.py` in your terminal.
2. Locate the header: `Learned rules for the best tree:`.
3. Verify that the output uses the column name `petal_length` rather than `feature_2`.
4. Open `outputs/rules.txt` in your text editor and confirm the rules are saved on disk.
5. Notice that neither `sepal_length`, `sepal_width`, nor `petal_width` appear in the rules for `max_depth=2`.

## Expected Output or Observable Behaviour
Console and `rules.txt` display:
```
|--- petal_length <= 2.45
|   |--- class: setosa
|--- petal_length >  2.45
|   |--- petal_length <= 4.85
|   |   |--- class: versicolor
|   |--- petal_length >  4.85
|   |   |--- class: virginica
```
This confirms that the tree consists of 2 decision splits and 3 terminal leaf classes.

## Practical Exercises
- **Exercise 1.1**: What happens if you run `export_text(model)` without the `feature_names` parameter?
- **Exercise 1.2**: Write down the exact threshold used to separate *versicolor* from *virginica*.
- **Exercise 1.3**: If a flower has `petal_length = 2.45`, which class is it assigned to? (Notice the `<=` operator: exactly 2.45 evaluates to `setosa`).

## Common Mistakes and Debugging
| Mistake | Why It Happens | Solution |
|---|---|---|
| Mismatched feature names length | Passing a feature list with different length than `X.shape[1]` | Ensure `len(feature_names) == 4` matching `X_train.shape[1]`. |
| Printing non-tree estimator | Passing a LogisticRegression or KNN model to `export_text` | `export_text` only works on tree-based estimators from `sklearn.tree`. |
| Overlooking boundary equality | Assuming `<` instead of `<=` | Remember decision tree thresholds use `<=` (less than or equal to). |

## Best Practices and Security Considerations
- **Version Control for Rules**: Always archive the generated `rules.txt` alongside model checkpoints in Git to maintain an immutable compliance log.
- **Rule Complexity Audits**: If `export_text` prints hundreds of lines of deeply nested rules, the model is likely severely overfitted; constrain `max_depth`.
- **Automated Sanity Testing**: Unit-test extracted rules against edge cases (e.g. `petal_length = 0.0` or `petal_length = 10.0`) to verify sensible behavior.

## Summary
Scikit-learn's `export_text()` function transforms complex decision tree data structures into human-readable ASCII hierarchies. Passing `feature_names=FEATURES` ensures decision splits reference meaningful botanical dimensions. The learned rules show that a depth-2 tree splits exclusively on `petal_length` at 2.45 cm and 4.85 cm, producing a transparent model easily deployed to microcontrollers or regulatory review boards.

## Knowledge-check Questions
1. Which scikit-learn module contains the `export_text` utility?
2. What generic names does `export_text` use if `feature_names` is omitted?
3. What mathematical comparison operator (`<`, `<=`, `>`, `>=`) is used at decision splits?
4. In our winning model, what is the exact petal length threshold separating *versicolor* and *virginica*?
5. How can `export_text` rules be deployed in environments without Python or scikit-learn installed?

## References
- scikit-learn export_text API documentation (https://scikit-learn.org/stable/modules/generated/sklearn.tree.export_text.html).
- Ribeiro, M. T., Singh, S., & Guestrin, C. (2016). *"Why Should I Trust You?": Explaining the Predictions of Any Classifier*. KDD.
