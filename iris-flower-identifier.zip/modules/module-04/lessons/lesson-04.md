# Lesson 04: Decoding Tree Nodes: Samples, Values, Gini Impurity, and Leaf Purity

**Lesson ID:** lesson-04
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Decode every line of metadata displayed inside a `plot_tree` node box
- Interpret the `value = [s1, s2, s3]` array representing training class distributions
- Calculate sample proportions and prediction confidence at any leaf node
- Understand the concept of "majority voting" in non-pure terminal leaves

## Prerequisites
- Completion of Lessons 01, 02, and 03
- Familiarity with the 3 classes: setosa (index 0), versicolor (index 1), virginica (index 2)

## Concept Explanation
### Reading Inside the Box
When you examine `outputs/iris_tree.png`, each rectangular box contains up to five distinct lines of text. Understanding how to decode these lines is essential for auditing model decisions:

```
+------------------------------------+
| 1. Split condition: petal_length <= 4.85
| 2. Gini impurity:   gini = 0.500
| 3. Sample count:    samples = 74
| 4. Class counts:    value = [0, 37, 37]
| 5. Majority label:  class = versicolor
+------------------------------------+
```

Let us dissect each component:
1. **Split Condition**: The binary inequality tested at this node. If a node is a leaf, this line is absent.
2. **`gini`**: The Gini impurity of the training samples residing at this node.
3. **`samples`**: The total number of training samples from `X_train` that passed through this node.
4. **`value`**: A list showing the exact breakdown of training samples by class: `[count_setosa, count_versicolor, count_virginica]`.
5. **`class`**: The name of the class that has the majority count in `value`. If this node were to issue a prediction right now, it would predict this class label.

### Class Array Ordering: Alphabetical Alignment
How does scikit-learn decide the ordering of numbers inside `value = [c0, c1, c2]`?
Scikit-learn sorts target classes **alphabetically**:
- Index 0: `setosa`
- Index 1: `versicolor`
- Index 2: `virginica`

Therefore, `value = [0, 35, 1]` means:
- 0 *setosa* samples
- 35 *versicolor* samples
- 1 *virginica* sample
Total samples = $0 + 35 + 1 = 36$.

### Majority Voting and Leaf Purity
In an unconstrained tree (`max_depth=None`), every leaf grows until it is 100% pure (`gini = 0.0`), with only one non-zero entry in `value`.
In a regularized, pruned tree (`max_depth=2`), leaves can be slightly **impure**:
- **Bottom-Left Leaf**:
  - `value = [38, 0, 0]` $ightarrow$ 100% pure *setosa* (`gini = 0.0`).
- **Bottom-Middle Leaf**:
  - `value = [0, 35, 1]` $ightarrow$ 35 versicolor vs. 1 virginica.
  - The node is not 100% pure (`gini = 0.053`).
  - By **majority voting**, because $35 > 1$, the node assigns the class label `versicolor`.
- **Bottom-Right Leaf**:
  - `value = [0, 2, 36]` $ightarrow$ 36 virginica vs. 2 versicolor.
  - Impurity `gini = 0.105`.
  - By **majority voting**, because $36 > 2$, the node assigns the class label `virginica`.

```
                  Root Node: [38, 37, 37] (Total: 112)
                             /             \
                      <= 2.45               > 2.45
                        /                     \
        Leaf: [38, 0, 0] (Pure Setosa)     Split: [0, 37, 37] (Total: 74)
                                                /            \
                                         <= 4.85              > 4.85
                                           /                    \
                       Leaf: [0, 35, 1] (Versicolor)       Leaf: [0, 2, 36] (Virginica)
                       (97.2% Versicolor, 2.8% Virginica)  (94.7% Virginica, 5.3% Versicolor)
```

### Predicting Class Probabilities (`predict_proba`)
A decision tree does not just output a hard class label; it can also output probability confidences using `model.predict_proba()`:
For any sample falling into the bottom-middle leaf:
$$P(\text{versicolor}) = \frac{35}{36} = 0.9722 \quad (97.2\%)$$
$$P(\text{virginica}) = \frac{1}{36} = 0.0278 \quad (2.8\%)$$
$$P(\text{setosa}) = \frac{0}{36} = 0.0000 \quad (0.0\%)$$
This reveals that our model is 97.2% confident that `new_flower` is a *versicolor*!

## Relevant Code
In `main.py` (lines 67-75):
```python
    plot_tree(
        model,
        feature_names=FEATURES,
        class_names=list(model.classes_),
        filled=True,
        rounded=True,
        fontsize=8,
        ax=ax,
    )
```

## Code Explanation
Passing `class_names=list(model.classes_)` tells `plot_tree` which text label corresponds to each index in `value`. `model.classes_` contains `['setosa', 'versicolor', 'virginica']`. This allows `plot_tree` to map index 0 to `setosa`, index 1 to `versicolor`, and index 2 to `virginica`, printing human-readable class names on line 5 of every box.

## Worked Example
Let us compute the Gini impurity for the bottom-middle leaf:
- Samples: $N = 36$
- Counts: 0 setosa, 35 versicolor, 1 virginica
- Proportions: $p_{\text{setosa}} = 0, p_{\text{versicolor}} = 35/36 \approx 0.9722, p_{\text{virginica}} = 1/36 \approx 0.0278$
- Sum of squared proportions:
  $$0^2 + (0.9722)^2 + (0.0278)^2 = 0 + 0.9452 + 0.0008 = 0.9460$$
- Gini impurity:
  $$I_G = 1 - 0.9460 = 0.054$$
Comparing this with `outputs/iris_tree.png`: the diagram displays `gini = 0.053` (minor rounding difference in 3rd decimal place). The calculation confirms the node is nearly 95% pure!

## Step-by-Step Student Instructions
1. Open `outputs/iris_tree.png`.
2. Inspect the bottom-middle leaf box.
3. Read the line: `value = [0, 35, 1]`.
4. Calculate the total samples in this leaf ($0 + 35 + 1 = 36$).
5. Compute the percentage of *versicolor* flowers ($35 / 36 = 97.2\%$).
6. In python, verify `model.predict_proba(new_flower)` matches this probability vector.

## Expected Output or Observable Behaviour
Running `model.predict_proba(new_flower)` in terminal outputs:
```python
array([[0.        , 0.97222222, 0.02777778]])
```
This confirms that the class probability matches the ratio of samples in the terminal leaf node box.

## Practical Exercises
- **Exercise 4.1**: What class is represented by index 2 in `value = [0, 2, 36]`?
- **Exercise 4.2**: In `value = [0, 2, 36]`, how many training samples were *versicolor*?
- **Exercise 4.3**: Why is the bottom-right leaf colored purple in `outputs/iris_tree.png`?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Solution |
|---|---|---|
| Confusing `samples` with test set | Assuming node samples come from `X_test` | Node boxes document the `X_train` samples (total 112) used during fitting. |
| Misinterpreting `value` array indices | Forgetting alphabetical sorting | Class indices are alphabetical: [setosa, versicolor, virginica]. |
| Assuming impure leaves cannot classify | Believing all leaves must have gini = 0 | Regularized trees classify by majority vote in slightly impure leaves. |

## Best Practices and Security Considerations
- **Threshold Calibration**: When class costs are asymmetric (e.g. cancer detection), do not rely on simple 50% majority voting; inspect `predict_proba` and apply custom probability thresholds.
- **Node Sample Auditing**: Beware of leaves with very small sample counts (e.g. `samples = 1` or `2`). These leaves are statistically fragile and prone to overfitting.
- **Transparent Communication**: When explaining predictions to end users, report both the winning class and the leaf purity percentage (e.g. "Versicolor with 97.2% confidence").

## Summary
Every node in a decision tree diagram documents five key metrics: the split condition, Gini impurity, sample count, class distribution vector (`value`), and majority class label. Classes are ordered alphabetically in scikit-learn (`[setosa, versicolor, virginica]`). In regularized trees (`max_depth=2`), terminal leaves may retain minor impurity, issuing predictions via majority voting. The leaf sample proportions directly define the model's output probabilities via `predict_proba()`.

## Knowledge-check Questions
1. What does the `value` array inside a decision tree node box represent?
2. In what order are class counts arranged inside the `value` list?
3. How many total training samples are present in the bottom-middle leaf (`value = [0, 35, 1]`)?
4. How does a leaf node decide which class to output when it contains samples from multiple classes?
5. Which scikit-learn method returns the class probability distribution for an input sample?

## References
- scikit-learn DecisionTreeClassifier predict_proba documentation (https://scikit-learn.org/stable/modules/generated/sklearn.tree.DecisionTreeClassifier.html#sklearn.tree.DecisionTreeClassifier.predict_proba).
- Tan, P. N., Steinbach, M., & Kumar, V. (2018). *Introduction to Data Mining*, 2nd Edition. Pearson. Chapter 4: Decision Trees.
