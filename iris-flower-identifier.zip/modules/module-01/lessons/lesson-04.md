# Lesson 04: White-Box Machine Learning: Decision Trees as Human-Readable Rules

**Lesson ID:** lesson-04
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain what differentiates "white-box" (interpretable) models from "black-box" models
- Describe how decision trees represent logic as an intuitive series of binary if-then questions
- Define the core anatomical components of a decision tree (root node, decision nodes, leaf nodes)
- Appreciate why model interpretability is critical in regulated fields like healthcare, finance, and legal compliance

## Prerequisites
- Completion of Lessons 01, 02, and 03
- Familiarity with basic programmatic conditional logic (`if`, `elif`, `else`)

## Concept Explanation
### Black-Box vs. White-Box Models
In modern artificial intelligence, algorithms are frequently grouped along an axis of **interpretability**:
- **Black-Box Models**: Deep neural networks, gradient-boosted ensembles with hundreds of estimators, and complex kernel support vector machines often achieve impressive predictive accuracy. However, their internal reasoning consists of millions of interconnected mathematical weights. It is nearly impossible for a human expert to look inside the model and determine exactly *why* a specific decision was made.
- **White-Box Models**: Algorithms whose internal reasoning is transparent, auditable, and easily explained in plain human language. Linear regression, logistic regression, and **decision trees** are classic examples of white-box models.

```
       Interpretability vs. Complexity
       
  High  ^  [Decision Trees]       [Linear Regression]
        |
        |
        |       [Random Forests]
        |
  Low   |                                [Deep Neural Networks]
        +------------------------------------------------------>
       Low                      Complexity                     High
```

### How a Decision Tree Thinks: Hierarchical Binary Splits
A Decision Tree makes predictions by asking a hierarchical sequence of yes/no questions about feature values:
1. **Root Node**: The very first question asked at the very top of the tree. Every sample starts here.
   - *Example*: "Is `petal_length <= 2.45` cm?"
2. **Internal Decision Nodes**: Subsequent questions asked if the sample follows a specific branch.
   - *Example*: "If no, is `petal_length <= 4.85` cm?"
3. **Leaf Nodes (Terminal Nodes)**: The end points of the tree where questioning stops. A leaf node contains no more branches; it issues the final class prediction.
   - *Example*: "Classify as `setosa`!"

Because each decision node is a simple inequality (`feature <= threshold`), any decision tree can be translated directly into a nested `if-elif-else` code block or printed as a clean flowchart.

### Why Interpretability Matters in the Real World
Imagine deploying an automated system:
- **In Medicine**: A doctor cannot prescribe an aggressive chemotherapy regimen simply because an algorithm said "risk score = 0.94." The physician must know which biological markers triggered the recommendation.
- **In Banking**: Under credit and lending regulations (such as the Equal Credit Opportunity Act and GDPR), financial institutions are legally required to provide "adverse action notices" explaining precisely why a loan application was rejected.
- **In Botany & Ecology**: An ecologist wants to understand the physical taxonomy separating species, not just receive a robotic label. Decision trees reveal the exact dimensional thresholds that distinguish living organisms.

## Relevant Code
In `main.py` (lines 55-56):
```python
print("\nLearned rules for the best tree:\n")
print(export_text(model, feature_names=FEATURES))
```

## Code Explanation
Scikit-learn provides the utility function `export_text()`. It takes a trained decision tree model along with the feature name strings, traverses the internal tree data structure, and outputs a clean ASCII hierarchy of if-then rules. Instead of obscure mathematical coefficients or matrix tensors, the student sees exact, readable physical thresholds printed in the console.

## Worked Example
Here is the actual decision tree rule set extracted by `export_text()` in `main.py`:
```
|--- petal_length <= 2.45
|   |--- class: setosa
|--- petal_length >  2.45
|   |--- petal_length <= 4.85
|   |   |--- class: versicolor
|   |--- petal_length >  4.85
|   |   |--- class: virginica
```
Tracing a specimen with `petal_length = 1.4`:
1. Step 1: Evaluate `petal_length <= 2.45`.
2. 1.4 is less than 2.45 (Condition True).
3. Follow the True branch: Arrive at leaf node `class: setosa`.
Prediction complete in a single question!

## Step-by-Step Student Instructions
1. Run `python main.py` in your terminal.
2. Locate the console header: `Learned rules for the best tree:`.
3. Read each line of the printed tree hierarchy.
4. Verify that only `petal_length` was chosen by the algorithm for its decision nodes, completely ignoring sepal dimensions at depth 2!
5. Trace why this makes the model completely explainable to any botanist.

## Expected Output or Observable Behaviour
The terminal displays:
```
Learned rules for the best tree:

|--- petal_length <= 2.45
|   |--- class: setosa
|--- petal_length >  2.45
|   |--- petal_length <= 4.85
|   |   |--- class: versicolor
|   |--- petal_length >  4.85
|   |   |--- class: virginica
```
This demonstrates the complete white-box transparency of the decision tree classifier.

## Practical Exercises
- **Exercise 4.1**: Convert the printed ASCII tree rules into a valid Python function `def classify_iris(petal_length):` using `if`, `elif`, and `else`.
- **Exercise 4.2**: What class would your function predict for a flower with `petal_length = 3.8`?
- **Exercise 4.3**: Name two high-stakes industries where white-box machine learning models are legally or ethically required over black-box models.

## Common Mistakes and Debugging
| Mistake | Why It Happens | Solution |
|---|---|---|
| Thinking trees can only test one feature | Seeing only `petal_length` in depth=2 | Trees *can* test multiple features, but this tree found petal length sufficient for 92% accuracy. |
| Believing decision trees are too simple for real ML | Over-indexing on deep neural networks | Trees and tree ensembles (Random Forests, XGBoost) win the majority of tabular data competitions. |
| Forgetting feature names in `export_text` | Calling `export_text(model)` without `feature_names` | Always pass `feature_names=FEATURES` so rules print human names instead of `feature_0`, `feature_2`. |

## Best Practices and Security Considerations
- **Auditing and Explainability**: Always extract and store decision rules alongside model weights during deployment to facilitate regulatory audits.
- **Tree Pruning**: Unconstrained decision trees grow massive, memorizing individual data points and losing their human interpretability. Constraining depth preserves readability.
- **Fairness & Bias Verification**: Inspecting tree thresholds allows engineers to verify that sensitive protected attributes (or their direct proxies) are not being used in unfair decision logic.

## Summary
Decision trees are premier "white-box" machine learning algorithms. Unlike inscrutable black-box neural networks, decision trees construct hierarchical if-then rules based on clear feature thresholds. This makes their predictions completely auditable, explainable, and trustworthy—essential qualities in high-stakes fields like healthcare, finance, and scientific discovery.

## Knowledge-check Questions
1. What is the fundamental difference between a white-box and a black-box machine learning model?
2. What are the three primary types of nodes in a decision tree hierarchy?
3. Which scikit-learn function generates an ASCII text summary of a decision tree's rules?
4. In the rules learned by our model, what feature and threshold isolates *Iris setosa*?
5. Why are interpretable models legally mandated in financial lending decisions?

## References
- Molnar, C. (2022). *Interpretable Machine Learning: A Guide for Making Black Box Models Explainable*. (https://christophm.github.io/interpretable-ml-book/).
- scikit-learn tree export_text documentation (https://scikit-learn.org/stable/modules/generated/sklearn.tree.export_text.html).
