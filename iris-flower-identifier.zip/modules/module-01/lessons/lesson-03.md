# Lesson 03: Multi-Class Classification: Distinguishing 3 Iris Species

**Lesson ID:** lesson-03
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define multi-class classification and distinguish it from binary classification and regression
- Name the three specific iris species in the dataset (*setosa*, *versicolor*, *virginica*)
- Explain how target labels ($y$) are represented and processed in classification tasks
- Describe the business and scientific applications of multi-class categorizers

## Prerequisites
- Completion of Lesson 01 and Lesson 02
- Basic understanding of discrete mathematical sets and categories

## Concept Explanation
### The Machine Learning Task Hierarchy
In supervised machine learning, models learn to predict an output ($y$) given a set of input features ($X$). The mathematical nature of that target determines the type of problem:
1. **Regression**: The target is a continuous numeric quantity (e.g., predicting house prices, temperature, or lemonade cup sales).
2. **Binary Classification**: The target is a discrete choice between exactly two categories (e.g., spam vs. not spam, loan approved vs. rejected, tumor malignant vs. benign).
3. **Multi-Class Classification**: The target is a discrete choice between **three or more mutually exclusive classes** (e.g., classifying animal species, optical character recognition for digits 0-9, or diagnosing disease subtypes).

```
                 Supervised Learning
                 /                 \
       Regression                   Classification
 (Predict continuous number)   (Predict discrete category)
                                    /              \
                           Binary              Multi-Class
                        (2 classes)         (3+ classes: Iris)
```

### The Three Iris Classes
The Iris Flower Identifier is a classic **multi-class classification** problem with $K = 3$ classes:
1. `setosa` (*Iris setosa*): Arctic or beachhead iris native to Alaska, northern Canada, and Siberia. Characterized by small, stubby petals.
2. `versicolor` (*Iris versicolor*): Harlequin blueflag native to eastern North America. Moderate petal size and slender growth.
3. `virginica` (*Iris virginica*): Virginia iris found in southeastern wetlands. Largest petals and broad sepals.

Each sample in `iris.csv` belongs to exactly one of these three species. The classes are mutually exclusive (a flower cannot be simultaneously *setosa* and *versicolor*) and collectively exhaustive for this benchmark.

### Handling Multi-Class Labels in scikit-learn
In older machine learning frameworks or custom algorithms, categorical text strings needed manual one-hot encoding or integer mapping (e.g., setosa=0, versicolor=1, virginica=2). One of scikit-learn's most convenient features is that its tree estimators seamlessly accept string class labels directly in the target vector $y = 	ext{df}["	ext{species}"]$. The estimator internally extracts the unique string labels, stores them in the `model.classes_` attribute, and outputs human-readable species names during prediction.

## Relevant Code
In `main.py` (lines 31-32 and 70):
```python
X = df[FEATURES]
y = df["species"]

# Checking internal model classes:
class_names = list(model.classes_)
```

## Code Explanation
Line 31 isolates the 4 numerical columns into feature matrix `X`. Line 32 isolates the `species` column into target Series `y`. When `DecisionTreeClassifier.fit(X_train, y_train)` is called, the classifier inspects `y_train` and discovers three unique strings: `'setosa'`, `'versicolor'`, and `'virginica'`. It sorts them alphabetically into `model.classes_`, preserving these human-readable names throughout visualization and prediction.

## Worked Example
Suppose an algorithm outputs probabilities for a test sample:
- $P(	ext{setosa}) = 0.00$
- $P(	ext{versicolor}) = 0.88$
- $P(	ext{virginica}) = 0.12$

In multi-class classification, the predicted class is the category associated with the maximum probability (the argmax):
$$\hat{y} = rg\max_{c \in C} P(y = c \mid X) = 	ext{versicolor}$$
The model selects `versicolor` because 88% is the highest assigned confidence.

## Step-by-Step Student Instructions
1. In your terminal, run Python interactively or execute a small one-liner:
   ```bash
   python -c "import pandas as pd; df=pd.read_csv('data/iris.csv'); print(df['species'].value_counts())"
   ```
2. Verify the output displays three species with exactly 50 samples each.
3. Check the spelling of each class label carefully: all are lowercase.

## Expected Output or Observable Behaviour
The command outputs:
```
setosa        50
versicolor    50
virginica     50
Name: species, dtype: int64
```
This confirms a balanced 3-class distribution with 50 samples per class.

## Practical Exercises
- **Exercise 3.1**: Is predicting tomorrow's temperature in Celsius regression or classification? Why?
- **Exercise 3.2**: Is predicting whether an email is "Work", "Personal", or "Spam" binary or multi-class classification?
- **Exercise 3.3**: What property of `df['species']` makes this problem multi-class rather than binary?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Solution |
|---|---|---|
| Treating species as a numeric feature | Leaving `species` in feature matrix `X` | Ensure `species` is extracted only into `y` and excluded from `X`. |
| Confusing multi-class with multi-label | In multi-label, an image can contain a cat AND a dog | In multi-class, each flower sample belongs to exactly ONE species. |
| Manually converting species to 0, 1, 2 | Thinking sklearn requires integer targets | `DecisionTreeClassifier` natively handles string labels like `'setosa'`. |

## Best Practices and Security Considerations
- **Categorical Target Integrity**: Verify that target strings do not contain leading/trailing whitespace (e.g. `'setosa '`) or case discrepancies (`'Setosa'` vs `'setosa'`).
- **Class Balance Checking**: Always run `df['species'].value_counts()` during preliminary exploratory data analysis to detect potential class skews early.
- **Fair Representation**: When building multi-class systems for real-world domains (e.g., facial recognition or language classification), ensure equitable training representation across all demographic subgroups.

## Summary
Multi-class classification involves categorizing samples into one of three or more mutually exclusive classes. The Iris Flower Identifier classifies flowers into three species: *Iris setosa*, *Iris versicolor*, and *Iris virginica*. Scikit-learn's `DecisionTreeClassifier` natively handles string class labels, learning decision boundaries that separate multiple classes simultaneously.

## Knowledge-check Questions
1. How does multi-class classification differ fundamentally from binary classification?
2. What are the names of the three species in the Iris dataset?
3. How many observations exist for each species in `iris.csv`?
4. What attribute on a trained scikit-learn model stores the array of learned target class names?
5. Does scikit-learn require you to convert string class labels into integers before passing them to `DecisionTreeClassifier`?

## References
- scikit-learn Multiclass and multioutput algorithms (https://scikit-learn.org/stable/modules/multiclass.html).
- Hastie, T., Tibshirani, R., & Friedman, J. (2009). *The Elements of Statistical Learning*. Springer. Chapter 4: Linear Methods for Classification.
