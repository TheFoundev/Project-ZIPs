# Lesson 02: Flower Anatomy: Sepals vs. Petals and 4 Physical Dimensions

**Lesson ID:** lesson-02
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Distinguish the botanical difference between a flower's sepals and petals
- Identify the four physical dimensions measured for each flower in centimeters
- Explain why physical morphology serves as the input feature space for machine learning algorithms
- Describe how calipers and continuous numeric measurements represent biological diversity

## Prerequisites
- Completion of Lesson 01 (The Famous Iris Dataset)
- Elementary understanding of centimeters and geometric measurements (length vs. width)

## Concept Explanation
### Botanical Morphology: Sepals vs. Petals
When studying flowering plants (angiosperms), casual observers often refer to all colored structures as "petals." In botanical taxonomy, however, flowers possess distinct anatomical whorls:
- **Sepals**: The outermost whorl of floral structures. In many flowers, sepals are green, leaf-like scales that encase and protect the flower bud before it opens. In the genus *Iris*, however, the sepals are enlarged, showy, and brightly colored, spreading downward or drooping outward (often called "falls" by horticulturists).
- **Petals**: The inner whorl of floral structures (often called "standards" in irises), typically growing more upright and delicate. Petals evolved primarily to attract insect pollinators like bees.

Because both sepals and petals are distinct organs with unique evolutionary pressures, their physical dimensions vary significantly between iris species.

```
      Iris Flower Anatomy
       
          /|  |\        <-- Petals (Upright Standards)
         / |  | \
        |  |  |  |
        |  |  |  |
       (    ||    )
      / \  ||  / \    <-- Sepals (Drooping Falls)
     /   \ || /   \
```

### The Four Morphological Dimensions
For every single flower in the dataset, Edgar Anderson measured four continuous numeric traits:
1. `sepal_length`: Distance from the base of the sepal to its outermost tip (in cm).
2. `sepal_width`: Maximum horizontal width across the sepal (in cm).
3. `petal_length`: Distance from the base of the petal to its outermost apex (in cm).
4. `petal_width`: Maximum horizontal width across the petal (in cm).

All four traits are recorded as continuous floating-point numbers with single-millimeter precision (e.g., 5.1 cm, 3.5 cm). In data science terminology, these four physical dimensions form our **4-dimensional feature vector**.

## Relevant Code
In `main.py` (lines 26 and 31):
```python
FEATURES = ["sepal_length", "sepal_width", "petal_length", "petal_width"]

def main() -> None:
    df = pd.read_csv(DATA / "iris.csv")
    X = df[FEATURES]
```

## Code Explanation
Line 26 defines `FEATURES` as an explicit Python list containing the four column strings. Grouping feature column names into an immutable constant list is an established software engineering best practice. In line 31, pandas uses this list to slice the DataFrame, creating `X`, a two-dimensional tabular feature matrix containing 150 rows and exactly 4 columns.

## Worked Example
Let us compare typical measurements across the three species:
- **Iris setosa**:
  - Petal length: Typically 1.0 to 1.9 cm (very small, stubby petals)
  - Petal width: Typically 0.1 to 0.6 cm (very narrow)
  - Sepal width: Typically 2.9 to 4.4 cm (relatively wide sepals)
- **Iris versicolor**:
  - Petal length: Typically 3.0 to 5.1 cm (medium-sized petals)
  - Petal width: Typically 1.0 to 1.8 cm (medium width)
- **Iris virginica**:
  - Petal length: Typically 4.5 to 6.9 cm (long, grand petals)
  - Petal width: Typically 1.4 to 2.5 cm (broad petals)

Notice how petal length alone forms almost non-overlapping ranges between *setosa* (1.0-1.9 cm) and the others (> 3.0 cm). This morphological contrast is the foundation for decision tree threshold splits.

## Step-by-Step Student Instructions
1. Open `main.py` and locate line 26 where `FEATURES` is defined.
2. Note the spelling of all four features: underscores are used instead of hyphens or spaces.
3. Using python in your terminal, verify the column types:
   ```bash
   python -c "import pandas as pd; df=pd.read_csv('data/iris.csv'); print(df.dtypes)"
   ```
4. Observe that all 4 features are `float64`, while `species` is `object` (string).

## Expected Output or Observable Behaviour
Running the inspection command shows:
```
sepal_length    float64
sepal_width     float64
petal_length    float64
petal_width     float64
species          object
dtype: object
```
This confirms that our four physical dimensions are numeric continuous floats suitable for mathematical comparison.

## Practical Exercises
- **Exercise 2.1**: Name the four physical measurements taken for each flower and give their unit of measurement.
- **Exercise 2.2**: Why are botanical measurements recorded in centimeters rather than categorical tags like "small", "medium", or "large"? (Continuous numeric values provide precise mathematical thresholds for decision tree splits).
- **Exercise 2.3**: What is the anatomical difference between an iris sepal and an iris petal?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Solution |
|---|---|---|
| Confusing sepals with stems | Sepals are floral leaves, not the plant stem or stalk | Sepals form the outer ring of colorful drooping petals in irises. |
| Swapping length and width | Careless column indexing when creating new samples | Always maintain consistent feature ordering: `sepal_length`, `sepal_width`, `petal_length`, `petal_width`. |
| Treating features as integers | Forgetting millimeter precision | Measurements like 5.1 cm or 0.2 cm are floating-point numbers, not discrete integers. |

## Best Practices and Security Considerations
- **Consistent Feature Naming**: Standardize feature names with lower_case_snake_convention to avoid whitespace issues in pandas queries.
- **Unit Awareness**: In real-world data pipelines, always document whether dimensions are in millimeters, centimeters, or inches to prevent catastrophic unit mismatch errors.
- **Data Validation**: When accepting user input for new flowers, enforce non-negative float ranges (e.g., rejecting negative petal lengths).

## Summary
The Iris dataset captures four physical measurements—sepal length, sepal width, petal length, and petal width—recorded in centimeters. In botany, sepals protect the unopened bud while petals attract pollinators. In machine learning, these four dimensions form the 4-dimensional feature vector ($X$) that enables algorithms to distinguish plant species with mathematical precision.

## Knowledge-check Questions
1. What does the acronym/unit "cm" stand for in the dataset?
2. What are the four specific physical features measured for each flower?
3. Which botanical structure forms the outer protective whorl of an iris flower?
4. Are the morphological dimensions stored as integers, booleans, or floating-point numbers?
5. Why are continuous numerical measurements preferred over subjective descriptors like "long" or "short"?

## References
- Botanical Society of America: Flower Anatomy Guide (https://botany.org).
- scikit-learn Iris Dataset Documentation (https://scikit-learn.org/stable/auto_examples/datasets/plot_iris_dataset.html).
