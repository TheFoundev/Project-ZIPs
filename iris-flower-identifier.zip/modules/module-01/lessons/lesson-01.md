# Lesson 01: The Famous Iris Dataset & Ronald Fisher's 1936 Benchmark

**Lesson ID:** lesson-01
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Trace the historical origins of the Iris dataset published by Ronald A. Fisher in 1936
- Explain why the Iris dataset became the foundational "Hello World" benchmark for machine learning and pattern recognition
- Identify the dataset scale: 150 total records spanning 3 distinct botanical species
- Appreciate the balance between simplicity and realistic feature overlap that makes Iris ideal for learning decision trees

## Prerequisites
- Familiarity with basic data tables containing rows and columns
- An understanding of basic biological species categories

## Concept Explanation
### The Genesis of Modern Machine Learning Data
In 1936, the British statistician and evolutionary biologist Ronald Aylmer Fisher published a paper titled *"The use of multiple measurements in taxonomic problems"* in the *Annals of Eugenics*. In this historic paper, Fisher introduced linear discriminant analysis to determine whether physical measurements could differentiate biological species. The empirical data used in the paper had been collected in Quebec's Gaspé Peninsula by the renowned botanist Edgar Anderson.

Anderson carefully collected 50 wild iris flowers from each of three related species:
1. *Iris setosa*
2. *Iris versicolor*
3. *Iris virginica*

For each individual flower, Anderson measured four specific morphological characteristics: sepal length, sepal width, petal length, and petal width, recorded meticulously in centimeters.

### Why Did the Iris Dataset Become Immortal in Machine Learning?
Almost ninety years later, the Iris dataset remains the standard introductory dataset across computer science, data science, and artificial intelligence courses worldwide. There are three key reasons for this enduring longevity:
1. **Manageable Dimensions**: With 150 rows and 4 feature columns, the dataset is lightweight enough to inspect entirely in a spreadsheet or small terminal window, with zero loading latency.
2. **Perfect Class Balance**: The dataset contains exactly 50 instances of each species, meaning learners do not have to struggle with severe class imbalance on their first machine learning project.
3. **Didactic Geometric Separation**: One species (*Iris setosa*) is completely linearly separable from the other two based on simple petal measurements. However, *Iris versicolor* and *Iris virginica* have slight natural overlap. This makes the dataset challenging enough to demonstrate boundary errors, threshold selection, and overfitting without overwhelming the student.

## Relevant Code
In `main.py` (lines 1-8 and 30):
```python
"""Project 14: The Iris Flower Identifier (decision tree).

Run:
    python main.py

The classic 150-row Iris dataset. The decision tree is drawn as a flowchart
so every prediction can be traced back to a readable rule.
"""

# Loading the dataset inside main():
df = pd.read_csv(DATA / "iris.csv")
```

## Code Explanation
The docstring immediately establishes the educational context: this project operates on the classic 150-row Iris dataset. It specifies the chosen algorithm—a Decision Tree—and explains why this algorithm was selected: it can be rendered directly as a flowchart so that every single prediction made by the computer can be traced back to an explicit, human-readable rule. Line 30 uses `pd.read_csv()` to load the historical observations from `data/iris.csv` into memory.

## Worked Example
Consider an ecologist in the field who discovers an unidentified iris blossom. They use calipers to measure:
- Sepal length: 5.0 cm
- Sepal width: 3.5 cm
- Petal length: 1.4 cm
- Petal width: 0.2 cm

Looking back at Fisher's 1936 baseline data:
- *Iris setosa* specimens have an average petal length of approximately 1.46 cm.
- *Iris versicolor* petals average 4.26 cm.
- *Iris virginica* petals average 5.55 cm.

Without running a complex algorithm, a human botanist immediately notes that a 1.4 cm petal is distinctly *Iris setosa*. Machine learning decision trees automate and codify this exact diagnostic process.

## Step-by-Step Student Instructions
1. Open your terminal and navigate to the project directory: `cd beginner-projects-main/AI-ML\ Beginners/projects/14_iris_identifier`.
2. Inspect the project docstring by viewing the first 10 lines of `main.py`.
3. Open `data/iris.csv` in a text editor or run `head -n 10 data/iris.csv` in the terminal.
4. Count the header columns: verify there are 4 numerical measurements and 1 species label.
5. Notice that the first several rows all list `species` as `setosa`.

## Expected Output or Observable Behaviour
When inspecting the first few lines of `data/iris.csv`, you will see:
```csv
sepal_length,sepal_width,petal_length,petal_width,species
5.1,3.5,1.4,0.2,setosa
4.9,3.0,1.4,0.2,setosa
4.7,3.2,1.3,0.2,setosa
4.6,3.1,1.5,0.2,setosa
5.0,3.6,1.4,0.2,setosa
```
This confirms that the raw data matches Fisher's historical botanical measurements.

## Practical Exercises
- **Exercise 1.1**: Calculate the total number of data cells in `iris.csv` (150 rows × 5 columns = 750 data points).
- **Exercise 1.2**: If you randomly sampled one flower from the dataset without replacement, what is the probability that it belongs to *Iris virginica*? (50/150 = 1/3 or 33.33%).
- **Exercise 1.3**: Explain in two sentences why high class balance (equal samples per category) is beneficial when first learning classification algorithms.

## Common Mistakes and Debugging
| Mistake | Why It Happens | Solution |
|---|---|---|
| Assuming Iris has 10,000+ rows | Confusing modern web datasets with historic benchmarks | Remember Iris has exactly 150 rows; small datasets require careful overfitting control. |
| Expecting 2 classes (binary) | Most introductory ML examples use binary classification | Iris has 3 classes (*setosa*, *versicolor*, *virginica*); multi-class classification is required. |
| Forgetting Edgar Anderson | Fisher wrote the statistical paper, but Anderson gathered the flowers | Recognize Anderson's botanical fieldwork in Quebec as the source of the data. |

## Best Practices and Security Considerations
- **Historical Data Integrity**: Never alter the original raw benchmark data; always maintain an immutable reference copy in `data/`.
- **Reproducibility**: When dealing with benchmark datasets, always report exact random seeds so that your splits and accuracy numbers match published literature.
- **Privacy & Security**: The Iris dataset contains purely open botanical measurements, presenting zero personally identifiable information (PII) or ethical compliance risks.

## Summary
The Iris dataset, introduced by Ronald A. Fisher in 1936 using Edgar Anderson's botanical measurements, is the foundational benchmark of machine learning. It contains 150 samples evenly divided across three species (*setosa*, *versicolor*, *virginica*), each quantified by four continuous features. Its balance of clean separability for *setosa* and subtle overlap between *versicolor* and *virginica* makes it the ideal domain for studying decision tree logic.

## Knowledge-check Questions
1. In what year did Ronald Fisher publish the Iris dataset?
2. How many total flowers are documented in the Iris dataset?
3. How many distinct species are represented, and how many flowers belong to each species?
4. Which botanist collected the physical specimens in the Gaspé Peninsula?
5. Why is the Iris dataset referred to as a "benchmark" in machine learning?

## References
- Fisher, R. A. (1936). *The use of multiple measurements in taxonomic problems*. Annals of Eugenics, 7(2), 179-188.
- Anderson, E. (1936). *The species problem in Iris*. Annals of the Missouri Botanical Garden, 23(3), 457-509.
- UCI Machine Learning Repository: Iris Dataset (https://archive.ics.uci.edu/dataset/53/iris).
