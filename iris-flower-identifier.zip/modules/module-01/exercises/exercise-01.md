# Module 1 Exercises: Iris Overview & Decision Tree Principles

## Exercise 1.1: Historical Context & Dataset Dimensions (10 min)
**Objective:** Verify understanding of Ronald Fisher's 1936 benchmark dataset and its basic structure.
**Problem Statement:** A data scientist needs to confirm the scale, composition, and historical context of the Iris dataset before writing any machine learning code.

**Requirements:**
1. State the year the Iris dataset was published and the author who introduced it to statistics.
2. State the total number of flower samples in `data/iris.csv`.
3. List the three target species and state how many samples represent each species.
4. Calculate the dataset's class balance ratio (e.g., 1:1:1).

**Constraints:** Base answers on `data/iris.csv` and historical facts from Lesson 01.

**Expected Behaviour:** A concise summary answering all 4 points with exact numerical counts.

**Acceptance Criteria:**
- [ ] Correctly identifies Ronald A. Fisher (1936) and botanist Edgar Anderson
- [ ] States total sample count is exactly 150
- [ ] Lists `setosa`, `versicolor`, and `virginica` with exactly 50 samples each
- [ ] Confirms the dataset is perfectly balanced (33.3% per class)

**Hints:**
- Run `wc -l data/iris.csv` in terminal (subtract 1 for the header line).
- Inspect `df['species'].value_counts()`.

**Difficulty:** Basic
**Estimated Completion Time:** 10 minutes

---

## Exercise 1.2: Flower Anatomy & Feature Mapping (15 min)
**Objective:** Map physical flower anatomy to scikit-learn feature columns.
**Problem Statement:** You are handed an iris flower and calipers. You need to map your physical measurements to the exact variable names used in `main.py`.

**Requirements:**
1. Identify the anatomical difference between an iris sepal and an iris petal.
2. List the four exact feature column names used in `main.py` in the exact order specified by `FEATURES`.
3. Specify the unit of measurement used for all four traits.
4. Explain why these traits are continuous numeric variables rather than discrete categories.

**Constraints:** Follow the exact variable names in `main.py` line 26.

**Expected Behaviour:** Written response providing anatomical definitions, the exact Python list `FEATURES`, and unit specifications.

**Acceptance Criteria:**
- [ ] Sepal defined as outer whorl/falls; petal defined as inner whorl/standards
- [ ] Exact list matches: `["sepal_length", "sepal_width", "petal_length", "petal_width"]`
- [ ] Measurement units specified as centimeters (cm)
- [ ] Continuous numeric property explained (infinite precision along a real number continuum)

**Hints:**
- Look at line 26 of `main.py`.
- Features use lowercase snake_case.

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 1.3: Classification vs. Regression Taxonomy (10 min)
**Objective:** Formally categorize machine learning task types.
**Problem Statement:** Given three hypothetical data science tasks for a botanical nursery, classify each task as Regression, Binary Classification, or Multi-Class Classification.

**Requirements:**
1. Task A: Predicting the auction selling price of an exotic orchid in dollars ($).
2. Task B: Determining whether an iris plant is infected with leaf fungal disease (Infected vs. Healthy).
3. Task C: Classifying an unknown iris specimen as *setosa*, *versicolor*, or *virginica*.
4. Justify each classification based on the mathematical nature of target variable $y$.

**Constraints:** Provide clear justifications referencing continuous numeric vs. discrete categorical labels.

**Expected Behaviour:** A structured table or list identifying the problem type for each scenario with justification.

**Acceptance Criteria:**
- [ ] Task A classified as Regression (continuous dollar amount)
- [ ] Task B classified as Binary Classification (2 mutually exclusive classes)
- [ ] Task C classified as Multi-Class Classification (3 mutually exclusive species)
- [ ] Clear distinction between numeric quantities and discrete labels articulated

**Hints:**
- If target is a number you can measure with a scale or ruler -> Regression.
- If target is a choice between 2 labels -> Binary.
- If target is a choice between 3+ labels -> Multi-Class.

**Difficulty:** Intermediate
**Estimated Completion Time:** 10 minutes

---

## Exercise 1.4: Manual Decision Logic Tracing (15 min)
**Objective:** Trace unseen samples through decision tree rules manually.
**Problem Statement:** Given the learned decision rules from `main.py`:
```
|--- petal_length <= 2.45
|   |--- class: setosa
|--- petal_length >  2.45
|   |--- petal_length <= 4.85
|   |   |--- class: versicolor
|   |--- petal_length >  4.85
|   |   |--- class: virginica
```
Classify three new botanical observations manually.

**Requirements:**
1. Flower Alpha: `sepal_length=6.1, sepal_width=3.0, petal_length=1.3, petal_width=0.2`
2. Flower Beta: `sepal_length=5.9, sepal_width=2.8, petal_length=4.2, petal_width=1.3`
3. Flower Gamma: `sepal_length=7.2, sepal_width=3.6, petal_length=6.1, petal_width=2.5`
4. Document the exact node traversal path for each flower.
5. Explain why the values of `sepal_length`, `sepal_width`, and `petal_width` did not affect the classification outcome.

**Constraints:** Rely strictly on the printed rules from `main.py`.

**Expected Behaviour:** Step-by-step trace showing which inequality was evaluated and the resulting classification for all 3 flowers.

**Acceptance Criteria:**
- [ ] Flower Alpha classified as `setosa` via `petal_length <= 2.45` (1.3 <= 2.45)
- [ ] Flower Beta classified as `versicolor` via `petal_length > 2.45` and `<= 4.85` (4.2)
- [ ] Flower Gamma classified as `virginica` via `petal_length > 4.85` (6.1 > 4.85)
- [ ] Accurately notes that at `max_depth=2`, the model splits solely on `petal_length`, ignoring the other 3 features

**Hints:**
- Look only at `petal_length` for each flower.
- Compare against thresholds 2.45 and 4.85.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes
