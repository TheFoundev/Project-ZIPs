# Module 5 Exercises: Evaluation, Classification Report & Confusion Matrix

## Exercise 5.1: Manual Calculation of Precision, Recall, and F1 (15 min)
**Objective:** Calculate precision, recall, and F1-score by hand using confusion matrix counts.
**Problem Statement:** Given the test set confusion matrix:
```
              setosa  versicolor  virginica
  setosa        12         0          0
versicolor       0        12          1
 virginica       0         2         11
```
Calculate per-class metrics for *Iris versicolor*.

**Requirements:**
1. Identify True Positives (TP) for versicolor.
2. Identify False Positives (FP) for versicolor (samples predicted as versicolor that were actually other species).
3. Identify False Negatives (FN) for versicolor (actual versicolor samples predicted as other species).
4. Compute Precision to 2 decimal places: $\text{TP} / (\text{TP} + \text{FP})$.
5. Compute Recall to 2 decimal places: $\text{TP} / (\text{TP} + \text{FN})$.
6. Compute F1-score to 2 decimal places: $2 \times (\text{P} \times \text{R}) / (\text{P} + \text{R})$.

**Constraints:** Verify your calculations match `classification_report` output from `main.py`.

**Expected Behaviour:** Step-by-step arithmetic derivation.

**Acceptance Criteria:**
- [ ] $\text{TP} = 12$
- [ ] $\text{FP} = 2$ (2 virginica flowers misclassified as versicolor)
- [ ] $\text{FN} = 1$ (1 versicolor flower misclassified as virginica)
- [ ] $\text{Precision} = 12 / (12 + 2) = 12/14 \approx 0.86$
- [ ] $\text{Recall} = 12 / (12 + 1) = 12/13 \approx 0.92$
- [ ] $\text{F1} = 2 \times (0.857 \times 0.923) / (0.857 + 0.923) \approx 0.89$

**Hints:**
- Look at the column for versicolor to find FP.
- Look at the row for versicolor to find FN.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 5.2: Parsing and Auditing outputs/rules.txt (10 min)
**Objective:** Write a Python test script that audits the contents of `outputs/rules.txt`.
**Problem Statement:** In an automated CI/CD pipeline, write a test to verify that `rules.txt` was generated properly and contains expected keywords.

**Requirements:**
1. Check that `outputs/rules.txt` exists on disk.
2. Read the file contents.
3. Assert that the string `"best depth: 2"` exists in the text.
4. Assert that `"petal_length <= 2.45"` exists in the text.
5. Assert that `"new flower prediction: versicolor"` exists in the text.

**Constraints:** Use Python's `pathlib.Path` and `assert`.

**Expected Behaviour:** A Python script that executes silently and exits with status 0 upon assertion success.

**Acceptance Criteria:**
- [ ] Script reads `outputs/rules.txt`
- [ ] All 3 string assertions pass
- [ ] Clear printed confirmation: `"All rules.txt audit assertions passed!"`

**Hints:**
- Use `Path("outputs/rules.txt").read_text(encoding="utf-8")`.

**Difficulty:** Basic
**Estimated Completion Time:** 10 minutes

---

## Exercise 5.3: Customizing ConfusionMatrixDisplay (15 min)
**Objective:** Render a customized confusion matrix plot with normalized values.
**Problem Statement:** Modify lines 82-89 of `main.py` to produce a normalized confusion matrix where cells show percentages rather than raw integer counts.

**Requirements:**
1. Compute `cm_norm = confusion_matrix(y_test, predictions, labels=labels, normalize="true")`.
2. Render with `ConfusionMatrixDisplay(cm_norm, display_labels=labels).plot(cmap="Blues", values_format=".1%")`.
3. Set title to `"Normalized Iris Confusion Matrix"`.
4. Save to `outputs/confusion_matrix_normalized.png`.

**Constraints:** Ensure Matplotlib uses `"Agg"` backend.

**Expected Behaviour:** A customized blue heatmap displaying percentages (e.g. 100.0%, 92.3%, 84.6%).

**Acceptance Criteria:**
- [ ] Normalized confusion matrix displays percentages
- [ ] Colormap is `"Blues"`
- [ ] Image saved to `outputs/confusion_matrix_normalized.png`
- [ ] Setosa shows 100.0% diagonal, Versicolor shows 92.3%, Virginica shows 84.6%

**Hints:**
- Pass `values_format=".1%"` to `.plot()`.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 5.4: Macro vs Weighted Average Mathematical Proof (15 min)
**Objective:** Prove mathematically why macro and weighted averages converge when classes are balanced.
**Problem Statement:** Demonstrate using the Iris support counts why macro average and weighted average yield identical 0.92 scores.

**Requirements:**
1. Write the general formula for Macro F1.
2. Write the general formula for Weighted F1.
3. Plug in the project values: $F1 = [1.00, 0.89, 0.88]$ and $\text{support} = [12, 13, 13]$.
4. Explain what happens to the formulas when class sample sizes $N_1 = N_2 = N_3$.

**Constraints:** Show all algebraic steps.

**Expected Behaviour:** Written mathematical proof.

**Acceptance Criteria:**
- [ ] Correctly derives Macro average as $(1.00 + 0.89 + 0.88) / 3 = 0.923$
- [ ] Correctly derives Weighted average as $(12(1.00) + 13(0.89) + 13(0.88)) / 38 = (12 + 11.57 + 11.44) / 38 = 35.01 / 38 = 0.921$
- [ ] Proves that when $N_k$ are equal, weighted average reduces exactly to macro average

**Hints:**
- Total support is $12 + 13 + 13 = 38$.

**Difficulty:** Advanced
**Estimated Completion Time:** 15 minutes
