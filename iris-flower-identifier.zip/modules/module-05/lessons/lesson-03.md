# Lesson 03: Diagnosing Misclassifications with the Confusion Matrix

**Lesson ID:** lesson-03
**Module:** module-05
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Compute and interpret a multi-class confusion matrix
- Distinguish between diagonal elements (correct predictions) and off-diagonal elements (errors)
- Identify the exact nature of boundary confusion between *versicolor* and *virginica*
- Use scikit-learn's `ConfusionMatrixDisplay` to plot and save a visual heatmap

## Prerequisites
- Completion of Lesson 01 and Lesson 02
- Familiarity with 2D matrices and row/column indexing

## Concept Explanation
### The Diagnostic Tool: The Confusion Matrix
A classification report tells you *how many* errors occurred, but it cannot tell you *which species was confused with which*.
A **Confusion Matrix** is a square $K 	imes K$ grid (where $K$ is the number of classes) that maps actual true labels along the rows and predicted labels along the columns:
- **Rows**: The ground-truth actual species in the test set.
- **Columns**: The species predicted by the trained model.
- **The Main Diagonal (Top-Left to Bottom-Right)**: Correct predictions where actual equals predicted.
- **Off-Diagonal Cells**: Errors and cross-species confusions.

```
                  Predicted Species
               setosa  versicolor  virginica
             +------------------------------+
    setosa   |   12         0          0    |  <-- 12 True Setosa (12 correct)
A            |                              |
c versicolor |    0        12          1    |  <-- 13 True Versicolor (12 correct, 1 mistaken for virginica)
t            |                              |
u  virginica |    0         2         11    |  <-- 13 True Virginica (11 correct, 2 mistaken for versicolor)
a            +------------------------------+
l
```

### Analyzing the Project's Confusion Matrix
Let us analyze the numbers in our project:
1. **Row 1 (`setosa`, 12 samples)**:
   - Predicted as setosa: **12**
   - Predicted as versicolor: **0**
   - Predicted as virginica: **0**
   - *Diagnosis*: 100% correct. Setosa is completely isolated with zero false positives and zero false negatives.
2. **Row 2 (`versicolor`, 13 samples)**:
   - Predicted as setosa: **0**
   - Predicted as versicolor: **12**
   - Predicted as virginica: **1**
   - *Diagnosis*: 12 out of 13 were correctly identified. Exactly 1 *versicolor* flower had unusually long petals and was misclassified as *virginica*.
3. **Row 3 (`virginica`, 13 samples)**:
   - Predicted as setosa: **0**
   - Predicted as versicolor: **2**
   - Predicted as virginica: **11**
   - *Diagnosis*: 11 out of 13 were correctly identified. Exactly 2 *virginica* flowers had shorter petals and were misclassified as *versicolor*.

### Biological Takeaway
Notice that the first column and first row for *setosa* contain zeros in all off-diagonal cells! There is **zero confusion** between *setosa* and any other flower.
All 3 misclassifications in the entire project occurred strictly between *versicolor* and *virginica*. This perfectly reflects real-world evolutionary biology: *Iris versicolor* and *Iris virginica* are closely related species whose morphological measurements naturally overlap along their evolutionary boundary.

## Relevant Code
In `main.py` (lines 82-89):
```python
    # ---- Confusion matrix ---------------------------------------------
    labels = sorted(df["species"].unique())
    cm = confusion_matrix(y_test, predictions, labels=labels)
    fig, ax = plt.subplots(figsize=(5.5, 4.5))
    ConfusionMatrixDisplay(cm, display_labels=labels).plot(ax=ax, cmap="Greens", colorbar=False)
    ax.set_title("Iris classification results")
    fig.tight_layout()
    fig.savefig(OUT / "confusion_matrix.png", dpi=150, bbox_inches="tight")
    plt.close(fig)
```

## Code Explanation
Line 82 extracts unique class strings and sorts them alphabetically: `['setosa', 'versicolor', 'virginica']`. Line 83 calls `confusion_matrix(y_test, predictions, labels=labels)`. Passing explicit `labels` guarantees that rows and columns follow identical alphabetical ordering. Line 85 uses `ConfusionMatrixDisplay` to render the matrix with a pleasing green colormap (`cmap="Greens"`), disabling the redundant colorbar. Line 88 saves the graphic to `outputs/confusion_matrix.png`.

## Worked Example
Let us compute the confusion matrix manually from raw test arrays:
```python
import numpy as np

# Total correct = sum of diagonal:
diagonal_sum = 12 + 12 + 11  # = 35
total_samples = 38
accuracy = diagonal_sum / total_samples
print(f"Diagonal Correct: {diagonal_sum}/{total_samples} = {accuracy:.1%}")

# Total off-diagonal errors:
off_diagonal = 0 + 0 + 0 + 1 + 0 + 2  # = 3 mistakes
print(f"Total Misclassifications: {off_diagonal}")
```
Output:
```
Diagonal Correct: 35/38 = 92.1%
Total Misclassifications: 3
```
This confirms that the confusion matrix directly accounts for every single sample in the 92.1% accuracy calculation!

## Step-by-Step Student Instructions
1. Run `python main.py` in your terminal.
2. Open `outputs/confusion_matrix.png` in an image previewer.
3. Locate the main diagonal cells: notice the dark green shading on numbers 12, 12, and 11.
4. Locate the error cells: find the cell showing `1` (versicolor actual, virginica predicted).
5. Find the cell showing `2` (virginica actual, versicolor predicted).
6. Verify that the entire row and column for *setosa* contains zeros outside the diagonal.

## Expected Output or Observable Behaviour
Opening `outputs/confusion_matrix.png` displays a 3x3 grid:
- `(setosa, setosa)` = 12 (Dark Green)
- `(versicolor, versicolor)` = 12 (Dark Green)
- `(virginica, virginica)` = 11 (Dark Green)
- `(versicolor, virginica)` = 1 (Light Green / White)
- `(virginica, versicolor)` = 2 (Light Green / White)
- All other cells = 0 (White)

## Practical Exercises
- **Exercise 3.1**: What is the sum of the numbers in the second row of the confusion matrix? What does this sum represent? (12 + 1 = 13; the total number of true versicolor samples in the test set).
- **Exercise 3.2**: How many actual *virginica* flowers were misclassified as *versicolor*?
- **Exercise 3.3**: Why is `labels=sorted(df["species"].unique())` passed explicitly to `confusion_matrix`?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Solution |
|---|---|---|
| Inverting rows and columns | Confusing actual vs predicted axes | Remember: rows are actual truth ($y$), columns are predictions ($\hat{y}$). |
| Mismatched label ordering | Omitting `labels=labels` | Pass explicit sorted labels to ensure identical row/column alignment. |
| Forgetting `colorbar=False` | Default Matplotlib colorbars can distort layout | Set `colorbar=False` for cleaner compact visualization. |

## Best Practices and Security Considerations
- **Heatmap Color Intensity**: Choose accessible, intuitive colormaps (e.g. Greens or Blues) where darker saturation corresponds to higher sample counts.
- **Auditing Asymmetric Error Costs**: If misclassifying versicolor as virginica carried severe ecological penalties, inspecting the confusion matrix allows targeted threshold tuning.
- **Normalization Option**: For imbalanced datasets, pass `normalize='true'` to view per-class percentages rather than raw integer counts.

## Summary
The confusion matrix is the definitive diagnostic visualization for classification systems. Mapping actual truth against model predictions reveals that the decision tree achieved 100% accuracy on *setosa* (12/12) and made only 3 total errors across the overlapping boundary of *versicolor* (1 misclassified as virginica) and *virginica* (2 misclassified as versicolor). `ConfusionMatrixDisplay` renders these insights into a clean, presentation-ready heatmap.

## Knowledge-check Questions
1. In a confusion matrix, what do the rows and columns represent?
2. What do numbers along the main diagonal (top-left to bottom-right) indicate?
3. How many total misclassifications occurred in the 38-sample test set?
4. Which two species experienced misclassifications?
5. How many actual *setosa* flowers were misclassified as other species?

## References
- scikit-learn ConfusionMatrixDisplay API documentation (https://scikit-learn.org/stable/modules/generated/sklearn.metrics.ConfusionMatrixDisplay.html).
- Stehman, S. V. (1997). *Selecting and using an accuracy measure to evaluate thematic accuracy of land cover maps*. Remote Sensing of Environment, 62(1), 77-89.
