# Lesson 04: Exporting Production Artifacts to rules.txt

**Lesson ID:** lesson-04
**Module:** module-05
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Document machine learning experiments into persistent, human-readable text files
- Write structured evaluation reports combining hyperparameters, metrics, and text rules
- Parse and audit the contents of `outputs/rules.txt`
- Appreciate the importance of reproducible artifact management in machine learning engineering (MLOps)

## Prerequisites
- Completion of Lessons 01, 02, and 03
- Basic understanding of Python file I/O (`with open(...) as handle:`)

## Concept Explanation
### Why MLOps Demands Persistent Artifacts
In professional software and machine learning engineering (MLOps), training a model and simply printing numbers to the terminal is unacceptable. Once the terminal closes, the experimental logs vanish. If a model is deployed to production, engineers need a version-controlled, immutable paper trail that answers:
1. What hyperparameters were tested, and what were their exact benchmark scores?
2. Which hyperparameter configuration was chosen as the winning production model?
3. What exact decision logic and thresholds did the winning model learn?
4. What prediction was issued for reference test specimens?
5. What was the detailed per-class classification report?

In `main.py`, lines 91-98 solve this by generating `outputs/rules.txt`.

```
+-------------------------------------------------------------+
|              outputs/rules.txt Anatomy                      |
+-------------------------------------------------------------+
| Section 1: Depth Benchmark Comparison                        |
|   depth=2: accuracy=0.9211                                  |
|   depth=3: accuracy=0.8947                                  |
|   depth=None: accuracy=0.8947                               |
|                                                             |
| Section 2: Winning Hyperparameter                           |
|   best depth: 2                                             |
|                                                             |
| Section 3: Learned Decision Rules                           |
|   |--- petal_length <= 2.45                                 |
|   |   |--- class: setosa                                    |
|   |--- petal_length >  2.45                                 |
|   |   |--- petal_length <= 4.85                             |
|   |   |   |--- class: versicolor                            |
|   |   |--- petal_length >  4.85                             |
|   |   |   |--- class: virginica                             |
|                                                             |
| Section 4: Sample Prediction Verification                   |
|   new flower prediction: versicolor                         |
|                                                             |
| Section 5: Exhaustive Classification Report                 |
|                 precision    recall  f1-score   support     |
|         setosa       1.00      1.00      1.00        12     |
|     versicolor       0.86      0.92      0.89        13     |
|      virginica       0.92      0.85      0.88        13     |
+-------------------------------------------------------------+
```

### Python File I/O: Safe Context Managers
To write to disk safely without resource leaks, Python provides the `with open(...)` context manager:
```python
with open(OUT / "rules.txt", "w", encoding="utf-8") as handle:
    # write operations...
```
Using `with open`:
- Opens the destination file in write mode (`"w"`), creating it if it does not exist or overwriting it cleanly.
- Specifies `encoding="utf-8"` to guarantee cross-platform text encoding consistency across Windows, Linux, and macOS.
- Automatically flushes buffers and closes the file handle when the block terminates, even if an exception occurs inside the block.

## Relevant Code
In `main.py` (lines 91-98):
```python
    with open(OUT / "rules.txt", "w", encoding="utf-8") as handle:
        for depth, (_, _, acc) in models.items():
            handle.write(f"depth={depth}: accuracy={acc:.4f}\n")
        handle.write(f"\nbest depth: {best_depth}\n\n")
        handle.write(export_text(model, feature_names=FEATURES))
        handle.write(f"\nnew flower prediction: {new_species}\n")
        handle.write("\n" + classification_report(y_test, predictions, zero_division=0))
```

## Code Explanation
Line 91 opens `outputs/rules.txt`. Lines 92-93 iterate through the `models` dictionary, formatting each depth and its accuracy float to 4 decimal places (`{acc:.4f}`). Line 94 writes the selected `best_depth`. Line 95 writes the ASCII rules extracted by `export_text()`. Line 96 writes the predicted species for `new_flower`. Line 97 appends the complete multi-class `classification_report`.

## Worked Example
Let us inspect the exact file created on disk:
```bash
cat outputs/rules.txt
```
Output:
```
depth=2: accuracy=0.9211
depth=3: accuracy=0.8947
depth=None: accuracy=0.8947

best depth: 2

|--- petal_length <= 2.45
|   |--- class: setosa
|--- petal_length >  2.45
|   |--- petal_length <= 4.85
|   |   |--- class: versicolor
|   |--- petal_length >  4.85
|   |   |--- class: virginica

new flower prediction: versicolor

              precision    recall  f1-score   support

      setosa       1.00      1.00      1.00        12
  versicolor       0.86      0.92      0.89        13
   virginica       0.92      0.85      0.88        13

    accuracy                           0.92        38
   macro avg       0.92      0.92      0.92        38
weighted avg       0.92      0.92      0.92        38
```
This single 25-line file captures the entire scientific outcome of the project.

## Step-by-Step Student Instructions
1. Run `python main.py` in your terminal.
2. Check that the message `Saved: outputs/iris_tree.png, outputs/confusion_matrix.png, outputs/rules.txt` prints.
3. Open `outputs/rules.txt` in your text editor.
4. Verify the 5 sections: depth accuracies, best depth, decision rules, new flower prediction, and classification report.
5. Notice that depth accuracies are recorded with 4 decimal places of precision (`0.9211`).

## Expected Output or Observable Behaviour
Verifying `outputs/rules.txt` shows a complete, properly formatted text report matching the console output.

## Practical Exercises
- **Exercise 4.1**: What encoding is specified in `open(OUT / "rules.txt", "w", encoding="utf-8")`? Why is explicit encoding recommended?
- **Exercise 4.2**: What happens if the `outputs/` folder does not exist when `open()` is called? (Python raises a `FileNotFoundError`; that is why `OUT.mkdir(exist_ok=True)` was called on line 24).
- **Exercise 4.3**: How does saving `rules.txt` facilitate automated regression testing in continuous integration (CI) pipelines?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Solution |
|---|---|---|
| Missing `encoding="utf-8"` | Relying on system default encoding | Always pass `encoding="utf-8"` to prevent Unicode errors on Windows. |
| Forgetting `\n` newline characters | Calling `write()` without formatting newlines | Append `\n` to `write()` strings to avoid run-on sentences. |
| Overwriting during append | Using mode `"w"` when wanting `"a"` | Mode `"w"` creates a fresh file; use `"a"` if appending to existing logs. |

## Best Practices and Security Considerations
- **Directory Guardrails**: Always ensure target output directories exist before file I/O using `pathlib.Path.mkdir(exist_ok=True)`.
- **Atomic File Writing**: For high-concurrency production systems, write to a temporary file first and atomically rename it to prevent partially written files during server crashes.
- **Data Privacy**: Ensure exported reports and debug logs do not leak sensitive personal data or unhashed credentials.

## Summary
Persisting model evaluations to `outputs/rules.txt` bridges experimental prototyping and professional MLOps. Using Python's `with open(...)` context manager with UTF-8 encoding ensures clean, safe file handling. The generated artifact encapsulates depth comparisons, best hyperparameter selection, extracted decision rules, inference verification, and full multi-class classification metrics in an auditable text record.

## Knowledge-check Questions
1. What are the five key sections documented inside `outputs/rules.txt`?
2. Why is `encoding="utf-8"` explicitly specified when opening files?
3. What Python statement ensures file handles are automatically closed even if errors occur?
4. How many decimal places of precision are recorded for depth accuracy in `rules.txt`?
5. Why must `OUT.mkdir(exist_ok=True)` be executed prior to opening `outputs/rules.txt`?

## References
- Python File I/O documentation (https://docs.python.org/3/tutorial/inputoutput.html#reading-and-writing-files).
- Sculley, D., et al. (2015). *Hidden technical debt in machine learning systems*. NeurIPS.
