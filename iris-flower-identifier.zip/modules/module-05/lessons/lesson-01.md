# Lesson 01: Comparative Accuracy Analysis Across Depths

**Lesson ID:** lesson-01
**Module:** module-05
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Evaluate multi-class classification accuracy across constrained and unconstrained tree depths
- Calculate the exact number of correct and incorrect test classifications for each depth
- Explain why accuracy alone is insufficient for evaluating imbalanced problems but effective for balanced sets
- Analyze the trade-offs between depth 2, depth 3, and unconstrained depth

## Prerequisites
- Completion of Module 03 and Module 04
- Basic understanding of test set evaluation

## Concept Explanation
### The Evaluation Pipeline: Depth-by-Depth Scoring
In `main.py`, lines 41-54 compare three distinct architectures:
- `max_depth=2`
- `max_depth=3`
- `max_depth=None` (unlimited)

Every model is evaluated strictly on the 38 holdout test flowers (`X_test, y_test`). None of the models were allowed to inspect these 38 flowers during training.

```
       Depth Accuracy Comparison on Test Set (38 flowers)
       
  100% |
   95% |   [92.1%] (35/38)
   90% |                       [89.5%] (34/38)     [89.5%] (34/38)
   85% |
    0% +------------------------------------------------------------
           max_depth=2           max_depth=3         max_depth=None
```

### Deconstructing the Test Set Scores
Let us inspect the exact mathematical tally on the 38 test flowers:
1. **At `max_depth=2`**:
   - Total test flowers: 38
   - Correctly classified: **35 flowers**
   - Misclassified: **3 flowers**
   - Test Accuracy: $rac{35}{38} = 0.92105 ightarrow \mathbf{92.1\%}$
2. **At `max_depth=3`**:
   - Total test flowers: 38
   - Correctly classified: **34 flowers**
   - Misclassified: **4 flowers**
   - Test Accuracy: $rac{34}{38} = 0.89473 ightarrow \mathbf{89.5\%}$
3. **At `max_depth=None`**:
   - Total test flowers: 38
   - Correctly classified: **34 flowers**
   - Misclassified: **4 flowers**
   - Test Accuracy: $rac{34}{38} = 0.89473 ightarrow \mathbf{89.5\%}$

### Why Did Deeper Trees Lose a Flower?
Notice that adding extra depth from 2 to 3 caused the model to lose exactly one correct prediction (dropping from 35 correct to 34 correct).
Why? Because `max_depth=2` relied entirely on the robust macroscopic threshold `petal_length <= 4.85 cm`.
At depth 3, the model created an additional decision node testing `petal_width <= 1.75 cm` to isolate an anomalous flower in the training set. On the test set, however, a legitimate *virginica* specimen happened to have a narrow petal width of 1.7 cm, tricking the depth-3 tree into misclassifying it as a *versicolor*!

### When is Accuracy a Reliable Metric?
Accuracy is defined as:
$$	ext{Accuracy} = rac{	ext{Correct Predictions}}{	ext{Total Predictions}}$$
Accuracy is a reliable, intuitive metric **only when the target classes are balanced**. Because our test set contains 12 setosa, 13 versicolor, and 13 virginica (an almost perfect 33.3% split), a model that randomly guesses would score ~33.3%. An accuracy of 92.1% represents true, high-quality botanical discrimination.

## Relevant Code
In `main.py` (lines 41-54):
```python
    print("Comparing tree depths:\n")
    models = {}
    for depth in (2, 3, None):
        model = DecisionTreeClassifier(max_depth=depth, random_state=42)
        model.fit(X_train, y_train)
        predictions = model.predict(X_test)
        accuracy = accuracy_score(y_test, predictions)
        models[depth] = (model, predictions, accuracy)
        label = "unlimited" if depth is None else str(depth)
        print(f"  max_depth={label:9s} accuracy={accuracy:.1%}")

    best_depth = max(models, key=lambda depth: models[depth][2])
    model, predictions, accuracy = models[best_depth]
    print(f"\nBest tree: max_depth={best_depth}")
```

## Code Explanation
Inside the loop, `accuracy_score(y_test, predictions)` compares actual species strings against predicted species strings element-by-element. The accuracy float is printed with `.1%` formatting (multiplying by 100 and appending a percent sign). In line 52, `max()` dynamically selects `best_depth = 2` as the winner.

## Worked Example
Suppose an engineer writes a verification script `verify_accuracy.py`:
```python
from sklearn.metrics import accuracy_score

y_true = ["setosa", "versicolor", "virginica", "versicolor"]
y_pred = ["setosa", "versicolor", "versicolor", "versicolor"]  # 1 mistake on virginica

acc = accuracy_score(y_true, y_pred)
print(f"Accuracy: {acc:.2%} ({sum(t == p for t, p in zip(y_true, y_pred))}/{len(y_true)} correct)")
```
Output:
```
Accuracy: 75.00% (3/4 correct)
```
This mirrors how scikit-learn evaluates the 38 Iris test samples.

## Step-by-Step Student Instructions
1. Run `python main.py` in your terminal.
2. Locate the console section: `Comparing tree depths:`.
3. Verify that `max_depth=2` prints `92.1%`.
4. Verify that `max_depth=3` prints `89.5%`.
5. Verify that `max_depth=unlimited` prints `89.5%`.
6. Confirm that `Best tree: max_depth=2` is selected.

## Expected Output or Observable Behaviour
Terminal displays:
```
Comparing tree depths:

  max_depth=2         accuracy=92.1%
  max_depth=3         accuracy=89.5%
  max_depth=unlimited accuracy=89.5%

Best tree: max_depth=2
```
This confirms that the quantitative comparison identified depth 2 as the superior model.

## Practical Exercises
- **Exercise 1.1**: Calculate the test accuracy if a model correctly classified 36 out of 38 flowers. (36/38 = 94.74%).
- **Exercise 1.2**: Why would accuracy be a dangerously misleading metric if 99% of your dataset belonged to *setosa* and only 1% belonged to other species? (A dummy model predicting setosa 100% of the time would achieve 99% accuracy while detecting zero versicolor or virginica).
- **Exercise 1.3**: How many misclassifications did `max_depth=2` make on the 38 test flowers?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Solution |
|---|---|---|
| Reporting training accuracy as model accuracy | Calling `model.score(X_train, y_train)` | Always evaluate and report generalization accuracy on `X_test, y_test`. |
| Assuming higher depth always improves accuracy | Confusing model capacity with generalization | Recognize that increased depth often decreases test accuracy due to overfitting. |
| Misinterpreting accuracy percentage | Forgetting sample size denominator | Always check both percentage (92.1%) and absolute counts (35/38). |

## Best Practices and Security Considerations
- **Baseline Comparison**: Always compare model accuracy against a dummy baseline (e.g. predicting the majority class, which would yield 34.2% on this test set).
- **Metric Diversity**: Never rely exclusively on overall accuracy; always inspect per-class metrics to ensure minority classes are not being neglected.
- **Statistical Significance**: On small test sets (38 samples), a difference of 1 flower represents 2.6%; consider cross-validation to confirm results.

## Summary
The depth comparison demonstrates that `max_depth=2` achieves 92.1% test accuracy (35/38 correct), outperforming both `max_depth=3` (89.5%) and `max_depth=None` (89.5%). Because the 38-sample test partition is well balanced across species, overall accuracy provides an objective benchmark. Deeper trees overfit to training nuances, misclassifying an additional test flower.

## Knowledge-check Questions
1. What test accuracy was achieved by `max_depth=2`?
2. How many test flowers out of 38 did `max_depth=2` classify correctly?
3. How many flowers were correctly classified by `max_depth=3`?
4. Under what dataset condition is classification accuracy considered a reliable metric?
5. Why did increasing tree depth from 2 to 3 result in lower test accuracy?

## References
- scikit-learn accuracy_score API reference (https://scikit-learn.org/stable/modules/generated/sklearn.metrics.accuracy_score.html).
- Fawcett, T. (2006). *An introduction to ROC analysis*. Pattern Recognition Letters, 27(8), 861-874.
