# Architecture & Pipeline

The Iris Flower Identifier implements a complete supervised machine learning workflow for multi-class classification using Decision Trees.

```
+-------------------------------------------------------------------------------+
|                                Pipeline Flow                                  |
+-------------------------------------------------------------------------------+
|  1. Configuration & Matplotlib Agg Setup                                      |
|     - matplotlib.use("Agg") prevents GUI popups                               |
|     - Define paths (BASE, DATA, OUT) with pathlib                             |
|     - Feature list: sepal_length, sepal_width, petal_length, petal_width      |
+-------------------------------------------------------------------------------+
                                      |
                                      v
+-------------------------------------------------------------------------------+
|  2. Data Ingestion & Target Separation                                        |
|     - Read data/iris.csv into pandas DataFrame (150 rows x 5 columns)         |
|     - Feature matrix X: 4 numerical columns (150, 4)                          |
|     - Target vector y: categorical species strings (150,)                     |
+-------------------------------------------------------------------------------+
                                      |
                                      v
+-------------------------------------------------------------------------------+
|  3. Stratified Train/Test Split                                               |
|     - train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)     |
|     - Training set: 112 samples (balanced: ~37-38 per species)                |
|     - Test set: 38 samples (balanced: 12 setosa, 13 versicolor, 13 virginica) |
+-------------------------------------------------------------------------------+
                                      |
                                      v
+-------------------------------------------------------------------------------+
|  4. Depth Tuning Loop & Model Selection                                       |
|     - Loop through depths: max_depth in (2, 3, None)                          |
|     - Train DecisionTreeClassifier(max_depth=depth, random_state=42)          |
|     - Compute test accuracy_score(y_test, predictions)                        |
|     - Store models in dict: {depth: (model, predictions, accuracy)}           |
|     - Select best model via max(models, key=lambda d: models[d][2])           |
|     - Outcome: max_depth=2 achieves 92.1% (simpler tree beats deeper 89.5%)   |
+-------------------------------------------------------------------------------+
                                      |
                                      v
+-------------------------------------------------------------------------------+
|  5. Rule Extraction & Detailed Evaluation                                     |
|     - export_text() prints clear if/then decision logic based on petal_length |
|     - classification_report() calculates precision, recall, and f1 per class  |
|     - Predict class for new_flower: [5.8, 2.7, 4.1, 1.0] -> versicolor        |
+-------------------------------------------------------------------------------+
                                      |
                                      v
+-------------------------------------------------------------------------------+
|  6. Visualization & Artifact Persistence                                      |
|     - plot_tree(): Renders colored flowchart to outputs/iris_tree.png         |
|     - confusion_matrix(): Renders 3x3 matrix to outputs/confusion_matrix.png  |
|     - outputs/rules.txt: Writes accuracies, rules, and classification report  |
+-------------------------------------------------------------------------------+
```

---

## Key Architectural Components

### 1. Feature Representation
Four continuous morphological measurements in centimeters:
- `sepal_length`: Sepal length in cm
- `sepal_width`: Sepal width in cm
- `petal_length`: Petal length in cm
- `petal_width`: Petal width in cm

### 2. Decision Tree Classifier
The core learning algorithm is scikit-learn's `DecisionTreeClassifier`. It recursively selects the feature and numeric threshold that minimizes Gini impurity at each split. Because decision trees are non-parametric, they require no feature scaling or normalization.

### 3. Hyperparameter Tuning Strategy
The script tests three distinct depth constraints:
- `max_depth=2`: Shallow tree (maximum 3 decision splits, 4 leaves)
- `max_depth=3`: Moderate depth (up to 7 decision splits, 8 leaves)
- `max_depth=None`: Unlimited depth (splits continue until all leaves are 100% pure)

### 4. Evaluation Suite
- **Stratified Split**: Prevents sampling bias across 3 classes.
- **Accuracy Score**: Overall fraction of correct predictions.
- **Per-Class Metrics**: Precision, recall, and F1-score via `classification_report`.
- **Confusion Matrix**: Identifies cross-species boundary errors (`versicolor` vs `virginica`).
