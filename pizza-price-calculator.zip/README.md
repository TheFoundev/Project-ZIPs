# The Pizza Price Calculator: Multiple Linear Regression Educational Package

Welcome to **The Pizza Price Calculator** educational project. This package guides beginner AI and machine learning students through building, evaluating, and operationalizing a **Multiple Linear Regression** pipeline using real-world Python data science libraries.

---

## Project At A Glance

- **Subject**: Supervised Machine Learning (Multiple Linear Regression)
- **Dataset**: `data/pizza_menu.csv` (45 menu configurations: diameter, toppings, price)
- **Features ($X$)**:
  - `diameter_inches` (Continuous float: 8.4" to 17.6")
  - `toppings` (Discrete integer count: 0 to 5)
- **Target Variable ($y$)**: `price_usd` (Continuous float: $12.59 to $30.43)
- **Algorithm**: Ordinary Least Squares (OLS) via `sklearn.linear_model.LinearRegression`
- **Fitted Pricing Model**:
  $$\text{Price} = \$4.02 + (\$0.97 \times \text{diameter}) + (\$1.81 \times \text{toppings})$$
- **Benchmark Prediction**: Quote for a 12-inch pizza with 3 toppings $\rightarrow \mathbf{\$21.05}$
- **Performance**: $\text{MAE} = \mathbf{\$0.58}$, $R^2 = \mathbf{0.98}$ (on held-out test data)
- **Special Software Pattern**: `quote_pizza()` function as a reusable pricing API and automated batch menu catalog generator

---

## Real-World Business Context

Commercial pizzerias, ghost kitchens, and food delivery applications face the constant challenge of pricing custom build-your-own pizzas. Arbitrary pricing risks either eroding profit margins or driving away customers. 

By applying multiple linear regression to historical menu prices, businesses can decompose pizza pricing into transparent, cost-reflective economic parameters:
1. **Base Crust & Overhead Cost** ($\approx \$4.02$ intercept): Fixed cost of preparation, labor, baking, packaging, and oven overhead.
2. **Size Marginal Rate** ($\approx \$0.97/\text{inch}$): Cost of dough, cheese base, sauce, and pan surface area per additional diameter inch.
3. **Topping Marginal Rate** ($\approx \$1.81/\text{topping}$): Cost of ingredients, portioning, and prep per added topping.

---

## What You Will Learn

1. **Foundations & Problem Formulation (Module 01)**: Understand supervised regression with multiple simultaneous predictors and distinguish multi-variable regression planes from single-variable regression lines.
2. **Data Ingestion & Exploration (Module 02)**: Use `pandas` and `pathlib` for safe data loading, structure 2D feature matrices without warnings, and perform bivariate visual analysis.
3. **Multiple Regression & Economic Interpretation (Module 03)**: Partition data with `train_test_split`, fit `LinearRegression()`, and interpret regression coefficients as marginal costs.
4. **The Model-as-an-API Pattern (Module 04)**: Wrap trained scikit-learn models inside reusable Python functions (`quote_pizza`) and generate dynamic catalog price lists using `itertuples`.
5. **Evaluation & Residual Diagnostics (Module 05)**: Quantify error in real currency units using MAE, compute $R^2$, and construct actual-versus-predicted diagonal scatter plots.
6. **Execution, File Export, & Extensions (Module 06)**: Run complete production scripts, persist formatted outputs to `outputs/quotes.txt`, and extend models with dummy indicator variables like `stuffed_crust`.

---

## Directory Structure

```text
pizza-price-calculator/
├── project.json                 # Project metadata & competencies
├── README.md                    # Master project documentation
├── architecture.md              # Pipeline architecture, data flow & dimensions
├── prerequisites.md             # Required skills, tools, and conceptual review
├── setup-guide.md               # Step-by-step setup and execution guide
├── glossary.md                  # Comprehensive AI/ML & economic terms glossary
├── references.json              # Official documentation links and resources
├── PROJECT_SUMMARY.md           # Executive overview for instructors & mentors
├── ALL_ASSESSMENT_ANSWERS.md    # Master answer key for all 6 module assessments
├── manifest.json                # Complete catalog of all 61 package files
├── final-project/               # Capstone project specifications
│   ├── requirements.md          # Comprehensive rebuild requirements
│   ├── evaluation-rubric.json   # 105-point grading criteria
│   └── solution-guide.md        # Reference implementation and verification guide
└── modules/                     # 6 In-Depth Learning Modules (48 files total)
    ├── module-01/               # Overview and Business Context
    ├── module-02/               # Data Loading and Menu Exploration
    ├── module-03/               # Multiple Linear Regression & Economics
    ├── module-04/               # The quote_pizza() Function Pattern
    ├── module-05/               # Model Evaluation & Residual Diagnostics
    └── module-06/               # Pipeline Execution & Model Extensions
```

---

## Quick Start

To execute the underlying reference implementation directly from the repository:

```bash
cd "beginner-projects-main/AI-ML Beginners/projects/08_pizza_price"
pip install pandas numpy matplotlib scikit-learn
python main.py
```

### Expected Terminal Output

```text
============================================================
THE PIZZA PRICE CALCULATOR
============================================================
Equation: price = 4.02 + 0.97 x diameter + 1.81 x toppings
Mean absolute error: $0.58
R-squared: 0.98
Quote for a 12-inch pizza with 3 toppings: $21.05

Price list from the model:
  Small, 8-inch, 1 topping            $13.56
  Medium, 12-inch, 3 toppings         $21.05
  Large, 16-inch, 5 toppings          $28.53
  Party, 18-inch, 5 toppings          $30.46

Saved: outputs/actual_vs_predicted.png, outputs/quotes.txt
Try this: add a 'stuffed_crust' true/false column and retrain.
```

### Generated Artifacts

- **`outputs/actual_vs_predicted.png`**: High-resolution 150 DPI scatter plot comparing test set actual prices against model quotes against an ideal 45-degree dashed parity line.
- **`outputs/quotes.txt`**: Formatted text file containing four-decimal precision parameters, evaluation metrics, and the four-tier generated menu catalog.

---

## How to Work Through This Course

1. **Sequential Module Progression**: Begin with Module 01 and complete through Module 06. Each module contains 4 structured lessons covering conceptual foundations, code walkthroughs, and practical debugging.
2. **Hands-On Exercises**: Complete the hands-on coding lab in each module's `exercises/` folder to practice key techniques.
3. **Knowledge Verification**: Take the 10-question multiple-choice assessment at the end of each module to validate understanding.
4. **Capstone Final Project**: Rebuild the entire pipeline from scratch following `final-project/requirements.md` and benchmark your results using `final-project/solution-guide.md`.

---

## Security & Reliability Considerations

- **Headless Backend**: Configured with `matplotlib.use("Agg")` prior to importing pyplot to avoid display server dependencies in CI/CD and containerized environments.
- **Safe Pathing**: Uses `pathlib.Path(__file__).resolve().parent` to resolve dataset and output paths regardless of the current working directory.
- **Resource Management**: Uses Python context managers (`with open(...)`) and `OUT.mkdir(exist_ok=True)` for leak-free file handling.
- **Offline & Secure**: Operates 100% locally with zero external network calls or sensitive credentials.
