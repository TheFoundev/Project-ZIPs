# All Correct Answers for Assessments
Project: The Pizza Price Calculator
---

## Module 01: Project Overview and Business Context
**q1-01.** In the Pizza Price Calculator project, what is the primary business problem being solved?
   **Correct Answer:** b. Predicting the continuous market price of a pizza based on its size and toppings
   *Explanation:* The Pizza Price Calculator project addresses the commercial challenge of pricing pizzas based on diameter and topping counts by predicting the continuous market price in US Dollars.

**q1-02.** Which CSV file contains the historical menu dataset used to train the pricing model in main.py?
   **Correct Answer:** b. data/pizza_menu.csv
   *Explanation:* In main.py line 28, the code specifically reads from DATA / 'pizza_menu.csv', which stores the historical catalog of 45 pizza configurations.

**q1-03.** Which column in the dataset represents the target variable (dependent variable) to be predicted?
   **Correct Answer:** c. price_usd
   *Explanation:* price_usd is the dependent target variable (y) that the model aims to predict based on the input specifications of the pizza.

**q1-04.** Which two columns in the dataset are selected as the independent feature variables (X) for the model?
   **Correct Answer:** b. diameter_inches and toppings
   *Explanation:* diameter_inches and toppings are selected together as the feature columns (X) because both physical size and ingredient counts jointly determine pizza pricing.

**q1-05.** In main.py, how is the feature matrix X extracted from the pandas DataFrame df?
   **Correct Answer:** b. X = df[['diameter_inches', 'toppings']]
   *Explanation:* Passing a list of strings within indexing brackets, df[['diameter_inches', 'toppings']], returns a 2D pandas DataFrame containing both feature columns as required by scikit-learn.

**q1-06.** Why is X extracted using double brackets df[['diameter_inches', 'toppings']] in pandas?
   **Correct Answer:** b. Scikit-learn requires features to be formatted as a 2D tabular structure (DataFrame)
   *Explanation:* Scikit-learn estimators require feature matrix X to have a two-dimensional shape (n_samples, n_features). Double brackets return a DataFrame, preserving this required 2D structure.

**q1-07.** What are the dimensions (shape) of the feature matrix X extracted from pizza_menu.csv?
   **Correct Answer:** b. (45, 2)
   *Explanation:* pizza_menu.csv contains 45 sample rows and X contains 2 selected feature columns (diameter_inches and toppings), resulting in a shape of (45, 2).

**q1-08.** How does multiple linear regression differ from simple linear regression in this project?
   **Correct Answer:** b. It estimates the target price using two independent features (size and toppings) simultaneously
   *Explanation:* Multiple linear regression models outcomes based on two or more predictor features simultaneously, allowing the pricing model to account for both pizza diameter and topping count.

**q1-09.** What design role does the quote_pizza(diameter_inches, toppings) function serve in main.py?
   **Correct Answer:** b. It wraps the trained model as a reusable API function that formats inputs and returns price estimates
   *Explanation:* quote_pizza() wraps the trained regression model as a clean, reusable function that constructs a compliant single-row DataFrame, executes predict(), and returns a clean dollar quote.

**q1-10.** Why is supervised learning specifically suitable for commercial pizza price estimation?
   **Correct Answer:** b. Because it learns the mathematical relationship from historical menu examples where both features and ground-truth prices are known
   *Explanation:* Supervised learning utilizes historical examples where both the inputs (size, toppings) and the correct output (historical price) are known, enabling the algorithm to learn the pricing relationship.

## Module 02: Data Loading and Menu Exploration
**q2-01.** Why does main.py configure matplotlib using matplotlib.use('Agg') at the top of the script?
   **Correct Answer:** b. To enable a headless, non-interactive backend that saves image files without requiring a GUI window server
   *Explanation:* matplotlib.use('Agg') activates the non-interactive Anti-Grain Geometry backend, which enables rendering and saving plots directly to disk without requiring a graphical display server or GUI desktop environment.

**q2-02.** What is the total number of rows (observations) loaded from data/pizza_menu.csv?
   **Correct Answer:** c. 45
   *Explanation:* data/pizza_menu.csv contains 45 data rows (lines 2 through 46 in the file), representing 45 distinct pizza offerings in the restaurant menu.

**q2-03.** Which pandas statement extracts the feature matrix X with the correct 2D shape required by scikit-learn?
   **Correct Answer:** b. X = df[['diameter_inches', 'toppings']]
   *Explanation:* Passing a Python list of column names inside indexing brackets df[['diameter_inches', 'toppings']] returns a 2D DataFrame with shape (45, 2), meeting scikit-learn's dimensionality requirements.

**q2-04.** What happens if you pass a 1D pandas Series of shape (45,) as the feature matrix X to LinearRegression.fit()?
   **Correct Answer:** b. Scikit-learn raises a ValueError stating that a 2D array was expected
   *Explanation:* Scikit-learn expects feature matrix X to have 2 dimensions (n_samples, n_features). Passing a 1D Series raises a ValueError advising the user to reshape the array to (-1, 1).

**q2-05.** In the scatter plot of diameter vs price, why is there vertical dispersion among pizzas with identical diameters?
   **Correct Answer:** b. Because pizzas of the same diameter can have different numbers of toppings
   *Explanation:* Pizzas sharing identical diameters have varying prices because they carry different numbers of toppings (from 0 up to 5), causing vertical price spread in 2D projections.

**q2-06.** Why must matplotlib.use('Agg') be called before importing matplotlib.pyplot?
   **Correct Answer:** b. Because importing pyplot automatically initializes the default GUI backend, ignoring subsequent .use() calls
   *Explanation:* Importing matplotlib.pyplot initializes the default graphical backend immediately. Calling matplotlib.use('Agg') must occur beforehand to ensure the headless backend is registered before initialization.

**q2-07.** What is the approximate Pearson correlation between diameter_inches and toppings in pizza_menu.csv?
   **Correct Answer:** c. Essentially zero correlation (~ -0.05)
   *Explanation:* Calculating Pearson correlation on pizza_menu.csv shows r = -0.046 between diameter_inches and toppings, which is statistically indistinguishable from zero correlation.

**q2-08.** Why is near-zero cross-correlation between diameter_inches and toppings mathematically advantageous for multiple regression?
   **Correct Answer:** b. It prevents multicollinearity, allowing the model to cleanly isolate the independent marginal effect of each feature
   *Explanation:* When predictor features have near-zero cross-correlation, multicollinearity is absent. This allows ordinary least squares regression to calculate distinct, stable coefficients for each feature without inflated standard errors.

**q2-09.** How does pathlib.Path(__file__).resolve().parent ensure reliable data loading in main.py?
   **Correct Answer:** b. It resolves filesystem paths relative to the script's physical location on disk rather than the current working directory
   *Explanation:* Path(__file__).resolve().parent calculates the absolute path to the directory enclosing the script, ensuring that data and output paths work reliably regardless of the terminal's working directory.

**q2-10.** Comparing the two individual feature correlations with price_usd, which feature has the higher Pearson correlation coefficient in pizza_menu.csv?
   **Correct Answer:** b. toppings (r ≈ 0.741)
   *Explanation:* In pizza_menu.csv, toppings has a Pearson correlation with price_usd of r ≈ 0.741, which is higher than the correlation between diameter_inches and price_usd (r ≈ 0.654).

## Module 03: Multiple Linear Regression and Economic Interpretation
**q3-01.** In multiple linear regression with 2 features, what geometric shape represents the fitted model in 3D space?
   **Correct Answer:** b. A 2-dimensional flat planar surface (hyperplane)
   *Explanation:* With 2 predictor features (diameter and toppings), the multiple linear regression equation defines a flat 2-dimensional planar surface (hyperplane) slicing through 3-dimensional coordinate space.

**q3-02.** In main.py, what parameter values are passed to train_test_split?
   **Correct Answer:** b. test_size=0.25, random_state=42
   *Explanation:* In main.py line 33, train_test_split is invoked with test_size=0.25 and random_state=42, partitioning 25% of the data into the test set deterministically.

**q3-03.** How many rows are allocated to the training set and testing set respectively by train_test_split in main.py?
   **Correct Answer:** b. 33 in training, 12 in testing
   *Explanation:* With a 75/25 split on 45 total observations, 73.3% (33 rows) are assigned to training (X_train, y_train) and 26.7% (12 rows) are assigned to testing (X_test, y_test).

**q3-04.** What mathematical criterion does scikit-learn's LinearRegression estimator minimize during model.fit()?
   **Correct Answer:** b. The Residual Sum of Squares (RSS) between actual and predicted target values
   *Explanation:* Ordinary Least Squares (OLS) solves for model parameters by minimizing the Residual Sum of Squares (RSS), which is the sum of squared differences between ground-truth labels and model predictions.

**q3-05.** What does the learned size_weight coefficient (~$0.97) represent economically?
   **Correct Answer:** b. The marginal increase in pizza price associated with each additional inch of diameter, holding toppings constant
   *Explanation:* In multiple regression, each slope coefficient reflects the marginal rate of change in the target per unit increase in that feature, holding all other features constant. Size weight ~$0.97 means price rises $0.97 per extra inch.

**q3-06.** What does the learned topping_weight coefficient (~$1.81) represent economically?
   **Correct Answer:** b. The marginal increase in pizza price associated with adding one extra topping, holding diameter constant
   *Explanation:* Topping weight (~$1.81) represents the partial regression coefficient for toppings: holding diameter constant, adding one topping increases the estimated price by $1.81.

**q3-07.** What does the learned intercept (~$4.02) represent in the commercial context of pizza pricing?
   **Correct Answer:** a. The fixed base operational overhead (packaging, oven operation, basic labor, core dough/sauce/cheese)
   *Explanation:* The intercept ($4.02) represents the baseline fixed cost incurred for every pizza order (dough preparation, oven operation, cardboard box packaging, and core mozzarella/sauce) before adding size or toppings.

**q3-08.** In scikit-learn, what do trailing underscores in attribute names (such as coef_ and intercept_) denote?
   **Correct Answer:** b. That the parameters were estimated from data during the fit() method
   *Explanation:* In scikit-learn's API design, all attributes that are estimated from training data during the fit() method are given trailing underscores (e.g., coef_, intercept_, n_features_in_).

**q3-09.** Why is random_state=42 explicitly specified in train_test_split?
   **Correct Answer:** b. To seed the random shuffle, ensuring identical data partitions and reproducible model results across runs
   *Explanation:* Setting random_state=42 seeds the pseudo-random number generator used for data shuffling, guaranteeing identical splits and perfectly reproducible model parameters and metrics across environments.

**q3-10.** Using the learned pricing equation: price = 4.02 + 0.97 * diameter + 1.81 * toppings, what is the predicted quote for a 14-inch pizza with 2 toppings?
   **Correct Answer:** c. $21.22
   *Explanation:* Applying the formula: price = 4.02 + (0.97 * 14) + (1.81 * 2) = 4.02 + 13.58 + 3.62 = $21.22 (using unrounded weights 4.0224 + 0.9656*14 + 1.8125*2 = 21.2258 -> $21.22).

## Module 04: The quote_pizza() Function Pattern
**q4-01.** What is the primary architectural purpose of wrapping model.predict() inside the quote_pizza() helper function?
   **Correct Answer:** b. To encapsulate the model behind a clean, reusable API function that accepts standard primitives and returns scalar dollar quotes
   *Explanation:* The wrapper function encapsulates the trained regression model behind a clean, reusable interface that accepts standard primitives (float, int) and returns a clean scalar dollar quote, hiding scikit-learn's internal matrix mechanics.

**q4-02.** What is the model quote for a Medium, 12-inch pizza with 3 toppings generated by quote_pizza(12, 3)?
   **Correct Answer:** c. $21.05
   *Explanation:* Calling quote_pizza(12, 3) executes 4.0224 + 0.9656(12) + 1.8125(3) = 21.0471, which rounds cleanly to $21.05 as displayed in the project console output.

**q4-03.** Inside quote_pizza(), what data structure is constructed before calling model.predict()?
   **Correct Answer:** b. A single-row pandas DataFrame with columns 'diameter_inches' and 'toppings'
   *Explanation:* Inside quote_pizza(), lines 47-49 build order = pd.DataFrame([{'diameter_inches': diameter_inches, 'toppings': toppings}]), creating a 1-row, 2-column DataFrame.

**q4-04.** Why does quote_pizza() package the order as a pandas DataFrame with explicit column names rather than passing a raw list [[12, 3]]?
   **Correct Answer:** b. To guarantee feature name alignment with the training matrix and eliminate scikit-learn feature name mismatch warnings
   *Explanation:* Constructing a DataFrame with column names matching the training matrix guarantees feature alignment and eliminates scikit-learn's UserWarning regarding missing feature names.

**q4-05.** In the statement return float(model.predict(order)[0]), what is the purpose of [0]?
   **Correct Answer:** b. It extracts the first scalar prediction from the 1-dimensional NumPy array returned by predict()
   *Explanation:* model.predict() always returns a 1D NumPy array (here of shape (1,)). Indexing with [0] extracts the first scalar element from that array.

**q4-06.** Why is menu.itertuples() preferred over menu.iterrows() when computing batch model quotes in main.py?
   **Correct Answer:** b. Because itertuples() yields lightweight named tuples, executing much faster and with lower memory overhead than iterrows()
   *Explanation:* itertuples() yields lightweight named tuples without the overhead of instantiating pandas Series for each row, making it significantly faster and more memory-efficient than iterrows().

**q4-07.** What is the model quote for a Small, 8-inch pizza with 1 topping in the generated price list?
   **Correct Answer:** b. $13.56
   *Explanation:* For an 8-inch pizza with 1 topping: 4.0224 + 0.9656(8) + 1.8125(1) = 13.5597, which formats cleanly as $13.56 in the generated menu price list.

**q4-08.** What model quote is generated for the Large (16-inch, 5 toppings) and Party (18-inch, 5 toppings) pizzas respectively?
   **Correct Answer:** b. $28.53 and $30.46
   *Explanation:* The model quotes $28.53 for Large (16 in, 5 toppings) and $30.46 for Party (18 in, 5 toppings), scaling predictably with diameter.

**q4-09.** Why is defensive input validation essential before passing customer orders to an unconstrained linear regression model?
   **Correct Answer:** b. Because unconstrained linear models will extrapolate mathematically to impossible results, such as negative prices for negative diameters
   *Explanation:* Linear regression models are unbounded linear hyperplanes. Without domain validation guards, passing negative diameters or negative toppings produces nonsensical negative prices.

**q4-10.** How does defining quote_pizza() inside main() form a Python closure over the model variable?
   **Correct Answer:** b. It enables the nested function to capture and retain access to the trained local model object without requiring global variables
   *Explanation:* Defining quote_pizza inside main() after model is fitted creates a Python closure, allowing quote_pizza to access the local model object directly without exposing it as a global variable.

## Module 05: Model Evaluation and Residual Diagnostics
**q5-01.** What is the mathematical definition of Mean Absolute Error (MAE) in regression evaluation?
   **Correct Answer:** a. The average of the absolute differences between actual ground-truth values and model predictions
   *Explanation:* Mean Absolute Error is mathematically defined as the average of the absolute differences between the observed values and the predicted values across all samples in the evaluation set.

**q5-02.** What does the Coefficient of Determination (R2) measure in linear regression?
   **Correct Answer:** b. The proportion of total variance in the target variable that is explained by the regression model features
   *Explanation:* R-squared measures the proportion of the total variance in the dependent target variable that is explained by the independent predictor features in the regression model.

**q5-03.** In an Actual vs. Predicted scatter plot, what does the dashed 45-degree reference line represent?
   **Correct Answer:** c. The line of perfect prediction where predicted price exactly equals actual price
   *Explanation:* The dashed 45-degree line represents y = x, where the model predicted price matches the actual ground truth menu price exactly with zero prediction error.

**q5-04.** Our model achieves a Mean Absolute Error of $0.58 on the test set. What is the correct business interpretation of this result?
   **Correct Answer:** a. On average, the model's price quotes deviate from actual menu prices by approximately 58 cents
   *Explanation:* An MAE of $0.58 indicates that on average across all test orders, the model's price prediction deviates from the true historical menu price by approximately 58 cents.

**q5-05.** Why is Mean Absolute Error (MAE) considered more robust to isolated extreme outliers than Root Mean Squared Error (RMSE)?
   **Correct Answer:** a. MAE scales each individual error linearly, whereas RMSE squares errors before averaging, heavily penalizing large discrepancies
   *Explanation:* MAE penalizes errors linearly, meaning a $4.00 error counts four times as much as a $1.00 error. In contrast, RMSE squares errors before taking the root, giving quadratic weight to large deviations.

**q5-06.** The pizza price model achieves an R2 score of 0.98 on the test set. What does this specific numerical result indicate?
   **Correct Answer:** a. 98% of the variation in pizza prices is explained by diameter and toppings, with only 2% unexplained
   *Explanation:* An R2 of 0.98 means that 98% of the price variability in the test menu is captured and explained by pizza diameter and topping count, leaving only 2% unexplained residual variation.

**q5-07.** If a pizza order has an actual price of $22.00 and a predicted price of $20.50, what is the residual (actual - predicted), and what does it mean?
   **Correct Answer:** a. Residual is +$1.50, indicating the model underpredicted the price (quoted lower than actual)
   *Explanation:* Residual is defined as actual price minus predicted price ($22.00 - $20.50 = +$1.50). A positive residual means the actual price was higher than the model estimate, indicating an underprediction.

**q5-08.** In an Actual vs. Predicted plot where actual price is on the X-axis and predicted price is on the Y-axis, what does a point lying above the 45-degree diagonal line represent?
   **Correct Answer:** b. An overprediction where the model estimated a price higher than the menu price
   *Explanation:* When actual price is on the horizontal X-axis and predicted price is on the vertical Y-axis, any point above the diagonal has Y > X (predicted price > actual price), representing an overprediction.

**q5-09.** What is heteroscedasticity, and how does it commonly present in restaurant menu pricing models?
   **Correct Answer:** a. Non-constant residual variance, where prediction errors fan out and become larger in magnitude as pizza size or price increases
   *Explanation:* Heteroscedasticity refers to non-constant variance in residuals across predictor levels, typically manifesting as larger error dispersion for larger, more expensive pizzas.

**q5-10.** Suppose a model achieves an R2 of 0.99 on the training set but an R2 of 0.35 on the held-out test set. What diagnostic conclusion should be drawn?
   **Correct Answer:** a. The model has suffered severe overfitting, memorizing training noise rather than learning generalizable pricing patterns
   *Explanation:* A large discrepancy between high training performance (R2 = 0.99) and poor test performance (R2 = 0.35) is the classic hallmark of overfitting, where the model memorizes noise rather than generalizable relationships.

## Module 06: Pipeline Execution, File Export, and Model Extensions
**q6-01.** What is the correct logical execution sequence of the end-to-end pizza price calculator pipeline in main.py?
   **Correct Answer:** a. Data ingestion -> Train/test split -> Model fitting -> Pricing inference wrapper -> Evaluation & plot export
   *Explanation:* The pipeline strictly executes data ingestion first, partitions into train/test, trains the model, constructs the inference wrapper, and completes with performance evaluation and artifact export.

**q6-02.** Why is the Python context manager syntax 'with open(filename, 'w') as f:' mandatory for production file export?
   **Correct Answer:** a. It guarantees that the file handle is properly closed even if an unhandled exception or crash occurs during writing
   *Explanation:* Python context managers guarantee that the file resource is closed and flushed properly upon exiting the block, preventing resource leaks even during runtime exceptions.

**q6-03.** How is a categorical binary attribute such as 'stuffed_crust' represented in a multiple linear regression feature matrix?
   **Correct Answer:** a. As a numerical dummy indicator variable taking values of 0 (regular crust) and 1 (stuffed crust)
   *Explanation:* Categorical binary options are represented numerically as dummy variables using 0 to represent absence (regular crust) and 1 to represent presence (stuffed crust).

**q6-04.** In a 3-feature model where price = 4.00 + 0.95*diameter + 1.80*toppings + 2.75*stuffed_crust, how is the coefficient 2.75 interpreted?
   **Correct Answer:** a. Upgrading to stuffed crust adds a flat surcharge of $2.75, holding pizza diameter and topping count constant
   *Explanation:* In multiple linear regression, each coefficient represents the change in target price for a one-unit increase in that feature while holding all other features constant.

**q6-05.** When exporting a menu table to outputs/quotes.txt, what is the best practice to prevent FileNotFoundError if the outputs folder is missing?
   **Correct Answer:** a. Invoke Path('outputs').mkdir(parents=True, exist_ok=True) prior to opening the file
   *Explanation:* Calling Path('outputs').mkdir(parents=True, exist_ok=True) ensures the directory structure exists before file creation, avoiding FileNotFoundError without manual user intervention.

**q6-06.** Why should a production pricing wrapper like quote_pizza_safe() implement explicit input boundaries (e.g. diameter between 6 and 24 inches)?
   **Correct Answer:** a. Linear regression extrapolates indefinitely, producing absurd or negative prices for extreme or negative input values
   *Explanation:* Linear regression fits an unbounded hyperplane. Without input validation guardrails, extreme or negative inputs will generate nonsensical quotes or negative menu prices.

**q6-07.** What is the primary indicator that an operational retail pricing model is experiencing concept drift?
   **Correct Answer:** a. A persistent increase in prediction residuals and Mean Absolute Error on recent actual transactions
   *Explanation:* Concept drift occurs when the economic relationship between predictors and prices changes (e.g. inflation), resulting in systematically larger residuals and rising MAE on live orders.

**q6-08.** What is the 'dummy variable trap' when encoding categorical variables in linear regression with an intercept?
   **Correct Answer:** a. Including dummy columns for all k categories alongside an intercept creates perfect multicollinearity and matrix singularity
   *Explanation:* When an intercept term is present, including dummy columns for all k categories creates a linear dependency (summing to 1.0), causing perfect multicollinearity and matrix inversion failure.

**q6-09.** What is the fundamental difference between data drift and concept drift in a production restaurant pricing service?
   **Correct Answer:** a. Data drift is a shift in incoming feature distributions, while concept drift is a change in the economic relationship between features and price
   *Explanation:* Data drift represents a change in the input feature distribution P(X), whereas concept drift represents a change in the conditional mapping P(Y|X) between features and target price.

**q6-10.** In an automated MLOps retraining architecture for the pizza calculator, which safeguard prevents deploying a degraded model?
   **Correct Answer:** a. An automated evaluation gate that aborts deployment and alerts engineers if test MAE exceeds $0.85 or R2 falls below 0.90
   *Explanation:* An automated evaluation quality gate acts as a deployment circuit breaker, validating new model performance against strict thresholds before promoting the model to production.
