# Setup Guide

Follow this step-by-step guide to set up your environment, verify the menu dataset, execute the Pizza Price Calculator pipeline, and inspect generated artifacts.

---

## Step 1: Navigate to the Project Directory

Open your terminal and navigate to the project root directory:

```bash
cd "beginner-projects-main/AI-ML Beginners/projects/08_pizza_price"
```

Verify that the expected project layout is present:
```bash
ls -la
```
You should see `main.py` and the `data/` folder containing `pizza_menu.csv`.

---

## Step 2: Set Up a Python Virtual Environment (Recommended)

Isolating your project dependencies in a virtual environment prevents version conflicts with other system packages:

```bash
# Create a virtual environment named 'venv'
python3 -m venv venv

# Activate the virtual environment:
# On Linux / macOS:
source venv/bin/activate

# On Windows (Command Prompt):
# venv\Scripts\activate.bat

# On Windows (PowerShell):
# venv\Scripts\Activate.ps1
```

When activated, `(venv)` will precede your terminal prompt.

---

## Step 3: Install Required Dependencies

Install the required data science packages via `pip`:

```bash
pip install pandas numpy matplotlib scikit-learn
```

Alternatively, if you create a `requirements.txt` file:
```text
pandas>=1.3.0
numpy>=1.20.0
matplotlib>=3.4.0
scikit-learn>=1.0.0
```

Install using:
```bash
pip install -r requirements.txt
```

Verify your installation by testing package imports:
```bash
python -c "import pandas, numpy, matplotlib, sklearn; print('All dependencies imported successfully!')"
```

---

## Step 4: Verify the Dataset

Examine the first few rows of the pizza menu catalog:

```bash
head -n 6 data/pizza_menu.csv
```

Expected output:
```text
diameter_inches,toppings,price_usd
10.5,3,19.03
13.3,5,25.35
15.6,0,18.66
14.3,3,23.63
10.0,5,22.17
```

Confirm that the dataset contains exactly 45 menu configurations (plus 1 header line = 46 lines total):
```bash
wc -l data/pizza_menu.csv
```

---

## Step 5: Run the Pipeline

Execute the primary script:

```bash
python main.py
```

---

## Step 6: Verify Outputs & Generated Artifacts

### 1. Terminal Console Output
Verify that standard output displays the regression equation, evaluation metrics, benchmark quote, and the 4-tier model price list:

```text
============================================================
THE PIZZA PRICE CALCULATOR
============================================================
Equation: price = 4.02 + 0.97 x diameter + 1.81 x toppings
Mean absolute error: $0.58
R-squared: 0.98
Quote for a 12-inch pizza with 3 toppings: $21.05

Price list from the model:
  Small, 8-inch, 1 topping            $13.56
  Medium, 12-inch, 3 toppings         $21.05
  Large, 16-inch, 5 toppings          $28.53
  Party, 18-inch, 5 toppings          $30.46

Saved: outputs/actual_vs_predicted.png, outputs/quotes.txt
Try this: add a 'stuffed_crust' true/false column and retrain.
```

### 2. Diagnostic Plot Artifact
Verify that `outputs/actual_vs_predicted.png` was created:
- A square 6x6-inch diagnostic scatter plot showing test set predictions vs. actual prices.
- An ideal 45-degree dashed blue parity line.
- Orange points clustered closely along the reference diagonal, confirming high predictive fidelity.

### 3. Catalog Text File Artifact
Inspect `outputs/quotes.txt`:
```bash
cat outputs/quotes.txt
```
Expected content:
```text
equation: price = 4.0224 + 0.9656*diameter + 1.8125*toppings
MAE: 0.5791
R2: 0.9762

Small, 8-inch, 1 topping: $13.56
Medium, 12-inch, 3 toppings: $21.05
Large, 16-inch, 5 toppings: $28.53
Party, 18-inch, 5 toppings: $30.46
```

---

## Step 7: Troubleshooting Common Issues

| Issue | Cause | Solution |
|---|---|---|
| `ModuleNotFoundError: No module named 'sklearn'` | Dependencies not installed in active environment | Run `pip install scikit-learn` in your activated environment |
| `FileNotFoundError: data/pizza_menu.csv` | Script executed from outside the project directory | Ensure you are in the directory containing `main.py` or verify `pathlib` relative path anchoring |
| `UserWarning: X does not have valid feature names` | Passing a raw NumPy array or DataFrame without column names to `predict()` | Wrap single queries in a DataFrame with matching column names: `pd.DataFrame([{"diameter_inches": d, "toppings": t}])` |
| GUI / Display Server Error with Matplotlib | Matplotlib attempting to open an interactive GUI window on a headless server | Ensure `matplotlib.use("Agg")` is called before importing `pyplot` |

---

## Step 8: Hands-On Exploration

Try calling `quote_pizza()` interactively from the Python REPL:
```python
python -i main.py
>>> quote_pizza(14.0, 2)
17.54
>>> quote_pizza(20.0, 4)
30.58
```
Then proceed to **Module 01** to study the theoretical foundation and code architecture in depth.
