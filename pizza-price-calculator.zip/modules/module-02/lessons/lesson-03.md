# Lesson 03: Visualizing Price vs. Diameter: Scatter Plots and Trends

**Lesson ID:** lesson-03
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Generate and interpret bivariate scatter plots of pizza diameter versus price
- Configure matplotlib with non-interactive headless backends (`Agg`)
- Identify linear trends and estimate the empirical slope of price increases per diameter inch
- Recognize unexplained variance caused by secondary features (toppings) in 2D projections
- Apply visual diagnostics to confirm whether a linear model is appropriate for the data

## Prerequisites
- Completion of Lessons 01 and 02
- Basic understanding of Cartesian coordinate systems ($x, y$ axes)

## Concept Explanation

### The Power of Bivariate Visualization
Before fitting statistical algorithms, data scientists visually inspect the relationship between individual features and the target. A **scatter plot** maps each observation in the dataset to a point on a Cartesian plane, where the horizontal axis ($x$) represents the feature and the vertical axis ($y$) represents the target.

When plotting `diameter_inches` against `price_usd`, we seek answers to key questions:
1. **Directionality:** Does price increase as diameter increases? (Positive correlation)
2. **Linearity:** Does the relationship resemble a straight line, or does it exhibit severe exponential or logarithmic curvature?
3. **Spread / Noise:** Are points tightly clustered along a line, or is there substantial vertical scatter at any given diameter?

```mermaid
flowchart LR
    A["Diameter (x)"] --> B["Bivariate Scatter Plot"]
    C["Price (y)"] --> B
    B --> D["Observation: Upward Linear Trend"]
    B --> E["Observation: Vertical Scatter at same Diameter"]
    E --> F["Hypothesis: Secondary Feature (Toppings) causes the scatter!"]
```

### The Headless Backend (`matplotlib.use('Agg')`)
When running machine learning scripts on cloud servers, automated containers, or command-line terminals without graphical displays, attempting to open a GUI window with `plt.show()` triggers an error:
```
UserWarning: Matplotlib is currently using agg, which is a non-GUI backend, so cannot show the figure.
```
To avoid GUI dependency issues, `main.py` establishes the **Agg** backend before importing pyplot:
```python
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
```
The **Agg** (Anti-Grain Geometry) backend renders raster images directly to in-memory buffers or image files (`.png`, `.jpg`) without requiring an active desktop display server (such as X11 or Wayland).

### Interpreting the Diameter vs Price Scatter
When we plot diameter vs price across the 45 menu items, we observe:
- **Strong Positive Linear Trend:** As diameter expands from 8 inches to 18 inches, base prices rise from roughly $13 to over $30.
- **Vertical Dispersion:** At any specific diameter (for example, 10.0 inches), we observe multiple distinct price points:
  - 10.0 inches, 0 toppings: $12.59
  - 10.0 inches, 0 toppings: $13.76
  - 10.0 inches, 2 toppings: $17.48
  - 10.0 inches, 5 toppings: $22.17
The vertical spread at 10.0 inches spans nearly $10.00! This confirms visually that diameter alone cannot explain pizza pricing—the secondary feature (`toppings`) is responsible for the vertical dispersion.

## Relevant Code (from main.py, lines 12-15)
```python
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
```

## Code Architecture and Walkthrough
- **Line 12-14:** `matplotlib.use("Agg")` must be invoked **before** importing `matplotlib.pyplot`. If pyplot is imported first, matplotlib initializes its default interactive backend, making subsequent `.use()` calls ineffective or triggering backend-already-loaded warnings.
- **Line 15:** `import matplotlib.pyplot as plt` imports the standard procedural plotting interface.

## Worked Example
Let us write an exploratory script to visualize diameter vs price and save the plot:
```python
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

df = pd.read_csv("data/pizza_menu.csv")

fig, ax = plt.subplots(figsize=(7, 5))
ax.scatter(df["diameter_inches"], df["price_usd"], color="#e67e22", s=60, alpha=0.8, edgecolors="none")

ax.set_xlabel("Pizza Diameter (inches)", fontsize=11)
ax.set_ylabel("Price (USD)", fontsize=11)
ax.set_title("Exploratory Analysis: Pizza Diameter vs. Price", fontsize=12, fontweight="bold")
ax.grid(True, linestyle="--", alpha=0.5)

fig.tight_layout()
fig.savefig("diameter_vs_price_scatter.png", dpi=150)
plt.close(fig)
print("Saved exploratory scatter plot: diameter_vs_price_scatter.png")
```
When generated, the plot shows a clear upward trend with an empirical slope of roughly $1.00 per inch, alongside vertical clusters created by varying topping counts.

## Step-by-Step Implementation Guide
1. Import `matplotlib` and set the backend: `matplotlib.use('Agg')`.
2. Import `matplotlib.pyplot as plt` and `pandas as pd`.
3. Load `pizza_menu.csv`.
4. Initialize a figure and axes: `fig, ax = plt.subplots(figsize=(6, 5))`.
5. Scatter plot `df['diameter_inches']` on $x$ and `df['price_usd']` on $y$.
6. Label axes and title clearly, including units of measurement.
7. Save the figure to disk using `fig.savefig('scatter.png', dpi=150, bbox_inches='tight')`.
8. Always call `plt.close(fig)` to release memory.

## Expected Output and Verification
Inspecting the generated figure reveals:
1. Data points distributed smoothly between 8.4 and 17.6 inches.
2. Prices strictly increasing with diameter.
3. No non-linear saturations (such as plateaus or parabolic dips) within the observed menu range.
4. Confirmation that linear regression is a mathematically valid assumption.

## Practical Exercises
- **Exercise 3.1:** Compute the Pearson correlation coefficient between `diameter_inches` and `price_usd` using `df['diameter_inches'].corr(df['price_usd'])`. What does the value indicate?
- **Exercise 3.2:** Filter the DataFrame for only pizzas with 0 toppings (`df[df['toppings'] == 0]`) and plot diameter vs price. Does the vertical scatter disappear?
- **Exercise 3.3:** Why is calling `plt.close(fig)` especially critical when generating dozens or hundreds of plots in automated loops?

## Common Pitfalls and Debugging Strategies
| Pitfall | Root Cause | Debugging Strategy |
|---|---|---|
| Blank or corrupted image saved | Calling `plt.savefig()` after `plt.close()` | Always save the figure before calling `plt.close(fig)`. |
| Script hangs or crashes on server | Calling `plt.show()` on a headless remote server | Set `matplotlib.use('Agg')` at the very top of the script and save images with `savefig()`. |
| Axis labels cut off in saved file | Large fonts overflowing bounding box | Pass `bbox_inches='tight'` to `fig.savefig()`. |

## Best Practices and Industry Standards
- **Always Configure Headless Backends:** Set `matplotlib.use('Agg')` in production scripts to ensure seamless execution in CI/CD pipelines and Docker containers.
- **Explicit Memory Management:** Always call `plt.close(fig)` after saving figures to avoid memory leaks in long-running services.
- **Label Units Explicitly:** Always specify physical units in axis labels (e.g., "Diameter (inches)" and "Price (USD)").

## Real-World Business Context
Exploratory data visualization is a mandatory first step in commercial pricing analytics. If a franchise notices pricing plateaus (e.g., 14-inch and 16-inch pizzas selling for the same price due to legacy promotions), data scientists alert marketing executives before fitting models, preventing legacy pricing inconsistencies from being codified into automated algorithms.

## Summary and Key Takeaways
- Bivariate scatter plots reveal positive linear correlation between pizza diameter and menu price.
- Substantial vertical dispersion at identical diameters indicates that diameter alone does not fully explain pricing.
- Setting `matplotlib.use('Agg')` ensures reliable headless image generation in automated environments.

## Knowledge Check and Self-Assessment
1. Why must `matplotlib.use('Agg')` be executed before importing `matplotlib.pyplot`?
2. What does the vertical dispersion of prices at a constant diameter of 10.0 inches reveal about the pricing model?
3. What is the approximate Pearson correlation between pizza diameter and price?
4. Why is `plt.close(fig)` called at the end of plotting routines?

## References and Further Reading
- Matplotlib Backends Guide: https://matplotlib.org/stable/users/explain/backends.html
- Matplotlib Scatter Plot Documentation: https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.scatter.html
- Exploratory Data Analysis with Python: https://realpython.com/pandas-python-explore/
