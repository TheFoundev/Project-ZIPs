# Lesson 01: Ingesting Tabular Data with Pandas and Pathlib

**Lesson ID:** lesson-01
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why `pathlib.Path` provides a more robust file-handling approach than hardcoded strings
- Locate and ingest `data/pizza_menu.csv` into a pandas DataFrame
- Inspect DataFrame metadata, row indices, column data types, and memory footprints
- Identify missing or corrupted entries in tabular datasets
- Verify environment and folder readiness prior to downstream model operations

## Prerequisites
- Basic familiarity with Python variables and imports
- Understanding of tabular files (.csv)

## Concept Explanation

### The Fragility of Hardcoded Paths in Production
When developing software scripts, beginner developers often load data using raw relative string literals:
```python
df = pd.read_csv("data/pizza_menu.csv")
```
While this works if the user's terminal happens to be open in the exact folder where the script lives, it breaks immediately if invoked from any other working directory (for example, executing `python projects/08_pizza_price/main.py` from the repository root). The Python interpreter looks for a `data/` subdirectory relative to the current terminal working directory, raising a fatal `FileNotFoundError`.

To eliminate this fragility, modern Python applications rely on standard library `pathlib.Path`:
```python
from pathlib import Path
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
```
Here, `__file__` is a special variable pointing to the executing script itself. Calling `.resolve().parent` computes the absolute filesystem path of the directory enclosing `main.py`. The division operator (`/`) is overloaded by `Path` objects to construct clean, cross-platform paths on Linux, macOS, and Windows alike.

### Ingestion Mechanics with Pandas
The `pd.read_csv()` function converts a comma-delimited disk file into a structured two-dimensional memory container: a `pandas.DataFrame`. During parsing, pandas automatically infers the data types of each column:
- Floating-point numbers (`10.5`, `19.03`) are parsed into 64-bit floats (`float64`).
- Integer counts (`3`, `5`, `0`) are parsed into 64-bit integers (`int64`).
- Header names are assigned as the DataFrame's column index.

### Verification of Data Hygiene
Before feeding records into machine learning models, engineers perform three verification checks:
1. **Dimension Verification:** Does the table contain the expected count of rows and columns? (`df.shape`)
2. **Missing Value Auditing:** Are there null or NaN values that would cause estimators to fail? (`df.isna().sum()`)
3. **Type Consistency:** Are numerical values represented as native numbers rather than textual strings? (`df.dtypes`)

## Relevant Code (from main.py, lines 21-28)
```python
from pathlib import Path
import pandas as pd

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)


def main() -> None:
    df = pd.read_csv(DATA / "pizza_menu.csv")
```

## Code Architecture and Walkthrough
- **Line 21:** `BASE = Path(__file__).resolve().parent` resolves the canonical parent path.
- **Line 22:** `DATA = BASE / "data"` anchors the data directory relative to the script location.
- **Line 23-24:** `OUT = BASE / "outputs"` defines the artifact output directory. `OUT.mkdir(exist_ok=True)` creates the directory if it does not already exist, preventing runtime errors when plots or text reports are saved later.
- **Line 28:** `pd.read_csv(DATA / "pizza_menu.csv")` ingests the file using the resolved path.

## Worked Example
Let us trace what occurs under the hood when loading `pizza_menu.csv`:
```python
import pandas as pd
from pathlib import Path

BASE = Path.cwd()
DATA = BASE / "data"

df = pd.read_csv(DATA / "pizza_menu.csv")

# 1. Inspect dimensions
print(f"Shape: {df.shape}")

# 2. Inspect first 3 rows
print("
First 3 rows:")
print(df.head(3))

# 3. Check for null values
print("
Missing values per column:")
print(df.isna().sum())
```
Execution yields:
```
Shape: (45, 3)

First 3 rows:
   diameter_inches  toppings  price_usd
0             10.5         3      19.03
1             13.3         5      25.35
2             15.6         0      18.66

Missing values per column:
diameter_inches    0
toppings           0
price_usd          0
dtype: int64
```
The audit confirms: 45 clean rows, 3 columns, and zero missing data points.

## Step-by-Step Implementation Guide
1. Launch your Python interpreter or editor in the project directory.
2. Import `pathlib.Path` and `pandas as pd`.
3. Set `BASE = Path(__file__).resolve().parent` (or `Path.cwd()` in an interactive notebook).
4. Define `DATA = BASE / "data"` and verify the directory exists with `DATA.exists()`.
5. Execute `df = pd.read_csv(DATA / "pizza_menu.csv")`.
6. Inspect the summary statistics using `df.describe()`.
7. Verify that minimum diameter is approximately 8.4 inches and maximum is 17.6 inches.

## Expected Output and Verification
Calling `df.describe()` displays the statistical distribution of the dataset:
```
       diameter_inches   toppings  price_usd
count        45.000000  45.000000  45.000000
mean         13.328889   2.600000  21.205778
std           2.668707   1.763261   4.254146
min           8.400000   0.000000  12.590000
50%          13.300000   3.000000  21.320000
max          17.600000   5.000000  30.460000
```
This confirms that the data has loaded accurately and is distributed evenly across standard commercial ranges.

## Practical Exercises
- **Exercise 1.1:** Write a one-line Python statement to check if any column contains negative numbers in `df`.
- **Exercise 1.2:** Calculate the average price of pizzas that have exactly 5 toppings.
- **Exercise 1.3:** Create a new column in `df` called `price_per_inch` by dividing `price_usd` by `diameter_inches`. What is the minimum and maximum ratio?

## Common Pitfalls and Debugging Strategies
| Pitfall | Root Cause | Debugging Strategy |
|---|---|---|
| `FileNotFoundError` | Hardcoded relative path strings failing under different terminal directories | Always use `Path(__file__).resolve().parent` to anchor paths. |
| Corrupted CSV delimiter | File saved with semicolons (`;`) or tabs instead of commas | Inspect raw file in terminal using `head` and specify `sep=';'` if required. |
| Non-numeric strings in numeric columns | Spaces or currency symbols in data rows | Use `pd.to_numeric(df['col'], errors='coerce')` to find rogue string entries. |

## Best Practices and Industry Standards
- **Use Pathlib for All Paths:** Treat filesystem paths as objects rather than strings to guarantee operating system portability.
- **Always Audit Missing Data:** Never pass raw ingested DataFrames directly to estimators without first checking `df.isna().sum()`.
- **Pre-create Output Directories:** Use `exist_ok=True` on `mkdir()` to make execution idempotent across repeated automated pipeline runs.

## Real-World Business Context
In production restaurant technology, data ingestion pipelines pull nightly sales tables from hundreds of franchise POS databases. Automated data quality validation ensures that corrupt receipts or negative promotional discounts do not poison production pricing models.

## Summary and Key Takeaways
- `pathlib.Path` resolves file paths relative to the script location, eliminating `FileNotFoundError` across execution environments.
- `pd.read_csv()` ingests `pizza_menu.csv` into a clean 45-row by 3-column DataFrame.
- Automated data hygiene auditing (`shape`, `isna().sum()`, `describe()`) guarantees dataset integrity before model fitting.

## Knowledge Check and Self-Assessment
1. Why does `Path(__file__).resolve().parent` prevent `FileNotFoundError` when executing scripts from parent directories?
2. What are the three columns present in `data/pizza_menu.csv`?
3. How many observations exist in the pizza menu dataset?
4. What pandas method provides summary statistics (mean, std, min, max) for all numeric columns?

## References and Further Reading
- Python Pathlib Documentation: https://docs.python.org/3/library/pathlib.html
- Pandas read_csv User Guide: https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.read_csv.html
- Data Cleaning Best Practices in Python: https://realpython.com/python-data-cleaning-numpy-pandas/
