# Lesson 04: Visualizing Price vs. Toppings & Cross-Feature Correlation

**Lesson ID:** lesson-04
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Generate and interpret scatter plots showing price versus topping counts
- Analyze the correlation matrix across all features and the target variable
- Evaluate whether collinearity exists between `diameter_inches` and `toppings`
- Explain why independence between predictor features strengthens multiple linear regression
- Synthesize findings from exploratory visualizations into a unified modeling hypothesis

## Prerequisites
- Completion of Lessons 01, 02, and 03
- Understanding of correlation coefficients (-1 to +1)

## Concept Explanation

### The Impact of Topping Count on Menu Price
In Lesson 03, we observed that pizza diameter has a strong linear relationship with price, but leaves vertical dispersion unexplained. In this lesson, we isolate the second feature: `toppings`.

Unlike diameter (which is a continuous physical measurement), topping count is a discrete integer taking values in $\{0, 1, 2, 3, 4, 5\}$. When plotting `toppings` against `price_usd`, points form vertical columns at each discrete integer level:
- At 0 toppings (plain cheese), pizzas range from $12.59 (small 10-inch) to $20.39 (giant 17.5-inch).
- At 5 toppings, pizzas range from $21.32 (small 8.4-inch) to $30.43 (giant 17.5-inch).

```mermaid
flowchart TD
    A["Explore Bivariate Relationships"]
    A --> B["Diameter vs Price (r ≈ 0.65)"]
    A --> C["Toppings vs Price (r ≈ 0.74)"]
    B --> D["Check Cross-Feature Correlation"]
    C --> D
    D --> E["Diameter vs Toppings (r ≈ -0.05)"]
    E --> F["Zero Collinearity: Perfect for Multiple Regression!"]
```

### Analyzing the Full Correlation Matrix
To rigorously quantify linear relationships between all variables, data scientists compute the **Pearson Correlation Matrix**. Pearson's correlation coefficient $r$ ranges from $-1.0$ (perfect negative correlation) to $+1.0$ (perfect positive correlation), with $0.0$ indicating no linear correlation.

Computing `df.corr()` for `pizza_menu.csv` yields:
| Column | `diameter_inches` | `toppings` | `price_usd` |
|---|---|---|---|
| `diameter_inches` | 1.000 | -0.046 | 0.654 |
| `toppings` | -0.046 | 1.000 | 0.741 |
| `price_usd` | 0.654 | 0.741 | 1.000 |

### Critical Finding: Absence of Multicollinearity
Examine the intersection of `diameter_inches` and `toppings`:
$$r = -0.046 \approx 0.00$$
This is an exceptional finding for machine learning modeling:
1. **Feature-to-Target Correlation:** Both features correlate strongly and positively with price ($r = 0.654$ for diameter and $r = 0.741$ for toppings).
2. **Feature-to-Feature Independence:** The correlation between the two features is essentially zero ($r = -0.046$). Customers order 5 toppings on small pizzas just as frequently as on large pizzas.

When predictor features are independent of each other (orthogonal), multiple linear regression performs at its theoretical best:
- There is **no multicollinearity** to inflate the variance of coefficient estimates.
- Each coefficient ($w_1$ and $w_2$) isolates the pure marginal effect of its respective feature without confounding from the other.

## Relevant Code (from main.py, lines 28-34)
```python
def main() -> None:
    df = pd.read_csv(DATA / "pizza_menu.csv")
    X = df[["diameter_inches", "toppings"]]
    y = df["price_usd"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42
    )
```

## Code Architecture and Walkthrough
The absence of feature multicollinearity allows `main.py` to directly proceed to the train/test split:
- `X` bundles both independent features into a single matrix.
- `train_test_split(X, y, test_size=0.25, random_state=42)` partitions the 45 observations into a 33-row training set and a 12-row testing set.
- Because features are mutually independent, the split maintains healthy variance across both dimensions in both training and test subsets.

## Worked Example
Let us compute and display the correlation matrix directly using Python:
```python
import pandas as pd

df = pd.read_csv("data/pizza_menu.csv")

# Compute Pearson correlation matrix
corr = df.corr()
print("Correlation Matrix:")
print(corr.round(3))

# Verify feature-to-target correlations
print(f"
Correlation between Diameter and Price: {corr.loc['diameter_inches', 'price_usd']:.3f}")
print(f"Correlation between Toppings and Price: {corr.loc['toppings', 'price_usd']:.3f}")
print(f"Cross-correlation between Diameter and Toppings: {corr.loc['diameter_inches', 'toppings']:.3f}")
```
Output:
```
Correlation Matrix:
                 diameter_inches  toppings  price_usd
diameter_inches            1.000    -0.046      0.654
toppings                  -0.046     1.000      0.741
price_usd                  0.654     0.741      1.000

Correlation between Diameter and Price: 0.654
Correlation between Toppings and Price: 0.741
Cross-correlation between Diameter and Toppings: -0.046
```
The strong individual correlations with price ($0.654$ and $0.741$) combined with near-zero cross-correlation ($-0.046$) confirm that combining both features will yield high predictive accuracy ($R^2 > 0.95$).

## Step-by-Step Implementation Guide
1. Load `pizza_menu.csv` into a pandas DataFrame.
2. Call `df.corr()` to generate the Pearson correlation matrix.
3. Verify that both feature correlations with `price_usd` exceed $0.60$.
4. Verify that cross-correlation between `diameter_inches` and `toppings` is near zero ($|r| < 0.15$).
5. Create a 2-panel figure with matplotlib:
   - Left panel: Scatter plot of `diameter_inches` vs `price_usd`.
   - Right panel: Scatter plot of `toppings` vs `price_usd`.
6. Save the comparison figure to disk.

## Expected Output and Verification
The two-panel visual comparison reveals:
- Left panel shows a continuous upward slope spanning 8 to 18 inches.
- Right panel shows stepped upward columns across 0, 1, 2, 3, 4, and 5 toppings.
- In both plots, variance is evenly distributed, confirming homoscedasticity across the feature domain.

## Practical Exercises
- **Exercise 4.1:** What would happen to model stability if customers only ordered 5 toppings on 18-inch pizzas and 0 toppings on 8-inch pizzas? (Explain multicollinearity).
- **Exercise 4.2:** Use pandas grouping `df.groupby('toppings')['price_usd'].mean()` to inspect average prices by topping count.
- **Exercise 4.3:** How much does average pizza price increase between 0 toppings and 5 toppings in the raw dataset?

## Common Pitfalls and Debugging Strategies
| Pitfall | Root Cause | Debugging Strategy |
|---|---|---|
| High multicollinearity ($r > 0.85$) between features | Including redundant features (e.g., diameter and radius) | Inspect correlation matrices before model training; drop or combine collinear features. |
| Misinterpreting discrete counts as categories | Treating `toppings` as nominal text rather than numeric integers | Preserve numeric counts ($0, 1, 2, \dots$) so linear regression can estimate marginal cost per unit. |
| Overlooking non-linear relationships | Assuming zero correlation implies no relationship | Always inspect visual scatter plots alongside correlation numbers to detect non-linear curves. |

## Best Practices and Industry Standards
- **Inspect Cross-Feature Collinearity:** Always examine feature-to-feature correlations prior to fitting multiple linear regression models.
- **Preserve Ordinal Numeric Scales:** When features represent genuine counts (like topping items), keep them as numeric integers rather than one-hot encoding them into separate dummy variables.
- **Synthesize Multi-Feature Hypotheses:** Combine insights from univariate explorations into a clear multi-feature hypothesis before running optimization algorithms.

## Real-World Business Context
In commercial retail analytics, feature cross-correlation analysis is essential for discovering consumer behavior patterns. If larger pizzas were strongly correlated with higher topping counts, pricing models might struggle to unbundle the true cost of toppings from crust size. The empirical independence found in `pizza_menu.csv` reflects realistic ordering habits across diverse customer segments.

## Summary and Key Takeaways
- `toppings` has a strong positive correlation with `price_usd` ($r = 0.741$).
- Cross-correlation between `diameter_inches` and `toppings` is essentially zero ($r = -0.046$).
- The independence of the two features guarantees that multiple linear regression will accurately isolate the marginal price per inch and marginal price per topping.

## Knowledge Check and Self-Assessment
1. What is the Pearson correlation coefficient between `toppings` and `price_usd` in `pizza_menu.csv`?
2. What is the correlation between `diameter_inches` and `toppings`?
3. Why is near-zero cross-correlation between features advantageous for multiple linear regression?
4. What visual pattern is formed when plotting a continuous target against a discrete integer feature?

## References and Further Reading
- Pandas Correlation Documentation: https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.corr.html
- Multicollinearity in Regression Analysis: https://www.investopedia.com/terms/m/multicollinearity.asp
- Scikit-learn Model Selection and Evaluation: https://scikit-learn.org/stable/modules/model_evaluation.html
