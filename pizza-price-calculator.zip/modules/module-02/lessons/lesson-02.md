# Lesson 02: Extracting Features and Target for Scikit-Learn

**Lesson ID:** lesson-02
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Formulate the feature matrix $X$ and target vector $y$ from a raw DataFrame
- Differentiate between a pandas DataFrame (2D) and a pandas Series (1D)
- Explain why scikit-learn estimators strictly require 2D feature matrices
- Verify array shapes and memory layouts before invoking `model.fit()`
- Avoid common indexing errors that trigger runtime exceptions during training

## Prerequisites
- Completion of Lesson 01
- Understanding of Python lists and pandas indexing operators

## Concept Explanation

### The Mathematical Role of $X$ and $y$
In supervised machine learning, algorithms estimate a mapping function $f$ such that:
$$\hat{y} = f(X)$$
where:
- $X$ is the **Feature Matrix** (also called design matrix, inputs, or independent variables).
- $y$ is the **Target Vector** (also called labels, outputs, or dependent variable).

In our pizza pricing problem:
- $X$ contains two predictor features: `diameter_inches` and `toppings`.
- $y$ contains the single continuous outcome: `price_usd`.

### DataFrame (2D) vs Series (1D) in Pandas
The syntax used to slice columns in pandas fundamentally alters the dimensionality of the returned object:
1. **Single Square Brackets `df["column_name"]`:** Returns a 1D `pandas.Series`. A Series has a shape of `(n_samples,)`—it has length, but lacks a second column dimension.
2. **Double Square Brackets `df[["column_name"]]`:** Passes a Python list of column names into the indexer, returning a 2D `pandas.DataFrame`. Even with a single column, its shape is `(n_samples, 1)`. When passed multiple columns `df[["col1", "col2"]]`, its shape is `(n_samples, 2)`.

```mermaid
flowchart TD
    A["Raw DataFrame df (45, 3)"] --> B["X = df[['diameter_inches', 'toppings']]"]
    A --> C["y = df['price_usd']"]
    B --> D["2D DataFrame: shape (45, 2)"]
    C --> E["1D Series: shape (45,)"]
    D --> F["Scikit-Learn Estimator Expects (n_samples, n_features)"]
    E --> G["Scikit-Learn Estimator Expects (n_samples,)"]
```

### Why Scikit-Learn Enforces 2D Feature Matrices
Scikit-learn adheres to strict object-oriented design standards across all estimators:
- The method `estimator.fit(X, y)` expects $X$ to represent a two-dimensional matrix of dimensions `(n_samples, n_features)`. This allows the estimator to consistently query `X.shape[1]` to determine how many weight coefficients ($w_1, w_2, \dots, w_p$) to allocate during optimization.
- If a 1D array of shape `(n_samples,)` is passed as $X$, scikit-learn raises a `ValueError`:
  ```
  ValueError: Expected 2D array, got 1D array instead:
  Reshape your data either using array.reshape(-1, 1) if your data has a single feature...
  ```
- Conversely, for single-target regression, $y$ is expected to be a 1D vector of shape `(n_samples,)` representing one scalar truth per sample.

## Relevant Code (from main.py, lines 28-31)
```python
def main() -> None:
    df = pd.read_csv(DATA / "pizza_menu.csv")
    X = df[["diameter_inches", "toppings"]]
    y = df["price_usd"]
```

## Code Architecture and Walkthrough
- **Line 29:** `X = df[["diameter_inches", "toppings"]]` explicitly selects the two predictor columns using double brackets. This constructs a 2D DataFrame with 45 rows and 2 columns.
- **Line 30:** `y = df["price_usd"]` selects the ground-truth target using single brackets, yielding a 1D Series with 45 elements.

## Worked Example
Let us observe the concrete Python objects and their internal shapes:
```python
import pandas as pd
from pathlib import Path

df = pd.read_csv("data/pizza_menu.csv")

X = df[["diameter_inches", "toppings"]]
y = df["price_usd"]

print(f"Type of X: {type(X)}")
print(f"Shape of X: {X.shape}")
print(f"Dimensions of X: {X.ndim}")

print(f"
Type of y: {type(y)}")
print(f"Shape of y: {y.shape}")
print(f"Dimensions of y: {y.ndim}")
```
Output:
```
Type of X: <class 'pandas.core.frame.DataFrame'>
Shape of X: (45, 2)
Dimensions of X: 2

Type of y: <class 'pandas.core.frame.Series'>
Shape of y: (45,)
Dimensions of y: 1
```
This confirms that $X$ and $y$ perfectly fulfill scikit-learn's architectural requirements.

## Step-by-Step Implementation Guide
1. Ingest `pizza_menu.csv` using pandas.
2. Inspect column names: `list(df.columns)`.
3. Construct the feature matrix: `X = df[['diameter_inches', 'toppings']]`.
4. Construct the target vector: `y = df['price_usd']`.
5. Check shapes: `assert X.shape == (45, 2)` and `assert y.shape == (45,)`.
6. Inspect the first 5 feature rows with `X.head()`.

## Expected Output and Verification
Inspecting `X.head()` verifies that column headers are retained:
```
   diameter_inches  toppings
0             10.5         3
1             13.3         5
2             15.6         0
3             14.3         3
4             10.0         5
```
Retaining column names allows scikit-learn to preserve feature metadata, which aids debugging and feature importance analysis.

## Practical Exercises
- **Exercise 2.1:** What happens if you run `X = df[['diameter_inches']]`? What is the shape of $X$, and why would scikit-learn accept it?
- **Exercise 2.2:** What happens if you run `y = df[['price_usd']]` with double brackets? Does `LinearRegression.fit(X, y)` accept a 2D $y$? (Test this in Python).
- **Exercise 2.3:** Write a Python function `validate_inputs(X, y)` that asserts $X$ has 2 dimensions, $y$ has 1 dimension, and `len(X) == len(y)`.

## Common Pitfalls and Debugging Strategies
| Pitfall | Root Cause | Debugging Strategy |
|---|---|---|
| `KeyError: ('diameter_inches', 'toppings')` | Single brackets around comma-separated strings `df['col1', 'col2']` | Use double brackets `df[['col1', 'col2']]` to pass a list. |
| `ValueError: Expected 2D array` | Passing a 1D Series as $X$ to `model.fit()` | Wrap feature column in double brackets or call `.to_frame()`. |
| Target leakage | Including `price_usd` inside the feature list `X` | Double check that `price_usd` appears ONLY in $y$, never in $X$. |

## Best Practices and Industry Standards
- **Explicit Feature Selection:** Explicitly declare feature column lists rather than relying on column dropping (`df.drop(...)`), as schema changes can inadvertently inject unintended columns.
- **Enforce Separation of Concerns:** Keep feature extraction cleanly separated from preprocessing, splitting, and training.
- **Verify Sample Alignment:** Always ensure `len(X) == len(y)` to guarantee that every feature row corresponds to exactly one target observation.

## Real-World Business Context
In production feature stores (like Feast or AWS SageMaker Feature Store), feature tables are segregated from transaction labels. Feature engineering pipelines extract independent attributes while billing systems provide audited ground-truth revenue numbers. Ensuring consistent dimensional contracts is fundamental to stable automated ML systems.

## Summary and Key Takeaways
- Scikit-learn requires feature matrices $X$ to be 2D `(n_samples, n_features)` and target vectors $y$ to be 1D `(n_samples,)`.
- In pandas, double brackets `df[['col1', 'col2']]` produce a 2D DataFrame, while single brackets `df['col']` produce a 1D Series.
- For `pizza_menu.csv`, `X.shape` is `(45, 2)` and `y.shape` is `(45,)`.

## Knowledge Check and Self-Assessment
1. What error does scikit-learn raise if you pass a 1D array as the feature matrix $X$?
2. What is the syntactic difference between extracting a Series versus a DataFrame in pandas?
3. What are the exact dimensions of $X$ and $y$ in `main.py`?
4. Why must `price_usd` never be included inside the feature matrix $X$?

## References and Further Reading
- Scikit-learn API Design Principles: https://arxiv.org/abs/1309.0238
- Pandas Data Structures: https://pandas.pydata.org/pandas-docs/stable/user_guide/dsintro.html
- Python Data Science Handbook: Data Manipulation with Pandas
