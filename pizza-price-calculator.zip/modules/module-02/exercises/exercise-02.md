# Module 2 Exercises: Data Ingestion, Correlation Exploration & Feature Formatting

## Exercise 2.1: Robust Ingestion and Hygiene Auditing (15 min)
**Objective:** Ingest `data/pizza_menu.csv` using `pathlib.Path` and pandas, and implement an automated data hygiene audit.
**Problem Statement:** You must create an ingestion module that guarantees cross-platform reliability, checks for missing data, and verifies data types before any machine learning modeling occurs.

**Requirements:**
1. Use `pathlib.Path(__file__).resolve().parent` to locate `data/pizza_menu.csv`.
2. Load the dataset into a pandas DataFrame.
3. Write an auditing function `audit_dataset(df)` that checks:
   - Row count (must be 45)
   - Column names (must contain `diameter_inches`, `toppings`, `price_usd`)
   - Null count across all columns (must be 0)
   - Data types (`diameter_inches` and `price_usd` as floats, `toppings` as integer)
4. Print a formatted confirmation message if all checks pass.

**Constraints:** Write clean, modular Python code matching the architecture of `main.py`.

**Expected Behaviour:** The script runs cleanly and prints an affirmative audit report.

**Acceptance Criteria:**
- [ ] Uses `pathlib.Path` to anchor paths relative to the script location.
- [ ] Confirms exact row count of 45.
- [ ] Confirms exact column headers.
- [ ] Asserts 0 null values across all columns.
- [ ] Validates column numeric data types.

**Hints:**
- Use `df.isna().sum().sum() == 0` to check for missing values.
- Check column dtypes using `df.dtypes`.

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 2.2: Feature Matrix and Target Vector Construction (15 min)
**Objective:** Correctly extract the 2D feature matrix $X$ and 1D target vector $y$, asserting dimensional validity.
**Problem Statement:** Scikit-learn estimators fail if feature matrices lack a 2D shape. You must implement the extraction logic and verify shapes programmatically.

**Requirements:**
1. Extract `diameter_inches` and `toppings` into `X` using double brackets.
2. Extract `price_usd` into `y` using single brackets.
3. Assert that `X.shape == (45, 2)` and `y.shape == (45,)`.
4. Demonstrate in comments or code what error occurs if `df['diameter_inches', 'toppings']` is used.
5. Demonstrate what error occurs if a 1D Series is passed to `LinearRegression.fit()`.

**Constraints:** Use pandas and scikit-learn.

**Expected Behaviour:** Script verifies shapes and demonstrates scikit-learn's dimensionality requirements.

**Acceptance Criteria:**
- [ ] `X` extracted as DataFrame of shape `(45, 2)`.
- [ ] `y` extracted as Series of shape `(45,)`.
- [ ] Assertions verify shapes without raising exceptions.
- [ ] Explains why scikit-learn requires 2D feature inputs.

**Hints:**
- Double brackets pass a list to `__getitem__`.
- Scikit-learn needs `X.shape[1]` to know how many coefficients to initialize.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 2.3: Bivariate Scatter Visualization (15 min)
**Objective:** Generate a publication-quality scatter plot of pizza diameter versus price using headless matplotlib.
**Problem Statement:** Create an exploratory visualization module that plots `diameter_inches` on the x-axis and `price_usd` on the y-axis, saving the result to `outputs/diameter_vs_price.png`.

**Requirements:**
1. Set `matplotlib.use("Agg")` prior to importing `pyplot`.
2. Create a figure with `figsize=(6, 5)`.
3. Scatter plot diameter vs price with distinct color, size, and slight transparency (`alpha=0.85`).
4. Set x-label ("Diameter (inches)"), y-label ("Price (USD)"), title, and grid.
5. Save the figure with `dpi=150` and `bbox_inches='tight'`.
6. Call `plt.close(fig)` to clean up memory.

**Constraints:** Save outputs into an `outputs/` directory created with `mkdir(exist_ok=True)`.

**Expected Behaviour:** A clean PNG image is saved to disk showing the upward diameter-vs-price trend.

**Acceptance Criteria:**
- [ ] Configures `matplotlib.use('Agg')` before importing `pyplot`.
- [ ] Generates scatter plot with appropriate styling.
- [ ] Includes clear axis labels with units.
- [ ] Saves image with `dpi=150` and calls `plt.close(fig)`.

**Hints:**
- Use `Path('outputs').mkdir(exist_ok=True)` before saving.
- The Agg backend prevents GUI display errors on headless servers.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 2.4: Correlation Matrix Analysis and Reporting (15 min)
**Objective:** Compute the Pearson correlation matrix and document why the absence of multicollinearity benefits multiple regression.
**Problem Statement:** Management wants an explanation of why size and toppings can be analyzed together in a single regression equation. You must calculate the correlation matrix and write a short technical justification.

**Requirements:**
1. Compute the Pearson correlation matrix for `pizza_menu.csv` using pandas.
2. Extract and display the correlation between `diameter_inches` and `price_usd` ($r \approx 0.654$).
3. Extract and display the correlation between `toppings` and `price_usd` ($r \approx 0.741$).
4. Extract and display the cross-correlation between `diameter_inches` and `toppings` ($r \approx -0.046$).
5. Write a short explanation (3-5 sentences) explaining why near-zero cross-correlation between features is advantageous for multiple regression.

**Constraints:** Use actual dataset values from `pizza_menu.csv`.

**Expected Behaviour:** Printed correlation statistics accompanied by a concise mathematical explanation.

**Acceptance Criteria:**
- [ ] Correctly calculates correlation values matching the dataset.
- [ ] Identifies that both features strongly correlate with price.
- [ ] Identifies that features have near-zero correlation with each other.
- [ ] Explains that lack of multicollinearity ensures independent, stable coefficient estimation.

**Hints:**
- Use `df.corr().round(3)`.
- When features are uncorrelated, each regression weight reflects the pure marginal effect of that feature.

**Difficulty:** Advanced
**Estimated Completion Time:** 15 minutes
