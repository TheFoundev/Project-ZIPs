# Module 05 Exercises: Evaluation and Residual Diagnostics

These exercises reinforce the concepts of model evaluation, error metrics, variance explanation, and diagnostic visualization learned in Module 05.

---

## Exercise 1: Subgroup Mean Absolute Error Analysis

### Objective
Calculate and compare the Mean Absolute Error across two menu categories: Small/Medium pizzas (diameter <= 12 inches) versus Large/Party pizzas (diameter > 12 inches).

### Background
Overall MAE ($0.58) summarizes the entire test set. However, restaurants often need to verify whether pricing errors are evenly distributed across item categories or concentrated in larger sizes.

### Requirements
1. Partition the test set `X_test` and `y_test` into two subgroups:
   - `small_mask = X_test['diameter_inches'] <= 12`
   - `large_mask = X_test['diameter_inches'] > 12`
2. Compute the MAE for the small/medium subgroup using `mean_absolute_error`.
3. Compute the MAE for the large/party subgroup using `mean_absolute_error`.
4. Print both subgroup MAEs formatted to 2 decimal places with currency signs.

### Acceptance Criteria
- [ ] Script successfully partitions test samples based on diameter.
- [ ] MAE is computed separately for both partitions.
- [ ] Output displays clear comparison: e.g., `Small/Medium MAE: $X.XX` and `Large/Party MAE: $Y.YY`.
- [ ] Script handles empty subsets gracefully without crashing.

---

## Exercise 2: Manual R-Squared Verification Routine

### Objective
Implement the mathematical definition of $R^2$ from scratch without using scikit-learn, and verify that your manual computation matches `sklearn.metrics.r2_score` within 6 decimal places.

### Background
Implementing metrics from first principles solidifies understanding of $SS_{tot}$ (total sum of squares) and $SS_{res}$ (residual sum of squares).

### Requirements
1. Write a function `custom_r2(y_true, y_pred)` that:
   - Computes the mean of `y_true`: $\bar{y}$.
   - Computes $SS_{tot} = \sum (y_i - \bar{y})^2$.
   - Computes $SS_{res} = \sum (y_i - \hat{y}_i)^2$.
   - Returns $1.0 - (SS_{res} / SS_{tot})$.
2. Execute `custom_r2(y_test.values, y_pred)` on the test predictions.
3. Compare the result with `r2_score(y_test, y_pred)`.
4. Assert that `abs(custom_val - sklearn_val) < 1e-6`.

### Acceptance Criteria
- [ ] `custom_r2` function contains no calls to scikit-learn metrics.
- [ ] Correct mathematical formulation of $SS_{tot}$ and $SS_{res}$ is implemented.
- [ ] Assertion confirms equality with scikit-learn to at least 6 decimal places.
- [ ] Output prints both values and confirms verification success.

---

## Exercise 3: Enhanced Actual vs. Predicted Plot with Error Bands

### Objective
Create an enhanced version of `actual_vs_predicted.png` that includes $\pm \$1.00$ error tolerance bands along the 45-degree diagonal.

### Background
Visualizing an acceptable pricing tolerance corridor (e.g. within $1.00 of actual price) allows business stakeholders to immediately see what percentage of test pizzas fall within commercial tolerance.

### Requirements
1. Create an 8x6 inch figure with `plt.subplots()`.
2. Scatter plot `y_test` vs `y_pred` using orange markers with black edges.
3. Plot the dashed gray 45-degree line of perfect prediction.
4. Plot two semi-transparent dotted lines or a shaded polygon representing $\pm \$1.00$ tolerance:
   - Upper line: $y = x + 1.00$
   - Lower line: $y = x - 1.00$
   - Alternatively, use `ax.fill_between(lims, lims - 1, lims + 1, alpha=0.15, color="gray", label="+/- $1.00 Tolerance")`
5. Save the output to `enhanced_actual_vs_predicted.png` at 150 DPI.

### Acceptance Criteria
- [ ] Plot contains scatter points, diagonal reference line, and shaded or bounded tolerance corridor.
- [ ] Axis labels and title clearly describe the plot contents.
- [ ] Legend identifies the test points, perfect prediction line, and tolerance corridor.
- [ ] Output image `enhanced_actual_vs_predicted.png` is generated and saved cleanly.

---

## Exercise 4: Residual Distribution Analysis and Outlier Detection

### Objective
Write an automated script that calculates test residuals, computes summary statistics, and outputs a formatted table of all items whose pricing error exceeds $1.00.

### Background
Automated quality gates prevent deploying models that exhibit severe isolated prediction failures even when overall MAE looks acceptable.

### Requirements
1. Calculate residuals: `residuals = y_test - y_pred`.
2. Calculate absolute errors: `abs_errors = np.abs(residuals)`.
3. Identify all test cases where `abs_errors > 1.00`.
4. Construct a pandas DataFrame containing:
   - `diameter_inches`
   - `toppings`
   - `actual_price`
   - `predicted_price`
   - `error_dollars`
5. Display the flagged outliers. If no items exceed $1.00, print "No pricing outliers exceeding $1.00 detected."

### Acceptance Criteria
- [ ] Residuals and absolute errors are computed accurately.
- [ ] Filtering condition correctly identifies orders exceeding the $1.00 threshold.
- [ ] Formatted diagnostic table displays feature values, actual price, predicted price, and error.
- [ ] Script terminates cleanly with informative terminal output.
