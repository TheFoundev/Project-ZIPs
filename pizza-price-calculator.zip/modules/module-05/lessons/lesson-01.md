# Lesson 01: Measuring Pricing Accuracy with Mean Absolute Error (MAE)

**Lesson ID:** lesson-01
**Module:** module-05
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain the mathematical definition and intuitive meaning of Mean Absolute Error (MAE)
- Calculate MAE in native currency units (USD) to evaluate pricing predictions
- Differentiate between Mean Absolute Error (MAE) and Mean Squared Error (MSE) / Root Mean Squared Error (RMSE)
- Understand why signed errors cancel out and why absolute differences are mandatory
- Apply scikit-learn's `mean_absolute_error` function to test partition predictions

## Prerequisites
- Completion of Module 03 and Module 04
- Familiarity with calculating vector differences in NumPy and pandas
- Basic understanding of test set evaluation principles

## Concept Explanation

### The Business Question: How Close Are Our Quotes?
When deploying an automated pricing algorithm in a pizzeria, stakeholders—restaurant owners, kitchen managers, and customers—do not evaluate models using abstract cost functions. They ask a simple, concrete question: *"On average, how many dollars or cents is our price quote off from the actual menu price?"*

If our algorithm predicts a 14-inch, 3-topping pizza at $22.50, but the historical hand-calculated menu price is $23.00, our error on that order is $0.50. If another pizza is quoted at $18.25 when the menu says $17.50, our error on that order is $0.75. 

To evaluate overall model quality across an entire menu or test dataset, we must aggregate these individual prediction errors into a single representative metric.

### Why Not Just Compute the Average Error?
A common beginner mistake is computing the simple mean of the errors:
$$\text{Signed Error} = \frac{1}{n} \sum_{i=1}^n (y_i - \hat{y}_i)$$

Consider two predictions:
- Order A: Actual = $20.00, Predicted = $25.00 $\rightarrow$ Error = $20 - 25 = -$5.00 (overpredicted by $5.00)
- Order B: Actual = $20.00, Predicted = $15.00 $\rightarrow$ Error = $20 - 15 = +$5.00 (underpredicted by $5.00)

If we calculate the simple average of these signed errors:
$$\frac{(-5.00) + (+5.00)}{2} = \frac{0.00}{2} = \$0.00$$

A naive evaluation would conclude that our model has zero error and is perfectly accurate! In reality, every single quote was incorrect by a massive $5.00. Positive errors (underpredictions) and negative errors (overpredictions) canceled each other out.

### The Mean Absolute Error (MAE) Formulation
To prevent positive and negative errors from canceling each other out, we take the **absolute value** of each individual error before averaging. This is Mean Absolute Error (MAE):

$$\text{MAE} = \frac{1}{n} \sum_{i=1}^n |y_i - \hat{y}_i|$$

Where:
- $n$ is the total number of evaluated samples (e.g., $n = 12$ in our test set).
- $y_i$ is the actual ground-truth price for sample $i$.
- $\hat{y}_i$ is the model's predicted price for sample $i$.
- $|y_i - \hat{y}_i|$ is the absolute magnitude of the pricing error, ignoring direction.

Using MAE on Orders A and B:
$$\text{MAE} = \frac{|-5.00| + |+5.00|}{2} = \frac{5.00 + 5.00}{2} = \$5.00$$

The metric accurately reflects that on average, our predictions deviate by $5.00 from actual prices.

### MAE vs. MSE and RMSE: Penalty Characteristics
Scikit-learn offers several regression metrics. Understanding their differences is crucial:

1. **Mean Absolute Error (MAE):**
   - Formula: $\frac{1}{n} \sum |y - \hat{y}|$
   - Units: Exact target units (USD dollars).
   - Penalty: Linear. An error of $4.00 is penalized exactly twice as much as an error of $2.00.
   - Outlier sensitivity: Robust. Single extreme outliers do not disproportionately distort the summary metric.

2. **Mean Squared Error (MSE):**
   - Formula: $\frac{1}{n} \sum (y - \hat{y})^2$
   - Units: Squared target units ($	ext{USD}^2$).
   - Penalty: Quadratic. An error of $4.00 is penalized sixteen times as much as an error of $1.00 ($16.00 vs $1.00).
   - Interpretability: Poor for business stakeholders because squared dollars have no physical meaning.

3. **Root Mean Squared Error (RMSE):**
   - Formula: $\sqrt{\text{MSE}}$
   - Units: Target units (USD dollars).
   - Penalty: Emphasizes larger errors due to squaring before taking the square root. Highly sensitive to occasional large outliers.

For everyday retail menu pricing, **MAE** is preferred as the primary metric because it translates directly into executive decision-making: *"Our quotes are accurate within 58 cents on average."*

## Relevant Code (from main.py, lines 70-74)
```python
# Evaluate
mae = mean_absolute_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
print(f"Mean Absolute Error: ${mae:.2f}")
print(f"R-squared:           {r2:.2f}")
```

## Code Architecture and Walkthrough
The evaluation logic follows standard supervised learning conventions:
1. `y_test`: A 1D pandas Series of ground-truth prices for the 12 pizzas in the test partition.
2. `y_pred`: A 1D NumPy array generated by `model.predict(X_test)` containing the model's 12 price estimates.
3. `mean_absolute_error(y_test, y_pred)`: Iterates element-wise over both collections, computes $|y_i - \hat{y}_i|$ for each pair, sums them up, and divides by 12.
4. `f"${mae:.2f}"`: Formats the floating-point result to 2 decimal places with a dollar sign prefix, yielding `$0.58`.

## Worked Example
Let us compute MAE by hand on 4 representative pizzas from our test set:

| Pizza | Diameter | Toppings | Actual Price ($y$) | Predicted Price ($\hat{y}$) | Error ($y - \hat{y}$) | Absolute Error ($|y - \hat{y}|$) |
|---|---|---|---|---|---|---|
| Pizza 1 | 8 | 1 | $13.50 | $13.56 | -$0.06 | $0.06 |
| Pizza 2 | 12 | 3 | $21.50 | $21.05 | +$0.45 | $0.45 |
| Pizza 3 | 16 | 5 | $27.99 | $28.53 | -$0.54 | $0.54 |
| Pizza 4 | 18 | 5 | $31.75 | $30.46 | +$1.29 | $1.29 |

Sum of absolute errors:
$$0.06 + 0.45 + 0.54 + 1.29 = 2.34$$

Sample MAE:
$$\text{MAE} = \frac{2.34}{4} = \$0.585 \approx \$0.59$$

Across all 12 test samples, the exact sum of absolute errors is 6.949, giving:
$$\text{MAE} = \frac{6.949}{12} = 0.5791 \approx \$0.58$$

## Step-by-Step Implementation Guide

### Step 1: Import the Metric from Scikit-Learn
```python
from sklearn.metrics import mean_absolute_error
```

### Step 2: Generate Test Predictions
Ensure you evaluate against unseen test data, never the training data:
```python
y_pred = model.predict(X_test)
```

### Step 3: Compute MAE
Pass ground truth first, followed by model predictions:
```python
mae = mean_absolute_error(y_test, y_pred)
```

### Step 4: Display with Clean Formatting
```python
print(f"Mean Absolute Error: ${mae:.2f}")
```

## Expected Output and Verification
When executed on the project's dataset:
```text
Mean Absolute Error: $0.58
```
Verification checks:
- Value is strictly positive ($> 0$).
- Value is less than $1.00, demonstrating sub-dollar accuracy on pizzas ranging from $9 to $32.

## Practical Exercises
1. Calculate the MAE manually using pure NumPy: `np.mean(np.abs(y_test.values - y_pred))`. Verify it matches `mean_absolute_error(y_test, y_pred)` to 6 decimal places.
2. Calculate the training MAE using `mean_absolute_error(y_train, model.predict(X_train))`. Is the training MAE smaller or larger than the test MAE? Why?
3. Calculate the Percentage MAE (Mean Absolute Percentage Error or MAPE): `np.mean(np.abs((y_test.values - y_pred) / y_test.values)) * 100`. Interpret what this percentage means for customer satisfaction.

## Common Pitfalls and Debugging Strategies
- **Evaluating on Training Data:** Reporting `mean_absolute_error(y_train, model.predict(X_train))` gives an over-optimistic estimate. Always evaluate on `y_test`.
- **Reversed Arguments:** Although `mean_absolute_error(y_true, y_pred)` is symmetric because $|a - b| = |b - a|$, custom metrics or directed metrics (like residuals) depend on order. Always maintain standard `(y_true, y_pred)` convention.
- **Forgetting Currency Scale:** An MAE of 0.58 on pizzas ($10-$30) is outstanding. An MAE of 0.58 on luxury vehicles ($50,000) would be nearly zero, while an MAE of 0.58 on penny candy ($0.10) would be disastrous. Always interpret MAE relative to target scale.

## Best Practices and Industry Standards
- **Always Report Metric Units:** Never state "the model error is 0.58". State "the model error is $0.58 per pizza".
- **Benchmark Against a Naive Baseline:** Compare your model's MAE against a dummy regressor that always predicts the mean price of the menu. If the dummy model has an MAE of $5.40, your $0.58 MAE proves an 89% reduction in error.
- **Inspect Max Absolute Error:** In addition to the mean, check `np.max(np.abs(y_test - y_pred))` to find the worst-case quote across the entire test set.

## Real-World Business Context
In restaurant economics, an average pricing discrepancy of $0.58 represents an acceptable margin of error. Most pizza menus price items in whole dollars or ending in .99. A 58-cent variance falls well within the normal pricing flexibility needed to absorb minor ingredient price fluctuations.

## Summary and Key Takeaways
- Mean Absolute Error averages the absolute magnitudes of individual prediction errors.
- Absolute values prevent positive and negative pricing errors from canceling out.
- MAE is directly interpretable in target currency units ($USD) and treats all error magnitudes linearly.
- In our pizza calculator, the test MAE is $0.58, indicating high real-world quoting reliability.

## Knowledge Check and Self-Assessment
1. What would happen to the evaluation metric if we forgot to take absolute values when computing average error across many balanced positive and negative errors?
2. If Pizza A has an error of +$2.00 and Pizza B has an error of -$2.00, what is the MAE?
3. Why is MAE preferred over MSE when explaining model performance to non-technical restaurant managers?

## References and Further Reading
- Scikit-Learn Documentation: `sklearn.metrics.mean_absolute_error`
- Willmott & Matsuura (2005): "Advantages of the Mean Absolute Error (MAE) over the Root Mean Squared Error (RMSE) in Assessing Average Model Performance"
- Hands-On Machine Learning with Scikit-Learn, Keras, and TensorFlow (Aurélien Géron), Chapter 2
