# Lesson 03: Visualizing Predictions with Actual vs. Predicted Plots

**Lesson ID:** lesson-03
**Module:** module-05
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Construct an Actual vs. Predicted scatter plot using matplotlib
- Draw an ideal 45-degree reference line ($y = x$) representing perfect predictions
- Interpret scatter point positioning relative to the perfect prediction diagonal
- Configure chart styling, labels, legends, and export resolution
- Save production-quality diagnostic charts as standalone image files (`actual_vs_predicted.png`)

## Prerequisites
- Completion of Lesson 01 and Lesson 02
- Basic familiarity with matplotlib's object-oriented interface (`fig, ax = plt.subplots()`)
- Understanding of test set predictions (`y_test`, `y_pred`)

## Concept Explanation

### Why Summary Metrics Are Not Enough
In the previous two lessons, we computed two numerical summary statistics:
- Mean Absolute Error (MAE): $0.58
- Coefficient of Determination ($R^2$): 0.98

While these numbers provide a high-level summary of model performance, summary statistics can hide critical failure modes:
- Does the model perform equally well on small 8-inch pizzas and giant 18-inch party pizzas?
- Are the pricing errors randomly scattered, or does the model systematically overprice small pizzas and underprice large ones?
- Is there a single severe outlier that was masked by the average?

To answer these diagnostic questions, machine learning practitioners rely on the **Actual vs. Predicted Scatter Plot**.

### The Anatomy of an Actual vs. Predicted Plot
In an Actual vs. Predicted plot:
1. The **horizontal axis (X-axis)** represents the **Actual Price ($)** from the ground-truth test set (`y_test`).
2. The **vertical axis (Y-axis)** represents the **Predicted Price ($)** produced by our linear model (`y_pred`).
3. Each individual pizza in the test dataset appears as a distinct scatter point $(y_{test, i}, y_{pred, i})$.

### The Ideal 45-Degree Diagonal ($y = x$)
If our machine learning model were 100% perfect, every single prediction would exactly equal its actual price:
$$\hat{y}_i = y_i$$

On our scatter plot, all points where $\hat{y} = y$ lie precisely along a straight diagonal line passing through the origin with a slope of 1 (a 45-degree angle). This line is called the **line of perfect prediction**.

By overlaying this reference line on our scatter plot, we can instantly evaluate model behavior:
- **Points directly on the diagonal:** Perfect prediction (zero error).
- **Points above the diagonal:** The model predicted a higher price than the actual menu price (overprediction: $\hat{y} > y$).
- **Points below the diagonal:** The model predicted a lower price than the actual menu price (underprediction: $\hat{y} < y$).
- **Tight clustering along the line:** High model precision and strong linear fit.

## Relevant Code (from main.py, lines 78-90)
```python
# Plot
fig, ax = plt.subplots(figsize=(8, 6))
ax.scatter(y_test, y_pred, color="#e67e22", edgecolors="black", s=70, label="Pizzas (test)")
lims = [0, max(max(y_test), max(y_pred)) + 5]
ax.plot(lims, lims, "--", color="gray", label="Perfect prediction")
ax.set_xlabel("Actual Price ($)")
ax.set_ylabel("Predicted Price ($)")
ax.set_title("Pizza Price: Actual vs Predicted")
ax.legend()
plt.tight_layout()
plt.savefig("actual_vs_predicted.png", dpi=150)
plt.close()
```

## Code Architecture and Walkthrough

Let us examine each component of the plotting pipeline:

### 1. Figure and Axes Creation
```python
fig, ax = plt.subplots(figsize=(8, 6))
```
We use matplotlib's object-oriented interface. An 8x6 inch figure provides ample canvas space for clear axis ticks and readable typography.

### 2. Plotting the Test Points
```python
ax.scatter(y_test, y_pred, color="#e67e22", edgecolors="black", s=70, label="Pizzas (test)")
```
- `y_test`: Array of actual menu prices.
- `y_pred`: Array of model predictions.
- `color="#e67e22"`: A pizza-themed warm terracotta/crust orange.
- `edgecolors="black"`: Sharp contrast border around each marker, making overlapping points easily distinguishable.
- `s=70`: Point area in square points, offering high visibility.
- `label="Pizzas (test)"`: Human-readable description for the legend.

### 3. Dynamic Axis Range and Reference Diagonal
```python
lims = [0, max(max(y_test), max(y_pred)) + 5]
ax.plot(lims, lims, "--", color="gray", label="Perfect prediction")
```
To ensure the diagonal line spans the full range of the data:
- `max(max(y_test), max(y_pred))` finds the highest price across both actual and predicted values (approx $32).
- Adding `+ 5` leaves comfortable margin space (0 to ~$37).
- `ax.plot(lims, lims, "--", color="gray")` draws a dashed line from `(0, 0)` to `(37, 37)`. Because both X and Y coordinates are identical, this creates an exact 45-degree slope.

### 4. Labels, Legend, and Layout
```python
ax.set_xlabel("Actual Price ($)")
ax.set_ylabel("Predicted Price ($)")
ax.set_title("Pizza Price: Actual vs Predicted")
ax.legend()
plt.tight_layout()
```
Clear descriptive labels with units ($) prevent ambiguity. `plt.tight_layout()` adjusts subplot parameters so that all labels fit within the figure boundaries without clipping.

### 5. File Export and Resource Cleanup
```python
plt.savefig("actual_vs_predicted.png", dpi=150)
plt.close()
```
- `savefig`: Writes the rendered chart directly to disk at 150 DPI (dots per inch), suitable for documentation and client presentations.
- `plt.close()`: Destroys the figure from memory, preventing memory leaks in production or batch scripts.

## Worked Example
Suppose our test set has 3 pizzas:
1. Small Cheese: Actual $10.00, Predicted $10.20 $\rightarrow$ Point at $(10.00, 10.20)$. Lying slightly above the diagonal.
2. Medium Veggie: Actual $18.50, Predicted $18.40 $\rightarrow$ Point at $(18.50, 18.40)$. Lying slightly below the diagonal.
3. Large Meat Lovers: Actual $28.00, Predicted $28.10 $\rightarrow$ Point at $(28.00, 28.10)$. Lying almost exactly on the diagonal.

When plotted, all three points form an ultra-tight cluster along the dashed gray line. No points stray far from the line, confirming that error is uniform across small, medium, and large pizzas.

## Step-by-Step Implementation Guide

### Step 1: Prepare Imports
```python
import matplotlib.pyplot as plt
```

### Step 2: Initialize Figure
```python
fig, ax = plt.subplots(figsize=(8, 6))
```

### Step 3: Draw Scatter Points and Diagonal Reference
```python
ax.scatter(y_test, y_pred, color="#e67e22", edgecolors="black", s=70, label="Pizzas (test)")
lims = [0, max(max(y_test), max(y_pred)) + 5]
ax.plot(lims, lims, "--", color="gray", label="Perfect prediction")
```

### Step 4: Configure Labels and Styling
```python
ax.set_xlabel("Actual Price ($)")
ax.set_ylabel("Predicted Price ($)")
ax.set_title("Pizza Price: Actual vs Predicted")
ax.legend()
plt.tight_layout()
```

### Step 5: Save and Close
```python
plt.savefig("actual_vs_predicted.png", dpi=150)
plt.close()
```

## Expected Output and Verification
A file named `actual_vs_predicted.png` is generated in the working directory:
- Resolution: 1200 x 900 pixels (8 inches x 150 dpi by 6 inches x 150 dpi).
- Contents: A clear Cartesian plane spanning ~$0 to $37 on both axes, a dashed diagonal line, and 12 orange circular dots tightly clustered along the diagonal.

## Practical Exercises
1. Modify the plot code to display training data points as light gray open circles alongside the test points. What visual insight does this provide about train/test consistency?
2. Add vertical error bars or vertical connecting lines from each test point $(y_{actual}, y_{pred})$ to the diagonal line $(y_{actual}, y_{actual})$. What geometric property do these vertical line lengths represent?
3. Calculate the Pearson correlation coefficient between `y_test` and `y_pred` using `np.corrcoef(y_test, y_pred)[0, 1]` and display the correlation in the plot title.

## Common Pitfalls and Debugging Strategies
- **Unequal Axis Limits:** If the X-axis spans 0 to 40 but the Y-axis spans 10 to 30, the diagonal reference line will not appear at a 45-degree angle, visually distorting the perceived error. Always ensure both axes share identical limits when plotting $y = x$.
- **Leaking Training Data:** Plotting predictions on the training set instead of the held-out test set will make your model look deceptively perfect. Always label and plot test data.
- **Forgetting `plt.close()`:** In automated pipelines generating hundreds of plots, failing to call `plt.close()` retains figures in matplotlib's internal registry, leading to severe memory consumption.

## Best Practices and Industry Standards
- **Use Distinct Visual Styling:** Avoid default tiny blue dots. Use contrasting colors, explicit borders (`edgecolors="black"`), and appropriate sizing (`s=70`) for readability.
- **Export at 150-300 DPI:** Default 72 DPI images appear blurry on modern high-DPI displays and PDF reports. 150 DPI provides sharp, crisp figures with modest file sizes (~50-100 KB).
- **Include Units on Both Axes:** Always write `"Actual Price ($)"` rather than simply `"Actual"`.

## Real-World Business Context
Diagnostic plots bridge the communication gap between technical data scientists and operational stakeholders. A restaurant owner may not understand variance matrices or partial derivative loss functions, but they can instantly look at an Actual vs. Predicted plot and verify: *"Every single dot is hugging the dashed line—our quoting engine is reliable."*

## Summary and Key Takeaways
- Actual vs. Predicted scatter plots visually expose patterns that scalar metrics like MAE and $R^2$ may obscure.
- The 45-degree dashed line represents perfect prediction ($y = x$).
- Points above the line represent model overpredictions; points below represent underpredictions.
- Matplotlib's object-oriented API provides full control over aesthetic styling and high-resolution export.

## Knowledge Check and Self-Assessment
1. What does it signify if a scatter point in the Actual vs. Predicted plot sits significantly below the 45-degree dashed line?
2. Why is it important to set identical minimum and maximum values for both the X-axis and Y-axis limits?
3. Why should `plt.close()` be called immediately after `plt.savefig()` in automated scripts?

## References and Further Reading
- Matplotlib Documentation: `matplotlib.axes.Axes.scatter` and `matplotlib.pyplot.savefig`
- Wickham, H. (2010): "A Layered Grammar of Graphics", Journal of Computational and Graphical Statistics
- Tufte, E. R. (2001): "The Visual Display of Quantitative Information", Graphics Press
