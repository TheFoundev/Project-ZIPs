# Lesson 02: Quantifying Explained Variance with R-Squared (R²)

**Lesson ID:** lesson-02
**Module:** module-05
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define the Coefficient of Determination ($R^2$) mathematically and conceptually
- Calculate $R^2$ using scikit-learn's `r2_score` function on test data
- Interpret an $R^2$ score of 0.98 in the context of pizza pricing variance
- Differentiate between Total Sum of Squares ($SS_{tot}$) and Residual Sum of Squares ($SS_{res}$)
- Identify scenarios where $R^2$ can be misleading or negative

## Prerequisites
- Completion of Lesson 01
- Understanding of variance and mean baseline predictions
- Familiarity with linear regression concepts

## Concept Explanation

### The Need for a Normalized Performance Metric
In Lesson 01, we evaluated our model using Mean Absolute Error (MAE = $0.58). While MAE is intuitive because it is denominated in dollars, it has one major limitation: **it is scale-dependent**.

If you tell a machine learning executive that your model has an MAE of 0.58, they cannot tell whether that is good or bad without knowing the scale. If the dataset consists of items priced around $0.60, an error of $0.58 is unacceptable. If the dataset consists of items priced around $100.00, an error of $0.58 is phenomenal.

To compare model quality independently of the target variable's currency scale, statisticians developed the **Coefficient of Determination**, denoted as **$R^2$** (pronounced "R-squared").

### The Intuition: Beating the Naive Mean Benchmark
Imagine a naive pricing strategy that knows nothing about pizza size or toppings. Whenever a customer asks for a price, this naive strategy simply quotes the **average price of all pizzas in the dataset** (denoted as $\bar{y}$).

How much error does this naive mean strategy produce?
The total variability of actual prices around their mean is measured by the **Total Sum of Squares ($SS_{tot}$)**:
$$SS_{tot} = \sum_{i=1}^n (y_i - \bar{y})^2$$

Now, consider our linear regression model. It does not predict the mean; it uses diameter and topping count to predict a customized price $\hat{y}_i$. The remaining error that our model fails to explain is the **Residual Sum of Squares ($SS_{res}$)**:
$$SS_{res} = \sum_{i=1}^n (y_i - \hat{y}_i)^2$$

### The Mathematical Definition of $R^2$
$R^2$ compares the error of our regression model ($SS_{res}$) against the error of the naive mean benchmark ($SS_{tot}$):

$$R^2 = 1 - \frac{SS_{res}}{SS_{tot}}$$

Let us analyze the three canonical benchmark values:
1. **$R^2 = 1.0$ (Perfect Model):**
   - $SS_{res} = 0$ (the model predicts every single pizza price with zero error).
   - $R^2 = 1 - \frac{0}{SS_{tot}} = 1.0$. The model explains 100% of the price variability.
2. **$R^2 = 0.0$ (Baseline Model):**
   - $SS_{res} = SS_{tot}$ (the model performs no better than simply predicting the dataset mean for every order).
   - $R^2 = 1 - \frac{SS_{tot}}{SS_{tot}} = 1 - 1 = 0.0$. The model explains 0% of price variability.
3. **$R^2 < 0.0$ (Negative $R^2$ - Worse Than Mean):**
   - If a model is tested on unseen data and performs worse than the simple sample mean, $SS_{res} > SS_{tot}$, resulting in a negative score. This occurs when a model is severely misfitted or applied to fundamentally shifted distributions.

### Interpreting $R^2 = 0.98$ for Our Pizza Model
In our project, running `r2_score(y_test, y_pred)` yields **0.98** (specifically 0.9762).

What does 0.98 mean in plain English?
> **Interpretation:** Exactly **98% of the variation** in pizza prices across our menu is explained by the combination of diameter in inches and number of toppings. Only **2% of the variation** is attributable to unexplained factors (such as specialty dough, premium sauce, or pricing noise).

This exceptionally high score confirms that pizza pricing in this establishment follows a strongly linear, rule-based economic structure.

## Relevant Code (from main.py, lines 71-74)
```python
r2 = r2_score(y_test, y_pred)
print(f"R-squared:           {r2:.2f}")
```

## Code Architecture and Walkthrough
The calculation is performed in one clean call:
1. `r2_score(y_test, y_pred)` is imported from `sklearn.metrics`.
2. It takes `y_test` (ground truth prices) and `y_pred` (model estimates).
3. Internally, scikit-learn computes $\bar{y}_{test} = \text{mean}(y\_test)$, calculates $SS_{tot} = \sum (y\_test - \bar{y}_{test})^2$, computes $SS_{res} = \sum (y\_test - y\_pred)^2$, and evaluates $1 - (SS_{res} / SS_{tot})$.
4. The result is printed with 2 decimal precision: `0.98`.

## Worked Example
Let us compute $R^2$ step-by-step on a small 3-sample subset:
- Actual prices: $y = [15.00, 20.00, 25.00]$
- Mean price: $\bar{y} = (15 + 20 + 25) / 3 = 20.00$
- $SS_{tot} = (15 - 20)^2 + (20 - 20)^2 + (25 - 20)^2 = (-5)^2 + 0^2 + 5^2 = 25 + 0 + 25 = 50.0$

Suppose our model predicts:
- $\hat{y} = [15.50, 19.80, 24.50]$
- Residuals: $y - \hat{y} = [-0.50, +0.20, +0.50]$
- Squared residuals: $(-0.5)^2 + (0.2)^2 + (0.5)^2 = 0.25 + 0.04 + 0.25 = 0.54$
- $SS_{res} = 0.54$

Now compute $R^2$:
$$R^2 = 1 - \frac{SS_{res}}{SS_{tot}} = 1 - \frac{0.54}{50.0} = 1 - 0.0108 = 0.9892$$

The model captures 98.9% of the variation in price.

## Step-by-Step Implementation Guide

### Step 1: Import r2_score
```python
from sklearn.metrics import r2_score
```

### Step 2: Calculate Score on Test Partition
```python
r2 = r2_score(y_test, y_pred)
```

### Step 3: Format and Display
```python
print(f"R-squared: {r2:.4f} (or {r2 * 100:.1f}% explained variance)")
```

## Expected Output and Verification
```text
R-squared:           0.98
```
Verification checks:
- $R^2$ must be between 0.0 and 1.0 for a standard well-trained regression model.
- Test score of 0.98 indicates excellent predictive capability without severe overfitting (since training $R^2$ is also ~0.98).

## Practical Exercises
1. Calculate the training $R^2$ using `r2_score(y_train, model.predict(X_train))`. Compare it with test $R^2$. If they are within 0.02 of each other, what does that tell you about model overfitting?
2. Implement a pure Python function `calculate_r2(y_true, y_pred)` using basic list comprehensions or NumPy arrays. Verify its output against scikit-learn's `r2_score`.
3. Create a hypothetical bad prediction array where every prediction equals $0.00. Compute $R^2$ against `y_test`. Observe how dramatically negative the resulting score is.

## Common Pitfalls and Debugging Strategies
- **Confusing $R^2$ with Pearson Correlation Coefficient ($r$):** In simple univariate linear regression, $R^2 = r^2$. However, in multiple regression with two or more features, $R^2$ is the multivariate coefficient of determination and cannot be computed from a single pairwise correlation.
- **Assuming $R^2$ Proves Causality:** An $R^2$ of 0.98 proves that diameter and toppings predict price with high statistical fidelity. It does not technically prove that size causes price (though our domain knowledge of restaurant ingredient costs confirms this relationship).
- **Ignoring Sample Size:** On very small datasets ($n < 5$), high $R^2$ values can occur purely by chance. Our test set has 12 items and the full dataset has 45 items, providing adequate statistical support for a 2-feature model.

## Best Practices and Industry Standards
- **Always Pair $R^2$ with MAE or RMSE:** Never report $R^2$ in isolation. An executive needs both the relative metric ($R^2 = 0.98$) to gauge model maturity and the absolute metric (MAE = $0.58) to assess commercial risk.
- **Check Adjusted $R^2$ when Adding Many Features:** As you add more predictor features, raw $R^2$ can never decrease, even if the features are meaningless random noise. Adjusted $R^2$ penalizes excessive features:
  $$R_{adj}^2 = 1 - \left[ \frac{(1 - R^2)(n - 1)}{n - k - 1} \right]$$
  where $k$ is the number of features. For our 2-feature model with $n=33$ training samples, raw $R^2$ and adjusted $R^2$ are virtually identical.

## Real-World Business Context
When presenting ML pricing models to restaurant franchisors or board members, $R^2$ serves as the primary "confidence score." A score of 0.98 demonstrates that the automated engine will not introduce erratic pricing behavior across franchised locations, satisfying audit and compliance requirements.

## Summary and Key Takeaways
- $R^2$ quantifies the proportion of target variance explained by model features.
- It normalizes performance between 0.0 (baseline mean) and 1.0 (perfect prediction).
- Our pizza price model achieves $R^2 = 0.98$, proving that diameter and topping count explain 98% of menu price variance.
- Reporting $R^2$ alongside MAE provides both relative variance capture and absolute monetary accuracy.

## Knowledge Check and Self-Assessment
1. What does an $R^2$ value of 0.0 mean about a model's predictive ability?
2. Under what condition can $R^2$ become negative on an unseen test dataset?
3. If a regression model achieves an $R^2$ of 0.98 on the training set but an $R^2$ of 0.35 on the test set, what problem has occurred?

## References and Further Reading
- Scikit-Learn Documentation: `sklearn.metrics.r2_score`
- Draper, N. R., & Smith, H. (1998): "Applied Regression Analysis", John Wiley & Sons
- Alexander, D. L. J., Tropsha, A., & Winkler, D. A. (2015): "Beware of R2: Simple, Unambiguous Assessment of Model Quality"
