# Module 1 Exercises: Problem Framing, Feature Identification & Dataset Exploration

## Exercise 1.1: Business Problem Framing & Paradigm Classification (15 min)
**Objective:** Formulate the pizza pricing challenge as a supervised multiple linear regression problem and contrast it with classification.
**Problem Statement:** You are the lead machine learning engineer hired by a national pizza franchise. The management team currently sets prices manually based on employee intuition, leading to erratic profit margins on customized orders. You must document why machine learning is suitable for this problem and classify the exact learning task.

**Requirements:**
1. Define why pizza pricing is a regression task rather than a classification task.
2. Define supervised learning in the context of `pizza_menu.csv`.
3. Explain why a single-feature model (using only diameter) would fail on commercial menus.
4. List the target variable and all independent predictor variables in the project.

**Constraints:** Base your answers on the actual codebase in `08_pizza_price/main.py` and the dataset `data/pizza_menu.csv`.

**Expected Behaviour:** Produce a written report (4-6 paragraphs) thoroughly answering all four requirements with concrete examples from the pizza menu.

**Acceptance Criteria:**
- [ ] Correctly identifies the task as supervised regression because `price_usd` is a continuous numeric quantity.
- [ ] Clearly distinguishes regression from classification (predicting continuous dollar values vs categorical classes).
- [ ] Explains supervised learning as learning from 45 historical pairs of `(diameter_inches, toppings)` and `price_usd`.
- [ ] Demonstrates why diameter alone is insufficient by referencing pizzas with high toppings vs zero toppings.
- [ ] Identifies target as `price_usd` and features as `diameter_inches` and `toppings`.

**Hints:**
- Look at Sample 3 (15.6 in, 0 toppings, $18.66) vs Sample 2 (13.3 in, 5 toppings, $25.35) in `data/pizza_menu.csv`.
- What would happen to the price of a small pizza with 5 meat toppings if toppings were ignored?

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 1.2: Exploring and Validating pizza_menu.csv (15 min)
**Objective:** Load `data/pizza_menu.csv` using pandas, inspect its dimensional properties, and verify data hygiene.
**Problem Statement:** Before fitting statistical estimators, you must write an exploratory script to load `data/pizza_menu.csv` and verify that the dataset contains no corrupt values, unexpected datatypes, or missing rows.

**Requirements:**
1. Write a Python script using pandas to load `data/pizza_menu.csv`.
2. Print the shape of the DataFrame and verify there are exactly 45 rows and 3 columns.
3. Check for any missing/null values across all columns.
4. Compute and display the minimum, maximum, and mean values for `diameter_inches`, `toppings`, and `price_usd`.

**Constraints:** Use `pathlib.Path` to locate the CSV file relative to the script directory.

**Expected Behaviour:** A Python script that executes cleanly and prints a structured statistical audit of the dataset.

**Acceptance Criteria:**
- [ ] Uses `pathlib.Path` to construct the dataset path.
- [ ] Correctly prints shape `(45, 3)`.
- [ ] Verifies 0 null values across all three columns.
- [ ] Correctly calculates diameter range (8.4 to 17.6 in), toppings range (0 to 5), and price range ($12.59 to $30.43).

**Hints:**
- Use `df.isnull().sum()` to verify absence of missing values.
- Use `df.describe()` to quickly generate summary statistics.

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 1.3: Feature Matrix Formatting and Shape Verification (15 min)
**Objective:** Extract the feature matrix $X$ and target vector $y$ in compliance with scikit-learn's dimensionality requirements.
**Problem Statement:** Scikit-learn estimators require feature matrices to have a two-dimensional shape `(n_samples, n_features)` and target vectors to have a one-dimensional shape `(n_samples,)`. You must implement and verify this extraction from `pizza_menu.csv`.

**Requirements:**
1. Extract `diameter_inches` and `toppings` into variable `X` using pandas double-bracket notation.
2. Extract `price_usd` into variable `y` using single-bracket notation.
3. Print `type(X)`, `X.shape`, `type(y)`, and `y.shape`.
4. Demonstrate what error or warning occurs if `X` is extracted with single brackets `df['diameter_inches']`.

**Constraints:** Write valid Python code matching the design of `main.py`.

**Expected Behaviour:** Console output showing `X.shape == (45, 2)` and `y.shape == (45,)`.

**Acceptance Criteria:**
- [ ] `X` is verified as a `pd.DataFrame` with shape `(45, 2)`.
- [ ] `y` is verified as a `pd.Series` with shape `(45,)`.
- [ ] Explanation clearly states why scikit-learn requires 2D inputs for feature matrices.
- [ ] Demonstrates that single brackets on multiple column names raises a `KeyError` or returns a 1D Series if only one column is selected.

**Hints:**
- In pandas, `df[['col1', 'col2']]` passes a Python list to `__getitem__`, returning a DataFrame.
- In scikit-learn, an estimator's `.fit(X, y)` inspects `X.shape` to configure its weight coefficients.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 1.4: Prototyping the Automated Quoting Service (15 min)
**Objective:** Trace and explain the Model-as-an-API architecture implemented by `quote_pizza()`.
**Problem Statement:** Management wants to understand how the trained model will interact with their online ordering website. You must trace the execution of `quote_pizza(12, 3)` and explain each step in the quotation pipeline.

**Requirements:**
1. Diagram or step through the four stages of the `quote_pizza()` function.
2. Explain why the function creates a single-row `pd.DataFrame` with column names `diameter_inches` and `toppings` rather than passing raw numbers `[12, 3]` to `model.predict()`.
3. Explain why the return statement uses `float(model.predict(order)[0])`.
4. Manually verify the quote for a 12-inch, 3-topping pizza using the learned equation $\text{price} = 4.02 + 0.97 \times \text{diameter} + 1.81 \times \text{toppings}$.

**Constraints:** Reference lines 45-53 of `08_pizza_price/main.py`.

**Expected Behaviour:** A detailed technical walkthrough explaining the function design, data conversion, and mathematical output ($21.05).

**Acceptance Criteria:**
- [ ] Accurately describes the input transformation into a pandas DataFrame.
- [ ] Explains that scikit-learn checks feature names against training columns to prevent feature order mismatches.
- [ ] Explains that `model.predict()` returns a 1D NumPy array and `[0]` extracts the first prediction.
- [ ] Accurately shows mathematical derivation yielding approximately $21.05.

**Hints:**
- Scikit-learn version 1.0+ issues a warning if a model trained on a DataFrame is evaluated on a raw NumPy array without feature names.
- Native Python floats are JSON-serializable, whereas NumPy float64 types can cause errors in certain web frameworks.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes
