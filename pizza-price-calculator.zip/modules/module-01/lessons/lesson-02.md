# Lesson 02: Introduction to Multiple Features in Machine Learning

**Lesson ID:** lesson-02
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Compare simple linear regression (one feature) with multiple linear regression (two or more features)
- Understand matrix representation and dimensional notation ($n \times p$) in tabular datasets
- Explain how scikit-learn expects feature matrices ($X$) to be structured in two dimensions
- Identify the feature columns in the pizza pricing dataset
- Recognize the mathematical advantages of multidimensional regression in capturing cost drivers

## Prerequisites
- Completion of Lesson 01
- Understanding of 2D tabular formats (rows and columns) in spreadsheets or pandas DataFrames

## Concept Explanation

### From Univariate to Multivariate Regression
In elementary machine learning, students often begin with **Simple Linear Regression**. In simple linear regression, a single feature $x$ predicts a target $y$:
$$y = w_1 x_1 + b$$
For example, estimating lemonade cups sold from outdoor temperature alone.

However, real-world systems are rarely determined by one isolated factor. When evaluating consumer goods, multiple independent forces act simultaneously. In the Pizza Price Calculator, if we used only `diameter_inches`, two pizzas with an identical diameter of 12 inches would receive identical price estimates, even if one pizza was plain cheese (0 toppings) and the other was loaded with 5 toppings.

To resolve this limitation, **Multiple Linear Regression** extends the model to $p$ distinct features:
$$\hat{y} = w_1 x_1 + w_2 x_2 + \dots + w_p x_p + b$$
For our pizza project, with $p = 2$ features:
$$\text{price} = w_{\text{size}} \times \text{diameter\_inches} + w_{\text{topping}} \times \text{toppings} + b$$

### Matrix Notation and Dimensionality
In machine learning terminology:
- $n$: The number of observations (or samples). In our pizza menu dataset, $n = 45$.
- $p$: The number of predictor features. In our project, $p = 2$ (`diameter_inches` and `toppings`).
- $X$: The **feature matrix**, which has dimensions $n \times p$ ($45 \times 2$).
- $y$: The **target vector**, which has dimension $n \times 1$ or a 1D vector of length $n$ ($45$).

Each row in $X$ represents an individual pizza offering on the menu, and each column represents a measured property.

| Observation Row | Feature 1: `diameter_inches` ($x_1$) | Feature 2: `toppings` ($x_2$) | Target: `price_usd` ($y$) |
|---|---|---|---|
| Sample 1 | 10.5 | 3 | $19.03 |
| Sample 2 | 13.3 | 5 | $25.35 |
| Sample 3 | 15.6 | 0 | $18.66 |
| Sample 4 | 14.3 | 3 | $23.63 |

Notice Sample 3: despite having a large diameter of 15.6 inches, it has 0 toppings, resulting in a price of $18.66—lower than the smaller 13.3-inch pizza in Sample 2 ($25.35) which carries 5 toppings! A univariate model would be hopelessly confused by this comparison, but a multiple regression model readily untangles the simultaneous contributions of size and toppings.

## Relevant Code (from main.py, lines 28-31)
```python
    df = pd.read_csv(DATA / "pizza_menu.csv")
    X = df[["diameter_inches", "toppings"]]
    y = df["price_usd"]
```

## Code Architecture and Walkthrough
Look closely at line 29:
```python
    X = df[["diameter_inches", "toppings"]]
```
- **Double Square Brackets `[[ ... ]]`:** In pandas, passing a list of string column names inside indexing brackets returns a two-dimensional `pd.DataFrame`.
- **Dimensionality Requirement:** Scikit-learn models require the feature matrix $X$ to possess a 2D shape of `(n_samples, n_features)`. Here, `X.shape` evaluates to `(45, 2)`.
- **Target Selection:** Line 30 uses single square brackets `df["price_usd"]`, which yields a 1D `pd.Series` of shape `(45,)`. Scikit-learn expects target $y$ as a one-dimensional array-like collection for standard single-output regression.

## Worked Example
Let us see how the two features operate together on three different test pizzas:
Suppose our fitted weights are $w_1 = 0.97$, $w_2 = 1.81$, and $b = 4.02$.

1. **Pizza A (Small, Loaded):** Diameter = 8.0, Toppings = 5
   $$\text{Price}_A = 4.02 + (0.97 \times 8.0) + (1.81 \times 5) = 4.02 + 7.76 + 9.05 = \$20.83$$
2. **Pizza B (Large, Plain):** Diameter = 16.0, Toppings = 0
   $$\text{Price}_B = 4.02 + (0.97 \times 16.0) + (1.81 \times 0) = 4.02 + 15.52 + 0.00 = \$19.54$$

Despite being twice as wide as Pizza A, Pizza B is predicted to be cheaper ($19.54 vs $20.83) because 5 toppings contribute more incremental cost ($9.05) than 8 extra inches of plain crust ($7.76). Multiple features capture the true trade-offs in customer orders.

## Step-by-Step Implementation Guide
1. Import pandas: `import pandas as pd`.
2. Load the CSV file: `df = pd.read_csv('data/pizza_menu.csv')`.
3. Verify table dimensions: `print(df.shape)` should output `(45, 3)`.
4. Slice features into matrix $X$: `X = df[['diameter_inches', 'toppings']]`.
5. Check feature matrix shape: `print(X.shape)` should output `(45, 2)`.
6. Slice target into vector $y$: `y = df['price_usd']`.
7. Confirm target vector shape: `print(y.shape)` should output `(45,)`.

## Expected Output and Verification
When checking the shapes in an interactive Python session:
```python
>>> import pandas as pd
>>> df = pd.read_csv("data/pizza_menu.csv")
>>> X = df[["diameter_inches", "toppings"]]
>>> y = df["price_usd"]
>>> X.shape
(45, 2)
>>> y.shape
(45,)
```
The shape `(45, 2)` proves that our feature representation has successfully captured 45 distinct menu items across 2 independent dimensions.

## Practical Exercises
- **Exercise 2.1:** What error would occur if you wrote `X = df['diameter_inches', 'toppings']` with single brackets? Test this in Python.
- **Exercise 2.2:** If a third feature column `stuffed_crust` (values 0 or 1) were added to the menu, what would the shape of $X$ become?
- **Exercise 2.3:** Calculate the predicted price for a 14-inch pizza with 2 toppings using $w_1 = 0.97, w_2 = 1.81, b = 4.02$.

## Common Pitfalls and Debugging Strategies
| Pitfall | Root Cause | Debugging Strategy |
|---|---|---|
| Passing 1D Series for $X$ | Using single brackets `df['diameter_inches']` | Always use double brackets `df[['diameter_inches', ...]]` when slicing feature matrices for scikit-learn. |
| Feature order mismatch | Passing features in reverse order during prediction | Maintain identical column ordering between training matrix and inference inputs (`['diameter_inches', 'toppings']`). |
| Missing columns in DataFrame | Misspelling column names | Inspect `df.columns` to verify exact casing and underscores. |

## Best Practices and Industry Standards
- **Explicit Column Selection:** Never pass entire DataFrames into models without explicitly defining feature subsets; otherwise, database identifiers or target columns will leak into the training matrix.
- **Dimensionality Verification:** Always assert or inspect `X.ndim == 2` and `y.ndim == 1` before invoking estimator fitting methods.
- **Meaningful Feature Names:** Retain clear column names like `diameter_inches` and `toppings` rather than abstract symbols like `x1` and `x2` to ease business interpretation.

## Real-World Business Context
Multivariate modeling powers automated pricing engines across modern industries: ride-sharing services balance distance and duration, airline ticket algorithms balance departure dates and passenger loads, and retail platforms balance dimensions, material, and packaging. In restaurant operations, multivariate modeling prevents systematic margin loss on complex customized menu items.

## Summary and Key Takeaways
- Multiple Linear Regression models real-world outcomes that depend simultaneously on two or more distinct causal drivers.
- In `main.py`, $X$ is a 2D feature matrix of shape `(45, 2)` containing `diameter_inches` and `toppings`.
- The target $y$ is a 1D vector of shape `(45,)` containing `price_usd`.
- Pandas double-bracket notation `df[['col1', 'col2']]` guarantees the 2D structure required by scikit-learn.

## Knowledge Check and Self-Assessment
1. How does multiple linear regression differ mathematically from simple linear regression?
2. What are the dimensions of the feature matrix $X$ extracted in `main.py`?
3. Why does scikit-learn require $X$ to have two dimensions even when only evaluating features?
4. How can a smaller pizza with many toppings cost more than a larger pizza with zero toppings?

## References and Further Reading
- Scikit-learn Data Representation: https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html
- Pandas Indexing and Selecting Data: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html
- Python Data Science Handbook (VanderPlas), Chapter 5: In-Depth Linear Regression
