# Lesson 03: Exploring the Pizza Menu Dataset (data/pizza_menu.csv)

**Lesson ID:** lesson-03
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Locate, load, and inspect the structure of `data/pizza_menu.csv`
- Identify the statistical ranges, data types, and null values in the dataset
- Explain how variations in diameter and topping counts reflect realistic restaurant offerings
- Describe the relationship between continuous measurements (`diameter_inches`, `price_usd`) and discrete counts (`toppings`)
- Verify data hygiene and prepare the raw data for machine learning modeling

## Prerequisites
- Completion of Lessons 01 and 02
- Basic familiarity with terminal commands and file navigation

## Concept Explanation

### Anatomy of `data/pizza_menu.csv`
The dataset powering the Pizza Price Calculator is located at `data/pizza_menu.csv`. It comprises 45 recorded pizza configurations, reflecting real offerings from a commercial pizza establishment.

The dataset features three columns:
1. `diameter_inches` (float): The measured physical diameter of the pizza in inches, ranging from personal sizes (approx. 8.4 inches) to extra-large party pizzas (approx. 17.6 inches).
2. `toppings` (integer): The count of distinct toppings requested on the pizza, ranging from 0 (plain cheese) to 5 gourmet toppings.
3. `price_usd` (float): The actual menu price charged in US Dollars, ranging from approximately $12.59 up to $30.43.

### Inspecting Raw CSV Data
Before passing data to machine learning models, professional data scientists inspect the raw text file to verify structural integrity. Let us inspect the first few lines of `data/pizza_menu.csv`:
```csv
diameter_inches,toppings,price_usd
10.5,3,19.03
13.3,5,25.35
15.6,0,18.66
14.3,3,23.63
10.0,5,22.17
8.5,1,15.01
```

Notice key characteristics:
- The file uses standard comma delimiters with no trailing commas.
- Row 1 provides descriptive headers matching our feature names.
- Decimal points are formatted with standard periods (`.`), avoiding regional comma confusion.
- There are no extraneous categorical strings or missing values in this clean training set.

### Statistical Summary of Menu Features
Analyzing summary statistics helps assess whether the data represents a plausible commercial menu:
- **Sample size:** 45 records. While small compared to enterprise data warehouses, 45 well-distributed points are ideal for linear regression with 2 features (giving a high observation-to-feature ratio of $45 : 2$).
- **Diameter distribution:** Mean diameter is approximately 13.3 inches, spanning personal smalls (8.4 in), mediums (11–13 in), larges (14–16 in), and party pies (17+ in).
- **Toppings distribution:** Mean toppings is approximately 2.6 items, uniformly distributed across cheese-only (0) to maximum toppings (5).
- **Price distribution:** Prices average roughly $21.20, showing a strong positive correlation with both size and toppings.

## Relevant Code (from main.py, lines 21-28)
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)


def main() -> None:
    df = pd.read_csv(DATA / "pizza_menu.csv")
```

## Code Architecture and Walkthrough
- **Path Resolution:** `BASE = Path(__file__).resolve().parent` calculates the absolute path to the directory containing `main.py`. This ensures that relative path references like `DATA / "pizza_menu.csv"` work identically regardless of whether the script is invoked from the project root, a parent folder, or an IDE runner.
- **Subdirectory Anchoring:** `DATA = BASE / "data"` establishes a dedicated path object pointing to the data repository.
- **CSV Ingestion:** `pd.read_csv(DATA / "pizza_menu.csv")` parses the comma-separated file into a memory-resident `pd.DataFrame`.

## Worked Example
Let us compute basic exploratory statistics using pandas:
```python
import pandas as pd
from pathlib import Path

DATA_PATH = Path("data/pizza_menu.csv")
df = pd.read_csv(DATA_PATH)

print(f"Total rows: {len(df)}")
print(f"Columns: {list(df.columns)}")
print(f"Diameter range: {df['diameter_inches'].min():.1f} to {df['diameter_inches'].max():.1f} inches")
print(f"Toppings range: {df['toppings'].min()} to {df['toppings'].max()} toppings")
print(f"Price range: ${df['price_usd'].min():.2f} to ${df['price_usd'].max():.2f}")
```
Output:
```
Total rows: 45
Columns: ['diameter_inches', 'toppings', 'price_usd']
Diameter range: 8.4 to 17.6 inches
Toppings range: 0 to 5 toppings
Price range: $12.59 to $30.43
```
This confirms our dataset contains no corrupt records or extreme outliers.

## Step-by-Step Implementation Guide
1. Open your terminal and navigate to the project directory.
2. Confirm the existence of the data file: `ls data/pizza_menu.csv`.
3. Display the first 10 rows: `head -n 10 data/pizza_menu.csv`.
4. Count the total lines (header + 45 rows = 46 lines): `wc -l data/pizza_menu.csv`.
5. Launch Python and load the DataFrame to check data types:
   ```python
   import pandas as pd
   df = pd.read_csv("data/pizza_menu.csv")
   df.info()
   ```
6. Verify that `diameter_inches` and `price_usd` are `float64`, while `toppings` is `int64`.

## Expected Output and Verification
Running `df.info()` confirms clean data types:
```
<class 'pandas.core.frame.DataFrame'>
RangeIndex: 45 entries, 0 to 44
Data columns (total 3 columns):
 #   Column           Non-Null Count  Dtype  
---  ------           --------------  -----  
 0   diameter_inches  45 non-null     float64
 1   toppings         45 non-null     int64  
 2   price_usd        45 non-null     float64
dtypes: float64(2), int64(1)
memory usage: 1.2 KB
```
Zero null values and appropriate numeric datatypes mean no imputation or casting is necessary.

## Practical Exercises
- **Exercise 3.1:** What is the median price of a pizza in `pizza_menu.csv`? Calculate it using `df['price_usd'].median()`.
- **Exercise 3.2:** Filter the DataFrame to show all pizzas with 0 toppings. How does their price vary with diameter?
- **Exercise 3.3:** Find the cheapest and most expensive pizza in the dataset. What are their respective diameters and topping counts?

## Common Pitfalls and Debugging Strategies
| Pitfall | Root Cause | Debugging Strategy |
|---|---|---|
| `FileNotFoundError` | Executing the script from a different working directory | Use `pathlib.Path(__file__).resolve().parent` to anchor paths to the script location rather than the working directory. |
| Mixed data types in CSV | Currency symbols (`$`) in raw price column | Ensure raw numeric CSVs contain pure numbers (`19.03`), not string formatted currency (`$19.03`). |
| Inadvertent indexing column | Saving CSV with row index included | When writing datasets with pandas, always specify `index=False` to prevent generating unnamed index columns. |

## Best Practices and Industry Standards
- **Keep Raw Data Immutable:** Never directly edit or overwrite source CSV files during exploratory analysis.
- **Validate Data Types Early:** Catch string-formatted numbers or null entries immediately upon loading before passing data to scikit-learn.
- **Verify Sample Distributions:** Check that feature ranges adequately cover the anticipated operational domain (e.g., diameters from 8 to 18 inches).

## Real-World Business Context
In production restaurant management platforms like Toast or Square POS, menu databases store item master records with standard ingredient costs. Clean tabular representations allow algorithmic price optimization tools to ingest point-of-sale data nightly and update pricing strategies based on sales volume and ingredient inflation.

## Summary and Key Takeaways
- `data/pizza_menu.csv` contains 45 observations across three columns: `diameter_inches`, `toppings`, and `price_usd`.
- All three columns are clean, complete, and numeric, with zero missing values.
- Diameter ranges from 8.4 to 17.6 inches; toppings range from 0 to 5; prices range from $12.59 to $30.43.
- Robust path handling with `pathlib.Path` ensures consistent file access across all execution environments.

## Knowledge Check and Self-Assessment
1. How many total pizza records are present in `data/pizza_menu.csv`?
2. What are the minimum and maximum values for `toppings` in the dataset?
3. Why is it preferable for `price_usd` to be stored as a raw float rather than formatted with a dollar sign?
4. What role does `Path(__file__).resolve().parent` play in establishing reliable data loading?

## References and Further Reading
- Python pathlib documentation: https://docs.python.org/3/library/pathlib.html
- Pandas read_csv documentation: https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html
- Exploratory Data Analysis with Pandas: https://pandas.pydata.org/docs/getting_started/intro_tutorials/06_calculate_statistics.html
