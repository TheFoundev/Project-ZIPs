# Lesson 04: Practical ML as a Business Tool: Automated Quoting

**Lesson ID:** lesson-04
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain how machine learning models transition from experimental research code to operational business tools
- Describe the "Model-as-an-API" software engineering pattern
- Contrast manual price sheets with dynamic algorithmic quotation engines
- Trace the lifecycle of a pricing request from customer input to model prediction
- Articulate the commercial benefits of automated pricing consistency and margin protection

## Prerequisites
- Completion of Lessons 01, 02, and 03
- Basic understanding of Python functions and return values

## Concept Explanation

### The Gap Between ML Research and Commercial Software
In academic or introductory data science courses, machine learning projects often stop once evaluation metrics (like Mean Absolute Error or $R^2$) are printed to the console. While calculating statistical performance is necessary, it provides zero commercial value on its own. A business cannot sell a Jupyter Notebook to a hungry customer.

To create commercial value, a trained model must be embedded into an operational workflow. In the Pizza Price Calculator, we bridge this gap by converting the trained regression model into a **reusable price-quoting service**:
```python
def quote_pizza(diameter_inches: float, toppings: int) -> float:
    """Return the model's price estimate for one pizza."""
    ...
```
This architectural pattern is known in software engineering as the **Model-as-an-API** or **Model Wrapper** pattern.

```mermaid
flowchart LR
    A["Customer Order: 12 in, 3 toppings"] --> B["quote_pizza() API Function"]
    B --> C["Package into DataFrame"]
    C --> D["model.predict() Engine"]
    D --> E["Format Dollar Quote: $21.05"]
    E --> F["POS / Customer Receipt / Menu"]
```

### Commercial Benefits of Algorithmic Pricing
Why would a pizzeria deploy a machine learning model instead of printing a static laminated menu?
1. **Infinite Customization:** A traditional menu lists only predefined sizes (e.g., Small, Medium, Large). When a customer asks for a non-standard 11-inch pan pizza or a giant 20-inch catering sheet pizza, staff no longer need to guess prices inconsistently.
2. **Pricing Consistency:** Different cashiers might charge different amounts for extra toppings or off-menu sizes. Algorithmic quotation ensures strict pricing fairness and consistency.
3. **Dynamic Inflation and Cost Updating:** If mozzarella prices rise by 10% and flour rises by 5%, the restaurant can retrain the model on updated cost data or adjust baseline weights. The entire digital menu updates simultaneously.
4. **Automated Catalog Generation:** The model can automatically generate wholesale menus, catering proposals, and multi-tier price lists with zero manual spreadsheet calculation.

### How the Quoting Lifecycle Operates
The automated quoting process follows four distinct phases:
1. **Input Ingestion:** The service receives user inputs (`diameter_inches: float`, `toppings: int`).
2. **Feature Packaging:** Scikit-learn models cannot accept loose float arguments; inputs must be packaged into a 2D tabular container (such as a single-row `pd.DataFrame`) whose column headers exactly match the training features.
3. **Model Inference:** The trained estimator executes matrix multiplication: $\hat{y} = w_1 x_1 + w_2 x_2 + b$.
4. **Response Formatting:** The continuous raw float is converted into a standard commercial currency string (`$21.05`).

## Relevant Code (from main.py, lines 45-53, 62-76)
```python
    def quote_pizza(diameter_inches: float, toppings: int) -> float:
        """Return the model's price estimate for one pizza."""
        order = pd.DataFrame(
            [{"diameter_inches": diameter_inches, "toppings": toppings}]
        )
        return float(model.predict(order)[0])

    example = quote_pizza(12, 3)

    print("=" * 60)
    print("THE PIZZA PRICE CALCULATOR")
    print("=" * 60)
    ...
    print(f"Quote for a 12-inch pizza with 3 toppings: ${example:.2f}")

    menu = pd.DataFrame(
        [
            {"order": "Small, 8-inch, 1 topping", "diameter": 8, "toppings": 1},
            {"order": "Medium, 12-inch, 3 toppings", "diameter": 12, "toppings": 3},
            {"order": "Large, 16-inch, 5 toppings", "diameter": 16, "toppings": 5},
            {"order": "Party, 18-inch, 5 toppings", "diameter": 18, "toppings": 5},
        ]
    )
    menu["model_quote"] = [
        quote_pizza(row.diameter, row.toppings) for row in menu.itertuples()
    ]
```

## Code Architecture and Walkthrough
- **Closure and Encapsulation:** `quote_pizza` is defined inside `main()` after `model` has been fitted. It forms a Python closure over `model`, granting the function access to the trained weights without requiring global variables.
- **DataFrame Reconstruction:** `order = pd.DataFrame([{"diameter_inches": diameter_inches, "toppings": toppings}])` creates a 1-row, 2-column DataFrame. This ensures scikit-learn receives identical feature column names, suppressing feature name warnings.
- **Scalar Extraction:** `model.predict(order)` returns a NumPy array containing one element (`array([21.0471...])`). `float(...[0])` extracts the native Python float scalar.
- **Batch Menu Pricing:** Lines 70-72 demonstrate vectorization over a batch catalog: a list comprehension iterates over standard menu options, invoking `quote_pizza` to produce an automated price list.

## Worked Example
Suppose an online food ordering platform queries our model for four standard pizza sizes:
- Small (8 in, 1 topping)
- Medium (12 in, 3 toppings)
- Large (16 in, 5 toppings)
- Party (18 in, 5 toppings)

Using the learned equation $\text{price} = 4.0224 + 0.9656 \times \text{diameter} + 1.8125 \times \text{toppings}$:
- Small: $4.0224 + 0.9656(8) + 1.8125(1) = 4.0224 + 7.7248 + 1.8125 = \$13.56$
- Medium: $4.0224 + 0.9656(12) + 1.8125(3) = 4.0224 + 11.5872 + 5.4375 = \$21.05$
- Large: $4.0224 + 0.9656(16) + 1.8125(5) = 4.0224 + 15.4496 + 9.0625 = \$28.53$
- Party: $4.0224 + 0.9656(18) + 1.8125(5) = 4.0224 + 17.3808 + 9.0625 = \$30.46$

The business owner obtains an instantly harmonized price list adhering strictly to empirical cost trends.

## Step-by-Step Implementation Guide
1. Train your regression model on the training partition.
2. Define the helper function `quote_pizza(diameter_inches, toppings)`.
3. Inside the helper, package the arguments into a single-row dictionary and convert to `pd.DataFrame`.
4. Call `model.predict(order)` and cast the first array element to a native `float`.
5. Call `quote_pizza(12, 3)` to verify single-item quotation ($21.05).
6. Build a catalog DataFrame representing standard menu items.
7. Apply `quote_pizza` across catalog rows using list comprehension or `.apply()`.
8. Format and print the generated catalog prices.

## Expected Output and Verification
Executing the menu generation code prints:
```
Price list from the model:
  Small, 8-inch, 1 topping            $13.56
  Medium, 12-inch, 3 toppings         $21.05
  Large, 16-inch, 5 toppings          $28.53
  Party, 18-inch, 5 toppings          $30.46
```
The output confirms that prices scale logically with both size increases and topping counts.

## Practical Exercises
- **Exercise 4.1:** Call `quote_pizza(10, 2)` to calculate the price for a 10-inch pizza with 2 toppings.
- **Exercise 4.2:** What price does the model quote for a plain 12-inch cheese pizza (0 toppings)? Compare it to the 3-topping 12-inch quote.
- **Exercise 4.3:** How would you modify `quote_pizza` to round prices to commercial $0.99 endings (e.g., $13.99 instead of $13.56)?

## Common Pitfalls and Debugging Strategies
| Pitfall | Root Cause | Debugging Strategy |
|---|---|---|
| Column name mismatch warning | Passing a plain 2D array or DataFrame with wrong column names to `predict()` | Build the single-row DataFrame using dictionary keys that exactly match `X_train.columns`. |
| Indexing errors on model output | Forgetting `[0]` when extracting scalar from `predict()` | `predict()` always returns a 1D array; extract the scalar using `[0]`. |
| Extrapolating beyond reasonable bounds | Quoting an impossible 100-inch pizza or negative toppings | Implement validation assertions (`assert diameter > 0`) inside the quotation wrapper. |

## Best Practices and Industry Standards
- **Encapsulate Models in Domain Functions:** Wrap raw estimators in clean, type-annotated functions (`def quote_pizza(...) -> float:`) that hide ML library complexities from consumers.
- **Input Validation:** Enforce boundary checks on input arguments (e.g., rejecting negative diameters or fractional toppings) before invoking predictions.
- **Explicit Return Types:** Cast NumPy floats to Python standard `float` to guarantee JSON serializability in microservices and web APIs.

## Real-World Business Context
In cloud-native architectures, functions like `quote_pizza` are deployed as serverless microservices (e.g., AWS Lambda, Google Cloud Run) behind REST or GraphQL endpoints. When a customer adjusts a pizza size slider on a mobile ordering app, the frontend sends an asynchronous JSON request to the pricing API, which returns real-time quotes without page reloads.

## Summary and Key Takeaways
- Practical machine learning requires deploying trained estimators into usable software constructs.
- The `quote_pizza()` function pattern encapsulates the trained model into a reusable pricing service.
- The wrapper formats input features into a compliant DataFrame, calls `model.predict()`, and returns clean monetary values.
- Automated quoting enables instant menu catalog generation, protects restaurant profit margins, and eliminates subjective pricing errors.

## Knowledge Check and Self-Assessment
1. Why is wrapping a trained machine learning model inside a helper function considered a best practice in software engineering?
2. What specific container structure does `quote_pizza()` construct before calling `model.predict()`?
3. What is the predicted price for a 12-inch pizza with 3 toppings?
4. How does `quote_pizza()` facilitate batch price list generation for an entire restaurant menu?

## References and Further Reading
- Designing Machine Learning Systems (Chip Huyen), Chapter 9: Continual Learning and Serving
- Microservice Architecture Patterns: https://microservices.io/patterns/index.html
- Scikit-learn Model Persistence and Serving: https://scikit-learn.org/stable/model_persistence.html
