# Lesson 01: The Pizza Pricing Problem & Business Context

**Lesson ID:** lesson-01
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- State the commercial business problem addressed by the Pizza Price Calculator
- Explain why pricing pizza requires multiple input variables rather than a single attribute
- Differentiate between rule-based manual pricing and machine-learned statistical pricing
- Identify the target variable (`price_usd`) and initial features (`diameter_inches`, `toppings`)
- Explain why supervised multiple regression is the appropriate paradigm for pricing estimation

## Prerequisites
- Familiarity with basic mathematical equations ($y = mx + b$)
- Understanding of variables and functions in basic Python

## Concept Explanation

### The Commercial Pricing Dilemma
In any pizzeria or casual dining restaurant, establishing a fair, profitable, and consistent pricing schedule is a core operational challenge. Traditionally, restaurant managers set fixed prices for discrete tiers: an 8-inch small pizza with cheese, a 12-inch medium pepperoni pizza, or an 18-inch party pizza with various extra toppings. However, custom orders and promotional offerings quickly complicate discrete pricing tables. If a customer demands a 14.5-inch custom pan pizza with 4 gourmet toppings, what price should the cashier or digital point-of-sale (POS) terminal quote?

If the price is set too low, the restaurant loses money on food costs (dough, sauce, mozzarella, and meat toppings) and specialized labor. If the price is set too high, price-sensitive consumers abandon their digital shopping carts and purchase from competitors.

### Why Multiple Factors Matter in Pricing
In simpler machine learning examples, such as predicting lemonade stand sales strictly from the ambient outdoor temperature, a single independent feature is evaluated against the target. However, real-world commerce is rarely single-dimensional. 

Consider a pizza:
1. **Physical size (Diameter in inches):** The surface area of a circular pizza is proportional to the square of its radius ($A = \pi r^2$). As diameter expands from 8 inches to 16 inches, the surface area quadruples from roughly $50.3\text{ in}^2$ to $201.1\text{ in}^2$. Larger pizzas require significantly more raw dough, base cheese, sauce, box packaging, and oven space.
2. **Topping volume (Number of toppings):** Each additional topping (mushrooms, pepperoni, onions, bacon, bell peppers) introduces incremental ingredient costs and prep line labor.

If an algorithm only observed pizza diameter, an 8-inch specialty pizza with 5 gourmet meats would be underpriced against an 8-inch plain cheese pizza. Conversely, if an algorithm only observed the topping count, a giant 18-inch pizza with 1 topping might be priced identically to a tiny personal 8-inch single-topping pizza. Therefore, establishing an accurate price requires **multiple features simultaneously**.

### Supervised Learning for Commercial Valuation
This task falls squarely under **supervised learning**. We provide an algorithm with historical examples where both the input features (size and topping count) and the ground-truth outcome (the actual historical menu price in USD) are already recorded in a database. The algorithm analyzes this historical tabular dataset to learn the underlying pricing pattern, enabling it to generalize to novel pizza configurations.

## Relevant Code (from main.py, lines 1-8)
```python
"""Project 08: The Pizza Price Calculator (linear regression).

Run:
    python main.py

Train a model on a small menu, then use it as a reusable price-quoting
function for any pizza size and topping count.
"""
```

## Code Architecture and Walkthrough
The introductory docstring of `main.py` defines the scope and commercial goal of the project:
- **Title and Paradigm:** "Project 08: The Pizza Price Calculator (linear regression)." It explicitly specifies linear regression as the learning algorithm.
- **The Execution Model:** It instructs the user to run `python main.py` directly from the terminal without complicated orchestration flags.
- **The Core Innovation:** Unlike typical classroom scripts that simply train a model and terminate after printing summary statistics, this project encapsulates the trained model inside a **reusable price-quoting function** (`quote_pizza`). This transforms a static machine learning script into an interactive pricing engine suitable for integration into an e-commerce API or POS system.

## Worked Example
Suppose a pizzeria wants to calculate an initial estimate for a 12-inch pizza with 3 toppings based on a known historical pricing formula:
$$\text{Price} = \text{Base Cost} + (\text{Rate per Inch} \times \text{Diameter}) + (\text{Rate per Topping} \times \text{Toppings})$$

If historical menu trends indicate:
- Base preparation cost (intercept): $4.02
- Value per diameter inch: $0.97
- Value per topping item: $1.81

Let us manually compute the expected quotation:
1. Size contribution: $12 \times 0.97 = 11.64$
2. Topping contribution: $3 \times 1.81 = 5.43$
3. Base cost: $4.02$
4. Total predicted quote: $4.02 + 11.64 + 5.43 = \$21.09$ (or $21.05 with unrounded coefficients).

The machine learning model will discover these exact weights directly from the historical menu data without manual human guesswork.

## Step-by-Step Implementation Guide
To understand how the business problem maps into an AI/ML project:
1. **Identify the Business Outcome:** The goal is automated, objective pricing of any customer pizza order.
2. **Define the Target Variable:** Label the variable to be predicted as `price_usd` (a continuous numeric dollar amount).
3. **Select Predictor Features:** Select `diameter_inches` and `toppings` as independent features that directly dictate cost.
4. **Collect Labeled Examples:** Assemble historical menu offerings into `pizza_menu.csv`.
5. **Formulate the Mathematical Objective:** Find weights $w_1, w_2$ and intercept $b$ such that predicted price closely aligns with actual historical price across all menu items.

## Expected Output and Verification
When the model executes the pricing logic, it outputs a clean pricing schedule matching the restaurant's operational targets:
```
============================================================
THE PIZZA PRICE CALCULATOR
============================================================
Equation: price = 4.02 + 0.97 x diameter + 1.81 x toppings
Mean absolute error: $0.58
R-squared: 0.98
Quote for a 12-inch pizza with 3 toppings: $21.05
```
Notice how the quotation of $21.05 closely matches our intuitive hand calculations, proving the validity of the learning algorithm.

## Practical Exercises
- **Exercise 1.1:** Calculate the expected price of a personal 8-inch pizza with 1 topping using the equation $\text{price} = 4.02 + 0.97 \times \text{diameter} + 1.81 \times \text{toppings}$.
- **Exercise 1.2:** If a restaurant introduces a 20-inch colossal party pizza with 6 toppings, what would the linear pricing formula predict?
- **Exercise 1.3:** Explain why setting pizza prices using intuition or ad-hoc guessing can harm restaurant profitability compared to statistical regression modeling.

## Common Pitfalls and Debugging Strategies
| Pitfall | Root Cause | Debugging Strategy |
|---|---|---|
| Treating pricing as a classification task | Confusion between continuous money and discrete categories | Verify that prices are numeric floats ($19.03, $25.35) requiring regression rather than discrete class labels. |
| Using only diameter as a predictor | Ignoring topping variance | Always inspect all available business drivers; omitting toppings leaves high residual variance unexplained. |
| Predicting negative prices | Using unconstrained models outside valid input domains | Understand that linear models extrapolate; inputting negative diameter or toppings produces nonsensical negative prices. |

## Best Practices and Industry Standards
- **Align Feature Selection with Domain Physics:** Choose features that physically correlate with operational costs (surface area, raw ingredient counts).
- **Ensure Ground Truth Accuracy:** Ensure historical menu prices in training data reflect sustainable profit margins, not liquidation sales or erratic discounts.
- **Maintain Modular Architecture:** Separate data loading, model fitting, and quotation services into distinct functional steps.

## Real-World Business Context
Modern food delivery platforms like DoorDash, Uber Eats, and Domino's utilize automated pricing engines for dynamic menus, build-your-own interfaces, and automated cost optimization. By treating pricing as a regression function, multi-branch franchises can update global pricing algorithms instantly when ingredient costs change across regional supply chains.

## Summary and Key Takeaways
- The Pizza Price Calculator solves the commercial need for consistent, automated pizza pricing across arbitrary sizes and custom topping selections.
- Real-world pricing is multivariate: diameter accounts for base crust and cheese area, while topping count accounts for incremental ingredient costs.
- Supervised linear regression models this relationship by estimating an equation that balances both features to predict continuous dollar amounts (`price_usd`).

## Knowledge Check and Self-Assessment
1. What is the dependent target variable in the Pizza Price Calculator project?
2. What are the two independent feature variables used to estimate the target?
3. Why would a single-variable model relying only on pizza diameter fail on custom orders?
4. How does supervised learning leverage historical menu data to predict prices for new, unlisted pizzas?

## References and Further Reading
- Scikit-learn Linear Regression User Guide: https://scikit-learn.org/stable/modules/linear_model.html#ordinary-least-squares
- Introduction to Statistical Learning (James et al.), Chapter 3: Linear Regression
- Pizza Price Calculator project repository: `08_pizza_price/main.py`
