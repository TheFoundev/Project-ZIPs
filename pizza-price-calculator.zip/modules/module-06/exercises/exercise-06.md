# Module 06 Exercises: Pipeline Execution, File Export, and Model Extensions

These exercises reinforce the concepts of full-pipeline execution, persistent file exporting, feature extension with dummy variables, and production operationalization learned in Module 06.

---

## Exercise 1: Pipeline Execution and Output File Verification Script

### Objective
Execute the full `main.py` pipeline and write an automated verification test that asserts all expected console outputs, numerical values, and file artifacts are present and correct.

### Background
Automated continuous integration (CI) tests ensure that code modifications do not break pipeline execution or alter core mathematical results.

### Requirements
1. Write a Python script `verify_pipeline.py`.
2. Use Python's `subprocess.run()` to execute `main.py` and capture `stdout` and `stderr`.
3. Assert that the exit code is 0.
4. Verify that the captured output contains:
   - "Mean Absolute Error: $0.58"
   - "R-squared:           0.98"
   - "Quote for 12-inch with 3 toppings: $21.05"
5. Verify that `actual_vs_predicted.png` exists and has a file size greater than 10,000 bytes.
6. Print a clear confirmation message upon successful verification.

### Acceptance Criteria
- [ ] Subprocess executes cleanly without exceptions.
- [ ] Output strings and numbers are asserted against expected ground-truth values.
- [ ] File existence and minimum size (>10KB) are validated.
- [ ] Test fails with informative error messages if any assertion fails.

---

## Exercise 2: Implementing Structured JSON and CSV Menu Exporters

### Objective
Extend the file export functionality to generate both a machine-readable JSON catalog (`outputs/menu_catalog.json`) and a tabular CSV file (`outputs/menu_catalog.csv`) containing quotes for 6 standard pizza configurations.

### Background
Downstream web applications and mobile apps consume JSON feeds, while spreadsheet-based accounting systems require CSV files.

### Requirements
1. Define a menu list containing at least 6 standard pizza configurations spanning small (8"), medium (10", 12"), large (14", 16"), and party (18") sizes with realistic topping counts.
2. For each configuration, compute the quote using `quote_pizza()`.
3. Export the results to `outputs/menu_catalog.json` using `json.dump()` with 2-space indentation.
4. Export the results to `outputs/menu_catalog.csv` using Python's `csv.writer` or pandas `DataFrame.to_csv(index=False)`.
5. Verify that both files exist and can be parsed cleanly.

### Acceptance Criteria
- [ ] Six distinct pizza configurations are evaluated.
- [ ] `outputs/menu_catalog.json` contains valid, parseable JSON with keys: `size`, `diameter_inches`, `toppings`, and `quote_usd`.
- [ ] `outputs/menu_catalog.csv` contains valid CSV headers and rows.
- [ ] Quotes match the model equation ($4.02 + 0.97 	imes d + 1.81 	imes t$).

---

## Exercise 3: Incorporating a Binary Feature and Retraining

### Objective
Create a synthetic dataset with a binary indicator `gluten_free` (0 or 1), fit a 3-feature regression model, and verify that the learned coefficient represents the flat surcharge for gluten-free crust.

### Background
Extending regression models with categorical dummy variables is standard practice in fast-casual restaurant pricing.

### Requirements
1. Load `data/pizza_menu.csv`.
2. Add a synthetic column `gluten_free`:
   - Set 1 for approximately 30% of rows and 0 for the remainder (e.g. using a deterministic rule or fixed random state).
   - For rows where `gluten_free == 1`, add an intentional price premium of $3.50 to `price_usd`.
3. Split the data into train (75%) and test (25%) using `random_state=42`.
4. Fit a 3-feature `LinearRegression` model on `["diameter_inches", "toppings", "gluten_free"]`.
5. Extract and print the coefficients. Verify that the coefficient for `gluten_free` is approximately $3.50 ($\pm$ $0.10).
6. Implement `quote_pizza_gf(diameter, toppings, gluten_free=False)` and verify that quoting a gluten-free pizza adds ~$3.50 compared to regular crust.

### Acceptance Criteria
- [ ] Synthetic dataset correctly integrates the binary column.
- [ ] 3-feature regression model fits without matrix singularity errors.
- [ ] Extracted coefficient for `gluten_free` is within $0.10 of the $3.50 ground truth surcharge.
- [ ] Quoting function correctly accepts and applies the boolean flag.

---

## Exercise 4: Building a Production-Guarded CLI Price Calculator

### Objective
Create an interactive command-line interface `quote_cli.py` using Python's `argparse` module that incorporates defensive input validation guardrails and graceful error handling.

### Background
CLI tools enable kitchen managers and store supervisors to generate quick price quotes directly from terminal workstations without writing Python code.

### Requirements
1. Create `quote_cli.py` using `argparse.ArgumentParser`.
2. Define required CLI arguments:
   - `--diameter` (float): Pizza diameter in inches.
   - `--toppings` (int): Number of toppings.
   - `--stuffed-crust` (optional flag, `action="store_true"`): Upgrade to stuffed crust.
3. Implement validation guardrails:
   - Reject diameter < 6 or > 24 inches with an informative message.
   - Reject toppings < 0 or > 12 with an informative message.
4. If inputs are valid, compute and display the formatted price quote.
5. Include `--help` documentation explaining all options and allowable ranges.

### Acceptance Criteria
- [ ] CLI runs via terminal command: `python3 quote_cli.py --diameter 14 --toppings 3`.
- [ ] Out-of-range inputs trigger clear, non-crashing error messages and exit with code 1.
- [ ] Valid inputs display cleanly formatted quote: `Quote for 14" pizza with 3 toppings: $X.XX`.
- [ ] `--help` displays complete usage instructions.
