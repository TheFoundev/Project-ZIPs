# Lesson 02: File Output and Automated Menu Exporting

**Lesson ID:** lesson-02
**Module:** module-06
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Export machine-generated price quotes to persistent disk files (`outputs/quotes.txt`)
- Utilize Python context managers (`with open(...) as f:`) for deterministic file resource handling
- Format tabular text outputs with column headers, alignment, and separator rules
- Handle filesystem directory creation programmatically using `pathlib.Path`
- Implement automated verification routines to audit file contents after export

## Prerequisites
- Completion of Lesson 01
- Understanding of Python file I/O operations (`open`, `write`, `close`)
- Familiarity with string formatting methods (f-strings, format specifiers)

## Concept Explanation

### The Persistence Imperative
In Module 04, we demonstrated how to generate standard menu price quotes in the terminal console using `quote_pizza()`:
- Small (8-inch, 1 topping): $13.56
- Medium (12-inch, 3 toppings): $21.05
- Large (16-inch, 5 toppings): $28.53
- Party (18-inch, 5 toppings): $30.46

While terminal output is ideal for developer debugging, terminal text is transient: once the terminal session closes, the quotes are lost. 
In commercial environments, downstream systems—such as point-of-sale (POS) terminals, digital menu signage, print catalog designers, and accounting software—require **persistent text or data artifacts**.

Our pipeline must therefore write these quotes to a dedicated output file: `outputs/quotes.txt`.

### Safe File Handling with Context Managers
When writing files in Python, naive implementations often use:
```python
f = open("quotes.txt", "w")
f.write("...")
f.close()
```
This naive approach is dangerous in production. If an exception occurs during `f.write()` (e.g., disk full, encoding error, or permission failure), `f.close()` is never executed. The file handle remains locked in the operating system, potentially corrupting data or causing file descriptor leaks.

The industry-standard solution is the **Python Context Manager** (`with` statement):
```python
with open("outputs/quotes.txt", "w", encoding="utf-8") as f:
    f.write("...")
```
The context manager guarantees that `f.close()` is invoked immediately upon exiting the block, even if an unhandled exception or crash occurs.

### Designing a Clean Text Catalog
A production text export should be immediately readable by human staff and easily parsed by shell utilities (like `grep`, `awk`, or `cat`). Key design elements include:
1. **Document Header:** Identifies the generating system, project title, and timestamp or version.
2. **Columnar Alignment:** Using f-string width specifiers (e.g. `{size:<10}`) to align columns neatly.
3. **Visual Separators:** Dashed horizontal rules (`---`) separating headers from data rows.
4. **Summary Footer:** Total items generated and model equation reference.

## Relevant Code Pattern
```python
from pathlib import Path

# Ensure outputs directory exists
output_dir = Path("outputs")
output_dir.mkdir(parents=True, exist_ok=True)
output_file = output_dir / "quotes.txt"

# Sample menu catalog items
catalog = [
    {"size": "Small",  "diameter": 8,  "toppings": 1},
    {"size": "Medium", "diameter": 12, "toppings": 3},
    {"size": "Large",  "diameter": 16, "toppings": 5},
    {"size": "Party",  "diameter": 18, "toppings": 5},
]

# Write persistent quotes
with open(output_file, "w", encoding="utf-8") as f:
    f.write("=====================================================\n")
    f.write("           PIZZA PRICE CALCULATOR QUOTE MENU         \n")
    f.write("=====================================================\n\n")
    f.write(f"{'Size':<10} | {'Diameter':<10} | {'Toppings':<10} | {'Quote Price':<12}\n")
    f.write("-" * 52 + "\n")
    
    for item in catalog:
        price = quote_pizza(item["diameter"], item["toppings"])
        f.write(f"{item['size']:<10} | {item['diameter']:>8}\" | {item['toppings']:>10} | ${price:>10.2f}\n")
    
    f.write("-" * 52 + "\n")
    f.write(f"Model Equation: price = 4.02 + 0.97 x diameter + 1.81 x toppings\n")
    f.write("=====================================================\n")
```

## Code Architecture and Walkthrough
Let us examine each critical design component:
1. `output_dir.mkdir(parents=True, exist_ok=True)`: Creates the destination directory if it does not already exist. The `parents=True` argument creates intermediate directories if needed, and `exist_ok=True` suppresses errors if the directory already exists.
2. `encoding="utf-8"`: Explicitly sets character encoding to UTF-8, ensuring consistent cross-platform compatibility across Linux, macOS, and Windows.
3. `{'Size':<10}`: Left-aligns text within a 10-character field width.
4. `${price:>10.2f}`: Right-aligns currency numbers to ensure decimal points align vertically for easy human scanning.

## Worked Example
When the file export code executes, it writes the following text to `outputs/quotes.txt`:

```text
=====================================================
           PIZZA PRICE CALCULATOR QUOTE MENU         
=====================================================

Size       | Diameter   | Toppings   | Quote Price 
----------------------------------------------------
Small      |        8" |          1 |      $13.56
Medium     |       12" |          3 |      $21.05
Large      |       16" |          5 |      $28.53
Party      |       18" |          5 |      $30.46
----------------------------------------------------
Model Equation: price = 4.02 + 0.97 x diameter + 1.81 x toppings
=====================================================
```

Every decimal point aligns in a clean column, and the header and footer frame the commercial catalog clearly.

## Step-by-Step Implementation Guide

### Step 1: Import Path from pathlib
```python
from pathlib import Path
```

### Step 2: Define and Create the Output Directory
```python
out_path = Path("outputs")
out_path.mkdir(parents=True, exist_ok=True)
```

### Step 3: Open the File with Context Manager and UTF-8 Encoding
```python
with open(out_path / "quotes.txt", "w", encoding="utf-8") as f:
    # Write header
    f.write("=== PIZZA QUOTE CATALOG ===
")
```

### Step 4: Iterate and Format Rows
```python
    for row in catalog:
        p = quote_pizza(row["diameter"], row["toppings"])
        f.write(f"{row['size']}: ${p:.2f}
")
```

### Step 5: Verify File Existence and Size
```python
target_file = out_path / "quotes.txt"
assert target_file.exists(), "Output file was not created!"
assert target_file.stat().st_size > 0, "Output file is empty!"
print(f"Successfully generated {target_file} ({target_file.stat().st_size} bytes)")
```

## Expected Output and Verification
Running the verification check outputs:
```text
Successfully generated outputs/quotes.txt (548 bytes)
```
Inspecting the file with `cat outputs/quotes.txt` displays the exact formatted table without trailing garbled characters.

## Practical Exercises
1. Modify the writer to also output quotes in comma-separated values (CSV) format to `outputs/quotes.csv`.
2. Add a generation timestamp using `datetime.now().strftime("%Y-%m-%d %H:%M:%S")` to the document header.
3. Implement a checksum routine using `hashlib.sha256()` to record a cryptographic hash of the generated menu file for audit trails.

## Common Pitfalls and Debugging Strategies
- **Missing Directory:** Calling `open("outputs/quotes.txt", "w")` when the `outputs/` folder does not exist throws a `FileNotFoundError`. Always call `Path("outputs").mkdir(parents=True, exist_ok=True)` first.
- **Platform-Dependent Line Endings:** Windows uses `
` (CRLF) while Linux/macOS use `
` (LF). Specifying standard `
` with UTF-8 handles modern cross-platform file reading cleanly.
- **Overwriting vs. Appending:** Mode `"w"` truncates and overwrites existing files. If you intend to preserve historical quote logs over time, use append mode `"a"`.

## Best Practices and Industry Standards
- **Explicit Encoding:** Always pass `encoding="utf-8"` to `open()`. Relying on system default encodings can corrupt currency symbols or non-ASCII characters on Windows systems.
- **Atomic File Writing:** In high-concurrency production environments, write to a temporary file first (`quotes.txt.tmp`) and then atomically rename it to `quotes.txt`. This prevents downstream readers from reading a half-written file during batch runs.
- **Separation of Formatting from Logic:** Keep table rendering functions separate from machine learning prediction routines.

## Real-World Business Context
Automating menu generation eliminates human transcription errors between pricing analytics and retail point-of-sale systems. In multi-unit restaurant operations, automated file exports feed directly into digital signage content management systems (CMS), guaranteeing that the price displayed on the store monitor matches the exact analytical pricing equation down to the penny.

## Summary and Key Takeaways
- Persistent file exports allow downstream POS and signage systems to consume ML predictions.
- The `with open(...)` context manager guarantees reliable resource cleanup and prevents descriptor leaks.
- Column-aligned text formatting improves human readability and operational auditing.
- Automated filesystem checks (`mkdir`, `exists`, `st_size`) make pipelines robust against missing directories.

## Knowledge Check and Self-Assessment
1. Why is `with open(...)` preferred over explicit `f.open()` and `f.close()` calls?
2. What happens if you attempt to open a file for writing in a subdirectory that does not exist?
3. How do f-string alignment specifiers like `{val:>10.2f}` simplify tabular text report generation?

## References and Further Reading
- Python Official Documentation: "Reading and Writing Files"
- Real Python Guide: "Working With Files in Python"
- Effective Python (Brett Slatkin), Item 54: Consider Using Lock for Concurrency in File I/O
