# Lesson 01: End-to-End Execution of the Pizza Price Calculator

**Lesson ID:** lesson-01
**Module:** module-06
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Trace the complete linear execution flow of `main.py` from initialization to completion
- Understand the sequential dependencies connecting data ingestion, preprocessing, modeling, evaluation, and reporting
- Execute the script from the command-line interface and verify console output against expected standards
- Audit generated artifacts to ensure correct directory structure and file persistence
- Diagnose common execution issues such as working directory mismatches or missing dependencies

## Prerequisites
- Completion of Modules 01 through 05
- Access to the command-line terminal and active Python virtual environment
- Verification of project file structure: `main.py` and `data/pizza_menu.csv`

## Concept Explanation

### The Anatomy of an End-to-End ML Pipeline
In previous modules, we dissected each subsystem of the Pizza Price Calculator in isolation:
- Module 01 examined data loading, DataFrame structures, and feature distributions.
- Module 02 mastered feature matrices ($X$) and target vectors ($y$), along with train/test splitting.
- Module 03 fit the `LinearRegression` model and extracted learned mathematical weights.
- Module 04 wrapped the fitted model into the `quote_pizza()` inference API and batch catalog loops.
- Module 05 evaluated model performance using MAE, $R^2$, and diagnostic scatter plots.

In software engineering and data science, an individual model component has no commercial utility until all stages are assembled into a coherent, repeatable, end-to-end pipeline. The `main.py` script serves as the conductor of this orchestra.

### Execution Lifecycle and Data Flow
When `main.py` is executed, the Python interpreter moves sequentially through six distinct operational phases:

1. **Import and Initialization Phase (Lines 1-13):**
   - Loads third-party libraries (`pandas`, `numpy`, `matplotlib`, `scikit-learn`).
   - Verifies system environment and dependency availability.

2. **Data Ingestion and Exploration Phase (Lines 15-28):**
   - Ingests `data/pizza_menu.csv` via `pd.read_csv()`.
   - Prints sample head rows, descriptive statistics, and dataset shape (45 items).

3. **Partitioning Phase (Lines 30-41):**
   - Splits dataset into 75% training (33 rows) and 25% testing (12 rows) using `random_state=42`.
   - Validates feature shapes.

4. **Model Training and Weight Inspection Phase (Lines 43-57):**
   - Fits Ordinary Least Squares regression via `model.fit(X_train, y_train)`.
   - Prints intercept ($4.02), diameter weight ($0.97/inch), and topping weight ($1.81/topping).

5. **Inference and Quoting Demonstration Phase (Lines 59-68):**
   - Defines `quote_pizza(diameter_inches, toppings)` wrapper function.
   - Evaluates a test quote: 12-inch with 3 toppings = $21.05.

6. **Evaluation and Visualization Phase (Lines 70-90):**
   - Calculates Mean Absolute Error ($0.58) and $R^2$ (0.98).
   - Generates `actual_vs_predicted.png` and exports it to disk.

## Relevant Code (from main.py, lines 1-90)
```python
# Full execution structure overview
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score

# 1. Load data
df = pd.read_csv("data/pizza_menu.csv")

# 2. Split features and target
X = df[["diameter_inches", "toppings"]]
y = df["price_usd"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)

# 3. Fit model
model = LinearRegression()
model.fit(X_train, y_train)

# 4. Define quoting function
def quote_pizza(diameter_inches, toppings):
    order = pd.DataFrame([[diameter_inches, toppings]], columns=["diameter_inches", "toppings"])
    return float(model.predict(order)[0])

# 5. Evaluate and export plot
y_pred = model.predict(X_test)
mae = mean_absolute_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
# ... plotting and export ...
```

## Code Architecture and Walkthrough
The design of `main.py` exemplifies a clean, monolithic batch script suitable for educational mastery and prototype deployment:
- **No Global Side-Effects in Functions:** `quote_pizza` accesses the trained model closure safely and operates deterministically on scalar inputs.
- **Fail-Fast Data Dependency:** If `data/pizza_menu.csv` is missing or corrupted, `pd.read_csv()` immediately raises `FileNotFoundError`, halting execution before invalid models can be trained.
- **Reproducible Partitioning:** Hardcoding `random_state=42` ensures identical train/test splits, coefficients, and evaluation metrics across every run.

## Worked Example
Executing the script from the command line:

```bash
$ cd "/home/aziz/foundev/Foundev-main/Beginner projects modules and assessments/projects/AI-ML/Pizza Price Calculator/pizza-price-calculator"
$ python3 main.py
```

Expected Terminal Output:
```text
=== PIZZA PRICE CALCULATOR ===
Dataset loaded: 45 menu items

--- Model Training ---
Training set: 33 pizzas
Test set:     12 pizzas
Trained Linear Regression Model:
  Intercept (base price): $4.02
  Diameter coefficient:  $0.97 per inch
  Toppings coefficient:  $1.81 per topping
Equation: price = 4.02 + 0.97 x diameter + 1.81 x toppings

--- Sample Quote ---
Quote for 12-inch with 3 toppings: $21.05

--- Model Evaluation ---
Mean Absolute Error: $0.58
R-squared:           0.98

Generated diagnostic plot: actual_vs_predicted.png
Pipeline executed successfully.
```

## Step-by-Step Implementation Guide

### Step 1: Open Terminal in Project Directory
Ensure your current working directory contains `main.py` and the `data/` subdirectory:
```bash
pwd
ls -la
```

### Step 2: Confirm Dependencies
Verify required packages are installed in your active environment:
```bash
python3 -c "import pandas, numpy, matplotlib, sklearn; print('All dependencies available.')"
```

### Step 3: Run the Script
```bash
python3 main.py
```

### Step 4: Verify Generated Artifacts
Confirm that `actual_vs_predicted.png` was created and has non-zero file size:
```bash
ls -lh actual_vs_predicted.png
```

## Expected Output and Verification
- Return code: `0` (clean exit without unhandled exceptions).
- Console output matches the expected numbers: Intercept ~$4.02, Diameter ~$0.97, Toppings ~$1.81, MAE ~$0.58, R2 ~0.98.
- PNG image generated: ~50-100 KB file size.

## Practical Exercises
1. Execute the script with Python's verbose optimization flag `python3 -v main.py | grep sklearn` to observe module loading times.
2. Measure total execution runtime using the Unix `time` command: `time python3 main.py`. Is execution under 1.5 seconds?
3. Introduce an intentional typo into the CSV file path (e.g., `data/pizza_menu_typo.csv`). Observe the exact Python traceback and exception hierarchy.

## Common Pitfalls and Debugging Strategies
- **Working Directory Mismatch:** Running `python3 projects/AI-ML/.../main.py` from the root directory causes `pd.read_csv("data/pizza_menu.csv")` to fail because the relative path resolves relative to the current shell location, not the script's directory. Always `cd` into the project directory or use `Path(__file__).parent / "data/pizza_menu.csv"`.
- **Headless Display Errors:** On servers without a GUI display, matplotlib may throw an error when rendering plots. Fix this by specifying the non-interactive backend at the top of the script: `import matplotlib; matplotlib.use('Agg')`.
- **Unpinned Random Seed:** Omitting `random_state=42` causes coefficients and MAE to fluctuate slightly on every run.

## Best Practices and Industry Standards
- **Use `if __name__ == '__main__':` Guard:** Encapsulate top-level execution code inside the `__main__` guard. This allows other modules or unit tests to import `quote_pizza` or `model` without inadvertently executing the entire batch pipeline.
- **Dynamic File Paths:** Use `from pathlib import Path; SCRIPT_DIR = Path(__file__).resolve().parent` to construct robust paths that work regardless of the shell's active directory.
- **Log Diagnostic Metrics:** In production, replace `print()` statements with Python's standard `logging` module to capture timestamps, log levels (INFO, WARNING), and process IDs.

## Real-World Business Context
An end-to-end pipeline script is the foundational unit of automated retail operations. In a real-world pizzeria chain with 50 locations, this script would run nightly as an automated cron job or Airflow DAG, ingesting updated ingredient cost data, retraining the linear weights, verifying MAE within tolerance (< $0.75), and publishing updated pricing tables to digital menu boards.

## Summary and Key Takeaways
- `main.py` coordinates data ingestion, partitioning, training, quoting, and evaluation into a single reproducible pipeline.
- A fixed random seed guarantees deterministic results across environments.
- Clean pipeline execution generates verified console metrics and persistent visual artifacts.
- Robust path handling and headless matplotlib configuration ensure portable deployment.

## Knowledge Check and Self-Assessment
1. Why does running a script from a parent directory sometimes trigger a `FileNotFoundError` on relative paths?
2. What role does `random_state=42` play in guaranteeing reproducibility across development teams?
3. How does the `if __name__ == '__main__':` pattern facilitate modular software testing?

## References and Further Reading
- Python Official Documentation: "Execution Model and Top-Level Code Environment"
- Python Packaging Guide: Structuring Production Machine Learning Projects
- Clean Code in Python (Mariano Anaya), Chapter 3: General Coding Principles
