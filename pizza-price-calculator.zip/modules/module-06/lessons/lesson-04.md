# Lesson 04: Operational Deployment, Monitoring, and Model Governance

**Lesson ID:** lesson-04
**Module:** module-06
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Formulate an operational deployment architecture for the pizza price calculator
- Implement defensive input validation guardrails to prevent out-of-domain pricing anomalies
- Understand the mechanisms of model decay, concept drift, and data drift in retail pricing
- Establish automated monitoring metrics, performance thresholds, and retraining triggers
- Apply model governance standards to track model versions, audit quotes, and ensure pricing compliance

## Prerequisites
- Completion of Lessons 01, 02, and 03
- Familiarity with the complete `main.py` script and evaluation metrics
- Understanding of basic software architecture principles (APIs, web services, microservices)

## Concept Explanation

### Beyond the Laboratory: The Lifecycle of a Production ML Model
Training a machine learning model that achieves an MAE of $0.58 in an isolated Python script is only the first step of machine learning engineering. 
In commercial production, a model does not live in a static notebook. It operates inside a complex, dynamic ecosystem:
- It serves thousands of concurrent API requests from mobile ordering apps and point-of-sale registers.
- It encounters unexpected user inputs (e.g. negative diameters or orders requesting 50 toppings).
- Economic environments change: wholesale cheese and flour prices rise due to inflation.
- Customer preferences evolve: competitors introduce aggressive promotional bundles.

Without active governance and operational monitoring, a once-accurate pricing model will degrade over time, leading to lost revenue or customer churn.

### Architectural Deployment Patterns
How does our trained `quote_pizza()` function reach end-users? There are three standard deployment tiers:

1. **Batch Architecture (Current Prototype):**
   - Script runs periodically (e.g. nightly), generating static pricing catalogs saved to files (`outputs/quotes.txt`) or pushed to database tables.
   - Pros: Simple, zero infrastructure latency, high reliability.
   - Cons: Cannot quote custom on-demand pizza configurations in real-time.

2. **Microservice REST API (FastAPI / Flask):**
   - The model is loaded into memory inside a lightweight web service.
   - Client applications submit JSON payloads: `POST /api/v1/quote {"diameter_inches": 14, "toppings": 3}`.
   - The service validates inputs, evaluates `quote_pizza()`, and returns `{"price_usd": 23.05, "status": "success"}` within 10 milliseconds.

3. **Edge / Client-Side Deployment:**
   - Because our linear model consists of just three numbers—intercept (4.02), diameter weight (0.97), and topping weight (1.81)—the entire mathematical formula can be compiled directly into client-side JavaScript or iOS/Android native code, running with zero network latency.

### Defensive Engineering: Input Validation Guardrails
A mathematical formula like `4.02 + 0.97 * d + 1.81 * t` will happily compute a price for *any* numerical inputs, including nonsensical or malicious values:
- `quote_pizza(-10, -5)` $\rightarrow$ returns -$14.73 (the restaurant pays the customer to take a negative-sized pizza!).
- `quote_pizza(100, 1000)` $\rightarrow$ returns $1,911.02 (a pizza the size of a billboard with a mountain of toppings).

Production models must implement strict **boundary guardrails** before passing data to the regression estimator:

```python
def quote_pizza_safe(diameter_inches, toppings):
    # Guardrail 1: Type validation
    if not isinstance(diameter_inches, (int, float)) or not isinstance(toppings, int):
        raise TypeError("Diameter must be numeric and toppings must be an integer.")
    
    # Guardrail 2: Domain boundary validation
    if not (6 <= diameter_inches <= 24):
        raise ValueError(f"Diameter {diameter_inches}\" outside allowable menu range (6\" to 24\").")
    
    if not (0 <= toppings <= 10):
        raise ValueError(f"Topping count {toppings} outside allowable menu range (0 to 10).")
    
    # Execute verified prediction
    order = pd.DataFrame([[diameter_inches, toppings]], columns=["diameter_inches", "toppings"])
    raw_price = float(model.predict(order)[0])
    
    # Guardrail 3: Business margin floor
    min_price = 8.50  # Hard floor to guarantee base ingredient cost recovery
    return max(raw_price, min_price)
```

### Monitoring Concept Drift and Retraining Triggers
Over time, machine learning models experience **performance decay** due to two primary phenomena:
1. **Data Drift:** The distribution of incoming features changes (e.g. customers start ordering much larger pizzas or radically different topping counts than were present in the training set).
2. **Concept Drift:** The statistical relationship between features and target price changes (e.g. inflation drives wholesale meat prices up 20%, meaning each topping now costs the restaurant $2.20 instead of $1.81).

To maintain model accuracy, production teams implement **monitoring hooks** and automated retraining pipelines:
- **Daily Residual Tracking:** Log the residual $e = y_{	ext{actual}} - y_{	ext{quoted}}$ for every transaction. If rolling 7-day MAE exceeds $0.85 (a 46% increase over the $0.58 baseline), trigger a Slack alert to the pricing team.
- **Scheduled Retraining:** Retrain the model on the first of every month using the trailing 90 days of sales data.
- **Canary Deployment:** When deploying a new model version, route 10% of traffic to the new model and 90% to the established model, comparing conversion rates and customer feedback before full cutover.

## Relevant Code (from main.py, lines 59-68)
```python
def quote_pizza_production(diameter_inches, toppings):
    # Production guardrails
    if not (6 <= diameter_inches <= 24):
        raise ValueError(f"Diameter {diameter_inches} out of menu range (6-24 inches)")
    if not (0 <= toppings <= 10):
        raise ValueError(f"Topping count {toppings} out of menu range (0-10 toppings)")
    
    order = pd.DataFrame([[diameter_inches, toppings]], columns=["diameter_inches", "toppings"])
    raw_quote = float(model.predict(order)[0])
    return max(raw_quote, 8.50)  # Margin floor
```

## Code Architecture and Walkthrough
The production service wraps the core machine learning inference pipeline inside defensive guardrail logic:
1. Type and boundary validation intercepts nonsensical inputs before they reach the model.
2. The estimator computes the linear projection price.
3. A business logic floor guarantees minimum ingredient margin recovery.
4. Logging middleware records request telemetry and pricing residuals for ongoing drift monitoring.

## Worked Example
Consider an incoming request for a 14-inch pizza with 4 toppings:
1. Input validation confirms diameter 14 is within [6, 24] and toppings 4 is within [0, 10].
2. The model evaluates: $4.02 + (0.97 \times 14) + (1.81 \times 4) = 4.02 + 13.58 + 7.24 = \$24.84$.
3. The margin floor check verifies: $\max(24.84, 8.50) = \$24.84$.
4. The API returns JSON payload `{"status": "success", "quote_usd": 24.84}` with 5ms response latency.

### Production Architecture Flow


```text
+-----------------------+      +-----------------------+
|  Mobile App / POS     | ---> |  API Gateway (Auth)   |
+-----------------------+      +-----------------------+
                                           |
                                           v
                               +-----------------------+
                               | Input Validation Gate |
                               | (6"-24", 0-10 tops)   |
                               +-----------------------+
                                           |
                                           v
                               +-----------------------+
                               | quote_pizza() Engine  |
                               | (Linear Regression)   |
                               +-----------------------+
                                           |
                     +---------------------+---------------------+
                     |                                           |
                     v                                           v
         +-----------------------+                   +-----------------------+
         | Price Quote Response  |                   | Audit Log & Telemetry |
         | ($21.05 returned)     |                   | (Residuals, Drift)    |
         +-----------------------+                   +-----------------------+
```

## Step-by-Step Implementation Guide

### Step 1: Encapsulate Validation Logic
Build explicit boundary checks that raise clean, actionable domain exceptions.

### Step 2: Establish Audit Logging
Log every incoming request, calculated quote, and processing timestamp to an audit log file or time-series database:
```python
import logging

logging.basicConfig(filename="pricing_service.log", level=logging.INFO,
                    format="%(asctime)s - %(levelname)s - %(message)s")

logging.info(f"Quote generated: diameter={d}, toppings={t}, quote=${price:.2f}")
```

### Step 3: Implement Automated Health Checks
Create a synthetic health-check order (12-inch, 3 toppings) that runs every minute to verify the service returns $21.05 $\pm$ $0.01.

## Expected Output and Verification
Running a guarded pricing routine with out-of-bound inputs:
```python
quote_pizza_safe(30, 2)  # Raises ValueError: Diameter 30" outside allowable menu range (6" to 24").
quote_pizza_safe(12, -1) # Raises ValueError: Topping count -1 outside allowable menu range (0 to 10).
quote_pizza_safe(12, 3)  # Returns $21.05
```

## Practical Exercises
1. Wrap `quote_pizza_safe` into a minimal FastAPI application with Swagger documentation (`/docs`).
2. Simulate concept drift: artificially inflate target prices by 15% and calculate how quickly the rolling MAE breaches the $0.85 alert threshold.
3. Implement a model registry pattern: save model metadata, training date, commit hash, and test MAE to a versioned JSON file (`model_v1.json`).

## Common Pitfalls and Debugging Strategies
- **Silent Failures:** Allowing invalid inputs (like negative toppings) to pass silently without validation creates bizarre pricing quotes that damage brand reputation.
- **Unversioned Model Deployments:** Overwriting production weights without tracking previous coefficients makes rollback impossible if a newly trained model misbehaves. Always version artifacts (`model_v1.0.pkl`, `model_v1.1.pkl`).
- **Ignoring Inference Latency:** Introducing complex external database lookups inside the hot inference loop can degrade response times from 5ms to 500ms.

## Best Practices and Industry Standards
- **Model Cards and Metadata:** Maintain a standardized Model Card documenting training data source, intended use cases, performance benchmarks (MAE = $0.58, R2 = 0.98), and known limitations.
- **Automated Rollback Safeguards:** If an automated retraining pipeline produces an $R^2 < 0.90$ or an MAE > $1.00, automatically abort deployment and retain the previous model version.
- **Privacy and Security:** Ensure pricing APIs do not log sensitive customer payment information alongside pricing telemetry.

## Real-World Business Context
In modern enterprise machine learning, model governance is a critical corporate asset. Whether operating a national restaurant franchise or an airline dynamic pricing engine, leadership requires absolute assurance that automated quoting algorithms adhere to brand guidelines, legal regulations against price discrimination, and strict profit margin controls. Establishing robust governance transforms an ML prototype into an enterprise-grade pricing engine.

## Summary and Key Takeaways
- Operational deployment requires moving beyond offline scripts to reliable APIs or edge runtimes.
- Defensive validation gates protect businesses from nonsensical or malicious inputs.
- Continuous monitoring of residuals and drift prevents silent model degradation.
- Model governance, versioning, and automated rollback ensure operational safety and compliance.

## Knowledge Check and Self-Assessment
1. Why must production ML APIs validate input ranges even when the underlying mathematical formula can accept any number?
2. What is the fundamental difference between data drift and concept drift in a pricing engine?
3. How does logging residuals for actual transactions allow engineering teams to detect when a model requires retraining?

## References and Further Reading
- Google Cloud Architecture Center: "Practices for MLOps and Machine Learning Pipelines"
- Sculley et al. (2015): "Hidden Technical Debt in Machine Learning Systems", NeurIPS
- Chip Huyen (2022): "Designing Machine Learning Systems", O'Reilly Media
