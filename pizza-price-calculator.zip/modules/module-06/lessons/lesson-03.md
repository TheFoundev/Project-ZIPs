# Lesson 03: Extending the Feature Space: Introducing Stuffed Crust

**Lesson ID:** lesson-03
**Module:** module-06
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain how categorical binary attributes are incorporated into multiple linear regression models
- Encode boolean menu options into binary dummy indicator variables (0 and 1)
- Interpret the mathematical and economic meaning of a binary indicator coefficient
- Update the pricing equation and `quote_pizza()` function signature to support feature extensions
- Evaluate how expanding the feature space impacts model fit, residual variance, and practical utility

## Prerequisites
- Completion of Lessons 01 and 02
- Understanding of multiple linear regression equations from Module 03
- Familiarity with pandas DataFrame column creation and boolean masks

## Concept Explanation

### The Need for Feature Extension
Our core Pizza Price Calculator models price as a function of two continuous numerical features:
$$\text{price} = \beta_0 + (\beta_{\text{size}} \times \text{diameter}) + (\beta_{\text{toppings}} \times \text{toppings})$$

While diameter and toppings explain 98% of overall price variation ($R^2 = 0.98$), actual restaurant menus frequently offer premium structural customizations that do not fit neatly into simple topping counts or diameter measurements. 

The most common premium customization in the pizza industry is **stuffed crust**—injecting mozzarella cheese or seasoned fillings directly into the outer crust perimeter. Because stuffed crust requires specialized dough preparation, additional cheese mass, and distinct labor steps, pizzerias charge a flat premium surcharge for this option.

How can our linear regression architecture incorporate such categorical choices?

### Binary Indicator (Dummy) Variables
Linear regression algorithms require all input features to be numerical numbers. They cannot directly perform matrix multiplication on text strings like `"yes"` or `"no"`.

To represent categorical choices, statisticians employ **binary indicator variables** (also called **dummy variables**):
$$\text{stuffed\_crust} = \begin{cases} 1 & \text{if the customer ordered stuffed crust} \\ 0 & \text{if the customer ordered regular/standard crust} \end{cases}$$

### Mathematical Formulation of the 3-Feature Model
Adding the `stuffed_crust` binary feature expands our feature matrix $X$ from 2 columns to 3 columns:
$$X = [\text{diameter\_inches}, \text{toppings}, \text{stuffed\_crust}]$$

The new linear regression pricing equation becomes:
$$\text{price} = \beta_0 + (\beta_1 \times \text{diameter}) + (\beta_2 \times \text{toppings}) + (\beta_3 \times \text{stuffed\_crust})$$

Let us analyze how this equation operates under both crust conditions:

1. **When `stuffed_crust = 0` (Regular Crust):**
   $$\text{price} = \beta_0 + (\beta_1 \times \text{diameter}) + (\beta_2 \times \text{toppings}) + (\beta_3 \times 0)$$
   $$\text{price} = \beta_0 + (\beta_1 \times \text{diameter}) + (\beta_2 \times \text{toppings})$$
   The equation collapses back to the standard base pricing formula.

2. **When `stuffed_crust = 1` (Stuffed Crust):**
   $$\text{price} = \beta_0 + (\beta_1 \times \text{diameter}) + (\beta_2 \times \text{toppings}) + (\beta_3 \times 1)$$
   $$\text{price} = (\beta_0 + \beta_3) + (\beta_1 \times \text{diameter}) + (\beta_2 \times \text{toppings})$$
   The entire regression plane shifts upward by exactly the constant value $\beta_3$.

### Economic Interpretation of $\beta_3$
The coefficient $\beta_3$ has a straightforward commercial meaning:
> **$\beta_3$ represents the flat premium surcharge for upgrading to a stuffed crust, holding diameter and topping count completely constant.**

If an ordinary least squares regression fitted on an expanded menu dataset reveals $\beta_3 = 2.75$, this proves the restaurant charges an average surcharge of $2.75 for the stuffed crust upgrade, regardless of whether the pizza is an 8-inch cheese or an 18-inch supreme.

## Relevant Code Pattern

```python
import pandas as pd
from sklearn.linear_model import LinearRegression

# Simulated expanded dataset including stuffed_crust binary column
data = [
    {"diameter_inches": 10, "toppings": 1, "stuffed_crust": 0, "price_usd": 15.50},
    {"diameter_inches": 10, "toppings": 1, "stuffed_crust": 1, "price_usd": 18.25},
    {"diameter_inches": 12, "toppings": 3, "stuffed_crust": 0, "price_usd": 21.00},
    {"diameter_inches": 12, "toppings": 3, "stuffed_crust": 1, "price_usd": 23.75},
    {"diameter_inches": 16, "toppings": 4, "stuffed_crust": 0, "price_usd": 26.50},
    {"diameter_inches": 16, "toppings": 4, "stuffed_crust": 1, "price_usd": 29.25},
]
df_ext = pd.DataFrame(data)

# 3-feature matrix and target
X_ext = df_ext[["diameter_inches", "toppings", "stuffed_crust"]]
y_ext = df_ext["price_usd"]

# Fit expanded regression model
model_ext = LinearRegression()
model_ext.fit(X_ext, y_ext)

# Inspect weights
print(f"Intercept:               ${model_ext.intercept_:.2f}")
print(f"Diameter Coefficient:    ${model_ext.coef_[0]:.2f}")
print(f"Topping Coefficient:     ${model_ext.coef_[1]:.2f}")
print(f"Stuffed Crust Surcharge: ${model_ext.coef_[2]:.2f}")
```

## Code Architecture and Walkthrough
1. **DataFrame Schema:** The new column `stuffed_crust` contains integer values `0` or `1`.
2. **Feature Matrix ($X$):** Passes a list of three feature names: `[["diameter_inches", "toppings", "stuffed_crust"]]`.
3. **Weight Vector (`coef_`):** Now contains 3 elements corresponding to the 3 features.
4. **Updated Signature:** We update the quoting function signature to accept a boolean or binary parameter:
   ```python
   def quote_pizza_ext(diameter_inches, toppings, stuffed_crust=False):
       flag = 1 if stuffed_crust else 0
       order = pd.DataFrame([[diameter_inches, toppings, flag]],
                            columns=["diameter_inches", "toppings", "stuffed_crust"])
       return float(model_ext.predict(order)[0])
   ```

## Worked Example
Suppose the fitted model yields:
- $\beta_0 = 4.00$ (base price)
- $\beta_1 = 0.95$ per diameter inch
- $\beta_2 = 1.80$ per topping
- $\beta_3 = 2.75$ for stuffed crust

Let us calculate quotes for two 12-inch, 3-topping pizzas:

**Case A: Regular Crust (`stuffed_crust = False`)**
$$\text{price} = 4.00 + (0.95 \times 12) + (1.80 \times 3) + (2.75 \times 0)$$
$$\text{price} = 4.00 + 11.40 + 5.40 + 0.00 = \$20.80$$

**Case B: Stuffed Crust (`stuffed_crust = True`)**
$$\text{price} = 4.00 + (0.95 \times 12) + (1.80 \times 3) + (2.75 \times 1)$$
$$\text{price} = 4.00 + 11.40 + 5.40 + 2.75 = \$23.55$$

The difference is exactly the $2.75 coefficient value. The client pays an intuitive, predictable upgrade fee.

## Step-by-Step Implementation Guide

### Step 1: Add the Binary Feature to the Dataset
Ensure boolean flags or categorical strings are mapped to integers:
```python
df["stuffed_crust"] = df["crust_type"].apply(lambda c: 1 if c == "stuffed" else 0)
```

### Step 2: Assemble the 3-Column Feature Matrix
```python
features = ["diameter_inches", "toppings", "stuffed_crust"]
X = df[features]
y = df["price_usd"]
```

### Step 3: Fit the Extended Estimator
```python
model = LinearRegression()
model.fit(X, y)
```

### Step 4: Implement Extended Quoting Wrapper
```python
def quote_extended(diameter, toppings, stuffed_crust=False):
    binary_val = 1 if stuffed_crust else 0
    order = pd.DataFrame([[diameter, toppings, binary_val]], columns=features)
    return float(model.predict(order)[0])
```

## Expected Output and Verification
```text
Intercept:               $4.00
Diameter Coefficient:    $0.95
Topping Coefficient:     $1.80
Stuffed Crust Surcharge: $2.75
Quote Regular: $20.80
Quote Stuffed: $23.55
Surcharge Difference: $2.75
```

## Practical Exercises
1. Add a second binary indicator `gluten_free_crust` (0 or 1). Train a 4-feature model and interpret both crust surcharges simultaneously.
2. What happens if a customer specifies both `stuffed_crust=True` and `gluten_free_crust=True`? Does the linear model assume additive pricing?
3. Create an interaction term `diameter_inches * stuffed_crust` to model the realistic business case where stuffed crust costs more on larger pizzas due to greater perimeter circumference ($\pi d$).

## Common Pitfalls and Debugging Strategies
- **The Dummy Variable Trap:** If you have two mutually exclusive categories (Regular vs. Stuffed), do NOT include both a `regular_crust` column and a `stuffed_crust` column alongside the intercept. Since $	ext{regular} + 	ext{stuffed} = 1$, the columns are perfectly collinear, causing matrix inversion failure in OLS. Always use $k - 1$ dummy columns for $k$ categories.
- **Passing Booleans Directly to Older Libraries:** While modern scikit-learn accepts boolean True/False, older numerical libraries expect integer `0` and `1`. Explicitly converting with `int(flag)` prevents type warnings.
- **Missing Feature Column Names:** Always construct inference DataFrames with the exact column list `["diameter_inches", "toppings", "stuffed_crust"]`.

## Best Practices and Industry Standards
- **Use Default Keyword Arguments:** Setting `stuffed_crust=False` in the function signature preserves backwards compatibility with existing client code that was written for the 2-parameter function.
- **Inspect Coefficient P-Values:** When expanding features in production, check statistical significance using statsmodels (`sm.OLS`) to verify that the surcharge coefficient is statistically distinguishable from zero.
- **Validate Realistic Combinations:** Ensure business logic prevents impossible combinations (e.g., thin-crust stuffed crust).

## Real-World Business Context
Modern fast-casual dining relies on modular "build-your-own" pricing engines. Whether ordering via mobile apps, third-party delivery aggregators, or in-store kiosks, customers expect transparent, itemized pricing. Extending regression models with binary indicator variables provides a mathematically disciplined method to quantify add-on surcharges while ensuring fair, consistent customer quotes.

## Summary and Key Takeaways
- Categorical options are integrated into linear models via binary dummy variables (0 and 1).
- The dummy coefficient represents the constant additive price shift associated with that option.
- Using $k - 1$ indicator columns for $k$ categories avoids the dummy variable trap.
- Default keyword arguments in API wrappers preserve backward compatibility while enabling feature evolution.

## Knowledge Check and Self-Assessment
1. Why must categorical variables be encoded as numbers before training a linear regression model?
2. What is the "dummy variable trap", and how is it avoided when encoding binary features?
3. If the coefficient for `gluten_free` is +$3.50, what does this indicate about the menu pricing strategy?

## References and Further Reading
- Scikit-Learn Guide: Preprocessing categorical features (`OneHotEncoder`)
- Wooldridge, J. M. (2019): "Introductory Econometrics: A Modern Approach", Chapter 7: Multiple Regression Analysis with Qualitative Information
- StatQuest with Josh Starmer: "Linear Regression with Categorical Predictors"
