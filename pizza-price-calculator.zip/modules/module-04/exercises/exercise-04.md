# Module 4 Exercises: Building and Testing the quote_pizza() Pricing Wrapper

## Exercise 4.1: Building the Core quote_pizza() Function (15 min)
**Objective:** Implement the `quote_pizza()` function wrapper and verify quotation accuracy against known benchmarks.
**Problem Statement:** You must implement the `quote_pizza(diameter_inches, toppings)` function from `main.py` and write automated verification checks.

**Requirements:**
1. Train `LinearRegression` on `pizza_menu.csv` using the 75/25 split with `random_state=42`.
2. Implement `quote_pizza(diameter_inches: float, toppings: int) -> float`.
3. Ensure the function packages inputs into a single-row DataFrame with columns `["diameter_inches", "toppings"]`.
4. Ensure the function extracts the scalar output and returns a native Python `float`.
5. Test `quote_pizza(12, 3)` and programmatically assert that the output rounds to `$21.05`.

**Constraints:** Follow lines 45-53 of `08_pizza_price/main.py`.

**Expected Behaviour:** Function returns float scalar ~$21.05 matching the reference benchmark.

**Acceptance Criteria:**
- [ ] Correctly constructs 1-row DataFrame with matched column names.
- [ ] Calls `model.predict()` and extracts scalar with `float(...[0])`.
- [ ] Asserts `round(quote_pizza(12, 3), 2) == 21.05`.
- [ ] Verified return type is native `float`.

**Hints:**
- Use `pd.DataFrame([{"diameter_inches": diameter_inches, "toppings": toppings}])`.
- Unrounded calculation is approximately `21.0471`.

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 4.2: Implementing Defensive Input Validation Guards (15 min)
**Objective:** Extend `quote_pizza()` with robust validation guards to reject invalid physical pizza configurations.
**Problem Statement:** Create an enhanced pricing function `quote_pizza_guarded(diameter_inches, toppings)` that enforces domain rules before running model inference.

**Requirements:**
1. Reject diameters less than 6.0 inches or greater than 24.0 inches with `ValueError`.
2. Reject non-integer toppings or toppings counts less than 0 or greater than 10 with `ValueError`.
3. Successfully quote valid inputs (e.g., 8-inch 1 topping, 16-inch 5 toppings).
4. Write test cases that verify exceptions are raised on:
   - `diameter_inches = -5`
   - `diameter_inches = 30`
   - `toppings = -1`
   - `toppings = 15`
   - `toppings = 2.5`

**Constraints:** Use Python `try...except` and `pytest.raises` or `unittest` style assertions.

**Expected Behaviour:** Clean validation handling that rejects invalid orders with descriptive error messages.

**Acceptance Criteria:**
- [ ] Validates diameter boundaries [6.0, 24.0].
- [ ] Validates topping integer constraints [0, 10].
- [ ] Verifies all 5 invalid test cases raise `ValueError`.
- [ ] Valid orders continue to return correct quotes.

**Hints:**
- Use `isinstance(toppings, int)` to check integer types.
- Check bounds before creating the DataFrame.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 4.3: Automated Menu Catalog Generation (15 min)
**Objective:** Generate and format a commercial menu price list using `itertuples()` and string padding.
**Problem Statement:** Implement the batch menu catalog generation logic from `main.py` and print a formatted price sheet.

**Requirements:**
1. Construct the 4-item menu catalog DataFrame:
   - Small: 8-inch, 1 topping
   - Medium: 12-inch, 3 toppings
   - Large: 16-inch, 5 toppings
   - Party: 18-inch, 5 toppings
2. Populate `menu['model_quote']` using a list comprehension over `menu.itertuples()`.
3. Print the formatted price list using fixed-width string formatting (`{row.order:35s} ${row.model_quote:.2f}`).
4. Verify prices: Small ($13.56), Medium ($21.05), Large ($28.53), Party ($30.46).

**Constraints:** Match lines 62-76 of `main.py`.

**Expected Behaviour:** Formatted console output displaying the four menu items and accurate dollar prices.

**Acceptance Criteria:**
- [ ] Constructs catalog DataFrame accurately.
- [ ] Uses list comprehension over `itertuples()`.
- [ ] Matches reference prices: $13.56, $21.05, $28.53, $30.46.
- [ ] Formats output with 35-character padding and 2 decimal places.

**Hints:**
- Named tuple attributes are accessed with dot notation: `row.diameter`, `row.toppings`.
- String padding: `f"  {row.order:35s} ${row.model_quote:.2f}"`.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 4.4: Benchmarking itertuples vs iterrows vs Vectorization (15 min)
**Objective:** Quantify the execution performance difference between `itertuples()`, `iterrows()`, and vectorized prediction.
**Problem Statement:** In large restaurant chains with thousands of daily orders, quotation latency matters. You must benchmark different batch prediction techniques.

**Requirements:**
1. Generate a synthetic DataFrame of 1,000 random pizza orders (diameters 8–18 in, toppings 0–5).
2. Measure execution time for batch quotation using:
   - Approach A: `[quote_pizza(row.diameter, row.toppings) for row in df.iterrows()]`
   - Approach B: `[quote_pizza(row.diameter, row.toppings) for row in df.itertuples()]`
   - Approach C: Direct batch inference `model.predict(df[['diameter_inches', 'toppings']])`
3. Print the elapsed time in milliseconds for all three approaches.
4. Document why Approach C (batch vectorization) is fastest and why Approach B is preferred when individual functional validation is required.

**Constraints:** Use Python's `time` or `timeit` module.

**Expected Behaviour:** Benchmarking script printing execution timings across 1,000 samples.

**Acceptance Criteria:**
- [ ] Generates 1,000 sample test orders.
- [ ] Measures runtime across all three approaches.
- [ ] Confirms `itertuples()` is significantly faster than `iterrows()`.
- [ ] Confirms batch `model.predict()` is orders of magnitude faster than row-wise loops.

**Hints:**
- `iterrows()` incurs the overhead of creating 1,000 `pd.Series` objects.
- `itertuples()` yields lightweight C-based namedtuples.

**Difficulty:** Advanced
**Estimated Completion Time:** 15 minutes
