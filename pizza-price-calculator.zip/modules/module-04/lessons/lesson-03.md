# Lesson 03: The Model-as-an-API Architecture and Error Handling

**Lesson ID:** lesson-03
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain the software architectural principles behind the "Model-as-an-API" pattern
- Identify the boundary between data science experimentation and production engineering
- Implement robust input validation guards for domain-specific pricing constraints
- Formulate standardized error responses for out-of-bounds orders
- Design modular prediction services ready for cloud microservice deployment

## Prerequisites
- Completion of Lessons 01 and 02
- Basic understanding of API client-server communication concepts

## Concept Explanation

### What is the Model-as-an-API Pattern?
In contemporary enterprise architecture, machine learning models are rarely deployed as monolithic scripts that run once and exit. Instead, models are packaged as **stateless prediction microservices** accessible via Application Programming Interfaces (APIs).

The **Model-as-an-API** pattern decouples the machine learning engine from customer-facing user interfaces:
- The **Client** (e.g., a cashier POS touchscreen, a mobile ordering app, or a website) does not need Python, pandas, or scikit-learn.
- The Client simply sends a structured request: `{"diameter_inches": 12.0, "toppings": 3}`.
- The **API Service** executes the `quote_pizza()` logic and returns a structured response: `{"quote_usd": 21.05}`.

```mermaid
sequenceDiagram
    autonumber
    actor Customer as Mobile App / POS Terminal
    participant API as quote_pizza() API Service
    participant Validator as Input Validator
    participant Model as Linear Regression Engine

    Customer->>API: Request Quote (diameter=12, toppings=3)
    API->>Validator: Validate Inputs (12 > 0, 3 >= 0)
    Validator-->>API: Validated OK
    API->>Model: predict(order_df)
    Model-->>API: array([21.0471...])
    API-->>Customer: Return Quote ($21.05)
```

### The Necessity of Defensive Input Validation
Linear regression models are unconstrained mathematical hyperplanes. If a user queries the model with impossible inputs, the equation will happily compute an absurd result:
- If a user passes a negative diameter: `quote_pizza(-10, 0)` -> $4.02 + 0.97(-10) = -\$5.68$ (The restaurant pays the customer to take a negative-sized pizza!)
- If a user passes 50 toppings: `quote_pizza(12, 50)` -> $4.02 + 0.97(12) + 1.81(50) = \$106.16$ (Physically impossible to fit 50 toppings on one pizza crust!)

In production systems, the wrapper function must enforce **domain validation guards**:
1. **Physical Size Boundaries:** Reject diameters below a minimum personal size (e.g., $d < 6$ in) or above maximum oven dimensions (e.g., $d > 24$ in).
2. **Ingredient Limits:** Reject negative topping counts ($t < 0$) or quantities exceeding kitchen capacity (e.g., $t > 10$).
3. **Type Safety:** Ensure toppings is an integer, rejecting fractional toppings like $2.5$ toppings.

### Error Handling Architecture
When an order violates physical constraints, the pricing service should raise descriptive exceptions or return standardized error payloads rather than executing invalid mathematical inference:
```python
def quote_pizza_safe(diameter_inches: float, toppings: int) -> float:
    if diameter_inches < 6.0 or diameter_inches > 24.0:
        raise ValueError(f"Diameter {diameter_inches} out of bounds (must be 6 to 24 inches).")
    if not isinstance(toppings, int) or toppings < 0 or toppings > 10:
        raise ValueError(f"Toppings count {toppings} invalid (must be an integer 0 to 10).")
    
    order = pd.DataFrame([{"diameter_inches": float(diameter_inches), "toppings": int(toppings)}])
    return float(model.predict(order)[0])
```

## Relevant Code (from main.py, lines 45-53)
```python
    def quote_pizza(diameter_inches: float, toppings: int) -> float:
        """Return the model's price estimate for one pizza."""
        order = pd.DataFrame(
            [{"diameter_inches": diameter_inches, "toppings": toppings}]
        )
        return float(model.predict(order)[0])

    example = quote_pizza(12, 3)
```

## Code Architecture and Walkthrough
- `main.py` presents the clean reference implementation of the wrapper pattern.
- In line 52, `example = quote_pizza(12, 3)` serves as an integration test verifying that the API endpoint produces valid quotations for standard commercial orders.
- The clean separation between training lines (36-44) and inference lines (45-53) establishes the foundation for modular deployment.

## Worked Example
Let us test how an enhanced, production-ready `quote_pizza` handles both valid orders and invalid client requests:
```python
import pandas as pd
from sklearn.linear_model import LinearRegression

# Setup minimal fitted model
model = LinearRegression()
X = pd.DataFrame({"diameter_inches": [8.0, 16.0], "toppings": [0, 5]})
y = pd.Series([11.78, 28.53])
model.fit(X, y)

def quote_pizza_validated(diameter_inches: float, toppings: int) -> float:
    """Production pricing API with validation guards."""
    if diameter_inches < 6.0:
        raise ValueError(f"Diameter {diameter_inches}in is below minimum personal size (6.0in).")
    if toppings < 0:
        raise ValueError(f"Topping count {toppings} cannot be negative.")
    
    order = pd.DataFrame([{"diameter_inches": float(diameter_inches), "toppings": int(toppings)}])
    return float(model.predict(order)[0])

# Valid request
print(f"Valid 12in, 3 toppings: ${quote_pizza_validated(12, 3):.2f}")

# Invalid request handling
try:
    quote_pizza_validated(-5, 2)
except ValueError as err:
    print(f"Caught expected error: {err}")
```
Output:
```
Valid 12in, 3 toppings: $20.15
Caught expected error: Diameter -5in is below minimum personal size (6.0in).
```

## Step-by-Step Implementation Guide
1. Identify valid operational domains for the business problem (e.g., diameter between 6 and 24 inches, toppings between 0 and 10).
2. Add conditional validation checks at the beginning of `quote_pizza()`.
3. Raise descriptive `ValueError` exceptions when inputs violate domain rules.
4. Convert validated inputs into a single-row DataFrame.
5. Invoke `model.predict()` and extract the scalar float.
6. Test edge cases: personal minimum (6 in), party maximum (24 in), and zero toppings.

## Expected Output and Verification
Validating orders before prediction prevents erroneous negative prices, eliminates extrapolation crashes, and ensures strict adherence to restaurant business rules.

## Practical Exercises
- **Exercise 3.1:** What price does the unvalidated model quote for a 0-inch pizza with 0 toppings? Explain why this equals the intercept ($4.02).
- **Exercise 3.2:** Write a decorator `@log_quote` that prints the input parameters, execution time in milliseconds, and the returned dollar price every time `quote_pizza` is invoked.
- **Exercise 3.3:** How would you modify `quote_pizza` to return a dictionary `{"quote": 21.05, "currency": "USD", "status": "success"}` suitable for a JSON web API?

## Common Pitfalls and Debugging Strategies
| Pitfall | Root Cause | Debugging Strategy |
|---|---|---|
| Silent mathematical extrapolation | Allowing unconstrained linear models to evaluate extreme inputs | Enforce minimum and maximum input validation guards. |
| Catching exceptions too broadly | Using bare `except:` blocks that mask syntax bugs | Catch specific exceptions like `ValueError` or `TypeError`. |
| Modifying global state inside functions | Re-fitting the model inside `quote_pizza` | Treat fitted models as immutable read-only objects during inference. |

## Best Practices and Industry Standards
- **Validate Before Inference:** Always validate input bounds before invoking machine learning inference engines.
- **Stateless Inference:** Design prediction services to be completely stateless; the output should depend strictly on the current input, not on prior queries.
- **Provide Actionable Error Messages:** Ensure error messages clearly state what input violated which constraint (e.g., "Diameter must be between 6 and 24 inches").

## Real-World Business Context
In production cloud environments (such as Kubernetes microservice clusters), pricing APIs must process thousands of requests per second from diverse client applications. Implementing defensive validation guards directly inside the model wrapper prevents corrupt requests from propagating through point-of-sale systems or billing databases.

## Summary and Key Takeaways
- The Model-as-an-API pattern decouples model training from client application consumption.
- Linear regression models require input validation guards to prevent nonsensical mathematical extrapolations.
- Defensive programming guarantees that invalid inputs are caught early and reported with clear, actionable error messages.
- Clean model wrappers form the architectural foundation for scalable microservices and serverless deployment.

## Knowledge Check and Self-Assessment
1. What does the Model-as-an-API architecture decouple in software engineering?
2. What undesirable output occurs if an unconstrained linear model receives a negative diameter?
3. Name two domain-specific validation checks that should be applied to pizza pricing inputs.
4. Why should a trained model object be treated as immutable during the inference lifecycle?

## References and Further Reading
- Building Machine Learning Powered Applications (Emmanuel Ameisen), Chapter 7: Deploying Models
- Designing Data-Intensive Applications (Martin Kleppmann), Chapter 4: Encoding and Evolution
- Python Exception Handling Guide: https://docs.python.org/3/tutorial/errors.html
