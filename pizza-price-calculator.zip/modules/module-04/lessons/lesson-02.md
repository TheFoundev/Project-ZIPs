# Lesson 02: Packaging Single-Item Orders for model.predict()

**Lesson ID:** lesson-02
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why scikit-learn estimators reject loose scalar inputs during `model.predict()`
- Construct a single-row pandas DataFrame using dictionary literals
- Explain why matching feature column names prevents `UserWarning: X does not have valid feature names`
- Extract single scalar predictions from 1D NumPy output arrays
- Implement input validation guards to prevent nonsensical pricing predictions

## Prerequisites
- Completion of Lesson 01
- Understanding of pandas DataFrame creation from dictionaries

## Concept Explanation

### The Dimensional Contract of `predict()`
When a user wants to quote a single pizza, they provide two individual numbers: `diameter = 12` and `toppings = 3`. However, passing these directly to scikit-learn:
```python
model.predict(12, 3)  # TypeError: predict() takes 2 positional arguments but 3 were given
model.predict([12, 3])  # ValueError: Expected 2D array, got 1D array instead
```
Scikit-learn's `.predict()` method expects a **2-dimensional collection of samples**, where:
- Axis 0 represents the samples (even if there is only 1 sample).
- Axis 1 represents the features (must exactly match the number and order of features used during training).

```mermaid
flowchart TD
    A["Raw User Inputs: diameter=12, toppings=3"] --> B["Dict: [{'diameter_inches': 12, 'toppings': 3}]"]
    B --> C["pd.DataFrame(..., shape=(1, 2))"]
    C --> D["model.predict(order)"]
    D --> E["Returns: np.ndarray([21.0471...]), shape=(1,)"]
    E --> F["Array Indexing: [0]"]
    F --> G["float(...) -> 21.0471..."]
```

### The Feature Name Matching Requirement
In older versions of scikit-learn, users frequently passed raw nested lists:
```python
model.predict([[12, 3]])
```
While this satisfies the 2D requirement (shape `(1, 2)`), it introduces severe risks:
1. **Positional Fragility:** If the developer forgets whether diameter or toppings comes first, passing `[[3, 12]]` silently produces an incorrect prediction.
2. **Feature Name Warnings:** When a model is fitted on a pandas DataFrame with named columns (`['diameter_inches', 'toppings']`), calling `predict()` with an unlabelled NumPy array triggers a warning:
   ```
   UserWarning: X does not have valid feature names, but LinearRegression was fitted with feature names
   ```

To avoid warnings and guarantee positional correctness, `quote_pizza()` builds a single-row DataFrame with explicit column labels:
```python
order = pd.DataFrame([{"diameter_inches": diameter_inches, "toppings": toppings}])
```
By passing a list of a single dictionary, pandas constructs a DataFrame with shape `(1, 2)` whose column labels match the training matrix exactly.

### Unpacking the Prediction Array
The output of `model.predict(order)` is not a float—it is a 1-dimensional NumPy array:
```python
pred = model.predict(order)
print(type(pred))   # <class 'numpy.ndarray'>
print(pred.shape)   # (1,)
print(pred)         # [21.04714457]
```
To return a clean scalar price:
1. `pred[0]` indexes into the first (and only) sample.
2. `float(...)` casts the `numpy.float64` to a standard Python `float`.

## Relevant Code (from main.py, lines 47-50)
```python
        order = pd.DataFrame(
            [{"diameter_inches": diameter_inches, "toppings": toppings}]
        )
        return float(model.predict(order)[0])
```

## Code Architecture and Walkthrough
- **Lines 47-49:** Constructs a single-row DataFrame using a list of one dictionary. The keys `"diameter_inches"` and `"toppings"` match the feature matrix $X$ extracted on line 29.
- **Line 50:** Chains three operations seamlessly:
  1. `model.predict(order)` runs inference.
  2. `[0]` extracts the first prediction from the returned array.
  3. `float(...)` converts the scalar to a native Python float.

## Worked Example
Let us inspect the intermediate objects created inside `quote_pizza`:
```python
import pandas as pd
from sklearn.linear_model import LinearRegression

# Recreate fitted model
X_train = pd.DataFrame({"diameter_inches": [10.0, 14.0], "toppings": [1, 3]})
y_train = pd.Series([15.00, 23.00])
model = LinearRegression().fit(X_train, y_train)

# Inside quote_pizza(12, 3)
diameter_inches = 12
toppings = 3

order = pd.DataFrame([{"diameter_inches": diameter_inches, "toppings": toppings}])
print("Constructed order DataFrame:")
print(order)
print(f"order shape: {order.shape}")
print(f"order columns: {list(order.columns)}")

raw_pred = model.predict(order)
print(f"
Raw model.predict output: {raw_pred} (type: {type(raw_pred).__name__})")

scalar_pred = float(raw_pred[0])
print(f"Extracted scalar: {scalar_pred:.2f} (type: {type(scalar_pred).__name__})")
```
Output:
```
Constructed order DataFrame:
   diameter_inches  toppings
0               12         3
order shape: (1, 2)
order columns: ['diameter_inches', 'toppings']

Raw model.predict output: [21.] (type: ndarray)
Extracted scalar: 21.00 (type: float)
```

## Step-by-Step Implementation Guide
1. Create a dictionary mapping feature names to argument values: `{'diameter_inches': diameter_inches, 'toppings': toppings}`.
2. Wrap the dictionary in a Python list: `[{...}]`.
3. Pass the list to `pd.DataFrame([{...}])`.
4. Inspect `order.shape` to confirm it is `(1, 2)`.
5. Call `model.predict(order)`.
6. Extract index 0: `pred[0]`.
7. Cast to float: `float(pred[0])`.
8. Return the float.

## Expected Output and Verification
When executed on the project model:
- `order.shape` is always `(1, 2)`.
- Scikit-learn evaluates inference without issuing any `UserWarning`.
- The return value is a pure Python `float` ready for currency formatting.

## Practical Exercises
- **Exercise 2.1:** What happens if you misspell a column name, such as `{"diameter": 12, "toppings": 3}`? What error does scikit-learn raise?
- **Exercise 2.2:** Add input validation to `quote_pizza` that raises a `ValueError` if `diameter_inches <= 0` or `toppings < 0`.
- **Exercise 2.3:** Compare the memory overhead of creating a 1-row DataFrame versus a 2D NumPy array with `np.array([[diameter, toppings]])`. Why is the DataFrame approach preferred for safety despite minor overhead?

## Common Pitfalls and Debugging Strategies
| Pitfall | Root Cause | Debugging Strategy |
|---|---|---|
| `ValueError: The feature names should match` | Column name typo in `order` dictionary | Copy column names directly from `X_train.columns` to ensure exact spelling. |
| `TypeError: 'float' object is not subscriptable` | Adding `[0]` to an already unpacked scalar | Ensure `[0]` is applied to the output of `model.predict()`, not a float. |
| Scikit-learn feature name warning | Passing raw `[[12, 3]]` array without feature names | Always pass a DataFrame with named columns when the estimator was fitted on named columns. |

## Best Practices and Industry Standards
- **Mirror Training Column Names:** Always construct inference DataFrames with column names that match `model.feature_names_in_`.
- **Enforce Defensive Typing:** Cast model outputs to standard Python primitives before passing them to web frameworks or serialization libraries.
- **Fail Fast on Invalid Domains:** Implement boundary validation to reject nonsensical orders (e.g., negative toppings) before running model inference.

## Real-World Business Context
In production e-commerce backends, pricing requests arrive as JSON payloads from mobile apps: `{"diameter": 12.0, "toppings": 3}`. The backend service validates the JSON schema, maps incoming keys into the model's feature contract, and returns a verified dollar quote. Mismatched feature names in production can lead to severe financial discrepancies or customer-facing errors.

## Summary and Key Takeaways
- Scikit-learn requires 2D tabular inputs of shape `(1, n_features)` even for single-sample inference.
- Packaging inputs into a single-row pandas DataFrame preserves feature names and suppresses scikit-learn warnings.
- The `float(model.predict(order)[0])` pattern extracts the scalar prediction from the returned 1D NumPy array.
- This approach guarantees both positional safety and framework independence for downstream applications.

## Knowledge Check and Self-Assessment
1. Why does `model.predict([12, 3])` fail with a `ValueError`?
2. Why is passing a DataFrame preferable to passing a raw 2D list `[[12, 3]]` in modern scikit-learn?
3. What is the shape of the DataFrame created inside `quote_pizza()`?
4. What are the two transformations applied to the output of `model.predict(order)` before returning?

## References and Further Reading
- Scikit-learn Feature Names in Inference: https://scikit-learn.org/stable/whats_new/v1.0.html
- Pandas DataFrame from Dictionaries: https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.from_dict.html
- Robust Python (Patrick Viafore), Chapter 4: Type Annotations and Contracts
