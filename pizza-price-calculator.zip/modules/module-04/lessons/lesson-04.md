# Lesson 04: Automated Menu Catalog Generation with Pandas Itertuples

**Lesson ID:** lesson-04
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Construct multi-item catalog DataFrames representing standard restaurant menu tiers
- Apply the `quote_pizza()` wrapper across batch menu records using list comprehensions and `itertuples`
- Explain why `itertuples()` is significantly faster and more memory-efficient than `iterrows()`
- Format and display professional price lists aligned with commercial standards
- Automate catalog generation to synchronize digital menus with underlying pricing models

## Prerequisites
- Completion of Lessons 01, 02, and 03
- Understanding of Python list comprehensions and tuple iteration

## Concept Explanation

### The Need for Batch Catalog Generation
While individual customers query the pricing engine for custom single-pizza orders, restaurant managers also need to publish standard menu tiers for printed menus, digital boards, and promotional flyers:
- **Small:** 8-inch, 1 topping
- **Medium:** 12-inch, 3 toppings
- **Large:** 16-inch, 5 toppings
- **Party:** 18-inch, 5 toppings

Manually computing prices for dozens of menu configurations in a spreadsheet is tedious and prone to calculation errors. With our reusable `quote_pizza()` function, we can automate batch catalog pricing across any arbitrary list of offerings in milliseconds.

```mermaid
flowchart TD
    A["Menu Tier Specifications"] --> B["Small (8 in, 1 top)"]
    A --> C["Medium (12 in, 3 top)"]
    A --> D["Large (16 in, 5 top)"]
    A --> E["Party (18 in, 5 top)"]
    B --> F["menu.itertuples()"]
    C --> F
    D --> F
    E --> F
    F --> G["quote_pizza(row.diameter, row.toppings)"]
    G --> H["Automated Price Column: menu['model_quote']"]
    H --> I["Formatted Menu Price List"]
```

### Iteration Strategies in Pandas: `itertuples` vs `iterrows`
When applying a function row-by-row across a pandas DataFrame, Python developers have several techniques:
1. **`df.iterrows()`:** Yields each row as a `(index, pd.Series)` tuple. Because pandas must construct a new `pd.Series` object for every single row, `iterrows()` is notoriously slow and incurs heavy memory overhead.
2. **`df.itertuples()`:** Yields each row as an efficient lightweight named tuple. It avoids Series instantiation, making it roughly **10x to 50x faster** than `iterrows()`. Named attributes (e.g., `row.diameter`, `row.toppings`) allow clean, readable code.
3. **List Comprehension over `itertuples()`:**
   ```python
   menu["model_quote"] = [
       quote_pizza(row.diameter, row.toppings) for row in menu.itertuples()
   ]
   ```
   This Pythonic syntax iterates cleanly over the catalog DataFrame and assigns the resulting list of quotes directly back as a new column.

### Formatting Commercial Menu Lists
Raw floating-point numbers (`13.5597`, `21.0471`) must be formatted cleanly for human consumption:
- Use string formatting `:35s` to left-align order descriptions to a fixed width of 35 characters.
- Use currency formatting `:${row.model_quote:.2f}` to format values with two decimal digits.

## Relevant Code (from main.py, lines 62-76)
```python
    menu = pd.DataFrame(
        [
            {"order": "Small, 8-inch, 1 topping", "diameter": 8, "toppings": 1},
            {"order": "Medium, 12-inch, 3 toppings", "diameter": 12, "toppings": 3},
            {"order": "Large, 16-inch, 5 toppings", "diameter": 16, "toppings": 5},
            {"order": "Party, 18-inch, 5 toppings", "diameter": 18, "toppings": 5},
        ]
    )
    menu["model_quote"] = [
        quote_pizza(row.diameter, row.toppings) for row in menu.itertuples()
    ]
    print("
Price list from the model:")
    for row in menu.itertuples():
        print(f"  {row.order:35s} ${row.model_quote:.2f}")
```

## Code Architecture and Walkthrough
- **Lines 62-69:** Defines the catalog specification as a list of four dictionaries and wraps it into `menu = pd.DataFrame(...)`.
- **Lines 70-72:** Uses a list comprehension over `menu.itertuples()` to compute model quotes for all rows simultaneously, creating the `menu["model_quote"]` column.
- **Lines 73-76:** Iterates over the updated menu DataFrame with `itertuples()`, printing each item with clean fixed-width column alignment.

## Worked Example
Let us trace the execution of the batch catalog generator:
1. Catalog rows defined:
   - Row 0: `order = 'Small, 8-inch, 1 topping'`, `diameter = 8`, `toppings = 1`
   - Row 1: `order = 'Medium, 12-inch, 3 toppings'`, `diameter = 12`, `toppings = 3`
   - Row 2: `order = 'Large, 16-inch, 5 toppings'`, `diameter = 16`, `toppings = 5`
   - Row 3: `order = 'Party, 18-inch, 5 toppings'`, `diameter = 18`, `toppings = 5`
2. Quotations calculated:
   - Small: $4.0224 + 0.9656(8) + 1.8125(1) = 13.5597 \rightarrow \$13.56$
   - Medium: $4.0224 + 0.9656(12) + 1.8125(3) = 21.0471 \rightarrow \$21.05$
   - Large: $4.0224 + 0.9656(16) + 1.8125(5) = 28.5345 \rightarrow \$28.53$
   - Party: $4.0224 + 0.9656(18) + 1.8125(5) = 30.4657 \rightarrow \$30.46$
3. Formatted print loop executes:
   ```
   Price list from the model:
     Small, 8-inch, 1 topping            $13.56
     Medium, 12-inch, 3 toppings         $21.05
     Large, 16-inch, 5 toppings          $28.53
     Party, 18-inch, 5 toppings          $30.46
   ```

## Step-by-Step Implementation Guide
1. Create a catalog DataFrame specifying standard menu offerings.
2. Use list comprehension over `catalog.itertuples()` calling `quote_pizza(row.diameter, row.toppings)`.
3. Assign the resulting quotes to a new column `catalog['model_quote']`.
4. Iterate over `catalog.itertuples()`.
5. Use f-strings with width specifier `{row.order:35s}` and currency specifier `${row.model_quote:.2f}`.
6. Verify output alignment in the console.

## Expected Output and Verification
The printed price list produces an aesthetically aligned, professional menu schedule:
```
Price list from the model:
  Small, 8-inch, 1 topping            $13.56
  Medium, 12-inch, 3 toppings         $21.05
  Large, 16-inch, 5 toppings          $28.53
  Party, 18-inch, 5 toppings          $30.46
```
The consistent spacing and 2-decimal rounding demonstrate that the automated pricing pipeline is ready for production deployment.

## Practical Exercises
- **Exercise 4.1:** Add an "Extra Large, 16-inch, 2 toppings" item to the catalog DataFrame. What price does the model generate?
- **Exercise 4.2:** Benchmark execution speed: compare generating quotes for 1,000 simulated orders using `itertuples()` versus `iterrows()`.
- **Exercise 4.3:** Export the generated catalog DataFrame to a CSV file using `menu.to_csv("menu_catalog.csv", index=False)`.

## Common Pitfalls and Debugging Strategies
| Pitfall | Root Cause | Debugging Strategy |
|---|---|---|
| Misaligned console output | Inconsistent string lengths without fixed width formatting | Use fixed width specifiers like `{row.order:35s}`. |
| Inefficient `iterrows()` usage | Using `iterrows()` on large catalogs | Use `itertuples()` or vectorized operations for row-wise iteration. |
| Column name collision in namedtuples | Column names with spaces or symbols in `itertuples()` | Use clean snake_case column names (`diameter`, `toppings`) for clean attribute access. |

## Best Practices and Industry Standards
- **Prefer `itertuples` Over `iterrows`:** When row-wise looping is required in pandas, always prefer `itertuples()` for superior execution speed and lower memory usage.
- **Maintain Clean Output Formatting:** Format monetary values with two decimal digits (`:.2f`) and use column padding to guarantee readable reports.
- **Automate Catalog Synchronization:** Regenerate published menus automatically whenever the underlying model is retrained, ensuring prices never drift from model weights.

## Real-World Business Context
In multi-unit franchise management, corporate pricing directors update master menu price lists every quarter. By automating catalog generation with pandas and machine learning wrappers, franchises can publish localized price sheets across hundreds of store locations in seconds, completely replacing error-prone manual spreadsheet maintenance.

## Summary and Key Takeaways
- Batch menu catalog generation applies the trained pricing function across standard menu configurations.
- `df.itertuples()` delivers fast, lightweight named tuple iteration that is significantly faster than `iterrows()`.
- List comprehensions provide clean, expressive syntax for populating new DataFrame columns with model quotes.
- Fixed-width string formatting produces professional, aligned price lists suitable for commercial use.

## Knowledge Check and Self-Assessment
1. Why is `itertuples()` preferred over `iterrows()` when iterating across pandas DataFrames?
2. What are the four standard menu items evaluated in `main.py`?
3. What is the model quote for the "Large, 16-inch, 5 toppings" pizza?
4. What string formatting syntax is used to left-align order descriptions to 35 characters?

## References and Further Reading
- Pandas itertuples Documentation: https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.itertuples.html
- Python String Formatting Syntax: https://docs.python.org/3/library/string.html#format-specification-mini-language
- High-Performance Pandas Techniques: https://realpython.com/fast-flexible-pandas/
