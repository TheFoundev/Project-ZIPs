# Lesson 01: From Scikit-Learn Model to Reusable Software Function

**Lesson ID:** lesson-01
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why raw machine learning models must be wrapped in software functions for practical deployment
- Identify the interface requirements of consumer-facing pricing systems
- Describe how Python closures encapsulate fitted model objects without global state
- Contrast raw array-based prediction calls with domain-specific function signatures
- Articulate the software engineering principles behind the Model Wrapper pattern

## Prerequisites
- Completion of Module 03
- Understanding of Python functions, parameters, and variable scope

## Concept Explanation

### The Usability Gap in Raw ML Models
After executing `model.fit(X_train, y_train)`, we possess a trained `LinearRegression` instance in memory. However, consider how a non-technical software engineer building a mobile app or POS cash register would interact with this raw estimator.

To get a quote for a 12-inch pizza with 3 toppings using the raw scikit-learn API, the developer would need to:
1. Know the internal ordering of the model's feature columns (`diameter_inches` first, then `toppings`).
2. Construct a 2-dimensional array or DataFrame with exact column names.
3. Call `model.predict(...)`.
4. Index into the returned NumPy array `[0]`.
5. Cast the resulting `np.float64` to a standard Python `float`.

```mermaid
flowchart LR
    A["Caller: Cashier POS / Mobile App"] --> B["quote_pizza(12, 3)"]
    subgraph "Model Wrapper Function"
      B --> C["Package: pd.DataFrame(...)"]
      C --> D["model.predict(...)"]
      D --> E["Extract Scalar & Cast: float(...[0])"]
    end
    E --> F["Return: 21.05 (clean float)"]
```

Requiring client applications to manage scikit-learn data containers directly is error-prone:
- If the developer passes `[3, 12]` instead of `[12, 3]`, the model quotes a 3-inch pizza with 12 toppings, producing an absurdly incorrect price without raising any syntax error!
- If scikit-learn updates its internal validation warnings, client applications will be littered with framework-specific warnings.

### Encapsulation via the Model Wrapper Pattern
The solution is **encapsulation**: wrapping the raw model inside a clean, intuitive, domain-specific Python function:
```python
def quote_pizza(diameter_inches: float, toppings: int) -> float:
    """Return the model's price estimate for one pizza."""
    ...
```
This wrapper establishes a clean **contract**:
- The caller provides standard Python primitives (`diameter_inches: float`, `toppings: int`).
- The wrapper handles all scikit-learn data transformation and inference mechanics.
- The wrapper returns a clean, native Python `float` representing the dollar quote.

### Closures in Python
In `main.py`, `quote_pizza` is defined **inside** the `main()` function immediately after `model.fit()`:
```python
    model = LinearRegression()
    model.fit(X_train, y_train)
    ...
    def quote_pizza(diameter_inches: float, toppings: int) -> float:
        order = pd.DataFrame([{"diameter_inches": diameter_inches, "toppings": toppings}])
        return float(model.predict(order)[0])
```
Because `quote_pizza` is defined within the local scope of `main()`, it forms a **closure** over the local variable `model`. It captures a direct reference to the trained estimator without polluting the global module namespace, ensuring clean, self-contained execution.

## Relevant Code (from main.py, lines 45-53)
```python
    def quote_pizza(diameter_inches: float, toppings: int) -> float:
        """Return the model's price estimate for one pizza."""
        order = pd.DataFrame(
            [{"diameter_inches": diameter_inches, "toppings": toppings}]
        )
        return float(model.predict(order)[0])

    example = quote_pizza(12, 3)
```

## Code Architecture and Walkthrough
- **Line 45:** Function signature with clear PEP 484 type annotations: `(diameter_inches: float, toppings: int) -> float`.
- **Line 46:** Clear docstring documenting the functional behavior.
- **Lines 47-49:** Ingestion and conversion into a compliant DataFrame.
- **Line 50:** Invocation of `predict()`, array slicing `[0]`, and casting via `float()`.
- **Line 52:** Clean invocation: `example = quote_pizza(12, 3)`. The caller does not need to know that scikit-learn, NumPy, or pandas even exist!

## Worked Example
Let us trace what occurs during the function call `quote_pizza(12, 3)`:
1. Arguments received: `diameter_inches = 12`, `toppings = 3`.
2. Dictionary created: `{"diameter_inches": 12, "toppings": 3}`.
3. List of dictionaries wrapped in DataFrame:
   ```
      diameter_inches  toppings
   0               12         3
   ```
4. `model.predict(order)` evaluates OLS matrix multiplication:
   $$\hat{y} = 4.0224 + 0.9656(12) + 1.8125(3) = 21.0471$$
   Returns: `array([21.04714457])`.
5. `[0]` extracts the first element: `21.04714457`.
6. `float(...)` converts NumPy float to native Python float: `21.04714457`.
7. Client receives the result, formatting it as `f"${example:.2f}"` -> `"$21.05"`.

## Step-by-Step Implementation Guide
1. Train `LinearRegression` on training data.
2. Define `quote_pizza(diameter_inches: float, toppings: int) -> float`.
3. Add a docstring describing the return value.
4. Convert inputs into a 1-row DataFrame with exact training column names.
5. Invoke `model.predict(order)`.
6. Extract scalar element 0 and cast with `float()`.
7. Return the computed scalar.
8. Test the function on standard input `quote_pizza(12, 3)` and verify output ~$21.05.

## Expected Output and Verification
Calling `example = quote_pizza(12, 3)` and printing `print(f"${example:.2f}")` outputs:
```
Quote for a 12-inch pizza with 3 toppings: $21.05
```
This confirms that the wrapper function cleanly handles all intermediate array manipulation and delivers an exact, production-ready dollar price.

## Practical Exercises
- **Exercise 1.1:** Call `quote_pizza(14, 0)` to quote a 14-inch plain cheese pizza. What is the returned price?
- **Exercise 1.2:** What happens if a user passes float toppings like `quote_pizza(12, 2.5)`? How could you enforce integer type constraints?
- **Exercise 1.3:** Explain how wrapping models inside functions simplifies the process of creating unit tests with pytest.

## Common Pitfalls and Debugging Strategies
| Pitfall | Root Cause | Debugging Strategy |
|---|---|---|
| Inverted argument values | Calling `quote_pizza(3, 12)` by accident | Use explicit keyword arguments: `quote_pizza(diameter_inches=12, toppings=3)`. |
| Unbound model variable | Defining `quote_pizza` outside the scope where `model` is fitted | Define `quote_pizza` inside `main()` after `model.fit()`, or pass `model` as an argument. |
| Returning raw NumPy array | Forgetting `[0]` or `float()` conversion | Always extract the scalar element `float(pred[0])` before returning from public API functions. |

## Best Practices and Industry Standards
- **Use Clear Type Annotations:** Type hints (`float`, `int`) document expected inputs for IDE autocompletion and static type checkers (`mypy`).
- **Encapsulate Data Conversions:** Never leak third-party data structures (like DataFrames or NumPy arrays) to external callers when simple primitives suffice.
- **Preserve Clean Return Types:** Return native Python types (`float`, `dict`) so the function can be directly integrated into web APIs and JSON endpoints.

## Real-World Business Context
In production machine learning systems, data scientists hand off trained weights to software engineering teams. Software engineers wrap these models into microservice endpoints using frameworks like FastAPI or Flask. The `quote_pizza` pattern is the exact architectural blueprint used to expose ML models as RESTful microservices.

## Summary and Key Takeaways
- The `quote_pizza()` pattern bridges the gap between statistical ML estimators and practical software applications.
- Encapsulation hides scikit-learn's internal matrix mechanics behind a simple, intuitive function interface.
- Python closures allow the helper function to access the trained model object without using dangerous global variables.
- The function receives primitives (`float`, `int`), performs inference, and returns a clean monetary float ($21.05).

## Knowledge Check and Self-Assessment
1. What software engineering principle does `quote_pizza()` implement by hiding DataFrame creation from the caller?
2. Why is `quote_pizza()` defined inside `main()` rather than at module scope in `main.py`?
3. What is the return type of `quote_pizza()`?
4. What is the predicted price for a 12-inch pizza with 3 toppings?

## References and Further Reading
- Clean Architecture (Robert C. Martin), Chapter 18: Component Principles
- Python Closures and Scoping: https://realpython.com/inner-functions-what-are-they-good-for/
- FastAPI Machine Learning Deployment Tutorial: https://fastapi.tiangolo.com/tutorial/
