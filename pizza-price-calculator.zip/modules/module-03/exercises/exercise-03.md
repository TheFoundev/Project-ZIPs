# Module 3 Exercises: Training Multiple Linear Regression & Calculating Equations

## Exercise 3.1: Reproducible Train/Test Partitioning (15 min)
**Objective:** Partition `pizza_menu.csv` using `train_test_split` with exact parameterization and verify sample allocations.
**Problem Statement:** You must implement the exact train/test partition used in `main.py` and write verification tests ensuring reproducibility and sample independence.

**Requirements:**
1. Load `data/pizza_menu.csv` and extract $X$ and $y$.
2. Call `train_test_split(X, y, test_size=0.25, random_state=42)`.
3. Programmatically assert:
   - `len(X_train) == 33`
   - `len(X_test) == 12`
   - `X_train.shape[1] == 2`
   - `len(set(X_train.index).intersection(set(X_test.index))) == 0`
4. Print the mean diameter and mean toppings in both the training set and testing set to verify balanced feature distributions.

**Constraints:** Use `sklearn.model_selection.train_test_split`.

**Expected Behaviour:** Clean execution confirming all assertions and printing sample statistics.

**Acceptance Criteria:**
- [ ] Correctly uses `test_size=0.25` and `random_state=42`.
- [ ] Confirms 33 train rows and 12 test rows.
- [ ] Confirms zero index overlap between train and test sets.
- [ ] Demonstrates balanced distributions between subsets.

**Hints:**
- In Python, `set(a).intersection(set(b))` finds common elements.
- `random_state=42` ensures identical splitting across runs.

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 3.2: Model Fitting and Parameter Extraction (15 min)
**Objective:** Fit `LinearRegression` on training data and extract parameters into named variables.
**Problem Statement:** Write the model training routine from `main.py`, extract `coef_` and `intercept_`, and print the exact regression equation.

**Requirements:**
1. Import and instantiate `LinearRegression` from `sklearn.linear_model`.
2. Fit the model strictly on `X_train, y_train`.
3. Extract `size_weight, topping_weight = model.coef_`.
4. Extract `intercept = model.intercept_`.
5. Format and print the equation: `price = {intercept:.2f} + {size_weight:.2f} x diameter + {topping_weight:.2f} x toppings`.
6. Assert that `intercept` rounds to `4.02`, `size_weight` rounds to `0.97`, and `topping_weight` rounds to `1.81`.

**Constraints:** Match lines 36-37 and 42-43 of `main.py`.

**Expected Behaviour:** Script fits model and prints the verified equation string.

**Acceptance Criteria:**
- [ ] Fits model on `X_train, y_train` only.
- [ ] Correctly unpacks `model.coef_` into two variables.
- [ ] Correctly extracts `model.intercept_`.
- [ ] Matches parameters: intercept ~4.02, size_weight ~0.97, topping_weight ~1.81.

**Hints:**
- `model.coef_` is a 1D NumPy array with 2 values.
- `model.intercept_` is a float.

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 3.3: Manual Equation Calculation vs Model Inference (15 min)
**Objective:** Prove mathematical equivalence between the algebraic equation and `model.predict()`.
**Problem Statement:** A skeptic on the restaurant management team believes that `model.predict()` performs mysterious calculations that differ from the printed equation. You must prove mathematically and programmatically that they are identical.

**Requirements:**
1. Select the first 5 records from `X_test`.
2. Generate predictions using `model.predict(X_test.head(5))`.
3. Calculate manual predictions using the formula:
   `intercept + (size_weight * row.diameter_inches) + (topping_weight * row.toppings)` for each record.
4. Compare the model predictions and manual calculations using `np.allclose()`.
5. Print a comparison table showing Diameter, Toppings, Model Prediction, and Manual Calculation.

**Constraints:** Use `numpy.allclose` with tolerance $10^{-6}$.

**Expected Behaviour:** A comparison table demonstrating identical numerical outputs to at least 4 decimal places.

**Acceptance Criteria:**
- [ ] Generates predictions using `model.predict()`.
- [ ] Calculates manual predictions using extracted coefficients.
- [ ] Proves equivalence with `np.allclose()`.
- [ ] Displays clear comparison table.

**Hints:**
- Use `np.allclose(model_preds, manual_preds)`.
- Ordinary linear regression is strictly linear matrix multiplication.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 3.4: Cost Breakdown Simulator for Custom Pizzas (15 min)
**Objective:** Build an economic cost breakdown simulator that decomposes any pizza quote into its three cost components.
**Problem Statement:** Create an interactive simulator function `explain_quote(diameter, toppings)` that prints the dollar and percentage breakdown of base cost, size cost, and topping cost.

**Requirements:**
1. Define `explain_quote(diameter: float, toppings: int) -> dict`.
2. Compute:
   - `base_fee = intercept`
   - `size_fee = size_weight * diameter`
   - `topping_fee = topping_weight * toppings`
   - `total_price = base_fee + size_fee + topping_fee`
3. Compute the percentage contribution of each fee to the total price.
4. Test the function on:
   - Small (8 in, 1 topping)
   - Medium (12 in, 3 toppings)
   - Large (16 in, 5 toppings)
   - Party (18 in, 5 toppings)
5. Print formatted cost breakdown summaries.

**Constraints:** Use the model parameters learned in `main.py`.

**Expected Behaviour:** Clear printed breakdown showing how each component contributes to customer pricing.

**Acceptance Criteria:**
- [ ] Correctly decomposes quotes into base, size, and topping fees.
- [ ] Computes exact dollar amounts and percentage shares.
- [ ] Accurately tests all 4 specified menu configurations.
- [ ] Verifies that sum of component fees equals total quoted price.

**Hints:**
- Medium (12 in, 3 toppings) should total $21.05.
- Percentage = `(component_fee / total_price) * 100`.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes
