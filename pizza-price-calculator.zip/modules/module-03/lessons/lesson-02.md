# Lesson 02: Partitioning Multi-Feature Data with Train-Test Split

**Lesson ID:** lesson-02
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why splitting data into disjoint training and testing sets prevents overfitting
- Configure `train_test_split` with `test_size=0.25` and `random_state=42`
- Verify the mathematical row counts and column dimensions across all four split partitions
- Explain why `random_state` is essential for scientific reproducibility
- Guard against data snooping and data leakage during preprocessing and evaluation

## Prerequisites
- Completion of Lesson 01
- Understanding of 2D feature matrices and 1D target vectors from Module 02

## Concept Explanation

### The Danger of In-Sample Evaluation (Overfitting)
If an algorithm is evaluated on the exact same dataset it was trained on, it can achieve deceptively high accuracy simply by memorizing noise, quirks, or outliers in the sample data. In commercial software, a pricing engine that merely memorizes past menu items but fails to quote accurate prices on novel customer orders is useless.

To simulate real-world deployment, machine learning practitioners split historical records into two mutually exclusive sets:
1. **Training Set ($X_{\text{train}}, y_{\text{train}}$):** The observations provided to the algorithm during `model.fit()`. The model uses these records to calculate its weight parameters.
2. **Testing Set ($X_{\text{test}}, y_{\text{test}}$):** Held-out observations strictly hidden from the algorithm during training. Once fitted, the model predicts prices for $X_{\text{test}}$, and its predictions are compared against ground-truth $y_{\text{test}}$ to evaluate true generalization.

```mermaid
flowchart TD
    A["Entire Dataset (45 samples)"] --> B["train_test_split(test_size=0.25, random_state=42)"]
    B --> C["X_train: (33, 2)"]
    B --> D["X_test: (12, 2)"]
    B --> E["y_train: (33,)"]
    B --> F["y_test: (12,)"]
    C --> G["Model Fitting: model.fit(X_train, y_train)"]
    E --> G
    G --> H["Trained Model"]
    D --> I["Evaluation: model.predict(X_test)"]
    H --> I
    I --> J["Compare with y_test (MAE, R2)"]
```

### The 75/25 Split Ratio
In `main.py`, the partitioning parameter is specified as `test_size=0.25`:
- Total samples: $n = 45$
- Test allocation: $45 \times 0.25 = 11.25 \rightarrow 12$ rows (26.67% of data)
- Training allocation: $45 - 12 = 33$ rows (73.33% of data)

For small tabular datasets (30–100 records), a 75/25 or 80/20 split provides an optimal balance: 33 observations are more than sufficient to constrain 3 linear parameters ($b, w_1, w_2$), while 12 test observations provide a robust out-of-sample performance benchmark.

### Why `random_state=42` Matters
The `train_test_split` function shuffles rows randomly before partitioning. If the random number generator is unseeded, every script execution produces a different permutation of rows, resulting in fluctuating coefficients, varying error metrics, and non-reproducible research.

By specifying `random_state=42`:
- The pseudo-random number generator is initialized with a deterministic seed.
- The exact same 33 rows are assigned to training, and the exact same 12 rows are assigned to testing every time the script runs.
- Every student, instructor, and automated testing suite obtains identical weights, identical MAE ($0.58), and identical $R^2$ ($0.98$).

## Relevant Code (from main.py, lines 32-34)
```python
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42
    )
```

## Code Architecture and Walkthrough
- **Function Import:** `from sklearn.model_selection import train_test_split`
- **Argument Order:** The function accepts positional arguments `X` and `y`.
- **Keyword Arguments:**
  - `test_size=0.25`: Allocates 25% of records to the test set.
  - `random_state=42`: Establishes deterministic pseudo-random shuffling.
- **Unpacking Tuple:** It returns a four-element tuple in the exact sequence: `X_train, X_test, y_train, y_test`. Reversing or misordering these variable names is a frequent beginner bug.

## Worked Example
Let us inspect the dimensions and index alignment of the four partitions:
```python
import pandas as pd
from sklearn.model_selection import train_test_split

df = pd.read_csv("data/pizza_menu.csv")
X = df[["diameter_inches", "toppings"]]
y = df["price_usd"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)

print(f"X_train shape: {X_train.shape} (type: {type(X_train).__name__})")
print(f"X_test shape:  {X_test.shape}  (type: {type(X_test).__name__})")
print(f"y_train shape: {y_train.shape}   (type: {type(y_train).__name__})")
print(f"y_test shape:  {y_test.shape}   (type: {type(y_test).__name__})")

# Verify sample indices match between X and y
assert (X_train.index == y_train.index).all()
assert (X_test.index == y_test.index).all()
print("
Index integrity verified: Features and labels remain perfectly aligned!")
```
Output:
```
X_train shape: (33, 2) (type: DataFrame)
X_test shape:  (12, 2) (type: DataFrame)
y_train shape: (33,)   (type: Series)
y_test shape:  (12,)   (type: Series)

Index integrity verified: Features and labels remain perfectly aligned!
```

## Step-by-Step Implementation Guide
1. Import `train_test_split` from `sklearn.model_selection`.
2. Ensure `X` has shape `(45, 2)` and `y` has shape `(45,)`.
3. Call `train_test_split(X, y, test_size=0.25, random_state=42)`.
4. Unpack into `X_train, X_test, y_train, y_test`.
5. Verify shapes:
   - `assert X_train.shape == (33, 2)`
   - `assert X_test.shape == (12, 2)`
   - `assert y_train.shape == (33,)`
   - `assert y_test.shape == (12,)`
6. Check that sum of rows equals original length: `len(X_train) + len(X_test) == 45`.

## Expected Output and Verification
Inspecting the first few rows of `X_train` shows that original DataFrame indices are preserved (e.g., indices 24, 13, 29...):
```
    diameter_inches  toppings
24             14.9         4
13             11.8         3
29             15.8         1
```
Preserving index labels allows engineers to cross-reference test errors back to specific raw records in the source CSV file.

## Practical Exercises
- **Exercise 2.1:** What happens to `X_train.shape` if you change `test_size=0.20`? How many rows are allocated to train and test?
- **Exercise 2.2:** What happens if you omit `random_state` and run the script multiple times? Do the model coefficients remain identical?
- **Exercise 2.3:** Write a unit test asserting that the set of index labels in `X_train` has zero overlap with the index labels in `X_test`.

## Common Pitfalls and Debugging Strategies
| Pitfall | Root Cause | Debugging Strategy |
|---|---|---|
| Inverted return variable order | Writing `X_train, y_train, X_test, y_test = ...` | Always follow standard convention: `X_train, X_test, y_train, y_test`. |
| Data leakage into training | Fitting scalers or models on the entire dataset before splitting | Always split raw data first; fit models strictly on `X_train, y_train`. |
| Non-reproducible benchmarks | Forgetting `random_state=42` | Explicitly specify `random_state=42` in all deterministic project pipelines. |

## Best Practices and Industry Standards
- **Golden Rule of ML:** Never expose test partition data to the model during the training phase.
- **Maintain Determinism:** Use explicit seeds in random partitions to ensure code reviews and verification suites produce consistent results.
- **Preserve Tabular Metadata:** Keeping feature matrices as pandas DataFrames rather than converting to raw NumPy arrays preserves column names for downstream error analysis.

## Real-World Business Context
In financial modeling and enterprise pricing engines, regulatory compliance requires full auditability. If an automated pricing model is challenged by a customer or consumer protection bureau, the company must be able to reproduce the exact model weights by running the identical training code with the documented random seed.

## Summary and Key Takeaways
- Train/test splitting simulates real-world deployment by evaluating trained models on unseen data.
- In `main.py`, `test_size=0.25` partitions 45 records into 33 training rows and 12 test rows.
- `random_state=42` guarantees identical shuffling and full scientific reproducibility.
- The 4-element return tuple maintains feature column headers and row alignment across all partitions.

## Knowledge Check and Self-Assessment
1. Why must a machine learning model be evaluated on data it was never trained on?
2. How many rows are allocated to the training set and testing set respectively in `main.py`?
3. What is the consequence of omitting `random_state=42` in `train_test_split`?
4. What is the correct variable unpacking order returned by `train_test_split`?

## References and Further Reading
- Scikit-learn train_test_split User Guide: https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html
- Data Leakage in Machine Learning: https://machinelearningmastery.com/data-leakage-machine-learning/
- Reproducibility in Data Science: https://towardsdatascience.com/reproducible-machine-learning-best-practices-6f8aa5ce675c
