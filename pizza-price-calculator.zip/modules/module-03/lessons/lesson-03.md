# Lesson 03: Model Fitting & Parameter Extraction (coef_ and intercept_)

**Lesson ID:** lesson-03
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Instantiate and fit scikit-learn's `LinearRegression` estimator on training data
- Understand the internal state transition of estimators during `.fit()`
- Extract learned weights using `model.coef_` and the base bias using `model.intercept_`
- Generate model predictions on unseen test samples using `model.predict()`
- Construct the human-readable mathematical pricing equation from fitted attributes

## Prerequisites
- Completion of Lessons 01 and 02
- Understanding of scikit-learn's estimator API pattern (`fit` and `predict`)

## Concept Explanation

### The Estimator Lifecycle in Scikit-Learn
Scikit-learn structures all machine learning algorithms around consistent object-oriented interfaces:
1. **Instantiation:** `model = LinearRegression()` creates an uninitialized estimator object containing hyperparameters (e.g., `fit_intercept=True`). At this stage, the model contains no learned weights.
2. **Fitting (Optimization):** `model.fit(X_train, y_train)` executes the Ordinary Least Squares solver on the training records. The solver calculates the optimal parameters that minimize the sum of squared errors.
3. **Inference (Prediction):** `predictions = model.predict(X_test)` computes $\hat{y} = X_{\text{test}} \mathbf{w} + b$ across the test samples.

```mermaid
stateDiagram-v2
    [*] --> Instantiated: LinearRegression()
    Instantiated --> Fitted: model.fit(X_train, y_train)
    note right of Fitted
      Learned Attributes Populated:
      - model.coef_ = [0.9656, 1.8125]
      - model.intercept_ = 4.0224
    end note
    Fitted --> Inference: model.predict(X_test)
    Inference --> Fitted
```

### Inspecting Learned Attributes: `coef_` and `intercept_`
Upon successful completion of `.fit()`, scikit-learn stores the learned parameters as attributes ending with a trailing underscore:
- `model.coef_`: A NumPy array containing the slope coefficients corresponding to each input feature in $X$. Since $X$ contains 2 features (`diameter_inches` and `toppings`), `model.coef_` is a 1D array of length 2:
  ```python
  model.coef_  # array([0.96562086, 1.81253488])
  ```
- `model.intercept_`: A float scalar representing the baseline offset ($b$):
  ```python
  model.intercept_  # 4.022421321481971
  ```

### Unpacking Parameters Cleanly
In `main.py`, line 42 unpacks the coefficient array directly into domain-specific variable names:
```python
size_weight, topping_weight = model.coef_
intercept = model.intercept_
```
- `size_weight`: Equal to `0.9656` (the marginal dollar increase per inch of diameter).
- `topping_weight`: Equal to `1.8125` (the marginal dollar increase per added topping).
- `intercept`: Equal to `4.0224` (the base dollar charge for dough, oven heating, packaging, and labor).

## Relevant Code (from main.py, lines 36-43, 54-57)
```python
    model = LinearRegression()
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    mae = mean_absolute_error(y_test, predictions)
    r2 = r2_score(y_test, predictions)
    size_weight, topping_weight = model.coef_
    intercept = model.intercept_
    ...
    print("=" * 60)
    print("THE PIZZA PRICE CALCULATOR")
    print("=" * 60)
    print(f"Equation: price = {intercept:.2f} + {size_weight:.2f} x diameter + {topping_weight:.2f} x toppings")
```

## Code Architecture and Walkthrough
- **Line 36-37:** `model = LinearRegression()` and `model.fit(X_train, y_train)` trains the pricing engine strictly on the 33 training records.
- **Line 38:** `predictions = model.predict(X_test)` evaluates the 12 test records, returning a 1D NumPy array of predicted dollar prices.
- **Line 42-43:** `size_weight, topping_weight = model.coef_` unpacks the 2-element coefficient array.
- **Line 57:** Prints the formatted formula using Python f-strings formatted to two decimal places (`:.2f`).

## Worked Example
Let us trace the parameter extraction and manual verification:
```python
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

df = pd.read_csv("data/pizza_menu.csv")
X = df[["diameter_inches", "toppings"]]
y = df["price_usd"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)

model = LinearRegression()
model.fit(X_train, y_train)

size_weight, topping_weight = model.coef_
intercept = model.intercept_

print(f"Intercept:      {intercept:.4f}")
print(f"Size weight:    {size_weight:.4f}")
print(f"Topping weight: {topping_weight:.4f}")

# Manually verify prediction on first test sample
first_test_diameter = X_test.iloc[0]["diameter_inches"]
first_test_toppings = X_test.iloc[0]["toppings"]
actual_price = y_test.iloc[0]

manual_pred = intercept + (size_weight * first_test_diameter) + (topping_weight * first_test_toppings)
model_pred = model.predict(X_test.iloc[[0]])[0]

print(f"
First Test Sample: {first_test_diameter} in, {first_test_toppings} toppings")
print(f"Actual Price:      ${actual_price:.2f}")
print(f"Manual Equation:   ${manual_pred:.2f}")
print(f"Model Predict():   ${model_pred:.2f}")
assert abs(manual_pred - model_pred) < 1e-6
print("Verification Succeeded: Equation matches predict() exactly!")
```
Output:
```
Intercept:      4.0224
Size weight:    0.9656
Topping weight: 1.8125

First Test Sample: 14.1 in, 0 toppings
Actual Price:      $18.00
Manual Equation:   $17.64
Model Predict():   $17.64
Verification Succeeded: Equation matches predict() exactly!
```

## Step-by-Step Implementation Guide
1. Import `LinearRegression` from `sklearn.linear_model`.
2. Instantiate `model = LinearRegression()`.
3. Fit the model: `model.fit(X_train, y_train)`.
4. Generate test predictions: `predictions = model.predict(X_test)`.
5. Unpack weights: `size_weight, topping_weight = model.coef_`.
6. Extract intercept: `intercept = model.intercept_`.
7. Format and print the regression equation string.
8. Verify that `predictions.shape == (12,)`.

## Expected Output and Verification
Executing the code prints:
```
Equation: price = 4.02 + 0.97 x diameter + 1.81 x toppings
```
This confirms that the parameters were extracted correctly and round cleanly to $4.02 base cost, $0.97 per inch, and $1.81 per topping.

## Practical Exercises
- **Exercise 3.1:** What is the predicted price for a pizza with diameter 15 inches and 0 toppings? Calculate it manually using the printed equation.
- **Exercise 3.2:** What is the predicted price for a pizza with diameter 10 inches and 4 toppings?
- **Exercise 3.3:** If a model was trained with `fit_intercept=False`, what would `model.intercept_` evaluate to? Why would forcing a $0.00 intercept harm pizza pricing accuracy?

## Common Pitfalls and Debugging Strategies
| Pitfall | Root Cause | Debugging Strategy |
|---|---|---|
| Unpacking error `ValueError: too many values to unpack` | Number of features in $X$ does not match unpacking variables | Ensure `len(model.coef_) == 2` when unpacking into two variables. |
| Fitting on entire dataset | Passing `model.fit(X, y)` instead of `X_train, y_train` | Always train strictly on `X_train, y_train` to preserve test integrity. |
| Inverting features in predict | Passing `[[toppings, diameter]]` instead of `[[diameter, toppings]]` | Always pass a DataFrame with named columns to guarantee feature alignment. |

## Best Practices and Industry Standards
- **Always Verify Coefficient Signs:** Check that learned weights align with domain physics (e.g., both size and toppings should have positive signs).
- **Explicit Parameter Logging:** Log both unrounded high-precision floats and customer-facing rounded values in auditing files (`quotes.txt`).
- **Validate Prediction Consistency:** Confirm that `model.predict()` produces the exact same numerical result as the algebraic formula.

## Real-World Business Context
In automated corporate revenue management systems, regression weights serve as business intelligence benchmarks. Restaurant CFOs inspect `size_weight` and `topping_weight` to verify whether menu pricing accurately covers rising supplier ingredient costs. If the market cost of pepperoni jumps, the business immediately knows whether `topping_weight` ($1.81) needs an upward revision.

## Summary and Key Takeaways
- Calling `model.fit(X_train, y_train)` fits Ordinary Least Squares parameters to the training data.
- The model learns three parameters: `intercept_` ($4.0224$), and `coef_` ($[0.9656, 1.8125]$).
- The learned pricing equation is $\text{price} = 4.02 + 0.97 \times \text{diameter} + 1.81 \times \text{toppings}$.
- Manual calculation using the equation yields identical predictions to `model.predict()`.

## Knowledge Check and Self-Assessment
1. What Python data type is returned by `model.coef_` in a multiple linear regression model?
2. What are the values of `size_weight` and `topping_weight` learned by the model?
3. What is the value of the learned intercept $b$?
4. How do you unpack multiple regression coefficients into separate variable names in Python?

## References and Further Reading
- Scikit-learn Estimator Design: https://scikit-learn.org/stable/developers/develop.html
- Linear Model Coefficients and Interpretability: https://christophm.github.io/interpretable-ml-book/limo.html
- Python String Formatting (F-Strings): https://realpython.com/python-f-strings/
