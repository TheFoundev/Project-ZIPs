# Lesson 04: Economic Interpretation of Base Cost, Size Weight, and Topping Weight

**Lesson ID:** lesson-04
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Translate mathematical parameters into concrete business and economic principles
- Explain the commercial meaning of the intercept ($4.02) as fixed operational base cost
- Explain the marginal cost of pizza size via `size_weight` ($0.97 per inch)
- Explain the marginal cost of pizza ingredients via `topping_weight` ($1.81 per topping)
- Critique the linear surface approximation versus true quadratic pizza surface area ($A = \pi r^2$)

## Prerequisites
- Completion of Lessons 01, 02, and 03
- Basic understanding of fixed costs versus variable costs in economics

## Concept Explanation

### Unpacking the Economic Model
One of the primary reasons linear regression remains the most widely deployed algorithm in business is its **complete interpretability**. Unlike opaque neural networks or ensemble trees, every single parameter in a linear model has a direct, intuitive real-world meaning.

Our fitted pricing model:
$$\text{price\_usd} = 4.02 + 0.97 \times \text{diameter\_inches} + 1.81 \times \text{toppings}$$
decomposes the customer invoice into three distinct commercial components:
1. **The Fixed Base Fee (Intercept = $4.02):** The fixed operational overhead.
2. **The Size Marginal Fee (Size Weight = $0.97):** The variable cost per inch of diameter.
3. **The Topping Marginal Fee (Topping Weight = $1.81):** The variable cost per topping item.

```mermaid
flowchart TD
    A["Customer Pizza Price"] --> B["Fixed Overhead: $4.02 (Intercept)"]
    A --> C["Size Charge: $0.97 per inch (Size Weight)"]
    A --> D["Ingredient Charge: $1.81 per item (Topping Weight)"]
    B --> E["Box, kitchen labor, oven preheating, basic sauce & cheese"]
    C --> F["Dough expansion, box sizing, extra cooking time"]
    D --> G["Pepperoni, mushrooms, sausage, bacon, packaging labor"]
```

### The Intercept as Fixed Cost ($4.02)
In pure mathematics, the intercept is the predicted value of $y$ when all inputs equal zero ($x_1 = 0, x_2 = 0$). While a "0-inch pizza with 0 toppings" does not exist on a dining menu, in business economics the intercept represents **fixed overhead**:
- Cardboard delivery packaging and pizza box.
- Overhead costs of keeping pizza ovens heated to 500°F.
- Basic kitchen order handling and cashier labor.
- Baseline minimum portion of tomato sauce and core mozzarella cheese.

Charging a baseline fee of ~$4.02 guarantees that even the smallest personal pizza covers fixed operational costs before ingredient additions.

### The Size Weight as Linear Marginal Expansion ($0.97/inch)
The coefficient $w_1 = 0.9656 \approx \$0.97$ indicates that:
> For every additional inch of pizza diameter, menu price increases by approximately 97 cents, holding the number of toppings constant.

For example:
- A 10-inch pizza with 2 toppings costs: $4.02 + 0.97(10) + 1.81(2) = \$17.34$
- A 12-inch pizza with 2 toppings costs: $4.02 + 0.97(12) + 1.81(2) = \$19.28$
- Difference: $\$19.28 - \$17.34 = \$1.94$ (exactly $2 \times \$0.97$).

### The Topping Weight as Ingredient Add-On ($1.81/topping)
The coefficient $w_2 = 1.8125 \approx \$1.81$ indicates that:
> For every additional topping added to the pizza, menu price increases by approximately $1.81, holding pizza diameter constant.

This matches consumer pricing expectations across major restaurant chains, where extra toppings typically cost between $1.50 and $2.25.

### Economic Nuance: Linear Diameter vs Quadratic Area
Critical thinkers often ask: *Pizza is a circle; its surface area scales quadratically ($A = \pi r^2 = \frac{\pi}{4} d^2$). Why does a linear diameter feature work so well ($R^2 = 0.98$)?*
- An 8-inch pizza has an area of roughly $50.3\text{ in}^2$.
- A 16-inch pizza has an area of roughly $201.1\text{ in}^2$ (4 times the area!).
If pizza dough costs scaled strictly with area, pricing might require a quadratic term ($d^2$). However, commercial menu pricing is heavily anchored to consumer psychology:
1. Consumers think linearly in diameter ("12-inch medium vs 16-inch large"), not square inches.
2. Fixed overhead ($4.02) and topping fees ($1.81) buffer total price, keeping price curves within the linear regime across the 8–18 inch range.
3. Over the limited menu domain of 8 to 18 inches, a linear approximation achieves an outstanding $R^2 = 0.98$, proving that multiple linear regression is commercially optimal and easily understood by customers.

## Relevant Code (from main.py, lines 42-44, 57)
```python
    size_weight, topping_weight = model.coef_
    intercept = model.intercept_
    ...
    print(f"Equation: price = {intercept:.2f} + {size_weight:.2f} x diameter + {topping_weight:.2f} x toppings")
```

## Code Architecture and Walkthrough
- The formatting string `f"Equation: price = {intercept:.2f} + {size_weight:.2f} x diameter + {topping_weight:.2f} x toppings"` directly communicates the economic pricing model to restaurant stakeholders.
- Extracting weights directly allows managers to review whether supplier price hikes require model retraining.

## Worked Example
Suppose wholesale food inflation increases raw topping costs by 20%. The pizzeria owner wants to simulate the impact:
Current pricing model:
$$\text{Price} = 4.02 + 0.97 d + 1.81 t$$
If topping cost increases by 20%:
$$1.8125 \times 1.20 = 2.1750 \approx \$2.18$$
Adjusted inflation-aware pricing model:
$$\text{Price}_{\text{new}} = 4.02 + 0.97 d + 2.18 t$$

For a 12-inch pizza with 3 toppings:
- Old price: $4.02 + 0.97(12) + 1.81(3) = \$21.05$
- New price: $4.02 + 0.97(12) + 2.18(3) = \$22.16$
- Net price increase: $\$1.11$, perfectly protecting the restaurant's gross margins!

## Step-by-Step Implementation Guide
1. Train the multiple linear regression model on `pizza_menu.csv`.
2. Extract `size_weight, topping_weight = model.coef_` and `intercept = model.intercept_`.
3. Calculate the baseline cost for a plain pizza (0 toppings) across standard sizes (8, 10, 12, 14, 16, 18 inches).
4. Calculate the cost increment for adding 1, 2, 3, 4, and 5 toppings.
5. Create a breakdown table illustrating the proportion of price attributable to base cost, size, and toppings for a Medium (12-inch, 3-topping) pizza.

## Expected Output and Verification
Cost breakdown for Medium 12-inch, 3-topping pizza ($21.05 total):
- Base fixed fee: $4.02 (19.1% of price)
- Diameter size contribution: $11.59 (55.0% of price)
- Toppings contribution: $5.44 (25.9% of price)
- Total Quote: $21.05 (100.0%)

This breakdown demonstrates how multiple linear regression provides complete transparency into cost accounting.

## Practical Exercises
- **Exercise 4.1:** What proportion of the price of an 8-inch pizza with 1 topping ($13.56) is represented by the fixed base cost ($4.02)?
- **Exercise 4.2:** If a competitor charges $1.25 per topping, how does our model's topping weight ($1.81) compare? What might account for this difference?
- **Exercise 4.3:** Explain why linear regression coefficients are called "partial regression coefficients" in econometrics.

## Common Pitfalls and Debugging Strategies
| Pitfall | Root Cause | Debugging Strategy |
|---|---|---|
| Confusing intercept with minimum menu price | Treating intercept as a real pizza price | Explain that intercept is a mathematical baseline; all real pizzas have diameter $\ge 8.4$ inches. |
| Assuming non-linear effects require neural networks | Believing complex algorithms are always better | Verify that linear regression achieves $R^2 = 0.98$, making complex non-linear models unnecessary. |
| Inverting marginal interpretations | Saying diameter increases by $0.97 inches per dollar | Ensure interpretation states: price increases by $\$0.97$ per *unit of diameter*. |

## Best Practices and Industry Standards
- **Communicate Marginal Rates Clearly:** In commercial reports, always describe coefficients as rates (e.g., "$0.97 per additional inch", "$1.81 per added topping").
- **Verify Economic Reasonableness:** Ensure that coefficients have plausible economic signs and magnitudes before deploying pricing algorithms.
- **Maintain Stakeholder Transparency:** Use linear regression's transparent mathematical formula to gain trust from business managers and pricing committees.

## Real-World Business Context
In commercial food service, pricing models that cannot be explained to franchise owners are routinely rejected. Franchisees demand to know why a specific pizza is priced at $21.05 rather than $22.50. The linear equation `price = 4.02 + 0.97*diameter + 1.81*toppings` provides an unassailable, mathematically rigorous justification that satisfies both franchisees and corporate leadership.

## Summary and Key Takeaways
- The linear model's intercept ($4.02) represents fixed operational overhead (packaging, basic cheese/sauce, oven operation).
- The size weight ($0.97/inch) captures the marginal cost of crust expansion.
- The topping weight ($1.81/topping) captures the marginal cost of ingredient additions.
- The linear model provides an exceptional fit ($R^2 = 0.98$) that aligns with consumer psychology and delivers complete business explainability.

## Knowledge Check and Self-Assessment
1. What is the commercial interpretation of the intercept ($4.02) in the pizza pricing model?
2. What is the economic interpretation of the `size_weight` ($0.97)?
3. What is the economic interpretation of the `topping_weight` ($1.81)?
4. Why does a linear model work exceptionally well despite pizza area scaling with the square of the radius?

## References and Further Reading
- Principles of Microeconomics (Mankiw), Chapter 13: The Costs of Production
- Interpretable Machine Learning (Molnar), Chapter 5.1: Linear Regression
- Pricing Strategy and Tactics in Food Service: https://www.restaurantowner.com/public/Menu-Pricing-Strategies.cfm
