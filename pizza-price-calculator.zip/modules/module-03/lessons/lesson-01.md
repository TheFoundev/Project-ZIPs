# Lesson 01: The Mathematical Engine of Multiple Linear Regression

**Lesson ID:** lesson-01
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Formulate the multiple linear regression equation for two predictor features
- Understand how linear regression expands from a 2D line to a 3D planar surface (hyperplane)
- Explain the Ordinary Least Squares (OLS) optimization objective
- Relate mathematical coefficients to physical pricing components
- Identify the mathematical assumptions underpinning linear estimation

## Prerequisites
- Familiarity with simple linear equations ($y = mx + b$)
- Basic understanding of 3D Cartesian coordinates ($x_1, x_2, y$)

## Concept Explanation

### The Geometric Shift: From a Line to a Plane
In simple linear regression with one feature (such as predicting lemonade cups from temperature), the relationship is represented geometrically as a **straight line** embedded in a 2-dimensional plane:
$$y = w_1 x_1 + b$$
The line has a 1-dimensional slope ($w_1$) indicating how steeply $y$ climbs per unit increase in $x_1$.

When we add a second independent feature (combining `diameter_inches` as $x_1$ and `toppings` as $x_2$), our coordinate space expands into three dimensions:
- Axis 1 ($x_1$): Pizza Diameter in inches (horizontal axis)
- Axis 2 ($x_2$): Number of toppings (depth axis)
- Axis 3 ($y$): Menu price in USD (vertical height axis)

In this 3-dimensional space, the linear model is no longer a line. Instead, it is a flat, tilted **2D plane** slicing through 3D space:
$$\hat{y} = b + w_1 x_1 + w_2 x_2$$

```mermaid
flowchart TD
    A["Input Space (2 Features)"] --> B["Diameter Axis (x1)"]
    A --> C["Toppings Axis (x2)"]
    B --> D["3D Coordinate Space"]
    C --> D
    E["Target (Price USD)"] --> D
    D --> F["Fitted Model: 2D Planar Surface (Hyperplane)"]
```

If we added a third feature (such as `stuffed_crust`), the geometry would become a 3D hyperplane in 4-dimensional space. In general machine learning terminology, the linear decision surface is always called a **hyperplane**.

### The Ordinary Least Squares (OLS) Criterion
How does the computer determine the exact tilt and position of this pricing plane?
Scikit-learn's `LinearRegression` uses **Ordinary Least Squares (OLS)**. For each of the $n$ training pizzas, the model computes a **residual** (the vertical error between the actual price $y_i$ and the predicted plane height $\hat{y}_i$):
$$e_i = y_i - \hat{y}_i$$

The algorithm calculates the **Residual Sum of Squares (RSS)**:
$$\text{RSS} = \sum_{i=1}^{n} (y_i - \hat{y}_i)^2 = \sum_{i=1}^{n} (y_i - (b + w_1 x_{i1} + w_2 x_{i2}))^2$$
OLS finds the unique mathematical values of $b$, $w_1$, and $w_2$ that minimize RSS. By squaring the residuals, OLS heavily penalizes large pricing errors and ensures that positive and negative residuals do not cancel each other out.

### Closed-Form Normal Equation
Unlike iterative algorithms (such as gradient descent in deep learning), linear regression with small tabular datasets can be solved directly using linear algebra via the **Normal Equation**:
$$\mathbf{w} = (\mathbf{X}^T \mathbf{X})^{-1} \mathbf{X}^T \mathbf{y}$$
Scikit-learn computes this solution nearly instantaneously using highly optimized LAPACK linear algebra routines.

## Relevant Code (from main.py, lines 36-37, 42-43)
```python
    model = LinearRegression()
    model.fit(X_train, y_train)
    ...
    size_weight, topping_weight = model.coef_
    intercept = model.intercept_
```

## Code Architecture and Walkthrough
- **Line 36:** `model = LinearRegression()` instantiates the scikit-learn estimator object. By default, it configures `fit_intercept=True`, instructing the solver to calculate baseline bias $b$.
- **Line 37:** `model.fit(X_train, y_train)` executes the OLS optimization on training data.
- **Line 42:** `size_weight, topping_weight = model.coef_` unpacks the learned coefficient vector. In a 2-feature model, `model.coef_` is a 1D NumPy array of length 2: `[0.9656, 1.8125]`.
- **Line 43:** `intercept = model.intercept_` extracts the scalar baseline intercept: `4.0224`.

## Worked Example
Let us compute the price of a custom pizza directly using the OLS pricing plane:
Given parameters:
- Intercept $b = 4.0224$
- Size weight $w_1 = 0.9656$
- Topping weight $w_2 = 1.8125$

Suppose a customer orders an **11-inch pizza with 4 toppings**:
1. Base crust and facility fee: $\$4.0224$
2. Size cost: $11.0 \times 0.9656 = \$10.6216$
3. Topping cost: $4 \times 1.8125 = \$7.2500$
4. Total predicted price:
   $$\hat{y} = 4.0224 + 10.6216 + 7.2500 = \$21.8940 \approx \$21.89$$

Every point on our pricing plane represents an exact, predictable quote.

## Step-by-Step Implementation Guide
1. Import `LinearRegression` from `sklearn.linear_model`.
2. Instantiate the model: `model = LinearRegression()`.
3. Pass training data: `model.fit(X_train, y_train)`.
4. Inspect `model.coef_` to observe the weight vector.
5. Inspect `model.intercept_` to observe the baseline scalar.
6. Print the formatted plane equation:
   `print(f"price = {model.intercept_:.2f} + {model.coef_[0]:.2f}*diameter + {model.coef_[1]:.2f}*toppings")`

## Expected Output and Verification
Printing the model attributes produces the exact equation discovered in `main.py`:
```
price = 4.02 + 0.97 x diameter + 1.81 x toppings
```
This confirms that the pricing plane climbs by $0.97 for each inch of diameter and by $1.81 for each added topping, starting from a base elevation of $4.02.

## Practical Exercises
- **Exercise 1.1:** If a pizza had 0 diameter and 0 toppings, what price would the mathematical equation predict? Why is this purely a mathematical baseline rather than a physical menu item?
- **Exercise 1.2:** Calculate the price of a 16-inch pizza with 2 toppings using the unrounded parameters $b = 4.0224, w_1 = 0.9656, w_2 = 1.8125$.
- **Exercise 1.3:** Explain what would happen to the RSS if you shifted the intercept up by $5.00 without changing the slope coefficients.

## Common Pitfalls and Debugging Strategies
| Pitfall | Root Cause | Debugging Strategy |
|---|---|---|
| Unpacking `coef_` into wrong variables | Inverting the feature column order | Always verify `X.columns` order: column 0 is diameter, column 1 is toppings. |
| Accessing `coef_` before `fit()` | Calling attributes on untrained models | Always invoke `model.fit(X_train, y_train)` before querying trailing-underscore attributes like `coef_` or `intercept_`. |
| Singular matrix error in OLS | Two perfectly collinear identical features | Ensure features are not duplicate copies of each other ($X^T X$ must be invertible). |

## Best Practices and Industry Standards
- **Understand Trailing Underscores:** In scikit-learn, all attributes estimated during `.fit()` end with an underscore (e.g., `coef_`, `intercept_`, `classes_`) to distinguish learned parameters from user-configured hyperparameters.
- **Inspect Matrix Condition Numbers:** In enterprise ML, check that feature matrices are well-conditioned before relying on OLS coefficients.
- **Document Baseline Assumptions:** Clearly state that linear regression assumes additive, non-saturating effects across the operational domain.

## Real-World Business Context
Linear pricing planes are ubiquitous in commercial pricing and logistics: freight shipping quotes base fees plus weight per pound plus distance per mile; cloud compute platforms charge base instance fees plus RAM gigabytes plus storage terabytes. Multiple linear regression guarantees transparent, explainable pricing formulas required by business auditors and regulatory agencies.

## Summary and Key Takeaways
- Multiple linear regression models two features as a 2D planar surface (hyperplane) within 3D space.
- Ordinary Least Squares (OLS) minimizes the Residual Sum of Squares (RSS) between observed prices and the pricing plane.
- The learned equation for pizza pricing is $\text{price} = 4.02 + 0.97 \times \text{diameter} + 1.81 \times \text{toppings}$.

## Knowledge Check and Self-Assessment
1. Geometrically, what shape does a linear model with two features form in three-dimensional space?
2. What mathematical criterion does Ordinary Least Squares (OLS) minimize?
3. What do the trailing underscores in `model.coef_` and `model.intercept_` signify in scikit-learn?
4. What is the length and shape of `model.coef_` in this two-feature project?

## References and Further Reading
- Scikit-learn LinearRegression Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html
- The Normal Equation in Linear Algebra: https://mathworld.wolfram.com/NormalEquation.html
- An Introduction to Statistical Learning, Chapter 3: Multiple Linear Regression
