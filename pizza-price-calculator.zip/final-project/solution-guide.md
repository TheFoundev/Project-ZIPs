# Mentor Solution Guide: Pizza Price Calculator

## Overview
This guide provides mentors with complete reference solutions, line-by-line code explanations, verification checkpoints, and debugging strategies for evaluating student implementations of the **Pizza Price Calculator** final project.

---

## Reference Implementation Checkpoints

### Checkpoint 1: Headless Matplotlib and Library Imports (Lines 1-13)
```python
import matplotlib
matplotlib.use("Agg")  # Ensure headless server compatibility
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split
```
- **Mentor Verification:** Ensure `matplotlib.use("Agg")` is called *before* importing `pyplot` if running in environments without an active X11 display server.
- **Common Mistake:** Students often forget `train_test_split` or import it from the wrong module (`sklearn.cross_validation` is obsolete).

---

### Checkpoint 2: Data Ingestion and Inspection (Lines 15-28)
```python
# 1. Load data
data_path = Path("data/pizza_menu.csv")
if not data_path.exists():
    raise FileNotFoundError(f"Required dataset not found at {data_path.resolve()}")

df = pd.read_csv(data_path)
print("=== PIZZA PRICE CALCULATOR ===")
print(f"Dataset loaded: {len(df)} menu items")
print(df.head())
print("
Summary Statistics:")
print(df.describe())
```
- **Mentor Verification:** Dataset must contain 45 rows and 3 columns (`diameter_inches`, `toppings`, `price_usd`).
- **Common Mistake:** Running the script from a different working directory causing relative path failure. Encourage students to use `Path(__file__).parent / "data/pizza_menu.csv"`.

---

### Checkpoint 3: Feature Matrix Separation and Train/Test Split (Lines 30-41)
```python
# 2. Split features and target
X = df[["diameter_inches", "toppings"]]
y = df["price_usd"]

# 3. Train/test split (75/25, random_state=42)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)

print(f"
Training set: {X_train.shape[0]} pizzas")
print(f"Test set:     {X_test.shape[0]} pizzas")
```
- **Mentor Verification:** 
  - `X` must be a 2D DataFrame: `shape == (45, 2)`.
  - `y` must be a 1D Series: `shape == (45,)`.
  - `X_train.shape == (33, 2)`, `X_test.shape == (12, 2)`.
  - `random_state=42` is mandatory; omitting it changes all subsequent coefficients and MAE.

---

### Checkpoint 4: Model Training and Parameter Inspection (Lines 43-57)
```python
# 4. Fit model
model = LinearRegression()
model.fit(X_train, y_train)

# Extract learned parameters
intercept = model.intercept_
coef_diameter = model.coef_[0]
coef_toppings = model.coef_[1]

print("
--- Model Training ---")
print("Trained Linear Regression Model:")
print(f"  Intercept (base price): ${intercept:.2f}")
print(f"  Diameter coefficient:  ${coef_diameter:.2f} per inch")
print(f"  Toppings coefficient:  ${coef_toppings:.2f} per topping")
print(f"Equation: price = {intercept:.2f} + {coef_diameter:.2f} x diameter + {coef_toppings:.2f} x toppings")
```
- **Expected Numerical Values:**
  - Intercept: `4.022378...` $\rightarrow$ prints `$4.02`
  - Diameter coefficient: `0.965611...` $\rightarrow$ prints `$0.97`
  - Topping coefficient: `1.812497...` $\rightarrow$ prints `$1.81`
- **Mentor Tip:** If coefficients differ, check whether features were passed in reverse order `[['toppings', 'diameter_inches']]`.

---

### Checkpoint 5: The quote_pizza() Inference Wrapper (Lines 59-68)
```python
# 5. Define quoting function
def quote_pizza(diameter_inches, toppings):
    order = pd.DataFrame(
        [[diameter_inches, toppings]], 
        columns=["diameter_inches", "toppings"]
    )
    return float(model.predict(order)[0])

# Demonstration quote
demo_price = quote_pizza(12, 3)
print("
--- Sample Quote ---")
print(f"Quote for 12-inch with 3 toppings: ${demo_price:.2f}")
```
- **Expected Result:** `$21.05` ($21.0471).
- **Mentor Verification:** Verify the function returns a standard Python `float`, not a NumPy 1D array `array([21.05])`.
- **Warning Check:** Confirm that passing a DataFrame with column names suppresses scikit-learn's `"X does not have valid feature names"` warning.

---

### Checkpoint 6: Model Evaluation Metrics (Lines 70-76)
```python
# 6. Evaluate
y_pred = model.predict(X_test)
mae = mean_absolute_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print("
--- Model Evaluation ---")
print(f"Mean Absolute Error: ${mae:.2f}")
print(f"R-squared:           {r2:.2f}")
```
- **Expected Results:**
  - MAE: `0.579088...` $\rightarrow$ prints `$0.58`
  - $R^2$: `0.976214...` $\rightarrow$ prints `0.98`
- **Mentor Verification:** Confirm evaluation is strictly computed against `(y_test, y_pred)`, NOT `(y_train, y_pred_train)`. Training MAE is ~$0.52 and training $R^2$ is ~0.98.

---

### Checkpoint 7: Diagnostic Scatter Plot Export (Lines 78-90)
```python
# 7. Plot
fig, ax = plt.subplots(figsize=(8, 6))
ax.scatter(y_test, y_pred, color="#e67e22", edgecolors="black", s=70, label="Pizzas (test)")
lims = [0, max(max(y_test), max(y_pred)) + 5]
ax.plot(lims, lims, "--", color="gray", label="Perfect prediction")
ax.set_xlabel("Actual Price ($)")
ax.set_ylabel("Predicted Price ($)")
ax.set_title("Pizza Price: Actual vs Predicted")
ax.legend()
plt.tight_layout()
plt.savefig("actual_vs_predicted.png", dpi=150)
plt.close()
```
- **Mentor Verification:**
  - Check that `actual_vs_predicted.png` is created and readable.
  - Check colors: dots must be `#e67e22` (orange) with black outline.
  - Check that diagonal is a dashed gray line spanning 0 to ~37.
  - Check that `plt.close()` was executed.

---

### Checkpoint 8: File Output and Menu Export
```python
# 8. Export persistent menu quotes
out_dir = Path("outputs")
out_dir.mkdir(parents=True, exist_ok=True)
out_file = out_dir / "quotes.txt"

menu_catalog = [
    ("Small", 8, 1),
    ("Medium", 12, 3),
    ("Large", 16, 5),
    ("Party", 18, 5)
]

with open(out_file, "w", encoding="utf-8") as f:
    f.write("=====================================================\n")
    f.write("           PIZZA PRICE CALCULATOR QUOTE MENU         \n")
    f.write("=====================================================\n\n")
    f.write(f"{'Size':<10} | {'Diameter':<10} | {'Toppings':<10} | {'Quote Price':<12}\n")
    f.write("-" * 52 + "\n")
    for name, dia, tops in menu_catalog:
        p = quote_pizza(dia, tops)
        f.write(f"{name:<10} | {dia:>8}\" | {tops:>10} | ${p:>10.2f}\n")
    f.write("-" * 52 + "\n")
    f.write(f"Equation: price = {intercept:.2f} + {coef_diameter:.2f} x diameter + {coef_toppings:.2f} x toppings\n")
    f.write("=====================================================\n")

print(f"
Generated persistent menu catalog: {out_file}")
```
- **Expected Prices in `outputs/quotes.txt`:**
  - Small (8", 1 top): `$13.56`
  - Medium (12", 3 tops): `$21.05`
  - Large (16", 5 tops): `$28.53`
  - Party (18", 5 tops): `$30.46`

---

## Common Student Misconceptions and Debugging Guide

| Issue | Root Cause | Debugging Instruction for Mentor |
|---|---|---|
| Single brackets `df['diameter_inches']` | Extracts a 1D Series instead of 2D DataFrame for $X$. | Show student the difference between `df['col'].ndim == 1` and `df[['col']].ndim == 2`. |
| `scikit-learn` warning: "X does not have valid feature names" | Passing a raw NumPy array or list of lists into `model.predict()`. | Instruct student to wrap inference values in a `pd.DataFrame(..., columns=feature_names)`. |
| Coefficients do not match $4.02, $0.97, $1.81 | `random_state` was omitted or set to a number other than 42. | Check `train_test_split(..., random_state=42)`. |
| Residual signs inverted | Calculating `y_pred - y_test` instead of `y_test - y_pred`. | Explain that a positive residual means ground truth exceeded predicted ($y > \hat{y}$, underprediction). |
| `FileNotFoundError` when creating `outputs/quotes.txt` | Attempting to open a file in a non-existent subdirectory. | Remind student to call `Path("outputs").mkdir(parents=True, exist_ok=True)`. |

---

## Mentor Check-in Questions
1. *"Why does the pizza model have a positive intercept ($4.02)? Could a pizza ever cost $0.00 in a real restaurant?"*
2. *"If a customer wants to add 2 extra toppings, how much does their bill increase according to our regression weights?"* ($1.81 	imes 2 = $3.62)
3. *"Why is MAE denominated in dollars while $R^2$ has no units?"*
