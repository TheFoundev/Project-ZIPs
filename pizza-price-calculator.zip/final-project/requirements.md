# Final Project Requirements: Pizza Price Calculator

## Project Objective
Reproduce the complete **Pizza Price Calculator** machine learning pipeline from scratch, following the architecture and implementation standards established in `main.py`. 

Your completed project must ingest historical menu data, partition datasets into reproducible training and testing splits, fit an Ordinary Least Squares multiple linear regression model, wrap the trained estimator in a clean inference function, evaluate predictive accuracy with MAE and $R^2$, generate a publication-quality diagnostic scatter plot, export persistent menu price catalogs to disk, and provide an analytical commentary on the model's economic behavior.

---

## Functional Requirements

### 1. Environment and Library Imports
- Import core data science and machine learning dependencies:
  - `pandas` for tabular data manipulation
  - `numpy` for numerical array operations
  - `matplotlib.pyplot` for diagnostic visualization (configured with non-interactive backend `matplotlib.use('Agg')` if running in headless environments)
  - `sklearn.linear_model.LinearRegression` for Ordinary Least Squares regression
  - `sklearn.model_selection.train_test_split` for reproducible data partitioning
  - `sklearn.metrics.mean_absolute_error` and `sklearn.metrics.r2_score` for model evaluation
  - `pathlib.Path` for cross-platform filesystem handling

### 2. Data Ingestion and Validation
- Load the historical menu dataset from `data/pizza_menu.csv`.
- Assert that the dataset contains exactly 45 rows and 3 columns:
  - `diameter_inches` (integer/float: 8 to 18 inches)
  - `toppings` (integer: 1 to 6 toppings)
  - `price_usd` (float: $9.50 to $32.00)
- Validate that the dataset contains zero null, NaN, or infinite values.
- Print descriptive statistics (mean, standard deviation, min, max) for all three variables to standard output.

### 3. Feature Matrix and Target Vector Construction
- Construct the 2D feature matrix $X$ using double-bracket column indexing:
  ```python
  X = df[["diameter_inches", "toppings"]]
  ```
  Verify that `X.shape == (45, 2)`.
- Construct the 1D target vector $y$:
  ```python
  y = df["price_usd"]
  ```
  Verify that `y.shape == (45,)`.

### 4. Partitioning into Training and Testing Sets
- Partition the dataset using `train_test_split`:
  - `test_size=0.25` (25% testing, 75% training)
  - `random_state=42` (mandatory for exact mathematical reproducibility)
- Verify and print partition dimensions:
  - Training features `X_train.shape == (33, 2)`
  - Training target `y_train.shape == (33,)`
  - Test features `X_test.shape == (12, 2)`
  - Test target `y_test.shape == (12,)`

### 5. Model Fitting and Weight Extraction
- Instantiate and fit `LinearRegression`:
  ```python
  model = LinearRegression()
  model.fit(X_train, y_train)
  ```
- Extract and display learned parameters formatted as currency:
  - Base price (intercept $\beta_0$): ~$4.02 ($4.0224)
  - Diameter slope coefficient ($\beta_1$): ~$0.97 per inch ($0.9656)
  - Topping slope coefficient ($\beta_2$): ~$1.81 per topping ($1.8125)
- Print the complete learned pricing formula:
  $$\text{price} = 4.02 + 0.97 \times \text{diameter} + 1.81 \times \text{toppings}$$

### 6. Quoting Function Implementation
- Implement the `quote_pizza(diameter_inches, toppings)` wrapper function:
  - Must accept numeric diameter and integer topping parameters.
  - Must construct a 1-row pandas DataFrame with exact column names `["diameter_inches", "toppings"]` to avoid scikit-learn feature name mismatch warnings.
  - Must extract and return a pure Python `float` rounded or formatted to 2 decimal places.
- Verify that calling `quote_pizza(12, 3)` returns exactly `$21.05` ($21.0471).

### 7. Model Evaluation and Performance Metrics
- Generate predictions for the held-out test partition: `y_pred = model.predict(X_test)`.
- Compute and display the evaluation metrics:
  - **Mean Absolute Error (MAE):** Must equal `$0.58` ($0.5791), proving average pricing deviation under 60 cents.
  - **Coefficient of Determination ($R^2$):** Must equal `0.98` (0.9762), demonstrating 98% explained variance.
- Display both metrics with clean terminal formatting.

### 8. Diagnostic Visualization
- Create an 8x6 inch figure using `fig, ax = plt.subplots(figsize=(8, 6))`.
- Scatter plot test observations (`y_test` vs `y_pred`):
  - Marker color: `#e67e22` (terracotta/crust orange)
  - Edge color: `black`
  - Marker size: `s=70`
  - Label: `"Pizzas (test)"`
- Overlay a dashed gray 45-degree reference line representing perfect prediction ($y = x$):
  - Limits: `[0, max(max(y_test), max(y_pred)) + 5]`
  - Style: `"--"`, color: `"gray"`, label: `"Perfect prediction"`
- Configure axis labels:
  - X-axis: `"Actual Price ($)"`
  - Y-axis: `"Predicted Price ($)"`
  - Title: `"Pizza Price: Actual vs Predicted"`
- Apply `plt.tight_layout()` and export the chart to `actual_vs_predicted.png` at 150 DPI.
- Call `plt.close()` to ensure proper memory release.

### 9. Persistent File Output and Menu Export
- Automatically create the destination directory `outputs/` using `Path("outputs").mkdir(parents=True, exist_ok=True)`.
- Use the `with open("outputs/quotes.txt", "w", encoding="utf-8") as f:` context manager.
- Export a neatly aligned tabular price list for four standard catalog sizes:
  - Small (8-inch, 1 topping): $13.56
  - Medium (12-inch, 3 toppings): $21.05
  - Large (16-inch, 5 toppings): $28.53
  - Party (18-inch, 5 toppings): $30.46
- Include a document header, column dividers, and the model equation in the file footer.

---

## Non-Functional Requirements

### Code Quality and Standards
- Maintain strict PEP 8 compliance for variable naming, spacing, and line lengths.
- Provide clear function docstrings specifying parameter types, return values, and mathematical logic.
- Avoid global mutable state inside the quoting function.
- Ensure scripts run deterministically from any working directory using relative path anchors.

### Error Handling and Edge Cases
- Handle missing files gracefully with clear terminal warnings.
- Prevent division by zero or empty DataFrame operations.
- Ensure all file writing routines flush buffers completely before process termination.

---

## Analytical Requirements
Accompany your implementation with a concise written summary addressing:
1. **Economic Interpretation:** Explain why the intercept ($4.02) is positive and what business costs it represents (dough, base sauce, labor, kitchen overhead).
2. **Feature Marginal Contributions:** Compare the marginal cost of adding 1 inch of diameter ($0.97) versus adding 1 extra topping ($1.81).
3. **Model Limitations:** Discuss why a linear diameter model might underprice giant pizzas relative to surface area ($\pi r^2$) and suggest potential polynomial feature extensions.
