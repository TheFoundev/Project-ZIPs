# Architecture & Data Flow

## 1. Pipeline Overview

The **Pizza Price Calculator** implements an end-to-end multiple linear regression pricing pipeline. The workflow ingests historical menu data, structures multi-dimensional feature spaces, fits an Ordinary Least Squares estimator, wraps the estimator in an inference API, evaluates generalization on held-out test data, and exports visual and text artifacts.

```
                    ┌────────────────────────┐
                    │  data/pizza_menu.csv   │
                    │   (45 Menu Records)    │
                    └───────────┬────────────┘
                                │
                                ▼
                    ┌────────────────────────┐
                    │     Data Ingestion     │ ──► pd.read_csv(DATA / "pizza_menu.csv")
                    └───────────┬────────────┘
                                │
                                ▼
         ┌──────────────────────────────────────────────────┐
         │         Feature & Target Separation              │
         │  X = df[["diameter_inches", "toppings"]] (45, 2) │
         │  y = df["price_usd"]                     (45,)   │
         └──────────────────────┬───────────────────────────┘
                                │
                                ▼
         ┌──────────────────────────────────────────────────┐
         │             Train/Test Partitioning              │
         │  train_test_split(X, y, test_size=0.25, seed=42) │
         │  ├── Training Set: X_train (33, 2), y_train (33) │
         │  └── Testing Set:  X_test  (12, 2), y_test  (12) │
         └──────────────────────┬───────────────────────────┘
                                │
                                ▼
         ┌──────────────────────────────────────────────────┐
         │             Model Training (OLS)                 │
         │  model = LinearRegression()                      │
         │  model.fit(X_train, y_train)                     │
         │  ├── Intercept:      $4.0224 (Base crust/overhead)│
         │  ├── Size Weight:    $0.9656 / diameter inch     │
         │  └── Topping Weight: $1.8125 / topping           │
         └──────────────────────┬───────────────────────────┘
                                │
                 ┌──────────────┴──────────────┐
                 ▼                             ▼
   ┌───────────────────────────┐ ┌───────────────────────────┐
   │     Model Validation      │ │    Model-as-an-API Wrap   │
   │  predictions = predict(X) │ │  def quote_pizza(d, t):   │
   │  MAE = $0.5791            │ │    pd.DataFrame(...)      │
   │  R²  = 0.9762             │ │    return float(...)      │
   └─────────────┬─────────────┘ └─────────────┬─────────────┘
                 │                             │
                 │                             ▼
                 │               ┌───────────────────────────┐
                 │               │  Batch Catalog Generation │
                 │               │  4-item menu via          │
                 │               │  menu.itertuples()        │
                 │               └─────────────┬─────────────┘
                 │                             │
                 ▼                             ▼
   ┌───────────────────────────┐ ┌───────────────────────────┐
   │ Diagnostic Visualization  │ │    File Persistence       │
   │ outputs/                  │ │ outputs/quotes.txt        │
   │ actual_vs_predicted.png   │ │ (Model formula, metrics,  │
   │ (Scatter + Parity line)   │ │  and formatted price list)│
   └───────────────────────────┘ └───────────────────────────┘
```

---

## 2. Key Components & Responsibilities

1. **Environment Setup & Backend Decoupling**: Sets `matplotlib.use("Agg")` prior to importing `pyplot`, ensuring headless, server-friendly rasterization without requiring an active graphical desktop.
2. **Path Resolution**: Employs Python's `pathlib.Path(__file__).resolve().parent` to reliably target `data/` and `outputs/` independent of the terminal invocation directory.
3. **Multi-Feature Matrix Structuring**: Selects `diameter_inches` and `toppings` into a two-dimensional DataFrame $X$, ensuring compliance with scikit-learn's 2D input expectation.
4. **Reproducible Holdout Partitioning**: Uses `train_test_split` with `test_size=0.25` and `random_state=42`, allocating 33 records for training and 12 records for validation.
5. **Ordinary Least Squares Solver**: Trains `LinearRegression()` on the training set, computing parameter weights that minimize the sum of squared residuals across the 2D feature plane.
6. **Inference Encapsulation (`quote_pizza`)**: Constructs a clean, typed software wrapper that accepts primitive arguments (`float`, `int`), converts them into a single-row labeled DataFrame, and returns a scalar prediction.
7. **Batch Menu Pricing**: Uses `itertuples()` for vectorized traversal of catalog definitions, producing quotes for standard menu tiers (Small, Medium, Large, Party).
8. **Residual & Accuracy Diagnostics**: Computes Mean Absolute Error (MAE) and $R^2$, then plots observed prices against predicted prices along a 45-degree reference diagonal.
9. **Artifact Export**: Safely persists diagnostic plots to PNG and writes parameters, metrics, and quotes to `outputs/quotes.txt`.

---

## 3. Data Structures & Dimensionality Matrix

| Pipeline Stage | Variable | Data Structure | Dimensions / Shape | Type | Description |
|---|---|---|---|---|---|
| Ingestion | `df` | `pandas.DataFrame` | `(45, 3)` | float64 / int64 | Full historical menu catalog |
| Features | `X` | `pandas.DataFrame` | `(45, 2)` | float64, int64 | 2D matrix: `diameter_inches`, `toppings` |
| Target | `y` | `pandas.Series` | `(45,)` | float64 | 1D vector: `price_usd` |
| Train Partition | `X_train`, `y_train` | DataFrame / Series | `(33, 2)` / `(33,)` | float64 | 75% of data used to learn coefficients |
| Test Partition | `X_test`, `y_test` | DataFrame / Series | `(12, 2)` / `(12,)` | float64 | 25% of data held out for unbiased testing |
| Predictions | `predictions` | `numpy.ndarray` | `(12,)` | float64 | Model price estimates on test data |
| Single Query | `order` | `pandas.DataFrame` | `(1, 2)` | float64, int64 | Single pizza input to `quote_pizza()` |
| Menu Catalog | `menu` | `pandas.DataFrame` | `(4, 3)` | object, int64 | 4 standard catalog order configurations |
| Priced Catalog | `menu["model_quote"]` | `pandas.Series` | `(4,)` | float64 | Estimated prices for the 4 catalog tiers |

---

## 4. Software Design Patterns & Best Practices

### The Model-as-an-API Pattern
Directly invoking `model.predict()` in application code couples consumer logic to machine learning mechanics (requiring NumPy arrays or DataFrames with exact column names). Wrapping the estimator in `quote_pizza(diameter_inches, toppings)` abstracts the data structure requirements, validates input contracts, and provides a stable, callable interface suitable for microservices, web backends, or desktop applications.

### Itertuples vs. Iterrows Efficiency
When generating the 4-tier menu catalog, the pipeline iterates using `menu.itertuples()`:
```python
menu["model_quote"] = [
    quote_pizza(row.diameter, row.toppings) for row in menu.itertuples()
]
```
`itertuples()` yields lightweight Python namedtuples, avoiding the substantial overhead of constructing a full `pandas.Series` object on each row that occurs with `iterrows()`.

### Headless Rendering Guarantee
By declaring `matplotlib.use("Agg")` before importing `pyplot`, the pipeline eliminates dependency on local display engines (X11, Wayland, macOS Quartz, Windows GDI). This prevents execution failures in automated testing, container environments, and remote servers.
