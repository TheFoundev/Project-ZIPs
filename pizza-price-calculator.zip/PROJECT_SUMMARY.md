# Project Summary: The Pizza Price Calculator

## Executive Overview

The **Pizza Price Calculator** is an applied machine learning educational package designed to teach the theory, implementation, and operational patterns of **Supervised Multiple Linear Regression**. Using historical menu pricing data from `data/pizza_menu.csv` located in `beginner-projects-main/AI-ML Beginners/projects/08_pizza_price/`, learners build an end-to-end pricing engine in Python using pandas, numpy, matplotlib, and scikit-learn.

Rather than predicting from a single feature, learners model pizza pricing as a simultaneous function of two continuous/discrete attributes: physical diameter (in inches) and topping count. Furthermore, learners implement the **Model-as-an-API** software engineering pattern by wrapping the fitted estimator into a reusable `quote_pizza()` inference function and generating a production-style batch catalog.

---

## Educational Objectives & Competencies

- **Multi-Feature Modeling**: Extend regression thinking from simple 2D lines ($y = mx + b$) to multidimensional hyperplanes ($y = \beta_0 + \beta_1 x_1 + \beta_2 x_2$).
- **Tabular Data Wrangling**: Enforce 2D feature shapes (`(45, 2)`) using pandas double brackets and manage cross-platform paths using `pathlib.Path`.
- **Reproducible Holdout Partitioning**: Split datasets into training (75%, 33 samples) and testing (25%, 12 samples) sets using `random_state=42`.
- **Economic Parameter Interpretation**: Map abstract regression coefficients to real-world costs: base crust/overhead ($\approx \$4.02$), marginal inch cost ($\approx \$0.97/\text{in}$), and marginal topping cost ($\approx \$1.81/\text{topping}$).
- **Production API Encapsulation**: Package raw scikit-learn estimators inside clean Python functions that accept primitive arguments and return scalar predictions.
- **Batch Processing**: Iterate over customer orders and product catalogs using efficient `DataFrame.itertuples()`.
- **Comprehensive Evaluation**: Measure error magnitude using Mean Absolute Error ($\$0.58$) and goodness-of-fit with $R^2$ ($0.98$).
- **Diagnostic Visualization**: Render publication-quality Actual vs. Predicted plots with a 45-degree reference diagonal line in headless mode (`matplotlib.use("Agg")`).
- **Feature Engineering & Lifecycle Governance**: Explore model extensions (e.g. `stuffed_crust` binary indicators) and identify production hazards like extrapolation, data drift, and concept drift.

---

## Real-World Business Context

In the food service, restaurant, and e-commerce industries, pricing custom-built products requires balancing customer value perception with cost-plus profitability. Arbitrary pricing tiers cause margin erosion on large, multi-topping orders or suppress demand on smaller sizes.

By fitting multiple linear regression on historical pricing data:
1. Pizzerias can automate online ordering quotes with mathematical consistency.
2. Kitchen managers can audit whether pricing matches raw ingredient costs and baking labor.
3. Marketing teams can simulate promotional pricing and quantify the revenue impact of size or topping promotions.

---

## Implemented Architecture & Pipeline

1. **Environment Setup**: Configures non-interactive `Agg` backend to ensure headless script execution without graphical display errors.
2. **Data Ingestion**: Reads `data/pizza_menu.csv` (45 records with `diameter_inches`, `toppings`, `price_usd`).
3. **Feature Matrix Construction**: Extracts 2D matrix $X$ (`shape=(45, 2)`) and 1D target $y$ (`shape=(45,)`).
4. **Train/Test Splitting**: Partitions data with `test_size=0.25` and `random_state=42` into 33 training records and 12 holdout testing records.
5. **Model Estimation**: Fits `LinearRegression()` via Ordinary Least Squares, extracting learned coefficients and intercept.
6. **Model Validation**: Generates predictions on the 12 test records, computing MAE and $R^2$.
7. **Inference Encapsulation**: Defines `quote_pizza(diameter_inches: float, toppings: int) -> float`, packaging inputs into a single-row DataFrame matching training column names.
8. **Benchmark Query**: Evaluates a 12-inch pizza with 3 toppings, returning $\$21.05$.
9. **Batch Catalog Creation**: Iterates over a 4-tier standard menu DataFrame using `itertuples()`, generating quotes for Small, Medium, Large, and Party pizzas.
10. **Diagnostic Plotting**: Exports an actual vs. predicted scatter plot with a 45-degree parity line to `outputs/actual_vs_predicted.png`.
11. **Persistence**: Writes high-precision parameters, evaluation metrics, and the catalog price list to `outputs/quotes.txt`.

---

## Key Quantitative Results

| Metric / Parameter | High-Precision Value | Rounded Console Output | Description |
|---|---|---|---|
| **Intercept ($\beta_0$)** | `4.0224` | `$4.02` | Baseline cost (crust, kitchen overhead, box) |
| **Size Weight ($\beta_1$)** | `0.9656` | `$0.97 / inch` | Marginal cost per additional diameter inch |
| **Topping Weight ($\beta_2$)** | `1.8125` | `$1.81 / topping` | Marginal cost per additional topping |
| **Mean Absolute Error (MAE)** | `0.5791` | `$0.58` | Average test set prediction error |
| **R-squared ($R^2$)** | `0.9762` | `0.98` | 98% of price variance explained |
| **Benchmark Quote (12", 3 top)** | `$21.0471` | `$21.05` | Standard medium order quote |
| **Small (8", 1 top)** | `$13.5596` | `$13.56` | Catalog tier 1 quote |
| **Medium (12", 3 top)** | `$21.0471` | `$21.05` | Catalog tier 2 quote |
| **Large (16", 5 top)** | `$28.5346` | `$28.53` | Catalog tier 3 quote |
| **Party (18", 5 top)** | `$30.4658` | `$30.46` | Catalog tier 4 quote |

---

## Project Structure

```text
08_pizza_price/
├── main.py
├── data/
│   └── pizza_menu.csv
└── outputs/
    ├── actual_vs_predicted.png
    └── quotes.txt
```

---

## Security, Reliability, & Deployment Profile

- **Headless Execution**: `matplotlib.use("Agg")` eliminates X11/GUI display server dependencies, enabling smooth automated grading and CI/CD pipelines.
- **Path Resolution**: `pathlib.Path(__file__).resolve().parent` guarantees path resolution across all operating systems.
- **Zero Network Exposure**: 100% self-contained local execution with zero remote API dependencies or external data transfers.
- **Leak-Free File I/O**: Context managers (`with open(...)`) ensure file streams are reliably closed and flushed.

---

## Educational Modules Breakdown

1. **Module 01: Project Overview and Business Context** — Introduces commercial pizza pricing, contrasts single-feature vs. multi-feature regression, inspects the 45-row dataset, and introduces the Model-as-an-API paradigm.
2. **Module 02: Data Loading and Menu Exploration** — Covers headless matplotlib configuration, pathlib directory anchoring, pandas feature matrix extraction (`(45, 2)`), and bivariate scatter plot exploration.
3. **Module 03: Multiple Linear Regression and Economic Interpretation** — Explores hyperplane mathematics, executes 75/25 train-test splitting with seed 42, fits scikit-learn OLS, and interprets intercept and slope weights economically.
4. **Module 04: The quote_pizza() Function Pattern** — Implements the API wrapper function, handles single-row DataFrame construction to prevent scikit-learn warnings, and generates automated 4-tier menu catalogs using `itertuples`.
5. **Module 05: Model Evaluation and Residual Diagnostics** — Analyzes test MAE ($0.58) and $R^2$ (0.98), creates the Actual vs. Predicted diagonal scatter plot, and examines residual patterns and heteroscedasticity.
6. **Module 06: Pipeline Execution, File Export, and Model Extensions** — Executes the end-to-end pipeline, exports persistent reports to `quotes.txt`, explores binary dummy features (`stuffed_crust`), and examines production drift monitoring.
