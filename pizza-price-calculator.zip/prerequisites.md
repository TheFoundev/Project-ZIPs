# Prerequisites

Before starting **The Pizza Price Calculator** educational project, review the technical requirements, software tools, and foundational concepts outlined below.

---

## 1. Technical Skills Required

- **Python Basics**:
  - Defining functions with typed parameters and return values (`def quote_pizza(diameter_inches: float, toppings: int) -> float:`)
  - Inner functions and closures (accessing outer-scope model estimators)
  - List comprehensions and dictionary representations of records
  - String formatting with f-strings and precision specifiers (`{intercept:.2f}`)
- **Data Wrangling Basics**:
  - Reading CSV files using `pandas.read_csv()`
  - Understanding the structural difference between a 2D `pandas.DataFrame` and a 1D `pandas.Series`
  - DataFrame iteration patterns (e.g., `menu.itertuples()`)
- **Mathematical & Economic Intuition**:
  - Linear equations with multiple variables: $y = \beta_0 + \beta_1 x_1 + \beta_2 x_2$
  - Concept of an intercept (baseline cost when inputs are zero) and slopes/coefficients (marginal cost per additional unit)
  - Cartesion coordinate systems and 3D spatial thinking (two input features forming a plane)
- **Command Line Basics**:
  - Navigating filesystem directories (`cd`, `ls` / `dir`)
  - Running Python scripts from the terminal (`python main.py`)
  - Managing virtual environments (`venv`) and installing packages via `pip`

---

## 2. Tools & Environment Required

- **Python Runtime**: Python 3.8 or higher (Python 3.10+ recommended)
- **Package Manager**: `pip` (standard with Python)
- **Terminal / Shell**: Bash, Zsh, PowerShell, or Windows Command Prompt
- **Code Editor**: Visual Studio Code, Cursor, PyCharm, or any text editor with Python language support

---

## 3. Required Python Packages

The project relies on standard data science and machine learning libraries:

| Package | Minimum Version | Purpose in Project |
|---|---|---|
| `pandas` | 1.3+ | Ingesting `pizza_menu.csv`, constructing 2D feature matrices, and batch catalog generation |
| `numpy` | 1.20+ | Numerical operations, array slicing, and axis boundary computations |
| `matplotlib` | 3.4+ | Generating actual vs. predicted diagnostic scatter plots in headless mode (`Agg`) |
| `scikit-learn` | 1.0+ | Ordinary Least Squares regression (`LinearRegression`), `train_test_split`, `mean_absolute_error`, `r2_score` |

To install all dependencies at once:
```bash
pip install pandas numpy matplotlib scikit-learn
```

---

## 4. Foundational Concepts to Review

- **Supervised Learning**: Learning an approximating function from labeled examples where both input features ($X$) and ground-truth targets ($y$) are known.
- **Multiple Linear Regression vs. Simple Linear Regression**: Simple regression models one feature to one target ($y = mx + b$, a line in 2D space). Multiple regression models two or more features simultaneously ($y = \beta_0 + \beta_1 x_1 + \beta_2 x_2$, a planar surface in 3D space).
- **The 2D Feature Matrix Rule**: scikit-learn estimators mandate that the feature input $X$ has two dimensions: `(n_samples, n_features)`. In pandas, double brackets `df[["diameter_inches", "toppings"]]` preserve 2D shape, whereas single brackets collapse to a 1D Series.
- **Holdout Validation**: Partitioning data into training (75%) and testing (25%) subsets ensures that performance metrics (MAE and $R^2$) measure generalization on unseen data, not mere memorization.
- **The Model-as-an-API Pattern**: Encapsulating a raw estimator inside a clean function (`quote_pizza`) creates an intuitive software boundary, converting primitive user inputs into properly shaped DataFrames for inference.
