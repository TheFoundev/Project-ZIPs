# The Study Buddy Planner

## Overview
The Study Buddy Planner is an explainable machine learning recommendation system that suggests an optimal study strategy based on a student's current constraints and mental state. Using a `DecisionTreeClassifier` with `max_depth=4` trained on `data/study_situations.csv` from `beginner-projects-main/AI-ML Beginners/projects/20_study_buddy_planner/`, the system maps four intuitive situational variables (`hours_left`, `difficulty`, `energy`, `distraction`) into four distinct action plans: **Deep focus block**, **Practice problems**, **Quick review**, and **Take a break first**.

Unlike black-box models, this decision tree produces human-readable logical rules that allow students and educators to verify, question, and understand exactly why each recommendation is generated.

## Real-World Use Case
Modern students frequently face cognitive overload, burnout, and time management dilemmas. A transparent recommendation engine can guide students toward realistic productivity techniques without pretending to possess mystical authority. When students can inspect the reasoning path behind a recommendation—such as recognizing that low energy calls for rest regardless of the subject—they build metacognitive awareness and trust in AI systems.

## Features (Implemented)
- **Data Loading & Inspection**: Ingests 120 student study scenarios from `data/study_situations.csv`.
- **Stratified Partitioning**: Utilizes `train_test_split(..., test_size=0.25, random_state=42, stratify=y)` to preserve balanced multi-class proportions across training (90 samples) and test (30 samples) sets.
- **Constrained Decision Tree**: Employs `DecisionTreeClassifier(max_depth=4, random_state=42)` to achieve 100% test accuracy while preventing over-complex branching.
- **Dual Execution Modes**:
  - **Scripted Demo Mode (Default)**: Trains the model, evaluates performance, prints learned text rules, evaluates 4 preset benchmark situations, and saves plots.
  - **Interactive CLI Mode (`--interactive`)**: Presents a user-friendly terminal Q&A prompt with robust type and range validation using `ask_situation()`.
- **Explainable Rule Extraction**: Generates an ASCII rule tree via `export_text()` saved directly to `outputs/rules.txt`.
- **Visual Diagramming**: Produces a comprehensive flowchart visualization (`outputs/study_tree.png`) and a multi-class confusion matrix (`outputs/confusion_matrix.png`).

## Technology Stack
- **Language**: Python 3.8+
- **Data Manipulation**: `pandas`
- **Machine Learning**: `scikit-learn` (`DecisionTreeClassifier`, `export_text`, `plot_tree`, `accuracy_score`, `classification_report`, `confusion_matrix`, `ConfusionMatrixDisplay`, `train_test_split`)
- **Visualization**: `matplotlib` (using the headless `"Agg"` backend)
- **System & Path Handling**: `sys`, `pathlib.Path`

## System Requirements
- Operating System: Linux, macOS, or Windows
- Python: Version 3.8 or higher
- Package Manager: `pip`

## Installation Instructions
```bash
# Navigate to the project directory
cd "beginner-projects-main/AI-ML Beginners/projects/20_study_buddy_planner"

# Install required dependencies
pip install pandas scikit-learn matplotlib

# Run the scripted demo
python main.py

# Run the interactive CLI mode
python main.py --interactive
```

## Project Structure (Actual)
```
20_study_buddy_planner/
├── main.py
├── data/
│   └── study_situations.csv
└── outputs/
    ├── confusion_matrix.png
    ├── rules.txt
    └── study_tree.png
```

## How It Works
1. **Setup & Ingestion**: Sets the non-interactive `matplotlib` backend (`"Agg"`), defines paths via `pathlib.Path`, and reads `data/study_situations.csv`.
2. **Feature & Target Matrix**: Isolates the four numeric feature columns (`hours_left`, `difficulty`, `energy`, `distraction`) into $X$ and the target label (`strategy`) into $y$.
3. **Stratified Split**: Splits 120 samples into 90 training samples and 30 testing samples, maintaining proportional representation of all four strategy classes.
4. **Model Training**: Fits a `DecisionTreeClassifier(max_depth=4, random_state=42)` on the training set.
5. **Evaluation**: Evaluates the model on unseen test data, computing accuracy (100.0%) and the multi-class classification report.
6. **Rule Synthesis**: Translates the learned decision splits into indented text rules using `export_text()`.
7. **Preset Demo Scenarios**: Tests 4 diverse student scenarios, printing the inputs and the model's recommended plans.
8. **Artifact Generation**: Saves visual tree diagrams, confusion matrix plots, and text logs to the `outputs/` directory.
9. **Interactive Execution**: When the `--interactive` flag is passed via `sys.argv`, prompts the user with bounded input queries to generate an on-the-spot personalized strategy.

## Expected Output
Running `python main.py` produces:
- High accuracy metric (100.0%) and complete classification report on the console.
- Indented ASCII rule tree demonstrating splits on `hours_left`, `energy`, `distraction`, and `difficulty`.
- Four demo plan evaluations printed cleanly.
- Confirmation of three saved artifacts: `outputs/study_tree.png`, `outputs/confusion_matrix.png`, and `outputs/rules.txt`.

Running `python main.py --interactive` prompts:
```
How many hours do you have left? (1-10) 
How difficult is the subject? (1-5) 
How much energy do you have? (1-5) 
How distracted do you feel? (1-5) 

Suggested strategy: Deep focus block
```

## Security Considerations
- **Local Execution**: All data ingestion, model fitting, and inference execute locally in memory with zero network dependencies or external telemetry.
- **Input Sanitization**: The `ask_situation()` function encapsulates user input in a `try...except ValueError` block and strictly enforces numeric interval checks (`low <= value <= high`), protecting the application from runtime crashes or type injection.
- **No Sensitive Telemetry**: The CSV file contains synthetic, anonymous study attributes with no personally identifiable information (PII).
