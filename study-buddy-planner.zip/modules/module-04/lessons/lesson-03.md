# Lesson 03: Tracing Situation 3 & Situation 4

**Lesson ID:** lesson-03
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Trace Demo Situation 3 step-by-step through the tree rules to arrive at `Take a break first`
- Trace Demo Situation 4 step-by-step through the tree rules to arrive at `Take a break first`
- Contrast internal biological fatigue (Situation 3) with external environmental distraction (Situation 4)
- Explain why two completely different situational profiles terminate at the same strategy label
- Demonstrate how decision trees capture disjunctive concepts (logical OR relationships)

## Prerequisites
- Completion of Lessons 01 and 02 in Module 04
- Understanding of the learned ASCII rules from Module 03

## Concept Explanation

### The Power of Disjunctive Rules (Logical OR)
In educational psychology and cognitive science, two completely different sets of circumstances can lead to the identical operational recommendation. Consider the instruction: **"Take a break first"**.
- A student might need a break because they stayed up until 3:00 AM and have an **energy level of 1** (biological exhaustion).
- Another student might be well-rested with an **energy level of 4**, but is sitting in an airport terminal or loud student lounge with screaming children and blaring announcements (**distraction level of 5**).

Linear models and shallow trees struggle to represent this kind of disjunctive logic without complex interaction terms.
A decision tree, however, naturally captures **logical OR** relationships by creating multiple distinct branches that terminate in the same class label.

```
                          DISJUNCTIVE BREAK LOGIC
                          
                              [ ROOT NODE ]
                           hours_left <= 2.50?
                                   │  False
                                   ▼
                         [ Node 2: energy <= 2.50? ]
                                 ╱           ╲
                         True   ╱             ╲   False
                               ▼               ▼
                        ┌──────────────┐   [ Node 3: distraction <= 3.50? ]
                        │    LEAF 2    │          ╱           ╲
                        │ Take a break │  True   ╱             ╲   False
                        │ (Fatigue)    │        ▼               ▼
                        └──────────────┘       ...       ┌──────────────┐
                                                         │    LEAF 5    │
                                                         │ Take a break │
                                                         │(Distraction) │
                                                         └──────────────┘
```

---

### Deep Dive: Tracing Demo Situation 3 (Fatigue-Driven Break)
- **Input Vector**:
  `{"hours_left": 4, "difficulty": 3, "energy": 1, "distraction": 2}`
- **Student Profile**: The student has 4 hours available, a moderate subject (difficulty 3), and a quiet environment (distraction 2). However, their energy is rated 1 out of 5 (completely drained).

#### Step-by-Step Path Traversal:
1. **Root Node Evaluation**:
   - Condition: `hours_left <= 2.50`
   - Evaluation: $4 \le 2.50 \implies \mathbf{False}$. Transition to `hours_left > 2.50`.
2. **Level 2 Evaluation**:
   - Condition: `energy <= 2.50`
   - Evaluation: $1 \le 2.50 \implies \mathbf{True}$.
3. **Terminal Leaf Reached (Leaf 2)**:
   - Leaf assignment: `class: Take a break first`.
   - Traversal terminates at Depth 2!

#### Pedagogical Validation:
Why does the model prescribe rest when the student still has 4 hours left and a quiet room?
Because working memory depends on prefrontal metabolic stamina. When a student is running on empty (`energy = 1`), cognitive throughput drops near zero. Reading sentences repeatedly without comprehension wastes precious time and increases demoralization. A 30-minute nap, brisk walk, or wholesome meal restores cognitive glucose, allowing the remaining 3.5 hours to be far more productive than 4 hours of drowsy pseudo-studying.

---

### Deep Dive: Tracing Demo Situation 4 (Distraction-Driven Break)
- **Input Vector**:
  `{"hours_left": 8, "difficulty": 2, "energy": 4, "distraction": 5}`
- **Student Profile**: The student has almost an entire day available (8 hours), an easy subject (difficulty 2), and high physical stamina (energy 4). However, their environment is overwhelmingly chaotic (distraction 5).

#### Step-by-Step Path Traversal:
1. **Root Node Evaluation**:
   - Condition: `hours_left <= 2.50`
   - Evaluation: $8 \le 2.50 \implies \mathbf{False}$. Transition to `hours_left > 2.50`.
2. **Level 2 Evaluation**:
   - Condition: `energy <= 2.50`
   - Evaluation: $4 \le 2.50 \implies \mathbf{False}$. Transition to `energy > 2.50`.
3. **Level 3 Evaluation**:
   - Condition: `distraction <= 3.50`
   - Evaluation: $5 \le 3.50 \implies \mathbf{False}$. Transition to `distraction > 3.50`.
4. **Terminal Leaf Reached (Leaf 5)**:
   - Leaf assignment: `class: Take a break first`.
   - Traversal terminates at Depth 3!

#### Pedagogical Validation:
Why does the model recommend taking a break when the student has 8 hours, high energy, and easy material?
Because attention is a vulnerable resource. Under a distraction level of 5 (loud music, people talking, phone pinging every 30 seconds), human attention is repeatedly hijacked. Studies show that after an interruption, it takes an average of 23 minutes to regain deep focus.
The model wisely instructs the student to pause first (`Take a break first`)—which in this context means stepping away from the chaotic environment, turning off devices, or relocating to a quiet library before opening their books.

## Relevant Code (from main.py, lines 82-83 and 87-89)
```python
demo_situations = pd.DataFrame(
    [
        # ...
        {"hours_left": 4, "difficulty": 3, "energy": 1, "distraction": 2},
        {"hours_left": 8, "difficulty": 2, "energy": 4, "distraction": 5},
    ]
)
# ...
demo_predictions = model.predict(demo_situations)
print(f"  {demo_situations.iloc[2].to_dict()} -> {demo_predictions[2]}")
print(f"  {demo_situations.iloc[3].to_dict()} -> {demo_predictions[3]}")
```

## Code Explanation
- **Lines 82-83**: Encodes Demo Situations 3 and 4 into the test DataFrame.
- **Lines 87-89**: Evaluates both situations through `model.predict()`, printing `Take a break first` for both cases.
- **Auditing**: Confirms that although both situations output the identical recommendation string, they arrived via completely different internal pathways (Leaf 2 vs Leaf 5).

## Worked Example: Comparing Situations 3 and 4
Let us construct a comparison table highlighting the disjunctive reasoning:

| Attribute | Situation 3 | Situation 4 | Contrast |
|---|---|---|---|
| `hours_left` | 4 hours | 8 hours | Situation 4 has twice as much time |
| `difficulty` | 3 (Moderate) | 2 (Easy) | Situation 3 is more demanding |
| `energy` | **1 (Exhausted)** | **4 (Alert)** | **Situation 3 fails on energy** |
| `distraction` | **2 (Quiet)** | **5 (Chaotic)** | **Situation 4 fails on distraction** |
| Terminating Node | Node 2 (`energy <= 2.50`) | Node 3 (`distraction > 3.50`) | Different depths and questions |
| Resulting Leaf | Leaf 2 | Leaf 5 | Distinct physical leaves |
| Recommendation | `Take a break first` | `Take a break first` | Identical actionable guidance |

This comparison elegantly demonstrates how a decision tree captures multiple root causes for the same behavioral recommendation.

## Step-by-Step Student Instructions
1. In an interactive Python session, construct DataFrames for Situations 3 and 4:
   ```python
   import pandas as pd
   s3 = pd.DataFrame([{"hours_left": 4, "difficulty": 3, "energy": 1, "distraction": 2}])
   s4 = pd.DataFrame([{"hours_left": 8, "difficulty": 2, "energy": 4, "distraction": 5}])
   ```
2. Predict the strategies using the fitted `model`:
   ```python
   print("Situation 3:", model.predict(s3)[0])
   print("Situation 4:", model.predict(s4)[0])
   ```
3. Use scikit-learn's `decision_path()` method to inspect the node indices traversed:
   ```python
   dp3 = model.decision_path(s3).toarray()
   dp4 = model.decision_path(s4).toarray()
   print("Nodes traversed by S3:", dp3.nonzero()[1])
   print("Nodes traversed by S4:", dp4.nonzero()[1])
   ```
4. Observe that the list of traversed node IDs is completely different for S3 and S4!

## Expected Output or Observable Behaviour
Python displays:
```
Situation 3: Take a break first
Situation 4: Take a break first
Nodes traversed by S3: [0 2 3]
Nodes traversed by S4: [0 2 4 8]
```
The node traversal arrays confirm that Situation 3 terminates at Node 3 (Leaf 2), while Situation 4 cascades past Node 4 and terminates at Node 8 (Leaf 5).

## Practical Exercises
- **Exercise 3.1**: If Situation 3's energy was increased from 1 to 4, which leaf node and strategy would it reach?
- **Exercise 3.2**: If Situation 4's distraction was decreased from 5 to 1, which leaf node and strategy would it reach?
- **Exercise 3.3**: Why is taking a break before studying often more effective than studying through severe fatigue or chaos? Cite one cognitive science principle.

## Common Mistakes and Debugging
| Mistake | Why it happens | Correction |
|---|---|---|
| Assuming same prediction means same decision path | Overlooking multi-leaf tree topology | Check node traversal with `decision_path()` to see distinct branches. |
| Thinking high hours always permits studying | Ignoring biological/environmental constraints | Recognize that energy and quiet are strict prerequisites for studying regardless of time available. |
| Confusing node IDs with depth | Treating node index 8 as depth 8 | Note that node numbering is sequential across all nodes; depth remains $\le 4$. |

## Best Practices
- **Inspect Disjunctive Leaf Paths**: When multiple leaves predict the same class, document each path clearly so users understand the distinct circumstances triggering the advice.
- **Use `decision_path()` for Programmatic Audits**: scikit-learn's sparse matrix `decision_path()` enables automated tracing in production environments.

## Security Considerations
- **Transparent Justification for Negative Outcomes**: If an AI system denies permission or recommends stepping away from a task, providing the specific reason (fatigue vs environmental disruption) prevents user alienation.

## Summary
Demo Situations 3 and 4 demonstrate how decision trees represent logical OR relationships. Situation 3 triggers a break recommendation at Depth 2 due to biological exhaustion (`energy = 1`), despite quiet conditions. Situation 4 triggers a break recommendation at Depth 3 due to environmental disruption (`distraction = 5`), despite high energy and ample time. Both terminate at `Take a break first` through distinct, verifiable pathways.

## Knowledge-check Questions
1. What study strategy is recommended for both Demo Situation 3 and Demo Situation 4?
2. What specific condition triggers the break recommendation in Demo Situation 3?
3. What specific condition triggers the break recommendation in Demo Situation 4?
4. At what tree depth does Demo Situation 3 terminate versus Demo Situation 4?
5. What scikit-learn method allows programmatic inspection of the exact node IDs traversed by a sample?

## References
- Mark, G., Gudith, D., & Klocke, U. (2008). "The Cost of Interrupted Work: More Speed and Stress". *ACM CHI*.
- scikit-learn `decision_path` Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.tree.DecisionTreeClassifier.html#sklearn.tree.DecisionTreeClassifier.decision_path
- Project 20 code: `main.py` lines 82-83.
