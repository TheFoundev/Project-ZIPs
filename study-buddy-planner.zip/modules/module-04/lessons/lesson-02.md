# Lesson 02: Tracing Situation 1 & Situation 2

**Lesson ID:** lesson-02
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Trace Demo Situation 1 step-by-step through the decision tree logic to arrive at `Quick review`
- Trace Demo Situation 2 step-by-step through all four tree levels to arrive at `Practice problems`
- Explain why available time overrides high difficulty and moderate energy in Situation 1
- Explain how high stamina, calm environment, and complex material combine to trigger `Practice problems` in Situation 2
- Connect each step of the manual trace to the corresponding line in `export_text`

## Prerequisites
- Completion of Lesson 01 in Module 04
- Familiarity with the learned ASCII rules from Module 03

## Concept Explanation

### The Logic of Algorithmic Tracing
When validating an Explainable AI recommendation engine, data scientists must perform **tracing**—manually walking an input vector through each conditional test in the decision tree. Tracing guarantees that the model's predictions align with domain expertise and verifies that the model has not learned spurious shortcuts.

Let us recall the learned ASCII rule tree from `main.py`:
```
|--- hours_left <= 2.50
|   |--- class: Quick review
|--- hours_left >  2.50
|   |--- energy <= 2.50
|   |   |--- class: Take a break first
|   |--- energy >  2.50
|   |   |--- distraction <= 3.50
|   |   |   |--- difficulty <= 3.50
|   |   |   |   |--- class: Deep focus block
|   |   |   |--- difficulty >  3.50
|   |   |   |   |--- class: Practice problems
|   |   |--- distraction >  3.50
|   |   |   |--- class: Take a break first
```

```
                          TRACING SITUATION 1 & 2
                          
      SITUATION 1: hours_left = 2, diff = 4, energy = 3, dist = 2
      [Root: hours_left <= 2.50?] ──► TRUE ──► [LEAF: Quick review]
      
      SITUATION 2: hours_left = 6, diff = 5, energy = 4, dist = 1
      [Root: hours_left <= 2.50?] ──► FALSE (hours_left > 2.50)
                   │
                   ▼
      [Node 2: energy <= 2.50?]  ──► FALSE (energy > 2.50)
                   │
                   ▼
      [Node 3: distraction <= 3.50?] ──► TRUE
                   │
                   ▼
      [Node 4: difficulty <= 3.50?]  ──► FALSE (diff > 3.50)
                   │
                   ▼
      [LEAF: Practice problems]
```

### Deep Dive: Tracing Demo Situation 1
- **Input Vector**:
  `{"hours_left": 2, "difficulty": 4, "energy": 3, "distraction": 2}`
- **Student Profile**: The student is studying a difficult subject (difficulty 4), feels moderately alert (energy 3), and has a quiet room (distraction 2). However, they only have 2 hours left before their deadline.

#### Step-by-Step Path Traversal:
1. **Root Node Evaluation**:
   - Condition: `hours_left <= 2.50`
   - Evaluation: $2 \le 2.50 \implies \mathbf{True}$
2. **Terminal Leaf Reached**:
   - Leaf assignment: `class: Quick review`
   - Traversal terminates immediately at Depth 1!

#### Pedagogical Validation:
Why does the model ignore the student's high subject difficulty (4) and reasonable energy (3)?
In cognitive science, 2 hours is insufficient to set up, work through, and reflect on demanding, multi-step problem sets for a difficult subject. Attempting to start complex problem sets under a tight 2-hour deadline produces acute time anxiety and fragmented learning. The model wisely deduces that rapid, focused revision of high-yield concepts or summary sheets (`Quick review`) delivers the highest learning retention per minute.

---

### Deep Dive: Tracing Demo Situation 2
- **Input Vector**:
  `{"hours_left": 6, "difficulty": 5, "energy": 4, "distraction": 1}`
- **Student Profile**: The student has 6 uninterrupted hours, is well-rested and alert (energy 4), is in a silent library (distraction 1), and is confronting an extremely challenging topic (difficulty 5).

#### Step-by-Step Path Traversal:
1. **Root Node Evaluation**:
   - Condition: `hours_left <= 2.50`
   - Evaluation: $6 \le 2.50 \implies \mathbf{False}$. Transition to `hours_left > 2.50`.
2. **Level 2 Evaluation**:
   - Condition: `energy <= 2.50`
   - Evaluation: $4 \le 2.50 \implies \mathbf{False}$. Transition to `energy > 2.50`.
3. **Level 3 Evaluation**:
   - Condition: `distraction <= 3.50`
   - Evaluation: $1 \le 3.50 \implies \mathbf{True}$. Transition to `distraction <= 3.50`.
4. **Level 4 Evaluation**:
   - Condition: `difficulty <= 3.50`
   - Evaluation: $5 \le 3.50 \implies \mathbf{False}$. Transition to `difficulty > 3.50`.
5. **Terminal Leaf Reached**:
   - Leaf assignment: `class: Practice problems`
   - Traversal terminates at Depth 4!

#### Pedagogical Validation:
This scenario represents ideal conditions for deliberate practice:
- 6 hours provides ample time to engage deeply without watching the clock.
- Energy level 4 provides the stamina needed to struggle through difficult problems without cognitive exhaustion.
- Distraction level 1 protects working memory from context-switching overhead.
- Difficulty level 5 demands active recall and application rather than passive reading.
The model correctly recommends **Practice problems**.

## Relevant Code (from main.py, lines 78-81 and 87-89)
```python
demo_situations = pd.DataFrame(
    [
        {"hours_left": 2, "difficulty": 4, "energy": 3, "distraction": 2},
        {"hours_left": 6, "difficulty": 5, "energy": 4, "distraction": 1},
        # ...
    ]
)
# ...
demo_predictions = model.predict(demo_situations)
print(f"  {demo_situations.iloc[0].to_dict()} -> {demo_predictions[0]}")
print(f"  {demo_situations.iloc[1].to_dict()} -> {demo_predictions[1]}")
```

## Code Explanation
- **Lines 78-81**: Defines the first two rows of `demo_situations`.
- **`model.predict()`**: Traverses the internal C-level tree pointer network for each row, returning `"Quick review"` for row 0 and `"Practice problems"` for row 1.
- **Printed Output**: Formats each dictionary alongside its corresponding strategy prediction.

## Worked Example
Let us test what happens if we slightly modify Situation 2 by changing `difficulty` from 5 to 2:
- Inputs: `hours_left = 6, energy = 4, distraction = 1, difficulty = 2`
1. `hours_left <= 2.50`: False
2. `energy <= 2.50`: False
3. `distraction <= 3.50`: True
4. `difficulty <= 3.50`: $2 \le 3.50 \implies \mathbf{True}$!
5. Leaf reached: **`Deep focus block`**!

Notice that simply dropping subject difficulty from 5 to 2 shifted the recommendation from active problem sets to conceptual immersion (`Deep focus block`). The model exhibits sensitive, appropriate behavioral tuning.

## Step-by-Step Student Instructions
1. Open Python and replicate the first two demo situations:
   ```python
   import pandas as pd
   s1 = pd.DataFrame([{"hours_left": 2, "difficulty": 4, "energy": 3, "distraction": 2}])
   s2 = pd.DataFrame([{"hours_left": 6, "difficulty": 5, "energy": 4, "distraction": 1}])
   ```
2. Predict the strategies using the trained `model`:
   ```python
   print("Situation 1:", model.predict(s1)[0])
   print("Situation 2:", model.predict(s2)[0])
   ```
3. Verify that Situation 1 outputs `Quick review` and Situation 2 outputs `Practice problems`.
4. Open `outputs/rules.txt` and locate the matching text lines in the demo plans section.

## Expected Output or Observable Behaviour
Python displays:
```
Situation 1: Quick review
Situation 2: Practice problems
```
In `outputs/rules.txt`, the demo plans section records:
```txt
demo plans:
{'hours_left': 2, 'difficulty': 4, 'energy': 3, 'distraction': 2} -> Quick review
{'hours_left': 6, 'difficulty': 5, 'energy': 4, 'distraction': 1} -> Practice problems
```

## Practical Exercises
- **Exercise 2.1**: In Situation 1, what would happen if the student's energy increased from 3 to 5? Trace the rules and explain why the prediction does not change.
- **Exercise 2.2**: In Situation 2, what would happen if the distraction level increased from 1 to 4? Which branch would be taken at Level 3?
- **Exercise 2.3**: Write out the mathematical decision path for Situation 2 as a single boolean expression (e.g. `(hours_left > 2.50) and ...`).

## Common Mistakes and Debugging
| Mistake | Why it happens | Correction |
|---|---|---|
| Assuming Situation 1 checks difficulty | Forgetting that the tree short-circuits at root | Realize that if `hours_left <= 2.50`, no other features are ever evaluated. |
| Misinterpreting `difficulty > 3.50` | Thinking 3 is greater than 3.50 | 3 is $\le 3.50$ (Deep focus); only 4 and 5 satisfy $> 3.50$ (Practice problems). |
| Expecting Situation 2 to recommend Deep Focus | Overlooking subject difficulty level 5 | Remember that high difficulty triggers active practice problems rather than passive focus. |

## Best Practices
- **Verify Short-Circuit Paths**: Trace shallow leaves carefully to ensure that features bypassed by early branches (like difficulty in Situation 1) genuinely should not influence the decision.
- **Validate Deep Leaves on Real Edge Cases**: Verify that scenarios reaching maximum depth satisfy every prerequisite condition along the chain.

## Security Considerations
- **Transparent Audit Trails**: Being able to demonstrate the exact four-step trace for Situation 2 satisfies regulatory requirements (such as the EU AI Act) for explainable algorithmic decisions.

## Summary
Demo Situation 1 demonstrates root-level short-circuiting: because available time is limited to 2 hours, the tree immediately outputs `Quick review` regardless of difficulty or energy. Demo Situation 2 traverses the maximum depth of the tree: having ample time, high energy, and minimal distraction, the student confronts a high-difficulty subject, leading the model to prescribe intensive `Practice problems`.

## Knowledge-check Questions
1. Why does Demo Situation 1 only evaluate one single feature (`hours_left`) before terminating?
2. What strategy does the model recommend for Demo Situation 1?
3. How many decision nodes must be evaluated to arrive at the prediction for Demo Situation 2?
4. What strategy is recommended for Demo Situation 2, and why?
5. If subject difficulty in Demo Situation 2 was changed from 5 to 2, what strategy would be recommended?

## References
- Dunlosky, J. et al. (2013). "Improving Students' Learning with Effective Learning Techniques". *Psychological Science in the Public Interest*.
- scikit-learn Decision Path Extraction: https://scikit-learn.org/stable/modules/generated/sklearn.tree.DecisionTreeClassifier.html#sklearn.tree.DecisionTreeClassifier.decision_path
- Project 20 code: `main.py` lines 78-81.
