# Lesson 01: The Scripted Demo Architecture

**Lesson ID:** lesson-01
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why applied machine learning applications must support non-interactive scripted execution
- Describe how `main.py` provides automated verification via preset benchmark scenarios
- Contrast scripted execution with interactive loops in software deployment and automated testing
- Explain how constructing a pandas DataFrame of benchmark scenarios enables batch inference
- Identify the four preset demo situations defined in `main.py`

## Prerequisites
- Completion of Modules 01, 02, and 03
- Familiarity with executing Python scripts from the command line

## Concept Explanation

### The Need for Scripted, Non-Interactive Defaults
In software engineering and data science, applications must often run in environments where **no human is present at the keyboard**. Consider these scenarios:
1. **Continuous Integration (CI) and Regression Testing**: Every time a developer modifies `main.py` or updates `study_situations.csv`, an automated testing bot (like GitHub Actions) runs `python main.py` to ensure the code executes with exit code 0 and achieves expected accuracy. If `main.py` blocked immediately waiting for interactive user keyboard input, the automated build would hang indefinitely and time out.
2. **Reproducible Benchmarking**: To verify that a model behaves identically across different operating systems, developers require a deterministic set of test cases with known inputs and expected outputs.
3. **Classroom Demonstrations and Grading**: Instructors and grading autograders need to run student submissions in batch mode without manually typing inputs for each student.

For these reasons, `main.py` is architected with a **scripted demo mode as the default behavior**, reserving interactive prompt loops for when the user explicitly passes the `--interactive` flag.

```
                           EXECUTION FLOW MODES
                           
                        Terminal Execution Command
                                    │
                        Is "--interactive" in sys.argv?
                                   ╱ ╲
                          No      ╱   ╲     Yes
                                 ▼     ▼
                        [ SCRIPTED DEMO ]     [ INTERACTIVE CLI ]
                        Run 4 preset cases     Prompt 4 questions
                        Print Demo Plans       Predict user plan
                        Generate Artifacts     Generate Artifacts
```

### The 4 Preset Benchmark Scenarios
To showcase the decision tree's capabilities without requiring user typing, `main.py` embeds four concrete, diverse student situations directly in code (lines 78-85):

```python
demo_situations = pd.DataFrame(
    [
        {"hours_left": 2, "difficulty": 4, "energy": 3, "distraction": 2},
        {"hours_left": 6, "difficulty": 5, "energy": 4, "distraction": 1},
        {"hours_left": 4, "difficulty": 3, "energy": 1, "distraction": 2},
        {"hours_left": 8, "difficulty": 2, "energy": 4, "distraction": 5},
    ]
)
```

Notice the intentional diversity of these four scenarios:
- **Situation 1**: Tests time scarcity (`hours_left = 2`), checking whether the model prioritizes time limits above all else.
- **Situation 2**: Tests optimal problem-solving conditions (`hours_left = 6, difficulty = 5, energy = 4, distraction = 1`), checking if the deepest branch (`Practice problems`) is triggered.
- **Situation 3**: Tests internal fatigue (`energy = 1`), checking if low stamina properly triggers rest even when time is available and subject difficulty is moderate.
- **Situation 4**: Tests environmental chaos (`distraction = 5`), checking if severe distraction triggers rest even when time is plentiful (8 hours) and energy is high (4).

Together, these four situations exercise all major pathways of the decision tree!

### Vectorized Batch Inference
Rather than predicting scenarios one at a time inside a loop, `main.py` bundles the four dictionaries into a single pandas DataFrame:
```python
demo_predictions = model.predict(demo_situations)
```
This is **vectorized batch inference**. scikit-learn passes the entire 4-row matrix through the decision tree in a single optimized C-level operation, returning an array of four predicted strategy labels.

## Relevant Code (from main.py, lines 78-90)
```python
demo_situations = pd.DataFrame(
    [
        {"hours_left": 2, "difficulty": 4, "energy": 3, "distraction": 2},
        {"hours_left": 6, "difficulty": 5, "energy": 4, "distraction": 1},
        {"hours_left": 4, "difficulty": 3, "energy": 1, "distraction": 2},
        {"hours_left": 8, "difficulty": 2, "energy": 4, "distraction": 5},
    ]
)
demo_predictions = model.predict(demo_situations)
print("Demo plans:")
for situation, plan in zip(demo_situations.to_dict("records"), demo_predictions):
    print(f"  {situation} -> {plan}")
```

## Code Explanation
- **Lines 78-85**: Constructs `demo_situations` as a 4-row DataFrame whose column keys exactly match `FEATURES`.
- **Line 86**: Performs batch prediction on all 4 scenarios simultaneously using `model.predict()`.
- **Lines 87-90**: Iterates over paired input dictionaries and predictions using Python's built-in `zip()`, printing each scenario alongside its recommended plan.

## Worked Example
Let us trace what the console prints when lines 87-90 execute:
```
Demo plans:
  {'hours_left': 2, 'difficulty': 4, 'energy': 3, 'distraction': 2} -> Quick review
  {'hours_left': 6, 'difficulty': 5, 'energy': 4, 'distraction': 1} -> Practice problems
  {'hours_left': 4, 'difficulty': 3, 'energy': 1, 'distraction': 2} -> Take a break first
  {'hours_left': 8, 'difficulty': 2, 'energy': 4, 'distraction': 5} -> Take a break first
```
Notice how clean and readable this output is: any evaluator can immediately verify that all 4 scenarios received sensible, deterministic recommendations.

## Step-by-Step Student Instructions
1. Open terminal and run `python main.py`.
2. Locate the console block under `Demo plans:`.
3. Verify that all 4 demo scenarios are printed.
4. Check that each line displays a complete feature dictionary followed by `->` and the predicted strategy string.
5. Confirm that the script exits cleanly without waiting for keyboard input.

## Expected Output or Observable Behaviour
The terminal outputs:
```
============================================================
THE STUDY BUDDY PLANNER
============================================================
Accuracy: 100.0%
...
Demo plans:
  {'hours_left': 2, 'difficulty': 4, 'energy': 3, 'distraction': 2} -> Quick review
  {'hours_left': 6, 'difficulty': 5, 'energy': 4, 'distraction': 1} -> Practice problems
  {'hours_left': 4, 'difficulty': 3, 'energy': 1, 'distraction': 2} -> Take a break first
  {'hours_left': 8, 'difficulty': 2, 'energy': 4, 'distraction': 5} -> Take a break first
```
The entire script finishes in under 2 seconds.

## Practical Exercises
- **Exercise 1.1**: Add a 5th scenario to `demo_situations` representing `hours_left: 6, difficulty: 2, energy: 4, distraction: 1`. What strategy does the model predict, and why?
- **Exercise 1.2**: Why is batch inference using `model.predict(df)` preferred over calling `model.predict()` four separate times in a loop?
- **Exercise 1.3**: What would happen if one of the dictionaries in `demo_situations` had a typo in a key name, such as `"hour_left"` instead of `"hours_left"`? Test this and observe the pandas/scikit-learn error.

## Common Mistakes and Debugging
| Mistake | Why it happens | Correction |
|---|---|---|
| Column name mismatch in demo DataFrame | Misspelling a key (e.g. `"distractions"`) | Ensure dictionary keys match `FEATURES` exactly. |
| Passing a list of dictionaries directly to `predict` | Forgetting `pd.DataFrame(...)` | scikit-learn estimators require a 2D array or DataFrame with matching feature names. |
| Designing benchmark cases that test only one branch | Testing 4 nearly identical scenarios | Ensure benchmark test suites exercise diverse edge cases across the entire model. |

## Best Practices
- **Design Balanced Smoke Test Suites**: Include concrete benchmark scenarios that exercise all major branches and output classes of your model.
- **Default to Non-Interactive Execution**: Scripts should run to completion without user prompts unless specifically flagged, enabling automated CI testing.

## Security Considerations
- **Deterministic Test Suites Prevent Regressions**: Hardcoded benchmark test cases prevent unintentional logic drifts when refactoring codebase components or retraining models.

## Summary
The scripted demo mode in `main.py` provides a non-interactive default execution path essential for automated testing, CI/CD pipelines, and benchmarking. By executing batch inference on four carefully selected benchmark situations, the application demonstrates that the decision tree correctly handles time limits, high-difficulty problem sets, physical exhaustion, and environmental chaos.

## Knowledge-check Questions
1. Why is scripted, non-interactive execution critical for automated CI/CD build environments?
2. How does `main.py` construct the benchmark scenarios for batch prediction?
3. What are the four target predictions output for the four demo situations?
4. How does vectorized batch inference compare to single-sample loop inference?
5. Which demo situation tests the model's behavior under severe environmental distraction?

## References
- Fowler, M. (2006). "Continuous Integration". *ThoughtWorks*.
- scikit-learn `predict` Vectorization: https://scikit-learn.org/stable/modules/generated/sklearn.tree.DecisionTreeClassifier.html#sklearn.tree.DecisionTreeClassifier.predict
- Project 20 code: `main.py` lines 78-90.
