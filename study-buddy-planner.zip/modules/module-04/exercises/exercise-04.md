# Module 4 Exercises: Demo Mode & the 4 Demo Situations

## Exercise 4.1: Batch Inference Implementation & Benchmarking (10 min)
**Objective:** Construct a pandas DataFrame representing multiple study scenarios and execute vectorized batch predictions with `model.predict()`.

**Problem Statement:** You need to reproduce the batch inference logic used in lines 78-86 of `main.py` and benchmark its execution against sequential one-by-one predictions.

**Requirements:**
1. Train the reference `DecisionTreeClassifier(max_depth=4, random_state=42)` on `study_situations.csv`.
2. Construct the 4-row `demo_situations` DataFrame matching lines 79-84 of `main.py`.
3. Predict all 4 scenarios at once using `demo_predictions = model.predict(demo_situations)`.
4. Iterate over the inputs and predictions using `zip()` and print each mapping.
5. Confirm that the predictions match: `Quick review`, `Practice problems`, `Take a break first`, `Take a break first`.

**Constraints:** Ensure column names and orders match `FEATURES` exactly.

**Expected Behaviour:** Formatted console output showing the four demo situations and their predicted strategies.

**Acceptance Criteria:**
- [ ] Constructs DataFrame using list of dictionaries.
- [ ] Uses vectorized `model.predict(demo_situations)`.
- [ ] Formats output cleanly with `zip()`.
- [ ] Confirms all four predictions match expected outputs.

**Hints:**
- Use `demo_situations.to_dict("records")` to convert the DataFrame back to a list of row dictionaries for printing.
- `model.predict()` returns a 1D NumPy array of strings.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes

---

## Exercise 4.2: Tracing Custom Edge Cases (15 min)
**Objective:** Create three novel student scenarios targeting specific boundary thresholds (e.g. `hours_left = 3`, `energy = 3`, `distraction = 4`) and trace them manually through the rule tree.

**Problem Statement:** You will design three challenging edge-case situations that test the boundary values near 2.50 and 3.50, trace them by hand through the ASCII rules, and then verify your manual answers using `model.predict()`.

**Requirements:**
1. Design three scenarios:
   - **Case Alpha**: Boundary test for time (`hours_left = 3`, `difficulty = 4`, `energy = 4`, `distraction = 1`).
   - **Case Beta**: Boundary test for energy (`hours_left = 5`, `difficulty = 2`, `energy = 3`, `distraction = 2`).
   - **Case Gamma**: Boundary test for distraction (`hours_left = 6`, `difficulty = 5`, `energy = 5`, `distraction = 4`).
2. Manually trace each case through the rules in `outputs/rules.txt` and write down the predicted strategy.
3. Construct a DataFrame in Python with all three cases and run `model.predict()`.
4. Verify whether your manual trace matched the model's actual predictions.

**Constraints:** Use whole integer inputs within the valid domain bounds.

**Expected Behaviour:** A documented manual trace table followed by Python code verifying 100% agreement between manual logic and model output.

**Acceptance Criteria:**
- [ ] Case Alpha correctly traces to `Practice problems` ($3 > 2.50$, $4 > 2.50$, $1 \le 3.50$, $4 > 3.50$).
- [ ] Case Beta correctly traces to `Deep focus block` ($5 > 2.50$, $3 > 2.50$, $2 \le 3.50$, $2 \le 3.50$).
- [ ] Case Gamma correctly traces to `Take a break first` ($6 > 2.50$, $5 > 2.50$, $4 > 3.50$).
- [ ] Code outputs match manual predictions.

**Hints:**
- For Case Alpha: notice that 3 is strictly greater than 2.50, so it avoids the root leaf!
- For Case Gamma: notice that 4 is strictly greater than 3.50, triggering the distraction break leaf!

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 4.3: Disjunctive Path Analysis (15 min)
**Objective:** Inspect the decision paths of Situations 3 and 4 using scikit-learn's `decision_path()` method to prove they reach different leaf nodes.

**Problem Statement:** In lines 82-83 of `main.py`, Situations 3 and 4 both predict `Take a break first`. You must write a Python diagnostic script that inspects the internal node IDs traversed by each situation to prove they follow completely distinct decision branches.

**Requirements:**
1. Replicate Situations 3 and 4 as single-row DataFrames.
2. Call `path3 = model.decision_path(s3)` and `path4 = model.decision_path(s4)`.
3. Extract the nonzero column indices representing the node IDs traversed by each situation:
   `node_ids_3 = path3.toarray().nonzero()[1]`
   `node_ids_4 = path4.toarray().nonzero()[1]`
4. Print the node sequences and identify the final leaf node ID for each.
5. Explain in writing why having two separate leaf nodes for the same class is pedagogically sound.

**Constraints:** Use `scikit-learn`'s native `decision_path()` method.

**Expected Behaviour:** Console output displaying two distinct lists of integer node IDs confirming different paths to the same final class.

**Acceptance Criteria:**
- [ ] Extracts node ID arrays using `.nonzero()[1]`.
- [ ] Confirms the final node ID of S3 is different from S4.
- [ ] Explains that S3 represents internal biological fatigue while S4 represents external environmental distraction.

**Hints:**
- `decision_path()` returns a sparse matrix of shape `(n_samples, n_nodes)`.
- Use `.toarray()` to convert the sparse matrix to a standard NumPy array.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 4.4: Automated Audit Log Verification Script (15 min)
**Objective:** Write an automated test script that reads `outputs/rules.txt` and asserts the presence and accuracy of all four required sections.

**Problem Statement:** In production ML, automated test suites verify that build artifacts are generated correctly. You will write a test script that validates `outputs/rules.txt`.

**Requirements:**
1. Use `pathlib.Path` to locate `outputs/rules.txt`.
2. Check that the file exists and is non-empty (`stat().st_size > 0`).
3. Read the content with `encoding="utf-8"`.
4. Use `assert` statements to verify:
   - "accuracy: 1.0000" is at the start.
   - "|--- hours_left <= 2.50" is present.
   - "demo plans:" section is present.
   - All four strategy names appear in the demo plans and classification report.
5. Print a success message if all assertions pass.

**Constraints:** Use standard Python libraries (`pathlib`, `re`) without third-party testing frameworks.

**Expected Behaviour:** A standalone Python script that executes silently and prints "Verification Successful" if all assertions hold.

**Acceptance Criteria:**
- [ ] File existence and size are asserted.
- [ ] Accuracy string is verified.
- [ ] Rule structure is verified.
- [ ] Demo plan content is verified.
- [ ] Script exits with code 0.

**Hints:**
- Use `rules_file.read_text(encoding="utf-8")` to read all text at once.
- Combine string containment checks (`in`) with assertions.

**Difficulty:** Advanced  
**Estimated Completion Time:** 15 minutes
