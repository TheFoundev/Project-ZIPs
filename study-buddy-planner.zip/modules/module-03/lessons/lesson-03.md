# Lesson 03: Decoding ASCII Tree Rules via `export_text`

**Lesson ID:** lesson-03
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain the role and utility of scikit-learn's `export_text` function in Explainable AI (XAI)
- Interpret the ASCII tree formatting, indentation levels, and pipe characters (`|---`)
- Translate each branch of the learned tree into equivalent Python `if-elif-else` control flow
- Verify that every possible student input maps deterministically to exactly one leaf class
- Trace why the tree contains five terminal leaf nodes across four unique classes

## Prerequisites
- Completion of Lessons 01 and 02 in Module 03
- Familiarity with reading indented programming code

## Concept Explanation

### What is `export_text`?
In machine learning, model weights in complex architectures (like neural networks or gradient boosted ensembles) are stored as opaque multidimensional floating-point tensors. You cannot easily read them or print them out as human language.
However, a decision tree is fundamentally a collection of threshold comparisons. To make these comparisons transparent, `sklearn.tree.export_text()` traverses the trained internal tree structure and formats it as an indented, human-readable ASCII outline.

```python
from sklearn.tree import export_text
rule_text = export_text(model, feature_names=FEATURES)
```
Passing `feature_names=FEATURES` ensures that the printout displays meaningful names (`hours_left`, `energy`, etc.) rather than generic placeholder tokens (`feature_0`, `feature_1`).

### Anatomy of ASCII Tree Notation
Let us examine the complete rule text produced by `main.py`:
```
|--- hours_left <= 2.50
|   |--- class: Quick review
|--- hours_left >  2.50
|   |--- energy <= 2.50
|   |   |--- class: Take a break first
|   |--- energy >  2.50
|   |   |--- distraction <= 3.50
|   |   |   |--- difficulty <= 3.50
|   |   |   |   |--- class: Deep focus block
|   |   |   |--- difficulty >  3.50
|   |   |   |   |--- class: Practice problems
|   |   |--- distraction >  3.50
|   |   |   |--- class: Take a break first
```

Notice the structural conventions:
1. **Pipes and Dashes (`|---`)**: Mark the start of a conditional test or a terminal class assignment.
2. **Indentation Depth**: Each level of indentation (four characters: `|   `) represents one step deeper into the tree hierarchy:
   - Zero indentation: Depth 1 (Root node)
   - One pipe indent (`|   |---`): Depth 2
   - Two pipe indents (`|   |   |---`): Depth 3
   - Three pipe indents (`|   |   |   |---`): Depth 4
3. **Threshold Tests**: Displayed as `<feature_name> <= <threshold>` on the primary branch and `<feature_name> > <threshold>` on the opposing branch.
4. **Leaf Outputs (`class: <name>`)**: Designate a terminal endpoint that delivers the final strategy recommendation.

### Five Leaves for Four Classes
Carefully observe the leaf nodes in the rule printout:
1. Leaf 1: `class: Quick review` (under `hours_left <= 2.50`)
2. Leaf 2: `class: Take a break first` (under `hours_left > 2.50` and `energy <= 2.50`)
3. Leaf 3: `class: Deep focus block` (under `hours_left > 2.50`, `energy > 2.50`, `distraction <= 3.50`, `difficulty <= 3.50`)
4. Leaf 4: `class: Practice problems` (under `hours_left > 2.50`, `energy > 2.50`, `distraction <= 3.50`, `difficulty > 3.50`)
5. Leaf 5: `class: Take a break first` (under `hours_left > 2.50`, `energy > 2.50`, `distraction > 3.50`)

Notice that `Take a break first` appears in **two different leaf nodes** (Leaf 2 and Leaf 5)!
Why? Because there are two distinct pedagogical reasons to take a break:
- **Reason 1 (Leaf 2)**: The student has ample time, but is physically or mentally exhausted (`energy <= 2.50`).
- **Reason 2 (Leaf 5)**: The student has ample time and high energy, but the physical environment is too chaotic or distracting (`distraction > 3.50`).

The decision tree correctly captured both distinct real-world pathways to the same recommendation.

## Relevant Code (from main.py, lines 75-76 and 117-124)
```python
# Lines 75-76:
print("Learned rules:\n")
print(export_text(model, feature_names=FEATURES))

# Lines 117-124:
with open(OUT / "rules.txt", "w", encoding="utf-8") as handle:
    handle.write(f"accuracy: {accuracy:.4f}\n\n")
    handle.write(export_text(model, feature_names=FEATURES))
    handle.write("\ndemo plans:\n")
    for situation, plan in zip(demo_situations.to_dict("records"), demo_predictions):
        handle.write(f"{situation} -> {plan}\n")
    handle.write("\n" + classification_report(y_test, predictions, zero_division=0))
```

## Code Explanation
- **Lines 75-76**: Invokes `export_text()` and streams the formatted ASCII string directly to standard output.
- **Lines 117-124**: Opens `outputs/rules.txt` with UTF-8 encoding and persists the ASCII rules alongside test accuracy, demo outputs, and the full classification report, providing an immutable audit artifact.

## Worked Example: Translating to Pure Python
We can translate the ASCII rules directly into a standard Python function:

```python
def rule_based_study_planner(hours_left: int, difficulty: int, energy: int, distraction: int) -> str:
    if hours_left <= 2:
        return "Quick review"
    else:  # hours_left > 2.50
        if energy <= 2:
            return "Take a break first"
        else:  # energy > 2.50
            if distraction > 3:
                return "Take a break first"
            else:  # distraction <= 3.50
                if difficulty <= 3:
                    return "Deep focus block"
                else:  # difficulty > 3.50
                    return "Practice problems"
```
Because the decision tree is transparent, we can verify that this handwritten function produces identical predictions to `model.predict()` for all possible inputs!

## Step-by-Step Student Instructions
1. Run `python main.py` in the terminal.
2. Locate the printed `Learned rules:` block in the console.
3. Open `outputs/rules.txt` in your text editor.
4. Verify that the rule block in `outputs/rules.txt` matches the console output character for character.
5. Trace the rule path for a hypothetical student with `hours_left = 5`, `energy = 3`, `distraction = 2`, `difficulty = 4`. Verify that it leads to `Practice problems`.

## Expected Output or Observable Behaviour
When opening `outputs/rules.txt`, you will see:
```txt
accuracy: 1.0000

|--- hours_left <= 2.50
|   |--- class: Quick review
|--- hours_left >  2.50
|   |--- energy <= 2.50
|   |   |--- class: Take a break first
|   |--- energy >  2.50
|   |   |--- distraction <= 3.50
|   |   |   |--- difficulty <= 3.50
|   |   |   |   |--- class: Deep focus block
|   |   |   |--- difficulty >  3.50
|   |   |   |   |--- class: Practice problems
|   |   |--- distraction >  3.50
|   |   |   |--- class: Take a break first
```
The ASCII rules cleanly depict all five terminal pathways.

## Practical Exercises
- **Exercise 3.1**: What happens if you call `export_text(model)` *without* passing `feature_names=FEATURES`? Test this in Python and observe how features are named.
- **Exercise 3.2**: Explain why `Take a break first` appears twice in the tree rules. What are the two distinct scenarios that lead to it?
- **Exercise 3.3**: Trace an input with `hours_left = 1, difficulty = 5, energy = 5, distraction = 1`. Why does the model recommend `Quick review` even though difficulty and energy are both 5?

## Common Mistakes and Debugging
| Mistake | Why it happens | Correction |
|---|---|---|
| Omitting `feature_names` | Writing `export_text(model)` | Pass `feature_names=FEATURES` so rule thresholds display readable variable names instead of `feature_0`. |
| Misinterpreting indentation | Reading child nodes as siblings | Follow vertical pipe bars `|` straight down to track parent-child relationships. |
| Forgetting file encoding | Writing `open(OUT / "rules.txt", "w")` without UTF-8 | Always specify `encoding="utf-8"` when writing text files to avoid platform-specific character errors. |

## Best Practices
- **Archive Learned Rules Alongside Models**: Persisting an ASCII copy of the rules (`rules.txt`) alongside visual plots provides a quick, lightweight audit trail without loading Python libraries.
- **Verify Dual-Leaf Logic**: Always investigate why a class appears multiple times in a tree; it often uncovers multiple distinct real-world causes for the same outcome.

## Security Considerations
- **Auditable AI Logic**: Exported rules can be reviewed by compliance teams or domain experts to ensure no harmful, discriminatory, or nonsensical decisions are made in production.

## Summary
scikit-learn's `export_text` converts trained decision trees into formatted ASCII rule outlines. In the Study Buddy Planner, the extracted rules show an explicit sequence of threshold tests branching across `hours_left`, `energy`, `distraction`, and `difficulty`. The rules reveal five distinct leaves—including two separate pathways for recommending a break—allowing students and mentors to inspect, understand, and question the model's inner reasoning.

## Knowledge-check Questions
1. What scikit-learn function generates the ASCII rule tree in `main.py`?
2. What does each level of indentation represent in an `export_text` printout?
3. Why does `Take a break first` appear in two separate leaf nodes in the rule tree?
4. What output is produced if `export_text` is called without the `feature_names` parameter?
5. Under what file name and directory are the exported rules persisted in `main.py`?

## References
- scikit-learn `export_text` Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.tree.export_text.html
- Molnar, C. (2022). *Interpretable Machine Learning: A Guide for Making Black Box Models Explainable*. Chapter 5.4: Decision Tree.
- Project 20 code: `main.py` lines 75-76 and 117-124.
