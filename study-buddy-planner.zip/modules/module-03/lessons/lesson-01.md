# Lesson 01: Anatomy of a Decision Tree

**Lesson ID:** lesson-01
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Identify and describe the structural components of a decision tree: root node, internal decision nodes, branches, and leaf nodes
- Explain the concept of recursive binary splitting in classification trees
- Define Gini impurity and explain how decision trees measure split quality
- Trace how a student scenario traverses from the root to a terminal prediction leaf
- Explain why decision tree models create orthogonal (axis-aligned) decision boundaries

## Prerequisites
- Completion of Modules 01 and 02
- Basic understanding of conditional boolean logic (`if-else` branching)

## Concept Explanation

### The Tree Metaphor in Machine Learning
In computer science, a tree is an inverted hierarchical data structure: it begins at a single top node called the **root**, branches downward through **internal nodes**, and terminates at bottom endpoints called **leaves**.

In supervised machine learning, a **decision tree classifier** breaks down a complex multi-class classification problem into a sequence of simpler, binary (yes/no) questions.

```
                          DECISION TREE TOPOLOGY
                          
                               [ ROOT NODE ]
                             hours_left <= 2.50
                                ╱          ╲
                        True   ╱            ╲   False
                              ▼              ▼
                       [ LEAF NODE ]   [ INTERNAL NODE ]
                       Quick review     energy <= 2.50
                                           ╱        ╲
                                   True   ╱          ╲   False
                                         ▼            ▼
                                   [ LEAF NODE ]   [ INTERNAL NODE ]
                                 Take a break...    distraction <= 3.50
                                                       ╱        ╲
                                                      ...       ...
```

### Key Structural Components
1. **Root Node**: The very first test at the top of the hierarchy. In `main.py`, the root node tests: `hours_left <= 2.50`. Every sample in the dataset passes through this test.
2. **Internal (Decision) Nodes**: Intermediate points where a feature is compared against a numeric threshold. Internal nodes have exactly one incoming path and two outgoing branches (binary split).
3. **Branches (Edges)**: The directional pathways representing the outcome of the conditional test (e.g. `True` / `False`, or $\le$ / $>$).
4. **Leaf (Terminal) Nodes**: Endpoints that contain no further questions. When an input sample reaches a leaf, the tree outputs the leaf's assigned majority class as its final prediction.

### How Decision Trees Learn: Purity and Gini Impurity
When training a decision tree, how does scikit-learn decide *which* feature to split on first, and *what* threshold to choose?
It searches across all features and all potential split values to maximize **class purity**.

A node is considered **pure** if all training samples reaching that node belong to the exact same class. If a node contains an equal mix of all four strategy classes, it is highly **impure**.

scikit-learn defaults to measuring impurity using the **Gini Impurity** metric:
$$I_G(p) = 1 - \sum_{k=1}^{K} p_k^2$$
where $p_k$ is the proportion of samples belonging to class $k$ at that node.
- If a node contains only `Quick review` samples ($p_{\text{Quick review}} = 1.0$, all others $0.0$), then:
  $$I_G = 1 - (1.0^2 + 0 + 0 + 0) = 0.0 \quad (\text{Perfect purity!})$$
- If samples are evenly distributed across all 4 classes ($p_k = 0.25$ for each), then:
  $$I_G = 1 - 4 \times (0.25^2) = 1 - 0.25 = 0.75 \quad (\text{High impurity})$$

At every node, the algorithm evaluates every possible split across `hours_left`, `difficulty`, `energy`, and `distraction`. It selects the split that produces the greatest reduction in Gini impurity (called **information gain**).

### Axis-Aligned Decision Boundaries
Unlike linear regression or support vector machines with diagonal hyperplanes, decision trees split feature space along orthogonal, axis-aligned planes. Each split is perpendicular to one feature axis (e.g., `hours_left = 2.50`). This makes decision trees uniquely interpretable because each boundary isolates a single feature independently.

## Relevant Code (from main.py, line 65)
```python
model = DecisionTreeClassifier(max_depth=4, random_state=42)
model.fit(X_train, y_train)
```

## Code Explanation
- **`DecisionTreeClassifier`**: The scikit-learn class that implements the CART (Classification and Regression Trees) algorithm using recursive binary splitting.
- **`max_depth=4`**: Caps the maximum vertical distance from the root to any leaf at 4 levels.
- **`random_state=42`**: Ensures that tie-breaking between equally pure candidate splits is completely deterministic.
- **`model.fit(X_train, y_train)`**: Iteratively searches for optimal Gini splits on the 90 training samples until depth 4 or pure leaves are achieved.

## Worked Example
Let us trace an input sample through the tree topology:
Suppose a student situation is:
- `hours_left = 6`
- `energy = 4`
- `distraction = 1`
- `difficulty = 5`

1. **Root Node**: Is `hours_left <= 2.50`?
   - $6 \le 2.50$ is **False**. Take the right branch (`hours_left > 2.50`).
2. **Node 2**: Is `energy <= 2.50`?
   - $4 \le 2.50$ is **False**. Take the right branch (`energy > 2.50`).
3. **Node 3**: Is `distraction <= 3.50`?
   - $1 \le 3.50$ is **True**. Take the left branch (`distraction <= 3.50`).
4. **Node 4**: Is `difficulty <= 3.50`?
   - $5 \le 3.50$ is **False**. Take the right branch (`difficulty > 3.50`).
5. **Leaf Node**: Terminal reached!
   - Strategy prediction: **Practice problems**.

The student traversed exactly 4 decision nodes to arrive at an unambiguous conclusion.

## Step-by-Step Student Instructions
1. Open Python and import `DecisionTreeClassifier` from `sklearn.tree`.
2. Load the dataset, prepare `X_train` and `y_train` using lines 57-63 of `main.py`.
3. Instantiate and fit the model:
   ```python
   model = DecisionTreeClassifier(max_depth=4, random_state=42)
   model.fit(X_train, y_train)
   ```
4. Check the depth of the fitted tree:
   ```python
   print("Actual tree depth:", model.get_depth())
   ```
5. Check the total number of terminal leaf nodes:
   ```python
   print("Number of leaves:", model.get_n_leaves())
   ```
6. Confirm that `get_depth()` returns 4.

## Expected Output or Observable Behaviour
When querying the trained model attributes:
```python
>>> model.get_depth()
4
>>> model.get_n_leaves()
5
```
The tree has a maximum depth of exactly 4 levels and contains exactly 5 terminal leaves.

## Practical Exercises
- **Exercise 1.1**: Calculate the Gini impurity of a hypothetical node containing 10 `Deep focus block` samples, 10 `Quick review` samples, and 0 samples of other classes.
- **Exercise 1.2**: Why is a Gini impurity of 0.0 the ideal goal for a leaf node?
- **Exercise 1.3**: Explain why decision tree boundaries are always parallel to the coordinate axes rather than slanted or curved.

## Common Mistakes and Debugging
| Mistake | Why it happens | Correction |
|---|---|---|
| Confusing leaves with internal nodes | Thinking leaves also test questions | Leaves only hold class predictions; internal nodes test feature thresholds. |
| Assuming decision trees can only handle 2 classes | Generalizing from binary classification | Decision trees naturally handle multi-class classification by tracking sample distributions in leaves. |
| Forgetting to call `model.fit()` | Calling `model.predict()` immediately after instantiation | Always fit the model on `(X_train, y_train)` before attempting predictions or tree inspection. |

## Best Practices
- **Inspect Tree Structure Directly**: Use methods like `model.get_depth()` and `model.get_n_leaves()` to programmatically verify tree topology.
- **Understand the Split Criterion**: Knowing that trees optimize for Gini purity helps explain why rare classes are isolated into dedicated branches.

## Security Considerations
- **Deterministic Training**: Setting `random_state=42` ensures identical tree topology across test runs, preventing flaky test failures in continuous integration pipelines.

## Summary
Decision trees operate via recursive binary splitting, evaluating features against orthogonal thresholds to partition data into subsets of increasing class purity. Driven by Gini impurity minimization, the model constructs a hierarchy connecting a root node through internal nodes down to terminal leaf nodes that output definitive strategy predictions.

## Knowledge-check Questions
1. What is the difference between an internal decision node and a terminal leaf node?
2. What feature and threshold are evaluated at the root node in `main.py`?
3. What is the mathematical definition of Gini impurity, and what does a Gini impurity of 0.0 signify?
4. How many total decision leaves are produced in the trained Study Buddy Planner tree?
5. Why are decision boundaries in decision trees always axis-aligned?

## References
- Breiman, L., Friedman, J., Stone, C. J., & Olshen, R. A. (1984). *Classification and Regression Trees*. CRC Press.
- scikit-learn Decision Trees User Guide: https://scikit-learn.org/stable/modules/tree.html
- Project 20 code: `main.py` lines 65-66.
