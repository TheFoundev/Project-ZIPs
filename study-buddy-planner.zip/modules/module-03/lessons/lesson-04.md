# Lesson 04: Visualizing Trees with `plot_tree` and Matplotlib

**Lesson ID:** lesson-04
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain the visual and analytical advantages of flowchart tree diagrams over text-only rules
- Use `sklearn.tree.plot_tree` to render high-resolution decision tree diagrams
- Customize `plot_tree` parameters including `filled=True`, `rounded=True`, `class_names`, and `fontsize`
- Explain why large canvas dimensions (e.g. `figsize=(16, 8)`) are required to prevent text overlap
- Export rendered figures to disk with `savefig(..., dpi=150, bbox_inches="tight")` and prevent memory leaks using `plt.close()`

## Prerequisites
- Completion of Lessons 01, 02, and 03 in Module 03
- Basic understanding of matplotlib figures and axes

## Concept Explanation

### Beyond Text: Graphical Flowchart Visualization
While `export_text()` provides an invaluable ASCII outline for terminal logging, human beings process visual diagrams significantly faster than text hierarchies. A graphical decision tree flowchart allows learners, educators, and stakeholders to immediately grasp the structure of an AI advisor at a glance:
- Box positions reveal branching structure.
- Node colors indicate class identity and class purity.
- Node annotations show exact sample counts, Gini impurity values, and split criteria.

In `scikit-learn`, the primary tool for rendering these diagrams is `sklearn.tree.plot_tree`. Combined with `matplotlib.pyplot`, it produces publication-ready flowchart images.

```
                          PLOT_TREE NODE STRUCTURE
                          
                ┌────────────────────────────────────────┐
                │        hours_left <= 2.50              │ ◄── Split condition
                │            gini = 0.658                │ ◄── Gini impurity
                │            samples = 90                │ ◄── Training samples
                │       value = [22, 10, 16, 42]         │ ◄── Per-class counts
                │      class = Take a break first        │ ◄── Majority class
                └────────────────────────────────────────┘
```

### Deconstructing `plot_tree` Parameters
In `main.py` lines 92-105, `plot_tree` is invoked with several carefully chosen keyword arguments:

1. **`feature_names=FEATURES`**:
   Substitutes generic labels (`x[0]`, `x[1]`) with actual column names (`hours_left`, `difficulty`, `energy`, `distraction`).
2. **`class_names=list(model.classes_)`**:
   Displays the actual string name of the dominant strategy class inside each box instead of an integer index (0, 1, 2, 3).
3. **`filled=True`**:
   Colors the interior of each node box. Each class is assigned a unique pastel hue:
   - Orange for `Deep focus block`
   - Green for `Practice problems`
   - Blue for `Quick review`
   - Purple for `Take a break first`
   Crucially, color saturation reflects node purity: as Gini impurity decreases toward 0.0, the color becomes richer and more saturated. Pure leaf nodes display solid, vibrant colors.
4. **`rounded=True`**:
   Renders rounded corners on the node boxes, giving the flowchart a modern, polished aesthetic.
5. **`fontsize=8`**:
   Ensures that node text remains crisp, legible, and proportionate within each box.

### Figure Canvas Sizing and Saving
A tree with depth 4 and 5 terminal leaves has multiple horizontal branches. If rendered on a standard default canvas (such as `(6, 4)` inches), the node boxes collide and overlapping text becomes illegible.
`main.py` solves this by explicitly creating a wide canvas:
```python
fig, ax = plt.subplots(figsize=(16, 8))
```
- **`figsize=(16, 8)`**: 16 inches wide by 8 inches tall provides ample horizontal room for all branches to breathe.
- **`fig.tight_layout()`**: Automatically adjusts subplot margins to eliminate wasted white space.
- **`dpi=150`**: Sets resolution to 150 Dots Per Inch, ensuring high-definition clarity when zoomed in.
- **`bbox_inches="tight"`**: Crops extra padding around the border.
- **`plt.close(fig)`**: Explicitly destroys the figure object in memory, preventing matplotlib memory accumulation.

## Relevant Code (from main.py, lines 92-105)
```python
# ---- Draw the tree -------------------------------------------------
fig, ax = plt.subplots(figsize=(16, 8))
plot_tree(
    model,
    feature_names=FEATURES,
    class_names=list(model.classes_),
    filled=True,
    rounded=True,
    fontsize=8,
    ax=ax,
)
ax.set_title("The Study Buddy decision tree")
fig.tight_layout()
fig.savefig(OUT / "study_tree.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```

## Code Explanation
- **Lines 92-93**: Allocates a wide 16x8 inch figure canvas and axes object.
- **Lines 94-101**: Invokes `plot_tree`, passing the model, feature names, sorted class names, visual styling flags (`filled`, `rounded`), font size, and the destination axes.
- **Line 102**: Sets an informative title on the plot.
- **Lines 103-104**: Formats layout and saves the image to `outputs/study_tree.png` with high resolution (150 DPI).
- **Line 105**: Calls `plt.close(fig)` to clean up figure memory.

## Worked Example
Let us examine what information is displayed inside the terminal leaf for `Practice problems` in `study_tree.png`:
- **Top line**: (No split condition, since this is a terminal leaf).
- **`gini = 0.0`**: Perfect purity! All samples reaching this leaf belong to the exact same class.
- **`samples = 10`**: Exactly 10 training instances followed this path.
- **`value = [0, 10, 0, 0]`**: The class breakdown: 0 `Deep focus block`, 10 `Practice problems`, 0 `Quick review`, 0 `Take a break first`.
- **`class = Practice problems`**: The final classification output.
- **Color**: Vibrant, solid green indicating pure `Practice problems`.

Any student or mentor can immediately read this box and verify the model's confidence.

## Step-by-Step Student Instructions
1. Run `python main.py` in your terminal.
2. Verify that `outputs/study_tree.png` was created:
   ```bash
   ls -lh outputs/study_tree.png
   ```
3. Open `outputs/study_tree.png` in an image viewer or VS Code preview.
4. Locate the root box at the top and verify that it says `hours_left <= 2.5`.
5. Follow the left branch down to the first leaf. Confirm that it is shaded blue and labeled `Quick review`.
6. Trace the path to the green leaf (`Practice problems`) and count the decision nodes along that branch.

## Expected Output or Observable Behaviour
Opening `outputs/study_tree.png` displays a clean, symmetrical flowchart diagram:
- Root node at the top.
- Left branch terminating immediately at `Quick review`.
- Right branch cascading through `energy`, `distraction`, and `difficulty`.
- All text is sharp, legible, and uncrowded.
- File size is typically between 150 KB and 300 KB.

## Practical Exercises
- **Exercise 4.1**: What happens if you change `figsize=(16, 8)` to `figsize=(6, 4)` and re-run? Inspect the resulting image and describe the visual degradation.
- **Exercise 4.2**: Why does `filled=True` make some boxes lightly tinted while leaf boxes are intensely colored?
- **Exercise 4.3**: What is the purpose of passing `class_names=list(model.classes_)` instead of leaving `class_names=None`?

## Common Mistakes and Debugging
| Mistake | Why it happens | Correction |
|---|---|---|
| Text inside boxes is overlapping and unreadable | Canvas size is too small (e.g. default 6x4) | Use `figsize=(16, 8)` and set `fontsize=8`. |
| Node text displays `class = y[0]` instead of strategy names | Omitted `class_names` argument | Pass `class_names=list(model.classes_)`. |
| Memory leak warning during repeated runs | Forgetting `plt.close(fig)` | Always call `plt.close(fig)` after `fig.savefig()`. |

## Best Practices
- **Scale Canvas Proportionately to Tree Depth and Width**: As tree depth and leaf count increase, scale the horizontal and vertical figure dimensions to maintain readability.
- **Always Save with `bbox_inches="tight"`**: This strips superfluous white borders from the saved image file.

## Security Considerations
- **Prevent Memory Exhaustion in Server Pipelines**: Matplotlib keeps all open figure objects in global state until explicitly closed. Failing to call `plt.close()` in automated services will steadily consume RAM until the host process crashes.

## Summary
`sklearn.tree.plot_tree` transforms decision tree models into intuitive graphical flowcharts. By configuring `figsize=(16, 8)`, `feature_names=FEATURES`, `class_names=list(model.classes_)`, `filled=True`, and `rounded=True`, `main.py` generates `outputs/study_tree.png`—a clear, color-coded visual diagram that exposes the complete decision logic to students and evaluators.

## Knowledge-check Questions
1. What scikit-learn function generates graphical tree diagrams?
2. What does the `filled=True` parameter do in `plot_tree`?
3. Why does color saturation vary between internal nodes and leaf nodes?
4. Why is `figsize=(16, 8)` used in `main.py` instead of the default matplotlib figure size?
5. Why must `plt.close(fig)` be called after saving the diagram?

## References
- scikit-learn `plot_tree` Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.tree.plot_tree.html
- Matplotlib Figure Lifecycle: https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.close.html
- Project 20 code: `main.py` lines 92-105.
