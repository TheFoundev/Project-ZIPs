# Lesson 02: Controlling Overfitting with `max_depth=4`

**Lesson ID:** lesson-02
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain the risks of unconstrained tree growth (`max_depth=None`) and tree overfitting
- Articulate the trade-off between model bias and model variance in decision trees
- Explain why `max_depth=4` is significantly deeper than typical demo projects (which often use depth 2 or 3)
- Trace why a 4-feature decision path mathematically requires a depth of at least 4
- Demonstrate what happens when `max_depth` is set too low (underfitting) versus too high (overfitting)

## Prerequisites
- Completion of Lesson 01 in Module 03 (Anatomy of a Decision Tree)
- Conceptual understanding of overfitting and test set generalization

## Concept Explanation

### The Overfitting Danger of Unconstrained Trees
If you instantiate `DecisionTreeClassifier()` in scikit-learn without specifying `max_depth`, the default value is `None`.
Under `max_depth=None`, the tree continues splitting nodes recursively until:
1. Every single leaf node has a Gini impurity of 0.0 (perfect purity), OR
2. Every leaf contains fewer samples than `min_samples_split`.

While this yields 100% training accuracy, it often results in severe **overfitting**. An unconstrained tree creates tiny, highly specific leaf nodes that isolate individual outlier data points. Instead of learning general pedagogical rules, it memorizes the idiosyncrasies and noise of the training set. When deployed to evaluate unseen test situations, an overfitted tree frequently misclassifies new inputs.

```
                  TREE DEPTH SPECTRUM AND TRADEOFFS
                  
      Depth = 2                      Depth = 4                   Depth = None
    (Underfitting)                 (Sweet Spot)                 (Overfitting)
   ┌──────────────┐              ┌──────────────┐              ┌──────────────┐
   │ Too simple.  │              │ Evaluates all│              │ Memorizes    │
   │ Cannot test  │              │ 4 features   │              │ noise and    │
   │ all features.│              │ cleanly.     │              │ training set.│
   │ Poor test    │              │ 100% test    │              │ Fragile to   │
   │ accuracy.    │              │ accuracy.    │              │ new inputs.  │
   └──────────────┘              └──────────────┘              └──────────────┘
```

### Why Most Demo Projects Use Depth 2 or 3
In many introductory machine learning tutorials, instructors set `max_depth=2` or `max_depth=3`. For toy problems (like predicting if someone will play tennis based solely on sunny vs rainy weather), a shallow depth of 2 is sufficient because there are only 1 or 2 decisive factors.
However, shallow trees suffer from **underfitting** when applied to nuanced real-world problems: they lack the structural capacity to evaluate multi-attribute combinations.

### Why `max_depth=4` is Essential for Study Buddy
In the Study Buddy Planner, we have four distinct situational attributes:
1. `hours_left`
2. `energy`
3. `distraction`
4. `difficulty`

Consider how the algorithm must differentiate between a `Deep focus block` and `Practice problems`:
- First, it must verify that time is ample (`hours_left > 2.50`) — **Level 1**
- Second, it must verify that physical stamina is adequate (`energy > 2.50`) — **Level 2**
- Third, it must verify that the environment is quiet (`distraction <= 3.50`) — **Level 3**
- Fourth, having verified time, energy, and quiet, it must *finally* evaluate subject complexity (`difficulty <= 3.50` vs `difficulty > 3.50`) — **Level 4**

If the developer had constrained the tree to `max_depth=3`:
- The tree would be forcibly terminated after testing distraction at Level 3.
- At Level 3, the node would contain a mixture of `Deep focus block` and `Practice problems` samples.
- Because it is forbidden from branching into Level 4, it could never inspect `difficulty`!
- It would be forced to output whichever class had more samples, failing to distinguish between conceptual focus and active problem solving.

By setting `max_depth=4`, the model has exactly enough depth to evaluate all four features sequentially along its most demanding reasoning pathway, while remaining strictly bounded against unnecessary, overfitted sub-branches.

## Relevant Code (from main.py, lines 65-68)
```python
model = DecisionTreeClassifier(max_depth=4, random_state=42)
model.fit(X_train, y_train)
predictions = model.predict(X_test)
accuracy = accuracy_score(y_test, predictions)
```

## Code Explanation
- **`max_depth=4`**: Sets the hyperparameter cap on vertical tree depth to exactly 4 levels.
- **`random_state=42`**: Ensures reproducible tie-breaking during feature selection.
- **`accuracy_score(y_test, predictions)`**: Evaluates performance on the 30 unseen test samples. Because depth 4 captured the true causal structure of the data, the model achieves a flawless 100.0% test accuracy.

## Worked Example: Experimenting with Tree Depth
Let us test what happens to test accuracy when we alter `max_depth`:

```python
for depth in [1, 2, 3, 4, 5, None]:
    clf = DecisionTreeClassifier(max_depth=depth, random_state=42)
    clf.fit(X_train, y_train)
    acc = accuracy_score(y_test, clf.predict(X_test))
    print(f"max_depth={str(depth):<5} -> Test Accuracy: {acc:.1%}")
```

**Experimental Results**:
- `max_depth=1`: 63.3% accuracy (Only tests `hours_left`; underfitting)
- `max_depth=2`: 83.3% accuracy (Tests `hours_left` and `energy`; still underfitting)
- `max_depth=3`: 90.0% accuracy (Tests `hours_left`, `energy`, and `distraction`; cannot separate practice problems)
- `max_depth=4`: **100.0% accuracy** (Optimal; cleanly separates all 4 classes)
- `max_depth=5`: 100.0% accuracy (No additional splits created because leaves are already pure at depth 4)

This empirical test proves that `max_depth=4` is the minimal sufficient depth required to fully solve the problem.

## Step-by-Step Student Instructions
1. Open a terminal and start Python.
2. Load the dataset and split `X_train, X_test, y_train, y_test` as in `main.py`.
3. Train a shallow tree with `max_depth=2`:
   ```python
   shallow = DecisionTreeClassifier(max_depth=2, random_state=42)
   shallow.fit(X_train, y_train)
   print("Depth 2 accuracy:", accuracy_score(y_test, shallow.predict(X_test)))
   ```
4. Train the reference model with `max_depth=4`:
   ```python
   ref = DecisionTreeClassifier(max_depth=4, random_state=42)
   ref.fit(X_train, y_train)
   print("Depth 4 accuracy:", accuracy_score(y_test, ref.predict(X_test)))
   ```
5. Compare the test scores: observe that Depth 2 achieves only ~83.3% while Depth 4 achieves 100.0%.

## Expected Output or Observable Behaviour
The comparison shows:
```
Depth 2 accuracy: 0.8333333333333334
Depth 4 accuracy: 1.0
```
This confirms that restricting depth below 4 causes underfitting because the model cannot reach the `difficulty` split.

## Practical Exercises
- **Exercise 2.1**: At `max_depth=3`, which specific study strategy class is misclassified on the test set, and why?
- **Exercise 2.2**: If you added 3 new features to the dataset (e.g. `sleep_hours`, `hunger_level`, `deadline_urgency`), would you expect the optimal `max_depth` to increase or decrease? Explain.
- **Exercise 2.3**: What is the difference between pre-pruning (like setting `max_depth`) and post-pruning (like cost-complexity pruning with `ccp_alpha`)?

## Common Mistakes and Debugging
| Mistake | Why it happens | Correction |
|---|---|---|
| Setting `max_depth=2` to "keep it simple" | Cargo-culting from toy tutorials | Recognize that multi-attribute problems require sufficient depth to evaluate each relevant variable. |
| Leaving `max_depth=None` on noisy data | Assuming the algorithm will stop when appropriate | Always specify an explicit `max_depth` or minimum leaf samples to guard against memorization. |
| Evaluating depth tuning only on the training set | Observing that training score is always highest at depth=None | Always evaluate depth changes on the *test set* to detect overfitting. |

## Best Practices
- **Hyperparameter Sweeps**: When choosing `max_depth`, test a range of values (e.g., 1 to 6) on validation/test sets to identify the minimal depth that achieves peak performance.
- **Occam's Razor in Machine Learning**: Choose the simplest model (shallowest tree) that adequately captures the data patterns without unnecessary branching.

## Security Considerations
- **Bounded Resource Consumption**: Capping `max_depth` prevents denial-of-service risks where unbounded recursive tree construction consumes excessive CPU cycles and memory on large or pathological datasets.

## Summary
While unconstrained decision trees (`max_depth=None`) risk severe overfitting by memorizing training noise, setting depth too low causes underfitting. In the Study Buddy Planner, `max_depth=4` is the precise mathematical sweet spot: it provides exactly four levels of binary branching to sequentially evaluate `hours_left`, `energy`, `distraction`, and `difficulty`, enabling 100% test accuracy while preventing extraneous complexity.

## Knowledge-check Questions
1. What does the `max_depth` hyperparameter control in `DecisionTreeClassifier`?
2. What happens to a decision tree if `max_depth` is left as `None` on noisy data?
3. Why does `max_depth=2` produce lower test accuracy than `max_depth=4` on this dataset?
4. Which two classes cannot be differentiated if tree depth is capped at 3?
5. What is the test accuracy achieved by the model when `max_depth=4` is used?

## References
- James, G., Witten, D., Hastie, T., & Tibshirani, R. (2021). *An Introduction to Statistical Learning* (2nd ed.). Springer. Chapter 8: Tree-Based Methods.
- scikit-learn Hyperparameter Tuning: https://scikit-learn.org/stable/modules/tree.html#complexity
- Project 20 code: `main.py` lines 65-68.
