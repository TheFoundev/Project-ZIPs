# Exercise 06: Evaluation Analysis and Deadline Feature Extension

- **Exercise ID**: `exercise-06`
- **Module**: `module-06` (Evaluation, Running Both Modes & Explainable AI)
- **Duration**: 45 minutes

## Purpose
The objective of this hands-on lab is to perform comprehensive statistical evaluation of the Study Buddy Planner, generate normalized confusion matrices, and implement the project's signature architectural extension: engineering and training a 5th feature (`"deadline_soon"`) into both scripted batch execution and the interactive question loop.

---

## Prerequisites
Before beginning this lab, ensure you have completed:
- [Lesson 01: Multi-Class Performance Metrics](../lessons/lesson-01.md)
- [Lesson 02: Multi-Class Confusion Matrix Analysis](../lessons/lesson-02.md)
- [Lesson 03: End-to-End Operational Execution](../lessons/lesson-03.md)
- [Lesson 04: Explainable AI (XAI) in Education & Extensions](../lessons/lesson-04.md)

---

## Lab Tasks

### Task 1: Comprehensive Multi-Class Metric Audit
In this task, you will create an evaluation script named `audit_metrics.py` that computes and compares precision, recall, and F1-scores across all 4 strategy classes.

#### Instructions:
1. Load `data/study_situations.csv` and replicate the 75/25 stratified split.
2. Fit `DecisionTreeClassifier(max_depth=4, random_state=42)`.
3. Predict on `X_test`.
4. Extract the classification report as a dictionary using `classification_report(y_test, predictions, output_dict=True)`.
5. Extract and print:
   - Overall Accuracy
   - Macro Average F1-score
   - Weighted Average F1-score
   - Precision and Recall for the minority class (*Practice problems*)

---

### Task 2: Normalized Confusion Matrix Generation
Extend the visualization pipeline to export a normalized confusion matrix where cell values display proportions (0.0 to 1.0) rather than raw sample counts.

#### Instructions:
1. Compute the normalized confusion matrix using `confusion_matrix(y_test, predictions, labels=labels, normalize="true")`.
2. Render the normalized matrix using `ConfusionMatrixDisplay` with `values_format=".2f"`.
3. Use the `"Blues"` colormap.
4. Save the figure to `outputs/confusion_matrix_normalized.png` at 150 DPI.
5. Verify that each row sums to exactly `1.00`.

---

### Task 3: The "Deadline Soon" Feature Extension
Implement the core project extension by adding a 5th feature: `"deadline_soon"` (binary: 0 = No, 1 = Yes).

#### Instructions:
1. Create a modified script named `main_deadline.py`.
2. Create an augmented dataset named `data/study_situations_deadline.csv` with the `deadline_soon` column.
   - For rows where `hours_left <= 2`, set `deadline_soon = 1`.
   - For rows where `hours_left > 4`, set `deadline_soon = 0`.
   - For borderline rows, assign 0 or 1 to reflect real-world urgency.
3. Update `FEATURES` to include `"deadline_soon"`.
4. Update `QUESTIONS` to append:
   `("Is your deadline within 12 hours? (0 = No, 1 = Yes) ", "deadline_soon", 0, 1)`
5. Retrain the model and save the new tree diagram as `outputs/study_tree_deadline.png`.
6. Inspect how the decision tree uses the new feature to resolve study conflicts.

---

### Task 4: Interactive Rule Explanation Generator
Build an explanation generator that translates the decision tree's path into a student-friendly explanation.

#### Instructions:
1. Define a function `generate_explanation(situation_dict: dict, prediction: str) -> str`.
2. Inspect the input features:
   - If `prediction == "Take a break first"`, explain whether the break was caused by fatigue (`energy <= 2`) or high distraction (`distraction >= 4`).
   - If `prediction == "Quick review"`, explain that limited available time (`hours_left <= 2`) mandates concise review.
   - If `prediction == "Practice problems"`, highlight that high difficulty combined with high energy makes problem solving optimal.
   - If `prediction == "Deep focus block"`, explain that moderate difficulty, high energy, and low distraction enable deep sustained focus.
3. Integrate this function into the interactive mode so students receive both the recommendation and the plain-English rationale!

---

## Verification & Expected Output

When running `main_deadline.py --interactive`:
```text
Answer five questions and the planner will suggest a strategy.

How many hours do you have left? (1-10) 3
How difficult is the subject? (1-5) 4
How much energy do you have? (1-5) 2
How distracted do you feel? (1-5) 2
Is your deadline within 12 hours? (0 = No, 1 = Yes) 1

Suggested strategy: Quick review
Reasoning: Even though your energy is low, your imminent deadline makes taking an extended break risky. A quick, targeted review of key concepts is recommended!
```

---

## Submission Checklist
- [ ] `audit_metrics.py` successfully extracts dictionary metrics and validates 100% accuracy.
- [ ] `outputs/confusion_matrix_normalized.png` is saved with 2-decimal normalized values.
- [ ] `data/study_situations_deadline.csv` contains the 5th feature column.
- [ ] `main_deadline.py` trains successfully on 5 features and supports `--interactive`.
- [ ] Decision path explanations are provided in clear, empathetic natural language.