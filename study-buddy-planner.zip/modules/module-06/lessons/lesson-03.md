# Lesson 03: End-to-End Operational Execution

- **Lesson ID**: `module-06-lesson-03`
- **Module**: `module-06` (Evaluation, Running Both Modes & Explainable AI)
- **Duration**: 30 minutes

## Purpose and Learning Objectives
A complete machine learning project is more than an isolated model algorithm; it is an integrated software system that manages data ingestion, preprocessing, training, evaluation, visualization generation, persistence, and multi-modal user interaction. Verifying the complete execution lifecycle across both scripted and interactive operational workflows ensures that the software behaves reliably, creates all expected artifacts, and gracefully handles varied execution contexts.

By the end of this lesson, you will be able to:
1. Trace the end-to-end execution lifecycle of `main.py` from interpreter invocation to script termination.
2. Execute and compare the operational behaviors of default scripted mode (`python main.py`) and user-facing interactive mode (`python main.py --interactive`).
3. Audit and validate all generated persistent artifacts inside the `outputs/` directory.
4. Verify execution success using operating system return codes and automated pipeline checks.

---

## Prerequisites
Before starting this lesson, you should be familiar with:
- All preceding lessons in Modules 01 through 05.
- Basic terminal navigation and file inspection commands (`ls`, `cat`, `head`).
- Terminal environment variables and process exit codes (`echo $?`).

---

## Concept Explanation

### The Execution Lifecycle Architecture
When `main.py` is invoked from a shell, the script follows an engineered pipeline:

```mermaid
sequenceDiagram
    autonumber
    actor User as Developer / Student / CI
    participant Main as main.py Process
    participant FS as File System
    participant Model as Decision Tree Model

    User->>Main: python main.py [--interactive]
    Main->>FS: Load data/study_situations.csv
    Main->>Model: Split data & model.fit(X_train, y_train)
    Main->>Model: model.predict(X_test) -> 100% Accuracy
    Main->>User: Print Metrics & ASCII Rules to stdout
    Main->>FS: Save outputs/study_tree.png
    Main->>FS: Save outputs/confusion_matrix.png
    Main->>FS: Write outputs/rules.txt
    alt Flag '--interactive' present
        Main->>User: Prompt 4 questions via terminal
        User->>Main: Enter student numbers
        Main->>Model: Single-row predict()
        Main->>User: Display Personalized Strategy
    else Flag absent (default)
        Main->>User: Display CLI tip & extension challenge
    end
    Main->>User: Process exit 0
```

### Scripted vs Interactive Execution Comparison

| Operational Feature | Scripted Default Mode (`python main.py`) | Interactive Personalization Mode (`python main.py --interactive`) |
| :--- | :--- | :--- |
| **Primary Use Case** | CI/CD testing, batch model training, artifact generation | End-user student advising, interactive testing |
| **Terminal Blocking** | Never blocks; executes in ~1.2 seconds | Pauses for 4 consecutive user inputs |
| **Model Training** | Trains `DecisionTreeClassifier` on 90 rows | Trains identical model on 90 rows |
| **Evaluation Metrics** | Evaluates 30 holdout test samples | Evaluates identical holdout test samples |
| **Demo Scenarios** | Evaluates 4 hardcoded demo plans | Evaluates 4 hardcoded demo plans |
| **Artifacts Created** | `study_tree.png`, `confusion_matrix.png`, `rules.txt` | `study_tree.png`, `confusion_matrix.png`, `rules.txt` |
| **Final Action** | Prints extension challenge tip; terminates | Gathers student situation; outputs personalized plan |

---

## Relevant Code (from main.py, lines 1-9, 117-138)

```python
"""Project 20: The Study Buddy Planner (decision tree).

Run:
    python main.py              # scripted demo
    python main.py --interactive # answer four questions
"""

# ... [data loading, training, evaluation, plotting] ...

    with open(OUT / "rules.txt", "w", encoding="utf-8") as handle:
        handle.write(f"accuracy: {accuracy:.4f}\n\n")
        handle.write(export_text(model, feature_names=FEATURES))
        handle.write("\ndemo plans:\n")
        for situation, plan in zip(demo_situations.to_dict("records"), demo_predictions):
            handle.write(f"{situation} -> {plan}\n")
        handle.write("\n" + classification_report(y_test, predictions, zero_division=0))

    print("\nSaved: outputs/study_tree.png, outputs/confusion_matrix.png, outputs/rules.txt")

    if "--interactive" in sys.argv:
        print("\nAnswer four questions and the planner will suggest a strategy.\n")
        situation = ask_situation()
        plan = model.predict(situation)[0]
        print(f"\nSuggested strategy: {plan}")
    else:
        print("Run `python main.py --interactive` to get a personal plan.")
        print("Try this: add a 'deadline soon' feature and retrain.")


if __name__ == "__main__":
    main()
```

---

## Code Explanation

### 1. Unified Pipeline Upstream
Regardless of command-line flags, lines 1 through 125 execute unconditionally. This architectural design ensures that model artifacts (`study_tree.png`, `confusion_matrix.png`, and `rules.txt`) are always refreshed and up to date, even if a user runs in interactive mode.

### 2. Atomic Artifact Writing (Lines 117-124)
`rules.txt` is opened in write mode (`"w"`) with explicit UTF-8 encoding. It encapsulates four vital verification components into a single human-readable text document:
1. Floating-point accuracy score (`accuracy: 1.0000`).
2. Indented hierarchical ASCII rules tree from `export_text`.
3. All four demo situations with their resolved strategy plans.
4. The complete classification report table with per-class support and F1-scores.

### 3. Execution Confirmation (Line 125)
Line 125 outputs an unambiguous message to standard out:
`Saved: outputs/study_tree.png, outputs/confusion_matrix.png, outputs/rules.txt`.
This gives developers and automated log scanners immediate confirmation of artifact generation.

### 4. Branching Execution at Tail (Lines 127-135)
Placing the interactive check at the very end of `main()` guarantees that:
- All training and mathematical evaluation are complete.
- Visualizations are already safely flushed and closed on disk.
- Interactive latency does not delay artifact generation.

---

## Worked Example

Let us examine the complete lifecycle when running scripted mode in a terminal:

### Terminal Command:
```bash
$ python main.py
```

### Step-by-Step System Progression:
1. Python loads interpreter, imports `sys`, `pathlib`, `matplotlib`, `pandas`, `sklearn`.
2. `matplotlib.use("Agg")` sets headless mode.
3. `OUT.mkdir(exist_ok=True)` ensures `outputs/` exists.
4. `pd.read_csv(...)` reads 120 rows from `data/study_situations.csv`.
5. `train_test_split(...)` splits 90 train / 30 test.
6. `model.fit(...)` fits the tree in under 5 milliseconds.
7. `accuracy_score` computes `1.0`.
8. Terminal displays banner, accuracy, classification report, and ASCII rules.
9. 4 demo situations evaluated and printed.
10. `plot_tree(...)` renders `outputs/study_tree.png`.
11. `ConfusionMatrixDisplay(...)` renders `outputs/confusion_matrix.png`.
12. `rules.txt` is written to disk.
13. Terminal prints confirmation and the non-interactive tip:
    `Run python main.py --interactive to get a personal plan.`
14. Process exits with code `0`.

---

## Step-by-Step Student Instructions

1. **Verify Scripted Execution**:
   Run the scripted demo:
   ```bash
   python main.py
   ```
   Check the process exit code:
   ```bash
   echo $?
   ```
   Verify that it outputs `0` (success).

2. **Audit Generated Artifacts**:
   List the contents of the `outputs` directory:
   ```bash
   ls -lh outputs/
   ```
   Verify that all three expected files exist:
   - `study_tree.png` (~100-200 KB)
   - `confusion_matrix.png` (~50-100 KB)
   - `rules.txt` (~1-2 KB)

3. **Inspect `rules.txt`**:
   Print the full contents of `rules.txt`:
   ```bash
   cat outputs/rules.txt
   ```
   Confirm that it contains accuracy, the ASCII tree, demo plans, and the classification report.

4. **Verify Interactive Execution**:
   Launch interactive mode:
   ```bash
   python main.py --interactive
   ```
   Provide valid study parameters and verify that your suggested strategy prints at the end.

---

## Expected Output or Observable Behaviour

### Scripted Mode Terminal Tail:
```text
Saved: outputs/study_tree.png, outputs/confusion_matrix.png, outputs/rules.txt
Run `python main.py --interactive` to get a personal plan.
Try this: add a 'deadline soon' feature and retrain.
```

### Interactive Mode Terminal Tail:
```text
Saved: outputs/study_tree.png, outputs/confusion_matrix.png, outputs/rules.txt

Answer four questions and the planner will suggest a strategy.

How many hours do you have left? (1-10) 5
How difficult is the subject? (1-5) 2
How much energy do you have? (1-5) 4
How distracted do you feel? (1-5) 1

Suggested strategy: Deep focus block
```

---

## Practical Exercises

### Exercise 1: Automated Pipeline Verification Script
Write a bash script named `verify_pipeline.sh` that:
1. Executes `python main.py`.
2. Tests if `$?` is equal to 0.
3. Checks if `outputs/study_tree.png`, `outputs/confusion_matrix.png`, and `outputs/rules.txt` exist.
4. Checks that `outputs/rules.txt` contains the string `"accuracy: 1.0000"`.
5. Prints `"PASS: Pipeline verified successfully"` or exits with an error code.

### Exercise 2: Benchmarking Execution Latency
Using Python's `time` module or the Linux `time` command (`time python main.py`), measure the exact execution duration of the scripted run. Determine how much of the runtime is spent importing libraries versus fitting the decision tree.

### Exercise 3: Dynamic Output Directory Flag
Modify `main.py` so that a user can optionally specify a custom output directory flag:
```bash
python main.py --outdir experiment_1
```
Ensure the directory is created automatically and all three artifacts are routed there.

---

## Common Mistakes and Debugging

### Mistake 1: Relative Path Failures
Running the script from outside its root directory (e.g., `cd .. && python study-buddy-planner/main.py`) can cause file-not-found errors if hardcoded relative paths like `"data/study_situations.csv"` are used. In `main.py`, this is avoided by anchoring all paths to `Path(__file__).resolve().parent`.

### Mistake 2: Missing File Encodings
Opening text files with default system encoding (which may be ASCII or Windows-1252 on older platforms) can cause encoding errors if Unicode characters (like `—` or `°`) are present. Always specify `encoding="utf-8"`.

### Mistake 3: Terminating Interactive Sessions Improperly
If a user presses Enter on an empty line in interactive mode, the script should not crash; it re-prompts until valid input is supplied.

---

## Best Practices
1. **Always Anchor Paths to Script Location**: Use `BASE = Path(__file__).resolve().parent` so the script can be executed from any working directory without path resolution bugs.
2. **Atomic Writes**: Flush and close all file handles promptly using `with open(...)` context managers.
3. **Deterministic Clean Terminations**: Ensure all code paths terminate with clear exit statuses so downstream automation can verify success.
4. **Log Artifact Locations**: Always print the absolute or relative paths of newly created files so users know where to find them.

---

## Security Considerations
- **Output Directory Overwrites**: Ensure that writing to `outputs/` does not overwrite critical system files by sanitizing file paths and disallowing arbitrary path traversal (e.g., `../../`).
- **File Permissions**: When writing audit logs in shared server environments, use appropriate file creation masks (`umask`) to prevent unauthorized modification.

---

## Summary
- `main.py` executes a complete 11-step pipeline from data ingestion to persistent artifact export.
- Scripted mode provides deterministic execution ideal for automated regression testing and CI/CD.
- Interactive mode provides immediate, personalized recommendations for students.
- All three key artifacts (`study_tree.png`, `confusion_matrix.png`, `rules.txt`) are reliably generated on every run.

---

## Knowledge-check Questions
1. What three persistent files are written to the `outputs/` directory during execution?
2. Why is the interactive prompt check placed at the very end of `main()` rather than at the start?
3. How does `Path(__file__).resolve().parent` ensure the script can be executed from any directory?
4. What exit status code does Python return when a script runs to completion without unhandled exceptions?

---

## References
- [Python Pathlib: Object-Oriented Filesystem Paths](https://docs.python.org/3/library/pathlib.html)
- [GNU Bash Manual: Exit Status ($?)](https://www.gnu.org/software/bash/manual/html_node/Exit-Status.html)
- [Twelve-Factor App: Logs and Execution](https://12factor.net/logs)