# Lesson 02: Multi-Class Confusion Matrix Analysis

- **Lesson ID**: `module-06-lesson-02`
- **Module**: `module-06` (Evaluation, Running Both Modes & Explainable AI)
- **Duration**: 30 minutes

## Purpose and Learning Objectives
While a classification report provides aggregate numerical summaries, a **confusion matrix** offers a granular, two-dimensional spatial map of exactly how actual classes correspond to predicted classes. It reveals not only how often a model is correct, but precisely which classes are being confused with one another. Mastering multi-class confusion matrices and their graphical visualization enables engineers to diagnose systematic classification errors and fine-tune decision boundaries.

By the end of this lesson, you will be able to:
1. Explain the row-and-column layout of a multi-class confusion matrix.
2. Calculate and interpret diagonal (True Positive) and off-diagonal (misclassification) cells.
3. Utilize scikit-learn's `confusion_matrix` and `ConfusionMatrixDisplay` with custom styling and colormaps.
4. Export publication-quality confusion matrix heatmaps to disk using matplotlib's headless backend.

---

## Prerequisites
Before starting this lesson, you should be familiar with:
- Multi-class classification concepts from Module 06 Lesson 01.
- Matplotlib plotting fundamentals and headless figure saving (`Agg` backend).
- Ground truth vs predicted arrays (`y_test`, `predictions`).

---

## Concept Explanation

### The Multi-Class Confusion Matrix Anatomy
In binary classification, a confusion matrix is a $2 \times 2$ grid. In multi-class classification with $K$ classes, the matrix scales to a $K \times K$ square grid. In the Study Buddy Planner, $K = 4$, resulting in a $4 \times 4$ grid containing 16 cells:

```text
                                  PREDICTED LABELS
                    Deep focus   Practice    Quick     Take a
                      block      problems    review   break first
                  ┌────────────┬───────────┬─────────┬───────────┐
      Deep focus  │     8      │     0     │    0    │     0     │
        block     │  (TP_DF)   │           │         │           │
ACTUAL            ├────────────┼───────────┼─────────┼───────────┤
GROUND Practice   │     0      │     3     │    0    │     0     │
TRUTH  problems   │            │  (TP_PP)  │         │           │
LABELS            ├────────────┼───────────┼─────────┼───────────┤
       Quick      │     0      │     0     │    5    │     0     │
       review     │            │           │ (TP_QR) │           │
                  ├────────────┼───────────┼─────────┼───────────┤
       Take a     │     0      │     0     │    0    │    14     │
     break first  │            │           │         │  (TP_TB)  │
                  └────────────┴───────────┴─────────┴───────────┘
```

#### Conventions:
1. **Vertical Axis (Rows)**: Represents the **Actual Ground Truth** class labels ($y_{\text{true}}$).
2. **Horizontal Axis (Columns)**: Represents the **Model Predictions** ($y_{\text{pred}}$).
3. **The Main Diagonal (Top-Left to Bottom-Right)**: Contains all correct classifications where Actual == Predicted ($TP$). In an optimal classifier, all non-zero numbers lie exclusively along this diagonal.
4. **The Off-Diagonal Cells**: Represent misclassifications.
   - Any number in row $i$, column $j$ (where $i \neq j$) means that a sample whose true class was $i$ was mistakenly classified as class $j$.

### Alphabetical Label Alignment
In `main.py`, label ordering is made deterministic by sorting unique class strings:
```python
labels = sorted(df["strategy"].unique())
```
Alphabetical sorting yields:
1. `Deep focus block`
2. `Practice problems`
3. `Quick review`
4. `Take a break first`

Passing explicit `labels=labels` to both `confusion_matrix()` and `ConfusionMatrixDisplay()` guarantees that row 0 corresponds to *Deep focus block*, row 1 to *Practice problems*, row 2 to *Quick review*, and row 3 to *Take a break first*.

### Visualizing with Heatmaps
While raw numeric arrays can be inspected in terminal output, human visual processing digests heatmaps much faster. Scikit-learn's `ConfusionMatrixDisplay` automatically handles:
- Rendering numeric annotations inside every cell.
- Mapping cell magnitude to a color intensity gradient (e.g., `"Purples"`).
- Formatting axis tick labels cleanly.

---

## Relevant Code (from main.py, lines 21, 107-115)

```python
from sklearn.metrics import ConfusionMatrixDisplay, confusion_matrix

# ... inside main() ...

    # ---- Confusion matrix ---------------------------------------------
    labels = sorted(df["strategy"].unique())
    cm = confusion_matrix(y_test, predictions, labels=labels)
    fig, ax = plt.subplots(figsize=(7, 5.5))
    ConfusionMatrixDisplay(cm, display_labels=labels).plot(ax=ax, cmap="Purples", colorbar=False)
    ax.set_title("Study strategy predictions")
    fig.tight_layout()
    fig.savefig(OUT / "confusion_matrix.png", dpi=150, bbox_inches="tight")
    plt.close(fig)
```

---

## Code Explanation

### 1. Label Extraction and Sorting (Line 108)
```python
labels = sorted(df["strategy"].unique())
```
`df["strategy"].unique()` extracts the distinct class strings from the target column. Wrapping this in `sorted()` returns an alphabetically sorted Python list. This prevents non-deterministic row/column orders across different runs or Python environments.

### 2. Computing the Raw Matrix (Line 109)
```python
cm = confusion_matrix(y_test, predictions, labels=labels)
```
`confusion_matrix()` builds the $4 \times 4$ NumPy integer array. Supplying `labels=labels` guarantees that the matrix row and column indices align precisely with our sorted list.

### 3. Figure and Subplot Creation (Line 110)
```python
fig, ax = plt.subplots(figsize=(7, 5.5))
```
Creates a matplotlib figure object of width 7 inches and height 5.5 inches, providing ample spatial margin for class name text on both axes without text overlap.

### 4. Plotting the Heatmap with `ConfusionMatrixDisplay` (Line 111)
```python
ConfusionMatrixDisplay(cm, display_labels=labels).plot(ax=ax, cmap="Purples", colorbar=False)
```
- `ConfusionMatrixDisplay(cm, display_labels=labels)`: Wraps the raw matrix and human-readable label strings into a display manager.
- `.plot(ax=ax)`: Draws the visualization onto the specific matplotlib axis `ax`.
- `cmap="Purples"`: Uses matplotlib's sequential purple colormap, where higher integer counts receive darker purple hues, while zero counts appear white or very pale lilac.
- `colorbar=False`: Suppresses the vertical gradient bar on the right margin, keeping the visualization clean and focused.

### 5. Title, Layout & Export (Lines 112-115)
- `ax.set_title("Study strategy predictions")`: Adds a descriptive title above the plot.
- `fig.tight_layout()`: Automatically adjusts padding around axis ticks so class labels are not clipped.
- `fig.savefig(OUT / "confusion_matrix.png", dpi=150, bbox_inches="tight")`: Exports a crisp raster PNG file at 150 DPI resolution.
- `plt.close(fig)`: Destroys the figure from memory to prevent memory leaks in automated pipelines.

---

## Worked Example

Let us trace how the raw matrix maps to the visualized PNG artifact:

### Raw Matrix ($cm$):
```text
[[ 8,  0,  0,  0],
 [ 0,  3,  0,  0],
 [ 0,  0,  5,  0],
 [ 0,  0,  0, 14]]
```

### Visual Representation:
- Cell (0, 0): Value `8`, medium-dark purple hue.
- Cell (1, 1): Value `3`, light purple hue.
- Cell (2, 2): Value `5`, medium purple hue.
- Cell (3, 3): Value `14`, darkest purple hue in the matrix (maximum support).
- All 12 off-diagonal cells: Value `0`, crisp white background.

Because every off-diagonal cell is zero, the model made zero errors across the entire holdout set.

---

## Step-by-Step Student Instructions

1. **Run the Script to Generate the Matrix**:
   In your terminal, execute:
   ```bash
   python main.py
   ```
2. **Inspect File Generation**:
   Confirm that the image was created in the `outputs/` folder:
   ```bash
   ls -la outputs/confusion_matrix.png
   ```
3. **Inspect the Matrix Numerically**:
   Open a Python REPL and print the matrix array directly:
   ```python
   import pandas as pd
   from sklearn.metrics import confusion_matrix
   from sklearn.model_selection import train_test_split
   from sklearn.tree import DecisionTreeClassifier

   df = pd.read_csv("data/study_situations.csv")
   X = df[["hours_left", "difficulty", "energy", "distraction"]]
   y = df["strategy"]
   X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)

   model = DecisionTreeClassifier(max_depth=4, random_state=42)
   model.fit(X_train, y_train)
   preds = model.predict(X_test)

   labels = sorted(df["strategy"].unique())
   cm = confusion_matrix(y_test, preds, labels=labels)
   print("Confusion Matrix:")
   print(cm)
   ```
4. Verify that the sum of the diagonal elements equals 30:
   ```python
   print(f"Total correct: {cm.diagonal().sum()} / {cm.sum()}")
   ```
5. Exit the REPL.

---

## Expected Output or Observable Behaviour

Terminal REPL output:
```text
Confusion Matrix:
[[ 8  0  0  0]
 [ 0  3  0  0]
 [ 0  0  5  0]
 [ 0  0  0 14]]
Total correct: 30 / 30
```

The resulting PNG file at `outputs/confusion_matrix.png` renders a clean $4 \times 4$ purple heatmap with True labels on the Y-axis and Predicted labels on the X-axis.

---

## Practical Exercises

### Exercise 1: Normalized Confusion Matrix
Modify the `confusion_matrix()` call to compute normalized proportions rather than raw counts by adding the argument `normalize='true'`. Observe how row sums equal 1.00 (100%), representing per-class recall rates.

### Exercise 2: Exploring Different Colormaps
Change `cmap="Purples"` to other matplotlib sequential colormaps such as `"Blues"`, `"Viridis"`, or `"Greens"`. Compare visual contrast and accessibility.

### Exercise 3: Simulating Class Confusion
Intentionally change `max_depth=2` during model training. Re-run evaluation and observe how the confusion matrix reveals non-zero off-diagonal cells where classes with similar features begin to overlap.

---

## Common Mistakes and Debugging

### Mistake 1: Inconsistent Label Sorting
If `confusion_matrix` is called with default label ordering while `ConfusionMatrixDisplay` uses sorted labels, the numerical cells and the axis tick labels will not align, causing misinterpretation. Always pass explicit `labels=labels` to both calls.

### Mistake 2: Transposing Actual and Predicted Axes
Remember that in scikit-learn convention, the first argument is always the ground truth (`y_true`), and the second is the predictions (`y_pred`). Reversing them transposes the matrix, confusing false positives with false negatives.

### Mistake 3: Omitting `plt.close(fig)`
In long-running evaluation loops or Jupyter notebooks, failing to call `plt.close()` causes matplotlib to retain every figure in memory, eventually causing memory exhaustion (`OutOfMemoryError`).

---

## Best Practices
1. **Explicit Label Ordering**: Always pass an explicit, sorted list of class strings into `confusion_matrix(..., labels=labels)` for deterministic reproducibility.
2. **Choose Monochromatic Sequential Colormaps**: For confusion matrices, sequential colormaps (like `Purples` or `Blues`) are superior to diverging colormaps because higher numbers naturally map to darker shades.
3. **Check Diagonal Sum**: Ensure `cm.diagonal().sum() / cm.sum()` matches the reported top-level accuracy score.
4. **Use `tight_layout`**: Always call `fig.tight_layout()` before `savefig` to prevent multi-word class labels from being cut off.

---

## Security Considerations
- **Data Privacy in Visualizations**: Ensure that confusion matrices in multi-tenant environments aggregate sufficient sample counts per cell to avoid re-identification of individual users.
- **File System Permissions**: When exporting image artifacts in multi-user systems, ensure target directory permissions prevent unauthorized overwriting of audit plots.

---

## Summary
- A multi-class confusion matrix maps actual class labels (rows) against predicted class labels (columns).
- In our 30-sample test set, all samples lie on the main diagonal ($8, 3, 5, 14$), demonstrating perfect $100.0\%$ classification.
- Alphabetical label sorting ensures reproducible, unambiguous row and column alignment.
- `ConfusionMatrixDisplay` paired with matplotlib provides clear, interpretable heatmap visualizations saved directly to disk.

---

## Knowledge-check Questions
1. In a scikit-learn confusion matrix, do rows represent the actual ground-truth classes or the predicted classes?
2. What does a non-zero number in an off-diagonal cell indicate?
3. Why is it important to pass `labels=sorted(...)` to both `confusion_matrix` and `ConfusionMatrixDisplay`?
4. What is the mathematical relationship between the sum of the matrix diagonal and the accuracy score?

---

## References
- [Scikit-Learn Confusion Matrix Documentation](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.confusion_matrix.html)
- [Scikit-Learn ConfusionMatrixDisplay Documentation](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.ConfusionMatrixDisplay.html)
- [Matplotlib Colormaps Reference](https://matplotlib.org/stable/users/explain/colors/colormaps.html)