# Lesson 01: Multi-Class Performance Metrics

- **Lesson ID**: `module-06-lesson-01`
- **Module**: `module-06` (Evaluation, Running Both Modes & Explainable AI)
- **Duration**: 30 minutes

## Purpose and Learning Objectives
Evaluating a multi-class classification model requires going far beyond a single top-level accuracy number. While accuracy measures the overall proportion of correct classifications, it can mask critical weaknesses in minority classes or obscure asymmetric error costs. Understanding multi-class precision, recall, F1-score, support, macro averaging, and weighted averaging enables machine learning practitioners to assess model reliability with rigorous statistical nuance.

By the end of this lesson, you will be able to:
1. Define and compute accuracy, precision, recall, and F1-score in a multi-class recommendation setting.
2. Interpret the detailed tabular output of scikit-learn's `classification_report`.
3. Distinguish between macro averaging and weighted averaging, understanding how class imbalance impacts each metric.
4. Explain the purpose and operational safety of the `zero_division=0` configuration parameter in production reporting.

---

## Prerequisites
Before starting this lesson, you should be familiar with:
- Supervised classification concepts and discrete class labels.
- The 75/25 stratified train/test split from Module 03.
- Basic algebraic fractions and weighted averages.
- True Positives ($TP$), False Positives ($FP$), and False Negatives ($FN$).

---

## Concept Explanation

### The Four Pillars of Classification Metrics
When evaluating predictions against ground-truth labels across multiple classes ($K = 4$ in Study Buddy: *Deep focus block*, *Practice problems*, *Quick review*, *Take a break first*), metrics are first calculated on a per-class basis using a One-vs-Rest (OvR) formulation:

```mermaid
flowchart TD
    subgraph GroundTruth[Ground Truth Test Set: 30 Samples]
        C1["Deep focus block (support: 8)"]
        C2["Practice problems (support: 3)"]
        C3["Quick review (support: 5)"]
        C4["Take a break first (support: 14)"]
    end

    subgraph MetricsCalculation[Per-Class Evaluation]
        P["Precision = TP / (TP + FP)"]
        R["Recall = TP / (TP + FN)"]
        F1["F1-Score = 2 * (P * R) / (P + R)"]
    end

    subgraph Aggregate[Dataset Aggregates]
        Acc["Overall Accuracy = Sum(TP) / Total = 30 / 30 = 100.0%"]
        Macro["Macro Avg = Unweighted Mean across 4 classes"]
        Weighted["Weighted Avg = Support-weighted Mean across 4 classes"]
    end

    GroundTruth --> MetricsCalculation --> Aggregate
```

#### 1. Overall Accuracy
$$\text{Accuracy} = \frac{\sum_{k=1}^K TP_k}{N} = \frac{\text{Total Correct Classifications}}{\text{Total Test Samples}}$$
- In our test set ($N = 30$), the decision tree correctly classifies all 30 test scenarios, yielding:
  $$\text{Accuracy} = \frac{30}{30} = 1.00 \quad (100.0\%)$$

#### 2. Class-Specific Precision
$$\text{Precision}_k = \frac{TP_k}{TP_k + FP_k}$$
- **Question Answered**: When the model recommends strategy $k$, how often is that recommendation correct?
- **Cost of Low Precision**: False alarms. If the model recommends *Take a break first* when the student was actually ready for *Deep focus block*, valuable study momentum is wasted.

#### 3. Class-Specific Recall (Sensitivity)
$$\text{Recall}_k = \frac{TP_k}{TP_k + FN_k}$$
- **Question Answered**: Out of all real instances where the student needed strategy $k$, how many did the model identify?
- **Cost of Low Recall**: Missed opportunities. If an exhausted student needed *Take a break first* but was told to do *Practice problems*, they suffer cognitive burnout and frustration.

#### 4. F1-Score
The F1-score is the **harmonic mean** of precision and recall:
$$F_1 = 2 \cdot \frac{\text{Precision} \cdot \text{Recall}}{\text{Precision} + \text{Recall}}$$
The harmonic mean punishes extreme discrepancies far more severely than the arithmetic mean. If precision is 1.0 and recall is 0.0, the arithmetic mean is 0.5, but the F1-score collapses to 0.0, highlighting severe model failure.

### Support
**Support** is the structural count of actual, ground-truth samples belonging to each class within the test partition. In our 30-sample stratified test set:
- *Take a break first*: 14 samples (46.7% of test set)
- *Deep focus block*: 8 samples (26.7% of test set)
- *Quick review*: 5 samples (16.7% of test set)
- *Practice problems*: 3 samples (10.0% of test set)
- **Total Support**: $14 + 8 + 5 + 3 = 30$.

### Macro vs Weighted Averaging
When summarizing performance across all classes into a single metric, scikit-learn computes two distinct aggregations:

1. **Macro Average (Unweighted)**:
   $$\text{Macro Metric} = \frac{1}{K} \sum_{k=1}^K \text{Metric}_k$$
   - Treats every class equally, giving *Practice problems* (3 samples) the exact same weight as *Take a break first* (14 samples).
   - If a model fails entirely on a rare minority class, the macro average drops drastically.

2. **Weighted Average (Support-Weighted)**:
   $$\text{Weighted Metric} = \sum_{k=1}^K \left( \frac{\text{Support}_k}{N} \cdot \text{Metric}_k \right)$$
   - Weights each class by its empirical prevalence in the test set. Reflects real-world operational throughput when class distributions are naturally skewed.

### The `zero_division=0` Safeguard
When a model makes zero positive predictions for a given class ($TP_k + FP_k = 0$), the denominator for precision becomes zero: $\frac{0}{0}$.
By default, scikit-learn prints runtime warnings and assigns undefined (`nan`) values. Passing `zero_division=0` explicitly instructs scikit-learn to assign a clean `0.0` value without polluting console logs or breaking automated parsing pipelines.

---

## Relevant Code (from main.py, lines 21, 68, 73-74, 118, 123)

```python
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay, confusion_matrix

# ... inside main() ...

    predictions = model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)

    print(f"Accuracy: {accuracy:.1%}\n")
    print(classification_report(y_test, predictions, zero_division=0))

    # Persisting to rules.txt:
    with open(OUT / "rules.txt", "w", encoding="utf-8") as handle:
        handle.write(f"accuracy: {accuracy:.4f}\n\n")
        # ... rules and demo plans ...
        handle.write("\n" + classification_report(y_test, predictions, zero_division=0))
```

---

## Code Explanation

### 1. Metric Imports (Line 21)
`accuracy_score` and `classification_report` are imported from `sklearn.metrics`. These standard functions evaluate predictions generated on an unseen holdout test set (`X_test`) against ground-truth labels (`y_test`).

### 2. Computing Top-Level Accuracy (Line 68)
```python
accuracy = accuracy_score(y_test, predictions)
```
`accuracy_score` takes two 1D arrays: ground-truth labels `y_test` and predicted labels `predictions`. It compares element-by-element, returning a floating-point scalar between 0.0 and 1.0.

### 3. Formatting Accuracy String (Line 73)
```python
print(f"Accuracy: {accuracy:.1%}\n")
```
Python's format specifier `:.1%` multiplies the float by 100 and appends a percent sign with 1 decimal place: `100.0%`.

### 4. Tabular Breakdown via `classification_report` (Line 74)
`classification_report` formats a multi-column text table displaying precision, recall, F1-score, and support for each target class, followed by overall accuracy, macro average, and weighted average.

---

## Worked Example

Let us examine the exact classification report produced by `main.py`:

```text
                   precision    recall  f1-score   support

 Deep focus block       1.00      1.00      1.00         8
Practice problems       1.00      1.00      1.00         3
     Quick review       1.00      1.00      1.00         5
Take a break first       1.00      1.00      1.00        14

         accuracy                           1.00        30
        macro avg       1.00      1.00      1.00        30
     weighted avg       1.00      1.00      1.00        30
```

### Analysis:
1. **Per-Class Metrics**: Every single class achieves perfect 1.00 (100%) precision, recall, and F1-score.
2. **Support Distribution**:
   - Out of 30 test scenarios, *Take a break first* is nearly half the data (14 samples).
   - *Practice problems* is the rarest class with only 3 samples.
   - Because stratification was used in Module 03, the test distribution perfectly mirrors the 120-row master dataset proportions.
3. **Macro vs Weighted**: Since every class achieved 1.00, both macro and weighted averages are identically 1.00.

---

## Step-by-Step Student Instructions

1. **Execute the Performance Report**:
   Run the scripted evaluation from your terminal:
   ```bash
   python main.py
   ```
2. **Inspect the Terminal Output**:
   Locate the classification table and note the support counts for each class.
3. **Verify the Persisted Report**:
   Open `outputs/rules.txt` and scroll to the bottom to verify that the identical classification report was persisted to disk.
4. **Calculate Metrics Manually in Python**:
   Open a Python REPL and verify precision and recall calculations:
   ```python
   # Simulated counts for Practice problems
   tp = 3
   fp = 0
   fn = 0
   precision = tp / (tp + fp)
   recall = tp / (tp + fn)
   f1 = 2 * (precision * recall) / (precision + recall)
   print(f"Precision: {precision:.2f}, Recall: {recall:.2f}, F1: {f1:.2f}")
   ```
5. Exit the REPL.

---

## Expected Output or Observable Behaviour

Terminal display:
```text
Accuracy: 100.0%

                   precision    recall  f1-score   support

 Deep focus block       1.00      1.00      1.00         8
Practice problems       1.00      1.00      1.00         3
     Quick review       1.00      1.00      1.00         5
Take a break first       1.00      1.00      1.00        14

         accuracy                           1.00        30
        macro avg       1.00      1.00      1.00        30
     weighted avg       1.00      1.00      1.00        30
```

---

## Practical Exercises

### Exercise 1: Simulate Imperfect Classifiers
Write a Python script that injects artificial noise into predictions (e.g., flipping 2 instances of *Take a break first* to *Quick review*) and re-runs `classification_report`. Observe how precision, recall, and F1-score change for both classes.

### Exercise 2: Dictionary Output Export
Modify `classification_report(y_test, predictions, output_dict=True)` to obtain a nested Python dictionary of scores. Write a function that extracts only the macro F1-score and formats it as JSON.

### Exercise 3: Zero-Division Stress Test
Create an artificial test scenario where one class has 0 test samples or 0 predictions. Run `classification_report` both with and without `zero_division=0` to observe the warning suppression behavior.

---

## Common Mistakes and Debugging

### Mistake 1: Relying Solely on Top-Level Accuracy
In imbalanced datasets (e.g., fraud detection where 99% of samples are legitimate), a dummy classifier that always predicts "Not Fraud" achieves 99% accuracy while having 0.0 recall on actual fraud. Always evaluate precision, recall, and F1-score per class alongside accuracy.

### Mistake 2: Confusing Macro Average with Weighted Average
Reporting weighted average when a minority class is performing poorly can give a false sense of security, because high performance on the majority class will dominate the weighted score. Macro average gives equal weight to all classes regardless of sample size.

### Mistake 3: Evaluating Metrics on the Training Set
Calculating accuracy on `X_train` measures memorization rather than generalization. Always calculate your final reported metrics on an untouched holdout set (`X_test`).

---

## Best Practices
1. **Always Inspect Support**: Never evaluate precision and recall without looking at the support column; a class with support of 2 has high statistical uncertainty.
2. **Use `zero_division=0` in Pipelines**: Always pass `zero_division=0` or `zero_division=np.nan` to prevent warnings from polluting CI logs or stdout.
3. **Persist Metric Artifacts**: Save machine-readable or plain-text evaluation reports alongside model weights for auditability and compliance.
4. **Harmonize Averages**: In research papers and production reports, present both macro average and weighted average to provide full transparency.

---

## Security Considerations
- **Metric Gaming**: Adversarial actors can artificially inflate weighted accuracy by training models to over-predict dominant classes. Auditing class-specific recall prevents this vulnerability.
- **Fairness & Subgroup Performance**: In educational AI systems, ensure that recommendation quality does not degrade on underrepresented student profiles.

---

## Summary
- Overall accuracy measures the percentage of correct classifications across all classes ($100.0\%$ in Study Buddy).
- Precision quantifies recommendation exactness; recall quantifies recommendation coverage.
- The F1-score represents the harmonic mean of precision and recall.
- Macro averaging weights all classes equally; weighted averaging scales by empirical class support.
- Setting `zero_division=0` prevents runtime warnings when class predictions are absent.

---

## Knowledge-check Questions
1. Why is the harmonic mean used instead of the arithmetic mean when computing F1-score?
2. What does the "support" column in `classification_report` represent?
3. How does macro average differ from weighted average when evaluating an imbalanced test set?
4. What happens when `zero_division=0` is omitted and a class receives zero predictions?

---

## References
- [Scikit-Learn Metrics: classification_report](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.classification_report.html)
- [Scikit-Learn Metrics: accuracy_score](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.accuracy_score.html)
- [A Systematic Analysis of Multi-Class Evaluation Metrics (Powers, 2020)](https://arxiv.org/abs/2008.05756)