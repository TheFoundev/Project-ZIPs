# Lesson 04: Explainable AI (XAI) in Education & Extensions

- **Lesson ID**: `module-06-lesson-04`
- **Module**: `module-06` (Evaluation, Running Both Modes & Explainable AI)
- **Duration**: 30 minutes

## Purpose and Learning Objectives
As artificial intelligence increasingly guides educational planning, admissions, grading, and career guidance, the opacity of "black box" algorithms poses significant ethical and pedagogical risks. Students should never be passive consumers of mysterious algorithmic decrees; they must be empowered to interrogate, understand, and question automated recommendations. **Explainable AI (XAI)** provides the foundational technical bridge between statistical machine learning and human agency.

By the end of this lesson, you will be able to:
1. Define Explainable AI (XAI) and distinguish between "black box" and "glass box" architectures.
2. Explain the pedagogical and ethical necessity of algorithmic transparency in educational technology.
3. Interrogate decision paths and audit models against the "Right to Explanation" (GDPR Article 22 / ethical AI standards).
4. Implement the extension challenge from `main.py`: engineering a `"deadline soon"` feature into the data schema, model training, and interactive prompt loops.

---

## Prerequisites
Before starting this lesson, you should be familiar with:
- Decision tree logic and threshold splits from Module 02.
- The ASCII rules export format (`export_text`) from Module 04.
- The interactive prompt schema (`QUESTIONS`) from Module 05.
- Basic principles of feature engineering in machine learning.

---

## Concept Explanation

### The Spectrum of Model Explainability
Machine learning models inhabit a spectrum between predictive capacity and interpretability:

```text
┌────────────────────────────────────────────────────────────────────────┐
│                   THE MACHINE LEARNING SPECTRUM                        │
│                                                                        │
│   GLASS BOX (High Interpretability)      BLACK BOX (Low Interpretability)│
│                                                                        │
│   • Shallow Decision Trees (max_depth<=4)• Deep Neural Networks (LLMs)  │
│   • Linear / Logistic Regression         • Gradient Boosted Trees (XGB)│
│   • Rule-Based Expert Systems            • Random Forests (500 trees)  │
│                                                                        │
│   ✓ Complete Auditability                ✗ Opaque internal math        │
│   ✓ Human-verifiable rules               ✗ High computational complexity│
│   ✓ Zero explainability latency          ✗ Susceptible to hidden bias   │
└────────────────────────────────────────────────────────────────────────┘
```

In the Study Buddy Planner, we deliberately chose a **shallow decision tree (`max_depth=4`)**. Every single recommendation is backed by a deterministic, human-readable Boolean clause (e.g., `hours_left > 2.50 AND energy > 2.50 AND distraction <= 3.50 AND difficulty > 3.50 -> Practice problems`).

### Pedagogical Agency in Educational Systems
Why does explainability matter so intensely in education?
1. **Fostering Metacognition**: A student told *"Do practice problems"* learns nothing about how to manage their time. A student told *"Because you have over 2.5 hours, high energy, low distraction, and hard material, doing practice problems optimizes active recall"* learns how to assess their own cognitive state.
2. **Preventing Algorithmic Fatalism**: If a student is exhausted and the model suggests *"Take a break first"*, the student can see that their self-reported `energy = 1` triggered the rule. If they feel misjudged, they can re-evaluate their self-assessment.
3. **The Right to Explanation**: International regulatory frameworks (such as the EU General Data Protection Regulation / GDPR Article 22) mandate that individuals affected by automated decision-making systems have a legal right to receive meaningful explanations of the logic involved.

### The Extension Challenge: Adding a "Deadline Soon" Feature
Line 134 of `main.py` presents a challenge:
```text
Try this: add a 'deadline soon' feature and retrain.
```

How does an impending deadline alter human study psychology?
- Under normal conditions, low energy (`energy = 2`) triggers *"Take a break first"*.
- But if an exam is in **2 hours** (`deadline_soon = 1`), taking an open-ended nap might guarantee failure! The student may need a forced *"Quick review"* or tactical triage instead.

```mermaid
flowchart TD
    subgraph CurrentTopology[Current Model Topology]
        A["hours_left > 2.5"] --> B["energy <= 2.5"]
        B --> C["Take a break first"]
    end

    subgraph ExtendedTopology[Extended Model Topology]
        A2["hours_left > 2.5"] --> D{"deadline_soon == 1?"}
        D -- Yes --> E["Quick review (Emergency Triage)"]
        D -- No --> B2["energy <= 2.5"]
        B2 --> C2["Take a break first (Normal Recovery)"]
    end
```

Engineering this extension requires updating four coordinated layers:
1. **Dataset (`study_situations.csv`)**: Adding the `deadline_soon` column (binary `0` or `1`) across training rows.
2. **Model Schema (`FEATURES`)**: Updating `FEATURES = ["hours_left", "difficulty", "energy", "distraction", "deadline_soon"]`.
3. **Prompt Loop (`QUESTIONS`)**: Adding `("Is your deadline within 12 hours? (0=No, 1=Yes) ", "deadline_soon", 0, 1)`.
4. **Retraining & Verification**: Fitting the decision tree and inspecting how the split tree reorganizes its root and branch nodes.

---

## Relevant Code (from main.py, lines 7-8, 75-76, 117-124, 134)

```python
"""
A tiny recommendation system.  The decision tree learns rules for choosing a
study strategy, and the rules are printed so you can question them.
"""

# ... inside main() ...

    print("Learned rules:\n")
    print(export_text(model, feature_names=FEATURES))

    # Persisting complete rules text for auditability
    with open(OUT / "rules.txt", "w", encoding="utf-8") as handle:
        handle.write(f"accuracy: {accuracy:.4f}\n\n")
        handle.write(export_text(model, feature_names=FEATURES))
        # ...

    if "--interactive" in sys.argv:
        # ...
    else:
        print("Run `python main.py --interactive` to get a personal plan.")
        print("Try this: add a 'deadline soon' feature and retrain.")
```

---

## Code Explanation

### 1. Pedagogical Intent in Module Docstring (Lines 7-8)
Notice the core philosophical statement:
> *"The decision tree learns rules for choosing a study strategy, and the rules are printed so you can question them."*
The software is explicitly designed not as an oracle of authority, but as a transparent thinking partner.

### 2. Immediate Transparency via `export_text` (Lines 75-76)
Before any predictions or interactive prompts are shown, the full internal decision hierarchy is dumped to the screen. A user immediately understands every split threshold ($2.50$, $3.50$) governing their future recommendations.

### 3. Auditable Persistence (Lines 117-124)
Saving `outputs/rules.txt` creates an auditable record of the exact logic deployed. If a student disputes a recommendation, educators can inspect `rules.txt` to verify the mathematical decision path.

### 4. Continuous Iteration Prompt (Line 134)
The script concludes with an open-ended learning prompt (`Try this: add a 'deadline soon' feature and retrain.`), signaling to the student that machine learning models are malleable, evolving artifacts rather than static code.

---

## Worked Example: Engineering the "Deadline Soon" Feature

Let us walk through implementing the extension challenge step by step:

### Step 1: Augment the CSV Dataset
Open `data/study_situations.csv` and add the `deadline_soon` column:
```csv
hours_left,difficulty,energy,distraction,deadline_soon,strategy
2,4,3,2,1,Quick review
6,5,4,1,0,Practice problems
4,3,1,2,0,Take a break first
4,3,1,2,1,Quick review
```
Notice row 4: When `deadline_soon = 1`, an exhausted student is redirected to *"Quick review"* instead of *"Take a break first"*.

### Step 2: Update `main.py` Schema
```python
FEATURES = ["hours_left", "difficulty", "energy", "distraction", "deadline_soon"]
QUESTIONS = [
    ("How many hours do you have left? (1-10) ", "hours_left", 1, 10),
    ("How difficult is the subject? (1-5) ", "difficulty", 1, 5),
    ("How much energy do you have? (1-5) ", "energy", 1, 5),
    ("How distracted do you feel? (1-5) ", "distraction", 1, 5),
    ("Is your deadline imminent? (0 = No, 1 = Yes) ", "deadline_soon", 0, 1),
]
```

### Step 3: Retrain and Inspect
When re-executing `python main.py`, the new decision tree displays splits on `deadline_soon <= 0.50`, revealing how urgency logically re-routes exhausted students into triage review!

---

## Step-by-Step Student Instructions

1. **Audit Current Model Rules**:
   Open `outputs/rules.txt` in your text editor.
   Find the rule for *"Practice problems"*:
   ```text
   |--- hours_left >  2.50
   |   |--- energy >  2.50
   |   |   |--- distraction <= 3.50
   |   |   |   |--- difficulty >  3.50
   |   |   |   |   |--- class: Practice problems
   ```
2. **Trace a Student Scenario**:
   A student has 5 hours left, difficulty 4, energy 5, but distraction 4.
   Trace the tree:
   - `hours_left > 2.50` (True)
   - `energy > 2.50` (True)
   - `distraction <= 3.50`? No! `distraction = 4 > 3.50`.
   - Result: *"Take a break first"*.
3. **Question the Rule**:
   Ask yourself: *Is this recommendation pedagogically sound?*
   If a student's environment is chaotic (distraction 4), trying to do hard practice problems will likely lead to errors and frustration. Taking a break to change study environments or clear the desk is sensible advice!
4. **Reflect on Agency**:
   Because the rule is transparent, the student knows that the *only* reason they were told to take a break was distraction. If they put on noise-cancelling headphones (reducing distraction to 2), they can immediately transition to practice problems.

---

## Expected Output or Observable Behaviour

Terminal display of transparent decision hierarchy:
```text
Learned rules:
|--- hours_left <= 2.50
|   |--- class: Quick review
|--- hours_left >  2.50
|   |--- energy <= 2.50
|   |   |--- class: Take a break first
|   |--- energy >  2.50
|   |   |--- distraction <= 3.50
|   |   |   |--- difficulty <= 3.50
|   |   |   |   |--- class: Deep focus block
|   |   |   |--- difficulty >  3.50
|   |   |   |   |--- class: Practice problems
|   |   |--- distraction >  3.50
|   |   |   |--- class: Take a break first
```

---

## Practical Exercises

### Exercise 1: Natural Language Rule Transpiler
Write a Python function `explain_decision(situation_dict: dict, model) -> str` that traces a single input sample through the decision tree and outputs a personalized, plain-English paragraph explaining *why* the strategy was selected (e.g., *"We recommend 'Deep focus block' because you have 5 hours available, high energy (4/5), low distraction (1/5), and moderate difficulty (3/5)."*).

### Exercise 2: Implementing the Full "Deadline Soon" Extension
Create a feature branch or copy of `main.py` named `main_deadline.py`. Implement the 5th feature `deadline_soon` across data generation, training, and CLI questions. Run the script and verify that `outputs/study_tree.png` visualizes the new feature splits.

### Exercise 3: Counterfactual Explanations
Write a function that computes the **minimum feature change** required to alter a recommendation. For example: *"If your energy was 3 instead of 1, the recommendation would change from 'Take a break first' to 'Deep focus block'."*

---

## Common Mistakes and Debugging

### Mistake 1: Treating Machine Learning as Infallible Truth
Assuming that because an algorithm has 100% test accuracy, its recommendations must always be followed without question. 100% accuracy simply means the tree perfectly memorized and partitioned the rules of the training dataset. If the dataset's rules contain human biases or omissions, the tree inherits them perfectly.

### Mistake 2: Feature Overfitting on Extension
Adding too many granular features (e.g., `coffee_cups_consumed`, `room_temperature`, `chair_comfort`) without increasing the number of training samples will cause the decision tree to create idiosyncratic, non-generalizable splits.

### Mistake 3: Breaking the 4-Tuple Schema
When adding a new feature, failing to maintain the 4-tuple pattern `(prompt, key, low, high)` in `QUESTIONS` will cause an unpacking exception in `ask_situation()`.

---

## Best Practices
1. **Prioritize Glass Box Models in Human-Centric Domains**: Whenever algorithms make recommendations affecting student well-being, healthcare, or civil rights, prioritize interpretable architectures over unexplainable black boxes.
2. **Present Reasoning Alongside Predictions**: Never show a prediction in isolation. Always display the contributing factors or rule path to empower the user.
3. **Encourage Student Auditing**: Design software interfaces that prompt users to critique and challenge recommendations.
4. **Document Model Limitations**: Clearly state what features the model does *not* consider (e.g., emotional stress, illness, learning disabilities) in user-facing documentation.

---

## Security Considerations
- **Adversarial Exploitation of Transparency**: In adversarial settings (e.g., credit fraud or spam detection), fully transparent decision rules can allow malicious actors to game thresholds. In educational technology, however, transparency promotes collaboration and trust.
- **Ethical Safeguards**: Prevent models from incorporating protected personal demographic attributes (race, gender, socioeconomic status) as decision features.

---

## Summary
- Explainable AI (XAI) empowers users to understand, inspect, and question automated algorithmic decisions.
- Shallow decision trees serve as ideal "glass box" architectures, offering complete transparency with zero interpretability latency.
- In educational technology, explainability fosters metacognition, builds student trust, and satisfies regulatory requirements (GDPR Article 22).
- The "deadline soon" extension illustrates how feature engineering adapts model topology to capture complex real-world dynamics.

---

## Knowledge-check Questions
1. What is the fundamental difference between a "black box" model and a "glass box" model?
2. Why is explainability especially crucial in educational recommendation systems?
3. What legal principle under GDPR Article 22 relates directly to Explainable AI?
4. How would adding a `"deadline_soon"` feature alter the decision path for an exhausted student?

---

## References
- [DARPA Explainable Artificial Intelligence (XAI) Program](https://www.darpa.mil/program/explainable-artificial-intelligence)
- [EU General Data Protection Regulation (GDPR) Article 22](https://gdpr-info.eu/art-22-gdpr/)
- [Molnar, Christoph: Interpretable Machine Learning (2022)](https://christophm.github.io/interpretable-ml-book/)