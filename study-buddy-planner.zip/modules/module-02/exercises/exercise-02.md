# Module 2 Exercises: Data & Study Situations

## Exercise 2.1: Dataset Inspection & Path Verification (10 min)
**Objective:** Load `study_situations.csv` using `pathlib.Path` and verify dataset dimensions, column names, and absence of missing values.

**Problem Statement:** You need to verify that `data/study_situations.csv` contains exactly 120 rows and 5 columns, that the four feature column names match `FEATURES`, and that there are no missing or corrupted values.

**Requirements:**
1. Import `Path` from `pathlib` and `pandas as pd`.
2. Construct the dataset path dynamically using `BASE = Path(...).resolve().parent` and `DATA = BASE / "data"`.
3. Load the dataset into `df`.
4. Verify that `df.shape == (120, 5)`.
5. Check that `df.isnull().sum().sum() == 0`.

**Constraints:** Do not hardcode absolute path strings. Use `pathlib.Path`.

**Expected Behaviour:** A short Python script or console session confirming the row count, column names, and data cleanliness.

**Acceptance Criteria:**
- [ ] Loads file using `pathlib.Path` path arithmetic.
- [ ] Confirms exact shape `(120, 5)`.
- [ ] Confirms column names: `hours_left`, `difficulty`, `energy`, `distraction`, `strategy`.
- [ ] Confirms 0 null values across all columns.

**Hints:**
- Use `df.info()` or `df.isnull().sum()` to inspect nulls.
- `df.columns.tolist()` lists all column headers.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes

---

## Exercise 2.2: Feature Range & Boundary Profiling (15 min)
**Objective:** Compute descriptive statistics for all four numeric features and confirm that all values fall within their expected bounded domains.

**Problem Statement:** Before training a model, data scientists must ensure that no corrupted values exist outside expected domain intervals. You must profile `hours_left`, `difficulty`, `energy`, and `distraction`.

**Requirements:**
1. Isolate the feature matrix $X = df[FEATURES]$.
2. Compute descriptive statistics using `X.describe()`.
3. Verify that `hours_left` has a minimum $\ge 1$ and a maximum $\le 10$.
4. Verify that `difficulty`, `energy`, and `distraction` have minimums $\ge 1$ and maximums $\le 5$.
5. Record the median (50th percentile) value for each feature.

**Constraints:** Operate on the 2D feature DataFrame $X$, not the target vector $y$.

**Expected Behaviour:** A printed summary table displaying min, max, mean, and quartiles for each feature.

**Acceptance Criteria:**
- [ ] Correctly identifies the valid range for `hours_left` as $[1, 10]$.
- [ ] Correctly identifies the valid range for `difficulty`, `energy`, `distraction` as $[1, 5]$.
- [ ] Verifies no negative values or values exceeding upper bounds.
- [ ] Records the median for `hours_left` (6.0) and `energy` (3.0).

**Hints:**
- Use `X.agg(["min", "max", "median"])` for a compact view.
- Notice that all features are integer values.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes

---

## Exercise 2.3: Target Class Frequency & Imbalance Analysis (15 min)
**Objective:** Profile the distribution of the four target study strategies in `study_situations.csv` and analyze why class imbalance exists.

**Problem Statement:** In real-world data, classes are rarely perfectly balanced. You must quantify the distribution of `strategy` and explain why certain recommendations appear more frequently than others.

**Requirements:**
1. Extract the target column `y = df["strategy"]`.
2. Compute the frequency count of each strategy class using `y.value_counts()`.
3. Compute the percentage proportion of each strategy class using `y.value_counts(normalize=True)`.
4. Rank the classes from most frequent to least frequent.
5. Write a short explanation (3-4 sentences) explaining why `Take a break first` is the most common and `Practice problems` is the least common.

**Constraints:** Base counts on the complete 120-row dataset.

**Expected Behaviour:** A frequency table showing exact integer counts and percentages for all four strategies, accompanied by a pedagogical explanation.

**Acceptance Criteria:**
- [ ] Correctly records: `Take a break first` (56), `Deep focus block` (30), `Quick review` (21), `Practice problems` (13).
- [ ] Correctly computes percentages: ~46.7%, 25.0%, 17.5%, 10.8%.
- [ ] Explains that fatigue and distraction occur frequently in student life, making breaks common, while intense practice requires a rare alignment of ample time, high energy, and low distraction.

**Hints:**
- Multiply `y.value_counts(normalize=True)` by 100 for percentages.
- The total sum of counts must equal 120.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 2.4: Stratified vs Unstratified Splitting Experiment (15 min)
**Objective:** Compare stratified train/test splitting with standard random splitting to observe how class proportions are preserved.

**Problem Statement:** If you split an imbalanced dataset randomly, minority classes like `Practice problems` may be under-represented or completely absent in the test set. You will perform two splits—one with `stratify=y` and one without—and compare test set class counts.

**Requirements:**
1. Perform a stratified split:
   `X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)`
2. Record `y_test.value_counts()` for the stratified split. Confirm counts: `Take a break first`: 14, `Deep focus block`: 8, `Quick review`: 5, `Practice problems`: 3.
3. Perform an unstratified split:
   `X_train_un, X_test_un, y_train_un, y_test_un = train_test_split(X, y, test_size=0.25, random_state=7)`
4. Record `y_test_un.value_counts()` and note any discrepancies in class proportions.
5. Explain why `stratify=y` is essential for fair multi-class evaluation.

**Constraints:** Use `test_size=0.25` in both experiments.

**Expected Behaviour:** A side-by-side comparison of test set class distributions demonstrating the stability of stratified sampling.

**Acceptance Criteria:**
- [ ] Stratified test set has exactly 14, 8, 5, 3 samples.
- [ ] Explains that unstratified random splits cause class proportions to fluctuate arbitrarily.
- [ ] Connects stratification to reliable evaluation of minority classes.

**Hints:**
- Look at line 62 in `main.py` for the exact parameters used in the project.
- Total test samples will be 30 in both splits, but the per-class breakdown will vary in the unstratified split.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes
