# Lesson 01: Ingesting `study_situations.csv` with Pandas & Pathlib

**Lesson ID:** lesson-01
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why modern Python data science uses `pathlib.Path` instead of raw string paths or `os.path`
- Ingest tabular CSV data using `pd.read_csv()` combined with a dynamic `Path` object
- Verify dataset dimensions, column names, and data types in pandas
- Isolate the feature matrix $X$ using a list of column names
- Separate the target vector $y$ as a 1D Series

## Prerequisites
- Completion of Module 01
- Basic understanding of Python file systems and pandas DataFrames

## Concept Explanation

### Robust Path Management with `pathlib`
In beginner programming tutorials, file loading is often taught using relative string paths:
```python
df = pd.read_csv("data/study_situations.csv")  # Fragile!
```
While this works when the terminal happens to be open in the exact same directory as the script, it immediately breaks if the user runs the script from any other location (e.g. from the repository root or from a parent directory). The operating system interprets `"data/study_situations.csv"` relative to the *Current Working Directory (CWD)*, raising a `FileNotFoundError`.

Modern, production-grade Python resolves this using `pathlib.Path`:
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
```
- `__file__` is a special Python variable containing the path to the currently executing script.
- `.resolve()` evaluates all symbolic links and normalizes the absolute path.
- `.parent` yields the directory containing the script.
- The forward-slash operator `/` is overloaded by `Path` objects to construct platform-independent paths across Windows (which uses backslashes `\`) and POSIX systems (Linux/macOS, which use forward slashes `/`).

### Tabular Ingestion with `pd.read_csv()`
The dataset `data/study_situations.csv` contains 120 recorded study scenarios. Each scenario records the situational attributes of a student alongside the recommended study strategy.
Calling `pd.read_csv(DATA / "study_situations.csv")` parses the comma-separated text into a two-dimensional tabular data structure called a **DataFrame**.

### Separating Features ($X$) from Target ($y$)
In supervised machine learning, we must clearly separate:
1. **The Feature Matrix ($X$)**: The inputs used to make decisions. In `main.py`, $X$ is defined as `df[FEATURES]`. Passing a list of column names (`FEATURES = ["hours_left", "difficulty", "energy", "distraction"]`) extracts a 2D DataFrame with 120 rows and 4 columns.
2. **The Target Vector ($y$)**: The ground-truth label we seek to predict. In `main.py`, $y$ is defined as `df["strategy"]`. Passing a single column name as a string extracts a 1D pandas Series of length 120.

```
       RAW CSV (120 rows × 5 columns)
       hours_left | difficulty | energy | distraction | strategy
       ───────────────────────────────────────────────┼─────────
            3     |     5      |   1    |      3      | Take a break first
            9     |     3      |   4    |      3      | Deep focus block
            ...   |    ...     |  ...   |     ...     | ...
                          │                               │
                          ▼                               ▼
               Feature Matrix X (120, 4)         Target Vector y (120,)
```

## Relevant Code (from main.py, lines 25-27 and 57-59)
```python
# Lines 25-27:
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"

# Lines 57-59:
df = pd.read_csv(DATA / "study_situations.csv")
X = df[FEATURES]
y = df["strategy"]
```

## Code Explanation
- **Lines 25-27**: Initializes dynamic path anchors. `DATA / "study_situations.csv"` constructs a clean `PosixPath` or `WindowsPath` pointing directly to the CSV file.
- **Line 57**: Loads the dataset into memory as `df`.
- **Line 58**: Subsets the DataFrame to include only the four designated features (`hours_left`, `difficulty`, `energy`, `distraction`). Notice the capital letter $X$, adhering to mathematical convention where matrices are capitalized.
- **Line 59**: Subsets the target column `strategy` as lowercase $y$, adhering to mathematical convention where vectors are lowercase.

## Worked Example
Let us trace what occurs in Python when these lines execute:
```python
>>> import pandas as pd
>>> from pathlib import Path
>>> BASE = Path("beginner-projects-main/AI-ML Beginners/projects/20_study_buddy_planner").resolve()
>>> DATA = BASE / "data"
>>> df = pd.read_csv(DATA / "study_situations.csv")
>>> print(type(df))
<class 'pandas.core.frame.DataFrame'>
>>> print(df.shape)
(120, 5)
>>> FEATURES = ["hours_left", "difficulty", "energy", "distraction"]
>>> X = df[FEATURES]
>>> print(type(X), X.shape)
<class 'pandas.core.frame.DataFrame'> (120, 4)
>>> y = df["strategy"]
>>> print(type(y), y.shape)
<class 'pandas.core.frame.Series'> (120,)
```
The shape of $X$ is `(120, 4)`, satisfying scikit-learn's requirement for a 2D matrix, while $y$ has shape `(120,)`.

## Step-by-Step Student Instructions
1. Launch an interactive Python shell (`python3`) from any directory.
2. Import `pathlib.Path` and `pandas as pd`.
3. Replicate lines 25-27 and line 57 to load `study_situations.csv`.
4. Inspect the first 5 rows using `df.head()`.
5. Check for null or missing values using `df.isnull().sum()`. Observe that every column has 0 missing values.
6. Verify that `len(df)` equals 120.

## Expected Output or Observable Behaviour
When calling `df.info()`, pandas confirms:
```
<class 'pandas.core.frame.DataFrame'>
RangeIndex: 120 entries, 0 to 119
Data columns (total 5 columns):
 #   Column       Non-Null Count  Dtype 
---  ------       --------------  ----- 
 0   hours_left   120 non-null    int64 
 1   difficulty   120 non-null    int64 
 2   energy       120 non-null    int64 
 3   distraction  120 non-null    int64 
 4   strategy     120 non-null    object
dtypes: int64(4), object(1)
memory usage: 4.8+ KB
```
All four features are 64-bit integers (`int64`), and the target column is text strings (`object`).

## Practical Exercises
- **Exercise 1.1**: What happens if you accidentally write `X = df["hours_left"]` instead of `X = df[FEATURES]`? What are the dimensions and type of $X$?
- **Exercise 1.2**: Write a pandas query to filter only rows where `strategy == "Practice problems"`. How many such rows exist?
- **Exercise 1.3**: Use `df.describe()` to find the mean of the `hours_left` column. What is the average study duration available in this dataset?

## Common Mistakes and Debugging
| Mistake | Why it happens | Correction |
|---|---|---|
| `FileNotFoundError` | Using relative string `"data/study_situations.csv"` when running from another folder | Use `DATA = Path(__file__).resolve().parent / "data"` |
| Passing a string instead of a list for $X$ | Writing `df["hours_left", "difficulty"]` | Put column names inside a list: `df[["hours_left", "difficulty"]]` |
| Attempting to fit without separating $y$ | Passing the full `df` to `model.fit()` | Ensure `strategy` is removed from $X$ and assigned to $y$. |

## Best Practices
- **Never Hardcode System Paths**: Using `Path(__file__).resolve().parent` ensures code works identically on Windows, Linux, and macOS without manual path tweaking.
- **Validate Ingested Data Immediately**: Always inspect `.shape`, `.dtypes`, and null counts right after calling `pd.read_csv()`.

## Security Considerations
- **Prevent Path Traversal**: By resolving paths using `Path.resolve()`, you avoid path injection bugs where external user input manipulates folder navigation (e.g. `../../etc/passwd`).

## Summary
The Study Buddy Planner loads 120 historical study scenarios from `data/study_situations.csv` using `pathlib.Path` for cross-platform reliability. The tabular dataset is cleanly partitioned into a 2D feature matrix $X$ of shape `(120, 4)` and a 1D target vector $y$ of length 120. All four features are clean integers with zero missing entries.

## Knowledge-check Questions
1. Why is `pathlib.Path(__file__).resolve().parent` superior to using plain relative path strings like `"data/study_situations.csv"`?
2. How many total rows and columns exist in `study_situations.csv`?
3. What is the difference in pandas between `df[FEATURES]` and `df["strategy"]`?
4. What data types are stored in the four feature columns versus the target column?
5. What error does scikit-learn raise if you pass a 1D Series as the feature matrix $X$?

## References
- Python `pathlib` Documentation: https://docs.python.org/3/library/pathlib.html
- pandas `read_csv` Documentation: https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html
- scikit-learn Input Data Conventions: https://scikit-learn.org/stable/glossary.html#term-X
