# Lesson 04: Class Distribution, Stratification & `train_test_split`

**Lesson ID:** lesson-04
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why datasets must be partitioned into independent training and testing sets
- Identify the risks of unstratified random sampling on imbalanced multi-class datasets
- Define **stratified sampling** and explain how `stratify=y` preserves class proportions
- Calculate the exact train and test set sample counts for all four strategy classes
- Explain the role of `test_size=0.25` and `random_state=42` in reproducible evaluations

## Prerequisites
- Completion of Lessons 01, 02, and 03 in Module 02
- Basic understanding of train/test data splitting

## Concept Explanation

### Why Partition Data?
In supervised machine learning, our objective is to train a model that **generalizes** to novel, unseen situations. If we evaluate a model on the same data it was trained on, we cannot tell whether the model has learned true underlying principles or merely memorized the specific training examples (overfitting).
To obtain an honest, unbiased estimate of performance, we reserve a subset of the dataset strictly for evaluation.

In `main.py`, line 62 specifies `test_size=0.25`. This splits the 120 total samples into:
- **Training Set (75%)**: $120 \times 0.75 = 90$ samples
- **Test Set (25%)**: $120 \times 0.25 = 30$ samples

```
                            DATASET PARTITIONING
                            
       Total Dataset: 120 Samples
       ┌────────────────────────────────────────────────────────┐
       │   Training Set: 90 Samples (75%)    │  Test Set: 30    │
       │   (Used exclusively to fit model)   │  Samples (25%)   │
       └─────────────────────────────────────┴──────────────────┘
```

### The Hazard of Random Sampling on Imbalanced Classes
As established in Lesson 03, the four strategy classes are not equally represented:
- `Take a break first`: 56 samples (46.7%)
- `Deep focus block`: 30 samples (25.0%)
- `Quick review`: 21 samples (17.5%)
- `Practice problems`: 13 samples (10.8%)

Notice that `Practice problems` has only 13 total occurrences.
If we perform a standard, unstratified random split, pure probability could result in:
- 13 `Practice problems` samples all ending up in the training set, leaving **0** in the test set. In that scenario, we cannot evaluate whether the model can predict `Practice problems` on unseen data!
- Or, 8 `Practice problems` samples ending up in the test set, leaving only 5 in the training set, depriving the tree of sufficient training evidence.

### The Solution: Stratified Sampling (`stratify=y`)
**Stratification** ensures that both the training set and the test set maintain the exact same percentage of each class label as the original dataset.

When we supply `stratify=y` to scikit-learn's `train_test_split()`, the algorithm:
1. Groups the dataset by the target labels $y$.
2. Randomly selects exactly 25% from each class for the test set.
3. Places the remaining 75% of each class into the training set.

Let us examine the exact sample counts produced in `main.py`:

| Class Label | Total Samples in Dataset | Training Samples (75%) | Test Samples (25%) |
|---|---|---|---|
| `Take a break first` | 56 | 42 | 14 |
| `Deep focus block` | 30 | 22 | 8 |
| `Quick review` | 21 | 16 | 5 |
| `Practice problems` | 13 | 10 | 3 |
| **Total** | **120** | **90** | **30** |

Observe how the test support numbers (`14`, `8`, `5`, `3`) match the support column printed in the console classification report:
```
                    precision    recall  f1-score   support

  Deep focus block       1.00      1.00      1.00         8
 Practice problems       1.00      1.00      1.00         3
      Quick review       1.00      1.00      1.00         5
Take a break first       1.00      1.00      1.00        14

          accuracy                           1.00        30
```

### Reproducibility via `random_state=42`
Computers generate pseudo-random numbers starting from an initial integer seed. Without setting a seed, every execution of `train_test_split()` would generate different random partitions, leading to slight variations in tree splits and test metrics.
Setting `random_state=42` ensures that the random number generator produces the identical partition every time, making results 100% reproducible across machines and operating systems.

## Relevant Code (from main.py, lines 61-63)
```python
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)
```

## Code Explanation
- **`X` and `y`**: The feature matrix and target vector extracted from `df`.
- **`test_size=0.25`**: Designates 25% of the data (30 samples) for the test set and 75% (90 samples) for training.
- **`random_state=42`**: Sets a deterministic seed for the pseudo-random partition algorithm.
- **`stratify=y`**: Enforces proportional class representation across both partitions, guaranteeing 14, 8, 5, and 3 test samples for the respective classes.

## Worked Example
Let us verify the mathematical proportions:
1. `Take a break first`:
   - Dataset proportion: $56 / 120 = 46.67\%$
   - Test proportion: $14 / 30 = 46.67\%$
2. `Deep focus block`:
   - Dataset proportion: $30 / 120 = 25.00\%$
   - Test proportion: $8 / 30 = 26.67\%$
3. `Quick review`:
   - Dataset proportion: $21 / 120 = 17.50\%$
   - Test proportion: $5 / 30 = 16.67\%$
4. `Practice problems`:
   - Dataset proportion: $13 / 120 = 10.83\%$
   - Test proportion: $3 / 30 = 10.00\%$

Due to discrete integer rounding, the test set proportions match the global dataset proportions as closely as mathematically possible.

## Step-by-Step Student Instructions
1. In an interactive Python session, load `study_situations.csv` and define $X$ and $y$.
2. Run `train_test_split` with `stratify=y`:
   ```python
   from sklearn.model_selection import train_test_split
   X_train, X_test, y_train, y_test = train_test_split(
       X, y, test_size=0.25, random_state=42, stratify=y
   )
   ```
3. Inspect the shape of all four partitions:
   ```python
   print(X_train.shape, X_test.shape, y_train.shape, y_test.shape)
   ```
4. Check the class distribution in `y_test`:
   ```python
   print(y_test.value_counts())
   ```
5. Confirm that the counts are 14, 8, 5, and 3.

## Expected Output or Observable Behaviour
Python displays:
```
(90, 4) (30, 4) (90,) (30,)
strategy
Take a break first    14
Deep focus block       8
Quick review           5
Practice problems      3
Name: count, dtype: int64
```
This confirms that stratified sampling has partitioned the dataset with exact fidelity.

## Practical Exercises
- **Exercise 4.1**: What happens if you omit `stratify=y`? Run `train_test_split(X, y, test_size=0.25, random_state=1)` without stratification and check `y_test.value_counts()`. How do the counts differ?
- **Exercise 4.2**: If a dataset had 200 samples and you used `test_size=0.20`, how many samples would be in the training set and test set?
- **Exercise 4.3**: Why is it critical that `model.fit()` is called only on `X_train` and `y_train`, and never on `X_test`?

## Common Mistakes and Debugging
| Mistake | Why it happens | Correction |
|---|---|---|
| Forgetting `stratify=y` | Assuming random splitting is sufficient | Always pass `stratify=y` when dealing with multi-class classification with unequal class sizes. |
| Fitting on the test set | Writing `model.fit(X_test, y_test)` | Fit strictly on `X_train` and `y_train`; use `X_test` only for evaluation. |
| Inconsistent tuple unpacking order | Writing `X_train, y_train, X_test, y_test = ...` | Remember scikit-learn's return order: `X_train, X_test, y_train, y_test`. |

## Best Practices
- **Always Stratify Multi-Class Splits**: Use `stratify=y` to prevent minority classes from disappearing from test sets.
- **Fix Random Seeds During Experimentation**: Setting `random_state=42` guarantees that everyone on your team observes identical partition splits and metrics.

## Security Considerations
- **Prevent Data Leakage**: Keeping the test set strictly isolated during feature engineering and model training ensures that test metrics reflect true generalization performance rather than leaked answers.

## Summary
To evaluate model generalization, `main.py` splits 120 samples into 90 training rows (75%) and 30 test rows (25%). Because class distributions are imbalanced (ranging from 56 break recommendations to 13 practice problem recommendations), passing `stratify=y` ensures each subset preserves the exact class proportions of the overall dataset. Setting `random_state=42` guarantees full experimental reproducibility.

## Knowledge-check Questions
1. How many samples are in the training set and test set after executing `train_test_split(..., test_size=0.25)`?
2. What does the parameter `stratify=y` do?
3. Why is stratification especially important for the `Practice problems` class in this dataset?
4. What exact test set counts are produced for each of the four strategy classes?
5. What is data leakage, and how does proper train/test isolation prevent it?

## References
- scikit-learn `train_test_split` Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html
- Kohavi, R. (1995). "A Study of Cross-Validation and Bootstrap for Accuracy Estimation and Model Selection". *IJCAI*.
- Project 20 code: `main.py` lines 61-63.
