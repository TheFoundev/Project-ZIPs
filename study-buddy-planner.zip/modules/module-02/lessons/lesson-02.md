# Lesson 02: Feature Scales, Constraints & Bounded Domains

**Lesson ID:** lesson-02
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- State the exact numerical scales and boundary constraints for each of the four features
- Analyze descriptive statistics (mean, std, quartiles, min, max) using `df.describe()`
- Explain how decision trees determine split thresholds on integer-valued features
- Describe why bounded input domains prevent out-of-distribution inference failures
- Interpret why decision boundaries fall on fractional values like 2.50 and 3.50

## Prerequisites
- Completion of Lesson 01 (Ingesting `study_situations.csv`)
- Understanding of basic descriptive statistics (mean, minimum, maximum)

## Concept Explanation

### The Four Bounded Feature Domains
Machine learning algorithms do not understand semantics; they operate purely on numbers. If input numbers lack meaningful constraints, models can be fed absurd inputs (such as -50 hours or energy level 9,000) leading to nonsensical predictions.

In `main.py`, each of the four features is tightly bounded:
1. `hours_left`: $[1, 10]$
   - Minimum: 1 hour (emergency, last-minute crunch)
   - Maximum: 10 hours (full dedicated study day)
2. `difficulty`: $[1, 5]$
   - 1 = Elementary / straightforward
   - 3 = Moderate / typical college material
   - 5 = Complex, abstract, highly demanding
3. `energy`: $[1, 5]$
   - 1 = Physically and mentally drained
   - 3 = Normal baseline alertness
   - 5 = Peak vitality, hyper-focused
4. `distraction`: $[1, 5]$
   - 1 = Silent, undisturbed sanctuary
   - 3 = Typical ambient background noise
   - 5 = Constant interruptions, loud chaos

```
                          FEATURE SCALES COMPARISON
                          
   hours_left   [1 --------------------------------- 10]  (10 distinct levels)
   difficulty   [1 ------- 3 ------- 5]                   (5 Likert levels)
   energy       [1 ------- 3 ------- 5]                   (5 Likert levels)
   distraction  [1 ------- 3 ------- 5]                   (5 Likert levels)
```

### Statistical Profile of the Dataset
When we compute summary statistics on `df[FEATURES]`, we discover how student situations are distributed in the real dataset:

| Feature | Count | Mean | Std Dev | Min | 25% | Median (50%) | 75% | Max |
|---|---|---|---|---|---|---|---|---|
| `hours_left` | 120 | 5.81 | 3.13 | 1.00 | 3.00 | 6.00 | 9.00 | 10.00 |
| `difficulty` | 120 | 2.73 | 1.45 | 1.00 | 1.00 | 2.00 | 4.00 | 5.00 |
| `energy` | 120 | 3.15 | 1.48 | 1.00 | 2.00 | 3.00 | 4.25 | 5.00 |
| `distraction` | 120 | 2.77 | 1.28 | 1.00 | 2.00 | 3.00 | 4.00 | 5.00 |

Key takeaways:
- The average student scenario in the dataset has approximately 5.8 hours available.
- Energy averages 3.15, indicating a slightly above-average baseline stamina across scenarios.
- The minimums and maximums across all 120 records strictly adhere to the $[1, 10]$ and $[1, 5]$ intervals. No erroneous outliers or corrupted rows exist.

### How Decision Trees Split Discrete Integer Scales
In `main.py`, the learned rules contain thresholds such as:
- `hours_left <= 2.50`
- `energy <= 2.50`
- `distraction <= 3.50`
- `difficulty <= 3.50`

Why does the algorithm use decimals like `2.50` and `3.50` when the features in the CSV are all whole integers?
In scikit-learn's `DecisionTreeClassifier`, when evaluating where to place an orthogonal decision boundary between two adjacent integer training values (such as separating 2 from 3), the algorithm calculates the midpoint:
$$\text{Threshold} = \frac{v_1 + v_2}{2} = \frac{2 + 3}{2} = 2.50$$
By placing the split threshold halfway between adjacent integers, any future integer input is cleanly partitioned without ambiguity:
- If `hours_left` $\le 2$, it satisfies $\le 2.50$.
- If `hours_left` $\ge 3$, it satisfies $> 2.50$.

## Relevant Code (from main.py, lines 31-36 and 76)
```python
# Lines 31-36:
QUESTIONS = [
    ("How many hours do you have left? (1-10) ", "hours_left", 1, 10),
    ("How difficult is the subject? (1-5) ", "difficulty", 1, 5),
    ("How much energy do you have? (1-5) ", "energy", 1, 5),
    ("How distracted do you feel? (1-5) ", "distraction", 1, 5),
]

# Line 76:
print(export_text(model, feature_names=FEATURES))
```

## Code Explanation
- **Lines 31-36**: Encodes the numeric boundaries directly into the prompt metadata tuple `(prompt_text, feature_key, min_value, max_value)`. This ties the data scale directly to the validation engine.
- **Line 76**: Outputs the learned decision tree in text format, revealing the midpoint thresholds ($2.50$, $3.50$) derived from these bounded scales.

## Worked Example
Suppose a student enters the following values:
- `hours_left = 2`
- `energy = 3`
- `distraction = 2`
- `difficulty = 4`

Let us evaluate the threshold tests:
1. `hours_left <= 2.50`: Since $2 \le 2.50$, the test evaluates to **True**.
2. The tree terminates immediately at the leaf: `class: Quick review`.
Because available time is so scarce (2 hours or fewer), the student's moderate energy and difficult subject do not matter; the time constraint dominates.

## Step-by-Step Student Instructions
1. Open Python and load `study_situations.csv`.
2. Compute descriptive statistics:
   ```python
   df[["hours_left", "difficulty", "energy", "distraction"]].describe()
   ```
3. Check the minimum and maximum for each column to confirm no negative numbers or numbers exceeding 10.
4. Verify that the median (50%) value for `hours_left` is 6.0.
5. Identify why midpoint thresholds like 2.50 cleanly partition integer inputs.

## Expected Output or Observable Behaviour
When calling `df[["hours_left", "difficulty", "energy", "distraction"]].agg(["min", "max"])`, Python outputs:
```
     hours_left  difficulty  energy  distraction
min           1           1       1            1
max          10           5       5            5
```
This confirms that the dataset strictly conforms to the expected domain boundaries.

## Practical Exercises
- **Exercise 2.1**: Explain why a split threshold of `hours_left <= 2.50` produces identical decisions for integer inputs as `hours_left <= 2`.
- **Exercise 2.2**: If a student entered `distraction = 3.5` in an interactive prompt, what would happen in `ask_situation()`? Check `main.py` lines 43-48.
- **Exercise 2.3**: What percentage of records in `study_situations.csv` have `hours_left <= 2`? Write a one-line pandas query to calculate this.

## Common Mistakes and Debugging
| Mistake | Why it happens | Correction |
|---|---|---|
| Entering decimal numbers into CLI | Typing `2.5` for hours | Enter whole integers (1, 2, 3...) as required by `int(raw)`. |
| Thinking 2.50 means the tree expects decimals | Misinterpreting scikit-learn split points | Midpoints are placed halfway between adjacent integer training values ($2$ and $3$). |
| Assuming distraction is on a 1-10 scale | Inadvertently confusing `hours_left` with Likert scales | Remember: only `hours_left` extends to 10; all other attributes are 1-5. |

## Best Practices
- **Define Explicit Domain Boundaries**: Every feature should have a documented, validated operational interval to prevent out-of-distribution bugs.
- **Understand Split Midpoints**: Recognizing that decision trees place cutoffs at $(a+b)/2$ makes interpreting tree visualizations and ASCII rules intuitive.

## Security Considerations
- **Prevent Out-of-Bounds Inference**: Bounding inputs prevents out-of-distribution anomalies where an attacker inputs extreme numbers (e.g. $10^{18}$) that could distort numeric calculations.

## Summary
The four situational features in `study_situations.csv` operate on tightly bounded numeric intervals: `hours_left` spans 1 to 10, while `difficulty`, `energy`, and `distraction` use 1-to-5 Likert ratings. In the learned decision tree, orthogonal split thresholds fall on midpoints (2.50 and 3.50), cleanly and unambiguously dividing integer inputs into distinct branches.

## Knowledge-check Questions
1. What is the allowable integer range for `hours_left`?
2. What is the allowable integer range for `difficulty`, `energy`, and `distraction`?
3. Why does scikit-learn output threshold values like `2.50` and `3.50` when the training data consists entirely of integers?
4. What is the median value of `hours_left` across the 120 dataset records?
5. How does bounding feature intervals protect the model from out-of-distribution failures?

## References
- scikit-learn Tree Splitting Criterion: https://scikit-learn.org/stable/modules/tree.html#mathematical-formulation
- Likert, R. (1932). "A Technique for the Measurement of Attitudes". *Archives of Psychology*.
- Project 20 code: `main.py` lines 31-36.
