# Lesson 03: Profile of the Four Strategy Classes

**Lesson ID:** lesson-03
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Identify and describe each of the four target study strategy classes
- Quantify the exact sample count and percentage of each class in `study_situations.csv`
- Explain the pedagogical purpose and behavioral guidelines associated with each strategy
- Articulate why class imbalance naturally arises in real-world educational datasets
- Map specific combinations of student attributes to their corresponding optimal strategy

## Prerequisites
- Completion of Lessons 01 and 02 in Module 02
- Basic understanding of multi-class classification targets

## Concept Explanation

### The Four Actionable Educational Strategies
A study recommendation system is only as valuable as the actions it prescribes. In the Study Buddy Planner, the target variable `strategy` consists of four distinct, non-overlapping educational categories designed to guide students toward maximum effectiveness:

```
                          THE FOUR STRATEGY CLASSES
                          
      ┌─────────────────────────────────────────────────────────────┐
      │  Take a break first  │  56 samples (46.7%)                 │
      ├──────────────────────┼──────────────────────────────────────┤
      │  Deep focus block    │  30 samples (25.0%)                 │
      ├──────────────────────┼──────────────────────────────────────┤
      │  Quick review        │  21 samples (17.5%)                 │
      ├──────────────────────┼──────────────────────────────────────┤
      │  Practice problems   │  13 samples (10.8%)                 │
      └─────────────────────────────────────────────────────────────┘
                             Total = 120 samples
```

### Deep Dive into Each Strategy

#### 1. `Take a break first` (56 occurrences, 46.7%)
- **Pedagogical Meaning**: A structured, restorative pause before attempting any cognitive tasks.
- **When Triggered**:
  - Whenever energy is critically low (`energy <= 2.50`, meaning energy 1 or 2), regardless of subject difficulty or time available.
  - Or whenever ambient distraction is overwhelming (`distraction > 3.50`, meaning distraction 4 or 5), even if energy is high.
- **Why It Matters**: Attempting to force focus when biologically depleted or in an uncontrollably chaotic environment produces cognitive friction, elevated cortisol, and retention failure. A 20-30 minute walk, nap, or quiet reset restores baseline prefrontal cortex functioning.
- **Why It Is the Majority Class**: In real life, students frequently encounter study sessions when tired or distracted. Having 46.7% of the dataset fall into this class reflects the realistic prevalence of fatigue and disruption in student life.

#### 2. `Deep focus block` (30 occurrences, 25.0%)
- **Pedagogical Meaning**: A sustained, uninterrupted period of deep cognitive immersion (e.g. 90-120 minutes) dedicated to reading, conceptual synthesis, and note-taking.
- **When Triggered**:
  - Ample time available (`hours_left > 2.50`).
  - Adequate stamina (`energy > 2.50`).
  - Low-to-moderate distraction (`distraction <= 3.50`).
  - Straightforward-to-moderate subject difficulty (`difficulty <= 3.50`, meaning difficulty 1, 2, or 3).
- **Behavioral Protocol**: Close all browser tabs, mute notifications, and engage in continuous conceptual learning using the Pomodoro technique or uninterrupted flow blocks.

#### 3. `Quick review` (21 occurrences, 17.5%)
- **Pedagogical Meaning**: Rapid, low-friction revision focusing on high-yield summaries, flashcards, or formula sheets.
- **When Triggered**:
  - Limited time available (`hours_left <= 2.50`, meaning 1 or 2 hours remaining).
- **Behavioral Protocol**: Because time is scarce, attempting to start massive new textbook chapters or open-ended assignments induces panic. Quick review leverages spacing and active recall in compact 15-to-30 minute intervals, maximizing retention per minute.

#### 4. `Practice problems` (13 occurrences, 10.8%)
- **Pedagogical Meaning**: Rigorous, hands-on active problem-solving, code implementation, or mathematical derivations.
- **When Triggered**:
  - Ample time available (`hours_left > 2.50`).
  - High energy (`energy > 2.50`).
  - Low distraction (`distraction <= 3.50`).
  - High subject difficulty (`difficulty > 3.50`, meaning difficulty 4 or 5).
- **Why It Is the Rarest Class**: Active problem-solving is cognitively demanding. It requires all three positive conditions to align: sufficient time, high energy, and a calm environment. When facing difficult material without these conditions, students either need a break or a high-level review first.

## Relevant Code (from main.py, lines 108-111)
```python
labels = sorted(df["strategy"].unique())
cm = confusion_matrix(y_test, predictions, labels=labels)
fig, ax = plt.subplots(figsize=(7, 5.5))
ConfusionMatrixDisplay(cm, display_labels=labels).plot(ax=ax, cmap="Purples", colorbar=False)
```

## Code Explanation
- **Line 108**: Extracts all unique strategy labels from the dataset using `df["strategy"].unique()`, and sorts them alphabetically:
  `['Deep focus block', 'Practice problems', 'Quick review', 'Take a break first']`.
- **Line 109**: Passes the sorted list of labels to `confusion_matrix()`, guaranteeing deterministic, aligned axes.
- **Lines 110-111**: Renders the multi-class confusion matrix displaying all four strategies.

## Worked Example
Let us trace which strategy is selected for two distinct situations:
- **Situation A**: `hours_left = 6, difficulty = 5, energy = 4, distraction = 1`
  - Hours left > 2.50: True
  - Energy > 2.50: True (energy is 4)
  - Distraction <= 3.50: True (distraction is 1)
  - Difficulty > 3.50: True (difficulty is 5)
  - Strategy: **Practice problems**
- **Situation B**: `hours_left = 8, difficulty = 2, energy = 4, distraction = 5`
  - Hours left > 2.50: True
  - Energy > 2.50: True (energy is 4)
  - Distraction > 3.50: True (distraction is 5)
  - Strategy: **Take a break first**

Notice how Situation B has 8 hours and high energy, but because distraction is 5, the model directs the student to take a break first or change location.

## Step-by-Step Student Instructions
1. Load `study_situations.csv` into a pandas DataFrame.
2. Count the occurrences of each strategy using:
   ```python
   df["strategy"].value_counts()
   ```
3. Calculate the relative proportions of each class using:
   ```python
   df["strategy"].value_counts(normalize=True) * 100
   ```
4. Verify that `Take a break first` accounts for 46.7% and `Practice problems` accounts for 10.8%.
5. Confirm that the total row count across all four strategies is 120.

## Expected Output or Observable Behaviour
Running `df["strategy"].value_counts()` in Python prints:
```
strategy
Take a break first    56
Deep focus block      30
Quick review          21
Practice problems     13
Name: count, dtype: int64
```
This confirms that the four strategies are present in the exact proportions documented above.

## Practical Exercises
- **Exercise 3.1**: Why is `Practice problems` the least frequent class in the dataset? What does this reflect about real-world learning conditions?
- **Exercise 3.2**: Under what conditions would a student with 10 hours available receive a `Take a break first` recommendation? Find at least two rows in the CSV where `hours_left == 10` and `strategy == "Take a break first"`.
- **Exercise 3.3**: If a school wants to encourage more `Deep focus block` sessions, which input feature (hours, difficulty, energy, or distraction) is easiest for a student to control directly?

## Common Mistakes and Debugging
| Mistake | Why it happens | Correction |
|---|---|---|
| Assuming all four classes have equal samples | Expecting a perfectly balanced dataset | Recognize that real datasets often have natural class imbalances. |
| Misinterpreting `Take a break first` as "don't study" | Viewing breaks as unproductive | Emphasize that strategic rest restores cognitive capacity for future sessions. |
| Forgetting to sort `labels` before confusion matrix | Generating inconsistent matrix axis ordering | Always sort labels alphabetically using `sorted(df["strategy"].unique())`. |

## Best Practices
- **Design Action-Oriented Labels**: Target classes should clearly tell the user *what specific behavior* to enact next.
- **Respect Cognitive Bottlenecks**: High cognitive demand tasks (like `Practice problems`) should only be recommended when prerequisite biological conditions (high energy, low distraction) are met.

## Security Considerations
- **Deterministic Label Ordering**: Sorting categorical labels alphabetically prevents permutation errors across differing Python versions or operating system locales.

## Summary
The Study Buddy Planner classifies student situations into four actionable strategies: `Take a break first` (56 samples, 46.7%), `Deep focus block` (30 samples, 25.0%), `Quick review` (21 samples, 17.5%), and `Practice problems` (13 samples, 10.8%). Each strategy reflects an evidence-based pedagogical approach suited to specific alignments of time, difficulty, energy, and environmental distraction.

## Knowledge-check Questions
1. What are the exact sample counts for each of the four strategies in `study_situations.csv`?
2. Which strategy is the most frequent in the dataset, and what percentage of total samples does it represent?
3. Which strategy is the least frequent in the dataset, and why?
4. What conditions must be satisfied for the model to recommend `Practice problems`?
5. Why does `main.py` explicitly sort `labels` before generating the confusion matrix?

## References
- Ericsson, K. A. (1993). "The role of deliberate practice in the acquisition of expert performance". *Psychological Review*.
- Newport, C. (2016). *Deep Work: Rules for Focused Success in a Distracted World*.
- Project 20 code: `main.py` lines 108-111.
