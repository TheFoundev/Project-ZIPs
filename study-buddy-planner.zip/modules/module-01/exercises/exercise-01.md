# Module 1 Exercises: Project Overview & Explainable Recommendations

## Exercise 1.1: Problem Formulation & Recommendation Framing (10 min)
**Objective:** Formulate the study strategy recommendation problem as a supervised multi-class classification task and contrast it with regression and binary classification.

**Problem Statement:** You are designing an intelligent academic advisor to help students avoid decision fatigue. You must define why recommending one of four study strategies (`Deep focus block`, `Practice problems`, `Quick review`, `Take a break first`) constitutes a multi-class classification problem rather than a continuous numeric regression or a binary classification problem.

**Requirements:**
1. Define supervised learning in the context of the study situation dataset.
2. Differentiate multi-class classification from binary classification using the four strategy outcomes.
3. Explain why numeric regression (e.g. predicting a continuous floating-point score) is an inappropriate modeling choice for selecting discrete study behaviors.
4. Describe how matching study strategies to student constraints reduces cognitive load.

**Constraints:** Base your justification on the actual project architecture in `main.py` and the target values in `data/study_situations.csv`.

**Expected Behaviour:** A written analysis (4-6 sentences) clearly articulating the task formulation and justifying multi-class classification.

**Acceptance Criteria:**
- [ ] Correctly identifies the problem as supervised multi-class classification.
- [ ] Names all 4 strategy classes accurately.
- [ ] Clearly articulates why continuous regression fails for discrete behavioral actions.
- [ ] Connects student cognitive load reduction to automated recommendation.

**Hints:**
- Consider: Can a student do "2.73 of a strategy"? No, they need an explicit, actionable category.
- Recall that binary classification only accommodates two classes (0 vs 1), whereas here we have four.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes

---

## Exercise 1.2: Explainability Audit & Rule Interpretability (15 min)
**Objective:** Contrast black-box neural approaches with transparent decision trees and evaluate the pedagogical necessity of auditable rules.

**Problem Statement:** A student using an automated study planner is told to "Take a break first" even though they have 5 hours left before an exam. The student feels frustrated and skeptical. You need to explain how an explainable decision tree allows the student to audit this recommendation and build metacognitive trust.

**Requirements:**
1. Contrast a black-box model (like a deep neural network) with a white-box model (like a decision tree) in terms of explainability.
2. Reference the quote from `main.py` line 8: "the rules are printed so you can question them".
3. Trace the logic showing how high distraction (`distraction > 3.50`) or low energy (`energy <= 2.50`) justifies the "Take a break first" recommendation regardless of available time.
4. Explain how understanding the rule helps the student regulate their study habits.

**Constraints:** Use the learned rules extracted by `export_text()` from `main.py`.

**Expected Behaviour:** A structured walkthrough showing how rule transparency transforms an unexpected recommendation into a teachable moment.

**Acceptance Criteria:**
- [ ] White-box vs black-box trade-off is clearly explained.
- [ ] Explains how transparency builds trust and promotes metacognition.
- [ ] Identifies the exact conditional split (`energy <= 2.50` or `distraction > 3.50`) triggering the break recommendation.
- [ ] Connects back to the educational philosophy of questioning algorithmic advice.

**Hints:**
- Review the ASCII rule output printed by `main.py`.
- Notice that `hours_left > 2.50` leads to a split on `energy <= 2.50`.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 1.3: Input Feature State Space Exploration (15 min)
**Objective:** Map real-world study scenarios into the 4-dimensional feature vector defined by `FEATURES` and verify valid numerical ranges.

**Problem Statement:** You need to translate real-world student descriptions into numerical feature vectors that match the input requirements of the Study Buddy Planner model.

**Requirements:**
1. List the four features in `FEATURES` with their valid integer bounds.
2. Convert the following three student scenarios into numeric feature dictionaries:
   - **Scenario A**: Maya has an exam next week (7 hours available), feels well-rested (energy: 4), is studying in a quiet room (distraction: 1), and is revising advanced organic chemistry mechanisms (difficulty: 5).
   - **Scenario B**: Alex has 1 hour before dinner, feels moderately tired (energy: 2), has his phone buzzing (distraction: 4), and is reviewing basic vocabulary (difficulty: 1).
   - **Scenario C**: Jordan has 4 hours available, is running on 3 hours of sleep (energy: 1), in a library (distraction: 2), tackling calculus integrals (difficulty: 4).
3. Validate that all numbers fall within allowable bounds (`1-10` for hours, `1-5` for scales).

**Constraints:** Do not use out-of-bounds numbers or floating-point decimals.

**Expected Behaviour:** Three cleanly structured Python dictionaries mapping feature keys to valid integers.

**Acceptance Criteria:**
- [ ] All 4 feature keys (`hours_left`, `difficulty`, `energy`, `distraction`) are present in all three dictionaries.
- [ ] Values accurately reflect the scenario descriptions.
- [ ] All values satisfy the bounded range constraints.
- [ ] Dictionaries can be converted directly into a pandas DataFrame without schema errors.

**Hints:**
- Remember the ordering: `hours_left` (1-10), `difficulty` (1-5), `energy` (1-5), `distraction` (1-5).
- Low energy corresponds to 1 or 2; high difficulty corresponds to 4 or 5.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes

---

## Exercise 1.4: Pipeline Execution & Artifact Verification (15 min)
**Objective:** Execute `main.py` from the command line, verify execution output, and inspect all generated artifacts.

**Problem Statement:** Run `main.py` in both scripted mode and interactive mode, verify the terminal output, and confirm the generation of all three persistent files in `outputs/`.

**Requirements:**
1. Execute `python main.py` in the terminal and record the reported accuracy.
2. Confirm that the `outputs/` directory contains:
   - `study_tree.png`
   - `confusion_matrix.png`
   - `rules.txt`
3. Inspect `rules.txt` and confirm that it contains accuracy, learned rules, demo plans, and the classification report.
4. Execute `python main.py --interactive` and test one personal scenario.

**Constraints:** Ensure you are in the project root directory where `main.py` is located.

**Expected Behaviour:** Terminal outputs match expected accuracy (100.0%) and all three files exist on disk with non-zero size.

**Acceptance Criteria:**
- [ ] Scripted execution succeeds with exit code 0.
- [ ] Accuracy is recorded as 100.0%.
- [ ] All 3 files in `outputs/` are verified.
- [ ] Interactive mode prompts 4 questions sequentially and returns a valid strategy.

**Hints:**
- Use `ls -lh outputs/` to check file sizes.
- Use `cat outputs/rules.txt` to view the saved audit log.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes
