# Lesson 01: The Study Advisor Problem

**Lesson ID:** lesson-01
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define the real-world operational challenge of study planning and student decision fatigue
- Formulate study strategy selection as a machine learning recommendation task
- Differentiate between subjective human advice and algorithmic recommendation engines
- Identify the four target study strategies modeled in the project
- Explain why matching study strategies to student constraints improves learning efficiency

## Prerequisites
- Familiarity with basic high school or college study routines
- Basic conceptual distinction between supervised classification and continuous regression

## Concept Explanation

### The Challenge of Modern Study Planning
Every student encounters moments of severe decision fatigue when attempting to study. Consider a typical evening: you sit down at your desk with several assignments due later in the week. However, you are physically tired from a long day, your phone buzzes with social notifications, the textbook subject is dense and difficult, and you only have two hours before you must sleep.

What should you do?
- Should you force yourself into a 2-hour marathon of high-intensity calculus problems?
- Should you spend 20 minutes doing a rapid flashcard review and call it a night?
- Should you take a 30-minute nap or walk first to recover mental clarity?

When students make poor choices—such as attempting deep focus when completely drained—they experience cognitive friction, frustration, and eventual procrastination. Conversely, when students choose low-effort review when they have four uninterrupted hours and high energy, they fail to capitalize on peak learning conditions.

### Algorithmic Recommendation vs Human Intuition
Human mentors, tutors, and academic advisors routinely assess student situations by evaluating multiple constraint factors: available time, topic difficulty, fatigue, and environmental distractions. However, human advisors are not accessible on demand at 11:00 PM on a Tuesday.

An automated recommendation system leverages machine learning to formalize this advisory wisdom. By training on historical scenarios where specific strategies yielded optimal outcomes, an algorithm can instantly map a student's present state to an evidence-based study plan.

### Multi-Class Recommendation Target
Unlike binary classification (which distinguishes between two outcomes like spam vs ham), the Study Buddy Planner addresses a **multi-class classification** recommendation problem. The system outputs one of four distinct study strategies:
1. **Take a break first**: When cognitive fatigue or environmental chaos is too high, attempting immediate study is counter-productive. A timed break, hydration, or meditation restores baseline attention.
2. **Quick review**: When time is severely constrained (e.g., two hours or fewer), embarking on exhaustive problem sets causes panic. High-yield summary review or flashcards maximizes value in short bursts.
3. **Deep focus block**: When time is ample, energy is high, distraction is low, and the material is accessible, the student enters a flow state for sustained comprehension and notes synthesis.
4. **Practice problems**: When the material is challenging, active recall and hands-on application are essential to build neurological pathways, provided the student has adequate energy and focus.

## Relevant Code (from main.py, lines 1-9)
```python
"""Project 20: The Study Buddy Planner (decision tree).

Run:
    python main.py              # scripted demo
    python main.py --interactive # answer four questions

A tiny recommendation system.  The decision tree learns rules for choosing a
study strategy, and the rules are printed so you can question them.
"""
```

## Code Explanation
- **Lines 1-2**: Identifies the project as "Project 20: The Study Buddy Planner", utilizing a decision tree algorithm.
- **Lines 4-5**: Explicitly documents the two modes of operation: the default scripted demo (`python main.py`) and the interactive questionnaire mode (`python main.py --interactive`).
- **Lines 7-9**: Highlights the foundational philosophy of the project: it is a "tiny recommendation system" whose learned rules are explicitly printed so students and educators can inspect and question them.

## Worked Example
Let us examine how a student scenario translates into a recommendation. Suppose a student reports the following attributes:
- Available Time: 2 hours
- Subject Difficulty: 4 out of 5 (Hard)
- Current Energy: 3 out of 5 (Moderate)
- Ambient Distraction: 2 out of 5 (Quiet)

If this student attempts to tackle new practice problems across the entire syllabus, 2 hours is insufficient to complete the problem sets, leading to incomplete work and anxiety. The decision tree recognizes that because `hours_left <= 2.50`, the optimal educational recommendation is **Quick review**. The student spends 45 minutes reviewing high-priority summary sheets, cements key concepts, and avoids burnout.

## Step-by-Step Student Instructions
1. Open your terminal and navigate to the project directory:
   ```bash
   cd "beginner-projects-main/AI-ML Beginners/projects/20_study_buddy_planner"
   ```
2. Inspect `main.py` using your text editor or `head -n 25 main.py`.
3. Locate the docstring and read the project description.
4. Note the four target strategies: `Take a break first`, `Quick review`, `Deep focus block`, and `Practice problems`.
5. Run the script once without flags:
   ```bash
   python main.py
   ```
6. Observe how the system outputs demo plans for four distinct situations.

## Expected Output or Observable Behaviour
When executed, the console displays:
```
============================================================
THE STUDY BUDDY PLANNER
============================================================
Accuracy: 100.0%

                    precision    recall  f1-score   support

  Deep focus block       1.00      1.00      1.00         8
 Practice problems       1.00      1.00      1.00         3
      Quick review       1.00      1.00      1.00         5
Take a break first       1.00      1.00      1.00        14
```
This confirms that the multi-class recommender evaluates performance across all four study strategies.

## Practical Exercises
- **Exercise 1.1**: Formulate a personal study scenario: write down your current available hours, subject difficulty, energy, and distraction. Which of the four strategies would you intuitively pick?
- **Exercise 1.2**: Why would framing this problem as a regression task (e.g. predicting a continuous floating-point number from 1.0 to 4.0) be awkward and unhelpful for a student?
- **Exercise 1.3**: In what scenario would a student with 6 hours available still be advised to "Take a break first"?

## Common Mistakes and Debugging
| Mistake | Why it happens | Correction |
|---|---|---|
| Assuming the model predicts exam grades | Confusing the recommender with a grade predictor | Recognize that the target is `strategy` (an action recommendation), not an exam score. |
| Treating recommendation as binary classification | Thinking it only chooses "study" or "don't study" | Understand that the model chooses among four nuanced educational strategies. |
| Overlooking cognitive constraints | Believing study advice should only depend on time left | Acknowledge that energy and distraction strongly mediate whether studying is productive. |

## Best Practices
- **Define Actionable Classes**: Each recommendation class must translate directly into a concrete behavioral protocol (e.g., taking a 20-minute break vs doing 45 minutes of flashcards).
- **Match Algorithms to Intent**: Use classification models when selecting discrete actionable categories, reserving regression for continuous quantities.

## Security Considerations
- **No Data Leakage**: Student study logs and situational inputs are processed entirely in local application memory without sending personal study habits to third-party tracking services.

## Summary
The Study Buddy Planner solves student decision fatigue by framing study planning as a multi-class recommendation problem. Based on four situational inputs, the system selects between four distinct strategies: Deep focus block, Practice problems, Quick review, and Take a break first. Automating this decision reduces cognitive load and promotes effective study habits.

## Knowledge-check Questions
1. What are the four target strategies recommended by the Study Buddy Planner?
2. Why is study strategy recommendation framed as multi-class classification rather than binary classification?
3. How does decision fatigue negatively impact a student's study session?
4. What are the two operational modes documented in the docstring of `main.py`?
5. Under what condition is a "Quick review" recommended over a prolonged study block?

## References
- Dunlosky et al. (2013), "Improving Students' Learning With Effective Learning Techniques", *Psychological Science in the Public Interest*.
- scikit-learn Classification Guide: https://scikit-learn.org/stable/supervised_learning.html#classification
- Project 20 docstring in `main.py`, lines 1-9.
