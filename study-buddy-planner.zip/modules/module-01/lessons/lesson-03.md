# Lesson 03: The Four Situation Inputs

**Lesson ID:** lesson-03
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Identify and describe the four situational input features used in the Study Buddy Planner
- Specify the valid numeric ranges and units for each of the four features
- Explain the pedagogical significance of capturing both external constraints and internal states
- Describe how four numeric features form a multi-dimensional state space for decision trees
- Contrast continuous time modeling with Likert-style discrete scale ratings

## Prerequisites
- Completion of Lesson 01 (The Study Advisor Problem) and Lesson 02 (Why Explainability Matters)
- Basic understanding of numerical features in tabular machine learning

## Concept Explanation

### Modeling the Context of Learning
In machine learning, the performance and relevance of a model depend heavily on **feature engineering**—the choice of which variables from the real world are captured and presented to the algorithm. If essential context is omitted, the model cannot make sensible decisions.

When human beings sit down to study, their capacity to learn is shaped by an interplay between **external constraints** (how much time is left before deadlines, how difficult the subject material is) and **internal physiological/psychological states** (energy levels, ambient distraction).

The Study Buddy Planner captures this holistic context using four carefully chosen numeric features:
1. `hours_left`
2. `difficulty`
3. `energy`
4. `distraction`

```
                        STUDY SITUATION INPUTS
                        
        External Constraints                 Internal Mental States
        ┌──────────────────┐                 ┌──────────────────┐
        │    hours_left    │                 │      energy      │
        │      (1-10)      │                 │      (1-5)       │
        └──────────────────┘                 └──────────────────┘
        ┌──────────────────┐                 ┌──────────────────┐
        │    difficulty    │                 │   distraction    │
        │      (1-5)       │                 │      (1-5)       │
        └──────────────────┘                 └──────────────────┘
```

### Deep Dive into the Four Features

#### 1. `hours_left` (Scale: 1 to 10)
- **What it represents**: The total number of hours a student has available to study before their immediate deadline or end of day.
- **Why it matters**: Complex learning techniques (such as deep focus blocks or working through multi-step practice problem sets) require a minimum threshold of uninterrupted time. If a student only has 1 or 2 hours, attempting an open-ended deep focus session creates anxiety. Conversely, having 6 to 10 hours opens up possibilities for sustained deep work or taking a restorative break first.
- **Scale Range**: An integer scale from 1 (severe time crunch) to 10 (virtually entire day available).

#### 2. `difficulty` (Scale: 1 to 5)
- **What it represents**: The perceived cognitive complexity of the subject matter.
- **Why it matters**: Not all study hours require equal mental bandwidth. Reviewing a familiar, introductory topic requires vastly less cognitive effort than grappling with novel, abstract proofs or complex programming algorithms. Challenging topics demand active problem solving (`Practice problems`), while simpler topics can be synthesized during a `Deep focus block` or refreshed via a `Quick review`.
- **Scale Range**: Likert scale from 1 (Very easy / intuitive) to 5 (Extremely challenging / dense).

#### 3. `energy` (Scale: 1 to 5)
- **What it represents**: The student's subjective physical and mental stamina at the start of the study session.
- **Why it matters**: Energy is the physiological bottleneck of cognition. When a student's energy rating is 1 or 2 (exhausted), working memory capacity is severely impaired. No amount of willpower can overcome severe biological fatigue; attempting to study in this state leads to staring blankly at pages. The algorithm uses energy to enforce restorative breaks when stamina is depleted.
- **Scale Range**: Likert scale from 1 (Completely exhausted / drowsy) to 5 (Fully energized / alert).

#### 4. `distraction` (Scale: 1 to 5)
- **What it represents**: The degree of ambient, environmental, or psychological disruption present.
- **Why it matters**: Environmental factors (such as a noisy coffee shop, roommates talking, frequent phone notifications) or internal cognitive wanderings hijack executive functioning. High distraction levels (ratings 4 or 5) make deep focus impossible. Under high distraction, attempting demanding intellectual tasks results in repeated context switching. The model recognizes that high distraction requires stepping away or changing environments (`Take a break first`).
- **Scale Range**: Likert scale from 1 (Dead silent / serene focus) to 5 (Extremely noisy / chaotic).

## Relevant Code (from main.py, lines 30-36)
```python
FEATURES = ["hours_left", "difficulty", "energy", "distraction"]
QUESTIONS = [
    ("How many hours do you have left? (1-10) ", "hours_left", 1, 10),
    ("How difficult is the subject? (1-5) ", "difficulty", 1, 5),
    ("How much energy do you have? (1-5) ", "energy", 1, 5),
    ("How distracted do you feel? (1-5) ", "distraction", 1, 5),
]
```

## Code Explanation
- **Line 30**: Declares `FEATURES` as a Python list of four string column names. This ensures consistency across DataFrame column indexing, scikit-learn model fitting, and export formatting.
- **Lines 31-36**: Defines `QUESTIONS` as a structured list of 4-tuples. Each tuple encapsulates:
  1. The human-readable string prompt displayed to the user during interactive Q&A.
  2. The exact feature key string matching `FEATURES`.
  3. The lower allowable numeric bound (`low`).
  4. The upper allowable numeric bound (`high`).

## Worked Example
Let us evaluate how these four inputs define a 4-dimensional point.
Suppose Student Alice and Student Bob both report:
- `hours_left = 6`
- `difficulty = 4`

At first glance, their external academic demands are identical. However, let us examine their internal state:
- **Alice**: `energy = 4`, `distraction = 1`.
  - Alice has high stamina and a quiet library environment. The model predicts: **Practice problems**.
- **Bob**: `energy = 1`, `distraction = 4`.
  - Bob is exhausted after a shift at work, and his dorm room is loud. Even though he has 6 hours left, the model predicts: **Take a break first**.

By incorporating all four features, the recommendation engine avoids naive, one-size-fits-all scheduling.

## Step-by-Step Student Instructions
1. Open `main.py` in your editor and locate line 30 (`FEATURES`).
2. Verify that the order of features in `FEATURES` matches the keys in `QUESTIONS`.
3. Open `data/study_situations.csv` using `head -n 5 data/study_situations.csv`.
4. Check that the first four CSV column headers match `FEATURES` exactly:
   ```
   hours_left,difficulty,energy,distraction,strategy
   ```
5. Confirm that the fifth column represents the target label (`strategy`).

## Expected Output or Observable Behaviour
When inspecting the first few lines of `data/study_situations.csv`, you will observe:
```csv
hours_left,difficulty,energy,distraction,strategy
3,5,1,3,Take a break first
9,3,4,3,Deep focus block
9,4,5,3,Practice problems
6,1,4,3,Deep focus block
```
Every row provides a 4-element input vector mapping to a single strategy label.

## Practical Exercises
- **Exercise 3.1**: Create three distinct study situations representing (a) an exam tomorrow morning with low time, (b) a quiet weekend afternoon with high energy, and (c) an exhausted late-night study attempt. Write out their 4-feature numeric values.
- **Exercise 3.2**: Why are Likert scales (1 to 5) ideal for subjective metrics like `energy` and `distraction` compared to free-form text input?
- **Exercise 3.3**: If you were to add a fifth feature to describe a student's situation, what would it be, what would its scale be, and why would it improve recommendations?

## Common Mistakes and Debugging
| Mistake | Why it happens | Correction |
|---|---|---|
| Entering float values (e.g. 2.5 hours) | The CLI expects integer bounds | Enter whole numbers (e.g. 2 or 3) as enforced by `int(raw)` in `ask_situation()`. |
| Confusing `energy` scale direction | Assuming 1 means "high energy" | Remember: 1 is lowest (exhausted), 5 is highest (fully energized). |
| Confusing `distraction` scale direction | Assuming 5 means "focused" | Remember: 1 is quiet/focused, 5 is maximum chaos/distraction. |

## Best Practices
- **Standardize Input Scales**: Using consistent scales (such as 1-5 for subjective ratings) makes it easy for human users to calibrate their answers quickly.
- **Bind Prompts to Constants**: Decoupling prompts and valid boundaries into a configuration tuple (like `QUESTIONS`) simplifies validation logic and prevents code duplication.

## Security Considerations
- **Range Constraints Prevent Buffer/Logic Exploits**: Restricting inputs strictly to bounded intervals (1-10, 1-5) ensures adversarial users cannot inject extreme values (e.g. -999 or 1000000) that might distort calculations or trigger unhandled branching.

## Summary
The Study Buddy Planner models a student's learning context through four numeric features: `hours_left` (1-10), `difficulty` (1-5), `energy` (1-5), and `distraction` (1-5). By combining external deadlines and subject demands with internal physiological energy and environmental distractions, the system accurately maps real-world study conditions into an actionable state space.

## Knowledge-check Questions
1. What are the four features included in the `FEATURES` list in `main.py`?
2. What are the valid numeric bounds for `hours_left`?
3. What are the valid numeric bounds for `difficulty`, `energy`, and `distraction`?
4. In what way does `energy` act as a physiological bottleneck in study planning?
5. How does `QUESTIONS` in `main.py` maintain clean separation of concerns for interactive prompts?

## References
- Sweller, J. (2011). "Cognitive Load Theory". *Psychology of Learning and Motivation*.
- Likert, R. (1932). "A Technique for the Measurement of Attitudes". *Archives of Psychology*.
- Project 20 code: `main.py` lines 30-36.
