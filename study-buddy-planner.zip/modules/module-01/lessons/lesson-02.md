# Lesson 02: Why Explainability Matters

**Lesson ID:** lesson-02
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Contrast black-box machine learning algorithms with transparent, white-box models
- Define Explainable AI (XAI) and articulate its importance in educational technology
- Explain why students and teachers must be able to audit and verify algorithmic recommendations
- Interpret the project philosophy: "the rules are printed so you can question them"
- Identify the potential harms of unexplainable automated recommendations in learning environments

## Prerequisites
- Completion of Lesson 01 (The Study Advisor Problem)
- High-level understanding of algorithmic decision-making

## Concept Explanation

### The Black-Box Dilemma in Machine Learning
In recent years, deep neural networks, complex ensemble models (like random forests and gradient boosting machines), and large language models have achieved tremendous predictive accuracy across many domains. However, these architectures operate as **black boxes**: they take high-dimensional input vectors, pass them through millions of non-linear matrix multiplications and weights, and output a prediction.

When a black-box model makes a recommendation, it cannot provide an intuitive, human-understandable explanation of *why* that specific decision was made. If a complex neural network advises a student: "Take a break first", the student has no way of knowing whether the recommendation was triggered because their energy was low, because the subject was difficult, because their distraction was high, or because of some subtle statistical correlation in the training weights.

### Why Explainability is Paramount in Education
In educational tools, opacity is dangerous. Education is fundamentally about cultivating metacognition—the ability of students to reflect on, understand, and regulate their own learning processes.
1. **Building Trust**: If an AI advisor makes an opaque suggestion that feels counter-intuitive, a student will simply ignore the tool. Transparency builds trust because the student can see the clear logic.
2. **Promoting Self-Regulation**: When a student sees that the model recommended "Take a break first" because `distraction > 3.50`, the student learns an important metacognitive truth: high environmental distraction sabotages study sessions. The rule itself teaches the student how to evaluate their environment.
3. **Auditing and Bias Detection**: Teachers and instructional designers must be able to verify that the recommendation system is operating on sound pedagogical principles rather than spurious data correlations.

### White-Box Models: Decision Trees as Explainable Engines
A **decision tree** is the quintessential "white-box" model. Every decision made by a decision tree follows a deterministic sequence of boolean conditional tests (e.g., `hours_left <= 2.50`).
Because these rules can be directly extracted and translated into plain English or visual flowcharts, anyone—students, parents, teachers, and software engineers—can audit the complete decision hierarchy.

As the docstring of `main.py` explicitly notes:
> *"The decision tree learns rules for choosing a study strategy, and the rules are printed so you can question them."*

The keyword here is **question**. An explainable recommendation system does not demand blind obedience. It presents its reasoning so the user can agree, disagree, or refine the underlying rules.

## Relevant Code (from main.py, lines 7-8 and 75-76)
```python
# Lines 7-8:
# The decision tree learns rules for choosing a
# study strategy, and the rules are printed so you can question them.

# Lines 75-76:
print("Learned rules:
")
print(export_text(model, feature_names=FEATURES))
```

## Code Explanation
- **Lines 7-8**: In the header docstring, the author states the pedagogical mission: printing rules allows human stakeholders to challenge the model's logic.
- **Lines 75-76**: Invokes `scikit-learn`'s `export_text()` utility, passing the trained `model` and the explicit list of feature names (`FEATURES`). This prints an ASCII tree displaying exact numerical thresholds for every split.

## Worked Example
Consider what happens when we inspect the printed rules from `main.py`:
```
|--- hours_left <= 2.50
|   |--- class: Quick review
|--- hours_left >  2.50
|   |--- energy <= 2.50
|   |   |--- class: Take a break first
```
Suppose a student asks: *"Why did the system tell me to Take a break first when I have 5 hours before my exam?"*
With an opaque neural network, the student gets no answer.
With the Study Buddy Planner, the mentor or student traces the rules:
1. `hours_left > 2.50` (5 hours is greater than 2.50, so time is ample).
2. `energy <= 2.50` (The student reported energy level 2 out of 5).
Because energy is critically depleted, the model wisely deduces that attempting to study for 5 hours while exhausted will fail. The student can now understand and validate the pedagogical wisdom behind the recommendation.

## Step-by-Step Student Instructions
1. Open terminal and run `main.py`:
   ```bash
   python main.py
   ```
2. Locate the console section labeled `Learned rules:`.
3. Count how many feature splits exist in the printed rule tree.
4. Verify that each leaf node terminates in one of the four study strategy classes.
5. Identify the threshold used for the very first split (`hours_left <= 2.50`).

## Expected Output or Observable Behaviour
In the terminal, you will see the exact hierarchical rule output:
```
Learned rules:

|--- hours_left <= 2.50
|   |--- class: Quick review
|--- hours_left >  2.50
|   |--- energy <= 2.50
|   |   |--- class: Take a break first
|   |--- energy >  2.50
|   |   |--- distraction <= 3.50
|   |   |   |--- difficulty <= 3.50
|   |   |   |   |--- class: Deep focus block
|   |   |   |--- difficulty >  3.50
|   |   |   |   |--- class: Practice problems
|   |   |--- distraction >  3.50
|   |   |   |--- class: Take a break first
```
Notice how every single conditional statement is immediately readable and logically sound.

## Practical Exercises
- **Exercise 2.1**: Explain in your own words why printing decision rules empowers a student more than receiving an unexplained automated notification on their phone.
- **Exercise 2.2**: Looking at the printed rules above, what happens if a student has 4 hours left, energy = 4, distraction = 4, and difficulty = 1? Which rule path is triggered, and why?
- **Exercise 2.3**: What is one potential risk of using an unexplainable AI model to decide which students receive remedial tutoring?

## Common Mistakes and Debugging
| Mistake | Why it happens | Correction |
|---|---|---|
| Believing higher accuracy is always better than explainability | Prioritizing raw benchmark numbers over usability | In human-centric applications, an explainable model with 95% accuracy is far superior to an opaque model with 96% accuracy. |
| Assuming rules must be manually hardcoded | Confusing expert systems with machine learning | The decision tree *learned* these rules automatically from data; they were not hardcoded if-statements. |
| Ignoring edge cases in the rule thresholds | Overlooking floating-point cutoffs like 2.50 and 3.50 | Understand that scikit-learn places thresholds halfway between observed integer training values. |

## Best Practices
- **Prefer Interpretable Models for Sensitive Domains**: In education, healthcare, and finance, start with decision trees or linear models before considering complex black-box architectures.
- **Provide Human-in-the-Loop Verification**: Ensure systems provide explanations alongside recommendations so end-users retain agency and autonomy.

## Security Considerations
- **Algorithmic Accountability**: Transparent rules make it possible to audit systems for unfair bias or unintended discrimination, ensuring compliance with ethical AI standards.

## Summary
Explainable AI (XAI) ensures that the internal decision logic of machine learning systems can be understood and audited by humans. In educational applications, transparent decision trees build student trust, promote metacognitive self-regulation, and allow educators to verify that recommendations adhere to sound pedagogical principles.

## Knowledge-check Questions
1. What is the fundamental difference between a black-box model and a white-box model?
2. Why is explainability especially critical in educational recommendation tools?
3. What scikit-learn function is used in `main.py` to extract human-readable text rules?
4. What did the author of `main.py` mean by writing "the rules are printed so you can question them"?
5. How does seeing the rule `distraction > 3.50 -> Take a break first` help a student develop metacognitive awareness?

## References
- Ribeiro, M. T., Singh, S., & Guestrin, C. (2016). ""Why Should I Trust You?": Explaining the Predictions of Any Classifier". *ACM SIGKDD*.
- Molnar, C. (2022). *Interpretable Machine Learning: A Guide for Making Black Box Models Explainable*.
- scikit-learn `export_text` documentation: https://scikit-learn.org/stable/modules/generated/sklearn.tree.export_text.html
