# Lesson 01: Command-Line Interface Routing & sys.argv

- **Lesson ID**: `module-05-lesson-01`
- **Module**: `module-05` (Interactive Mode & Input Validation)
- **Duration**: 30 minutes

## Purpose and Learning Objectives
In modern software engineering and production machine learning, a script rarely operates in a single, inflexible mode. Data scientists and software engineers require scripts that can execute non-interactively in automated continuous integration (CI/CD) pipelines, scheduled cron tasks, or unit test suites, while simultaneously providing an intuitive interactive terminal mode for human practitioners and end users.

By the end of this lesson, you will be able to:
1. Explain how Python inspects and parses command-line arguments using the standard library `sys.argv` list.
2. Implement conditional execution routing in ML applications based on user-supplied command-line flags.
3. Understand the operational trade-offs between zero-dependency `sys.argv` checks and high-level CLI frameworks like `argparse`, `click`, or `typer`.
4. Design robust dual-mode scripts that prevent automated automation runners from freezing on blocking input calls.

---

## Prerequisites
Before starting this lesson, you should be familiar with:
- Running Python scripts from the operating system shell (`bash` or PowerShell).
- Passing positional parameters and flags to terminal commands (e.g., `python script.py --help`).
- Python standard library imports (`import sys`).
- Basic conditional control flow (`if`, `elif`, `else`).

---

## Concept Explanation

### What is `sys.argv`?
When you launch a Python program from a terminal shell, the operating system's process executor converts the command string into an array of null-terminated strings and passes them to the C runtime library. The Python interpreter captures these arguments and exposes them to the running program as a standard Python list of strings named `sys.argv`, housed inside the built-in `sys` module.

```text
Terminal Command:
  $ python main.py --interactive --verbose 10
             │            │           │      │
             ▼            ▼           ▼      ▼
sys.argv = ['main.py', '--interactive', '--verbose', '10']
Index:         0              1              2        3
```

Key characteristics of `sys.argv`:
1. **Always Present**: `sys.argv` is always a list of strings, even if no arguments were passed.
2. **Index Zero is the Script Name**: `sys.argv[0]` always holds the name or path of the script being executed (e.g., `'main.py'`).
3. **Strings Only**: All elements in `sys.argv` are pure Python `str` instances. Any numbers or booleans passed via the shell must be explicitly parsed or validated.
4. **Order Preservation**: Arguments appear in `sys.argv` in the exact sequence in which they were entered into the shell.

### Dual-Mode Execution Architecture
In `study-buddy-planner`, the project supports two fundamentally distinct operational workflows:

```mermaid
flowchart TD
    Start([Execute python main.py]) --> CheckFlag{"'--interactive' in sys.argv?"}
    CheckFlag -- Yes --> InteractiveMode["Interactive Mode\nPrompt student for 4 situational metrics\nRun real-time inference\nDisplay personalized recommendation"]
    CheckFlag -- No --> ScriptedMode["Scripted Mode (Default)\nEvaluate model on test set\nDisplay 4 hardcoded demo plans\nRender PNG visualizations\nExport rules.txt"]
    InteractiveMode --> Terminate([Exit 0])
    ScriptedMode --> Terminate
```

1. **Scripted Default Mode (`python main.py`)**:
   - Executes deterministically without pausing for user keystrokes.
   - Trains the model, computes test accuracy, prints the classification report, renders `study_tree.png` and `confusion_matrix.png`, and writes `rules.txt`.
   - Perfect for automated regression testing, CI/CD runners (like GitHub Actions), and quick code verification.

2. **Interactive Personalization Mode (`python main.py --interactive`)**:
   - Triggers terminal-based conversational questions asking the user for their exact current study conditions.
   - Predicts an immediate personalized study strategy.
   - Ideal for end students seeking actionable guidance.

If an ML script were hardcoded to prompt the user via `input()` on every run, running `pytest` or running an automated build script would hang indefinitely waiting for keyboard input that will never arrive, eventually causing the build to time out and fail. By using flag-based routing, the script defaults to non-interactive execution while preserving human interactivity on demand.

---

## Relevant Code (from main.py, lines 13, 127-135)

```python
import sys

# ... inside main() function ...

    if "--interactive" in sys.argv:
        print("\nAnswer four questions and the planner will suggest a strategy.\n")
        situation = ask_situation()
        plan = model.predict(situation)[0]
        print(f"\nSuggested strategy: {plan}")
    else:
        print("Run `python main.py --interactive` to get a personal plan.")
        print("Try this: add a 'deadline soon' feature and retrain.")
```

---

## Code Explanation

### 1. `import sys` (Line 13)
The `sys` module provides access to system-specific parameters and functions that interact directly with the Python interpreter runtime. It is part of the standard library, requiring no external packages or `pip install` commands.

### 2. Flag Membership Testing (`"--interactive" in sys.argv`) (Line 127)
Instead of relying on fragile positional indexing (e.g., checking `if len(sys.argv) > 1 and sys.argv[1] == "--interactive"`), `main.py` uses Python's `in` membership operator. This checks whether the string `"--interactive"` is present anywhere in the argument list. This allows the user to invoke the script with additional flags or variations without breaking the interactive trigger.

### 3. Interactive Branch (`lines 128-131`)
When the flag is detected:
- A welcoming banner is printed to standard output (`stdout`).
- `ask_situation()` is invoked to prompt the user and assemble a single-row DataFrame.
- `model.predict(situation)[0]` evaluates the trained decision tree against the input row.
- The predicted label is printed directly to the terminal.

### 4. Non-Interactive Guidance Branch (`lines 132-135`)
When the flag is absent:
- The script informs the user how to activate interactive mode (`Run 'python main.py --interactive' to get a personal plan`).
- It presents an educational challenge (`Try this: add a 'deadline soon' feature and retrain.`), encouraging student experimentation without blocking the execution pipeline.

---

## Worked Example

Let us examine how `sys.argv` changes across different shell invocations:

### Scenario A: Automated Pipeline Run
```bash
$ python main.py
```
- In the interpreter, `sys.argv` is `['main.py']`.
- `'--interactive' in sys.argv` evaluates to `False`.
- Output: The model trains, prints metrics, exports images and `rules.txt`, displays the demo plans, and terminates cleanly with exit code `0`.

### Scenario B: Human Terminal Run
```bash
$ python main.py --interactive
```
- In the interpreter, `sys.argv` is `['main.py', '--interactive']`.
- `'--interactive' in sys.argv` evaluates to `True`.
- Output: Following the training summary, execution enters `ask_situation()`, prompts the student for 4 numbers, and prints their custom plan.

### Scenario C: Mixed Flags
```bash
$ python main.py --seed 42 --interactive
```
- In the interpreter, `sys.argv` is `['main.py', '--seed', '42', '--interactive']`.
- Because `"--interactive" in sys.argv` performs a set membership scan, it still evaluates to `True`!

---

## Step-by-Step Student Instructions

1. **Verify Default Scripted Execution**:
   Open your terminal in the project directory and execute:
   ```bash
   python main.py
   ```
   Notice that the program executes from start to finish without pausing or waiting for keyboard input.

2. **Trigger Interactive Mode**:
   Execute the script with the `--interactive` flag:
   ```bash
   python main.py --interactive
   ```
   Observe how execution pauses after displaying the demo plans, presenting the first interactive prompt:
   ```text
   Answer four questions and the planner will suggest a strategy.

   How many hours do you have left? (1-10) 
   ```

3. **Inspect `sys.argv` in a Scratch Script**:
   Create a small script named `test_cli.py` to see `sys.argv` directly:
   ```python
   import sys

   print(f"Type of sys.argv: {type(sys.argv)}")
   print(f"Total arguments: {len(sys.argv)}")
   print(f"Raw contents: {sys.argv}")

   if "--interactive" in sys.argv:
       print("Interactive mode requested!")
   ```
   Run it with various parameters:
   ```bash
   python test_cli.py
   python test_cli.py --interactive
   python test_cli.py --mode fast --interactive
   ```

---

## Expected Output or Observable Behaviour

When executing with `--interactive`:
```text
============================================================
THE STUDY BUDDY PLANNER
============================================================
Accuracy: 100.0%

                   precision    recall  f1-score   support

 Deep focus block       1.00      1.00      1.00         8
Practice problems       1.00      1.00      1.00         3
     Quick review       1.00      1.00      1.00         5
Take a break first       1.00      1.00      1.00        14

         accuracy                           1.00        30
        macro avg       1.00      1.00      1.00        30
     weighted avg       1.00      1.00      1.00        30

Learned rules:
|--- hours_left <= 2.50
|   |--- class: Quick review
|--- hours_left >  2.50
|   |--- energy <= 2.50
|   |   |--- class: Take a break first
|   |--- energy >  2.50
|   |   |--- distraction <= 3.50
|   |   |   |--- difficulty <= 3.50
|   |   |   |   |--- class: Deep focus block
|   |   |   |--- difficulty >  3.50
|   |   |   |   |--- class: Practice problems
|   |   |--- distraction >  3.50
|   |   |   |--- class: Take a break first

Demo plans:
  {'hours_left': 2, 'difficulty': 4, 'energy': 3, 'distraction': 2} -> Quick review
  {'hours_left': 6, 'difficulty': 5, 'energy': 4, 'distraction': 1} -> Practice problems
  {'hours_left': 4, 'difficulty': 3, 'energy': 1, 'distraction': 2} -> Take a break first
  {'hours_left': 8, 'difficulty': 2, 'energy': 4, 'distraction': 5} -> Take a break first

Saved: outputs/study_tree.png, outputs/confusion_matrix.png, outputs/rules.txt

Answer four questions and the planner will suggest a strategy.

How many hours do you have left? (1-10) 
```

---

## Practical Exercises

### Exercise 1: Custom Help Flag
Add support for a `--help` or `-h` flag to `main.py` that prints a detailed usage manual and exits immediately with code `0` using `sys.exit(0)` before any training occurs.

### Exercise 2: Silent Evaluation Mode
Implement a `--quiet` or `-q` flag that suppresses all terminal output (`print` statements) except the final accuracy score and saved file confirmations.

### Exercise 3: Passing Direct Feature Arguments
Extend CLI handling so that instead of prompting interactively, a user can pass features directly on the command line, for example:
```bash
python main.py --predict 3 2 4 1
```
Parse the positional arguments into integers, create the single-row DataFrame, and output the recommendation directly.

---

## Common Mistakes and Debugging

### Mistake 1: Relying on Positional Indexing (`sys.argv[1]`)
```python
# Fragile anti-pattern:
if sys.argv[1] == "--interactive":  # Crashes with IndexError if run with no arguments!
    ...
```
**Fix**: If no arguments are passed, `len(sys.argv)` is 1, so accessing `sys.argv[1]` raises an `IndexError`. Using `'--interactive' in sys.argv` is safe because list membership does not throw an index exception on empty or single-element lists.

### Mistake 2: Assuming CLI Arguments are Integers
```python
# Buggy assumption:
hours = sys.argv[2]
if hours > 5:  # TypeError: '>' not supported between instances of 'str' and 'int'
    ...
```
**Fix**: Command-line arguments in `sys.argv` are always strings. You must explicitly cast them using `int(sys.argv[2])` or `float(sys.argv[2])` inside a `try...except ValueError` block.

### Mistake 3: Blocking Input in Automated Scripts
Placing `input()` calls in the unconditional root path of a script. When deployed in automated test suites or Docker containers without a TTY terminal, the process hangs or crashes with `EOFError: EOF when reading a line`.

---

## Best Practices
1. **Default to Non-Interactive**: Unless building a dedicated terminal text game, always make the non-interactive path the default behavior for machine learning training and evaluation scripts.
2. **Use Membership Checks for Simple Flags**: For lightweight scripts with one or two binary flags, `"--flag" in sys.argv` is clean, transparent, and requires no external imports.
3. **Graduate to `argparse` for Complex CLIs**: When your script requires typed options, mutual exclusion, default values, subcommands, and auto-generated `--help` documentation, migrate from raw `sys.argv` to Python's standard `argparse` library.
4. **Explicit Exit Codes**: Return explicit OS status codes (`sys.exit(0)` for success, `sys.exit(1)` for errors) so calling shell scripts or CI pipelines can catch failures.

---

## Security Considerations
- **Command Injection Resistance**: Parsing flags via `sys.argv` is inherently safe from shell injection because arguments have already been split by the OS shell before reaching Python.
- **Untrusted Arguments**: Never pass raw strings from `sys.argv` directly into SQL queries, operating system execution functions like `os.system()` or `subprocess.Popen(..., shell=True)`.
- **Denial of Service via Huge Inputs**: Validate length and range before allocating memory or processing heavy loops based on CLI parameters.

---

## Summary
- `sys.argv` is a standard Python list of strings containing all command-line arguments passed to the script, starting with the script name at index 0.
- Checking `"--interactive" in sys.argv` enables dual-mode execution: scripted batch evaluation by default, and conversational interactive prompts when requested.
- Dual-mode architecture ensures machine learning pipelines remain fully testable and CI/CD compatible while offering friendly human interactivity.

---

## Knowledge-check Questions
1. What does `sys.argv[0]` represent in a Python script invoked as `python main.py --interactive`?
2. Why is `"--interactive" in sys.argv` safer than `sys.argv[1] == "--interactive"`?
3. What data type are the elements contained in `sys.argv`?
4. What happens when an automated CI/CD pipeline runs a Python script that halts on an unconditional `input()` prompt?

---

## References
- [Python Standard Library: sys — System-specific parameters and functions](https://docs.python.org/3/library/sys.html)
- [Python CLI Programming Guide (argparse vs sys.argv)](https://docs.python.org/3/howto/argparse.html)
- [12-Factor App: Configuration and Process Execution](https://12factor.net/)