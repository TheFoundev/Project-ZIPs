# Lesson 03: Defensive Input Validation & Error Handling

- **Lesson ID**: `module-05-lesson-03`
- **Module**: `module-05` (Interactive Mode & Input Validation)
- **Duration**: 30 minutes

## Purpose and Learning Objectives
Real-world human users make mistakes. When prompted for numerical data in a terminal, users may type words (`"five"`), enter floating-point decimals (`"3.5"`), hit the spacebar accidentally (`"  4  "`), press enter without typing anything (`""`), or supply numbers far outside sensible physical boundaries (`"-10"`, `"999999"`). Without defensive input validation, unhandled exceptions will instantly crash the program.

By the end of this lesson, you will be able to:
1. Implement robust interactive validation loops using `while True`, `break`, and `continue`.
2. Sanitize raw terminal string input using Python's `.strip()` method.
3. Handle type conversion errors gracefully using structured `try...except ValueError` blocks.
4. Enforce relational boundary constraints (`low <= value <= high`) with distinct, user-friendly error messages.

---

## Prerequisites
Before starting this lesson, you should be familiar with:
- Standard input capture with Python's built-in `input()` function.
- Python exception handling constructs (`try`, `except`).
- Chained relational comparisons in Python (`a <= b <= c`).
- Module 05 Lesson 02 on the declarative `QUESTIONS` configuration.

---

## Concept Explanation

### The Principle of Defensive Programming
Defensive programming is an engineering philosophy where software systems are designed to operate reliably under unforeseen or hostile conditions. In user-facing CLI applications, input validation is the primary defensive barrier. 

```mermaid
flowchart TD
    PromptUser["Display Prompt: question"] --> ReadInput["raw = input().strip()"]
    ReadInput --> TryConvert{"try: int(raw)"}
    TryConvert -- "ValueError (e.g. 'abc', '3.5', '')" --> ShowTypeError["Print: 'Please enter a whole number from low to high.'"]
    ShowTypeError --> PromptUser
    TryConvert -- "Success (integer)" --> CheckBounds{"low <= value <= high?"}
    CheckBounds -- "No (e.g. 0, 15)" --> ShowRangeError["Print: 'Please enter a number from low to high.'"]
    ShowRangeError --> PromptUser
    CheckBounds -- "Yes" --> StoreValue["values[key] = value\nbreak loop"]
    StoreValue --> NextQuestion{"More questions?"}
```

The validation pipeline enforces two sequential verification filters:
1. **Type Validity (Syntactic Validation)**: Is the input an integer?
   - If the user types `"hello"`, `"five"`, or `"3.2"`, `int()` raises a `ValueError`. The script catches this exception, informs the user that a whole number is required, and repeats the prompt.
2. **Range Validity (Semantic Validation)**: Does the integer fall within acceptable physical boundaries?
   - If the user types `-5` or `99`, `int()` succeeds, but the value violates domain constraints. The script checks `low <= value <= high`. If false, it informs the user and re-prompts.

Only when both filters pass does the script invoke `break`, terminating the inner loop and moving to the next question.

---

## Relevant Code (from main.py, lines 39-54)

```python
def ask_situation() -> pd.DataFrame:
    values = {}
    for question, key, low, high in QUESTIONS:
        while True:
            raw = input(question).strip()
            try:
                value = int(raw)
            except ValueError:
                print(f"Please enter a whole number from {low} to {high}.")
                continue
            if low <= value <= high:
                values[key] = value
                break
            print(f"Please enter a number from {low} to {high}.")
    return pd.DataFrame([values])
```

---

## Code Explanation

### 1. Dictionary Initialization (`values = {}`) (Line 40)
An empty dictionary `values` is created to collect each verified feature. The keys will be the strings defined in `QUESTIONS` (`"hours_left"`, `"difficulty"`, `"energy"`, `"distraction"`), and the values will be clean, validated integers.

### 2. Outer Iteration (`for question, key, low, high in QUESTIONS:`) (Line 41)
The function loops through the declarative schema, unpacking the prompt string, feature key, minimum bound, and maximum bound for each situational dimension.

### 3. The Infinite Re-Prompt Loop (`while True:`) (Line 42)
An infinite loop ensures that the program will not advance until the user provides valid data for the current question. The loop will only terminate when the `break` statement on line 51 is reached.

### 4. Input Sanitization (`raw = input(question).strip()`) (Line 43)
- `input(question)` displays the prompt and halts execution until the user presses Enter.
- `.strip()` immediately strips any leading or trailing whitespace, tabs (`\t`), or newline characters (`\n`). If a user accidentally types `" 4 "` or presses Space before entering their number, `.strip()` cleans the string to `"4"`, preventing avoidable conversion errors.

### 5. Type Casting with `try...except ValueError` (Lines 44-48)
```python
try:
    value = int(raw)
except ValueError:
    print(f"Please enter a whole number from {low} to {high}.")
    continue
```
`int(raw)` attempts to parse the string into a Python integer. 
- If `raw` contains alphabetic letters, punctuation, empty strings, or decimals (`"3.5"`), Python raises a `ValueError`.
- The `except ValueError` clause catches this exception.
- It displays a helpful error message specifying that a **whole number** is required.
- The `continue` statement immediately jumps back to the top of the `while True` loop, prompting the user again.

### 6. Relational Range Validation (Lines 49-52)
```python
if low <= value <= high:
    values[key] = value
    break
print(f"Please enter a number from {low} to {high}.")
```
Python supports **chained relational comparisons**. `low <= value <= high` is syntactically equivalent to `(low <= value) and (value <= high)` in other languages like C++ or Java, but is more readable and concise.
- If the integer is within the inclusive bounds:
  - `values[key] = value` stores the clean integer in the dictionary under the corresponding feature name.
  - `break` exits the `while True` loop, allowing the outer `for` loop to proceed to the next feature.
- If the integer is outside bounds (e.g., entering `15` when the maximum is `10`):
  - Execution skips the `if` block.
  - Line 52 prints a message reminding the user of the acceptable interval.
  - Execution naturally loops back to `while True`.

---

## Worked Example

Let us trace user interaction during a run where a student makes multiple input mistakes:

### Interaction Transcript:
```text
How many hours do you have left? (1-10) five
Please enter a whole number from 1 to 10.
How many hours do you have left? (1-10) 3.5
Please enter a whole number from 1 to 10.
How many hours do you have left? (1-10) 15
Please enter a number from 1 to 10.
How many hours do you have left? (1-10) 0
Please enter a number from 1 to 10.
How many hours do you have left? (1-10)   4  
How difficult is the subject? (1-5) 
```

### Execution Trace:
1. User enters `"five"`:
   - `raw = "five"`
   - `int("five")` raises `ValueError`.
   - Caught by `except ValueError`. Prints `"Please enter a whole number from 1 to 10."`.
   - `continue` re-prompts.
2. User enters `"3.5"`:
   - `raw = "3.5"`
   - `int("3.5")` raises `ValueError` (Python does not implicitly truncate float strings to int).
   - Caught by `except ValueError`. Re-prompts.
3. User enters `"15"`:
   - `raw = "15"`
   - `value = int("15")` $\to 15$.
   - `1 <= 15 <= 10` is `False`.
   - Prints `"Please enter a number from 1 to 10."`. Re-prompts.
4. User enters `"0"`:
   - `raw = "0"`
   - `value = int("0")` $\to 0$.
   - `1 <= 0 <= 10` is `False`.
   - Prints `"Please enter a number from 1 to 10."`. Re-prompts.
5. User enters `"  4  "`:
   - `raw = "  4  ".strip()` $\to "4"$.
   - `value = int("4")` $\to 4$.
   - `1 <= 4 <= 10` is `True`.
   - `values["hours_left"] = 4`.
   - `break` exits loop.
   - Moves to Question 2 (`"difficulty"`).

---

## Step-by-Step Student Instructions

1. **Test the Validation Loop Manually**:
   Run `main.py` in interactive mode:
   ```bash
   python main.py --interactive
   ```
2. **Attempt Boundary Violations**:
   - At the first prompt (`hours_left`), enter `-1`. Verify that you see:
     `Please enter a number from 1 to 10.`
   - Enter `11`. Verify that you see:
     `Please enter a number from 1 to 10.`
3. **Attempt Type Violations**:
   - Enter `two`. Verify that you see:
     `Please enter a whole number from 1 to 10.`
   - Press Enter without typing anything. Verify that you see:
     `Please enter a whole number from 1 to 10.`
4. **Enter a Valid Value with Leading and Trailing Whitespace**:
   - Enter `   6   `. Verify that the script cleanly accepts `6` and moves immediately to the next question.
5. Complete all four questions and observe the final recommendation.

---

## Expected Output or Observable Behaviour

```text
Answer four questions and the planner will suggest a strategy.

How many hours do you have left? (1-10) -5
Please enter a number from 1 to 10.
How many hours do you have left? (1-10) abc
Please enter a whole number from 1 to 10.
How many hours do you have left? (1-10) 3
How difficult is the subject? (1-5) 5
How much energy do you have? (1-5) 4
How distracted do you feel? (1-5) 1

Suggested strategy: Practice problems
```

---

## Practical Exercises

### Exercise 1: Support for Floating-Point Numbers
Modify the validation loop to accept floating-point numbers for `hours_left` (e.g., `2.5` hours) while retaining integer restrictions for `difficulty`, `energy`, and `distraction`. (Hint: add a type parameter or callable parser to each tuple in `QUESTIONS`).

### Exercise 2: Maximum Attempt Counter
Extend `ask_situation()` so that if a user fails validation 5 consecutive times on any question, the program aborts with a graceful message: `"Too many invalid attempts. Exiting."` and calls `sys.exit(1)`.

### Exercise 3: Default Value on Empty Input
Update the loop so that if the user presses Enter on an empty line, a default value (e.g., the midpoint of `low` and `high`) is automatically selected and confirmed to the user.

---

## Common Mistakes and Debugging

### Mistake 1: Forgetting `.strip()`
```python
raw = input(question)  # If user enters "4 \n", int() might work, but regex/parsers fail
```
Leaving whitespace untreated can cause downstream parsing errors or confuse logging mechanisms. Always sanitize with `.strip()`.

### Mistake 2: Using Bare `except:`
```python
# Dangerous anti-pattern:
try:
    value = int(raw)
except:  # Catches KeyboardInterrupt (Ctrl+C), SystemExit, and MemoryError!
    print("Invalid number!")
```
**Consequence**: If the user presses `Ctrl+C` to terminate the program, a bare `except:` intercepts the interrupt signal and prints `"Invalid number!"` instead of exiting!
**Fix**: Always catch the specific exception expected: `except ValueError:`.

### Mistake 3: Omitting `continue` or `break`
If you forget `break` inside the `if low <= value <= high:` block, the loop will never terminate even after a valid entry. If you forget `continue` in the `except ValueError:` block, execution may fall through to the range check and cause a `UnboundLocalError` if `value` was never assigned.

---

## Best Practices
1. **Differentiate Error Messages**: Distinguish between syntax errors (non-numeric input) and semantic errors (out-of-range numbers). This provides clear feedback so users know how to correct their input.
2. **Never Mask System Exceptions**: Never use bare `except:`. Always catch `ValueError`.
3. **Keep Prompt Logic Isolated**: Encapsulate interactive input gathering into dedicated functions (like `ask_situation()`) so the core machine learning logic remains independent of the user interface.
4. **Sanitize String Boundaries**: Always apply `.strip()` immediately upon capturing terminal strings.

---

## Security Considerations
- **Denial of Service (Infinite Hangs)**: In automated environments, if standard input is closed (`EOF`), `input()` raises `EOFError`. If unhandled, this crashes the script. In web APIs, input validation prevents algorithmic denial of service by rejecting massive payload sizes before parsing.
- **Buffer Overflow Protection**: Python handles memory allocation dynamically for integers, preventing traditional C buffer overflows. However, extremely long strings passed to `int()` can consume CPU cycles parsing massive exponents.

---

## Summary
- Defensive programming safeguards CLI applications against unexpected, malformed, or hostile user input.
- A `while True` loop combined with `try...except ValueError` and relational bounds checking guarantees that only valid data reaches downstream machine learning models.
- Sanitizing with `.strip()` prevents user frustration from accidental whitespace.
- Differentiating between type errors and range errors delivers superior user experience and clear debugging feedback.

---

## Knowledge-check Questions
1. Why is `except ValueError:` preferable to a bare `except:` clause?
2. What happens if a user inputs `"3.5"` when `int(raw)` is executed?
3. How does `.strip()` improve user experience in terminal input collection?
4. What prevents the `while True` loop in `ask_situation()` from looping forever once a valid input is provided?

---

## References
- [Python Built-in Exceptions: ValueError](https://docs.python.org/3/library/exceptions.html#ValueError)
- [Python String Methods: str.strip](https://docs.python.org/3/library/stdtypes.html#str.strip)
- [Defensive Programming Principles (SEI CERT)](https://wiki.sei.cmu.edu/confluence/display/seccode/Top+10+Secure+Coding+Practices)