# Lesson 04: Single-Sample Inference & DataFrame Formatting

- **Lesson ID**: `module-05-lesson-04`
- **Module**: `module-05` (Interactive Mode & Input Validation)
- **Duration**: 30 minutes

## Purpose and Learning Objectives
In machine learning pipelines, models are trained on large two-dimensional tabular matrices containing thousands of historical rows. However, when deployed into real-world production systems—whether behind a REST API endpoint, a microservice, or an interactive command-line tool—inference is frequently requested for a **single sample at a time**. Bridging the gap between a single dictionary of user inputs and scikit-learn's strict multi-dimensional matrix expectations is a foundational engineering skill.

By the end of this lesson, you will be able to:
1. Explain why scikit-learn estimators strictly require two-dimensional tabular input structures for inference.
2. Construct single-row pandas DataFrames from dictionaries using `pd.DataFrame([values])`.
3. Validate feature column alignment to prevent schema mismatch errors during prediction.
4. Extract single scalar class labels from NumPy prediction arrays using index notation (`[0]`).

---

## Prerequisites
Before starting this lesson, you should be familiar with:
- Constructing pandas DataFrames from Python dictionaries and lists.
- Understanding 1D vs 2D arrays in NumPy and scikit-learn.
- Array indexing in Python.
- Module 05 Lessons 01, 02, and 03.

---

## Concept Explanation

### The Dimensionality Requirement of Scikit-Learn
Scikit-learn models are built on top of NumPy and C-level linear algebra routines optimized for batch processing. All estimators adhere to a universal API convention:
- **Input Feature Matrix ($X$)**: Must always be a **2D structure** with shape `(n_samples, n_features)`.
- When predicting on a single student's responses, $n_{samples} = 1$ and $n_{features} = 4$.
- Therefore, the input matrix shape must be `(1, 4)`.

```text
Flat Dictionary:
  {'hours_left': 4, 'difficulty': 3, 'energy': 1, 'distraction': 2}
                         │
                         ▼  pd.DataFrame([values])
2D Tabular DataFrame: (shape: 1 x 4)
  ┌────────────┬────────────┬────────┬─────────────┐
  │ hours_left │ difficulty │ energy │ distraction │
  ├────────────┼────────────┼────────┼─────────────┤
  │     4      │     3      │   1    │      2      │
  └────────────┴────────────┴────────┴─────────────┘
                         │
                         ▼  model.predict(...)
NumPy Array: (shape: 1,)
  array(['Take a break first'], dtype=object)
                         │
                         ▼  [0]
Scalar Prediction String:
  "Take a break first"
```

If you attempt to pass a raw 1D list `[4, 3, 1, 2]` or a flat dictionary `{'hours_left': 4, ...}` directly into `model.predict()`, scikit-learn will raise an immediate error:
`ValueError: Expected 2D array, got 1D array instead` or `ValueError: Expected 2D array, got dict instead`.

### Converting a Dictionary to a 1-Row DataFrame
In Python, wrapping a single dictionary inside a list bracket `[values]` creates a list with one dictionary element:
`[{"hours_left": 4, "difficulty": 3, "energy": 1, "distraction": 2}]`.
Passing this list to `pd.DataFrame()` tells pandas:
1. Each dictionary in the list represents one row of data ($n_{samples} = 1$).
2. The dictionary keys become the column headers (`df.columns`).
3. The dictionary values populate row 0.

### Scalar Extraction via Index Zero
Because `model.predict()` handles arbitrary batch sizes, it always returns a 1D NumPy `ndarray` of predictions, even when given only one input sample.
For a single row, the return value is:
```python
array(['Take a break first'], dtype=object)
```
To obtain the raw Python string to display cleanly to the user without NumPy array brackets or quotes, we unpack index `0`:
```python
plan = model.predict(situation)[0]  # "Take a break first"
```

---

## Relevant Code (from main.py, lines 53, 129-131)

```python
# Inside ask_situation():
def ask_situation() -> pd.DataFrame:
    values = {}
    # ... prompt loop ...
    return pd.DataFrame([values])

# Inside main():
    if "--interactive" in sys.argv:
        print("\nAnswer four questions and the planner will suggest a strategy.\n")
        situation = ask_situation()
        plan = model.predict(situation)[0]
        print(f"\nSuggested strategy: {plan}")
```

---

## Code Explanation

### 1. `return pd.DataFrame([values])` (Line 53)
Notice the brackets surrounding `values`. 
- If you call `pd.DataFrame(values)`, pandas expects dictionary values to be lists or arrays, raising `ValueError: If using all scalar values, you must pass an index`.
- By wrapping `values` in a list (`[values]`), pandas immediately constructs a DataFrame with an index of `[0]` and columns matching the keys of the dictionary.

Let us inspect the DataFrame created:
```python
>>> situation = ask_situation()
>>> print(situation)
   hours_left  difficulty  energy  distraction
0           4           3       1            2
>>> print(situation.shape)
(1, 4)
```

### 2. Tabular Schema Parity
Because the dictionary keys were derived directly from `QUESTIONS` (`"hours_left"`, `"difficulty"`, `"energy"`, `"distraction"`), the DataFrame columns match the exact column names seen by `model.fit(X_train, y_train)`. Scikit-learn verifies that:
1. All training feature names are present.
2. No extraneous or unexpected feature names are present.
3. The column order matches the training matrix order.

### 3. Model Inference (`plan = model.predict(situation)[0]`) (Line 130)
1. `model.predict(situation)`: Traverses the internal C-level decision tree structure from root node to leaf node using the values in `situation.iloc[0]`.
2. Output: A 1-element NumPy array `np.array(["Take a break first"])`.
3. `[0]`: Extracts the single element from the array, assigning the string `"Take a break first"` to the variable `plan`.

### 4. Output Display (`print(f"\nSuggested strategy: {plan}")`) (Line 131)
The extracted string is formatted into a clean, friendly terminal message for the student.

---

## Worked Example

Let us trace the complete data transformation from user keyboard input to final screen output:

### Step 1: User Types Responses
- Student enters: `hours_left = 6`, `difficulty = 5`, `energy = 4`, `distraction = 1`.

### Step 2: Dictionary Built by `ask_situation()`
```python
values = {
    "hours_left": 6,
    "difficulty": 5,
    "energy": 4,
    "distraction": 1
}
```

### Step 3: DataFrame Constructed
```python
situation = pd.DataFrame([values])
```
Represented as:
| Index | hours_left | difficulty | energy | distraction |
| :---: | :---: | :---: | :---: | :---: |
| **0** | 6 | 5 | 4 | 1 |

### Step 4: Decision Tree Evaluation
The tree executes:
1. `hours_left (6) <= 2.50`? $\to$ False.
2. `energy (4) <= 2.50`? $\to$ False.
3. `distraction (1) <= 3.50`? $\to$ True.
4. `difficulty (5) <= 3.50`? $\to$ False (5 > 3.50).
5. Leaf reached: `"Practice problems"`.

### Step 5: Scalar Extraction
```python
raw_predictions = model.predict(situation)  # array(['Practice problems'], dtype=object)
plan = raw_predictions[0]                  # 'Practice problems'
```

### Step 6: Terminal Output
```text
Suggested strategy: Practice problems
```

---

## Step-by-Step Student Instructions

1. **Test DataFrame Creation in Python**:
   Open a Python REPL:
   ```bash
   python
   ```
2. **Execute the Transformation**:
   ```python
   import pandas as pd
   from sklearn.tree import DecisionTreeClassifier

   # Simulated user values
   sample_dict = {"hours_left": 6, "difficulty": 5, "energy": 4, "distraction": 1}

   # Try without brackets:
   try:
       df_fail = pd.DataFrame(sample_dict)
   except ValueError as e:
       print(f"Failed as expected: {e}")

   # Correct with brackets:
   df_success = pd.DataFrame([sample_dict])
   print("\nSuccessful DataFrame:")
   print(df_success)
   print(f"DataFrame shape: {df_success.shape}")
   ```
3. **Inspect the Result**:
   Verify that `df_success.shape` is `(1, 4)`.
4. Exit the REPL with `quit()`.

---

## Expected Output or Observable Behaviour

```text
Failed as expected: If using all scalar values, you must pass an index

Successful DataFrame:
   hours_left  difficulty  energy  distraction
0           6           5       4            1
DataFrame shape: (1, 4)
```

---

## Practical Exercises

### Exercise 1: Probability Distribution Inspection
Instead of predicting just the discrete class label, modify line 130 to compute class probabilities using `model.predict_proba(situation)[0]`. Print each strategy name alongside its calculated probability percentage (e.g., `Take a break first: 0.0%, Practice problems: 100.0%`).

### Exercise 2: Column Order Independence
Verify whether pandas DataFrames preserve or alter column order when dictionaries are passed with keys in reversed order:
```python
reversed_dict = {"distraction": 1, "energy": 4, "difficulty": 5, "hours_left": 6}
df_rev = pd.DataFrame([reversed_dict])
```
Test whether `model.predict(df_rev)` produces the identical result as `df_success`. (Hint: modern scikit-learn models trained with DataFrame feature names automatically align column names by header!).

### Exercise 3: Formatting Actionable Next Steps
Create a dictionary mapping each of the four strategies to specific actionable tips:
- `Take a break first`: `"Step away from your screen, drink a glass of water, and stretch for 15 minutes."`
- `Deep focus block`: `"Set a 45-minute Pomodoro timer, silence all notifications, and tackle your core concepts."`
- `Practice problems`: `"Open your textbook question bank and solve 5 practice exercises without checking notes."`
- `Quick review`: `"Skim summary sheets, flashcards, or chapter glossaries to consolidate memory."`
Update the output display to print both the strategy and its actionable tip.

---

## Common Mistakes and Debugging

### Mistake 1: Forgetting Brackets Around `values`
```python
df = pd.DataFrame(values)  # ValueError: If using all scalar values, you must pass an index
```
Always use `pd.DataFrame([values])` when creating a single-row DataFrame from a dictionary of scalar numbers.

### Mistake 2: Missing the `[0]` Index on `predict()`
```python
plan = model.predict(situation)
print(f"Strategy: {plan}")  # Strategy: ['Practice problems']
```
Without `[0]`, `plan` is an array object, which prints with brackets and array formatting rather than a clean string.

### Mistake 3: Passing NumPy 2D Array Without Feature Names
If you convert the dictionary to a NumPy array `np.array([[6, 5, 4, 1]])` and pass it to a model fitted on a pandas DataFrame, scikit-learn will issue a `UserWarning: X does not have valid feature names, but DecisionTreeClassifier was fitted with feature names`. Passing a pandas DataFrame with proper column headers eliminates all warnings.

---

## Best Practices
1. **Preserve Tabular Metadata**: Always pass a pandas DataFrame with feature names rather than a raw NumPy array to preserve feature name safety checks.
2. **Enforce Feature Schema**: Before calling `predict()`, verify that `list(situation.columns) == FEATURES`.
3. **Extract Scalars for Clean UI**: Unpack array predictions with `[0]` before formatting strings for user interfaces or API JSON responses.
4. **Leverage Vectorization**: Even though interactive mode collects one sample, keeping the inference pipeline in DataFrame format allows effortless batch expansion.

---

## Security Considerations
- **Data Leakage & Logging**: Ensure that user inputs collected interactively do not contain personally identifiable information (PII) before logging or persisting.
- **Type Coercion Verification**: Ensure all DataFrame values are verified numeric types before inference to prevent downstream matrix calculation exceptions.

---

## Summary
- Scikit-learn estimators require 2D input matrices of shape `(n_samples, n_features)`.
- Wrapping a dictionary in a list (`pd.DataFrame([values])`) creates a 1-row tabular DataFrame conforming to model requirements.
- Passing a DataFrame with matching column headers guarantees feature name validation.
- `model.predict()` returns a 1D array; index `[0]` extracts the clean scalar prediction string.

---

## Knowledge-check Questions
1. Why does `pd.DataFrame(values)` fail when `values` is a dictionary of scalar integers?
2. What is the shape of the DataFrame generated by `pd.DataFrame([values])`?
3. What is the data type and shape of the return value of `model.predict(situation)`?
4. What warning does scikit-learn emit if you pass a raw NumPy array to a model trained on a pandas DataFrame?

---

## References
- [Pandas DataFrame Constructor Documentation](https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.html)
- [Scikit-Learn Common API: Estimator.predict()](https://scikit-learn.org/stable/developers/develop.html)
- [NumPy Array Indexing Guide](https://numpy.org/doc/stable/user/basics.indexing.html)