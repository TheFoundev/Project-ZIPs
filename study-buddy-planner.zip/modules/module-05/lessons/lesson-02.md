# Lesson 02: Structured Configuration with QUESTIONS

- **Lesson ID**: `module-05-lesson-02`
- **Module**: `module-05` (Interactive Mode & Input Validation)
- **Duration**: 30 minutes

## Purpose and Learning Objectives
Hardcoding user prompts, feature keys, and numerical validation boundaries into repetitive lines of procedural code leads to brittle, unmaintainable programs. When prompts are intertwined with control flow, modifying a single feature boundary requires hunting through dozens of nested statements. Professional software engineering utilizes **declarative configuration schemas** to cleanly decouple data definitions from operational logic.

By the end of this lesson, you will be able to:
1. Explain the architectural benefits of declarative schema definitions over imperative prompt loops.
2. Deconstruct the 4-tuple configuration pattern `(prompt, key, low, high)` used in `QUESTIONS`.
3. Align question schema keys with feature lists (`FEATURES`) to guarantee tabular schema parity with scikit-learn models.
4. Extend declarative configurations to support new features and dynamic validation constraints without modifying core application loops.

---

## Prerequisites
Before starting this lesson, you should be familiar with:
- Python collections, specifically tuples and lists of tuples.
- Tuple unpacking in `for` loops (`for a, b, c, d in collection:`).
- Feature matrices and tabular data representations in pandas (`pd.DataFrame`).
- Module 05 Lesson 01 concepts on CLI execution.

---

## Concept Explanation

### Imperative vs Declarative Prompt Design
Consider two ways of prompting a user for four study metrics:

#### The Imperative Anti-Pattern (Brittle and Repetitive):
```python
# Anti-pattern: 40 lines of repetitive, copy-pasted procedural logic
while True:
    try:
        hours = int(input("How many hours do you have left? (1-10) ").strip())
        if 1 <= hours <= 10:
            break
        print("Please enter a number from 1 to 10.")
    except ValueError:
        print("Please enter a whole number from 1 to 10.")

while True:
    try:
        diff = int(input("How difficult is the subject? (1-5) ").strip())
        if 1 <= diff <= 5:
            break
        print("Please enter a number from 1 to 5.")
    except ValueError:
        print("Please enter a whole number from 1 to 5.")

# ... repeated again for energy and distraction ...
```
This anti-pattern violates the fundamental **DRY (Don't Repeat Yourself)** principle. If you want to change how errors are reported or strip formatting, you must edit four separate code blocks. If you add a fifth feature, you must copy-paste an entire block.

#### The Declarative Schema Pattern (Elegant, Scalable):
Instead of repeating the procedural logic, define a **schema data structure** that describes what needs to be asked, what feature key it maps to, and what bounds apply:

```mermaid
classDiagram
    class QuestionTuple {
        +str prompt
        +str feature_key
        +int min_bound
        +int max_bound
    }
    class ValidationLoop {
        +ask_situation()
        +enforce_bounds()
        +cast_integer()
    }
    class MLModel {
        +predict()
    }

    QuestionTuple --> ValidationLoop : "Drives prompt & bounds"
    ValidationLoop --> MLModel : "Produces clean pd.DataFrame"
```

In `main.py`, the entire prompt and validation specification is captured in a clean, declarative constant: `QUESTIONS`.

### Anatomy of the 4-Tuple Schema
Each entry in `QUESTIONS` contains four distinct elements:
1. **`prompt` (`str`)**: The human-readable string displayed in the terminal, including friendly guidance on the expected integer range: `"How many hours do you have left? (1-10) "`.
2. **`key` (`str`)**: The exact programmatic feature name that matches the column name in `study_situations.csv` and `FEATURES`: `"hours_left"`.
3. **`low` (`int`)**: The inclusive minimum acceptable integer bound: `1`.
4. **`high` (`int`)**: The inclusive maximum acceptable integer bound: `10` (or `5` for Likert scale metrics).

---

## Relevant Code (from main.py, lines 30-36)

```python
FEATURES = ["hours_left", "difficulty", "energy", "distraction"]
QUESTIONS = [
    ("How many hours do you have left? (1-10) ", "hours_left", 1, 10),
    ("How difficult is the subject? (1-5) ", "difficulty", 1, 5),
    ("How much energy do you have? (1-5) ", "energy", 1, 5),
    ("How distracted do you feel? (1-5) ", "distraction", 1, 5),
]
```

---

## Code Explanation

### 1. `FEATURES` List (Line 30)
```python
FEATURES = ["hours_left", "difficulty", "energy", "distraction"]
```
This module-level constant acts as the authoritative contract for the machine learning pipeline. It dictates which columns are extracted from the raw training CSV (`df[FEATURES]`), which feature names are passed to scikit-learn's `export_text` and `plot_tree`, and what columns must exist in any new DataFrame supplied to `model.predict()`.

### 2. `QUESTIONS` Configuration List (Lines 31-36)
`QUESTIONS` is an immutable list of tuples defined at the top of the file. By elevating this configuration to module-level scope alongside `FEATURES`, any developer reviewing the script can instantly see the entire questionnaire structure without reading procedural functions.

Notice the exact correspondence between the second element (`key`) of each tuple and `FEATURES`:
- Index 0: `"hours_left"` $\leftrightarrow$ `FEATURES[0]`
- Index 1: `"difficulty"` $\leftrightarrow$ `FEATURES[1]`
- Index 2: `"energy"` $\leftrightarrow$ `FEATURES[2]`
- Index 3: `"distraction"` $\leftrightarrow$ `FEATURES[3]`

Because the schema explicitly embeds the feature keys, the input collection loop (`ask_situation()`) can assemble dictionary keys dynamically without knowing the feature names in advance!

---

## Worked Example

Suppose an educator wants to adapt `main.py` for a high school math competition, adding a new feature: `calculator_allowed` (a boolean encoded as `0` for No, `1` for Yes).

### Step 1: Update `FEATURES`
```python
FEATURES = ["hours_left", "difficulty", "energy", "distraction", "calculator_allowed"]
```

### Step 2: Append to `QUESTIONS`
```python
QUESTIONS = [
    ("How many hours do you have left? (1-10) ", "hours_left", 1, 10),
    ("How difficult is the subject? (1-5) ", "difficulty", 1, 5),
    ("How much energy do you have? (1-5) ", "energy", 1, 5),
    ("How distracted do you feel? (1-5) ", "distraction", 1, 5),
    ("Is a calculator permitted? (0 = No, 1 = Yes) ", "calculator_allowed", 0, 1),
]
```

### Result:
Zero changes are required inside `ask_situation()`! The loop automatically:
1. Iterates through all 5 items.
2. Prompts the student with the calculator question.
3. Enforces that only `0` or `1` are accepted.
4. Stores the result under the key `'calculator_allowed'`.
5. Assembles a 5-column DataFrame that directly feeds the updated decision tree.

This demonstrates the extraordinary power of declarative programming.

---

## Step-by-Step Student Instructions

1. **Inspect Tuple Structure Interactively**:
   Open a Python REPL or launch an interactive shell in your project directory:
   ```bash
   python
   ```
2. **Experiment with Unpacking**:
   Type the following commands into the Python REPL:
   ```python
   QUESTIONS = [
       ("How many hours do you have left? (1-10) ", "hours_left", 1, 10),
       ("How difficult is the subject? (1-5) ", "difficulty", 1, 5),
       ("How much energy do you have? (1-5) ", "energy", 1, 5),
       ("How distracted do you feel? (1-5) ", "distraction", 1, 5),
   ]

   for prompt, key, low, high in QUESTIONS:
       print(f"Key: {key:<12} | Range: [{low}, {high}] | Prompt: {prompt.strip()}")
   ```
3. **Verify Alignment with `FEATURES`**:
   Write an automated sanity check assertion:
   ```python
   question_keys = [q[1] for q in QUESTIONS]
   FEATURES = ["hours_left", "difficulty", "energy", "distraction"]
   assert question_keys == FEATURES, "Mismatch between QUESTIONS keys and FEATURES!"
   print("Schema alignment validated successfully!")
   ```
4. Exit the REPL with `quit()`.

---

## Expected Output or Observable Behaviour

When running the unpacking inspection in Python:
```text
Key: hours_left   | Range: [1, 10] | Prompt: How many hours do you have left? (1-10)
Key: difficulty   | Range: [1, 5]  | Prompt: How difficult is the subject? (1-5)
Key: energy       | Range: [1, 5]  | Prompt: How much energy do you have? (1-5)
Key: distraction  | Range: [1, 5]  | Prompt: How distracted do you feel? (1-5)
Schema alignment validated successfully!
```

---

## Practical Exercises

### Exercise 1: Schema Validation Utility
Write a function `validate_schema(features: list[str], questions: list[tuple]) -> bool` that verifies:
- The number of features equals the number of questions.
- Every feature key in `questions` exists in `features` in the identical order.
- Every `low` bound is strictly less than `high`.
- It returns `True` if valid, or raises an informative `ValueError` describing any discrepancies.

### Exercise 2: Converting Tuples to Dataclasses or NamedTuples
Refactor `QUESTIONS` using Python's `typing.NamedTuple` or `dataclasses.dataclass` to provide typed attribute access (e.g., `q.prompt`, `q.key`, `q.low`, `q.high`) instead of index-based tuple access.

### Exercise 3: Adding Unit Conversion or Formatting
Add a 5th element to each tuple representing an optional unit string (e.g., `"hours"`, `"rating"`, `"rating"`, `"rating"`) and modify the prompt to display the unit after the user enters their answer.

---

## Common Mistakes and Debugging

### Mistake 1: Misspelling the Feature Key
```python
# Subtle spelling mismatch:
("How difficult is the subject? (1-5) ", "diff", 1, 5),  # Model expects "difficulty"!
```
**Consequence**: When `model.predict()` is called, scikit-learn raises a `ValueError: The feature names should match those that were passed during fit. Feature names unseen at fit time: ['diff']`.
**Fix**: Always match the string key exactly to the column headers in the training DataFrame.

### Mistake 2: Reversed Bound Order
```python
("How much energy do you have? (1-5) ", "energy", 5, 1),  # low is 5, high is 1!
```
**Consequence**: The relational check `5 <= value <= 1` will evaluate to `False` for every possible real number, creating an inescapable infinite loop!
**Fix**: Always enforce `low <= high`.

### Mistake 3: Inconsistent Tuple Lengths
If one tuple has 4 elements and another has 3 elements, unpacking with `for prompt, key, low, high in QUESTIONS:` crashes with `ValueError: not enough values to unpack (expected 4, got 3)`.

---

## Best Practices
1. **Single Source of Truth**: Keep schema definitions grouped together near the top of the file or in a dedicated `config.py` module.
2. **Use Clear Schema Tuples or NamedTuples**: Document the meaning of each tuple slot, or use `NamedTuple` to give every field a semantic attribute name.
3. **Automate Consistency Checks**: Include an assertion at script startup (`assert [q[1] for q in QUESTIONS] == FEATURES`) to catch inadvertent drift during development.
4. **Inclusive Range Prompts**: Clearly state the acceptable bounds directly inside the prompt text so users know what to enter without guessing.

---

## Security Considerations
- **No Executable Code in Configuration**: Keep schemas purely declarative (strings and integers). Never store code strings meant to be evaluated with `eval()` or `exec()`.
- **DoS Prevention via Bound Limits**: The explicit `low` and `high` bounds protect downstream algorithms from extreme numbers (e.g., integer overflows or floating-point anomalies) that could destabilize numerical computations.

---

## Summary
- Declarative configuration cleanly isolates input parameters and UI prompts from operational execution code.
- `QUESTIONS` uses a 4-tuple pattern `(prompt, key, low, high)` to define prompts, feature mappings, and acceptable numerical bounds.
- Aligning `QUESTIONS` keys with `FEATURES` ensures seamless integration with scikit-learn models and pandas DataFrames.
- New features can be integrated simply by adding entries to `FEATURES` and `QUESTIONS`, leaving input gathering functions untouched.

---

## Knowledge-check Questions
1. What are the four elements comprising each tuple in `QUESTIONS`?
2. What error does scikit-learn raise if the key in `QUESTIONS` does not match the column name in `FEATURES`?
3. Why is declarative configuration preferred over writing four individual `while True` loops?
4. What happens during validation if a developer accidentally sets `low = 5` and `high = 1`?

---

## References
- [Python Data Structures: Tuples and Sequences](https://docs.python.org/3/tutorial/datastructures.html#tuples-and-sequences)
- [Clean Code: Separation of Concerns & Declarative Schemas](https://en.wikipedia.org/wiki/Separation_of_concerns)
- [PEP 557 – Data Classes](https://peps.python.org/pep-0557/)