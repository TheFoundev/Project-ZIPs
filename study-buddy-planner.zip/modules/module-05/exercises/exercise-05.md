# Exercise 05: Interactive Input Validation and Personal Study Planner

- **Exercise ID**: `exercise-05`
- **Module**: `module-05` (Interactive Mode & Input Validation)
- **Duration**: 45 minutes

## Purpose
The objective of this hands-on lab is to build, debug, and enhance an interactive command-line interface with bulletproof defensive validation, schema decoupling, and single-sample machine learning inference. You will work directly with Python's `sys.argv`, input sanitization, exception handling, and pandas DataFrame transformations.

---

## Prerequisites
Before beginning this lab, ensure you have completed:
- [Lesson 01: Command-Line Interface Routing & sys.argv](../lessons/lesson-01.md)
- [Lesson 02: Structured Configuration with QUESTIONS](../lessons/lesson-02.md)
- [Lesson 03: Defensive Input Validation & Error Handling](../lessons/lesson-03.md)
- [Lesson 04: Single-Sample Inference & DataFrame Formatting](../lessons/lesson-04.md)

---

## Lab Tasks

### Task 1: CLI Route Interception
In this task, you will create a small utility script that parses command-line arguments to toggle between three execution modes:
1. `--scripted` (default): Runs a non-interactive simulation.
2. `--interactive`: Launches the terminal question loop.
3. `--batch-file <path>`: Reads a CSV file of student situations and runs batch inference.

#### Instructions:
1. Create a script named `cli_router.py`.
2. Inspect `sys.argv` using Python's `sys` module.
3. If `--help` or `-h` is supplied, print a usage manual.
4. If no arguments are passed, default to scripted mode.
5. Print which mode was selected along with any parameters.

---

### Task 2: Declarative Schema Extender
Refactor the prompt system to support additional validation metadata.

#### Instructions:
1. Define a namedtuple or dataclass `FeaturePrompt` with fields:
   - `prompt_text`: String displayed to the user.
   - `feature_name`: Exact column name for pandas.
   - `min_val`: Minimum acceptable integer.
   - `max_val`: Maximum acceptable integer.
   - `help_hint`: Educational tip displayed if the user enters an invalid number twice.
2. Define a list of 5 `FeaturePrompt` objects including a new 5th feature: `"exam_tomorrow"` (`min_val=0`, `max_val=1`).
3. Write a validation function to verify that all feature names are alphanumeric and non-empty.

---

### Task 3: Hardened Validation Loop
Implement a defensive input collector function named `robust_ask()` that handles:
1. Stripping leading/trailing whitespace and control characters.
2. Catching `ValueError` when non-numeric strings are entered.
3. Re-prompting on numbers outside `[min_val, max_val]`.
4. Gracefully handling `KeyboardInterrupt` (Ctrl+C) by printing `"Session cancelled by user."` and exiting with code `0`.
5. Gracefully handling `EOFError` (end-of-file signal) by falling back to default midpoint values.

---

### Task 4: Single-Row DataFrame Inference Engine
Write a complete, executable Python script named `test_inference_engine.py` that:
1. Loads the pre-trained `DecisionTreeClassifier` (or trains a quick classifier on `data/study_situations.csv`).
2. Calls your `robust_ask()` function to obtain a 1-row DataFrame.
3. Verifies that the DataFrame shape is exactly `(1, 4)`.
4. Generates predictions using `model.predict(situation)`.
5. Extracts the scalar label and prints a recommendation card:
   ```text
   +-------------------------------------------------------+
   |              STUDY BUDDY RECOMMENDATION               |
   +-------------------------------------------------------+
   | Input Parameters:                                     |
   |   - Hours Remaining: 4                                |
   |   - Subject Difficulty: 5                             |
   |   - Energy Level: 4                                   |
   |   - Distraction Level: 2                              |
   +-------------------------------------------------------+
   | Recommended Strategy: Practice problems               |
   | Advice: Focus on active problem solving right away!   |
   +-------------------------------------------------------+
   ```

---

## Verification & Expected Output

Run your completed script with `--interactive`:
```bash
python test_inference_engine.py --interactive
```
Provide the following answers:
- Hours: `2`
- Difficulty: `4`
- Energy: `3`
- Distraction: `2`

Expected Strategy Output: `Quick review`

Provide a second run:
- Hours: `6`
- Difficulty: `5`
- Energy: `4`
- Distraction: `1`

Expected Strategy Output: `Practice problems`

---

## Submission Checklist
- [ ] `cli_router.py` correctly parses `--interactive`, `--help`, and defaults to scripted execution.
- [ ] Declarative question schema defines 5 features with explicit bounds and metadata.
- [ ] Validation loop handles `ValueError`, `KeyboardInterrupt`, and boundary violations without crashing.
- [ ] Input data is transformed into a `(1, N)` pandas DataFrame matching training column names.
- [ ] Scalar prediction string is cleanly extracted and displayed in formatted output.