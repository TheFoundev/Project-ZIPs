# Prerequisites

## Skills Required
- **Python Fundamentals**: Understanding variables, data types (integers, strings, dictionaries, lists), loops (`for`, `while`), conditional branching (`if/elif/else`), and basic error handling (`try/except`).
- **Data Inspection with Pandas**: Familiarity with DataFrames, Series, column selection with single/double brackets, and loading CSV files via `pd.read_csv()`.
- **Basic Machine Learning Concepts**: Conceptual understanding of supervised learning, distinguishing between input features ($X$) and target labels ($y$), and the purpose of train/test data splitting.
- **Command Line Navigation**: Running terminal commands, passing CLI arguments (e.g., `--interactive`), and inspecting generated files.

## Tools Required
- **Python Environment**: Python 3.8 or higher.
- **Package Manager**: `pip` (Python package installer).
- **Code Editor or Terminal**: VS Code, PyCharm, Cursor, or standard terminal.

## Packages
The following Python packages must be installed in your environment:
- `pandas` (for CSV ingestion and DataFrame manipulation)
- `scikit-learn` (for `DecisionTreeClassifier`, tree plotting, text export, and evaluation metrics)
- `matplotlib` (for headless plot rendering and chart saving)

You can verify and install these packages using:
```bash
pip install pandas scikit-learn matplotlib
```

## Knowledge to Review
- **Decision Trees vs. Linear Models**: Why a tree algorithm splits space using axis-aligned orthogonal boundaries rather than a single continuous slope.
- **Stratified Sampling**: Why keeping minority class proportions identical between training and test sets prevents biased evaluations.
- **Classification vs. Regression**: Why recommending one of four discrete strategies is a multi-class classification problem rather than a continuous numeric regression problem.
- **Explainability**: Why inspectable if-then rules are especially crucial when designing educational or human-centric AI tools.
