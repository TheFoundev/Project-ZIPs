# Glossary

| Term | Definition |
|---|---|
| **Decision Tree** | A supervised learning algorithm that makes decisions by splitting data across a hierarchy of conditional questions (if-then rules). |
| **Explainable AI (XAI)** | Machine learning methods and architectures whose internal decision logic can be directly inspected, understood, and audited by humans. |
| **`max_depth`** | Hyperparameter that limits the maximum vertical depth of a decision tree, preventing overfitting and preserving model interpretability. |
| **Node** | A point in a decision tree where a condition is evaluated on a single feature to branch the dataset into subsets. |
| **Leaf Node (Terminal Node)** | An endpoint in a decision tree that outputs a final classification class without further branching. |
| **Gini Impurity** | A metric (ranging from 0.0 to 1.0) measuring the probability of incorrectly classifying a randomly chosen element if it were randomly labeled according to the class distribution. Pure leaves have Gini = 0.0. |
| **Stratified Sampling (`stratify=y`)** | Splitting a dataset such that each partition (train and test) maintains the exact same proportion of class labels as the original dataset. |
| **Multi-Class Classification** | A supervised classification task where each instance must be assigned to one of three or more distinct discrete classes (here, 4 strategy classes). |
| **Accuracy** | The proportion of total predictions that the model classified correctly ($ \frac{\text{Correct Predictions}}{\text{Total Predictions}} $). |
| **Precision** | The fraction of positive predictions for a given class that were actually correct ($ \frac{TP}{TP + FP} $). |
| **Recall** | The fraction of actual occurrences of a given class that the model successfully identified ($ \frac{TP}{TP + FN} $). |
| **F1-Score** | The harmonic mean of precision and recall ($ 2 \times \frac{\text{Precision} \times \text{Recall}}{\text{Precision} + \text{Recall}} $), balancing false positives and false negatives. |
| **Confusion Matrix** | A square matrix showing counts of actual vs. predicted classes, revealing specific patterns of misclassification across all categories. |
| **`export_text()`** | A scikit-learn utility that translates a trained decision tree into a formatted, human-readable ASCII outline showing branching thresholds and leaf classes. |
| **`plot_tree()`** | A scikit-learn visualization function that renders the decision hierarchy as a graphical flowchart diagram with colored boxes, sample counts, and impurity values. |
| **`sys.argv`** | A Python list containing command-line arguments passed when executing a script, used to toggle execution flags like `--interactive`. |
| **Input Validation** | Defensive programming techniques (such as `try...except` and loop conditions) that verify user inputs conform to expected types and value ranges before processing. |
| **Feature (`X`)** | An independent input variable used by the model to make predictions (`hours_left`, `difficulty`, `energy`, `distraction`). |
| **Target (`y`)** | The dependent output variable that the model is trained to predict (`strategy`). |
| **Overfitting** | A modeling failure where an algorithm memorizes quirks or noise in the training data rather than general patterns, resulting in poor performance on unseen test data. |
