# Setup Guide

## Step 1: Navigate to Project Directory
Open your terminal and navigate to the project directory:
```bash
cd "/home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/20_study_buddy_planner"
```

## Step 2: Verify Python Environment
Ensure Python 3.8+ is installed and active:
```bash
python3 --version
```

## Step 3: Install Required Dependencies
Install the required scientific packages:
```bash
pip install pandas scikit-learn matplotlib
```

Alternatively, create a `requirements.txt` file with:
```txt
pandas>=1.3.0
scikit-learn>=1.0.0
matplotlib>=3.5.0
```
And install via:
```bash
pip install -r requirements.txt
```

## Step 4: Inspect the Dataset
Verify the presence and integrity of `data/study_situations.csv`:
```bash
head -n 10 data/study_situations.csv
```
Confirm the header row contains:
`hours_left,difficulty,energy,distraction,strategy`

## Step 5: Run Scripted Demo Mode (Default)
Execute the script without flags to run the end-to-end benchmark pipeline:
```bash
python3 main.py
```
Verify that:
- Accuracy is displayed as 100.0%.
- The multi-class classification report prints all 4 strategy classes.
- Learned rules are printed in ASCII format.
- 4 demo plans are evaluated.
- Output files are generated in `outputs/`.

## Step 6: Run Interactive Mode
Execute the script with the `--interactive` flag to test live Q&A recommendations:
```bash
python3 main.py --interactive
```
Answer the 4 prompts using valid whole numbers within the displayed ranges:
- Hours left: 1-10
- Difficulty: 1-5
- Energy: 1-5
- Distraction: 1-5

Verify that the system returns a valid strategy recommendation and gracefully handles invalid entries (such as letters or out-of-range numbers).

## Step 7: Verify Generated Artifacts
Check the contents of the `outputs/` directory:
- `outputs/study_tree.png`: High-resolution diagram of the decision tree.
- `outputs/confusion_matrix.png`: Heatmap plot of strategy predictions.
- `outputs/rules.txt`: Text file recording metrics, ASCII rules, and demo plan outputs.
