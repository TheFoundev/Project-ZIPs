# Study Buddy Planner: Complete Assessment Answer Key

> Comprehensive reference document consolidating all 60 multiple-choice assessment questions, correct answers, in-depth explanations, distractor analyses, concepts tested, and source code line references across all six modules.

---

## Module 01: Project Overview, Dataset Architecture & Problem Formulation

### Question Q1-01: What is the primary machine learning task solved by the Study Buddy Planner?

- **Difficulty**: `Basic`
- **Related Lesson**: `lesson-01`
- **Concept Tested**: Supervised multi-class classification vs other learning paradigms
- **Source Reference**: `main.py lines 7-8 and line 65: DecisionTreeClassifier`

**Options:**
- **[A]** Continuous numerical regression
- **[B]** Supervised multi-class recommendation / classification **(Correct)**
- **[C]** Unsupervised clustering
- **[D]** Reinforcement learning policy optimization

**Correct Answer:** Option **B** — *Supervised multi-class recommendation / classification*

**Explanation:** The Study Buddy Planner solves a supervised multi-class recommendation problem. It uses historical examples with known features and known strategies to train a DecisionTreeClassifier that recommends one of four distinct study action plans.

**Distractor Analysis:**
- **[A] (Continuous numerical regression):** Continuous numerical regression predicts floating-point numbers (such as sales or temperature), whereas this project predicts discrete categories.
- **[C] (Unsupervised clustering):** Unsupervised clustering groups unlabeled data without target labels, whereas this project uses labeled data with ground-truth strategies.
- **[D] (Reinforcement learning policy optimization):** Reinforcement learning optimizes actions via environment rewards and penalties, whereas this project trains on a static tabular dataset.

---

### Question Q1-02: Which algorithm is instantiated in main.py to learn study rules?

- **Difficulty**: `Basic`
- **Related Lesson**: `lesson-01`
- **Concept Tested**: Identifying the project algorithm
- **Source Reference**: `main.py lines 23 and 65: DecisionTreeClassifier(max_depth=4, random_state=42)`

**Options:**
- **[A]** LinearRegression
- **[B]** KMeans
- **[C]** DecisionTreeClassifier **(Correct)**
- **[D]** MultinomialNB

**Correct Answer:** Option **C** — *DecisionTreeClassifier*

**Explanation:** main.py imports and instantiates DecisionTreeClassifier(max_depth=4, random_state=42) from sklearn.tree. This algorithm splits data based on hierarchical if-then conditions.

**Distractor Analysis:**
- **[A] (LinearRegression):** LinearRegression is used for continuous regression problems, not discrete multi-class classification.
- **[B] (KMeans):** KMeans is an unsupervised clustering algorithm, not a supervised classifier.
- **[D] (MultinomialNB):** MultinomialNB is a Naive Bayes classifier commonly used for text classification, not the decision tree used here.

---

### Question Q1-03: What are the four input features defined in the FEATURES list in main.py?

- **Difficulty**: `Basic`
- **Related Lesson**: `lesson-03`
- **Concept Tested**: Dataset feature names
- **Source Reference**: `main.py line 30: FEATURES = ['hours_left', 'difficulty', 'energy', 'distraction']`

**Options:**
- **[A]** ['study_time', 'sleep_hours', 'grade', 'subject']
- **[B]** ['hours_left', 'difficulty', 'energy', 'distraction'] **(Correct)**
- **[C]** ['focus', 'fatigue', 'deadline', 'pages']
- **[D]** ['temperature', 'humidity', 'caffeine', 'noise']

**Correct Answer:** Option **B** — *['hours_left', 'difficulty', 'energy', 'distraction']*

**Explanation:** Line 30 of main.py explicitly defines FEATURES = ['hours_left', 'difficulty', 'energy', 'distraction']. These four columns serve as the input matrix X.

**Distractor Analysis:**
- **[A] (['study_time', 'sleep_hours', 'grade', 'subject']):** study_time, sleep_hours, grade, and subject are not columns in the dataset.
- **[C] (['focus', 'fatigue', 'deadline', 'pages']):** focus, fatigue, deadline, and pages are not the feature names used in the code.
- **[D] (['temperature', 'humidity', 'caffeine', 'noise']):** temperature and humidity were features in the Lemonade Stand project, not the Study Buddy Planner.

---

### Question Q1-04: Why is the Study Buddy Planner described as an 'explainable' recommendation engine?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-02`
- **Concept Tested**: Explainable AI (XAI) and decision tree transparency
- **Source Reference**: `main.py line 8: 'the rules are printed so you can question them'`

**Options:**
- **[A]** It uses natural language processing to generate long conversational essays
- **[B]** It uses a decision tree whose learned logic can be directly inspected as human-readable if-then rules **(Correct)**
- **[C]** It searches the web for educational articles to explain its output
- **[D]** It requires users to write an explanation of their feelings before making a prediction

**Correct Answer:** Option **B** — *It uses a decision tree whose learned logic can be directly inspected as human-readable if-then rules*

**Explanation:** The system is explainable because decision trees produce transparent, deterministic if-then branching rules (extracted with export_text) that humans can read, inspect, and evaluate directly.

**Distractor Analysis:**
- **[A] (It uses natural language processing to generate long conversational essays):** The project uses scikit-learn decision trees, not natural language generation models.
- **[C] (It searches the web for educational articles to explain its output):** The model operates completely offline and does not query external web search engines.
- **[D] (It requires users to write an explanation of their feelings before making a prediction):** The model takes four numeric values; it does not require users to write essay explanations.

---

### Question Q1-05: What are the four target study strategies that the model recommends?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-01`
- **Concept Tested**: Multi-class target labels
- **Source Reference**: `main.py classification_report and unique values in df['strategy']`

**Options:**
- **[A]** High pass, Low pass, Retake, Drop
- **[B]** Deep focus block, Practice problems, Quick review, Take a break first **(Correct)**
- **[C]** Read chapter, Watch video, Group study, Solo study
- **[D]** Morning study, Afternoon study, Night study, Weekend study

**Correct Answer:** Option **B** — *Deep focus block, Practice problems, Quick review, Take a break first*

**Explanation:** The four target strategy classes present in study_situations.csv and evaluated in main.py are 'Deep focus block', 'Practice problems', 'Quick review', and 'Take a break first'.

**Distractor Analysis:**
- **[A] (High pass, Low pass, Retake, Drop):** High pass, Low pass, Retake, Drop are academic grading designations, not study action plans.
- **[C] (Read chapter, Watch video, Group study, Solo study):** Read chapter, Watch video, Group study, Solo study are study mediums, not the model's target classes.
- **[D] (Morning study, Afternoon study, Night study, Weekend study):** Time-of-day designations are not the classes predicted by this model.

---

### Question Q1-06: Which command-line argument enables the interactive questionnaire mode in main.py?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-04`
- **Concept Tested**: CLI argument handling via sys.argv
- **Source Reference**: `main.py line 127: if '--interactive' in sys.argv:`

**Options:**
- **[A]** --test
- **[B]** --demo
- **[C]** --interactive **(Correct)**
- **[D]** --verbose

**Correct Answer:** Option **C** — *--interactive*

**Explanation:** Line 127 of main.py checks: if '--interactive' in sys.argv: to determine whether to trigger the ask_situation() interactive questionnaire.

**Distractor Analysis:**
- **[A] (--test):** --test is not recognized by the script.
- **[B] (--demo):** --demo is not a valid flag; scripted demo mode is the default when no flags are supplied.
- **[D] (--verbose):** --verbose is not implemented in main.py.

---

### Question Q1-07: Why does main.py call matplotlib.use('Agg') prior to importing pyplot?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-04`
- **Concept Tested**: Headless matplotlib rendering
- **Source Reference**: `main.py line 18: matplotlib.use('Agg')`

**Options:**
- **[A]** To speed up Python memory garbage collection
- **[B]** To enable a headless plotting backend that saves images without requiring a GUI window display **(Correct)**
- **[C]** To convert plots automatically into 3D animations
- **[D]** To invert the default color palette for high contrast

**Correct Answer:** Option **B** — *To enable a headless plotting backend that saves images without requiring a GUI window display*

**Explanation:** matplotlib.use('Agg') configures the Anti-Grain Geometry non-interactive backend, allowing plots to be generated and saved directly to disk without requiring a display server or GUI desktop environment.

**Distractor Analysis:**
- **[A] (To speed up Python memory garbage collection):** matplotlib backends govern rendering destinations, not Python runtime garbage collection.
- **[C] (To convert plots automatically into 3D animations):** Agg renders standard raster 2D images, not 3D animations.
- **[D] (To invert the default color palette for high contrast):** Color palettes are controlled via colormap arguments (e.g. cmap='Purples'), not the backend selector.

---

### Question Q1-08: What are the valid numerical bounds defined in QUESTIONS for the hours_left feature?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-03`
- **Concept Tested**: Feature boundary definitions in QUESTIONS
- **Source Reference**: `main.py line 32: ('How many hours do you have left? (1-10) ', 'hours_left', 1, 10)`

**Options:**
- **[A]** 0 to 100
- **[B]** 1 to 5
- **[C]** 1 to 10 **(Correct)**
- **[D]** 0 to 24

**Correct Answer:** Option **C** — *1 to 10*

**Explanation:** In QUESTIONS on line 32, hours_left is bounded between 1 and 10: ('How many hours do you have left? (1-10) ', 'hours_left', 1, 10).

**Distractor Analysis:**
- **[A] (0 to 100):** 0 to 100 is far too broad and unrealistic for a single study session.
- **[B] (1 to 5):** 1 to 5 is the range used for difficulty, energy, and distraction, but hours_left allows up to 10.
- **[D] (0 to 24):** 0 to 24 spans an entire day, but the project bounds study hours to 1-10.

---

### Question Q1-09: What pedagogical purpose is served by the docstring principle: 'the rules are printed so you can question them'?

- **Difficulty**: `Advanced`
- **Related Lesson**: `lesson-02`
- **Concept Tested**: Metacognitive benefits of Explainable AI in education
- **Source Reference**: `main.py line 8: 'the rules are printed so you can question them'`

**Options:**
- **[A]** It discourages students from using machine learning in their homework
- **[B]** It fosters metacognitive reflection and allows users to audit and verify algorithmic advice rather than blindly obeying it **(Correct)**
- **[C]** It warns users that the software has critical memory leak bugs
- **[D]** It proves that machine learning models never make mistakes

**Correct Answer:** Option **B** — *It fosters metacognitive reflection and allows users to audit and verify algorithmic advice rather than blindly obeying it*

**Explanation:** Transparent rules allow students to understand the causal factors behind advice (e.g., recognizing that high distraction necessitates rest), fostering self-reflection and preventing blind over-reliance on opaque automation.

**Distractor Analysis:**
- **[A] (It discourages students from using machine learning in their homework):** The goal is to empower student learning and AI literacy, not discourage computer use.
- **[C] (It warns users that the software has critical memory leak bugs):** Printing rules is a deliberate pedagogical feature, not a bug warning.
- **[D] (It proves that machine learning models never make mistakes):** Explainability allows users to detect errors when models make mistakes, rather than claiming infallibility.

---

### Question Q1-10: Why is study strategy recommendation framed as classification rather than continuous numeric regression?

- **Difficulty**: `Advanced`
- **Related Lesson**: `lesson-01`
- **Concept Tested**: Classification vs regression formulation
- **Source Reference**: `main.py uses DecisionTreeClassifier because y is categorical`

**Options:**
- **[A]** Regression can only be used on datasets with more than 10,000 samples
- **[B]** Study strategies are discrete, distinct behavioral action plans, not continuous scalar quantities **(Correct)**
- **[C]** Decision trees cannot perform mathematical calculations
- **[D]** Python does not support regression on CSV files

**Correct Answer:** Option **B** — *Study strategies are discrete, distinct behavioral action plans, not continuous scalar quantities*

**Explanation:** Study strategies represent distinct qualitative behavioral categories. You cannot assign a numerical average or continuous interpolation between 'Take a break first' and 'Practice problems'; they require discrete multi-class classification.

**Distractor Analysis:**
- **[A] (Regression can only be used on datasets with more than 10,000 samples):** Regression works fine on small datasets; the issue is that qualitative strategies are not continuous numbers.
- **[C] (Decision trees cannot perform mathematical calculations):** Decision trees can perform both regression and classification (DecisionTreeRegressor exists in scikit-learn).
- **[D] (Python does not support regression on CSV files):** Python and pandas readily support regression models on tabular CSV data.

---

## Module 02: Decision Tree Theory, Gini Impurity & Stratification

### Question Q2-01: How many total study scenario rows are in data/study_situations.csv?

- **Difficulty**: `Basic`
- **Related Lesson**: `lesson-01`
- **Concept Tested**: Dataset row count verification
- **Source Reference**: `data/study_situations.csv has 120 data rows`

**Options:**
- **[A]** 16
- **[B]** 120 **(Correct)**
- **[C]** 500
- **[D]** 1,000

**Correct Answer:** Option **B** — *120*

**Explanation:** The dataset data/study_situations.csv contains exactly 120 rows of student scenario data (121 lines including the header row).

**Distractor Analysis:**
- **[A] (16):** 16 was the number of rows in the Lemonade Stand dataset, not the Study Buddy Planner.
- **[C] (500):** 500 is much larger than the actual 120-row dataset.
- **[D] (1,000):** 1,000 is incorrect; the project deliberately uses a clean, compact dataset of 120 situations.

---

### Question Q2-02: What is the allowable range of values for hours_left in the dataset and QUESTIONS configuration?

- **Difficulty**: `Basic`
- **Related Lesson**: `lesson-02`
- **Concept Tested**: Feature domain boundary for hours_left
- **Source Reference**: `main.py line 32: ('How many hours do you have left? (1-10) ', 'hours_left', 1, 10)`

**Options:**
- **[A]** 0 to 24
- **[B]** 1 to 10 **(Correct)**
- **[C]** 1 to 5
- **[D]** -5 to +5

**Correct Answer:** Option **B** — *1 to 10*

**Explanation:** hours_left is bounded between 1 and 10 hours, representing the realistic amount of time a student might dedicate to a study session.

**Distractor Analysis:**
- **[A] (0 to 24):** 0 to 24 covers a full day, but the project bounds study hours to 1-10.
- **[C] (1 to 5):** 1 to 5 is the scale used for difficulty, energy, and distraction, not hours_left.
- **[D] (-5 to +5):** -5 to +5 is meaningless because study time cannot be negative.

---

### Question Q2-03: What rating scale is used for difficulty, energy, and distraction?

- **Difficulty**: `Basic`
- **Related Lesson**: `lesson-02`
- **Concept Tested**: Likert scale feature definitions
- **Source Reference**: `main.py lines 33-35: 1 to 5 bounds for difficulty, energy, and distraction`

**Options:**
- **[A]** Binary (0 or 1)
- **[B]** 1 to 10 scale
- **[C]** 1 to 5 Likert scale **(Correct)**
- **[D]** Floating-point percentage (0.0 to 1.0)

**Correct Answer:** Option **C** — *1 to 5 Likert scale*

**Explanation:** difficulty, energy, and distraction all use a 1-to-5 Likert scale, where 1 represents the lowest rating (very easy, completely exhausted, or dead quiet) and 5 represents the highest rating (very hard, peak energy, or extreme chaos).

**Distractor Analysis:**
- **[A] (Binary (0 or 1)):** Binary (0 or 1) does not provide enough nuance for subjective human states.
- **[B] (1 to 10 scale):** 1 to 10 scale is only used for hours_left, not the three 5-point scales.
- **[D] (Floating-point percentage (0.0 to 1.0)):** Floating-point percentages are not used; the inputs are whole integers from 1 to 5.

---

### Question Q2-04: Which study strategy is the most frequent in study_situations.csv, and how many occurrences does it have?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-03`
- **Concept Tested**: Identifying majority class distribution
- **Source Reference**: `df['strategy'].value_counts() shows Take a break first: 56`

**Options:**
- **[A]** Deep focus block (30 occurrences)
- **[B]** Take a break first (56 occurrences) **(Correct)**
- **[C]** Quick review (21 occurrences)
- **[D]** Practice problems (13 occurrences)

**Correct Answer:** Option **B** — *Take a break first (56 occurrences)*

**Explanation:** 'Take a break first' is the most frequent class, appearing 56 times (46.7% of the dataset). This reflects the reality that fatigue or high distraction frequently interrupt student study intentions.

**Distractor Analysis:**
- **[A] (Deep focus block (30 occurrences)):** Deep focus block has 30 occurrences (25.0%), ranking second.
- **[C] (Quick review (21 occurrences)):** Quick review has 21 occurrences (17.5%), ranking third.
- **[D] (Practice problems (13 occurrences)):** Practice problems has 13 occurrences (10.8%), ranking fourth.

---

### Question Q2-05: Which study strategy is the least frequent in the dataset?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-03`
- **Concept Tested**: Identifying minority class distribution
- **Source Reference**: `df['strategy'].value_counts() shows Practice problems: 13`

**Options:**
- **[A]** Deep focus block
- **[B]** Take a break first
- **[C]** Practice problems **(Correct)**
- **[D]** Quick review

**Correct Answer:** Option **C** — *Practice problems*

**Explanation:** 'Practice problems' is the least frequent class with only 13 occurrences (10.8%). This is because practice problems require a demanding alignment of high time, high energy, low distraction, and hard difficulty.

**Distractor Analysis:**
- **[A] (Deep focus block):** Deep focus block has 30 occurrences.
- **[B] (Take a break first):** Take a break first is the most frequent with 56 occurrences.
- **[D] (Quick review):** Quick review has 21 occurrences.

---

### Question Q2-06: In main.py, what is the value of test_size in train_test_split()?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-04`
- **Concept Tested**: Train/test split partition size
- **Source Reference**: `main.py line 62: test_size=0.25`

**Options:**
- **[A]** 0.10
- **[B]** 0.20
- **[C]** 0.25 **(Correct)**
- **[D]** 0.50

**Correct Answer:** Option **C** — *0.25*

**Explanation:** Line 62 of main.py explicitly uses test_size=0.25, partitioning 25% of the data (30 samples) into the test set and 75% (90 samples) into the training set.

**Distractor Analysis:**
- **[A] (0.10):** 0.10 would only yield 12 test samples, which is too small for a 4-class multi-class evaluation.
- **[B] (0.20):** 0.20 is commonly used in other projects, but main.py specifies test_size=0.25.
- **[D] (0.50):** 0.50 would split the data 50/50, depriving the model of training samples.

---

### Question Q2-07: Why is stratify=y passed to train_test_split() in main.py?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-04`
- **Concept Tested**: Purpose of stratified sampling
- **Source Reference**: `main.py line 62: stratify=y`

**Options:**
- **[A]** To automatically sort rows in ascending order
- **[B]** To ensure the training and testing sets maintain the exact same proportion of each strategy class **(Correct)**
- **[C]** To normalize all numeric features between 0.0 and 1.0
- **[D]** To remove all duplicate rows from the dataset

**Correct Answer:** Option **B** — *To ensure the training and testing sets maintain the exact same proportion of each strategy class*

**Explanation:** stratify=y forces the random partitioning algorithm to preserve identical class proportions between the training set and the test set, preventing minority classes from being under-sampled in either partition.

**Distractor Analysis:**
- **[A] (To automatically sort rows in ascending order):** Sorting rows is done by sort_values(), not stratify.
- **[C] (To normalize all numeric features between 0.0 and 1.0):** Feature normalization is performed using scalers like MinMaxScaler, not train_test_split.
- **[D] (To remove all duplicate rows from the dataset):** Deduplication is performed by drop_duplicates(), not stratify.

---

### Question Q2-08: How many samples are in the test set, and how many of those are 'Take a break first'?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-04`
- **Concept Tested**: Calculating exact sample counts under stratified split
- **Source Reference**: `Classification report support column in main.py: Take a break first = 14, total = 30`

**Options:**
- **[A]** 30 test samples total, with 14 being 'Take a break first' **(Correct)**
- **[B]** 40 test samples total, with 20 being 'Take a break first'
- **[C]** 25 test samples total, with 10 being 'Take a break first'
- **[D]** 50 test samples total, with 25 being 'Take a break first'

**Correct Answer:** Option **A** — *30 test samples total, with 14 being 'Take a break first'*

**Explanation:** With test_size=0.25 of 120 samples, the test set has exactly 30 samples. Because 'Take a break first' has 56 total occurrences, 25% of 56 is exactly 14 samples.

**Distractor Analysis:**
- **[B] (40 test samples total, with 20 being 'Take a break first'):** 40 test samples would correspond to a 33% split, which is incorrect.
- **[C] (25 test samples total, with 10 being 'Take a break first'):** 25 test samples does not match 25% of 120 (which is 30).
- **[D] (50 test samples total, with 25 being 'Take a break first'):** 50 test samples would represent nearly half the dataset.

---

### Question Q2-09: Why does scikit-learn's decision tree place split thresholds at decimal values like 2.50 and 3.50 when the features are whole integers?

- **Difficulty**: `Advanced`
- **Related Lesson**: `lesson-02`
- **Concept Tested**: Decision tree midpoint threshold calculation
- **Source Reference**: `scikit-learn DecisionTreeClassifier threshold formula: (X[i] + X[i+1]) / 2`

**Options:**
- **[A]** It represents a bug in floating-point roundoff error
- **[B]** Decision trees place split boundaries at the midpoint between adjacent observed integer training values **(Correct)**
- **[C]** The dataset was secretly converted to floating-point numbers during loading
- **[D]** 2.50 and 3.50 are arbitrary default constants hardcoded in scikit-learn

**Correct Answer:** Option **B** — *Decision trees place split boundaries at the midpoint between adjacent observed integer training values*

**Explanation:** In scikit-learn, decision tree cutoffs are calculated as the mathematical midpoint (average) between adjacent distinct values in the training data. For integer attributes, the boundary between 2 and 3 is placed at (2 + 3) / 2 = 2.50.

**Distractor Analysis:**
- **[A] (It represents a bug in floating-point roundoff error):** Midpoint calculation is an intentional, exact mathematical feature of decision tree splitting, not a floating-point bug.
- **[C] (The dataset was secretly converted to floating-point numbers during loading):** The dataset values remain int64; scikit-learn computes split thresholds internally.
- **[D] (2.50 and 3.50 are arbitrary default constants hardcoded in scikit-learn):** The values 2.50 and 3.50 are derived dynamically from the data, not hardcoded defaults.

---

### Question Q2-10: What would be the primary danger of performing an unstratified random split on this 120-row dataset?

- **Difficulty**: `Advanced`
- **Related Lesson**: `lesson-04`
- **Concept Tested**: Risks of unstratified splitting on imbalanced datasets
- **Source Reference**: `main.py line 62 uses stratify=y specifically to protect minority class evaluation`

**Options:**
- **[A]** It would cause Python to run out of RAM
- **[B]** The minority class ('Practice problems', with only 13 samples) could be severely under-represented or absent in the test set, producing invalid metric evaluations **(Correct)**
- **[C]** The CSV file would be permanently deleted from disk
- **[D]** It would force the decision tree depth to exceed 10 levels

**Correct Answer:** Option **B** — *The minority class ('Practice problems', with only 13 samples) could be severely under-represented or absent in the test set, producing invalid metric evaluations*

**Explanation:** In an unstratified random split of a small dataset with 13 minority class instances, pure chance could allocate 0 or 1 instances of 'Practice problems' to the test set, making it impossible to evaluate test precision and recall reliably.

**Distractor Analysis:**
- **[A] (It would cause Python to run out of RAM):** Splitting 120 rows uses a fraction of a megabyte of RAM; it cannot cause an out-of-memory error.
- **[C] (The CSV file would be permanently deleted from disk):** Splitting data in memory never alters or deletes the underlying CSV file on disk.
- **[D] (It would force the decision tree depth to exceed 10 levels):** The tree depth is strictly capped at max_depth=4 regardless of how the data is split.

---

## Module 03: Data Splitting, Stratification & Training Pipeline

### Question Q3-01: What is the top-most starting node of a decision tree called?

- **Difficulty**: `Basic`
- **Related Lesson**: `lesson-01`
- **Concept Tested**: Decision tree node topology and terminology
- **Source Reference**: `main.py export_text output line 1: |--- hours_left <= 2.50 is the root`

**Options:**
- **[A]** Leaf node
- **[B]** Root node **(Correct)**
- **[C]** Terminal node
- **[D]** Branch node

**Correct Answer:** Option **B** — *Root node*

**Explanation:** The root node is the topmost starting node of a decision tree from which all recursive binary branches originate. In main.py, the root node tests hours_left <= 2.50.

**Distractor Analysis:**
- **[A] (Leaf node):** Leaf nodes (terminal nodes) are the endpoints at the bottom of the tree, not the top starting point.
- **[C] (Terminal node):** Terminal node is a synonym for leaf node, representing an endpoint.
- **[D] (Branch node):** Branch node (or internal node) refers to intermediate splitting points below the root.

---

### Question Q3-02: What does a Gini impurity value of 0.0 indicate about a decision tree node?

- **Difficulty**: `Basic`
- **Related Lesson**: `lesson-01`
- **Concept Tested**: Definition and meaning of Gini impurity = 0.0
- **Source Reference**: `scikit-learn DecisionTreeClassifier Gini formula: 1 - sum(p_k^2)`

**Options:**
- **[A]** The node contains an equal number of all classes
- **[B]** The node is perfectly pure (all samples belong to the exact same class) **(Correct)**
- **[C]** The node contains a calculation error and cannot make predictions
- **[D]** The node contains zero training samples

**Correct Answer:** Option **B** — *The node is perfectly pure (all samples belong to the exact same class)*

**Explanation:** Gini impurity measures the degree of class mixture. A value of 0.0 means the node is perfectly pure—every single training sample reaching that node belongs to the exact same class.

**Distractor Analysis:**
- **[A] (The node contains an equal number of all classes):** An equal mix of classes produces maximum impurity (e.g. 0.75 for 4 equal classes).
- **[C] (The node contains a calculation error and cannot make predictions):** 0.0 is the ideal target state for classification nodes, not an error.
- **[D] (The node contains zero training samples):** The sample count is tracked independently by the samples attribute.

---

### Question Q3-03: What value is assigned to the max_depth hyperparameter in main.py?

- **Difficulty**: `Basic`
- **Related Lesson**: `lesson-02`
- **Concept Tested**: Identifying model hyperparameter settings
- **Source Reference**: `main.py line 65: model = DecisionTreeClassifier(max_depth=4, random_state=42)`

**Options:**
- **[A]** 2
- **[B]** 4 **(Correct)**
- **[C]** 10
- **[D]** None

**Correct Answer:** Option **B** — *4*

**Explanation:** Line 65 of main.py sets max_depth=4: model = DecisionTreeClassifier(max_depth=4, random_state=42).

**Distractor Analysis:**
- **[A] (2):** Depth 2 is too shallow and underfits the 4-feature dataset (only ~83.3% accuracy).
- **[C] (10):** Depth 10 is unconstrained for this dataset and could overfit on noisy samples.
- **[D] (None):** None is the scikit-learn default, but main.py explicitly specifies 4.

---

### Question Q3-04: Why does the Study Buddy Planner require max_depth=4 rather than a shallower depth like 2 or 3?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-02`
- **Concept Tested**: Causal justification for max_depth=4
- **Source Reference**: `export_text shows the deepest branch reaches depth 4 to test difficulty`

**Options:**
- **[A]** Because the dataset has 4 columns and depth must always equal the feature count
- **[B]** To evaluate the full 4-step sequence (hours -> energy -> distraction -> difficulty) needed to distinguish between 'Deep focus block' and 'Practice problems' **(Correct)**
- **[C]** To prevent Python from exceeding its maximum recursion limit
- **[D]** Because scikit-learn does not support tree depth values lower than 4

**Correct Answer:** Option **B** — *To evaluate the full 4-step sequence (hours -> energy -> distraction -> difficulty) needed to distinguish between 'Deep focus block' and 'Practice problems'*

**Explanation:** Differentiating between 'Deep focus block' and 'Practice problems' requires sequentially checking hours_left (Level 1), energy (Level 2), distraction (Level 3), and difficulty (Level 4). Without depth 4, the difficulty split cannot be reached.

**Distractor Analysis:**
- **[A] (Because the dataset has 4 columns and depth must always equal the feature count):** Tree depth is independent of feature count; trees can be deeper or shallower than the number of columns.
- **[C] (To prevent Python from exceeding its maximum recursion limit):** Python's recursion limit is typically 1,000, which has nothing to do with tree depth 4.
- **[D] (Because scikit-learn does not support tree depth values lower than 4):** scikit-learn readily supports any positive integer depth starting from 1.

---

### Question Q3-05: Which scikit-learn function generates the human-readable ASCII outline of the learned tree rules?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-03`
- **Concept Tested**: scikit-learn rule export utilities
- **Source Reference**: `main.py lines 23, 76, and 119: export_text(model, feature_names=FEATURES)`

**Options:**
- **[A]** tree_to_string
- **[B]** export_text **(Correct)**
- **[C]** print_rules
- **[D]** dump_tree

**Correct Answer:** Option **B** — *export_text*

**Explanation:** sklearn.tree.export_text() converts the internal tree structure into an indented ASCII text outline, showing exact feature thresholds and leaf classes.

**Distractor Analysis:**
- **[A] (tree_to_string):** tree_to_string is not a valid scikit-learn function.
- **[C] (print_rules):** print_rules does not exist in scikit-learn.
- **[D] (dump_tree):** dump_tree is used in other libraries (like XGBoost), not scikit-learn.

---

### Question Q3-06: In the learned rules, why does 'Take a break first' appear in two distinct leaf nodes?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-03`
- **Concept Tested**: Interpreting multi-leaf identical class assignments
- **Source Reference**: `export_text shows Take a break first at leaf 2 (energy) and leaf 5 (distraction)`

**Options:**
- **[A]** It represents an internal bug in scikit-learn's rule generator
- **[B]** There are two distinct real-world situations warranting a break: low energy (fatigue) or high distraction (chaotic environment) **(Correct)**
- **[C]** The dataset contains duplicate rows that confused the tree
- **[D]** The random seed was not set properly

**Correct Answer:** Option **B** — *There are two distinct real-world situations warranting a break: low energy (fatigue) or high distraction (chaotic environment)*

**Explanation:** The tree correctly models two distinct real-world pathways to taking a break: one caused by internal fatigue (energy <= 2.50) and another caused by external chaotic disruption (distraction > 3.50).

**Distractor Analysis:**
- **[A] (It represents an internal bug in scikit-learn's rule generator):** Multiple leaves predicting the same class is a normal, valid feature of decision trees.
- **[C] (The dataset contains duplicate rows that confused the tree):** Duplicate rows do not cause dual leaves; distinct feature combinations lead to this outcome.
- **[D] (The random seed was not set properly):** The random seed is correctly set to 42.

---

### Question Q3-07: What does the filled=True parameter do when calling plot_tree() in main.py?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-04`
- **Concept Tested**: plot_tree visual styling parameters
- **Source Reference**: `main.py line 98: filled=True in plot_tree`

**Options:**
- **[A]** It fills missing values in the dataset using median imputation
- **[B]** It colors the interior of node boxes according to their majority class and purity level **(Correct)**
- **[C]** It draws solid black boxes over sensitive feature information
- **[D]** It fills the entire user terminal screen with ASCII artwork

**Correct Answer:** Option **B** — *It colors the interior of node boxes according to their majority class and purity level*

**Explanation:** filled=True shades each node box with a distinct hue representing its majority class, with color intensity/saturation increasing as Gini impurity approaches 0.0 (pure nodes).

**Distractor Analysis:**
- **[A] (It fills missing values in the dataset using median imputation):** Missing value imputation is handled prior to modeling via SimpleImputer or pandas fillna.
- **[C] (It draws solid black boxes over sensitive feature information):** plot_tree is a diagnostic visualization tool and does not redact information.
- **[D] (It fills the entire user terminal screen with ASCII artwork):** Plot dimensions are controlled by matplotlib figsize, not filled=True.

---

### Question Q3-08: Why is figsize=(16, 8) specified when creating the figure canvas for plot_tree?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-04`
- **Concept Tested**: Matplotlib canvas dimensions for tree visualization
- **Source Reference**: `main.py line 92: fig, ax = plt.subplots(figsize=(16, 8))`

**Options:**
- **[A]** To comply with smartphone wallpaper dimensions
- **[B]** To provide ample horizontal and vertical canvas room so multi-level branch boxes and text labels do not collide or overlap **(Correct)**
- **[C]** Because matplotlib figures must always be multiples of 8 inches
- **[D]** To reduce the disk space consumed by the output image

**Correct Answer:** Option **B** — *To provide ample horizontal and vertical canvas room so multi-level branch boxes and text labels do not collide or overlap*

**Explanation:** Because the tree has 4 levels and 5 leaves, a standard small canvas causes neighboring branch boxes to overlap. An expansive 16x8 inch canvas provides sufficient space for crisp text and clear edges.

**Distractor Analysis:**
- **[A] (To comply with smartphone wallpaper dimensions):** Smartphone wallpapers typically use tall portrait ratios (e.g. 9:16), whereas (16, 8) is wide landscape.
- **[C] (Because matplotlib figures must always be multiples of 8 inches):** Matplotlib supports arbitrary float dimensions (e.g. figsize=(7.2, 3.4)).
- **[D] (To reduce the disk space consumed by the output image):** Larger figure dimensions actually produce slightly larger raster image files, not smaller.

---

### Question Q3-09: What would happen if DecisionTreeClassifier was trained with max_depth=None on a noisy dataset?

- **Difficulty**: `Advanced`
- **Related Lesson**: `lesson-02`
- **Concept Tested**: Overfitting risks of unconstrained tree depth
- **Source Reference**: `scikit-learn DecisionTreeClassifier documentation: max_depth=None leads to fully grown trees`

**Options:**
- **[A]** The tree would underfit and achieve low accuracy on both training and test sets
- **[B]** The tree would grow uncontrollably and memorize training noise, creating overly complex leaves that overfit **(Correct)**
- **[C]** The Python interpreter would refuse to compile the script
- **[D]** The tree would automatically prune itself to depth 1

**Correct Answer:** Option **B** — *The tree would grow uncontrollably and memorize training noise, creating overly complex leaves that overfit*

**Explanation:** When max_depth is unconstrained (None), the tree keeps splitting until all leaves are pure, isolating individual training samples and memorizing dataset noise (overfitting).

**Distractor Analysis:**
- **[A] (The tree would underfit and achieve low accuracy on both training and test sets):** Unconstrained trees suffer from high variance (overfitting), not underfitting.
- **[C] (The Python interpreter would refuse to compile the script):** Python and scikit-learn compile and execute max_depth=None without errors.
- **[D] (The tree would automatically prune itself to depth 1):** Pruning does not occur automatically unless explicit pruning parameters (like ccp_alpha) are provided.

---

### Question Q3-10: Why is plt.close(fig) called at the end of the plotting sections in main.py?

- **Difficulty**: `Advanced`
- **Related Lesson**: `lesson-04`
- **Concept Tested**: Matplotlib memory lifecycle and resource cleanup
- **Source Reference**: `main.py lines 105 and 115: plt.close(fig)`

**Options:**
- **[A]** To save the image file to disk
- **[B]** To prevent memory leaks by destroying the figure object and releasing system RAM **(Correct)**
- **[C]** To terminate the Python script immediately
- **[D]** To delete temporary image files from the cache

**Correct Answer:** Option **B** — *To prevent memory leaks by destroying the figure object and releasing system RAM*

**Explanation:** Matplotlib maintains global references to all open figures until explicitly closed. In headless environments and automated scripts, calling plt.close(fig) frees GPU/RAM memory and avoids resource leak warnings.

**Distractor Analysis:**
- **[A] (To save the image file to disk):** Saving the image is accomplished by fig.savefig(), not plt.close().
- **[C] (To terminate the Python script immediately):** plt.close() closes matplotlib figures, not the operating system shell or terminal.
- **[D] (To delete temporary image files from the cache):** plt.close() operates strictly on matplotlib's internal figure registry, leaving user variables intact.

---

## Module 04: Tree Visualization, Rule Extraction & Demo Scenarios

### Question Q4-01: What strategy is recommended for Demo Situation 1 (hours_left: 2, difficulty: 4, energy: 3, distraction: 2)?

- **Difficulty**: `Basic`
- **Related Lesson**: `lesson-02`
- **Concept Tested**: Demo Situation 1 inference and root node evaluation
- **Source Reference**: `main.py lines 61-68`

**Options:**
- **[A]** Deep focus block
- **[B]** Quick review **(Correct)**
- **[C]** Take a break first
- **[D]** Practice problems

**Correct Answer:** Option **B** — *Quick review*

**Explanation:** Demo Situation 1 features hours_left = 2, difficulty = 4, energy = 3, distraction = 2. At the root node, hours_left <= 2.50 evaluates to True, directing execution immediately to the 'Quick review' leaf node.

**Distractor Analysis:**
- **[A] (Deep focus block):** Deep focus block requires hours_left > 2.50, energy > 2.50, distraction <= 3.50, and difficulty <= 3.50.
- **[C] (Take a break first):** Take a break first requires energy <= 2.50 or distraction > 3.50 when hours_left > 2.50.
- **[D] (Practice problems):** Practice problems requires hours_left > 2.50, energy > 2.50, distraction <= 3.50, and difficulty > 3.50.

---

### Question Q4-02: What strategy is recommended for Demo Situation 2 (hours_left: 6, difficulty: 5, energy: 4, distraction: 1)?

- **Difficulty**: `Basic`
- **Related Lesson**: `lesson-02`
- **Concept Tested**: Demo Situation 2 inference and decision tree pathing
- **Source Reference**: `main.py lines 61-68`

**Options:**
- **[A]** Quick review
- **[B]** Take a break first
- **[C]** Practice problems **(Correct)**
- **[D]** Deep focus block

**Correct Answer:** Option **C** — *Practice problems*

**Explanation:** Demo Situation 2 features hours_left = 6 (> 2.50), energy = 4 (> 2.50), distraction = 1 (<= 3.50), and difficulty = 5 (> 3.50). This exact path through the decision tree lands on 'Practice problems'.

**Distractor Analysis:**
- **[A] (Quick review):** Quick review is only triggered when available hours_left <= 2.50.
- **[B] (Take a break first):** Take a break first is triggered when energy is low or distraction is high.
- **[D] (Deep focus block):** Deep focus block is selected when difficulty is low or moderate (<= 3.50); for difficulty 5, practice problems is chosen.

---

### Question Q4-03: What strategy is recommended for both Demo Situation 3 and Demo Situation 4?

- **Difficulty**: `Basic`
- **Related Lesson**: `lesson-03`
- **Concept Tested**: Demo situations 3 and 4 target class resolution
- **Source Reference**: `main.py lines 61-68`

**Options:**
- **[A]** Quick review
- **[B]** Deep focus block
- **[C]** Take a break first **(Correct)**
- **[D]** Practice problems

**Correct Answer:** Option **C** — *Take a break first*

**Explanation:** Both Demo Situation 3 (exhausted: energy = 1) and Demo Situation 4 (distracted: distraction = 5) resolve to 'Take a break first' through two distinct protective branches of the decision tree.

**Distractor Analysis:**
- **[A] (Quick review):** Quick review is only assigned when time is constrained (hours_left <= 2.50).
- **[B] (Deep focus block):** Deep focus block requires high energy and low distraction.
- **[D] (Practice problems):** Practice problems requires high energy and low distraction alongside high difficulty.

---

### Question Q4-04: Why does Demo Situation 1 output 'Quick review' even though the subject difficulty is 4 (hard)?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-02`
- **Concept Tested**: Hierarchical tree evaluation and early leaf termination
- **Source Reference**: `main.py lines 61-68`

**Options:**
- **[A]** Because the difficulty feature was dropped during model training
- **[B]** Because the root node tests hours_left <= 2.50, terminating at Quick review before difficulty is ever evaluated **(Correct)**
- **[C]** Because difficulty 4 is classified as easy by the decision tree
- **[D]** Because the student has energy level 3

**Correct Answer:** Option **B** — *Because the root node tests hours_left <= 2.50, terminating at Quick review before difficulty is ever evaluated*

**Explanation:** Decision trees evaluate splits hierarchically. When hours_left = 2 <= 2.50, the tree reaches a pure terminal leaf for 'Quick review' without ever testing difficulty, energy, or distraction.

**Distractor Analysis:**
- **[A] (Because the difficulty feature was dropped during model training):** The difficulty feature is active in the model and used for branching under hours_left > 2.50.
- **[C] (Because difficulty 4 is classified as easy by the decision tree):** Difficulty 4 is high, but the condition is bypassed due to severe time shortage.
- **[D] (Because the student has energy level 3):** Energy level 3 is not evaluated because the root node split is conclusive.

---

### Question Q4-05: What specific condition in Demo Situation 3 triggers the recommendation to take a break first?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-03`
- **Concept Tested**: Fatigue-based break leaf logic
- **Source Reference**: `main.py lines 61-68`

**Options:**
- **[A]** Distraction level is 5
- **[B]** Energy level is 1 (exhaustion), satisfying energy <= 2.50 **(Correct)**
- **[C]** The subject difficulty is too low
- **[D]** Available time is under 1 hour

**Correct Answer:** Option **B** — *Energy level is 1 (exhaustion), satisfying energy <= 2.50*

**Explanation:** Demo Situation 3 has energy = 1. After checking hours_left = 4 (> 2.50), the tree evaluates energy <= 2.50, which is True, routing directly to 'Take a break first' due to physical/mental exhaustion.

**Distractor Analysis:**
- **[A] (Distraction level is 5):** Demo Situation 3 has distraction = 2, which is low.
- **[C] (The subject difficulty is too low):** Difficulty is 3, which is moderate.
- **[D] (Available time is under 1 hour):** Available hours is 4, which is ample study time.

---

### Question Q4-06: What specific condition in Demo Situation 4 triggers the recommendation to take a break first?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-03`
- **Concept Tested**: Distraction-based break leaf logic
- **Source Reference**: `main.py lines 61-68`

**Options:**
- **[A]** Energy level is 1
- **[B]** Distraction level is 5 (chaotic environment), satisfying distraction > 3.50 **(Correct)**
- **[C]** Available hours is 0
- **[D]** Subject difficulty is 5

**Correct Answer:** Option **B** — *Distraction level is 5 (chaotic environment), satisfying distraction > 3.50*

**Explanation:** Demo Situation 4 has distraction = 5. With hours_left = 8 (> 2.50) and energy = 4 (> 2.50), the tree checks distraction <= 3.50. Because 5 > 3.50, it triggers the distraction break leaf: 'Take a break first'.

**Distractor Analysis:**
- **[A] (Energy level is 1):** Demo Situation 4 has high energy (energy = 4).
- **[C] (Available hours is 0):** Available hours is 8, which is the largest among all demo situations.
- **[D] (Subject difficulty is 5):** Subject difficulty is 2, not 5.

---

### Question Q4-07: What is the primary computational benefit of vectorized batch prediction (model.predict(demo_situations))?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-01`
- **Concept Tested**: Batch prediction performance and vectorized inference
- **Source Reference**: `main.py line 67`

**Options:**
- **[A]** It re-trains the decision tree on the demo scenarios
- **[B]** It executes inference on all input rows simultaneously in a single optimized operation **(Correct)**
- **[C]** It prevents scikit-learn from displaying console warnings
- **[D]** It automatically formats predictions as HTML tables

**Correct Answer:** Option **B** — *It executes inference on all input rows simultaneously in a single optimized operation*

**Explanation:** Vectorized batch prediction with model.predict(demo_situations) passes the entire DataFrame into compiled C routines in scikit-learn, predicting all rows simultaneously rather than calling predict in an iterative Python loop.

**Distractor Analysis:**
- **[A] (It re-trains the decision tree on the demo scenarios):** Predict does not perform any training; training is done strictly via model.fit().
- **[C] (It prevents scikit-learn from displaying console warnings):** Scikit-learn warnings depend on input feature formatting and versions, not vectorization.
- **[D] (It automatically formats predictions as HTML tables):** Predict returns a NumPy 1D array of class label strings, not an HTML table.

---

### Question Q4-08: What persistent file is created by main.py to record accuracy, ASCII rules, demo outputs, and the classification report?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-04`
- **Concept Tested**: Persisted text artifact generation
- **Source Reference**: `main.py lines 70-80`

**Options:**
- **[A]** outputs/study_tree.png
- **[B]** outputs/confusion_matrix.png
- **[C]** outputs/rules.txt **(Correct)**
- **[D]** data/study_situations.csv

**Correct Answer:** Option **C** — *outputs/rules.txt*

**Explanation:** main.py writes the evaluation summary, ASCII decision rules (export_text), and demo predictions directly to outputs/rules.txt using standard file I/O (open(..., 'w')).

**Distractor Analysis:**
- **[A] (outputs/study_tree.png):** outputs/study_tree.png is the graphical matplotlib render of the tree structure.
- **[B] (outputs/confusion_matrix.png):** outputs/confusion_matrix.png is the graphical confusion matrix plot.
- **[D] (data/study_situations.csv):** data/study_situations.csv is the read-only training/testing dataset.

---

### Question Q4-09: Why does the decision tree use two separate leaf nodes to recommend 'Take a break first' in this model?

- **Difficulty**: `Advanced`
- **Related Lesson**: `lesson-03`
- **Concept Tested**: Multi-leaf class convergence and domain logic in decision trees
- **Source Reference**: `main.py lines 52-59`

**Options:**
- **[A]** Because the decision tree was poorly trained and contains redundant branches
- **[B]** Because taking a break can be caused by two distinct logical conditions: biological exhaustion (energy <= 2.50) or environmental chaos (distraction > 3.50) **(Correct)**
- **[C]** Because max_depth was set too low
- **[D]** Because one leaf is for morning study and the other is for evening study

**Correct Answer:** Option **B** — *Because taking a break can be caused by two distinct logical conditions: biological exhaustion (energy <= 2.50) or environmental chaos (distraction > 3.50)*

**Explanation:** A decision tree can reach the same classification label through disparate independent logical pathways. In this model, fatigue (energy <= 2.50) and chaotic surroundings (distraction > 3.50) both independently mandate taking a break.

**Distractor Analysis:**
- **[A] (Because the decision tree was poorly trained and contains redundant branches):** The tree has 100% accuracy and perfectly isolates two realistic student failure modes.
- **[C] (Because max_depth was set too low):** A shallower max_depth would merge or prune necessary branches, reducing accuracy.
- **[D] (Because one leaf is for morning study and the other is for evening study):** Time of day is not a feature in the dataset.

---

### Question Q4-10: Why is a non-interactive default execution mode essential when integrating ML code into automated CI/CD pipelines?

- **Difficulty**: `Advanced`
- **Related Lesson**: `lesson-01`
- **Concept Tested**: Operational engineering and CI/CD compatibility
- **Source Reference**: `main.py lines 61-94`

**Options:**
- **[A]** Because automated CI/CD runners do not have Python installed
- **[B]** Because interactive prompt loops block execution indefinitely when no human is present to provide input, causing automated builds to hang and time out **(Correct)**
- **[C]** Because decision trees cannot make predictions in graphical terminals
- **[D]** Because CI/CD runners only support C++ scripts

**Correct Answer:** Option **B** — *Because interactive prompt loops block execution indefinitely when no human is present to provide input, causing automated builds to hang and time out*

**Explanation:** In automated CI/CD environments or scheduled container runs, standard input (stdin) is non-interactive. If a script prompts for user input, it hangs indefinitely waiting for input until the pipeline runner times out with failure.

**Distractor Analysis:**
- **[A] (Because automated CI/CD runners do not have Python installed):** CI/CD runners routinely execute Python environments.
- **[C] (Because decision trees cannot make predictions in graphical terminals):** Decision tree inference runs in any standard execution environment.
- **[D] (Because CI/CD runners only support C++ scripts):** CI/CD runners support any language including Python, Node.js, and Bash.

---

## Module 05: Interactive Mode & Input Validation

### Question Q5-01: What does sys.argv[0] always contain when executing a script via the terminal?

- **Difficulty**: `Basic`
- **Related Lesson**: `lesson-01`
- **Concept Tested**: Python sys.argv index structure
- **Source Reference**: `main.py line 13`

**Options:**
- **[A]** The first user argument passed after the script name
- **[B]** The name or path of the Python script being executed **(Correct)**
- **[C]** The exit status code of the previous command
- **[D]** The version string of the Python interpreter

**Correct Answer:** Option **B** — *The name or path of the Python script being executed*

**Explanation:** In Python, sys.argv[0] is populated by the interpreter runtime with the script filename or filepath specified in the invocation command (e.g., 'main.py').

**Distractor Analysis:**
- **[A] (The first user argument passed after the script name):** User arguments passed after the script start at index 1 (sys.argv[1]).
- **[C] (The exit status code of the previous command):** Command exit codes are inspected via $? in bash or os.system/subprocess return codes.
- **[D] (The version string of the Python interpreter):** The Python version string is stored in sys.version, not sys.argv[0].

---

### Question Q5-02: What data type is returned by Python's built-in input() function?

- **Difficulty**: `Basic`
- **Related Lesson**: `lesson-03`
- **Concept Tested**: Built-in input() return type
- **Source Reference**: `main.py line 43`

**Options:**
- **[A]** int
- **[B]** float
- **[C]** str **(Correct)**
- **[D]** bytes

**Correct Answer:** Option **C** — *str*

**Explanation:** Python's built-in input() function captures terminal standard input as a raw string (str). Even if the user types numeric digits, they must be explicitly parsed using int() or float().

**Distractor Analysis:**
- **[A] (int):** input() never returns an integer directly; explicit type casting is mandatory.
- **[B] (float):** Floating point casting requires calling float(input()).
- **[D] (bytes):** Standard terminal input is decoded to Unicode str, not binary bytes.

---

### Question Q5-03: Which expression correctly converts a dictionary of single-sample features into a 2D tabular DataFrame?

- **Difficulty**: `Basic`
- **Related Lesson**: `lesson-04`
- **Concept Tested**: Single-row DataFrame construction from dictionary
- **Source Reference**: `main.py line 53`

**Options:**
- **[A]** pd.DataFrame(values)
- **[B]** pd.DataFrame([values]) **(Correct)**
- **[C]** pd.Series(values).to_numpy()
- **[D]** pd.DataFrame.from_scalar(values)

**Correct Answer:** Option **B** — *pd.DataFrame([values])*

**Explanation:** Wrapping the dictionary in a list ([values]) creates a list of dictionaries with length 1. When passed to pd.DataFrame([values]), pandas constructs a 1-row DataFrame with dictionary keys as column names.

**Distractor Analysis:**
- **[A] (pd.DataFrame(values)):** pd.DataFrame(values) raises a ValueError when all dictionary values are scalar values without an explicit index.
- **[C] (pd.Series(values).to_numpy()):** pd.Series(values).to_numpy() creates a 1D NumPy array, which is rejected by scikit-learn models requiring 2D inputs.
- **[D] (pd.DataFrame.from_scalar(values)):** from_scalar is not a valid pandas DataFrame constructor method.

---

### Question Q5-04: Why does main.py use 'if "--interactive" in sys.argv:' instead of 'if sys.argv[1] == "--interactive":'?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-01`
- **Concept Tested**: Safe CLI argument membership testing
- **Source Reference**: `main.py line 127`

**Options:**
- **[A]** Because sys.argv is a dictionary, not a list
- **[B]** Because checking index [1] raises an IndexError if the script is run without arguments **(Correct)**
- **[C]** Because sys.argv does not support integer index slicing
- **[D]** Because the 'in' operator automatically converts command-line strings into booleans

**Correct Answer:** Option **B** — *Because checking index [1] raises an IndexError if the script is run without arguments*

**Explanation:** When a script is run without additional arguments (python main.py), sys.argv has a length of 1 containing only sys.argv[0]. Attempting to evaluate sys.argv[1] immediately triggers an IndexError: list index out of range.

**Distractor Analysis:**
- **[A] (Because sys.argv is a dictionary, not a list):** sys.argv is a standard Python list, not a dictionary.
- **[C] (Because sys.argv does not support integer index slicing):** sys.argv supports standard integer indexing and slicing.
- **[D] (Because the 'in' operator automatically converts command-line strings into booleans):** The 'in' operator checks sequence membership and returns a boolean; it does not convert command-line strings.

---

### Question Q5-05: In the declarative 4-tuple ('How many hours...', 'hours_left', 1, 10), what critical role does 'hours_left' play?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-02`
- **Concept Tested**: Declarative schema key mapping
- **Source Reference**: `main.py lines 31-36, 40-53`

**Options:**
- **[A]** It specifies the internal variable name in the terminal shell
- **[B]** It maps the collected value to the exact column name in the DataFrame matching the training FEATURES **(Correct)**
- **[C]** It sets the default fallback value if validation fails
- **[D]** It defines the target label class for supervised classification

**Correct Answer:** Option **B** — *It maps the collected value to the exact column name in the DataFrame matching the training FEATURES*

**Explanation:** The second element in each QUESTIONS tuple defines the exact key stored in the dictionary (values[key] = value), which subsequently becomes the DataFrame column name matching the training feature schema.

**Distractor Analysis:**
- **[A] (It specifies the internal variable name in the terminal shell):** Shell environment variables are isolated from internal Python dictionary keys.
- **[C] (It sets the default fallback value if validation fails):** Default values are not specified in the 4-tuple; the numbers represent min/max validation bounds.
- **[D] (It defines the target label class for supervised classification):** The target label class is 'strategy', whereas 'hours_left' is an input feature.

---

### Question Q5-06: What happens when a user types the alphabetic string 'five' into raw = input(...) and the script executes int(raw)?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-03`
- **Concept Tested**: Exception handling and type validation
- **Source Reference**: `main.py lines 44-48`

**Options:**
- **[A]** Python automatically translates English word numbers to integers (value = 5)
- **[B]** Python returns 0 without raising an error
- **[C]** Python raises a ValueError, which is intercepted by except ValueError to display a correction prompt **(Correct)**
- **[D]** The operating system terminates the Python interpreter immediately

**Correct Answer:** Option **C** — *Python raises a ValueError, which is intercepted by except ValueError to display a correction prompt*

**Explanation:** The int() function cannot convert non-digit alphabetic strings to integers, raising a ValueError. The try...except block catches this exception, prints a corrective error message, and uses continue to restart the prompt loop.

**Distractor Analysis:**
- **[A] (Python automatically translates English word numbers to integers (value = 5)):** Python standard library does not perform natural language number parsing.
- **[B] (Python returns 0 without raising an error):** int() does not fail silently or return 0 on text strings.
- **[D] (The operating system terminates the Python interpreter immediately):** Exceptions are handled within the Python process and do not cause OS-level interpreter crashes.

---

### Question Q5-07: What is the primary purpose of calling .strip() on the raw string returned by input()?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-03`
- **Concept Tested**: String sanitization with strip()
- **Source Reference**: `main.py line 43`

**Options:**
- **[A]** To convert uppercase letters to lowercase letters
- **[B]** To strip out non-ASCII Unicode characters
- **[C]** To remove leading and trailing whitespace, tabs, and newlines so accidental spaces do not cause conversion errors **(Correct)**
- **[D]** To encrypt the user's terminal input before storing it in memory

**Correct Answer:** Option **C** — *To remove leading and trailing whitespace, tabs, and newlines so accidental spaces do not cause conversion errors*

**Explanation:** .strip() removes whitespace, carriage returns, tabs, and newlines from both ends of the string. This prevents user errors caused by accidental spaces before or after valid numeric input.

**Distractor Analysis:**
- **[A] (To convert uppercase letters to lowercase letters):** Converting letter casing is performed by .lower(), not .strip().
- **[B] (To strip out non-ASCII Unicode characters):** Non-ASCII character filtering requires encoding or regex operations.
- **[D] (To encrypt the user's terminal input before storing it in memory):** String sanitization is for formatting, not cryptographic encryption.

---

### Question Q5-08: Why is the index [0] applied to the prediction output in 'plan = model.predict(situation)[0]'?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-04`
- **Concept Tested**: Vectorized inference scalar extraction
- **Source Reference**: `main.py line 130`

**Options:**
- **[A]** Because model.predict() returns a 1D NumPy array of predictions, and [0] extracts the single scalar string **(Correct)**
- **[B]** Because index 0 contains the model accuracy score
- **[C]** Because decision trees only output predictions if index 0 is requested
- **[D]** To sort the predictions in ascending alphabetical order

**Correct Answer:** Option **A** — *Because model.predict() returns a 1D NumPy array of predictions, and [0] extracts the single scalar string*

**Explanation:** Scikit-learn's predict() method is designed for batch processing and consistently returns a 1D NumPy ndarray. Unpacking index [0] retrieves the single predicted string label so it can be formatted cleanly in user output.

**Distractor Analysis:**
- **[B] (Because index 0 contains the model accuracy score):** Model accuracy is evaluated using accuracy_score(y_test, predictions), not predict()[0].
- **[C] (Because decision trees only output predictions if index 0 is requested):** Decision trees output predictions regardless of indexing; the index is strictly for scalar extraction.
- **[D] (To sort the predictions in ascending alphabetical order):** Predict does not sort classes; it returns predictions aligned with input rows.

---

### Question Q5-09: What operational failure occurs when an automated CI/CD pipeline or cron job executes a script that pauses on an unconditional input() call?

- **Difficulty**: `Advanced`
- **Related Lesson**: `lesson-01`
- **Concept Tested**: Operational engineering and CI/CD non-blocking design
- **Source Reference**: `main.py lines 127-135`

**Options:**
- **[A]** The CI/CD runner automatically inputs random numbers to complete the job
- **[B]** The non-interactive environment hangs indefinitely waiting for human input until the pipeline times out and fails **(Correct)**
- **[C]** The script bypasses the input call and assigns None to all variables
- **[D]** The scikit-learn model retrains automatically using synthetic test data

**Correct Answer:** Option **B** — *The non-interactive environment hangs indefinitely waiting for human input until the pipeline times out and fails*

**Explanation:** In automated execution environments (e.g., CI/CD, scheduled jobs, Docker containers), standard input is disconnected or non-interactive. Unconditional input() prompts cause the runner process to block indefinitely until an execution timeout is reached.

**Distractor Analysis:**
- **[A] (The CI/CD runner automatically inputs random numbers to complete the job):** CI/CD runners do not fabricate fake input unless explicitly configured with mock streams.
- **[C] (The script bypasses the input call and assigns None to all variables):** Python will not skip input(); it halts waiting for data or raises EOFError.
- **[D] (The scikit-learn model retrains automatically using synthetic test data):** Retraining requires explicit programmatic execution.

---

### Question Q5-10: If a developer modifies QUESTIONS to include a new feature key not present in the training FEATURES list, what happens when model.predict() is called?

- **Difficulty**: `Advanced`
- **Related Lesson**: `lesson-04`
- **Concept Tested**: Model feature schema consistency
- **Source Reference**: `main.py lines 58, 66, 130`

**Options:**
- **[A]** The model automatically updates its tree structure to include the new feature
- **[B]** The model silently drops the unrecognized column and makes an arbitrary guess
- **[C]** Scikit-learn raises a ValueError regarding unexpected or mismatching feature names **(Correct)**
- **[D]** The Python interpreter produces a segmentation fault

**Correct Answer:** Option **C** — *Scikit-learn raises a ValueError regarding unexpected or mismatching feature names*

**Explanation:** Scikit-learn validates input DataFrame feature names against the features seen during fit(). Passing unseen columns or omitting required columns causes a ValueError: The feature names should match those that were passed during fit.

**Distractor Analysis:**
- **[A] (The model automatically updates its tree structure to include the new feature):** Trained decision trees have fixed topologies and cannot dynamically adjust features without retraining.
- **[B] (The model silently drops the unrecognized column and makes an arbitrary guess):** Scikit-learn strictly enforces schema integrity and does not silently drop columns.
- **[D] (The Python interpreter produces a segmentation fault):** Python manages schema mismatches via high-level exceptions rather than memory segmentation faults.

---

## Module 06: Evaluation, Running Both Modes & Explainable AI

### Question Q6-01: What overall test accuracy does the DecisionTreeClassifier achieve on the 30-sample holdout test set in main.py?

- **Difficulty**: `Basic`
- **Related Lesson**: `lesson-01`
- **Concept Tested**: Model test accuracy evaluation
- **Source Reference**: `main.py lines 68, 73`

**Options:**
- **[A]** 75.0%
- **[B]** 85.5%
- **[C]** 92.3%
- **[D]** 100.0% **(Correct)**

**Correct Answer:** Option **D** — *100.0%*

**Explanation:** On the 30-sample stratified holdout test set, the DecisionTreeClassifier achieves an accuracy of 1.0 (100.0%), correctly classifying all 30 test scenarios across all 4 strategy classes.

**Distractor Analysis:**
- **[A] (75.0%):** 75.0% corresponds to the proportion of data in the training split, not model accuracy.
- **[B] (85.5%):** 85.5% is an arbitrary distractor; the model achieves perfect classification.
- **[C] (92.3%):** 92.3% is an arbitrary distractor; the model achieves perfect classification.

---

### Question Q6-02: In a multi-class confusion matrix, what do values lying along the main diagonal (top-left to bottom-right) represent?

- **Difficulty**: `Basic`
- **Related Lesson**: `lesson-02`
- **Concept Tested**: Confusion matrix diagonal interpretation
- **Source Reference**: `main.py lines 107-115`

**Options:**
- **[A]** Misclassifications where the model guessed incorrectly
- **[B]** True Positives (correct classifications where predicted class equals actual class) **(Correct)**
- **[C]** The number of missing values imputed during training
- **[D]** The Gini impurity scores for each terminal leaf

**Correct Answer:** Option **B** — *True Positives (correct classifications where predicted class equals actual class)*

**Explanation:** In a confusion matrix, the main diagonal represents cases where Actual Class == Predicted Class (True Positives). Off-diagonal cells represent misclassifications.

**Distractor Analysis:**
- **[A] (Misclassifications where the model guessed incorrectly):** Misclassifications appear in the off-diagonal cells of the matrix.
- **[C] (The number of missing values imputed during training):** The dataset contains zero missing values and no imputation was performed.
- **[D] (The Gini impurity scores for each terminal leaf):** Gini impurity is a node splitting criterion, not a cell value in a confusion matrix.

---

### Question Q6-03: Which matplotlib colormap is passed to ConfusionMatrixDisplay in main.py to shade cell intensities?

- **Difficulty**: `Basic`
- **Related Lesson**: `lesson-02`
- **Concept Tested**: Matplotlib colormap styling in scikit-learn
- **Source Reference**: `main.py line 111`

**Options:**
- **[A]** viridis
- **[B]** Purples **(Correct)**
- **[C]** hot
- **[D]** plasma

**Correct Answer:** Option **B** — *Purples*

**Explanation:** main.py explicitly configures cmap='Purples' inside ConfusionMatrixDisplay.plot(), creating a sequential purple heatmap where darker shades indicate higher sample counts.

**Distractor Analysis:**
- **[A] (viridis):** viridis is the default multi-color sequential colormap in matplotlib, but was overridden by Purples.
- **[C] (hot):** hot is a black-red-yellow colormap commonly used in thermal imaging.
- **[D] (plasma):** plasma is a perceptually uniform colormap, but Purples was specified.

---

### Question Q6-04: What does 'precision' measure when evaluating a specific recommendation strategy like 'Deep focus block'?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-01`
- **Concept Tested**: Precision vs recall definitions
- **Source Reference**: `main.py line 74`

**Options:**
- **[A]** The percentage of all actual deep focus situations that the model successfully detected
- **[B]** The percentage of times the model's prediction of deep focus was actually correct **(Correct)**
- **[C]** The time in milliseconds taken to compute the leaf node prediction
- **[D]** The depth of the tree branch leading to that leaf

**Correct Answer:** Option **B** — *The percentage of times the model's prediction of deep focus was actually correct*

**Explanation:** Precision evaluates exactness: out of all instances predicted as a class, what fraction actually belonged to that class? TP / (TP + FP). Recall measures completeness: TP / (TP + FN).

**Distractor Analysis:**
- **[A] (The percentage of all actual deep focus situations that the model successfully detected):** Measuring all actual situations that were detected is the definition of recall (sensitivity).
- **[C] (The time in milliseconds taken to compute the leaf node prediction):** Inference latency is measured using system clocks, not precision.
- **[D] (The depth of the tree branch leading to that leaf):** Tree branch depth measures structural complexity, not predictive precision.

---

### Question Q6-05: What is the technical purpose of passing 'zero_division=0' to classification_report()?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-01`
- **Concept Tested**: Classification report zero_division parameter
- **Source Reference**: `main.py lines 74, 123`

**Options:**
- **[A]** It removes classes that have zero training samples
- **[B]** It forces accuracy to be zero if any errors occur
- **[C]** It sets precision and recall to 0.0 instead of throwing warnings or returning NaN when a class receives zero predictions **(Correct)**
- **[D]** It divides continuous features by standard deviation

**Correct Answer:** Option **C** — *It sets precision and recall to 0.0 instead of throwing warnings or returning NaN when a class receives zero predictions*

**Explanation:** When a model makes zero predictions for a class, the precision denominator (TP + FP) is 0. Setting zero_division=0 forces precision to evaluate to 0.0 rather than raising runtime warnings or producing NaN values.

**Distractor Analysis:**
- **[A] (It removes classes that have zero training samples):** Classes with zero samples are unaffected; zero_division handles zero predictions in the denominator.
- **[B] (It forces accuracy to be zero if any errors occur):** Overall accuracy is computed from total correct predictions and is not forced to zero.
- **[D] (It divides continuous features by standard deviation):** Standard deviation scaling is done via StandardScaler, not metric parameters.

---

### Question Q6-06: In scikit-learn's classification_report, what does the 'support' column represent?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-01`
- **Concept Tested**: Classification report support interpretation
- **Source Reference**: `main.py line 74`

**Options:**
- **[A]** The number of trees in an ensemble model
- **[B]** The actual ground-truth sample count for each class in the test dataset **(Correct)**
- **[C]** The confidence score threshold for making a prediction
- **[D]** The CPU core count allocated for parallel inference

**Correct Answer:** Option **B** — *The actual ground-truth sample count for each class in the test dataset*

**Explanation:** In scikit-learn's classification_report, support is the true count of ground-truth instances belonging to each target class within the evaluated test set.

**Distractor Analysis:**
- **[A] (The number of trees in an ensemble model):** Ensemble tree counts are set via n_estimators in ensemble models like RandomForestClassifier.
- **[C] (The confidence score threshold for making a prediction):** Confidence thresholds are used in probabilistic binary classification (e.g., predict_proba > threshold).
- **[D] (The CPU core count allocated for parallel inference):** CPU cores are configured via n_jobs in scikit-learn estimators.

---

### Question Q6-07: How does macro average differ from weighted average in a classification report?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-01`
- **Concept Tested**: Macro vs weighted averaging
- **Source Reference**: `main.py line 74`

**Options:**
- **[A]** Macro average treats every class equally regardless of size, while weighted average weights each class by its support **(Correct)**
- **[B]** Macro average is only used for binary classification, while weighted average is used for multi-class
- **[C]** Macro average computes the median, while weighted average computes the mode
- **[D]** Macro average divides by total features, while weighted average divides by tree depth

**Correct Answer:** Option **A** — *Macro average treats every class equally regardless of size, while weighted average weights each class by its support*

**Explanation:** Macro average calculates the simple unweighted arithmetic mean across all classes. Weighted average scales each class's score by its proportion of support in the test set.

**Distractor Analysis:**
- **[B] (Macro average is only used for binary classification, while weighted average is used for multi-class):** Both macro and weighted averages apply to multi-class classification.
- **[C] (Macro average computes the median, while weighted average computes the mode):** Both metrics compute means (averages), not medians or modes.
- **[D] (Macro average divides by total features, while weighted average divides by tree depth):** Averaging operates on per-class metric scores, not feature counts or tree depth.

---

### Question Q6-08: Which three persistent artifacts are generated in the outputs/ directory upon running main.py?

- **Difficulty**: `Intermediate`
- **Related Lesson**: `lesson-03`
- **Concept Tested**: Generated output artifact verification
- **Source Reference**: `main.py lines 104, 114, 117-125`

**Options:**
- **[A]** model.pkl, weights.h5, architecture.json
- **[B]** study_tree.png, confusion_matrix.png, rules.txt **(Correct)**
- **[C]** dataset.csv, summary.html, log.txt
- **[D]** tree_diagram.svg, matrix.pdf, answers.md

**Correct Answer:** Option **B** — *study_tree.png, confusion_matrix.png, rules.txt*

**Explanation:** main.py generates and persists three distinct artifacts in the outputs/ directory: study_tree.png (tree visualization), confusion_matrix.png (confusion matrix plot), and rules.txt (evaluation report and ASCII rules).

**Distractor Analysis:**
- **[A] (model.pkl, weights.h5, architecture.json):** Serialized pickle or HDF5 model weights are not exported by main.py.
- **[C] (dataset.csv, summary.html, log.txt):** The dataset resides in data/study_situations.csv and HTML summaries are not generated.
- **[D] (tree_diagram.svg, matrix.pdf, answers.md):** SVG and PDF vector formats are not generated; main.py saves PNG and TXT files.

---

### Question Q6-09: Why is a shallow DecisionTreeClassifier considered a 'glass box' model in Explainable AI (XAI)?

- **Difficulty**: `Advanced`
- **Related Lesson**: `lesson-04`
- **Concept Tested**: Glass box vs black box models in Explainable AI
- **Source Reference**: `main.py lines 7-8, 75-76`

**Options:**
- **[A]** Because its code is proprietary and closed-source
- **[B]** Because every decision path can be audited as an exact, human-readable Boolean rule from root to leaf **(Correct)**
- **[C]** Because it requires transparent GPU hardware to run
- **[D]** Because it can only process visual image data

**Correct Answer:** Option **B** — *Because every decision path can be audited as an exact, human-readable Boolean rule from root to leaf*

**Explanation:** A shallow decision tree is a classic glass box model because its internal logic is completely transparent, deterministic, and can be inspected as a sequence of simple IF-THEN Boolean rules.

**Distractor Analysis:**
- **[A] (Because its code is proprietary and closed-source):** Proprietary, closed-source models are often black boxes; the decision tree code is open-source.
- **[C] (Because it requires transparent GPU hardware to run):** Glass box refers to algorithmic interpretability, not transparent computer hardware.
- **[D] (Because it can only process visual image data):** Decision trees routinely operate on tabular numerical and categorical data.

---

### Question Q6-10: What is the primary pedagogical rationale for encouraging students to 'question the rules' of an educational AI model?

- **Difficulty**: `Advanced`
- **Related Lesson**: `lesson-04`
- **Concept Tested**: Educational philosophy of Explainable AI
- **Source Reference**: `main.py lines 7-8, 134`

**Options:**
- **[A]** To find software bugs and crash the Python interpreter
- **[B]** To develop student metacognition, critical thinking, and algorithmic literacy rather than treating AI advice as infallible **(Correct)**
- **[C]** To circumvent school academic honesty honor codes
- **[D]** To increase the training loss of the decision tree

**Correct Answer:** Option **B** — *To develop student metacognition, critical thinking, and algorithmic literacy rather than treating AI advice as infallible*

**Explanation:** The core educational philosophy of Study Buddy is that students should develop critical agency and metacognition. Transparent rules allow students to understand why advice is given and question whether their self-assessment accurately reflects their state.

**Distractor Analysis:**
- **[A] (To find software bugs and crash the Python interpreter):** The goal of transparency is educational empowerment, not finding software bugs to crash systems.
- **[C] (To circumvent school academic honesty honor codes):** Study Buddy is a study habit advisor, unrelated to bypassing academic integrity policies.
- **[D] (To increase the training loss of the decision tree):** Training loss is an internal optimization metric computed during model fitting.

---
