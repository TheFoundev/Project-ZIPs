# Architecture

## Pipeline (from main.py)
1. **Environment & Headless Configuration**: Sets `matplotlib.use("Agg")` prior to importing `pyplot` to enable reliable headless plot rendering in all terminal and containerized environments.
2. **Path Setup**: Defines `BASE`, `DATA`, and `OUT` using `pathlib.Path(__file__).resolve().parent`, guaranteeing environment-independent relative path resolution, and creates `outputs/` with `mkdir(exist_ok=True)`.
3. **Configuration & Data Definitions**:
   - `FEATURES = ["hours_left", "difficulty", "energy", "distraction"]`
   - `QUESTIONS`: List of 4-tuples defining `(question_prompt, feature_key, min_bound, max_bound)` for interactive Q&A.
4. **Data Ingestion**: Loads 120 historical study scenarios from `data/study_situations.csv` via `pd.read_csv()`.
5. **Feature & Target Matrix**:
   - $X$: 2D DataFrame subset `df[FEATURES]` of shape `(120, 4)`.
   - $y$: 1D Series `df["strategy"]` of length 120.
6. **Stratified Splitting**: Splits $X$ and $y$ using `train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)`, generating 90 training samples and 30 testing samples with balanced class proportions.
7. **Model Training**: Trains `DecisionTreeClassifier(max_depth=4, random_state=42)` on `X_train` and `y_train`.
8. **Evaluation**:
   - Predicts on `X_test`.
   - Calculates test accuracy via `accuracy_score(y_test, predictions)`.
   - Generates full precision, recall, and f1-score metrics via `classification_report(y_test, predictions, zero_division=0)`.
9. **Rule Synthesis**: Calls `export_text(model, feature_names=FEATURES)` to construct human-readable hierarchical if/then decision rules.
10. **Demo Scenario Inference**: Runs the model against 4 predefined benchmark situations representing varied student constraints.
11. **Visual Plotting**:
    - Flowchart visualization rendered with `plot_tree()` and saved to `outputs/study_tree.png`.
    - Multi-class error analysis plot rendered with `ConfusionMatrixDisplay` (using the `"Purples"` colormap) and saved to `outputs/confusion_matrix.png`.
12. **Persistence**: Writes accuracy, ASCII rules, demo outputs, and the classification report to `outputs/rules.txt`.
13. **CLI Execution Routing**: Inspects `sys.argv` for the presence of `"--interactive"`:
    - If present, invokes `ask_situation()` for live user input and prints the suggested study plan.
    - If absent, prints helpful instructions and an extension challenge.

## Key Components
- **Data Engine**: Tabular CSV storage holding 120 curated study profiles with constrained integer features.
- **Explainable Model**: scikit-learn `DecisionTreeClassifier` with depth limited to 4 levels, ensuring complete inspectability.
- **Rule Engine**: Textual rule extraction and graphical tree plotting revealing exact split thresholds (`2.50`, `3.50`).
- **Validation Engine**: Robust terminal loop ensuring all interactive inputs are valid integers within designated bounds.
- **Reporting Engine**: Matplotlib and text-based exporters providing complete verification records.

## Data Flow
```
study_situations.csv
        │
        ▼
   pd.read_csv()
        │
        ├─────────────────────────────┐
        ▼                             ▼
Feature Matrix X (120, 4)       Target Vector y (120,)
        │                             │
        └──────────────┬──────────────┘
                       ▼
             train_test_split()
             (stratify=y, test=0.25)
                       │
         ┌─────────────┴─────────────┐
         ▼                           ▼
Training Set (90, 4)          Test Set (30, 4)
         │                           │
         ▼                           │
 DecisionTreeClassifier.fit()        │
         │                           │
         ├───────────────────────────┤
         ▼                           ▼
  Trained Decision Tree ────► model.predict(X_test)
         │                           │
         │                           ▼
         │                 accuracy_score &
         │               classification_report
         │                           │
         ├───────────────────────────┼───────────────────────────┐
         ▼                           ▼                           ▼
export_text() & plot_tree()   confusion_matrix()           Demo & CLI Inference
         │                           │                           │
         ▼                           ▼                           ▼
  study_tree.png             confusion_matrix.png            rules.txt &
                                                           Console Output
```
