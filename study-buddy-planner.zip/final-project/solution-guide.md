# Mentor Solution Guide: The Study Buddy Planner

## Overview
This guide provides instructional mentors and evaluators with a thorough walkthrough of the reference implementation for **The Study Buddy Planner**. The project demonstrates how decision tree classifiers act as transparent, auditable recommendation systems in applied settings.

Mentors should evaluate student submissions against the modular checkpoints below, verifying that students understand not only how to write the code, but why specific architectural decisions (such as stratified sampling, tree depth constraints, headless plotting backends, and defensive input loops) were chosen.

## Solution Checkpoints & Code Walkthrough

### Checkpoint 1: Headless Backend and Imports (lines 11-23)
```python
from __future__ import annotations

import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, export_text, plot_tree
```
**Mentor Verification Points:**
- `matplotlib.use("Agg")` must appear immediately after `import matplotlib` and *before* importing `matplotlib.pyplot`. If placed after, a backend conflict warning may trigger or the script may fail in headless server/CI environments.
- All imports should use the standard modern scientific libraries without unnecessary bloat.

### Checkpoint 2: Path Resolution & Constants (lines 25-36)
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)

FEATURES = ["hours_left", "difficulty", "energy", "distraction"]
QUESTIONS = [
    ("How many hours do you have left? (1-10) ", "hours_left", 1, 10),
    ("How difficult is the subject? (1-5) ", "difficulty", 1, 5),
    ("How much energy do you have? (1-5) ", "energy", 1, 5),
    ("How distracted do you feel? (1-5) ", "distraction", 1, 5),
]
```
**Mentor Verification Points:**
- Paths are resolved dynamically relative to `__file__`, ensuring the script can be invoked from any working directory.
- `OUT.mkdir(exist_ok=True)` avoids `FileExistsError` on repeated runs.
- `QUESTIONS` cleanly decouples the CLI user prompt, the feature column key, and valid range boundaries `[low, high]`.

### Checkpoint 3: Defensive CLI Input Validation (`ask_situation`) (lines 39-53)
```python
def ask_situation() -> pd.DataFrame:
    values = {}
    for question, key, low, high in QUESTIONS:
        while True:
            raw = input(question).strip()
            try:
                value = int(raw)
            except ValueError:
                print(f"Please enter a whole number from {low} to {high}.")
                continue
            if low <= value <= high:
                values[key] = value
                break
            print(f"Please enter a number from {low} to {high}.")
    return pd.DataFrame([values])
```
**Mentor Verification Points:**
- Trailing and leading whitespace is stripped with `.strip()`.
- Non-integer input (e.g., text, float strings) is trapped by `try...except ValueError` and prompts the user again without crashing.
- Range bounds are checked with chained comparisons (`low <= value <= high`).
- Returns a DataFrame with a single row (`pd.DataFrame([values])`) whose columns match `FEATURES`.

### Checkpoint 4: Data Ingestion and Stratified Splitting (lines 57-63)
```python
df = pd.read_csv(DATA / "study_situations.csv")
X = df[FEATURES]
y = df["strategy"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)
```
**Mentor Verification Points:**
- `X` is a 2D DataFrame (subsetting with list of feature names), `y` is a 1D Series.
- `stratify=y` is critical: because class counts are unbalanced (56 `Take a break first`, 12 `Practice problems`), stratified sampling guarantees that both training (90 rows) and test (30 rows) subsets receive identical class proportions.
- `random_state=42` guarantees reproducibility.

### Checkpoint 5: Model Training and Evaluation (lines 65-76)
```python
model = DecisionTreeClassifier(max_depth=4, random_state=42)
model.fit(X_train, y_train)
predictions = model.predict(X_test)
accuracy = accuracy_score(y_test, predictions)

print("=" * 60)
print("THE STUDY BUDDY PLANNER")
print("=" * 60)
print(f"Accuracy: {accuracy:.1%}\n")
print(classification_report(y_test, predictions, zero_division=0))
print("Learned rules:\n")
print(export_text(model, feature_names=FEATURES))
```
**Mentor Verification Points:**
- `max_depth=4` bounds tree depth to avoid memorization and ensure readability.
- `classification_report` uses `zero_division=0` to prevent division-by-zero warnings.
- `export_text()` prints the learned tree logic in ASCII format, demonstrating explainable AI.

### Checkpoint 6: Demo Scenarios Inference (lines 78-90)
```python
demo_situations = pd.DataFrame(
    [
        {"hours_left": 2, "difficulty": 4, "energy": 3, "distraction": 2},
        {"hours_left": 6, "difficulty": 5, "energy": 4, "distraction": 1},
        {"hours_left": 4, "difficulty": 3, "energy": 1, "distraction": 2},
        {"hours_left": 8, "difficulty": 2, "energy": 4, "distraction": 5},
    ]
)
demo_predictions = model.predict(demo_situations)
print("Demo plans:")
for situation, plan in zip(demo_situations.to_dict("records"), demo_predictions):
    print(f"  {situation} -> {plan}")
```
**Mentor Verification Points:**
- Demonstrates batch inference with a constructed DataFrame.
- Predicted demo plans should match:
  1. `hours_left: 2 ...` -> `Quick review`
  2. `hours_left: 6, difficulty: 5, energy: 4, distraction: 1` -> `Practice problems`
  3. `hours_left: 4, energy: 1 ...` -> `Take a break first`
  4. `hours_left: 8, distraction: 5 ...` -> `Take a break first`

### Checkpoint 7: Tree Visualization with `plot_tree` (lines 92-105)
```python
fig, ax = plt.subplots(figsize=(16, 8))
plot_tree(
    model,
    feature_names=FEATURES,
    class_names=list(model.classes_),
    filled=True,
    rounded=True,
    fontsize=8,
    ax=ax,
)
ax.set_title("The Study Buddy decision tree")
fig.tight_layout()
fig.savefig(OUT / "study_tree.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```
**Mentor Verification Points:**
- Large figure size `(16, 8)` ensures node text is readable.
- `filled=True` shades nodes by majority class; `rounded=True` rounds box corners.
- `plt.close(fig)` frees system memory.

### Checkpoint 8: Confusion Matrix and File Logging (lines 107-125)
```python
labels = sorted(df["strategy"].unique())
cm = confusion_matrix(y_test, predictions, labels=labels)
fig, ax = plt.subplots(figsize=(7, 5.5))
ConfusionMatrixDisplay(cm, display_labels=labels).plot(ax=ax, cmap="Purples", colorbar=False)
ax.set_title("Study strategy predictions")
fig.tight_layout()
fig.savefig(OUT / "confusion_matrix.png", dpi=150, bbox_inches="tight")
plt.close(fig)

with open(OUT / "rules.txt", "w", encoding="utf-8") as handle:
    handle.write(f"accuracy: {accuracy:.4f}\n\n")
    handle.write(export_text(model, feature_names=FEATURES))
    handle.write("\ndemo plans:\n")
    for situation, plan in zip(demo_situations.to_dict("records"), demo_predictions):
        handle.write(f"{situation} -> {plan}\n")
    handle.write("\n" + classification_report(y_test, predictions, zero_division=0))
```
**Mentor Verification Points:**
- `labels` sorted explicitly so matrix row/column order is deterministic.
- `"Purples"` colormap used cleanly without redundant colorbars.
- `rules.txt` written with UTF-8 encoding.

### Checkpoint 9: CLI Argument Routing (lines 127-135)
```python
if "--interactive" in sys.argv:
    print("\nAnswer four questions and the planner will suggest a strategy.\n")
    situation = ask_situation()
    plan = model.predict(situation)[0]
    print(f"\nSuggested strategy: {plan}")
else:
    print("Run `python main.py --interactive` to get a personal plan.")
    print("Try this: add a 'deadline soon' feature and retrain.")
```
**Mentor Verification Points:**
- `"--interactive" in sys.argv` correctly checks for CLI flags without requiring external argument parsing libraries.
- Predicts and prints the single-sample string output cleanly.

## Common Student Mistakes & Guidance
1. **Missing `stratify=y`**: If students omit `stratify=y`, the random split might severely under-represent `Practice problems` in the test set (which has only 12 instances total), leading to unstable metric reports.
2. **Interactive Crash on Invalid Input**: Students often use `int(input(...))` directly without a `try...except` block, causing `ValueError` crashes if a user enters a character or blank string. Guide them to inspect `ask_situation()`.
3. **Overplotting in `plot_tree`**: Small figure sizes (e.g., `(6, 4)`) render `plot_tree` unreadable. Emphasize using `figsize=(16, 8)` and `fontsize=8`.
4. **Failure to Call `plt.close(fig)`**: Leaving figures open causes matplotlib to accumulate memory across repeated invocations.
