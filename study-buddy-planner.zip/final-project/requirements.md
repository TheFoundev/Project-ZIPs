# Final Project Requirements: The Study Buddy Planner

## Project Objective
Implement the complete Study Buddy Planner from scratch, strictly adhering to the architecture, logic, and output standards demonstrated in `main.py` of `beginner-projects-main/AI-ML Beginners/projects/20_study_buddy_planner/`.

Your solution must load `data/study_situations.csv`, separate features and multi-class target labels, perform a stratified train/test split, train a `DecisionTreeClassifier` with `max_depth=4`, extract human-readable text rules, evaluate 4 preset demo scenarios, render graphical tree and confusion matrix plots, write outputs to `outputs/rules.txt`, and provide an interactive CLI mode with robust input validation when executed with `--interactive`.

## Functional Requirements

### 1. Environment & Path Setup
- Ensure `matplotlib.use("Agg")` is invoked before importing `matplotlib.pyplot` to guarantee headless operation without GUI popups.
- Import `sys`, `Path` from `pathlib`, `matplotlib.pyplot`, `pandas`, and required `scikit-learn` utilities (`accuracy_score`, `classification_report`, `ConfusionMatrixDisplay`, `confusion_matrix`, `train_test_split`, `DecisionTreeClassifier`, `export_text`, `plot_tree`).
- Define base and output paths dynamically via `Path(__file__).resolve().parent`.
- Create the `outputs/` directory automatically using `OUT.mkdir(exist_ok=True)`.

### 2. Constants & Data Schema
- Define the feature list constant: `FEATURES = ["hours_left", "difficulty", "energy", "distraction"]`.
- Define the interactive questions configuration list `QUESTIONS` containing tuples:
  - `("How many hours do you have left? (1-10) ", "hours_left", 1, 10)`
  - `("How difficult is the subject? (1-5) ", "difficulty", 1, 5)`
  - `("How much energy do you have? (1-5) ", "energy", 1, 5)`
  - `("How distracted do you feel? (1-5) ", "distraction", 1, 5)`

### 3. Data Ingestion & Partitioning
- Ingest `data/study_situations.csv` using `pd.read_csv()`.
- Extract feature matrix $X$ using `df[FEATURES]` and target vector $y$ using `df["strategy"]`.
- Perform a stratified 75/25 split using `train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)`.
- Confirm training set has 90 samples and test set has 30 samples.

### 4. Model Training & Evaluation
- Instantiate `DecisionTreeClassifier(max_depth=4, random_state=42)`.
- Train the model strictly on `X_train` and `y_train`.
- Generate test predictions on `X_test`.
- Compute test accuracy using `accuracy_score(y_test, predictions)`.
- Generate the full multi-class classification report with `zero_division=0`.
- Format and display accuracy as a percentage (`{accuracy:.1%}`).

### 5. Rule Extraction & Demo Scenarios
- Generate human-readable ASCII decision rules using `export_text(model, feature_names=FEATURES)`.
- Create a DataFrame containing the 4 benchmark demo situations:
  1. `hours_left: 2, difficulty: 4, energy: 3, distraction: 2`
  2. `hours_left: 6, difficulty: 5, energy: 4, distraction: 1`
  3. `hours_left: 4, difficulty: 3, energy: 1, distraction: 2`
  4. `hours_left: 8, difficulty: 2, energy: 4, distraction: 5`
- Generate batch predictions for all 4 demo situations and print each input dictionary mapped to its recommended strategy.

### 6. Visual Artifact Generation
- **Decision Tree Diagram**:
  - Render tree flowchart with `plot_tree(model, feature_names=FEATURES, class_names=list(model.classes_), filled=True, rounded=True, fontsize=8, ax=ax)`.
  - Set figure size to `(16, 8)` and title to `"The Study Buddy decision tree"`.
  - Save to `outputs/study_tree.png` with `dpi=150` and `bbox_inches="tight"`.
- **Confusion Matrix Diagram**:
  - Compute confusion matrix with `confusion_matrix(y_test, predictions, labels=labels)`.
  - Render using `ConfusionMatrixDisplay(cm, display_labels=labels).plot(ax=ax, cmap="Purples", colorbar=False)`.
  - Set figure size to `(7, 5.5)` and title to `"Study strategy predictions"`.
  - Save to `outputs/confusion_matrix.png` with `dpi=150` and `bbox_inches="tight"`.

### 7. File Persistence
- Write summary audit to `outputs/rules.txt` using `encoding="utf-8"`.
- Include accuracy formatted to 4 decimal places (`accuracy: {accuracy:.4f}`).
- Include ASCII rules from `export_text()`.
- Include demo situation mappings.
- Include the complete classification report.

### 8. Interactive CLI & Input Validation
- Implement `ask_situation() -> pd.DataFrame` which iterates through `QUESTIONS`.
- Employ a `while True` loop with `try...except ValueError` to catch non-integer input.
- Enforce lower and upper numeric boundaries (`low <= value <= high`).
- Return a single-row pandas DataFrame containing user answers.
- When `"--interactive" in sys.argv`:
  - Prompt the user through `ask_situation()`.
  - Predict the recommendation using `model.predict(situation)[0]`.
  - Print `"Suggested strategy: {plan}"`.
- When `"--interactive"` is not passed:
  - Print the hint to run `python main.py --interactive`.
  - Print the challenge suggestion: `"Try this: add a 'deadline soon' feature and retrain."`.

## Non-Functional Requirements
- **Reproducibility**: Set `random_state=42` in both `train_test_split` and `DecisionTreeClassifier`.
- **Code Style & Structure**: Enforce type hints (`-> None`, `-> pd.DataFrame`) and clear modular design.
- **Resource Management**: Explicitly close all matplotlib figures with `plt.close(fig)` to avoid memory leaks.
