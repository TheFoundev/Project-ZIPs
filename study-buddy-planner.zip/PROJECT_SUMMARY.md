# The Study Buddy Planner — Project Summary

## Executive Summary
The Study Buddy Planner is an applied educational machine learning project demonstrating how transparent decision trees function as explainable recommendation engines. While many recommendation systems rely on opaque matrix factorization or deep neural networks, this project uses `DecisionTreeClassifier` with `max_depth=4` to learn inspectable, human-auditable rules from student study scenarios.

The project demonstrates end-to-end machine learning engineering: data ingestion, stratified sampling, model fitting, metric computation, ASCII rule extraction, graphical plotting with `matplotlib`, dual-mode CLI handling (scripted vs interactive), and robust input sanitization.

## Core Problem Statement
Students struggle to select appropriate study strategies when balancing fluctuating energy levels, looming deadlines, ambient distractions, and varying subject difficulties. Choosing the wrong strategy—such as forcing a 4-hour deep focus session when exhausted and distracted—leads to frustration, procrastination, and inefficient learning.

The Study Buddy Planner solves this by mapping student constraints to one of four evidence-based study strategies:
1. **Quick review**: Short, low-pressure revision suited for tight timelines.
2. **Take a break first**: Cognitive rest or reset when energy is depleted or distractions are too high.
3. **Deep focus block**: Sustained conceptual work for moderate-to-high energy, low-to-moderate distraction, and manageable subject difficulty.
4. **Practice problems**: Hands-on active recall and problem sets when dealing with challenging material under solid focus.

## Dataset Profile
- **File**: `data/study_situations.csv`
- **Total Records**: 120 situations
- **Feature Dimensions**: 4 numeric features
  - `hours_left`: Continuous/discrete integer scale from 1 to 10 (available study time).
  - `difficulty`: Integer rating from 1 (very easy) to 5 (extremely hard).
  - `energy`: Integer rating from 1 (exhausted) to 5 (fully energized).
  - `distraction`: Integer rating from 1 (silent/focused) to 5 (highly chaotic/distracted).
- **Target Label**: `strategy` (4 discrete categorical classes)
  - `Take a break first` (56 total samples in dataset, 14 in test set)
  - `Deep focus block` (32 total samples in dataset, 8 in test set)
  - `Quick review` (20 total samples in dataset, 5 in test set)
  - `Practice problems` (12 total samples in dataset, 3 in test set)

## Model Configuration & Performance
- **Algorithm**: `sklearn.tree.DecisionTreeClassifier`
- **Hyperparameters**: `max_depth=4`, `random_state=42`
- **Partitioning**: 75% training (90 rows), 25% test (30 rows), stratified by target classes (`stratify=y`)
- **Evaluation Metrics**:
  - Test Accuracy: 100.0%
  - Precision / Recall / F1-Score: 1.00 across all four classes
- **Learned Rules Hierarchy**:
  - **Threshold 1 (`hours_left <= 2.50`)**: If less than or equal to 2 hours remaining, recommend **Quick review**.
  - **Threshold 2 (`hours_left > 2.50`, `energy <= 2.50`)**: If time is ample but energy is 1 or 2, recommend **Take a break first**.
  - **Threshold 3 (`energy > 2.50`, `distraction > 3.50`)**: If energy is sufficient but distraction is 4 or 5, recommend **Take a break first**.
  - **Threshold 4 (`distraction <= 3.50`, `difficulty <= 3.50`)**: If distractions are manageable and difficulty is moderate (1-3), recommend **Deep focus block**.
  - **Threshold 5 (`distraction <= 3.50`, `difficulty > 3.50`)**: If distractions are manageable and difficulty is challenging (4-5), recommend **Practice problems**.

## Project Highlights
1. **Explainable AI (XAI)**: Demystifies machine learning by exposing the full decision path through `export_text()`. Students can visually inspect every conditional branch.
2. **Dual-Mode Architecture**: Supports automated, non-interactive execution for automated grading or benchmarks, alongside an interactive terminal questionnaire (`--interactive`) powered by `sys.argv`.
3. **Defensive Programming**: Validates user inputs with type conversion, loop-based retry mechanisms, and boundary checks against the `QUESTIONS` configuration tuple.
4. **Multi-Artifact Delivery**: Generates structured console text, two high-resolution visual plots (`study_tree.png`, `confusion_matrix.png`), and a persistent audit log (`rules.txt`).
