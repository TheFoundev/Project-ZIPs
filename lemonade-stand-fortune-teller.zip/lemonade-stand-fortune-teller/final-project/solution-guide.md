# Mentor Solution Guide

## Overview

This guide walks mentors through the expected implementation of the final project. Students should follow main.py closely, and mentors should verify that their implementation matches the project's design decisions and produces equivalent results.

## Solution Structure

The reference solution mirrors main.py's structure exactly. Key checkpoints (in order):

### Checkpoint 1: Backend and Imports (lines 12-25)
```python
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split
```

**What mentors should verify:**
- `matplotlib.use("Agg")` appears BEFORE `import matplotlib.pyplot as plt`
- All 8 import lines are present (pathlib, matplotlib+backend, pyplot, numpy, pandas, LinearRegression, metrics, train_test_split)
- No extra third-party imports that aren't needed

**Common student errors:**
- Putting `matplotlib.use("Agg")` after pyplot import (may print a warning)
- Forgetting `encoding="utf-8"` in the `open()` call for prediction.txt (usually not an issue on Linux/macOS but can cause problems on Windows)
- Importing `LinearRegression` from the wrong module (e.g., `sklearn.linear_model` is correct, not `sklearn.models`)

### Checkpoint 2: Path Setup (lines 22-25)
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)
```

**What mentors should verify:**
- `BASE` uses `Path(__file__).resolve().parent` — this makes paths relative to the script's location, not the current working directory
- `OUT.mkdir(exist_ok=True)` is called BEFORE any save operations
- Paths use the `/` operator (pathlib), not string concatenation

**Common student errors:**
- Using `os.path` instead of `pathlib.Path` (accepted but not matching main.py style)
- Forgetting `exist_ok=True` (crashes if outputs/ already exists)
- Hardcoding paths like `"data/lemonade_days.csv"` without `BASE`

### Checkpoint 3: Data Loading (line 29)
```python
df = pd.read_csv(DATA / "lemonade_days.csv")
```

**What mentors should verify:**
- The filename is `lemonade_days.csv` (not `lemonade.csv` or `sales.csv`)
- The path is `DATA / "lemonade_days.csv"` (not hardcoded string)
- After loading, `df.shape` is `(16, 3)`

**Common student errors:**
- Wrong filename (most common: `lemonade.csv` without `_days`)
- Wrong path (e.g., `BASE / "data/lemonade_days.csv"` instead of `DATA / "lemonade_days.csv"`)

### Checkpoint 4: Feature/Target Separation (lines 30-31)
```python
X = df[["temperature_c"]]   # double brackets → DataFrame, shape (16, 1)
y = df["cups_sold"]          # single brackets → Series, shape (16,)
```

**What mentors should verify:**
- X uses double brackets `[["temperature_c"]]` → DataFrame (required by sklearn)
- y uses single brackets `["cups_sold"]` → Series
- `type(X)` is `pandas.DataFrame`, `type(y)` is `pandas.Series`
- `X.shape` is `(16, 1)`, `y.shape` is `(16,)`

**Common student errors:**
- Using single brackets for X: `df["temperature_c"]` → Series (1D) → sklearn error
- Using dot notation: `df.temperature_c` → also returns Series
- Using wrong column name: `df[["temp"]]` or `df[["Temperature"]]` → KeyError

### Checkpoint 5: Train/Test Split (lines 33-35)
```python
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)
```

**What mentors should verify:**
- `test_size=0.25` (not 0.5 or 0.2)
- `random_state=42` (exact value matters for reproducibility)
- Both X and y are passed to the same `train_test_split` call
- X_train has 12 rows, X_test has 4 rows

**Common student errors:**
- Forgetting `random_state` (results are non-reproducible)
- Using `test_size=0.5` (more data in test, less for training)
- Passing X and y in wrong order: `train_test_split(y, X, ...)` (works but confusing)

### Checkpoint 6: Model Training (lines 37-38)
```python
model = LinearRegression()
model.fit(X_train, y_train)
```

**What mentors should verify:**
- Model is instantiated before fitting
- `fit()` is called with `X_train, y_train` (NOT `X_test, y_test` — this is data leakage!)
- After fitting, `model.coef_` and `model.intercept_` are accessible

**Common student errors:**
- Fitting on test data: `model.fit(X_test, y_test)` — invalidates evaluation
- Fitting on all data: `model.fit(X, y)` — no train/test separation
- Accessing `model.coef_` before calling `fit()` → AttributeError

### Checkpoint 7: Coefficient Extraction (lines 41-42)
```python
slope = float(model.coef_[0])
intercept = float(model.intercept_)
```

**What mentors should verify:**
- `model.coef_[0]` — indexing because `coef_` is an array (even for 1 feature)
- `float()` wraps both — converts numpy float64 to Python float
- `model.intercept_` is a scalar, but `float()` is still used for consistency

**Common student errors:**
- Forgetting `[0]`: `slope = float(model.coef_)` → TypeError (can't convert array to float)
- Forgetting `float()`: works in f-strings but may cause formatting issues

### Checkpoint 8: Evaluation (lines 44-47)
```python
test_predictions = model.predict(X_test)
slope = float(model.coef_[0])
intercept = float(model.intercept_)
mae = mean_absolute_error(y_test, test_predictions)
r2 = r2_score(y_test, test_predictions)
```

**What mentors should verify:**
- `test_predictions = model.predict(X_test)` — predicts on TEST data (not training)
- `mean_absolute_error(y_test, test_predictions)` — arguments in order (y_true, y_pred)
- `r2_score(y_test, test_predictions)` — same argument order
- MAE ≈ 2.16, R² ≈ 0.90

**Common student errors:**
- Swapping arguments: `mean_absolute_error(test_predictions, y_test)` — gives wrong result
- Using `model.predict(X_train)` for test_predictions — evaluates on training data instead
- Using `accuracy_score` instead of `r2_score` — wrong metric for regression

### Checkpoint 9: 35°C Prediction (lines 46-47, 62-63)
```python
hot_day = pd.DataFrame({"temperature_c": [35.0]})
hot_prediction = float(model.predict(hot_day)[0])
```

**What mentors should verify:**
- `hot_day` is a DataFrame with column name `temperature_c` (must match training column)
- The value is `[35.0]` (a list with one float)
- `model.predict(hot_day)[0]` — extracts the single prediction from the returned array
- `float()` converts the result
- `hot_prediction ≈ 44.6`

**Common student errors:**
- Using a list: `model.predict([[35.0]])` — may work but is not the DataFrame approach used in main.py
- Using a scalar: `model.predict(35.0)` — causes ValueError (need 2D input)
- Wrong column name: `pd.DataFrame({"temp": [35.0]})` — ValueError due to feature name mismatch
- Forgetting `[0]`: `hot_prediction = float(model.predict(hot_day))` — TypeError (array to float)

### Checkpoint 10: Console Output (lines 69-73)
```python
print(f"Model: cups = {slope:.2f} x temperature + {intercept:.2f}")
print(f"Meaning: each extra 1 C is associated with about {slope:.2f} more cups.")
print(f"Mean absolute error: {mae:.2f} cups")
print(f"R-squared: {r2:.2f}")
print(f"Prediction for 35 C: {hot_prediction:.1f} cups")
```

**What mentors should verify:**
- Format specifiers are correct: `:.2f` for 2 decimals, `:.1f` for 1 decimal
- The variable references in f-strings match the assigned variables
- Output format matches the expected values

**Common student errors:**
- Wrong format specifier: `:.4f` instead of `:.2f`
- Using wrong variable: `{intercept:.2f}` instead of `{hot_prediction:.1f}` for the prediction line
- Missing "cups" in some lines that should have it

### Checkpoint 11: Visualization (lines 59-74)
```python
line_x = np.linspace(df["temperature_c"].min(), df["temperature_c"].max(), 100)
line_y = model.predict(pd.DataFrame({"temperature_c": line_x}))

fig, ax = plt.subplots(figsize=(7, 5))
ax.scatter(X_train, y_train, color="#e67e22", label="training days", s=55)
ax.scatter(X_test, y_test, color="#2c3e50", label="test days", s=55, marker="s")
ax.plot(line_x, line_y, color="#16a085", linewidth=2.5, label="learned trend line")
ax.scatter([35], [hot_prediction], color="#c0392b", s=140, marker="*",
           zorder=5, label="35 C prediction")

ax.set_xlabel("Temperature (C)")
ax.set_ylabel("Cups sold")
ax.set_title("Lemonade sales vs. temperature")
ax.legend()
ax.grid(alpha=0.25)
```

**What mentors should verify:**
- `line_x` uses `np.linspace` with 100 points across the data range
- `line_y` predictions use a DataFrame with column `temperature_c` (matching training)
- Training data: orange circles (`#e67e22`)
- Test data: dark blue squares (`#2c3e50`, `marker="s"`)
- Regression line: green (`#16a085`), `linewidth=2.5`
- Prediction star: red (`#c0392b`), `marker="*"`, `s=140`, `zorder=5`
- All labels, title, legend, and grid are present

**Common student errors:**
- Passing `X_train` directly to `ax.scatter` — `X_train` is a DataFrame; matplotlib may handle it but it's not clean
- Using wrong color codes or marker styles
- Forgetting `zorder=5` — the star may be hidden behind the line
- Using `plt.legend()` instead of `ax.legend()` — works but not OOP style

### Checkpoint 12: File Output (lines 72-80)
```python
fig.tight_layout()
fig.savefig(OUT / "lemonade_regression.png", dpi=150, bbox_inches="tight")
plt.close(fig)

with open(OUT / "prediction.txt", "w", encoding="utf-8") as handle:
    handle.write(f"Equation: cups = {slope:.4f} * temperature + {intercept:.4f}\n")
    handle.write(f"Prediction at 35 C: {hot_prediction:.2f} cups\n")
    handle.write(f"Mean absolute error: {mae:.2f}\n")
    handle.write(f"R-squared: {r2:.2f}\n")
```

**What mentors should verify:**
- `fig.tight_layout()` is called before `savefig`
- `dpi=150` and `bbox_inches="tight"` are in `savefig`
- `plt.close(fig)` is called after saving
- `prediction.txt` has exactly 4 lines with the correct format specifiers (`:.4f` for equation, `:.2f` for others)
- The equation in the file uses `*` (multiplication sign) not `×`

**Common student errors:**
- Forgetting `tight_layout()` — labels may be clipped in the saved figure
- Using wrong dpi or missing `bbox_inches`
- Writing only 3 lines (forgetting R²)
- Using wrong format specifiers in prediction.txt

## Evaluation Checklist for Mentors

Before approving a student's submission, mentors should verify:

1. **Code structure** — Does the code follow main.py's structure?
2. **Training correctness** — Was the model trained on training data only?
3. **Evaluation correctness** — Were MAE and R² computed on the test set?
4. **Output verification** — Do the prediction.txt values match the console output?
5. **Plot correctness** — Does the PNG show all required elements (scatter, line, star)?
6. **Reproducibility** — Does running twice produce identical results?
7. **No data leakage** — Are test data never used in training or coefficient extraction?
8. **Manual verification** — Does `slope × 35 + intercept ≈ hot_prediction`?

## Key Values to Check Against

| Value | Expected | Acceptable Range |
|---|---|---|
| Slope | ~1.5776 | 1.50 - 1.65 |
| Intercept | ~-10.6618 | -12 to -9 |
| MAE | ~2.16 | 1.5 - 3.0 |
| R² | ~0.90 | 0.80 - 1.00 |
| 35°C prediction | ~44.6 | 40 - 50 |
| Training rows | 12 | exactly 12 |
| Test rows | 4 | exactly 4 |

## Common Patterns That Are Wrong But Students Often Do

1. **Predicting before fitting** — `model.predict(X_test)` before `model.fit()` → AttributeError or no fitted model
2. **Using all data for training** — `model.fit(X, y)` — no test set → evaluation is meaningless
3. **Evaluating on training data** — `mean_absolute_error(y_train, model.predict(X_train))` — overly optimistic
4. **Wrong column name** — `df[["temp"]]` or `df[["Temperature"]]` — KeyError
5. **Single brackets for X** — `df["temperature_c"]` — gives Series, not DataFrame, causing sklearn errors