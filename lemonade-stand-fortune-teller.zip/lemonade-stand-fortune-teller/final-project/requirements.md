# Final Project Requirements

## Project Objective

Reproduce the complete Lemonade Stand Fortune Teller from scratch, following main.py exactly. Your implementation should load the dataset, train a linear regression model, evaluate it with MAE and R², predict sales for a 35°C day, and produce both a scatter plot with regression line and a prediction text file. You will then analyze the results and explain the model's behavior.

## Functional Requirements

1. **Imports and Setup**
   - Set the matplotlib Agg backend before importing pyplot
   - Import Path from pathlib, numpy, pandas, matplotlib, and all required sklearn modules
   - Define BASE, DATA, and OUT paths using pathlib
   - Create the outputs directory with `mkdir(exist_ok=True)`

2. **Data Loading**
   - Load `data/lemonade_days.csv` using `pd.read_csv()` with the correct path
   - Verify the dataset has 3 columns: `day`, `temperature_c`, `cups_sold`
   - Verify the dataset has 16 rows of data

3. **Feature/Target Separation**
   - Create `X = df[["temperature_c"]]` as a 2D DataFrame (double brackets)
   - Create `y = df["cups_sold"]` as a 1D Series (single brackets)

4. **Train/Test Split**
   - Split with `train_test_split(X, y, test_size=0.25, random_state=42)`
   - Verify: X_train has 12 rows, X_test has 4 rows

5. **Model Training**
   - Import `LinearRegression` from `sklearn.linear_model`
   - Create instance: `model = LinearRegression()`
   - Train: `model.fit(X_train, y_train)` (training data only, never test data)

6. **Coefficient Extraction**
   - Extract slope: `slope = float(model.coef_[0])`
   - Extract intercept: `intercept = float(model.intercept_)`
   - Form the equation: `cups = slope × temperature + intercept`

7. **Evaluation**
   - Generate test predictions: `test_predictions = model.predict(X_test)`
   - Calculate MAE: `mean_absolute_error(y_test, test_predictions)`
   - Calculate R²: `r2_score(y_test, test_predictions)`

8. **35°C Prediction**
   - Create: `hot_day = pd.DataFrame({"temperature_c": [35.0]})`
   - Predict: `hot_prediction = float(model.predict(hot_day)[0])`

9. **Console Output**
   - Print the header and all metrics in the format shown in main.py
   - Ensure slope, MAE, R² are formatted with 2 decimal places
   - Ensure prediction is formatted with 1 decimal place

10. **Visualization**
    - Create figure with `fig, ax = plt.subplots(figsize=(7, 5))`
    - Plot training data as orange circles
    - Plot test data as dark blue squares
    - Generate 100 points with `np.linspace` and predict along the line
    - Draw the regression line in green
    - Mark the 35°C prediction with a red star (zorder=5)
    - Set labels, title, legend, grid

11. **File Output**
    - Save plot: `fig.savefig(OUT / "lemonade_regression.png", dpi=150, bbox_inches="tight")`
    - Write prediction.txt with equation, prediction, MAE, R²
    - Close figure: `plt.close(fig)`

## Non-Functional Requirements

- **Reproducibility**: Use `random_state=42` for the train/test split; results must be identical across runs
- **Correctness**: The model equation must produce the same prediction as `model.predict()` for 35°C
- **Code clarity**: Include comments for each major step, following main.py's structure
- **Path safety**: Use pathlib for all file paths; never hardcode OS-specific separators
- **Memory management**: Always call `plt.close(fig)` after saving
- **No external dependencies**: All data is local; no network access needed

## Implementation Milestones

| Milestone | Deliverable | Verification |
|---|---|---|
| 1: Environment setup | Script runs without import errors | All packages import successfully |
| 2: Data loading | DataFrame with correct shape and columns | df.shape = (16, 3) |
| 3: Feature separation | X (16,1 DataFrame), y (16 Series) | Shapes verified |
| 4: Train/test split | 4 arrays with 12 and 4 rows | Shapes verified |
| 5: Model training | Trained LinearRegression | coef_ and intercept_ accessible |
| 6: Evaluation | MAE and R² computed | Values match known results |
| 7: 35°C prediction | hot_prediction value | ~44.6 cups |
| 8: Visualization | Plot with all elements | PNG file saved |
| 9: File output | prediction.txt written | File has 4 lines |
| 10: Full run | No errors, all outputs created | Console matches expected |

## Expected Deliverables

- [ ] **Working Python script** (`final_lemonade.py` or similar) that runs without errors
- [ ] **Console output** matching the expected format:
  ```
  ============================================================
  THE LEMONADE STAND FORTUNE TELLER
  ============================================================
  Model: cups = 1.58 x temperature + -10.66
  Meaning: each extra 1 C is associated with about 1.58 more cups.
  Mean absolute error: 2.16 cups
  R-squared: 0.90
  Prediction for 35 C: 44.6 cups
  ```
- [ ] **`outputs/lemonade_regression.png`** — plot with training points, test points, regression line, and 35°C star marker
- [ ] **`outputs/prediction.txt`** — text file with equation, prediction, MAE, R²
- [ ] **1-page analysis report** (text or markdown) containing:
  - The learned equation and its interpretation
  - MAE and R² values with interpretations
  - The 35°C prediction with interpretation
  - One limitation of this model
  - One suggestion for improvement

## Acceptance Criteria

- [ ] Script runs with `python final_lemonade.py` without errors
- [ ] Equation uses the correct format: `cups = {slope:.2f} x temperature + {intercept:.2f}`
- [ ] MAE is between 1.5 and 3.0 (reasonable for this dataset)
- [ ] R² is between 0.80 and 1.0 (good fit for this dataset)
- [ ] 35°C prediction is between 40 and 50 cups
- [ ] Manual check: `slope × 35 + intercept` matches the model's prediction (within rounding)
- [ ] Plot contains: orange circles, blue squares, green line, red star
- [ ] Plot has legend with all 4 entries, axis labels, title, and grid
- [ ] prediction.txt has exactly 4 lines matching expected format
- [ ] PNG file is valid and > 1KB
- [ ] `plt.close(fig)` is called after saving

## Testing Checklist

- [ ] Verify Python 3.x is installed: `python --version`
- [ ] Install dependencies: `pip install pandas numpy matplotlib scikit-learn`
- [ ] Verify data file exists: `ls data/lemonade_days.csv`
- [ ] Run the script: `python final_lemonade.py`
- [ ] Check console output matches expected format
- [ ] Check output files exist: `ls outputs/`
- [ ] Verify PNG is valid: `file outputs/lemonade_regression.png` (should show "PNG image data")
- [ ] Verify prediction.txt: `cat outputs/prediction.txt` (should have 4 lines)
- [ ] Verify equation: `python -c "print(1.58 * 35 + (-10.66))"` (should be ~44.6)
- [ ] Run twice to confirm reproducibility (identical output with random_state=42)
- [ ] Check memory: no `ResourceWarning` about unclosed figures

## Expected Output Values

Based on running main.py with the actual dataset:

| Metric | Expected Value | Format |
|---|---|---|
| Slope (coef_) | ~1.5776 | 2 decimal places in console |
| Intercept | ~-10.6618 | 2 decimal places in console |
| MAE | ~2.16 | 2 decimal places |
| R² | ~0.90 | 2 decimal places |
| 35°C Prediction | ~44.6 | 1 decimal place |

## Troubleshooting

| Issue | Cause | Fix |
|---|---|---|
| `ModuleNotFoundError` | Package not installed | `pip install pandas numpy matplotlib scikit-learn` |
| `FileNotFoundError: lemonade_days.csv` | Wrong working directory | Ensure data file is at `data/lemonade_days.csv`; main.py uses `Path(__file__).resolve().parent` so run from project dir |
| `ValueError: inconsistent numbers of features` | X is 1D (used single brackets) | Use `df[["temperature_c"]]` with double brackets |
| `AttributeError: no attribute 'coef_'` | Accessing coefficients before `fit()` | Call `model.fit()` first |
| `ValueError: x and y must have same first dimension` | X and y from different sources or lengths | Ensure both come from the same dataframe and split call |
| `ModuleNotFoundError: No module named 'sklearn'` | scikit-learn not installed | `pip install scikit-learn` |
| Plot window opens and freezes | Agg backend not set | Ensure `matplotlib.use("Agg")` is before `import matplotlib.pyplot` |
| PNG file not created | Outputs directory missing | `OUT.mkdir(exist_ok=True)` creates it |

## Optional Extension Challenges

1. **Add a rainy-day column**: Create a synthetic `weather` column (sunny/cloudy/rainy) in the CSV and see how it affects predictions. This teaches handling categorical features and feature engineering.

2. **Polynomial features**: Try fitting a degree-2 polynomial (`sklearn.preprocessing.PolynomialFeatures`) and compare MAE/R² to the linear model. This teaches the trade-off between model complexity and overfitting.

3. **K-fold cross-validation**: Instead of a single train/test split, implement 5-fold cross-validation using `sklearn.model_selection.cross_val_score`. This gives a more robust estimate of model performance.

4. **Confidence intervals**: Use `sklearn.utils.bootstrap` to generate bootstrap samples and compute confidence intervals for the slope and intercept. This introduces statistical uncertainty quantification.

5. **Interactive dashboard**: Create a simple command-line interface that asks the user for a temperature and returns the predicted sales, using the trained model.

6. **Multiple regression**: If additional data were available (humidity, day of week, price), add these as additional features and compare performance. This teaches multivariate regression.