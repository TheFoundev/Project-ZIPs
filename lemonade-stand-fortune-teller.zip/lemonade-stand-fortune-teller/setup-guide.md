# Setup Guide

## Step 1: Navigate to Project
```bash
cd beginner-projects-main/AI-ML\ Beginners/projects/02_lemonade_stand
```

## Step 2: Install Dependencies
```bash
pip install pandas numpy matplotlib scikit-learn
```

Or create requirements.txt:
```txt
pandas
numpy
matplotlib
scikit-learn
```
```bash
pip install -r requirements.txt
```

## Step 3: Understand Data
Look at `data/lemonade_days.csv`:
```bash
head data/lemonade_days.csv
```

## Step 4: Run the Project
```bash
python main.py
```

## Step 5: Check Outputs
- Console: equation, MAE, R², prediction for 35°C
- `outputs/lemonade_regression.png`
- `outputs/prediction.txt`
