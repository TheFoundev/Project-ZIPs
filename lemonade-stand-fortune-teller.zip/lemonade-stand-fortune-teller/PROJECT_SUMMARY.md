# The Lemonade Stand Fortune Teller

## Overview
This project uses **Linear Regression** to predict the number of lemonade cups sold based on the day's temperature. Using the actual dataset `data/lemonade_days.csv` from `beginner-projects-main/AI-ML Beginners/projects/02_lemonade_stand/`, you'll learn how to train a model, evaluate it, and make predictions.

## Real-World Use Case
Small businesses can forecast demand based on weather to manage inventory better.

## Features (Implemented)
- Load temperature and sales data from CSV
- Split data into training and testing sets (75/25)
- Train a Linear Regression model with scikit-learn
- Predict sales for 35°C
- Calculate Mean Absolute Error (MAE) and R² score
- Generate scatter plot with regression line and prediction point
- Save results to `outputs/prediction.txt`

## Technology Stack
- Python 3
- pandas, numpy
- matplotlib
- scikit-learn

## System Requirements
- Python 3.7+
- pip

## Installation Instructions
```bash
cd beginner-projects-main/AI-ML\ Beginners/projects/02_lemonade_stand
pip install pandas numpy matplotlib scikit-learn
python main.py
```

## Project Structure (Actual)
```
02_lemonade_stand/
├── main.py
├── data/
│   └── lemonade_days.csv
└── outputs/
    ├── lemonade_regression.png
    └── prediction.txt
```

## How It Works
1. Loads `data/lemonade_days.csv` with columns `day`, `temperature_c`, `cups_sold`
2. Uses `temperature_c` as feature X, `cups_sold` as target y
3. Splits with `train_test_split(test_size=0.25, random_state=42)`
4. Fits `LinearRegression()` to get slope and intercept
5. Evaluates on test set with MAE and R²
6. Predicts for 35°C using `pd.DataFrame({"temperature_c": [35.0]})`
7. Plots training/test points, regression line, and 35°C prediction

## Expected Output
- Console output with equation, MAE, R², and 35°C prediction
- `outputs/lemonade_regression.png`
- `outputs/prediction.txt`

## Security Considerations
- No hardcoded credentials
- Local file processing only

## Troubleshooting
- Install missing packages: `pip install -r requirements.txt` or individual packages
- Ensure you're in the project directory
- Check that data file exists

## Further Learning
- Linear Regression theory
- Train/test split
- Regression metrics (MAE, R²)
