# Lesson 02: Mean Absolute Error (MAE) on the Test Set

**Lesson ID:** lesson-02  
**Module:** module-04  
**Duration:** 20-25 minutes  

## Specific Learning Objectives
By the end of this lesson, you will be able to:
- Explain why we evaluate on the test set
- Generate predictions for X_test
- Calculate MAE using `mean_absolute_error`
- Interpret MAE in terms of cups sold

## Beginner-Friendly Explanation
We trained on X_train/y_train. To estimate real performance, we predict on unseen X_test and compare to y_test. Mean Absolute Error is the average of |actual - predicted| across test samples. It tells us, on average, how many cups off our predictions are. Lower MAE is better.

## Relevant Code (from main.py)
```python
test_predictions = model.predict(X_test)
mae = mean_absolute_error(y_test, test_predictions)
```
(see lines ~55, 60)

## Line-by-Line Explanation
- `model.predict(X_test)` - Predicts for all test samples
- `mean_absolute_error(y_test, test_predictions)` - Computes average absolute error
- Result stored in `mae`

## Worked Example
```python
from sklearn.metrics import mean_absolute_error
test_predictions = model.predict(X_test)
mae = mean_absolute_error(y_test, test_predictions)
print(f"MAE: {mae:.2f} cups")
```

## Step-by-Step Student Instructions
1. Ensure train/test split done
2. Predict on X_test
3. Import and call mean_absolute_error(y_test, predictions)
4. Interpret in cups

## Expected Output or Observable Behaviour
A numeric MAE (e.g., reasonable value like a few cups). Units are same as target (cups).

## Practical Exercise (with Success Criteria)
**Task:** Compute MAE and explain what it means for this project.
**Success Criteria:**
- [ ] Predict on test set only
- [ ] Use mean_absolute_error correctly
- [ ] Report MAE with units
- [ ] Explain interpretation

## Common Mistakes and Troubleshooting
| Mistake | Cause | Fix |
|---|---|---|
| Evaluating on training data | Wrong variables | Use X_test, y_test |
| Swapping arguments | API confusion | Check sklearn docs; usually (y_true, y_pred) |
| Forgetting import | Import missing | Import from sklearn.metrics |

## Short Knowledge Check
1. Why evaluate on test set?
2. What does MAE measure?
3. Are MAE units cups here? Why?

## References
- main.py lines 31, 55, 60
- sklearn.metrics.mean_absolute_error
