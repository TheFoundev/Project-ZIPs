# Lesson 01: Predicting for a New Temperature (35°C)

**Lesson ID:** lesson-01  
**Module:** module-04  
**Duration:** 20-25 minutes  

## Specific Learning Objectives
By the end of this lesson, you will be able to:
- Explain why we predict for 35°C in this project
- Create a DataFrame with the correct column name for prediction
- Use `model.predict()` on new data
- Understand why a DataFrame (not a list) is used with sklearn

## Beginner-Friendly Explanation
After training, the model can predict sales for temperatures it hasn't seen. In main.py, we create a new input `hot_day = pd.DataFrame({"temperature_c": [35.0]})` and call `model.predict(hot_day)`. The result is an array; we take `[0]` and convert to float for clean printing. Using a DataFrame keeps the column name consistent with training (`temperature_c`), which is important for clarity and consistency with sklearn workflows.

## Relevant Code (from main.py)
```python
hot_day = pd.DataFrame({"temperature_c": [35.0]})
hot_prediction = float(model.predict(hot_day)[0])
```
(see lines ~62-63)

## Line-by-Line Explanation
- `pd.DataFrame({"temperature_c": [35.0]})` - Creates a single-row DataFrame with feature name matching training
- `model.predict(hot_day)` - Returns array of predictions
- `[0]` - Extracts first (and only) prediction
- `float(...)` - Converts numpy float to Python float for formatting

## Worked Example
```python
# After training model
hot_day = pd.DataFrame({"temperature_c": [35.0]})
pred = model.predict(hot_day)
print(pred)        # array([...])
print(pred[0])     # value
print(float(pred[0]))
```

## Step-by-Step Student Instructions
1. Ensure model is trained on X_train, y_train
2. Create DataFrame with column `temperature_c` and value 35.0
3. Call `model.predict()` and extract first element
4. Print and compare with equation if desired

## Expected Output or Observable Behaviour
A numeric prediction (e.g., ~something reasonable based on data). Type is float after conversion.

## Practical Exercise (with Success Criteria)
**Task:** Predict for 30°C and 40°C. Print each prediction.
**Success Criteria:**
- [ ] Use DataFrame with correct column name
- [ ] Call predict() correctly
- [ ] Extract scalar value
- [ ] Explain why DataFrame is used

## Common Mistakes and Troubleshooting
| Mistake | Cause | Fix |
|---|---|---|
| Passing a list [[35.0]] to predict in wrong context | Shape confusion | Follow main.py pattern with DataFrame |
| Wrong column name | Mismatch with training | Use `temperature_c` exactly |
| Getting array instead of value | Forgot `[0]` | Extract first element |

## Short Knowledge Check
1. Why use a DataFrame for prediction in this code?
2. What does `[0]` do?
3. Why convert to float?

## References
- main.py lines 62-63
- sklearn LinearRegression.predict
