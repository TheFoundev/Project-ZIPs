# Lesson 03: R² Score

**Lesson ID:** lesson-03  
**Module:** module-04  
**Duration:** 20-25 minutes  

## Specific Learning Objectives
By the end of this lesson, you will be able to:
- Explain R² (coefficient of determination)
- Calculate R² with `r2_score`
- Interpret R² values (0-1 range conceptually)
- Compare MAE and R² as complementary metrics

## Beginner-Friendly Explanation
R² tells us how much of the variation in cups sold is explained by temperature. A value closer to 1 means temperature explains most of the variation; closer to 0 means less. In main.py: `r2 = r2_score(y_test, test_predictions)`. Use it alongside MAE - MAE gives error in cups, R² gives explained variance.

## Relevant Code (from main.py)
```python
r2 = r2_score(y_test, test_predictions)
```
(see lines ~31, 61)

## Line-by-Line Explanation
- Import `r2_score` from sklearn.metrics
- Call with y_test and test_predictions
- Print as float

## Worked Example
```python
from sklearn.metrics import r2_score
r2 = r2_score(y_test, test_predictions)
print(f"R-squared: {r2:.2f}")
```

## Step-by-Step Student Instructions
1. Have test predictions ready
2. Import r2_score
3. Compute on test set
4. Interpret meaning

## Expected Output or Observable Behaviour
R² value (commonly 0-1 for good linear fits).

## Practical Exercise (with Success Criteria)
**Task:** Compute and interpret both MAE and R².
**Success Criteria:**
- [ ] Compute MAE and R² on test set
- [ ] Explain difference between them
- [ ] State what they tell us about the model

## Common Mistakes and Troubleshooting
| Mistake | Cause | Fix |
|---|---|---|
| Computing on training data | Wrong set | Use test set |
| Confusing R² with accuracy | Different metric types | Remember R² for regression |
| Thinking R² must be 1 | Unrealistic expectation | Context matters |

## Short Knowledge Check
1. What does R² measure?
2. Why use both MAE and R²?
3. Should R² be computed on train or test set here?

## References
- main.py lines 31, 61
- sklearn.metrics.r2_score
