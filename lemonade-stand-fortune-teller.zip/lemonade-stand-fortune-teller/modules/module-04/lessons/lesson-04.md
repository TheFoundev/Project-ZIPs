# Lesson 04: Putting Predictions and Metrics Together

**Lesson ID:** lesson-04  
**Module:** module-04  
**Duration:** 20-25 minutes  

## Specific Learning Objectives
By the end of this lesson, you will be able to:
- Trace the full prediction/evaluation flow in main.py
- Reproduce all outputs for metrics
- Verify your understanding against actual code

## Beginner-Friendly Explanation
Lines 55-74 in main.py show: get test_predictions, compute slope/intercept (already have), compute mae and r2, create hot_day for 35°C, predict, print everything. All of this happens after training and before plotting.

## Relevant Code (from main.py)
```python
test_predictions = model.predict(X_test)
...
slope = float(model.coef_[0])
intercept = float(model.intercept_)
mae = mean_absolute_error(y_test, test_predictions)
r2 = r2_score(y_test, test_predictions)
hot_day = pd.DataFrame({"temperature_c": [35.0]})
hot_prediction = float(model.predict(hot_day)[0])
...
print("=" * 60)
print("THE LEMONADE STAND FORTUNE TELLER")
print("=" * 60)
print(f"Model: cups = {slope:.2f} x temperature + {intercept:.2f}")
print(f"Meaning: each extra 1 C is associated with about {slope:.2f} more cups.")
print(f"Mean absolute error: {mae:.2f} cups")
print(f"R-squared: {r2:.2f}")
print(f"Prediction for 35 C: {hot_prediction:.1f} cups")
```

## Step-by-Step Student Instructions
1. Read lines 55-74
2. Identify order of operations
3. Reproduce console output logic
4. Verify values make sense

## Expected Output or Observable Behaviour
Console shows equation, meaning, MAE, R², 35°C prediction.

## Practical Exercise (with Success Criteria)
**Task:** Reproduce the prediction and evaluation section from scratch.
**Success Criteria:**
- [ ] All calculations use correct variables
- [ ] Prediction uses DataFrame for 35°C
- [ ] MAE and R² on test set
- [ ] Output formatted clearly

## Common Mistakes and Troubleshooting
| Mistake | Cause | Fix |
|---|---|---|
| Wrong order | Printing before computing | Compute all values first |
| Using train data for metrics | Copy-paste error | Use test data |

## Short Knowledge Check
1. What order are predictions/metrics computed in?
2. Why compute metrics on test set?
3. What does the "meaning" line tell us?

## References
- main.py 55-74
