# Module 4 Exercises

## Exercise 4.1: Predict for 35°C (15 min)
**Objective:** Create a prediction DataFrame and use the trained model to predict sales for a 35°C day
**Problem Statement:** The model has been trained on temperature data. Now you need to predict how many cups would be sold at 35°C, following the same approach main.py uses.

**Requirements:**
1. Create `hot_day = pd.DataFrame({"temperature_c": [35.0]})`
2. Call `model.predict(hot_day)` to get the raw prediction
3. Extract the first element with `[0]`
4. Convert to float with `float()`
5. Print the prediction with 1 decimal place

**Constraints:** Use a DataFrame (not a list or numpy array) for the prediction input, matching the training feature structure exactly.

**Expected Behaviour:** Console output showing a prediction around 44.6 cups.

**Acceptance Criteria:**
- [ ] `hot_day` is a DataFrame with column name `temperature_c`
- [ ] `model.predict(hot_day)` is called correctly
- [ ] `[0]` extracts the single prediction
- [ ] `float()` converts the numpy type to Python float
- [ ] Output is printed with `:.1f` formatting
- [ ] The prediction is approximately 44.6 cups

**Hints:**
- The column name must match exactly: `temperature_c`, not `temp` or `Temperature`
- Using a list `[[35.0]]` would cause a feature-name mismatch error
- Using a 1D array `[35.0]` would cause a shape error
- The value 35.0 is a float, which matches the training data type

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 4.2: Computing MAE on the Test Set (20 min)
**Objective:** Evaluate the model's prediction accuracy using Mean Absolute Error
**Problem Statement:** The model has made predictions on the test set. Calculate the MAE to quantify how far off the predictions are from actual values.

**Requirements:**
1. Import `mean_absolute_error` from `sklearn.metrics`
2. Generate test predictions: `test_predictions = model.predict(X_test)`
3. Calculate MAE: `mae = mean_absolute_error(y_test, test_predictions)`
4. Interpret the result in terms of cups sold

**Constraints:** Use `y_test` (actual values) and `test_predictions` (predicted values) in the correct argument order.

**Expected Behaviour:** A numeric MAE value around 2.16, with an interpretation sentence.

**Acceptance Criteria:**
- [ ] `mean_absolute_error` is imported from the correct module
- [ ] `test_predictions` are generated from `model.predict(X_test)` (test features, not training)
- [ ] `mean_absolute_error(y_test, test_predictions)` has correct argument order
- [ ] MAE is approximately 2.16
- [ ] Interpretation correctly states "on average, predictions are off by about 2 cups"

**Hints:**
- The argument order for `mean_absolute_error` is `(y_true, y_pred)` — actual values first, then predictions
- MAE is always non-negative (absolute values are used)
- MAE has the same units as the target variable (cups)
- A lower MAE means better accuracy

**Difficulty:** Intermediate
**Estimated Completion Time:** 20 minutes

---

## Exercise 4.3: Computing R² Score (15 min)
**Objective:** Calculate and interpret the R-squared coefficient of determination
**Problem Statement:** Calculate the R² score to understand how much of the variance in cups sold is explained by temperature.

**Requirements:**
1. Import `r2_score` from `sklearn.metrics`
2. Calculate R²: `r2 = r2_score(y_test, test_predictions)`
3. Interpret the R² value in plain language
4. Explain how R² complements MAE

**Constraints:** Use the same test predictions from Exercise 4.2.

**Expected Behaviour:** A numeric R² value around 0.90, with interpretations.

**Acceptance Criteria:**
- [ ] `r2_score` is imported from the correct module
- [ ] `r2_score(y_test, test_predictions)` uses correct arguments
- [ ] R² is approximately 0.90
- [ ] Interpretation: "temperature explains ~90% of the variation in cups sold"
- [ ] Comparison: "MAE tells us average error in cups; R² tells us proportion of variance explained"

**Hints:**
- R² ranges from 0 to 1 for most regression models (can be negative for very poor models)
- R² = 1.0 means perfect prediction; R² = 0.0 means the model is no better than predicting the mean
- R² of 0.90 means 90% of the variation in cups sold is explained by temperature
- MAE and R² measure different aspects: MAE is absolute error magnitude, R² is relative variance explained

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 4.4: Full Prediction and Evaluation Section (25 min)
**Objective:** Replicate the complete prediction and evaluation flow from main.py
**Problem Statement:** Write the complete prediction/evaluation section that takes the trained model and produces all metrics and the 35°C prediction, matching main.py's output format.

**Requirements:**
1. Generate `test_predictions = model.predict(X_test)`
2. Extract `slope = float(model.coef_[0])` and `intercept = float(model.intercept_)`
3. Calculate `mae = mean_absolute_error(y_test, test_predictions)`
4. Calculate `r2 = r2_score(y_test, test_predictions)`
5. Create `hot_day` DataFrame and get `hot_prediction`
6. Print all results in the same format as main.py (equation, meaning, MAE, R², prediction)

**Constraints:** Match main.py's format closely. Verify your equation produces the same 35°C prediction.

**Expected Behaviour:** Console output matching main.py's output:
```
Model: cups = 1.58 x temperature + -10.66
Meaning: each extra 1 C is associated with about 1.58 more cups.
Mean absolute error: 2.16 cups
R-squared: 0.90
Prediction for 35 C: 44.6 cups
```

**Acceptance Criteria:**
- [ ] All 5 computations are present and correctly ordered
- [ ] `test_predictions` computed before metrics
- [ ] `slope` and `intercept` extracted with `float()` conversion
- [ ] MAE uses `y_test` and `test_predictions`
- [ ] R² uses `y_test` and `test_predictions`
- [ ] 35°C prediction uses `pd.DataFrame({"temperature_c": [35.0]})`
- [ ] Print output format matches main.py closely
- [ ] Manual equation check: `1.58 * 35 + (-10.66) ≈ 44.6`

**Hints:**
- The order matters: predict on test set first, then extract coefficients, then compute metrics
- MAE uses `mean_absolute_error`, not `mean_squared_error`
- R² uses `r2_score`, not `accuracy_score` (which is for classification)
- The `:.2f` format specifier gives 2 decimal places; `:.1f` gives 1 decimal place

**Difficulty:** Advanced
**Estimated Completion Time:** 25 minutes