# Module 2 Exercises

## Exercise 2.1: Imports and Environment Setup (15 min)
**Objective:** Understand each import in main.py and configure the matplotlib backend correctly
**Problem Statement:** main.py begins with a series of imports and setup steps. You need to explain what each import does and why the order matters.

**Requirements:**
1. List all imports in main.py and explain the purpose of each library
2. Explain why `matplotlib.use("Agg")` must be called before `import matplotlib.pyplot as plt`
3. Explain what `BASE`, `DATA`, and `OUT` represent and how they are constructed
4. Explain why `OUT.mkdir(exist_ok=True)` is important

**Constraints:** Reference actual line numbers and code from main.py.

**Expected Behaviour:** A written explanation of each import and setup step.

**Acceptance Criteria:**
- [ ] All 9 imports are listed with correct purpose (pathlib, matplotlib, numpy, pandas, sklearn LinearRegression, sklearn metrics, sklearn model_selection)
- [ ] The Agg backend explanation covers non-interactive vs interactive backends
- [ ] BASE/DATA/OUT path construction is correctly explained using pathlib
- [ ] mkdir(exist_ok=True) purpose (create dir if missing, no error if exists) is explained
- [ ] The order-sensitive nature of matplotlib.use() before pyplot import is emphasized

**Hints:**
- pathlib.Path is used instead of string paths for cross-platform compatibility
- matplotlib must have its backend set before pyplot is imported because pyplot locks in the backend on import
- DATA = BASE / "data" and OUT = BASE / "outputs" use pathlib's division operator for path joining

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 2.2: Data Loading and Shape Verification (15 min)
**Objective:** Load the dataset and verify the data structures
**Problem Statement:** Load the lemonade dataset using pandas and verify the structure, shapes, and data types.

**Requirements:**
1. Load `data/lemonade_days.csv` using the same path approach as main.py
2. Print `df.shape`, `df.columns`, and `df.dtypes`
3. Show the first 5 rows with `df.head()`
4. State the range of temperatures and cups sold

**Constraints:** Use the actual data file from the project.

**Expected Behaviour:** A script that loads the data and prints verification information.

**Acceptance Criteria:**
- [ ] CSV loads without error from the correct path
- [ ] df.shape is printed as (16, 3)
- [ ] df.columns lists day, temperature_c, cups_sold
- [ ] df.dtypes shows all columns as numeric (int64 or float64)
- [ ] df.head() shows the first 5 rows correctly
- [ ] Temperature range and cups_sold range are stated

**Hints:**
- Use `from pathlib import Path` and construct the path like main.py does
- Temperature range: ~21°C to ~38°C
- Cups sold range: ~24 to ~48

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 2.3: Creating X and y with Correct Shapes (15 min)
**Objective:** Correctly separate features and target with proper pandas indexing
**Problem Statement:** Create the feature DataFrame X and target Series y from the loaded data, ensuring correct shapes for sklearn.

**Requirements:**
1. Create `X = df[["temperature_c"]]` using double brackets
2. Create `y = df["cups_sold"]` using single brackets
3. Print `X.shape`, `y.shape`, `type(X)`, `type(y)`
4. Explain why X must be 2D and y can be 1D

**Constraints:** Verify the types and shapes by running the code.

**Expected Behaviour:** Code that creates X and y correctly, with shape/type output.

**Acceptance Criteria:**
- [ ] X is a DataFrame with shape (16, 1)
- [ ] y is a Series with shape (16,)
- [ ] type(X) shows DataFrame, type(y) shows Series
- [ ] The explanation correctly covers sklearn's 2D feature requirement
- [ ] The explanation notes that y is the target vector (1D is fine for regression)

**Hints:**
- `df[["temperature_c"]]` (double brackets) → DataFrame
- `df["temperature_c"]` (single bracket) → Series
- sklearn's `fit()` expects X to have shape (n_samples, n_features)

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 2.4: Splitting Data and Analyzing the Splits (20 min)
**Objective:** Perform the train/test split and analyze which data points end up in each set
**Problem Statement:** Split the lemonade data using `train_test_split` with the exact parameters from main.py, then analyze the resulting training and test sets.

**Requirements:**
1. Split the data with `train_test_split(X, y, test_size=0.25, random_state=42)`
2. Print the shapes of all four resulting variables
3. Print the actual temperature and cups_sold values in the test set
4. Verify that the same temperature values from the test set also appear correctly in y_test

**Constraints:** Use `random_state=42` to match main.py exactly.

**Expected Behaviour:** Code output showing 4 arrays/Series with 12 and 4 elements respectively, plus test set values.

**Acceptance Criteria:**
- [ ] Split uses `test_size=0.25, random_state=42`
- [ ] X_train shape is (12, 1), X_test shape is (4, 1)
- [ ] y_train shape is (12,), y_test shape is (4,)
- [ ] Test set values are displayed and match the expected rows
- [ ] Explanation of why random_state ensures reproducibility is provided

**Hints:**
- With random_state=42, you should get 4 specific test rows
- The test temperatures should be among the hottest days (since the model predicts for 35°C, the test set should include some hot days)
- To see the actual values, use `print(X_test)` and `print(y_test)`

**Difficulty:** Intermediate
**Estimated Completion Time:** 20 minutes