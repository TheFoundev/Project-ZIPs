# Lesson 02: Loading Data and Creating X, y

**Lesson ID:** lesson-02
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Use `pd.read_csv()` to load a CSV file using a pathlib path
- Create a feature DataFrame X using double brackets `[[]]`
- Create a target Series y using single brackets `[]`
- Explain the critical difference between `df["col"]` (Series) and `df[["col"]]` (DataFrame)
- Verify shapes are correct for scikit-learn input

## Prerequisites
- Lesson 01: Imports, backend, and path setup complete

## Concept Explanation

### Loading data with pandas
main.py loads the lemonade dataset with a single line:

```python
df = pd.read_csv(DATA / "lemonade_days.csv")
```

The result, `df`, is a **DataFrame** — pandas' primary data structure for tabular data. It has rows (one per observation) and columns (one per variable).

The path `DATA / "lemonade_days.csv"` uses pathlib's `/` operator to join the data directory path with the filename. This is equivalent to `"data/lemonade_days.csv"` as a string, but works correctly on all operating systems.

### Feature (X) vs Target (y)
In machine learning:
- **Features (X)** are the input variables — the known quantities we use to make predictions. For this project, temperature is the feature.
- **Target (y)** is the output variable — the unknown we want to predict. For this project, cups sold is the target.

### The critical difference: single vs double brackets
This is one of the most common sources of confusion and errors in pandas:

| Syntax | Returns | Dimensions | Used For |
|---|---|---|---|
| `df["temperature_c"]` | Series | 1D `(n,)` | Target variable (y) |
| `df[["temperature_c"]]` | DataFrame | 2D `(n, 1)` | Feature matrix (X) |

**Why does this matter?** scikit-learn's `fit()` method expects:
- **X** to have shape `(n_samples, n_features)` — a 2D array/DataFrame
- **y** to have shape `(n_samples,)` — a 1D array/Series

If you use single brackets for X, you get a 1D Series and sklearn will raise:
```
ValueError: Found input variables with inconsistent numbers of features
```

### Why does X need to be 2D?
Even though temperature is a single feature, sklearn's estimators are designed to handle multiple features simultaneously. A 2D structure `(n_samples, n_features)` works whether you have 1 feature or 10 features. When you have only 1 feature, the shape is `(16, 1)` — 16 samples, 1 feature.

## Relevant Code (from main.py, lines 29-31)
```python
df = pd.read_csv(DATA / "lemonade_days.csv")
X = df[["temperature_c"]]   # double brackets → DataFrame (2D)
y = df["cups_sold"]          # single brackets → Series (1D)
```

### Line-by-line explanation
- `df = pd.read_csv(DATA / "lemonade_days.csv")` — reads the CSV file; `df` now has shape (16, 3) with columns day, temperature_c, cups_sold
- `X = df[["temperature_c"]]` — selects one column as a DataFrame (2D, shape (16, 1)); called "feature matrix"
- `y = df["cups_sold"]` — selects one column as a Series (1D, shape (16,)); called "target vector"

## Worked Example

```python
import pandas as pd
from pathlib import Path

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"

# Step 1: Load the data
df = pd.read_csv(DATA / "lemonade_days.csv")
print(f"df.shape: {df.shape}")  # (16, 3)

# Step 2: Extract X and y with correct bracket types
X = df[["temperature_c"]]   # DataFrame — 2D
y = df["cups_sold"]          # Series — 1D

print(f"X.shape: {X.shape}")       # (16, 1)
print(f"y.shape: {y.shape}")       # (16,)
print(f"type(X): {type(X)}")       # <class 'pandas.DataFrame'>
print(f"type(y): {type(y)}")       # <class 'pandas.Series'>

# Step 3: Verify the data looks correct
print(f"\nFirst 3 X values:\n{X.head(3)}")
print(f"\nFirst 3 y values:\n{y.head(3)}")
```

**Expected output:**
```
df.shape: (16, 3)
X.shape: (16, 1)
y.shape: (16,)
type(X): <class 'pandas.DataFrame'>
type(y): <class 'pandas.Series'>

First 3 X values:
   temperature_c
0           23.3
1           30.0
2           31.8

First 3 y values:
0    29
1    38
2    42
Name: cups_sold, dtype: int64
```

## Step-by-Step Student Instructions

1. **Load the CSV** — Use `df = pd.read_csv(DATA / "lemonade_days.csv")` with the path setup from Lesson 01
2. **Verify the load** — Print `df.shape` (should be `(16, 3)`) and `df.columns` (should show day, temperature_c, cups_sold)
3. **Create X** — Type `X = df[["temperature_c"]]` using **double brackets**
4. **Create y** — Type `y = df["cups_sold"]` using **single brackets**
5. **Verify types and shapes** — Print `type(X)`, `X.shape`, `type(y)`, `y.shape`
6. **Confirm the difference** — Also print `df["temperature_c"].shape` to see it gives `(16,)` instead of `(16, 1)`

## Expected Output or Observable Behaviour

- `df.shape` → `(16, 3)`
- `X.shape` → `(16, 1)` (2D DataFrame)
- `y.shape` → `(16,)` (1D Series)
- `type(X)` → `pandas.DataFrame`
- `type(y)` → `pandas.Series`
- `df["temperature_c"].shape` → `(16,)` (1D — wrong for sklearn features!)

## Practical Exercises

**Exercise 2.2:** Load `data/lemonade_days.csv` and print shape and columns.
**Exercise 2.2b:** Create X as DataFrame from temperature_c and y from cups_sold. Print types and shapes.
**Exercise 2.2c:** Try creating X with single brackets and observe the shape difference.

## Common Mistakes and Debugging

| Mistake | Cause | Fix |
|---|---|---|
| Wrong filename | Typo in the path | Use `lemonade_days.csv` exactly as in main.py line 29 |
| `KeyError` on column access | Column name typo | Check exact spelling: `temperature_c` (lowercase, underscores) |
| `ValueError: inconsistent numbers of features` | Used `df["col"]` (Series) for X | Use `df[["col"]]` (DataFrame) for X |
| Empty DataFrame | File path wrong | Verify `DATA` points to the correct directory |
| Data loaded as strings | CSV has text in numeric columns | The lemonade dataset is clean; if you see this, check your CSV file |

## Best Practices and Security Considerations

- **Always check shapes after data prep**: `X.shape` and `y.shape` are quick sanity checks
- **Use the right bracket type**: Double brackets for features (DataFrame), single brackets for target (Series)
- **Use pathlib paths**: Consistent with main.py's approach
- **No security risk**: Reading a local CSV is safe; pandas does not execute code embedded in CSV files

## Summary

The dataset loads as a (16, 3) DataFrame. We create X as a 2D DataFrame using `df[["temperature_c"]]` (double brackets) because sklearn requires 2D features. We create y as a 1D Series using `df["cups_sold"]` (single brackets) because targets are 1D. The difference between `[]` and `[[]]` is a frequent source of errors and is critical to get right.

## Knowledge-check Questions
1. What is the shape of X and y?
2. Why double brackets for X and single for y?
3. What error occurs if you use single brackets for X?

## References
- pandas `read_csv` documentation: https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html
- pandas indexing documentation: https://pandas.pydata.org/docs/user_guide/indexing.html
- main.py lines 29-31
- scikit-learn API: https://scikit-learn.org/stable/developers/develop.html