# Lesson 03: Train/Test Split

**Lesson ID:** lesson-03
**Module:** module-02
**Duration:** 20-25 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain why we split data into training and test sets
- Use `train_test_split()` with the correct parameters for this project
- Interpret `test_size=0.25` and `random_state=42`
- Understand what happens to the data during the split
- Identify data leakage and its consequences

## Prerequisites
- Lesson 02: Data loaded, X and y created with correct shapes

## Concept Explanation

### Why split data at all?
The fundamental challenge in machine learning is: **how do we know our model will work on new, unseen data?**

If we train a model on all our data and then test it on that same data, we get an **overly optimistic** estimate of performance. The model has already "seen" every data point during training, so of course it does well. This is called **overfitting to the training data**.

The solution is the **train/test split**:
- **Training set** (75% of data): Used to train the model — it learns the pattern
- **Test set** (25% of data): Held out completely during training — used only for final evaluation

The test set simulates "new, unseen data." If the model performs well on the test set, we have confidence it will generalize to real-world data.

### The train_test_split function
scikit-learn's `train_test_split` randomly shuffles and divides the data:

```python
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)
```

**Parameters:**
- `X, y`: The data to split — both must be passed together to maintain alignment
- `test_size=0.25`: 25% goes to test, 75% goes to training
- `random_state=42`: Seeds the random shuffle for reproducibility

### What test_size=0.25 means
- Of the 16 data points: 12 go to training, 4 go to testing
- 75% training / 25% testing is a common default for small datasets
- Larger datasets can use smaller test fractions; very small datasets might use cross-validation instead

### What random_state=42 means
`train_test_split` shuffles the data before splitting. The `random_state` parameter seeds this shuffle. With `random_state=42`, everyone who runs this code gets the **exact same** 12 training points and 4 test points. Without it, each run could produce different splits, making results non-reproducible.

The specific value 42 is arbitrary (it's a reference to "The Hitchhiker's Guide to the Galaxy"). What matters is that it's **fixed** — any fixed integer works.

### What goes wrong: data leakage
**Data leakage** occurs when information from the test set leaks into the training process. A common example:

```python
# WRONG — this is data leakage:
model.fit(X_test, y_test)  # Training on test data!
mae = mean_absolute_error(y_test, model.predict(X_test))  # Evaluating on training data!
```

This gives artificially good metrics that won't reflect real-world performance.

## Relevant Code (from main.py, lines 33-35)
```python
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)
```

### Line-by-line explanation
- `train_test_split(X, y, ...)` — splits both X and y simultaneously, ensuring rows stay aligned
- `test_size=0.25` — 25% of data (4 rows) goes to testing
- `random_state=42` — seeds the random shuffle so results are reproducible
- The function returns four objects in order: X_train, X_test, y_train, y_test

## Worked Example

```python
import pandas as pd
from sklearn.model_selection import train_test_split

# Load and prepare data
df = pd.read_csv("data/lemonade_days.csv")
X = df[["temperature_c"]]
y = df["cups_sold"]

# Split with parameters from main.py
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)

# Check the results
print(f"Total samples: {len(X)}")              # 16
print(f"Training samples: {len(X_train)}")      # 12
print(f"Test samples: {len(X_test)}")           # 4
print(f"\nTraining temperatures:\n{X_train.values.ravel()}")
print(f"\nTest temperatures:\n{X_test.values.ravel()}")
print(f"\nTraining cups:\n{y_train.values}")
print(f"\nTest cups:\n{y_test.values}")

# Verify reproducibility
X_train2, X_test2, y_train2, y_test2 = train_test_split(
    X, y, test_size=0.25, random_state=42
)
print(f"\nReproducible (same test set): {X_test.equals(X_test2)}")  # True
```

**Expected output (values may vary slightly in formatting):**
```
Total samples: 16
Training samples: 12
Test samples: 4

Training temperatures:
[30.0 23.3 23.7 37.7 22.3 32.2 27.6 32.9 26.0 23.5 35.2 23.3]

Test temperatures:
[21.5 30.0 38.1 26.0]

Training cups:
[38 29 24 48 26 40 33 35 32 30 48 24]

Test cups:
[25 38 48 32]

Reproducible: True
```

## Step-by-Step Student Instructions

1. **Prepare X and y** — Ensure you have `X = df[["temperature_c"]]` and `y = df["cups_sold"]` from Lesson 02
2. **Import train_test_split** — `from sklearn.model_selection import train_test_split`
3. **Call the function** — `X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)`
4. **Check sizes** — Print `len(X_train)` and `len(X_test)` to confirm 12 and 4
5. **Check alignment** — Print `X_test` and `y_test` together to see they correspond to the same days
6. **Verify reproducibility** — Run the split twice and confirm test sets are identical

## Expected Output or Observable Behaviour

- `len(X_train)` → 12, `len(X_test)` → 4
- `len(X_train) + len(X_test)` → 16 (all data accounted for)
- Calling `train_test_split` with the same `random_state` twice produces identical splits
- The test set includes some of the hottest days (35-38°C range), which is good for testing predictions

## Practical Exercises

**Exercise 2.3:** Explain why we split into train and test sets.
**Exercise 2.3b:** What is the test set percentage, and how many rows does that give?
**Exercise 2.3c:** What happens if you change `random_state` to a different number?
**Exercise 2.3d:** What is data leakage, and why is it harmful?

## Common Mistakes and Debugging

| Mistake | Cause | Fix |
|---|---|---|
| Different splits each run | Forgot `random_state` | Add `random_state=42` |
| Mismatched X and y after split | Split X and y separately | Pass both to one `train_test_split(X, y, ...)` call |
| Test set too small | Used test_size=0.1 | main.py uses 0.25; use that for consistency |
| Training on test data | Passing X_test to fit() | Always fit on X_train, y_train only |
| Wrong parameter name | Used `split=0.25` or `train_size` | Use `test_size=0.25` |

## Best Practices and Security Considerations
- **Always use random_state**: Ensures reproducible results for debugging and reporting
- **Keep X and y together in split**: Passing them to one `train_test_split` call maintains row alignment
- **Never look at test data during training**: Resist the temptation to tune hyperparameters based on test performance
- **Use appropriate split ratios**: 75/25 is standard for small datasets; larger datasets can use 90/10 or 80/20
- **No security risk**: Splitting data is a pure data manipulation task

## Summary

The train/test split separates 16 data points into 12 for training and 4 for testing. `random_state=42` ensures the same split every time. Training data teaches the model; test data evaluates it. Splitting X and y in the same call maintains alignment. Never train on test data — it's data leakage that invalidates your evaluation.

## Knowledge-check Questions
1. What is test_size=0.25?
2. What does random_state=42 do?
3. How many rows go to training, and how many to testing?
4. Why can't we split X and y separately?

## References
- scikit-learn train_test_split: https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html
- Cross-validation vs train/test split: https://scikit-learn.org/stable/common_pitfalls.html
- main.py line 34: `test_size=0.25, random_state=42`