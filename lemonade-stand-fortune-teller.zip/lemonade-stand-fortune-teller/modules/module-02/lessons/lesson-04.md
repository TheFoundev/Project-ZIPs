# Lesson 04: Integrating Data Preparation and Model Training

**Lesson ID:** lesson-04
**Module:** module-02
**Duration:** 30-35 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Combine data loading, feature/target separation, and train/test splitting into one coherent script segment
- Trace the flow of variables from `pd.read_csv` through `train_test_split`
- Explain why each variable (X, y, X_train, X_test, y_train, y_test) exists and what it represents
- Write a complete data preparation section that mirrors main.py's approach
- Debug common variable confusion errors

## Prerequisites
- Lesson 01: Imports and Setup in main.py
- Lesson 02: Loading Data and Creating X, y
- Lesson 03: Train/Test Split

## Concept Explanation

### The data preparation pipeline as interconnected stages

The first 50 lines of main.py implement a data preparation pipeline with five interconnected stages. Each stage produces variables that the next stage consumes:

```
CSV file (lemonade_days.csv)
    ↓ pd.read_csv
DataFrame (df) — all data
    ↓ df[["temperature_c"]] / df["cups_sold"]
X (features), y (target)
    ↓ train_test_split(X, y, ...)
X_train, X_test, y_train, y_test — four subsets
```

### Why the variable naming convention?
- **Uppercase X**: Convention in scikit-learn — the feature matrix is 2D (samples × features), capital X signals "matrix"
- **Lowercase y**: The target vector is 1D (one value per sample), lowercase y signals "vector"
- **Suffix _train / _test**: Indicates which subset the data came from

### The train/test split parameters
- `test_size=0.25`: 25% of data goes to testing (4 out of 16 rows), 75% to training (12 out of 16 rows)
- `random_state=42`: Sets the random seed so the same split is produced every time you run the code. Without it, each run could split the data differently, making results non-reproducible.

### What happens during the split?
`train_test_split` randomly shuffles the data and then takes the first 75% for training and the last 25% for testing. Because `random_state=42` is fixed, everyone who runs this code gets the same training/test rows.

## Relevant Code (from main.py, lines 29-38)
```python
# Stage 1: Load data
df = pd.read_csv(DATA / "lemonade_days.csv")

# Stage 2: Separate features and target
X = df[["temperature_c"]]   # 2D — DataFrame with one column
y = df["cups_sold"]          # 1D — Series

# Stage 3: Split into train and test
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)
```

### Line-by-line explanation
- `df = pd.read_csv(DATA / "lemonade_days.csv")` — reads the CSV file into a DataFrame with 16 rows and 3 columns (`day`, `temperature_c`, `cups_sold`)
- `X = df[["temperature_c"]]` — extracts temperature as a 2D DataFrame (shape `(16, 1)`) — sklearn requires 2D features
- `y = df["cups_sold"]` — extracts cups sold as a 1D Series (shape `(16,)`) — the values to predict
- `train_test_split(X, y, test_size=0.25, random_state=42)` — shuffles and splits:
  - `X_train`: 12 rows of temperature (training features)
  - `X_test`: 4 rows of temperature (test features)
  - `y_train`: 12 rows of cups sold (training targets)
  - `y_test`: 4 rows of cups sold (test targets)

## Worked Example: Tracing Variables After Each Stage

Let's trace what happens with the actual 16-row dataset:

**After Stage 1 (load):**
- `df.shape` → `(16, 3)` — 16 days, 3 columns
- `df.columns` → `['day', 'temperature_c', 'cups_sold']`
- `df.head()` →
  ```
     day  temperature_c  cups_sold
  0    1           23.3         29
  1    2           30.0         38
  ...
  ```

**After Stage 2 (separate):**
- `X.shape` → `(16, 1)` — still 16 rows, but only 1 column (temperature)
- `y.shape` → `(16,)` — 16 target values

**After Stage 3 (split with test_size=0.25, random_state=42):**
- `X_train.shape` → `(12, 1)` — 12 training samples
- `X_test.shape` → `(4, 1)` — 4 test samples
- `y_train.shape` → `(12,)` — 12 training targets
- `y_test.shape` → `(4,)` — 4 test targets

## Step-by-Step Student Instructions

1. **Set up imports and paths** — Copy the import block and path setup from Lesson 01
2. **Load the data** — `df = pd.read_csv(DATA / "lemonade_days.csv")`
3. **Verify the load** — Print `df.shape` and `df.columns` to confirm 16 rows and the correct columns
4. **Create X and y** — `X = df[["temperature_c"]]` and `y = df["cups_sold"]`
5. **Verify shapes** — Print `X.shape` and `y.shape` to confirm correct dimensions
6. **Split the data** — `X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)`
7. **Verify split shapes** — Print all four shapes to confirm 12 train and 4 test

## Expected Output or Observable Behaviour

```python
print(df.shape)          # (16, 3)
print(X.shape)           # (16, 1)
print(y.shape)           # (16,)
print(X_train.shape)     # (12, 1)
print(X_test.shape)      # (4, 1)
print(y_train.shape)     # (12,)
print(y_test.shape)      # (4,)
```

## Practical Exercise (with Success Criteria)

**Task:** Write a script that loads the lemonade data, creates X and y, splits the data, and prints all shapes. Run it and verify the output matches the expected shapes above.

**Success Criteria:**
- [ ] CSV loads without errors from the correct path
- [ ] `X` is a DataFrame (2D) using double brackets
- [ ] `y` is a Series (1D) using single brackets
- [ ] `train_test_split` uses `test_size=0.25, random_state=42`
- [ ] Training set has 12 rows, test set has 4 rows
- [ ] All shape prints match expected values
- [ ] Running the script twice produces the same splits (reproducible)

## Common Mistakes and Troubleshooting

| Mistake | Cause | Fix |
|---|---|---|
| `KeyError: 'temperature_c'` | Column name has a typo | Copy the exact column name from `df.columns` |
| X has shape `(16,)` instead of `(16, 1)` | Used single brackets `df["temperature_c"]` | Use double brackets `df[["temperature_c"]]` |
| Split gives different results each run | Forgot `random_state` | Add `random_state=42` |
| `ValueError: Found input variables with inconsistent numbers of features` | X and y have different lengths | Ensure both come from the same `df` on the same split call |
| Training set has wrong size | Did not use `test_size=0.25` | Pass `test_size=0.25` explicitly |

## Best Practices and Security Considerations

- **Always verify shapes after loading**: `df.shape` is a quick sanity check
- **Use `random_state` for reproducibility**: In production ML, this is essential for debugging and auditing
- **Keep X and y aligned**: Never split them separately — pass both to one `train_test_split` call
- **Use double brackets for features**: This is a common source of confusion — sklearn needs 2D input
- **No security risk**: Reading a local CSV file is safe; no code execution from file contents

## Summary

The data preparation pipeline flows: load CSV → separate X (2D features) and y (1D targets) → split into train/test sets. With 16 rows and `test_size=0.25`, we get 12 training and 4 test samples. The `random_state=42` ensures the same split every time. This prepared data is ready to be fed into `LinearRegression.fit()`.

## Knowledge Check

1. What is the shape of X after separation, and why is it 2D?
2. How many rows go to training, and how many to testing?
3. What does `random_state=42` ensure?
4. Why must we split X and y together in one `train_test_split` call?

## References

- pandas `read_csv` documentation: https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html
- scikit-learn `train_test_split`: https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html
- main.py lines 29-35