# Lesson 01: Imports, Backend, and Path Setup

**Lesson ID:** lesson-01
**Module:** module-02
**Duration:** 20-25 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain the purpose of each import in main.py
- Understand why the matplotlib Agg backend must be set before importing pyplot
- Use pathlib to construct cross-platform file paths
- Create output directories safely with `mkdir(exist_ok=True)`
- Trace how main.py resolves its data and output paths

## Prerequisites
- Module 01 (basic understanding of the lemonade stand problem)
- Basic Python knowledge (imports, variables)

## Concept Explanation

### Import order matters for matplotlib
main.py begins with a specific sequence of imports. The order is critical:

```python
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
```

**Why this order?** When you import `matplotlib.pyplot`, matplotlib automatically selects a default backend based on what's available on your system. If a display is available, it selects an interactive backend (like TkAgg). If not, it selects a non-interactive one. Once pyplot is imported, the backend is "locked in" and calling `matplotlib.use()` afterward may print a warning and silently fail.

By calling `matplotlib.use("Agg")` **before** `import matplotlib.pyplot as plt`, we force the non-interactive Agg backend, which renders to files without opening a display. This is essential for running scripts on servers, in CI pipelines, or in any environment without a graphical display.

### What is the Agg backend?
The Agg backend is a non-interactive backend that:
- Renders figures directly to image files (PNG, PDF, etc.)
- Does NOT open a window or require a display
- Is always available (pure C implementation)
- Is ideal for automated scripts, servers, and headless environments

### pathlib vs string paths
main.py uses the `pathlib` module instead of string concatenation:

```python
from pathlib import Path
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
```

This approach has several advantages:
- **Cross-platform**: Uses `/` operator (works on Windows, macOS, Linux)
- **Absolute paths**: `__file__` always points to the script's location, and `.resolve()` converts to an absolute path
- **Readable**: `DATA / "lemonade_days.csv"` is clearer than `"data/lemonade_days.csv"`
- **Safe**: No manual path separator handling (no `os.path.join` needed)

### Understanding `__file__`
In Python, `__file__` is a special variable that contains the path to the currently running script. When main.py runs, `__file__` is the path to `main.py`. Calling `.resolve().parent` gives the directory containing main.py — which is the `02_lemonade_stand` directory. This means `DATA` and `OUT` are always relative to the project root, regardless of where you run the command from.

## Relevant Code (from main.py, lines 10-25)
```python
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)
```

### Line-by-line explanation
- `from pathlib import Path` — imports the Path class for path manipulation
- `import matplotlib` — imports the core matplotlib package (does NOT select a backend yet)
- `matplotlib.use("Agg")` — sets the non-interactive Agg backend BEFORE pyplot is imported
- `import matplotlib.pyplot as plt` — imports the plotting interface (backend is now locked as Agg)
- `import numpy as np` — numpy for numerical operations (used for linspace)
- `import pandas as pd` — pandas for data loading and manipulation
- `from sklearn.linear_model import LinearRegression` — the regression model class
- `from sklearn.metrics import mean_absolute_error, r2_score` — evaluation metrics
- `from sklearn.model_selection import train_test_split` — for splitting data
- `BASE = Path(__file__).resolve().parent` — the project root directory
- `DATA = BASE / "data"` — the data subdirectory path
- `OUT = BASE / "outputs"` — the output subdirectory path
- `OUT.mkdir(exist_ok=True)` — creates outputs/ if it doesn't exist; no error if it already exists

## Worked Example

```python
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)

print(f"BASE: {BASE}")
print(f"CSV exists: {(DATA / 'lemonade_days.csv').exists()}")
print(f"OUT exists: {OUT.exists()}")
```

**Expected output:**
```
BASE: /home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/02_lemonade_stand
CSV exists: True
OUT exists: True
```

## Step-by-Step Student Instructions

1. **Add the imports in the correct order** — Copy the exact import block from main.py. Notice that `matplotlib.use("Agg")` is on its own line between `import matplotlib` and `import matplotlib.pyplot as plt`.
2. **Set up paths** — Copy the BASE, DATA, and OUT lines. These will resolve to the project directory.
3. **Create the outputs directory** — Run the script to ensure `OUT.mkdir(exist_ok=True)` creates the directory.
4. **Verify the CSV path** — Add `print((DATA / "lemonade_days.csv").exists())` and confirm it prints `True`.
5. **Experiment** — Try changing `BASE` to a different path and see how it affects `DATA` and `OUT`.

## Expected Output or Observable Behaviour

- `BASE` resolves to the `02_lemonade_stand` project directory
- `DATA` resolves to `.../02_lemonade_stand/data`
- `OUT` resolves to `.../02_lemonade_stand/outputs`
- The `outputs/` directory is created if it did not exist
- `(DATA / "lemonade_days.csv").exists()` returns `True`

## Practical Exercise (with Success Criteria)

**Task:** Create a new Python script that replicates main.py's import block and path setup. Add print statements to verify that the data path resolves correctly and the CSV file exists. Then create the outputs directory.

**Success Criteria:**
- [ ] Import block matches main.py exactly (Agg before pyplot)
- [ ] `matplotlib.use("Agg")` is on its own line between the two matplotlib imports
- [ ] `BASE = Path(__file__).resolve().parent` is present
- [ ] `DATA = BASE / "data"` is present
- [ ] `OUT = BASE / "outputs"` is present
- [ ] `OUT.mkdir(exist_ok=True)` is present
- [ ] Running the script prints that the CSV file exists
- [ ] The `outputs/` directory is created (check with `ls`)

## Common Mistakes and Troubleshooting

| Mistake | Cause | Fix |
|---|---|---|
| `ImportError: No module named 'matplotlib'` | Package not installed | Run `pip install matplotlib` |
| Plot window opens during script run | Backend set after pyplot import | Move `matplotlib.use("Agg")` before `import matplotlib.pyplot` |
| `FileNotFoundError` when saving | OUT directory not created | Ensure `OUT.mkdir(exist_ok=True)` is called before saving |
| Wrong path resolution | Using `.` instead of `__file__` | Use `Path(__file__).resolve().parent` as main.py does |
| `TypeError: unsupported operand type(s) for /` | Using string instead of Path | Ensure `BASE` is a `Path` object before using `/` operator |

## Best Practices and Security Considerations

- **Import order is functional, not stylistic**: The matplotlib backend must be set before pyplot import — this is a correctness requirement
- **Use pathlib over string concatenation**: It is safer, more readable, and cross-platform
- **Use `__file__` for script-relative paths**: Never hardcode absolute paths or use `os.getcwd()`
- **`exist_ok=True` prevents crashes**: If the directory already exists, `mkdir` will not fail
- **No security risk**: This setup only creates local directories and reads local files

## Summary

The import block and path setup in main.py establishes the foundation for the entire script. The Agg backend is set before pyplot to enable non-interactive plotting. Paths are constructed using pathlib's `Path(__file__).resolve().parent`, which resolves relative to the script's location. The outputs directory is created safely with `mkdir(exist_ok=True)`.

## Knowledge Check

1. Why must `matplotlib.use("Agg")` come before `import matplotlib.pyplot as plt`?
2. What does `Path(__file__).resolve().parent` represent?
3. What is the purpose of `exist_ok=True` in `mkdir()`?
4. Why use pathlib's `/` operator instead of string concatenation for paths?

## References

- Python pathlib documentation: https://docs.python.org/3/library/pathlib.html
- Matplotlib backends: https://matplotlib.org/stable/users/explain/figure/backends.html
- main.py lines 10-25 (imports and path setup)