# Lesson 01: Running main.py End-to-End

**Lesson ID:** lesson-01
**Module:** module-06
**Duration:** 20-25 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Navigate to the correct project directory in a terminal
- Install all required Python packages using pip
- Run main.py with the correct Python command
- Interpret the console output as a verification of correct execution
- Identify common errors when running Python scripts and resolve them

## Prerequisites
- All previous modules (understanding of data loading, model training, prediction, evaluation, and plotting)
- A working Python 3 installation
- Basic familiarity with the command line (opening a terminal)

## Concept Explanation

### The running environment
main.py is a standard Python script. To run it, you need:
1. **Python 3** — the interpreter that executes the code
2. **Required packages** — pandas, numpy, matplotlib, scikit-learn
3. **Correct working directory** — the script uses relative paths via `Path(__file__).resolve().parent`, so you must be in the project directory (or run from anywhere, since `BASE` is computed from `__file__`)
4. **Data file present** — `data/lemonade_days.csv` must exist at `BASE / "data" / "lemonade_days.csv"`

### Why install packages first?
Python does not include third-party libraries by default. When main.py runs `import pandas`, Python looks for the `pandas` package in your environment. If it is not installed, you get a `ModuleNotFoundError`. Installing packages with pip before running avoids these import errors.

### The command to run
```bash
python main.py
```

The `python` command invokes the Python interpreter, and `main.py` is the script file. Inside the script, the `if __name__ == "__main__":` block at the bottom calls the `main()` function automatically.

## Step-by-Step Instructions

### Step 1: Navigate to the project directory
```bash
cd beginner-projects-main/AI-ML\ Beginners/projects/02_lemonade_stand
```

If your working directory is different, adjust the path accordingly. The backslash-space escapes the space in "AI-ML Beginners".

### Step 2: Verify Python is installed
```bash
python --version
```

You should see something like `Python 3.x.x`. If not, install Python 3 first.

### Step 3: Install required packages
```bash
pip install pandas numpy matplotlib scikit-learn
```

This installs:
- **pandas** — for loading and manipulating CSV data
- **numpy** — for numerical operations (used in `np.linspace`)
- **matplotlib** — for creating and saving plots
- **scikit-learn** — for `LinearRegression`, `train_test_split`, and evaluation metrics

### Step 4: Verify packages are installed
```bash
python -c "import pandas, numpy, matplotlib, sklearn; print('All packages ready')"
```

### Step 5: Run the project
```bash
python main.py
```

### Step 6: Observe the output
You should see console output that begins with a separator line, then the model equation, evaluation metrics, and the 35°C prediction.

## Expected Output

When main.py runs successfully, the console displays:

```
============================================================
THE LEMONADE STAND FORTUNE TELLER
============================================================
Model: cups = 1.58 x temperature + -10.66
Meaning: each extra 1 C is associated with about 1.58 more cups.
Mean absolute error: 2.16 cups
R-squared: 0.90
Prediction for 35 C: 44.6 cups

Saved: outputs/lemonade_regression.png, outputs/prediction.txt
Try this: add a rainy-day column and see whether the line changes.
```

**Explanation of each line:**
- `Model: cups = 1.58 x temperature + -10.66` — the learned linear equation: for every 1°C increase, ~1.58 more cups are sold; at 0°C, the model predicts -10.66 cups (a theoretical intercept)
- `Meaning: each extra 1 C is associated with about 1.58 more cups.` — plain-language interpretation of the slope
- `Mean absolute error: 2.16 cups` — on average, predictions are off by about 2.16 cups on the test set
- `R-squared: 0.90` — the model explains 90% of the variance in cups sold using temperature
- `Prediction for 35 C: 44.6 cups` — the model predicts 44.6 cups sold at 35°C
- `Saved: ...` — confirms both output files were written to the `outputs/` directory

## Practical Exercise (with Success Criteria)

**Task:** Navigate to the project directory, install all dependencies, and run main.py. Capture the full console output and confirm both output files were created.

**Success Criteria:**
- [ ] Terminal shows the correct Python version (3.x)
- [ ] All four packages (pandas, numpy, matplotlib, scikit-learn) import successfully
- [ ] `python main.py` runs without errors
- [ ] Console output matches the expected format above
- [ ] `outputs/lemonade_regression.png` file exists
- [ ] `outputs/prediction.txt` file exists and its contents match the console output values

## Common Mistakes and Troubleshooting

| Mistake | Cause | Fix |
|---|---|---|
| `ModuleNotFoundError: No module named 'pandas'` | Package not installed | Run `pip install pandas` (or all packages at once) |
| `FileNotFoundError: ... lemonade_days.csv` | Running from wrong directory | Ensure you are in the `02_lemonade_stand` directory, or run `python /full/path/to/main.py` |
| `'python' is not recognized` | Python not in PATH | Try `python3` instead, or add Python to PATH |
| `Permission denied` on Linux/Mac | Script not executable | Run `python main.py` (not `./main.py`); or `chmod +x main.py` if using `./main.py` |
| Plot appears but no file saved | `fig.savefig` path issue | Check that `OUT = BASE / "outputs"` exists; `mkdir(exist_ok=True)` handles this |
| Different numbers than expected | Different version of scikit-learn | The random_state=42 and small dataset should produce consistent results; if not, check scikit-learn version |

## Best Practices and Security Considerations

- **Check requirements before running**: Verify all imports work before running the full script
- **Use virtual environments**: Create a venv (`python -m venv venv && source venv/bin/activate`) to isolate dependencies
- **Pin versions for reproducibility**: For production use, save exact versions with `pip freeze > requirements.txt`
- **No security risk**: main.py only reads local data files and writes local output files; it does not make network connections or access sensitive resources
- **Avoid running untrusted scripts**: Only run code you understand; inspect `main.py` before executing

## Summary

Running main.py requires Python 3, the four required packages, and the data file in the correct location. The console output confirms the model trained correctly, the metrics are reasonable, and the outputs were saved. The script runs entirely locally with no external dependencies.

## Knowledge Check

1. What command runs the project?
2. Which four packages must be installed?
3. What does the `try this` message at the end suggest?
4. Why does main.py use `Path(__file__).resolve().parent`?

## References

- Python command-line documentation: https://docs.python.org/3/using/cmdline.html
- pip installation guide: https://pip.pypa.io/en/stable/installing/
- main.py docstring (lines 1-8)
- main.py `if __name__ == "__main__":` (line 86-87)