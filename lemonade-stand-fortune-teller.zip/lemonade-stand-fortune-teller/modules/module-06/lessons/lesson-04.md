# Lesson 04: Complete Pipeline Review and Troubleshooting

**Lesson ID:** lesson-04
**Module:** module-06
**Duration:** 25-30 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Trace the complete execution flow of main.py from start to finish
- Identify the order of operations and why each step depends on the previous one
- Recognize and fix the most common errors encountered when running the project
- Apply a systematic debugging approach when something goes wrong
- Verify that a successful run produces all expected outputs

## Prerequisites
- Module 06, Lessons 01-03 (running, reading output, verifying files)
- Understanding of the full data science workflow: load → split → train → predict → evaluate → visualize → save

## Concept Explanation

### The complete pipeline as a linear workflow
main.py is a linear script — each step depends on the previous one. The pipeline has nine stages:

1. **Imports and setup** — Load libraries, set backend, define paths
2. **Data loading** — Read the CSV file into a pandas DataFrame
3. **Feature/target separation** — Split into X (temperature) and y (cups sold)
4. **Train/test split** — Divide data into training and test sets
5. **Model training** — Fit LinearRegression on training data
6. **Evaluation and prediction** — Predict on test set, compute MAE and R², predict for 35°C
7. **Visualization** — Create scatter plot with regression line and prediction marker
8. **Save outputs** — Write PNG and prediction.txt to the outputs directory
9. **Final message** — Print confirmation of saved files and suggestion for extension

### Why the order matters
- You cannot train a model before splitting the data (you need to know which data to train on)
- You cannot evaluate before training (no model exists yet)
- You cannot plot before predicting (you need the prediction values to mark them)
- You cannot save before plotting (there's nothing to save)

### Common error patterns and their root causes

**`ModuleNotFoundError`**
- **Cause**: A required package is not installed
- **Fix**: `pip install pandas numpy matplotlib scikit-learn`

**`FileNotFoundError`** for the CSV
- **Cause**: The data file path is wrong, or you're running from the wrong directory
- **Fix**: main.py uses `Path(__file__).resolve().parent` for `BASE`, so it always finds data relative to the script's location. Verify `data/lemonade_days.csv` exists in the project directory.

**`ValueError`** about array shapes
- **Cause**: Passing 1D data where 2D is expected (e.g., using `df["temperature_c"]` instead of `df[["temperature_c"]]`)
- **Fix**: Ensure X uses double brackets `df[["temperature_c"]]` to create a DataFrame

**`AttributeError`** on model attributes
- **Cause**: Trying to access `model.coef_` before calling `model.fit()`
- **Fix**: Always call `fit()` before accessing `coef_` or `intercept_`

**Plot not showing prediction point**
- **Cause**: `zorder` not set high enough, or using wrong coordinates
- **Fix**: Ensure `zorder=5` on the scatter call for the prediction marker

## Pipeline Review

Full pipeline order in main.py:

```python
# Stage 1: Imports and setup (lines 10-25)
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)

# Stage 2: Data loading (line 29)
df = pd.read_csv(DATA / "lemonade_days.csv")

# Stage 3: Feature/target separation (lines 30-31)
X = df[["temperature_c"]]
y = df["cups_sold"]

# Stage 4: Train/test split (lines 33-35)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)

# Stage 5: Model training (lines 37-38)
model = LinearRegression()
model.fit(X_train, y_train)

# Stage 6: Evaluation and prediction (lines 39-47)
test_predictions = model.predict(X_test)
slope = float(model.coef_[0])
intercept = float(model.intercept_)
mae = mean_absolute_error(y_test, test_predictions)
r2 = r2_score(y_test, test_predictions)
hot_day = pd.DataFrame({"temperature_c": [35.0]})
hot_prediction = float(model.predict(hot_day)[0])

# Stage 7: Visualization (lines 59-74)
line_x = np.linspace(df["temperature_c"].min(), df["temperature_c"].max(), 100)
line_y = model.predict(pd.DataFrame({"temperature_c": line_x}))
fig, ax = plt.subplots(figsize=(7, 5))
ax.scatter(X_train, y_train, color="#e67e22", label="training days", s=55)
ax.scatter(X_test, y_test, color="#2c3e50", label="test days", s=55, marker="s")
ax.plot(line_x, line_y, color="#16a085", linewidth=2.5, label="learned trend line")
ax.scatter([35], [hot_prediction], color="#c0392b", s=140, marker="*", zorder=5,
           label="35 C prediction")
ax.set_xlabel("Temperature (C)")
ax.set_ylabel("Cups sold")
ax.set_title("Lemonade sales vs. temperature")
ax.legend()
ax.grid(alpha=0.25)

# Stage 8: Save outputs (lines 72-80)
fig.tight_layout()
fig.savefig(OUT / "lemonade_regression.png", dpi=150, bbox_inches="tight")
plt.close(fig)
with open(OUT / "prediction.txt", "w", encoding="utf-8") as handle:
    handle.write(f"Equation: cups = {slope:.4f} * temperature + {intercept:.4f}\n")
    handle.write(f"Prediction at 35 C: {hot_prediction:.2f} cups\n")
    handle.write(f"Mean absolute error: {mae:.2f}\n")
    handle.write(f"R-squared: {r2:.2f}\n")

# Stage 9: Final message (lines 82-85)
print("\nSaved: outputs/lemonade_regression.png, outputs/prediction.txt")
print("Try this: add a rainy-day column and see whether the line changes.")
```

## Worked Example: Troubleshooting a Failure

**Scenario:** You run main.py and get:
```
ValueError: Found input variables with inconsistent numbers of features
```

**Debugging steps:**
1. **Read the error message**: "inconsistent numbers of features" means the input data has a different number of columns than what the model was trained on.
2. **Trace the code**: The error likely occurs at `model.predict(hot_day)` or `model.predict(pd.DataFrame({"temperature_c": line_x}))`.
3. **Check the DataFrame shape**: The model was trained on `X = df[["temperature_c"]]` — a DataFrame with one column named `temperature_c`. If the prediction DataFrame has a different column name or shape, sklearn raises this error.
4. **Fix**: Ensure the prediction DataFrame uses the exact column name `temperature_c` and is 2D: `pd.DataFrame({"temperature_c": [35.0]})` or `pd.DataFrame({"temperature_c": line_x})`.

## Step-by-Step Student Instructions

### To reproduce the project from scratch:
1. Navigate to the project directory
2. Install all dependencies: `pip install pandas numpy matplotlib scikit-learn`
3. Verify the data file exists: `ls data/lemonade_days.csv`
4. Run: `python main.py`
5. Check outputs: `ls -la outputs/`
6. Read prediction.txt: `cat outputs/prediction.txt`
7. Open lemonade_regression.png in an image viewer

### To debug when something goes wrong:
1. **Read the full error message** — the last line usually tells you the problem
2. **Identify the stage** — which stage of the pipeline (1-9) is failing?
3. **Check the cause** — look at the "Common errors" table below
4. **Apply the fix** — make the specific change noted
5. **Re-run** — execute `python main.py` again
6. **Verify** — confirm the output matches expectations

## Expected Output or Observable Behaviour

A successful run produces:
- Console output with 6 key lines (header, equation, meaning, MAE, R², prediction)
- `outputs/lemonade_regression.png` — a valid PNG file (10-50KB)
- `outputs/prediction.txt` — 4 lines of text with the equation and metrics
- No error messages or tracebacks

## Practical Exercise (with Success Criteria)

**Task:** Perform a complete pipeline trace. For each of the 9 stages, identify the corresponding line numbers in main.py, the key variables created, and one thing that could go wrong at that stage.

**Success Criteria:**
- [ ] Stage 1 (imports/setup): Lines 10-25, variables: BASE, DATA, OUT
- [ ] Stage 2 (data loading): Line 29, variable: df
- [ ] Stage 3 (feature/target): Lines 30-31, variables: X, y
- [ ] Stage 4 (train/test split): Lines 33-35, variables: X_train, X_test, y_train, y_test
- [ ] Stage 5 (training): Lines 37-38, variable: model
- [ ] Stage 6 (evaluation): Lines 39-47, variables: test_predictions, slope, intercept, mae, r2, hot_prediction
- [ ] Stage 7 (visualization): Lines 59-74, variables: line_x, line_y, fig, ax
- [ ] Stage 8 (save): Lines 72-80, output files created
- [ ] Stage 9 (final message): Lines 82-85, confirmation printed
- [ ] For each stage, one potential error and its fix are documented

## Common Mistakes and Troubleshooting

| Issue | Stage Affected | Cause | Fix |
|---|---|---|---|
| `ModuleNotFoundError: No module named 'pandas'` | 1 | Package not installed | `pip install pandas` or install all: `pip install pandas numpy matplotlib scikit-learn` |
| `FileNotFoundError: lemonade_days.csv` | 2 | Data file missing or wrong path | Verify `data/lemonade_days.csv` exists in project directory |
| `ValueError: inconsistent numbers of features` | 3, 6, 7 | Single brackets used for X, or wrong column name in prediction | Use `df[["temperature_c"]]` and match column name exactly |
| Model not fitted error | 6 | `model.predict` called before `model.fit` | Ensure `fit()` is called first |
| `AttributeError: 'LinearRegression' object has no attribute 'coef_'` | 6 | Accessing coefficients before training | Call `fit()` before accessing `coef_` or `intercept_` |
| Plot file not created | 8 | `fig.savefig` path issue | Check `OUT` path; `OUT.mkdir(exist_ok=True)` should have created the directory |
| Prediction star not visible | 7 | Low zorder | Use `zorder=5` or higher |
| `outputs/` directory missing | 8 | `mkdir` not called | Ensure `OUT.mkdir(exist_ok=True)` is present |

## Best Practices and Security Considerations

- **Follow the pipeline order**: Never attempt steps out of sequence — each stage depends on the previous one
- **Verify data exists before training**: Always check `df.shape` and `df.columns` after loading
- **Use fixed random_state**: The `random_state=42` in `train_test_split` ensures reproducible results across runs
- **Evaluate on test data only**: Never compute MAE or R² on training data — this overestimates model quality
- **Close figures**: Always call `plt.close(fig)` after `savefig` to prevent memory leaks
- **No security risk**: main.py performs only local file I/O; no network access, no external APIs, no credential handling

## Summary

The lemonade stand pipeline is a 9-stage linear workflow: setup → load → separate features/target → split → train → evaluate/predict → visualize → save → confirm. Each stage builds on the previous one. The most common errors are missing packages, wrong file paths, and shape mismatches — all easily fixed by checking the stage-specific troubleshooting guide.

## Knowledge Check

1. List the 9 stages of the pipeline in order.
2. Which two variables must exist before you can call `model.fit()`?
3. Why must `train_test_split` happen before `model.fit()`?
4. What should you check first if you get `ValueError: inconsistent numbers of features`?

## References

- main.py complete code (lines 1-87)
- scikit-learn LinearRegression: https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html
- scikit-learn train_test_split: https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html
- Python pathlib documentation: https://docs.python.org/3/library/pathlib.html