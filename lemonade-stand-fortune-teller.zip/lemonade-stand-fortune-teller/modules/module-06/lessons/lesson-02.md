# Lesson 02: Reading and Interpreting Console Output

**Lesson ID:** lesson-02
**Module:** module-06
**Duration:** 20-25 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Match each line of console output to the corresponding line of code in main.py
- Explain the meaning of the model equation printed by main.py
- Interpret the `Meaning:` line as a real-world interpretation of the slope
- Understand what MAE tells us about prediction accuracy
- Interpret R² as the proportion of variance explained
- Explain the significance of the 35°C prediction

## Prerequisites
- Module 03 (training the model, extracting coefficients)
- Module 04 (predictions, MAE, R²)
- Module 06, Lesson 01 (running main.py)
- The actual console output from running the project

## Concept Explanation

### The console output as a model report card
When main.py runs successfully, it prints a structured summary of the model's performance. Each line corresponds to a specific computation from the code. Understanding this output is essential for interpreting whether the model works correctly and what the numbers mean.

### Breaking down the output

**Line 1-3: The header**
```
============================================================
THE LEMONADE STAND FORTUNE TELLER
============================================================
```
This is purely cosmetic — `print("=" * 60)` creates the separator, and `print("THE LEMONADE STAND FORTUNE TELLER")` prints the title. It makes the output readable.

**Line 4: The model equation**
```
Model: cups = 1.58 x temperature + -10.66
```
This comes from `print(f"Model: cups = {slope:.2f} x temperature + {intercept:.2f}")` (line 69). It shows the learned linear equation where:
- `1.58` is the slope (`model.coef_[0]`) — for every 1°C increase, sales increase by ~1.58 cups
- `-10.66` is the intercept (`model.intercept_`) — the theoretical prediction at 0°C

**Line 5: The meaning**
```
Meaning: each extra 1 C is associated with about 1.58 more cups.
```
From `print(f"Meaning: each extra 1 C is associated with about {slope:.2f} more cups.")` (line 70). This translates the mathematical slope into plain language.

**Line 6: Mean Absolute Error**
```
Mean absolute error: 2.16 cups
```
From `print(f"Mean absolute error: {mae:.2f} cups")` (line 71). MAE is the average absolute difference between predicted and actual cups sold on the test set. An MAE of 2.16 means predictions are, on average, off by about 2 cups.

**Line 7: R-squared**
```
R-squared: 0.90
```
From `print(f"R-squared: {r2:.2f}")` (line 72). R² = 0.90 means the model explains 90% of the variance in cups sold. The remaining 10% is unexplained (due to other factors not in the model, like weekends, promotions, or random variation).

**Line 8: Prediction for 35°C**
```
Prediction for 35 C: 44.6 cups
```
From `print(f"Prediction for 35 C: {hot_prediction:.1f} cups")` (line 73). This is the model's prediction for a day with temperature 35°C — it predicts 44.6 cups will be sold.

**Lines 9-10: Output confirmation**
```
Saved: outputs/lemonade_regression.png, outputs/prediction.txt
```
From `print("\nSaved: outputs/lemonade_regression.png, outputs/prediction.txt")` (line 107). This confirms both files were written.

## Relevant Code (from main.py, lines 67-74)
```python
print("=" * 60)
print("THE LEMONADE STAND FORTUNE TELLER")
print("=" * 60)
print(f"Model: cups = {slope:.2f} x temperature + {intercept:.2f}")
print(f"Meaning: each extra 1 C is associated with about {slope:.2f} more cups.")
print(f"Mean absolute error: {mae:.2f} cups")
print(f"R-squared: {r2:.2f}")
print(f"Prediction for 35 C: {hot_prediction:.1f} cups")
```

### Line-by-line explanation
- `print("=" * 60)` — prints a line of 60 equals-sign characters to separate the header
- `print(f"Model: cups = {slope:.2f} x temperature + {intercept:.2f}")` — uses an f-string to format the slope and intercept with 2 decimal places
- `print(f"Meaning: each extra 1 C is associated with about {slope:.2f} more cups.")` — uses the same slope value, formatted to 2 decimal places
- `print(f"Mean absolute error: {mae:.2f} cups")` — formats MAE to 2 decimal places with "cups" suffix
- `print(f"R-squared: {r2:.2f}")` — formats R² to 2 decimal places (no suffix needed)
- `print(f"Prediction for 35 C: {hot_prediction:.1f} cups")` — formats the prediction to 1 decimal place

## Worked Example

**Question:** If the slope were 2.00 and the intercept were -14.00, what would the output lines say?

**Step-by-step reasoning:**
1. Model equation: `cups = 2.00 x temperature + -14.00` → `print(f"Model: cups = {2.00:.2f} x temperature + {-14.00:.2f}")` → `Model: cups = 2.00 x temperature + -14.00`
2. Meaning: `each extra 1 C is associated with about 2.00 more cups.`
3. If MAE = 3.5 and R² = 0.85:
   - `Mean absolute error: 3.50 cups`
   - `R-squared: 0.85`
4. Prediction for 35°C using equation: `2.00 × 35 + (-14.00) = 70 - 14 = 56.0`
   - `Prediction for 35 C: 56.0 cups`

## Step-by-Step Student Instructions

1. **Run the project** — Execute `python main.py` and observe the full console output.
2. **Match lines to code** — For each printed line, find the corresponding `print()` statement in main.py (lines 67-74).
3. **Record the values** — Note the actual slope, intercept, MAE, R², and 35°C prediction.
4. **Verify the equation** — Manually check: does `slope × 35 + intercept ≈ hot_prediction`?
5. **Interpret each metric** — Write a one-sentence explanation of what each printed value tells you.

## Expected Output or Observable Behaviour

With the actual project data, the console output shows:

```
============================================================
THE LEMONADE STAND FORTUNE TELLER
============================================================
Model: cups = 1.58 x temperature + -10.66
Meaning: each extra 1 C is associated with about 1.58 more cups.
Mean absolute error: 2.16 cups
R-squared: 0.90
Prediction for 35 C: 44.6 cups
```

**Verification:** `1.58 × 35 + (-10.66) = 55.3 - 10.66 = 44.64` → rounds to 44.6 ✓

## Practical Exercise (with Success Criteria)

**Task:** Run main.py, capture the console output, and for each printed line, write:
a) The line number in main.py that produced it
b) The actual numeric value
c) A one-sentence interpretation of what it means

**Success Criteria:**
- [ ] All 8 output lines are captured
- [ ] Each line is matched to its source code line number
- [ ] Numeric values are recorded accurately
- [ ] The equation verification holds (slope × 35 + intercept ≈ prediction)
- [ ] Each metric is interpreted in plain language

## Common Mistakes and Troubleshooting

| Mistake | Cause | Fix |
|---|---|---|
| Confusing slope and intercept | Both are numbers; easy to swap mentally | Remember: slope is the coefficient of temperature, intercept is the constant term |
| Thinking R² = 0.90 means 90% accurate | R² is explained variance, not accuracy | R² measures how much of the variation is captured; higher is better but context matters |
| Interpreting negative intercept as error | Intercept at 0°C is not in the data range | The negative intercept is a mathematical artifact; predictions are valid within the data range |
| Not matching output to code | Skipping the code reference | Always check the `print()` statements in main.py lines 67-74 |

## Best Practices and Security Considerations

- **Always verify outputs**: Check that the printed equation produces the same prediction as the model
- **Document interpretations**: Write down what each metric means for the business problem
- **No security risk**: Console output only contains computed statistics; no sensitive data is printed

## Summary

The console output is a summary report of the model's performance. The equation shows the learned relationship, the slope interpretation connects math to real-world meaning, MAE tells us prediction accuracy in cups, R² tells us how much of the variation is explained, and the 35°C prediction demonstrates the model working on a new input. Each line maps to a specific `print()` statement in main.py.

## Knowledge Check

1. Which line of code produces the equation output?
2. What does the `Meaning:` line tell us that the equation does not?
3. How can you verify the prediction is correct using the equation?
4. Why is R² = 0.90 considered a good result for this model?

## References

- Python f-string documentation: https://docs.python.org/3/tutorial/format.html#f-strings
- main.py lines 67-74 (print statements)
- main.py lines 41-47 (variable computations)