# Lesson 03: Verifying the Output Files

**Lesson ID:** lesson-03
**Module:** module-06
**Duration:** 15-20 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Locate and inspect the `outputs/` directory created by main.py
- Read and interpret the contents of `prediction.txt`
- Match each line in `prediction.txt` to the corresponding `write()` call in main.py
- Verify that the console output values match the file output values
- Confirm that the PNG plot file was created and is a valid image file

## Prerequisites
- Module 06, Lesson 01 (running main.py)
- Module 06, Lesson 02 (reading console output)
- Understanding that main.py writes files to an `outputs/` directory

## Concept Explanation

### Why verify output files?
When a script runs and prints output to the console, the files it writes are the persisted evidence of its work. In a real data science or ML project, other tools, reports, or downstream processes may consume these files. Checking that they exist and contain the correct values is a critical validation step.

### The two output files
main.py produces two files:
1. **`outputs/lemonade_regression.png`** — a visual scatter plot with the regression line and 35°C prediction marker
2. **`outputs/prediction.txt`** — a text file with the model equation and metrics

Both files are written using pathlib paths: `OUT / "lemonade_regression.png"` and `OUT / "prediction.txt"`, where `OUT = BASE / "outputs"` and `BASE = Path(__file__).resolve().parent`.

### Reading prediction.txt
The file is written line by line in main.py:

```python
with open(OUT / "prediction.txt", "w", encoding="utf-8") as handle:
    handle.write(f"Equation: cups = {slope:.4f} * temperature + {intercept:.4f}\n")
    handle.write(f"Prediction at 35 C: {hot_prediction:.2f} cups\n")
    handle.write(f"Mean absolute error: {mae:.2f}\n")
    handle.write(f"R-squared: {r2:.2f}\n")
```

Each line contains the same values printed to the console, but with slightly different formatting (4 decimal places for the equation, 2 for others).

### Checking the PNG file
A valid PNG file starts with the magic bytes `\x89PNG`. You can verify it exists and has reasonable size with:
```bash
ls -la outputs/lemonade_regression.png
file outputs/lemonade_regression.png
```

## Relevant Code (from main.py, lines 100-105)
```python
with open(OUT / "prediction.txt", "w", encoding="utf-8") as handle:
    handle.write(f"Equation: cups = {slope:.4f} * temperature + {intercept:.4f}\n")
    handle.write(f"Prediction at 35 C: {hot_prediction:.2f} cups\n")
    handle.write(f"Mean absolute error: {mae:.2f}\n")
    handle.write(f"R-squared: {r2:.2f}\n")
```

### Line-by-line explanation
- `with open(OUT / "prediction.txt", "w", encoding="utf-8") as handle:` — opens the file for writing; the `with` statement ensures it is properly closed even if an error occurs
- `encoding="utf-8"` — ensures text is written with UTF-8 encoding (handles special characters)
- `handle.write(f"Equation: cups = {slope:.4f} * temperature + {intercept:.4f}\n")` — writes the equation with 4 decimal places for precision
- `handle.write(f"Prediction at 35 C: {hot_prediction:.2f} cups\n")` — writes the 35°C prediction with 2 decimal places
- `handle.write(f"Mean absolute error: {mae:.2f}\n")` — writes MAE without "cups" unit (matching console format)
- `handle.write(f"R-squared: {r2:.2f}\n")` — writes R² value

## Worked Example

**Checking prediction.txt contents:**

After running main.py, the file `outputs/prediction.txt` contains:
```
Equation: cups = 1.5776 * temperature + -10.6618
Prediction at 35 C: 44.55 cups
Mean absolute error: 2.16
R-squared: 0.90
```

**Verification against console output:**
- Console equation: `cups = 1.58 x temperature + -10.66` → file equation: `1.5776 * temperature + -10.6618` (same values, more precision in file) ✓
- Console prediction: `44.6 cups` → file prediction: `44.55 cups` (file has 2 decimals, console has 1) ✓
- Console MAE: `2.16 cups` → file MAE: `2.16` (same) ✓
- Console R²: `0.90` → file R²: `0.90` (same) ✓

**Checking the PNG file:**
```bash
$ ls -la outputs/
-rw-r--r-- 1 user user 18432 Oct 27 11:00 lemonade_regression.png
-rw-r--r-- 1 user user  172 Oct 27 11:00 prediction.txt
```

Both files exist and have reasonable sizes.

## Step-by-Step Student Instructions

1. **Locate the outputs directory** — After running main.py, check the `outputs/` folder in the project directory.
2. **Read prediction.txt** — Open the file with a text editor or `cat outputs/prediction.txt`.
3. **Compare values** — Match each value in the file to the corresponding console output value.
4. **Check the PNG file** — Use `ls -la outputs/lemonade_regression.png` to verify the file exists and has a non-zero size.
5. **Verify the plot** — Open the PNG file in an image viewer to confirm it shows the scatter plot, regression line, and 35°C star marker.

## Expected Output or Observable Behaviour

**`prediction.txt` contents:**
```
Equation: cups = 1.5776 * temperature + -10.6618
Prediction at 35 C: 44.55 cups
Mean absolute error: 2.16
R-squared: 0.90
```

**`outputs/` directory listing:**
```
lemonade_regression.png  (10KB-50KB range)
prediction.txt           (100-200 bytes)
```

The PNG file opens in an image viewer showing:
- Orange circles (training data) scattered across the plot
- Dark blue squares (test data) scattered across the plot
- A green line (regression trend line) running through the points
- A red star at the far right marking the 35°C prediction

## Practical Exercise (with Success Criteria)

**Task:** After running main.py, inspect both output files. Read `prediction.txt` and verify that:
a) It contains 4 lines (equation, prediction, MAE, R²)
b) The equation values match the console output (account for decimal place differences)
c) The MAE and R² values match the console output
d) The PNG file exists and is larger than 1KB

**Success Criteria:**
- [ ] `outputs/prediction.txt` exists and is readable
- [ ] File contains equation, prediction, MAE, and R² lines
- [ ] Equation values match console output (with precision differences)
- [ ] MAE value matches console output
- [ ] R² value matches console output
- [ ] `outputs/lemonade_regression.png` exists
- [ ] PNG file size is greater than 1KB

## Common Mistakes and Troubleshooting

| Mistake | Cause | Fix |
|---|---|---|
| File not found | Running from wrong directory | main.py uses `Path(__file__).resolve().parent`, so `BASE` is always the script's directory — check that directory for `outputs/` |
| Values don't match console | Using different formatting | Check decimal places: equation uses `.4f` in file vs `.2f` in console; prediction uses `.2f` in file vs `.1f` in console |
| PNG file exists but is 0 bytes | Script was interrupted during save | Re-run main.py to completion |
| Text editor shows garbled characters | Encoding mismatch | The file is UTF-8 encoded; open with UTF-8 support |

## Best Practices and Security Considerations

- **Always verify outputs**: Don't assume files were created just because the script ran without errors
- **Check file sizes**: A 0-byte file may indicate an interrupted save
- **Match precision expectations**: Understand that file output may have more decimal places than console output
- **No security risk**: Output files only contain computed statistics and a plot image — no sensitive data

## Summary

The `outputs/` directory contains two files: `prediction.txt` with the model equation and metrics, and `lemonade_regression.png` with the visual plot. Both can be verified against the console output for consistency. The file version of the equation uses more decimal places (`.4f`) for precision.

## Knowledge Check

1. What two files does main.py save to `outputs/`?
2. How many lines does `prediction.txt` contain?
3. Why does the equation in the file have more decimal places than the console output?
4. How can you verify the PNG file is valid?

## References

- Python `open()` and file writing: https://docs.python.org/3/tutorial/inputoutput.html#writing-to-files
- PNG file format: https://www.w3.org/TR/png/
- main.py lines 98-105 (savefig and prediction.txt writing)