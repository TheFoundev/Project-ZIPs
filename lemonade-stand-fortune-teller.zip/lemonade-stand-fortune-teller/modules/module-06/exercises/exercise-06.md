# Module 6 Exercises

## Exercise 6.1: Environment Setup and Project Execution (10 min)
**Objective:** Navigate to the project, install dependencies, and run main.py
**Problem Statement:** Set up the complete environment and execute the Lemonade Stand project from scratch.

**Requirements:**
1. Navigate to the project directory
2. Check Python version
3. Install all four required packages: `pip install pandas numpy matplotlib scikit-learn`
4. Verify all imports work
5. Run `python main.py`
6. Capture the full console output

**Constraints:** Use the correct working directory (the `02_lemonade_stand` folder).

**Expected Behaviour:** The script runs without errors and produces console output with the model equation, metrics, and 35°C prediction.

**Acceptance Criteria:**
- [ ] Python 3.x is installed and verified
- [ ] All four packages installed successfully
- [ ] `python -c "import pandas, numpy, matplotlib, sklearn"` runs without error
- [ ] `python main.py` executes without errors
- [ ] Console output starts with "THE LEMONADE STAND FORTUNE TELLER"
- [ ] Output contains "Model:", "Meaning:", "Mean absolute error:", "R-squared:", "Prediction for 35 C:"
- [ ] Output ends with "Saved: outputs/lemonade_regression.png, outputs/prediction.txt"

**Hints:**
- The project directory path has a space: `beginner-projects-main/AI-ML Beginners/projects/02_lemonade_stand`
- Use backslash-space or quotes in bash: `cd "path with spaces"`
- If `python` doesn't work, try `python3`
- On Windows, the path uses different escaping

**Difficulty:** Basic
**Estimated Completion Time:** 10 minutes

---

## Exercise 6.2: Interpreting Console Output (20 min)
**Objective:** Match each line of console output to the corresponding code and interpret the meaning
**Problem Statement:** Analyze the console output from running main.py, matching each line to its source code and explaining what it means.

**Requirements:**
1. List all output lines from the console
2. For each line, identify the corresponding `print()` statement in main.py (by line number)
3. Explain what each value means in the context of the lemonade stand
4. Manually verify the equation: does `slope × 35 + intercept ≈ prediction`?

**Constraints:** Use the actual output values from your run.

**Expected Behaviour:** A table or list mapping output lines to code lines with interpretations.

**Acceptance Criteria:**
- [ ] All 6 key output lines are listed (equation, meaning, MAE, R², prediction, saved message)
- [ ] Each line is matched to a `print()` statement in main.py (lines 67-74, 107)
- [ ] The equation interpretation is explained (slope = cups per degree)
- [ ] MAE is interpreted (average prediction error in cups)
- [ ] R² is interpreted (proportion of variance explained)
- [ ] Manual verification: `1.58 × 35 + (-10.66) = 55.3 - 10.66 = 44.64` ≈ 44.6 ✓

**Hints:**
- The header lines (===, title) come from `print("=" * 60)` and `print("THE LEMONADE STAND FORTUNE TELLER")`
- The equation line comes from line 69: `print(f"Model: cups = {slope:.2f} x temperature + {intercept:.2f}")`
- The meaning line comes from line 70
- The MAE and R² lines come from lines 71-72
- The prediction line comes from line 73

**Difficulty:** Intermediate
**Estimated Completion Time:** 20 minutes

---

## Exercise 6.3: Verifying Output Files (15 min)
**Objective:** Inspect and validate the output files created by main.py
**Problem Statement:** Check that both output files exist, have correct contents, and are valid.

**Requirements:**
1. List the `outputs/` directory and confirm both files exist
2. Read `prediction.txt` and verify it contains 4 lines
3. Match each line of `prediction.txt` to the corresponding `write()` call in main.py
4. Verify the PNG file is valid (size > 1KB, opens in an image viewer)
5. Compare prediction.txt values with console output

**Constraints:** The prediction.txt file should have 4 lines matching main.py's write statements.

**Expected Behaviour:** Both files verified, values match console output, PNG is valid.

**Acceptance Criteria:**
- [ ] `ls outputs/` shows both `lemonade_regression.png` and `prediction.txt`
- [ ] `prediction.txt` has exactly 4 lines
- [ ] Line 1: Equation (with 4 decimal places for slope/intercept)
- [ ] Line 2: Prediction at 35°C (with 2 decimal places)
- [ ] Line 3: Mean absolute error (with 2 decimal places)
- [ ] Line 4: R-squared (with 2 decimal places)
- [ ] PNG file size is > 1KB
- [ ] Prediction.txt MAE (2.16) matches console MAE (2.16)
- [ ] Prediction.txt R² (0.90) matches console R² (0.90)

**Hints:**
- The equation in prediction.txt uses `:.4f` (4 decimal places) vs `:.2f` in console
- The prediction in prediction.txt uses `:.2f` vs `:.1f` in console
- Use `cat outputs/prediction.txt` or a text editor to view the file
- Use `ls -la outputs/` to check file sizes
- The PNG should be 10-50KB in size

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 6.4: Complete Pipeline Trace and Troubleshooting (20 min)
**Objective:** Trace the complete pipeline from data loading through output saving, and troubleshoot common errors
**Problem Statement:** Document the complete main.py pipeline as a 9-stage workflow, then diagnose and fix common errors a beginner might encounter.

**Requirements:**
1. List all 9 stages of the pipeline in order with their main.py line numbers
2. For each stage, list the key variables created
3. Identify one common error per stage and its fix
4. Run main.py and verify all stages complete successfully

**Constraints:** Reference actual line numbers from main.py.

**Expected Behaviour:** A comprehensive pipeline trace document with error troubleshooting for each stage.

**Acceptance Criteria:**
- [ ] All 9 stages are listed in correct order
- [ ] Main variables for each stage are identified (e.g., Stage 2: df; Stage 3: X, y)
- [ ] One error per stage with fix is documented (e.g., "Stage 2: FileNotFoundError if data file missing → verify path")
- [ ] main.py runs successfully
- [ ] Both output files are created
- [ ] No errors or warnings during execution

**Hints:**
- The 9 stages are: Imports/Setup → Data Loading → Feature/Target → Split → Training → Evaluation/Prediction → Visualization → Save → Final Message
- Key line numbers: Lines 12-25 (imports/setup), Line 29 (load), Lines 30-31 (X/y), Lines 33-35 (split), Lines 37-38 (train), Lines 39-47 (evaluate/predict), Lines 59-74 (visualize), Lines 72-80 (save), Lines 82-85 (message)
- Common errors include: missing packages, wrong file path, wrong brackets for X, accessing coef_ before fit, etc.

**Difficulty:** Advanced
**Estimated Completion Time:** 20 minutes