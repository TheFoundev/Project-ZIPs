# Lesson 04: Connecting the Pieces — The Complete Data Story

**Lesson ID:** lesson-04
**Module:** module-01
**Duration:** 20-25 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Trace the complete flow from raw data to model prediction in this project
- Explain how features, targets, training, and evaluation connect into one pipeline
- Describe what the model learns from the lemonade data
- Identify potential limitations of a simple linear model on this dataset
- Summarize the end-to-end workflow that main.py implements

## Prerequisites
- Lesson 01: The Lemonade Stand Problem (what we predict, why regression)
- Lesson 02: Exploring the Dataset (data structure, feature/target identification)
- Lesson 03: Features and Targets (X, y, shapes, double brackets)

## Concept Explanation

### The end-to-end workflow in one picture

The Lemonade Stand project follows a standard supervised learning workflow. Here is how all the pieces fit together:

1. **We have data** — A CSV file with 16 rows, each recording one day's temperature and lemonade sales
2. **We define the problem** — Predict `cups_sold` (a number) from `temperature_c` (a number)
3. **We split the data** — 12 days go to training, 4 days go to testing (25% test, `random_state=42`)
4. **We train a model** — LinearRegression finds the best straight line through the training points
5. **We evaluate** — We ask the model to predict the 4 test days and compare predictions to actual values
6. **We make a new prediction** — We ask: "How many cups at 35°C?" using the learned line
7. **We visualize** — We draw a scatter plot showing the data, the line, and the prediction point
8. **We save results** — The plot and metrics are written to files

### What does "best-fit line" mean?
LinearRegression uses a method called **ordinary least squares**. It finds the slope and intercept that minimize the sum of squared vertical distances between each training point and the line. In simpler terms: it draws the line that passes as close as possible to all the training dots.

The equation is: `cups_sold = slope × temperature_c + intercept`

From our actual run:
- slope ≈ 1.58 → each additional degree Celsius adds about 1.58 cups
- intercept ≈ -10.66 → at 0°C (theoretical), the model predicts negative sales (this is normal — the intercept is a mathematical artifact, not a real prediction)

### Why do we need a test set?
If we evaluate the model on the same data we trained on, we get an overly optimistic picture (the model has already "seen" those points). By holding out 25% of the data as a test set, we get an honest estimate of how the model performs on unseen data.

### What can go wrong with a linear model?
- **Non-linear relationships**: If sales jumped suddenly at 30°C and then plateaued, a straight line would not capture that
- **Outliers**: A single unusually hot day with low sales could pull the line away from the true trend
- **Small dataset**: With only 16 data points, the model's estimates have uncertainty — a different random split could give different results

## Complete Picture from main.py

Here is the full pipeline as it exists in main.py:

```python
# 1. Load data
df = pd.read_csv(DATA / "lemonade_days.csv")

# 2. Separate features and target
X = df[["temperature_c"]]   # 2D DataFrame — features
y = df["cups_sold"]          # 1D Series — target to predict

# 3. Split into train and test
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)

# 4. Train the model
model = LinearRegression()
model.fit(X_train, y_train)

# 5. Evaluate and predict
test_predictions = model.predict(X_test)
slope = float(model.coef_[0])
intercept = float(model.intercept_)
mae = mean_absolute_error(y_test, test_predictions)
r2 = r2_score(y_test, test_predictions)

# 6. Predict for a new temperature (35°C)
hot_day = pd.DataFrame({"temperature_c": [35.0]})
hot_prediction = float(model.predict(hot_day)[0])

# 7. Print results
print(f"Model: cups = {slope:.2f} x temperature + {intercept:.2f}")
print(f"Mean absolute error: {mae:.2f} cups")
print(f"R-squared: {r2:.2f}")
print(f"Prediction for 35 C: {hot_prediction:.1f} cups")
```

## Worked Example: Walking Through One Prediction

Let's trace how the model predicts sales for a new day at 35°C:

1. **Training**: The model looked at 12 training days and found the best line: `cups = 1.58 × temp + (-10.66)`
2. **New input**: We create `hot_day = pd.DataFrame({"temperature_c": [35.0]})` — a single row with temperature = 35
3. **Prediction**: The model plugs 35 into the equation: `1.58 × 35 + (-10.66) = 55.3 - 10.66 = 44.64`
4. **Output**: The prediction (44.6) is printed and also used as the y-coordinate for the red star on the plot

This shows how the model generalizes: it takes a temperature value it may never have seen during training and produces a sales prediction based on the learned trend.

## Step-by-Step Student Instructions

1. **Review your data** — Look at `data/lemonade_days.csv`. Which columns exist? Which is the feature? Which is the target?
2. **Check the split** — How many rows go to training (75% of 16 = 12) and test (25% of 16 = 4)?
3. **Understand the equation** — Write out `cups = slope × temperature + intercept` using the actual slope and intercept from your run
4. **Verify a prediction** — Manually compute `slope × 35 + intercept` and compare with the printed 35°C prediction
5. **Interpret metrics** — Write a sentence explaining what MAE = 2.16 and R² = 0.90 mean for this model
6. **Reflect on limitations** — List one thing a straight line cannot capture about this data

## Expected Output or Observable Behaviour

- The model equation `cups = 1.58 × temperature + (-10.66)` fits the training data
- On the test set: MAE ≈ 2.16 cups, R² ≈ 0.90
- At 35°C: prediction ≈ 44.6 cups
- Training data points trend upward (higher temperature → more sales)
- The regression line passes through the middle of the training data cluster

## Practical Exercise (with Success Criteria)

**Task:** Write a one-paragraph summary that connects all the concepts from this module. Your summary should explain: (a) what data we start with, (b) how we split it, (c) what the model learns, (d) how we evaluate it, and (e) how we use it to predict for a new day.

**Success Criteria:**
- [ ] Mentions the dataset (lemonade_days.csv with temperature_c and cups_sold)
- [ ] Explains the train/test split (75/25, random_state=42)
- [ ] Describes what LinearRegression learns (best-fit line = slope + intercept)
- [ ] Explains MAE and R² in terms of model quality
- [ ] Shows how 35°C prediction connects to the equation
- [ ] Paragraph is coherent and connects all pieces

## Common Mistakes and Troubleshooting

| Mistake | Cause | Fix |
|---|---|---|
| Thinking the model memorizes data | Confusing memorization with learning patterns | The model learns a general trend, not individual data points |
| Expecting perfect predictions | Believing the model should get every prediction right | Models make errors; MAE and R² quantify this |
| Confusing correlation with causation | Assuming hot weather *causes* more sales because the line slopes up | The model shows association, not proven causation — other factors may drive both |

## Best Practices and Security Considerations

- **Understand the problem before building the model**: Knowing we predict a number (regression) guides all technical choices
- **Keep student data private**: The lemonade dataset is synthetic; never use real customer data without consent
- **Document your reasoning**: Write down why you chose each parameter — it helps when debugging later
- **No security risk**: This project uses only local data files; no credentials, network connections, or external services

## Summary

The Lemonade Stand project is a complete supervised learning pipeline. We start with temperature and sales data, split it into train and test sets, train a linear regression model to learn the relationship, evaluate with MAE and R², and use the model to predict sales for a new temperature. The model learns that each degree of warming adds about 1.58 cups to sales, and at 35°C it predicts about 44.6 cups.

## Knowledge Check

1. How many data points are used for training, and how many for testing?
2. What does the slope (1.58) tell you about the relationship between temperature and sales?
3. If you predicted for 25°C using the equation, what would you expect?
4. Why can't we say "temperature causes higher sales" just from this model?

## References

- main.py complete code (lines 28-83)
- scikit-learn LinearRegression: https://scikit-learn.org/stable/modules/linear_model.html#linear-models
- Train/test split concept: https://scikit-learn.org/stable/common_pitfalls.html#train-test-split
- Correlation vs causation: https://en.wikipedia.org/wiki/Correlation_does_not_imply_causation