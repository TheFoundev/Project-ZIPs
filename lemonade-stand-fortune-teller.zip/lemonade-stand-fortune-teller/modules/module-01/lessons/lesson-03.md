# Lesson 03: Features and Targets

**Lesson ID:** lesson-03
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Define "feature" (input) and "target" (output) in machine learning
- Explain why X uses double brackets `[[]]` and y uses single brackets `[]` in pandas
- Verify the shapes of X and y are correct for sklearn
- Understand the relationship between features and targets in a prediction
- Apply the feature/target split to new data correctly

## Prerequisites
- Lesson 02: Exploring the Dataset (know the column names and structure)

## Concept Explanation

### Features and targets: the core of supervised learning
Every supervised learning problem has two parts:
- **Features (X)**: The input variables — known quantities used to make predictions
- **Target (y)**: The output variable — the unknown we want to predict

In the Lemonade Stand project:
- **Feature**: `temperature_c` — we know the temperature, and we use it to predict sales
- **Target**: `cups_sold` — we want to predict this based on temperature

Think of it as a function: `cups_sold = f(temperature_c)`. The model learns `f` from the data.

### The DataFrame vs Series distinction
This is where beginners most often make mistakes. The key difference in pandas:

| Syntax | Result Type | Dimensions | Shape | Used For |
|---|---|---|---|---|
| `df["column"]` | **Series** | 1D | `(n,)` | Target variable (y) |
| `df[["column"]]` | **DataFrame** | 2D | `(n, 1)` | Feature matrix (X) |

The difference is **one bracket pair** — but it changes the type from 1D to 2D.

### Why does sklearn need 2D features?
scikit-learn is designed to handle datasets with **multiple features**. Even though we only have one feature (temperature), sklearn expects the feature matrix to always be 2D:

```
X should have shape: (n_samples, n_features)
                    = (16, 1)        # 16 days, 1 feature
```

If you accidentally use single brackets, you get a 1D Series with shape `(16,)`, and sklearn raises:
```
ValueError: Found input variables with inconsistent numbers of features
```

### Why can the target be 1D?
The target in regression is always a single value per sample (one number of cups sold per day). sklearn accepts:
- A 1D array/Series of shape `(16,)` — the standard
- A 2D array of shape `(16, 1)` — also works but unnecessary for single-output regression

main.py uses the simpler 1D Series: `y = df["cups_sold"]`.

## Relevant Code (from main.py, lines 30-31)
```python
X = df[["temperature_c"]]
y = df["cups_sold"]
```

### Line-by-line explanation
- `X = df[["temperature_c"]]` — **double brackets** select one column as a DataFrame (2D, shape `(16, 1)`). This is the feature matrix that sklearn requires.
- `y = df["cups_sold"]` — **single bracket** selects one column as a Series (1D, shape `(16,)`). This is the target vector to predict.

## Worked Example

```python
import pandas as pd

# Load data
df = pd.read_csv("data/lemonade_days.csv")

# Correct way (matches main.py):
X = df[["temperature_c"]]   # DataFrame — 2D, shape (16, 1)
y = df["cups_sold"]          # Series — 1D, shape (16,)

print(f"X type: {type(X)}")       # <class 'pandas.DataFrame'>
print(f"X shape: {X.shape}")       # (16, 1)
print(f"y type: {type(y)}")       # <class 'pandas.Series'>
print(f"y shape: {y.shape}")       # (16,)

# What goes wrong with single brackets for X:
X_wrong = df["temperature_c"]     # Series — 1D, shape (16,)
print(f"X_wrong shape: {X_wrong.shape}")  # (16,) — wrong for sklearn!

# Verification: these should produce the same numbers
print(f"\nX as Series:\n{df['temperature_c'].head()}")
print(f"\ny:\n{y.head()}")
```

## Step-by-Step Student Instructions

1. **Load the data** — `df = pd.read_csv(DATA / "lemonade_days.csv")`
2. **Check columns** — `print(df.columns)` to confirm `temperature_c` and `cups_sold` exist
3. **Create X with double brackets** — `X = df[["temperature_c"]]`
4. **Create y with single brackets** — `y = df["cups_sold"]`
5. **Verify types** — `print(type(X), type(y))` should show DataFrame and Series
6. **Verify shapes** — `print(X.shape, y.shape)` should show `(16, 1)` and `(16,)`
7. **Compare with wrong approach** — `print(df["temperature_c"].shape)` should show `(16,)` (wrong for sklearn)

## Expected Output or Observable Behaviour

```
X type: <class 'pandas.DataFrame'>
X shape: (16, 1)
y type: <class 'pandas.Series'>
y shape: (16,)
X_wrong shape: (16,)
```

The shape `(16,)` means the data is 1D (a list of values). The shape `(16, 1)` means it's 2D (a table with one column). sklearn requires the 2D form for features.

## Practical Exercises

**Exercise 1.3:** Explain why X uses double brackets.
**Exercise 1.3b:** What are the shapes of X and y? What types?
**Exercise 1.3c:** What happens if you use `df["temperature_c"]` (single brackets) for X?

## Common Mistakes and Debugging

| Mistake | Cause | Fix |
|---|---|---|
| `ValueError: inconsistent numbers of features` | Using `df["col"]` (Series) for X | Use `df[["col"]]` (DataFrame) — double brackets |
| Confusing X and y | Using temperature as target | Remember: X = input (feature), y = output (target); we predict cups from temperature, not vice versa |
| `KeyError` on column | Typo in column name | The column is `temperature_c` with underscores, not `temperature` or `temp` |
| Wrong shape check | Not checking `.shape` attribute | Always print shapes after creating X and y |

## Best Practices and Security Considerations
- **Always check shapes**: `X.shape` and `y.shape` are quick sanity checks that prevent sklearn errors
- **Use consistent naming**: `X` (uppercase) for features, `y` (lowercase) for target — this is the convention in sklearn and most ML code
- **Remember the bracket rule**: Double `[[]]` for DataFrame/2D, single `[]` for Series/1D
- **No security risk**: Selecting columns from a DataFrame is a pure data operation with no external effects

## Summary

Features (X) are inputs and targets (y) are outputs. In pandas, `df[["column"]]` (double brackets) returns a 2D DataFrame — which sklearn requires for features. `df["column"]` (single brackets) returns a 1D Series — which is fine for the target. Using the wrong brackets for X causes `ValueError: inconsistent numbers of features`.

## Knowledge-check Questions
1. Is X a DataFrame or Series? Why?
2. Is y a DataFrame or Series?
3. What shape does sklearn expect for X?
4. What happens if you use single brackets for X?

## References
- pandas indexing documentation: https://pandas.pydata.org/docs/user_guide/indexing.html
- scikit-learn data preparation: https://scikit-learn.org/stable/developers/develop.html
- main.py lines 30-31