# Lesson 02: Exploring the Dataset

**Lesson ID:** lesson-02
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Locate the dataset file used by main.py
- Use pandas to load a CSV file and inspect its structure
- Identify the column names, data types, and basic statistics
- Distinguish the feature column from the target column
- Count observations and understand the dataset size
- Recognize basic patterns in the data (e.g., hot days → more sales)

## Prerequisites
- Lesson 01: Understanding the problem (we predict cups_sold from temperature_c)

## Concept Explanation

### The dataset
The Lemonade Stand project uses a small dataset called `lemonade_days.csv`. It contains 16 rows of data — one row per day — with three columns:

| Column | Description | Data Type | Example Value |
|---|---|---|---|
| `day` | Sequential day number (1-16) | integer | 1, 2, 3, ... |
| `temperature_c` | Daily temperature in Celsius | float | 23.3, 30.0, 31.8 |
| `cups_sold` | Number of cups sold that day | integer | 29, 38, 42 |

### Finding the dataset
The dataset is located at `data/lemonade_days.csv` relative to the project directory. In main.py, it is loaded with:

```python
df = pd.read_csv(DATA / "lemonade_days.csv")
```

where `DATA = BASE / "data"` and `BASE = Path(__file__).resolve().parent`.

### Why inspect data first?
Before building any model, you should always inspect your data. This helps you:
1. **Verify the data is loaded correctly** — check the right file, right columns, right number of rows
2. **Identify the feature and target** — know which column to use for input and output
3. **Spot anomalies** — look for missing values, incorrect types, or outliers
4. **Understand data ranges** — know the minimum and maximum values to interpret predictions

### Using pandas to explore data
Key pandas methods for exploration:
- `df.head()` — shows the first 5 rows
- `df.shape` — returns (number_of_rows, number_of_columns)
- `df.columns` — lists column names
- `df.dtypes` — shows data types of each column
- `df.describe()` — shows count, mean, std, min, max for numeric columns

## Relevant Code (from main.py, line 29)
```python
df = pd.read_csv(DATA / "lemonade_days.csv")
```

### Code explanation
- `pd.read_csv()` — pandas function that reads a CSV file into a DataFrame
- `DATA / "lemonade_days.csv"` — uses pathlib to construct the full path: `<project_dir>/data/lemonade_days.csv`
- The resulting `df` variable holds all 16 rows and 3 columns of the dataset

## Worked Example

Let's inspect the dataset step by step:

```python
import pandas as pd
from pathlib import Path

BASE = Path(".").resolve()
DATA = BASE / "data"

# Load the data
df = pd.read_csv(DATA / "lemonade_days.csv")

# Inspect the structure
print(f"Shape: {df.shape}")
print(f"Columns: {list(df.columns)}")
print(f"Dtypes:\n{df.dtypes}")
print(f"\nFirst 5 rows:\n{df.head()}")
print(f"\nStatistics:\n{df.describe()}")
```

**Expected output:**
```
Shape: (16, 3)
Columns: ['day', 'temperature_c', 'cups_sold']
Dtypes:
day              int64
temperature_c    float64
cups_sold          int64
dtype: object

First 5 rows:
   day  temperature_c  cups_sold
0    1           23.3         29
1    2           30.0         38
2    3           31.8         42
3    4           21.5         25
4    5           23.7         24

Statistics:
              day  temperature_c   cups_sold
count  16.000000       16.00000  16.000000
mean    8.500000       27.92500  35.312500
std     4.764331        5.74079   7.635321
min     1.000000       21.50000  24.000000
25%     4.750000       23.47500  27.750000
50%     8.500000       27.60000  34.500000
75%    12.250000       31.62500  40.000000
max    16.000000       38.10000  48.000000
```

## Step-by-Step Student Instructions

1. **Set up paths** — Define `BASE` and `DATA` using pathlib, matching main.py
2. **Load the CSV** — `df = pd.read_csv(DATA / "lemonade_days.csv")`
3. **Check shape** — Print `df.shape` — should be `(16, 3)`
4. **Check columns** — Print `df.columns` — should show `day`, `temperature_c`, `cups_sold`
5. **Check data types** — Print `df.dtypes` — temperature_c is float64, others are int64
6. **View first rows** — Print `df.head()` to see actual data values
7. **View statistics** — Print `df.describe()` to see ranges and central tendency
8. **Identify feature and target** — `temperature_c` is the feature (X), `cups_sold` is the target (y)

## Expected Output or Observable Behaviour

- `df.shape` returns `(16, 3)` — 16 days, 3 columns
- Column names: `day`, `temperature_c`, `cups_sold`
- `temperature_c` is `float64` type; `day` and `cups_sold` are `int64`
- Temperature ranges from ~21.5°C to ~38.1°C
- Cups sold ranges from 24 to 48
- Higher temperatures generally correspond to more cups sold

## Practical Exercises

**Exercise 1.2:** Load the dataset and report how many days of data there are.
**Exercise 1.2b:** What are the minimum and maximum temperatures?
**Exercise 1.2c:** What is the highest number of cups sold on any single day?

## Common Mistakes and Debugging

| Mistake | Cause | Fix |
|---|---|---|
| `FileNotFoundError` | Wrong path or filename | Use `DATA / "lemonade_days.csv"` with the DATA path from main.py setup; do not add extra directory levels |
| `KeyError` when accessing column | Typo in column name | Copy the exact name: `temperature_c` (with underscores), not `temperature` or `Temp` |
| Data loaded as strings instead of numbers | CSV has extra formatting | Ensure no extra quotes or text in the CSV; the actual file has clean numeric data |

## Best Practices and Security Considerations

- **Always inspect before modeling**: Never skip `df.head()` and `df.describe()`
- **Check column names exactly**: Use `df.columns` to see exact names including underscores
- **Verify data types**: Ensure numeric columns are loaded as numbers, not strings
- **No security risk**: Reading a local CSV file is safe; no code execution from file contents

## Summary

The dataset has 16 rows and 3 columns: `day` (1-16), `temperature_c` (21.5-38.1°C), and `cups_sold` (24-48). Temperature is the feature used as input, and cups_sold is the target being predicted. The data shows a clear positive trend: hotter days have higher sales. The dataset is small (16 points), so the train/test split will use 12 training and 4 test samples.

## Knowledge-check Questions

1. What are the column names in lemonade_days.csv?
2. Which column is the feature? Which is the target?
3. How many rows of data are there?
4. What is the temperature range and cups sold range?
5. Do you see a pattern between temperature and cups sold?

## References

- pandas `read_csv` documentation: https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html
- pandas DataFrame `describe()` method: https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.describe.html
- main.py line 29: `df = pd.read_csv(DATA / "lemonade_days.csv")`
- Data file: `beginner-projects-main/AI-ML Beginners/projects/02_lemonade_stand/data/lemonade_days.csv`