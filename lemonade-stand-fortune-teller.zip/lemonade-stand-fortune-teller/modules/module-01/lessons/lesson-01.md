# Lesson 01: The Lemonade Stand Problem

**Lesson ID:** lesson-01
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- State the business problem this project solves
- Explain why predicting lemonade sales from temperature is a regression task
- Distinguish between a feature (input) and a target (output)
- Identify the prediction temperature used in the project (35°C)
- Explain what "supervised learning" means in this context

## Prerequisites
None

## Concept Explanation

### The business problem
Imagine you run a lemonade stand. On hot days, you sell more lemonade. On cold days, you sell less. You want to answer a question: **"If the forecast says 35°C tomorrow, how many cups of lemonade should I prepare?"**

This is a **prediction problem**: use known information (temperature) to predict an unknown value (cups sold). The project solves this by training a **linear regression** model on 16 days of historical temperature and sales data.

### Why is this "supervised" learning?
In supervised learning, we learn from **labeled examples** — data where we already know both the input (temperature) and the correct output (cups sold). The 16 rows in `lemonade_days.csv` are our labeled examples. The model studies these examples to learn the pattern, then applies that pattern to new inputs.

This is different from unsupervised learning, where we only have inputs and must find hidden patterns without knowing the correct outputs.

### Why is this "regression" (not classification)?
- **Regression** predicts a **continuous numeric value** — like 44.6 cups, or 32.1 cups
- **Classification** predicts a **category or class** — like "high sales" vs "low sales"

Since we want to predict a specific number of cups (a continuous value), this is a regression problem. Linear regression specifically finds the best straight line through the data points.

### The model's equation
Once trained, the model learns an equation of the form:

```
cups_sold = slope × temperature_c + intercept
```

From the actual project run:
- **slope ≈ 1.58**: For every 1°C increase in temperature, sales increase by about 1.58 cups
- **intercept ≈ -10.66**: At 0°C (theoretical), the model predicts -10.66 cups (not physically meaningful, but mathematically correct)
- **Prediction at 35°C**: 1.58 × 35 + (-10.66) = 55.3 - 10.66 = **44.6 cups**

### Why 35°C?
The value 35°C was chosen because it represents a **hot summer day** — the kind of day where demand forecasting is most valuable for inventory planning. Predicting for an extreme (hot) temperature tests whether the model generalizes beyond the training data range.

## Relevant Code (from main.py, lines 1-8)
```python
"""Project 02: The Lemonade Stand Fortune Teller (linear regression).

Run:
    python main.py

The model learns the relationship between temperature and cups sold, then
predicts sales for a 35 degree Celsius day.
"""
```

### Code explanation
- The docstring explicitly states the goal: learn the temperature-sales relationship, then predict for 35°C
- The project name "Fortune Teller" is a playful reference to predicting future sales
- The algorithm is named upfront: linear regression

## Worked Example

**Problem:** On a 28°C day, approximately how many cups would the model predict?

**Solution using the learned equation:**
```
cups = 1.58 × 28 + (-10.66)
    = 44.24 - 10.66
    = 33.58
```

So the model predicts approximately **33.6 cups** at 28°C.

**Verification:** Looking at the dataset, on day 10 with temperature 32.2°C, 40 cups were sold, and on day 11 with 27.6°C, 33 cups were sold. Our manual calculation of 33.6 at 28°C is consistent with these data points — the model has learned a reasonable trend.

## Step-by-Step Student Instructions

1. **Read the problem statement** — Open the project README and read the docstring in main.py
2. **Identify the prediction goal** — What are we trying to predict? (cups_sold)
3. **Identify the input** — What information do we use to make the prediction? (temperature_c)
4. **Classify the task** — Is this classification or regression? Why?
5. **Check the prediction temperature** — Locate the 35°C prediction in main.py
6. **Reflect on the business value** — How would a lemonade stand owner use this prediction?

## Expected Output or Observable Behaviour

After running main.py, the console shows:
```
Model: cups = 1.58 x temperature + -10.66
Meaning: each extra 1 C is associated with about 1.58 more cups.
R-squared: 0.90
Prediction for 35 C: 44.6 cups
```

This confirms the model has learned a relationship where hotter weather predicts more sales.

## Practical Exercises

**Exercise 1.1:** Is this classification or regression? Explain why.
**Exercise 1.2:** What is the business problem being solved?
**Exercise 1.3:** If the temperature were 20°C, would you expect more or fewer cups than at 35°C? Why?
**Exercise 1.4:** Why is this called "supervised" learning?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Calling this "classification" | Classification predicts categories; this predicts a number | It's regression because cups_sold is continuous |
| Thinking we predict temperature | Temperature is the input | We predict cups_sold FROM temperature |
| Ignoring the 35°C value | The prediction temperature is the key output | The model specifically predicts for a hot day |

## Best Practices and Security Considerations

- **Always define the problem first**: Understanding whether you need regression or classification determines which algorithms and metrics to use
- **Match the algorithm to the task**: LinearRegression is for continuous numeric prediction, not category prediction
- **Consider the business context**: Knowing that 35°C represents a hot day helps interpret predictions meaningfully
- **No security risk**: This is a simple local data analysis project with no network connections or user data

## Summary

The Lemonade Stand Fortune Teller is a supervised regression project. We predict a continuous numeric value (cups sold) from a known input (temperature) using labeled historical data. The model learns a linear relationship — approximately 1.58 additional cups per degree Celsius — and uses it to forecast sales for a 35°C day (~44.6 cups). This helps a lemonade stand owner plan inventory for hot weather.

## Knowledge-check Questions

1. What are we predicting?
2. Why is this regression, not classification?
3. What does "supervised" mean in this context?
4. At 35°C, what does the model predict?
5. What does the slope (1.58) tell us about lemonade sales?

## References
- main.py docstring (lines 1-8)
- scikit-learn Linear Regression overview: https://scikit-learn.org/stable/regression.html
- Supervised vs unsupervised learning: https://scikit-learn.org/stable/unsupervised_learning.html