# Module 1 Exercises

## Exercise 1.1: Problem Type Classification (10 min)
**Objective:** Distinguish supervised regression from classification and unsupervised learning
**Problem Statement:** The Lemonade Stand project predicts the number of cups sold based on temperature. You need to classify this as the correct type of machine learning problem.

**Requirements:**
1. Define supervised learning: learning from examples with known inputs and outputs
2. Define regression: predicting a continuous numeric value
3. Define classification: predicting a discrete category or class
4. Apply these definitions to the lemonade stand data (temperature → cups sold)

**Constraints:** Base your answer on the actual project code and dataset description, not on external sources.

**Expected Behaviour:** Write a clear 3-5 sentence explanation that correctly identifies the task type and justifies your answer.

**Acceptance Criteria:**
- [ ] Supervised learning is correctly defined
- [ ] Regression is correctly defined as predicting continuous values
- [ ] The identification of the lemonade stand as supervised regression is correct
- [ ] The explanation connects to the actual data (temperature → cups sold)
- [ ] No mention of classification as the correct answer

**Hints:**
- Think about what kind of value `cups_sold` is (discrete count vs continuous number)
- Consider what "labeled data" means in this context
- Recall that the model predicts a number, not a category

**Difficulty:** Basic
**Estimated Completion Time:** 10 minutes

---

## Exercise 1.2: Dataset Inspection (15 min)
**Objective:** Load and inspect the lemonade dataset to understand its structure
**Problem Statement:** You need to examine the actual dataset used by main.py and identify the feature and target columns.

**Requirements:**
1. Open `data/lemonade_days.csv` and identify all column names
2. Count the total number of data rows (excluding header)
3. Identify which column is the feature (input) and which is the target (output)
4. Briefly describe the range of values in each numeric column

**Constraints:** Use the actual dataset at `beginner-projects-main/AI-ML Beginners/projects/02_lemonade_stand/data/lemonade_days.csv`. Do not modify the file.

**Expected Behaviour:** Print or write down the column names, row count, and value ranges. State clearly which column is X and which is y.

**Acceptance Criteria:**
- [ ] All 3 column names are correctly identified: day, temperature_c, cups_sold
- [ ] Row count is correct (16 rows of data)
- [ ] Feature (temperature_c) and target (cups_sold) are correctly identified
- [ ] Temperature range and cups_sold range are noted
- [ ] The explanation correctly states X = temperature_c, y = cups_sold

**Hints:**
- Use `pd.read_csv()` to load the file and `df.shape` to count rows
- Use `df.describe()` to see value ranges
- The CSV header row is: day,temperature_c,cups_sold

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 1.3: DataFrame vs Series Shapes (10 min)
**Objective:** Understand why X uses double brackets and y uses single brackets in pandas
**Problem Statement:** In main.py, `X = df[["temperature_c"]]` uses double brackets while `y = df["cups_sold"]` uses single brackets. You need to explain the difference and verify the shapes.

**Requirements:**
1. Explain the difference between `df["column_name"]` (single brackets) and `df[["column_name"]]` (double brackets)
2. State the shape of X and the shape of y in the project
3. Explain why sklearn requires X to be 2D but accepts y as 1D

**Constraints:** Run actual code to verify shapes rather than guessing.

**Expected Behaviour:** A written explanation with code output showing `X.shape` and `y.shape`.

**Acceptance Criteria:**
- [ ] Single brackets → Series (1D) is correctly explained
- [ ] Double brackets → DataFrame (2D) is correctly explained
- [ ] X.shape is (16, 1) and y.shape is (16,)
- [ ] The explanation covers why sklearn needs 2D features
- [ ] The connection to `model.predict()` needing matching shapes is noted

**Hints:**
- Run `type(df["temperature_c"])` vs `type(df[["temperature_c"]])` to see the types
- sklearn's `fit()` expects X to have shape `(n_samples, n_features)`
- y can be 1D because there is only one target value per sample

**Difficulty:** Intermediate
**Estimated Completion Time:** 10 minutes

---

## Exercise 1.4: Prediction Target Analysis (10 min)
**Objective:** Identify the prediction goal and target temperature in the project
**Problem Statement:** Determine what the Lemonade Stand model predicts and at what temperature the prediction is made.

**Requirements:**
1. State what value the model predicts (the target variable)
2. Identify the specific temperature the model predicts for
3. Locate the line in main.py where the prediction DataFrame is created
4. Explain why 35°C was chosen as the prediction temperature

**Constraints:** Reference actual line numbers in main.py.

**Expected Behaviour:** A short written response with code references.

**Acceptance Criteria:**
- [ ] Correctly states prediction target is `cups_sold` (number of cups)
- [ ] Correctly identifies the prediction temperature is 35°C
- [ ] References `hot_day = pd.DataFrame({"temperature_c": [35.0]})` in main.py
- [ ] Provides a reasonable explanation for the 35°C choice (it represents a hot day for business planning)

**Hints:**
- The prediction appears in the console output line: "Prediction for 35 C: 44.6 cups"
- Look at the variable name `hot_day` — why is 35°C a "hot day"?
- The line `print(f"Prediction for 35 C: {hot_prediction:.1f} cups")` shows the prediction

**Difficulty:** Basic
**Estimated Completion Time:** 10 minutes