# Lesson 02: Coefficients and Intercept

**Lesson ID:** lesson-02
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain what `model.coef_` and `model.intercept_` represent
- Access the slope from `model.coef_[0]` using correct indexing
- Access the intercept from `model.intercept_`
- Convert numpy types to Python `float` for clean formatting
- Form the complete regression equation from the coefficients

## Prerequisites
- Lesson 01: Model is trained (model.fit() called)

## Concept Explanation

### What are coefficients?
After training, `model.coef_` stores the **slope** — the amount the target changes for a one-unit increase in each feature. Since we have one feature (temperature), `model.coef_` is an array with one element:

```
model.coef_ = array([1.5776...])
```

To get the actual numeric value, we use `model.coef_[0]` — indexing into the array to extract the first (and only) coefficient.

### What is the intercept?
`model.intercept_` is the **y-intercept** — the predicted value of the target when all features are zero. For our model:

```
model.intercept_ = -10.6617...
```

This means at 0°C, the model predicts -10.66 cups (not physically meaningful, but mathematically correct — the line extends below zero).

### Why is coef_ an array?
scikit-learn models support multiple features. If you had a model with three features (temperature, humidity, price), `model.coef_` would be an array with three elements: `[coef_temp, coef_humidity, coef_price]`. With one feature, it's an array with one element. The `[0]` indexing extracts the temperature coefficient.

### The regression equation
Once we have both values, the prediction equation is:

```
cups_sold = slope × temperature_c + intercept
cups_sold = 1.58 × temperature_c + (-10.66)
```

This means: for every 1°C increase in temperature, sales increase by approximately 1.58 cups. At 0°C, the model predicts -10.66 cups (a theoretical extrapolation).

### Why convert to float?
`model.coef_[0]` is a numpy `float64` type, and `model.intercept_` is also a numpy `float64`. Python's `float()` function converts these to native Python `float` objects, which:
1. Work seamlessly in f-strings with format specifiers like `:.2f`
2. Avoid potential issues with numpy scalar types in some formatting contexts
3. Make type checking clearer in your own code

## Relevant Code (from main.py, lines 41-42)
```python
slope = float(model.coef_[0])
intercept = float(model.intercept_)
```

### Line-by-line explanation
- `model.coef_[0]` — accesses the first element of the coefficients array (the slope for temperature_c)
- `float(...)` — converts the numpy float64 to a Python float
- `model.intercept_` — directly accesses the intercept scalar
- `float(...)` — converts the numpy float64 to a Python float

## Worked Example

```python
# After model.fit(X_train, y_train):
print(f"coef_ type: {type(model.coef_)}")          # <class 'numpy.ndarray'>
print(f"coef_ value: {model.coef_}")                # [1.577607...]
print(f"coef_[0] type: {type(model.coef_[0])}")    # <class 'numpy.float64'>
print(f"intercept_ type: {type(model.intercept_)}") # <class 'numpy.float64'>

# Extract with float conversion:
slope = float(model.coef_[0])
intercept = float(model.intercept_)

print(f"Slope: {slope}")            # 1.577607...
print(f"Intercept: {intercept}")    # -10.6617...
print(f"Equation: cups = {slope:.2f} * temp + {intercept:.2f}")
# Equation: cups = 1.58 * temp + -10.66

# Verify with manual calculation:
# At 35°C: 1.5776 * 35 + (-10.6618) = 55.216 - 10.6618 = 44.55...
print(f"Manual prediction at 35C: {slope * 35 + intercept:.2f}")
```

## Step-by-Step Student Instructions

1. **Ensure model is trained** — Confirm `model.fit(X_train, y_train)` has been called
2. **Access coef_** — Print `model.coef_` to see it's an array: `array([1.5776...])`
3. **Extract slope** — `slope = float(model.coef_[0])` — note the `[0]` indexing
4. **Access intercept** — Print `model.intercept_` to see it's a scalar
5. **Extract intercept** — `intercept = float(model.intercept_)`
6. **Form the equation** — Print `f"cups = {slope:.2f} × temperature + {intercept:.2f}"`
7. **Verify manually** — Compute `slope * 35 + intercept` and check it matches `hot_prediction`

## Expected Output or Observable Behaviour

```
coef_ type: <class 'numpy.ndarray'>
coef_ value: [1.577607...]
coef_[0] type: <class 'numpy.float64'>
intercept_ type: <class 'numpy.float64'>
Slope: 1.577607...
Intercept: -10.6617...
Equation: cups = 1.58 * temp + -10.66
Manual prediction at 35C: 44.55
```

## Practical Exercises

**Exercise 3.2:** Print slope and intercept and form the equation.
**Exercise 3.2b:** Try accessing `model.coef_0` (without brackets) and observe the error.
**Exercise 3.2c:** What is the type of `model.intercept_` before and after `float()` conversion?

## Common Mistakes and Debugging

| Mistake | Cause | Fix |
|---|---|---|
| `TypeError: float() argument must be a string or real number, not 'numpy.ndarray'` | Using `float(model.coef_)` without `[0]` | Use `float(model.coef_[0])` |
| `IndexError: index 0 is out of bounds` | coef_ is empty (model not fitted) | Call `model.fit()` first |
| `AttributeError: no attribute 'coef_'` | Model not trained | Call `model.fit(X_train, y_train)` before accessing coefficients |
| Negative intercept confusion | Intercept at 0°C is not meaningful | Remember the model only works within the data range (21-38°C) |

## Best Practices and Security Considerations
- **Extract coefficients after fit only**: Accessing `coef_` before `fit()` raises AttributeError
- **Index into coef_**: Even with one feature, `coef_` is an array — always use `[0]`
- **Convert to float for formatting**: Prevents potential numpy scalar formatting issues
- **No security risk**: Extracting model coefficients is a pure computation

## Summary

After training, `model.coef_[0]` gives the slope (how much cups change per degree) and `model.intercept_` gives the y-intercept. Both are wrapped in `float()` for clean formatting. The resulting equation `cups = 1.58 × temp + (-10.66)` can be used for manual predictions and verification.

## Knowledge-check Questions
1. What is model.coef_[0]?
2. What is model.intercept_?
3. Why do we need [0] to access the slope?
4. Why convert to float()?

## References
- scikit-learn LinearRegression.coef_: https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html#sklearn.linear_model.LinearRegression.coef_
- main.py lines 56-57