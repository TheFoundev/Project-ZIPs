# Lesson 03: Interpreting the Equation and Slope

**Lesson ID:** lesson-03
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Interpret the slope as a rate of change in the context of the problem
- Explain the intercept as a theoretical value at zero temperature
- Write meaningful interpretations of model coefficients for non-technical audiences
- Distinguish between correlation and causation when interpreting the model
- Apply the equation to make manual predictions

## Prerequisites
- Lesson 02: Coefficients and Intercept extracted
- Basic understanding of linear equations (y = mx + b)

## Concept Explanation

### The equation in context
The trained model produces the equation:

```
cups_sold = 1.58 × temperature_c + (-10.66)
```

This means: **for every 1°C increase in temperature, the model expects sales to increase by approximately 1.58 cups.**

### Interpreting the slope
main.py line 70 prints: `f"Meaning: each extra 1 C is associated with about {slope:.2f} more cups."`

This is the correct way to interpret the slope:
- **Positive slope (1.58)**: Higher temperature → more sales
- **Magnitude (1.58)**: Each degree adds about 1.58 cups
- **"Associated with"**: We use this language (not "causes") because correlation ≠ causation

**Example interpretations:**
- Going from 25°C to 26°C (a 1°C increase): ~1.58 more cups
- Going from 25°C to 35°C (a 10°C increase): ~15.8 more cups

### Interpreting the intercept
The intercept (-10.66) is the predicted cups sold when temperature = 0°C. This value is **not practically meaningful** because:
1. 0°C is outside the data range (minimum is 21.5°C)
2. Negative cups sold is impossible in reality
3. The intercept is a mathematical necessity of the linear equation, not a real prediction

The intercept is still important: it positions the line so the slope makes sense within the data range.

### Correlation vs. Causation
The positive slope tells us temperature and sales are **correlated** — they tend to move together. However, we **cannot conclude** that increasing temperature directly causes more lemonade sales. Other factors could explain the correlation:
- More people are outside on hot days
- People are thirstier on hot days
- Schools might be out (summer vacation) on hotter days

The model captures the observed pattern; it does not prove causation.

### Making manual predictions
Once we know the equation, we can predict without calling `model.predict()`:

**Prediction at 25°C:**
```
cups = 1.58 × 25 + (-10.66) = 39.5 - 10.66 = 28.84
```

**Prediction at 40°C:**
```
cups = 1.58 × 40 + (-10.66) = 63.2 - 10.66 = 52.54
```

These are extrapolations — the model is making predictions beyond the training data range (max 38.1°C). Extrapolation becomes less reliable as you move further from the observed data.

## Relevant Code (from main.py, lines 69-70)
```python
print(f"Model: cups = {slope:.2f} x temperature + {intercept:.2f}")
print(f"Meaning: each extra 1 C is associated with about {slope:.2f} more cups.")
```

### Code explanation
- `{slope:.2f}` — formats the slope to 2 decimal places (1.58)
- `{intercept:.2f}` — formats the intercept to 2 decimal places (-10.66)
- The "Meaning:" line translates the mathematical slope into a business-friendly interpretation
- Note the use of "associated with" rather than "causes" — careful language choice

## Worked Example

**Problem:** The model predicts 33.6 cups at 28°C. Verify this manually.

**Solution:**
```
cups = 1.5776 × 28 + (-10.6618)
    = 44.1728 - 10.6618
    = 33.511
```

Rounded to 1 decimal place: 33.5 cups. The model's prediction of 33.6 is consistent (small differences come from the `:.2f` rounding of slope and intercept in the equation display).

**Checking against the dataset:**
- Day with temp 27.6°C → 33 cups sold
- Day with temp 30.0°C → 38 cups sold
- At 28°C, interpolated expectation: ~33-35 cups
- Our model prediction of 33.6 cups is reasonable!

## Step-by-Step Student Instructions

1. **Read the equation** — Note the slope and intercept from the console output
2. **Interpret the slope** — What does 1.58 mean? Write it in plain language
3. **Address the intercept** — Explain why -10.66 is not a real prediction
4. **Make a prediction** — Choose a temperature within the data range and compute the predicted cups manually
5. **Compare with model** — If possible, verify your manual calculation against `model.predict()`
6. **Discuss limitations** — What does the model not account for?

## Expected Output or Observable Behaviour

The console shows:
```
Model: cups = 1.58 x temperature + -10.66
Meaning: each extra 1 C is associated with about 1.58 more cups.
```

Manual prediction at 30°C: `1.58 × 30 + (-10.66) = 47.4 - 10.66 = 36.74` ≈ 37 cups

The actual data point at 30°C shows 38 cups sold — the model's prediction is close but not exact, which is expected (the model fits a line, not perfect points).

## Practical Exercises

**Exercise 3.3:** If slope is 2.5, interpret it.
**Exercise 3.3b:** Interpret the intercept (-10.66) — is it a real prediction?
**Exercise 3.3c:** Predict cups at 28°C using the equation, then explain the result.

## Common Mistakes and Troubleshooting

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Interpreting slope as an intercept | Slope multiplies the feature; intercept is the constant | Slope is the rate of change per unit feature |
| Saying "temperature CAUSES more sales" | Correlation ≠ causation | Use "is associated with" or "predicts" |
| Expecting the intercept to be meaningful at 0°C | 0°C is outside the data range (21-38°C) | Interpret intercept as a mathematical artifact, not a real prediction |
| Thinking slope should be positive | It IS positive — more heat → more sales | Positive slope is correct for this problem |
| Claiming perfect predictions | Models have error (MAE = 2.16 cups) | Acknowledge prediction uncertainty |

## Best Practices and Security Considerations
- **Use careful language**: "associated with" rather than "causes" when interpreting coefficients
- **Acknowledge limitations**: Mention that the model is based on limited data (16 points)
- **Avoid extrapolation**: Predictions are most reliable within the observed data range (21-38°C)
- **No security risk**: Interpreting model coefficients is a pure analytical task

## Summary

The slope (1.58) means each additional degree Celsius is associated with about 1.58 more cups sold. The intercept (-10.66) is a mathematical artifact — at 0°C, the line predicts negative sales, but 0°C is outside our data range. The equation `cups = 1.58 × temp + (-10.66)` lets us make manual predictions and verify them against the model's output. Remember: association, not causation.

## Knowledge-check Questions
1. How to interpret slope?
2. What does intercept mean?
3. At 28°C, approximately how many cups would the model predict?
4. Why shouldn't we say "hot weather causes more lemonade sales"?

## References
- main.py line 70: `f"Meaning: each extra 1 C is associated with about {slope:.2f} more cups."`
- Simple linear regression: https://en.wikipedia.org/wiki/Simple_linear_regression
- Correlation vs causation: https://en.wikipedia.org/wiki/Correlation_does_not_imply_causation