# Lesson 04: End-to-End Training Workflow

**Lesson ID:** lesson-04
**Module:** module-03
**Duration:** 25-30 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Execute the complete model training workflow from instantiation to coefficient extraction
- Explain each step of the training pipeline and why it is necessary
- Verify that training produces valid coefficients and intercept values
- Debug common training errors (wrong data, missing fit, shape issues)
- Connect the trained model to the evaluation and prediction stages

## Prerequisites
- Lesson 01: LinearRegression in main.py (import, instantiate, fit)
- Lesson 02: Coefficients and Intercept (coef_, intercept_)
- Lesson 03: Understanding the Equation (interpreting slope and intercept)
- Module 02 completed (data is loaded and split)

## Concept Explanation

### The three-line training workflow
Training a LinearRegression model in scikit-learn requires exactly three lines:

```python
model = LinearRegression()          # Step 1: create the model (empty)
model.fit(X_train, y_train)         # Step 2: train it on training data
# Coefficients are now available:
slope = float(model.coef_[0])        # Step 3: extract the slope
intercept = float(model.intercept_)   # Step 4: extract the intercept
```

### Step 1: Instantiation — `LinearRegression()`
Creating `LinearRegression()` does **not** train the model. It simply creates an empty model object with default parameters (such as `fit_intercept=True` and `copy_X=True`). At this point, the model has no knowledge of your data. It's like having a blank notebook before you've written anything in it.

### Step 2: Training — `model.fit(X_train, y_train)`
The `fit()` method is where the actual learning happens. It takes:
- `X_train`: the training features (12 rows, 1 column: temperature_c)
- `y_train`: the training targets (12 values: cups_sold)

The method performs **ordinary least squares** optimization: it finds the slope and intercept values that minimize the sum of squared residuals (the vertical distances between each training point and the line). After `fit()` completes:
- `model.coef_` becomes an array containing the learned slope(s)
- `model.intercept_` becomes the learned y-intercept

### Step 3: Extracting coefficients
- `model.coef_[0]` — The slope for the first (and only) feature. It's an array even with one feature because sklearn supports multiple features. We access index `[0]` to get the single value.
- `model.intercept_` — The y-intercept, a scalar value directly.

We wrap both in `float()` to convert from numpy's `float64` type to a Python `float`, which makes them easier to format and work with in f-strings.

### Why only training data?
We fit exclusively on `X_train, y_train`, never on `X_test, y_test` or the full dataset. This is crucial: the test set must remain unseen by the model so that evaluation metrics (MAE, R²) provide an honest estimate of generalization performance.

## Relevant Code (from main.py, lines 55-57)
```python
model = LinearRegression()
model.fit(X_train, y_train)

slope = float(model.coef_[0])
intercept = float(model.intercept_)
```

### Line-by-line explanation
- `model = LinearRegression()` — creates a new, untrained LinearRegression instance
- `model.fit(X_train, y_train)` — trains the model: finds slope and intercept that best fit the 12 training data points
- `slope = float(model.coef_[0])` — extracts the coefficient for temperature_c and converts to Python float
- `intercept = float(model.intercept_)` — extracts the y-intercept and converts to Python float

## Worked Example: Training and Interpreting Results

```python
from sklearn.linear_model import LinearRegression

# Step 1: Create model (not yet trained)
model = LinearRegression()
print(f"Before fit — coef_: {model.coef_}")  # AttributeError! No, actually it raises this:

# Actually, accessing coef_ before fit raises an error
try:
    print(model.coef_)
except AttributeError as e:
    print(f"Error: {e}")
    # Output: 'LinearRegression' object has no attribute 'coef_'

# Step 2: Train the model
model.fit(X_train, y_train)

# Step 3: Extract coefficients (now available)
slope = float(model.coef_[0])
intercept = float(model.intercept_)
print(f"Slope: {slope:.4f}")        # ~1.5776
print(f"Intercept: {intercept:.4f}")  # ~-10.6618

# Step 4: Write the equation
print(f"Equation: cups = {slope:.2f} × temperature + ({intercept:.2f})")
# Output: Equation: cups = 1.58 × temperature + (-10.66)
```

**Expected output:**
```
Error: 'LinearRegression' object has no attribute 'coef_'
Slope: 1.5776
Intercept: -10.6618
Equation: cups = 1.58 × temperature + (-10.66)
```

## Step-by-Step Student Instructions

1. **Ensure data is ready** — Complete Module 02 so `X_train`, `y_train`, `X_test`, `y_test` exist
2. **Import LinearRegression** — `from sklearn.linear_model import LinearRegression`
3. **Create the model** — `model = LinearRegression()`
4. **Train the model** — `model.fit(X_train, y_train)`
5. **Check training succeeded** — Try printing `model.coef_` — it should show an array
6. **Extract the slope** — `slope = float(model.coef_[0])`
7. **Extract the intercept** — `intercept = float(model.intercept_)`
8. **Verify manually** — Pick one training point and check: `slope × temp + intercept ≈ cups_sold`

**Verification tip:** For a training point with temperature = 30.0 and cups_sold = 38:
`1.58 × 30 + (-10.66) = 47.4 - 10.66 = 36.74`
This is close to 38 but not exact — that's expected, as the line is a best-fit approximation.

## Expected Output or Observable Behaviour

After training:
```
Slope: 1.5776
Intercept: -10.6618
Equation: cups = 1.58 × temperature + (-10.66)
```

The model object has these attributes populated:
- `model.coef_` → `array([1.5776...])` — array with one element (one feature)
- `model.intercept_` → `-10.6618...` — scalar

If you try to access `coef_` before calling `fit()`, you get `AttributeError`.

## Practical Exercise (with Success Criteria)

**Task:** Train a LinearRegression model on the lemonade training data and extract the equation. Then manually verify the equation against one training data point.

**Success Criteria:**
- [ ] Model is created with `LinearRegression()` (no arguments needed)
- [ ] Model is trained with `model.fit(X_train, y_train)` (training data only)
- [ ] Slope is extracted as `float(model.coef_[0])`
- [ ] Intercept is extracted as `float(model.intercept_)`
- [ ] Equation is printed in the form `cups = slope × temperature + intercept`
- [ ] One manual verification shows the equation produces approximately correct output for a training point

## Common Mistakes and Troubleshooting

| Mistake | Cause | Fix |
|---|---|---|
| `AttributeError: no attribute 'coef_'` | Accessing coefficients before calling `fit()` | Call `model.fit()` first |
| `ValueError: Found input variables with inconsistent numbers of features` | X has wrong shape (1D instead of 2D) | Use `df[["temperature_c"]]` with double brackets |
| Training on test data | Using `X_test, y_test` for fit | Must use `X_train, y_train` |
| `TypeError: 'NoneType' object is not subscriptable` | Model variable is None | Ensure `LinearRegression()` is assigned to a variable before calling `fit` |
| Intercept is 0 | `fit_intercept=False` passed to constructor | Use default `LinearRegression()` which sets `fit_intercept=True` |

## Best Practices and Security Considerations

- **Fit once, use everywhere**: Train the model exactly once on the training set, then use it for all predictions
- **Never peek at test data during training**: Including test data in `fit()` invalidates your evaluation
- **Handle numpy types**: Convert `coef_` values to Python `float` when you need to format them in strings
- **Document your equation**: Print or log the learned equation so you can trace predictions back to it
- **No security risk**: Training a model on local data has no external security implications

## Summary

Training a LinearRegression model requires three steps: create an empty model, fit it on training data, and extract the learned coefficients. The `fit()` method performs ordinary least squares to find the best-fit line through the training points. After fitting, `model.coef_[0]` gives the slope (how much cups change per degree) and `model.intercept_` gives the intercept. Both must be wrapped in `float()` for clean formatting. The slope of ~1.58 means each additional degree adds ~1.58 cups of sales.

## Knowledge Check

1. What happens if you access `model.coef_` before calling `fit()`?
2. Why do we use `model.coef_[0]` instead of just `model.coef_`?
3. When should you call `fit()` relative to prediction?
4. Why do we wrap values in `float()`?

## References

- scikit-learn LinearRegression documentation: https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html
- Ordinary least squares method: https://en.wikipedia.org/wiki/Ordinary_least_squares
- main.py lines 37-38 (model training) and 55-57 (coefficient extraction)