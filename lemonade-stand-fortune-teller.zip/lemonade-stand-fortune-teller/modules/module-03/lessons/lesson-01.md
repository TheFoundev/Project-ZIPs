# Lesson 01: LinearRegression in main.py

**Lesson ID:** lesson-01
**Module:** module-03
**Duration:** 20-25 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Import `LinearRegression` from the correct sklearn module
- Explain what each component of the import path means
- Instantiate a `LinearRegression` model correctly
- Explain what `fit()` does and what it requires as input
- Distinguish between training (fit) and inference (predict)
- Understand the difference between `fit()` and `predict()` arguments

## Prerequisites
- Module 02 (data loaded, X/y separated, train/test split done)
- Understanding that X_train and y_train are ready for training

## Concept Explanation

### What is linear regression?
Linear regression is one of the oldest and simplest machine learning algorithms. It assumes the relationship between the input feature(s) and the target can be described by a straight line:

```
y = slope × x + intercept
```

In this project: `cups_sold = slope × temperature_c + intercept`

The algorithm finds the **slope** and **intercept** values that minimize the sum of squared differences between the predicted and actual values on the training data. This process is called **fitting** or **training**.

### The scikit-learn API for LinearRegression
scikit-learn follows a consistent API across all its estimators:

1. **Import**: `from sklearn.linear_model import LinearRegression`
   - `sklearn.linear_model` is the module containing linear models
   - `LinearRegression` is the specific class for linear regression

2. **Instantiate**: `model = LinearRegression()`
   - This creates an empty model with default parameters
   - At this point, the model has NO learned parameters

3. **Fit (train)**: `model.fit(X_train, y_train)`
   - This is where the magic happens
   - The method searches for the best slope and intercept
   - After `fit()`, `model.coef_` and `model.intercept_` become available

4. **Predict**: `model.predict(X)`
   - Uses the learned parameters to make predictions
   - Can be called on any data (training or new data)

### Parameters of LinearRegression (defaults used in main.py)
- `fit_intercept=True` (default): Whether to fit the intercept (y-axis crossing point). main.py uses the default.
- `copy_X=True` (default): Whether to copy the input data. main.py uses the default.
- `n_jobs=None` (default): Number of parallel jobs. main.py uses the default (single-threaded).

Since main.py uses `LinearRegression()` with no arguments, all defaults are used. This is the simplest configuration and works well for this small dataset.

### What fit() does internally
When you call `model.fit(X_train, y_train)`, the algorithm:
1. Receives the training features (12 rows, 1 column) and targets (12 values)
2. Computes the slope and intercept that minimize the residual sum of squares: `Σ(y_true - y_pred)²`
3. Stores the results as `model.coef_` (array with one element) and `model.intercept_` (scalar)
4. Marks the model as "fitted" so `predict()` can be called

## Relevant Code (from main.py, lines 18, 37-38)
```python
# Import (line 18):
from sklearn.linear_model import LinearRegression

# Instantiate and fit (lines 53-54):
model = LinearRegression()
model.fit(X_train, y_train)
```

### Line-by-line explanation
- `from sklearn.linear_model import LinearRegression` — imports the LinearRegression class from sklearn's linear_model module
- `model = LinearRegression()` — creates a new, untrained model instance with default parameters
- `model.fit(X_train, y_train)` — trains the model on the 12 training samples; after this call, `model.coef_` and `model.intercept_` are available

## Worked Example

```python
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import pandas as pd

# Assume df is loaded and X, y are created
X = df[["temperature_c"]]
y = df["cups_sold"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)

# Step 1: Create untrained model
model = LinearRegression()
print(f"Before fit — has coef_: {hasattr(model, 'coef_')}")
# Output: False (AttributeError would occur if we tried model.coef_)

# Step 2: Train the model
model.fit(X_train, y_train)
print(f"After fit — coef_: {model.coef_}")
print(f"After fit — intercept_: {model.intercept_}")
# Output: coef_: [1.5776...], intercept_: -10.6618...

# Step 3: Predict on test data
test_predictions = model.predict(X_test)
print(f"Test predictions: {test_predictions}")
```

## Step-by-Step Student Instructions

1. **Import LinearRegression** — Add `from sklearn.linear_model import LinearRegression` to your script
2. **Create the model** — Type `model = LinearRegression()` (no arguments needed)
3. **Fit the model** — Call `model.fit(X_train, y_train)` using the training split from Module 02
4. **Verify training succeeded** — Try accessing `model.coef_` — it should show an array like `[1.5776...]`
5. **Predict on test data** — Call `model.predict(X_test)` to see predictions for the test set

## Expected Output or Observable Behaviour

After fitting:
```
After fit — coef_: [1.577607...]
After fit — intercept_: -10.661771...
```

The slope is approximately 1.58 and the intercept is approximately -10.66, matching the values in main.py's console output.

## Practical Exercises

**Exercise 3.1:** Create LinearRegression, fit on X_train, y_train.
**Exercise 3.1b:** After fitting, print `model.coef_` and `model.intercept_` and verify they are not None.
**Exercise 3.1c:** What happens if you try to access `model.coef_` before calling `fit()`?

## Common Mistakes and Debugging

| Mistake | Cause | Fix |
|---|---|---|
| `AttributeError: 'LinearRegression' object has no attribute 'coef_'` | Accessing coefficients before calling `fit()` | Call `model.fit(X_train, y_train)` first |
| Fitting on all data | Using `fit(X, y)` instead of `fit(X_train, y_train)` | Use only training split to avoid data leakage |
| Fitting on test data | Using `fit(X_test, y_test)` | This is data leakage; test data must remain unseen during training |
| `ValueError: inconsistent numbers of features` | X is 1D (single brackets used) | Ensure X is a DataFrame with double brackets: `df[["temperature_c"]]` |

## Best Practices and Security Considerations
- **Fit on training data only**: Never use test data during training — it contaminates your evaluation
- **Use default parameters first**: The defaults work for this simple project; customize only when needed
- **Verify training succeeded**: Check that `coef_` is accessible before proceeding to prediction
- **No security risk**: Fitting a linear model on local numeric data is safe

## Summary

LinearRegression is imported from `sklearn.linear_model`, instantiated with default parameters, and trained with `model.fit(X_train, y_train)`. After fitting, the model stores the learned slope in `model.coef_` and the intercept in `model.intercept_`. The model must be trained before predictions can be made, and training must only use the training split.

## Knowledge-check Questions
1. What does the fit() method do?
2. On which data do we fit the model?
3. What attributes become available after fit()?
4. What error occurs if you access coef_ before fit()?

## References
- scikit-learn LinearRegression documentation: https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html
- sklearn linear_model module: https://scikit-learn.org/stable/modules/linear_model.html
- main.py lines 18, 53-54