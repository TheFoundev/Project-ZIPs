# Module 3 Exercises

## Exercise 3.1: Training the Model (15 min)
**Objective:** Instantiate and train a LinearRegression model on the training data
**Problem Statement:** Create a LinearRegression model and train it on the training split, then verify the training succeeded.

**Requirements:**
1. Import `LinearRegression` from `sklearn.linear_model`
2. Create the model: `model = LinearRegression()`
3. Train it: `model.fit(X_train, y_train)`
4. Verify training by checking that `model.coef_` and `model.intercept_` are now accessible

**Constraints:** Fit ONLY on training data, never on test data.

**Expected Behaviour:** Code that runs without errors and prints the slope and intercept after training.

**Acceptance Criteria:**
- [ ] LinearRegression is imported from the correct module
- [ ] Model is created with default parameters (no fitting before creation)
- [ ] `model.fit(X_train, y_train)` is called with training data only
- [ ] `model.coef_` is accessible after fit (an array with one value)
- [ ] `model.intercept_` is accessible after fit (a scalar)
- [ ] Both values are extracted using `float()` conversion

**Hints:**
- Before calling `fit()`, accessing `model.coef_` raises `AttributeError`
- After `fit()`, `model.coef_` is a numpy array like `array([1.5776...])`
- `model.coef_[0]` extracts the single coefficient for temperature_c
- `model.intercept_` is a scalar (not an array) for the single feature

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 3.2: Extracting and Interpreting the Equation (15 min)
**Objective:** Extract the model's slope and intercept and form the regression equation
**Problem Statement:** After training, extract the slope and intercept from the model and write the complete regression equation. Then interpret what each coefficient means.

**Requirements:**
1. Extract `slope = float(model.coef_[0])` and `intercept = float(model.intercept_)`
2. Form the equation: `cups = slope × temperature + intercept`
3. Interpret the slope in plain language (what it means for the lemonade stand)
4. Explain what the intercept represents (and why it may be negative)

**Constraints:** Use the actual trained model values, not hypothetical numbers.

**Expected Behaviour:** Printed equation with actual values (slope ≈ 1.58, intercept ≈ -10.66) and a plain-language interpretation.

**Acceptance Criteria:**
- [ ] Slope is extracted using `model.coef_[0]` wrapped in `float()`
- [ ] Intercept is extracted using `model.intercept_` wrapped in `float()`
- [ ] Equation is correctly formatted: `cups = slope × temperature + intercept`
- [ ] Slope interpretation: "each additional degree Celsius adds ~1.58 cups"
- [ ] Intercept explanation: "the theoretical prediction at 0°C, which is negative because the trend line extends below zero"
- [ ] Values match the actual project output

**Hints:**
- The slope is approximately 1.58 — meaning for every 1°C increase, sales increase by about 1.58 cups
- The intercept is approximately -10.66 — at 0°C, the model predicts -10.66 cups (not realistic, but mathematically correct)
- The intercept being negative is fine because 0°C is outside the data range (21-38°C)

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 3.3: Manual Prediction Verification (10 min)
**Objective:** Verify the model's prediction for 35°C using the equation directly
**Problem Statement:** Use the learned equation to manually compute the prediction for 35°C, then compare it with the model's actual prediction.

**Requirements:**
1. Compute `manual_prediction = slope * 35.0 + intercept`
2. Get the model's prediction: predict for 35°C using a DataFrame
3. Compare the two values and confirm they match (within rounding)
4. Explain any small differences

**Constraints:** Both methods should produce essentially the same result.

**Expected Behaviour:** Two predictions that differ at most by rounding (e.g., 44.55 from equation vs 44.6 from model.predict formatting).

**Acceptance Criteria:**
- [ ] Manual calculation uses `slope * 35.0 + intercept`
- [ ] Model prediction uses `pd.DataFrame({"temperature_c": [35.0]})` and `model.predict()`
- [ ] Both values are extracted as floats
- [ ] The two values match within expected rounding tolerance
- [ ] The explanation covers that both use the same learned equation

**Hints:**
- Manual: `1.5776 * 35 + (-10.6618) = 55.216 - 10.6618 = 44.5542...`
- Model: `float(model.predict(pd.DataFrame({"temperature_c": [35.0]}))[0])` ≈ 44.55
- The slight difference in the console output (44.6) is due to `:.1f` formatting

**Difficulty:** Intermediate
**Estimated Completion Time:** 10 minutes

---

## Exercise 3.4: Training Pipeline Replication (20 min)
**Objective:** Replicate the complete training section of main.py from memory
**Problem Statement:** Write the complete training code section that goes from importing LinearRegression through extracting the equation, without looking at main.py. Then verify it matches by running it.

**Requirements:**
1. Write the import statement for LinearRegression
2. Create the model instance
3. Fit on training data
4. Extract slope and intercept as floats
5. Print the equation in the same format as main.py

**Constraints:** Write the code without copying from main.py. Then run it and compare the equation output to the known values (slope ≈ 1.58, intercept ≈ -10.66).

**Expected Behaviour:** Working code that produces the same equation as main.py.

**Acceptance Criteria:**
- [ ] All 4 steps are present (import, create, fit, extract)
- [ ] `model.fit(X_train, y_train)` uses training data only
- [ ] `slope = float(model.coef_[0])` uses correct indexing
- [ ] `intercept = float(model.intercept_)` uses correct attribute
- [ ] Print output matches: `Model: cups = 1.58 x temperature + -10.66` (approximately)
- [ ] No errors or warnings during execution

**Hints:**
- Remember: `coef_` is an array, so you need `[0]` to get the single value
- `intercept_` is already a scalar, so no indexing needed
- The print format uses f-strings with `:.2f` for 2 decimal places
- The equation format is: `cups = {slope:.2f} x temperature + {intercept:.2f}`

**Difficulty:** Intermediate
**Estimated Completion Time:** 20 minutes