# Module 5 Exercises

## Exercise 5.1: Matplotlib Setup and Figure Creation (15 min)
**Objective:** Configure matplotlib for non-interactive plotting and create a figure/axes
**Problem Statement:** Set up the matplotlib environment exactly as main.py does, then create a figure with the same size.

**Requirements:**
1. Import matplotlib and set the Agg backend before importing pyplot
2. Import numpy, pandas, and the pyplot interface
3. Create a figure with `fig, ax = plt.subplots(figsize=(7, 5))`
4. Verify the figure and axes were created (check types)

**Constraints:** The `matplotlib.use("Agg")` call must appear before `import matplotlib.pyplot as plt`.

**Expected Behaviour:** Script runs without errors; `fig` and `ax` objects are created.

**Acceptance Criteria:**
- [ ] `import matplotlib` followed by `matplotlib.use("Agg")` followed by `import matplotlib.pyplot as plt` (correct order)
- [ ] `fig, ax = plt.subplots(figsize=(7, 5))` creates a figure and axes
- [ ] `type(fig)` is `matplotlib.figure.Figure`
- [ ] `type(ax)` is `matplotlib.axes.Axes`
- [ ] No GUI window opens during execution

**Hints:**
- The import order is critical: `matplotlib.use("Agg")` must come before `import matplotlib.pyplot`
- `plt.subplots()` returns a tuple `(fig, ax)` — use tuple unpacking
- `figsize=(7, 5)` means 7 inches wide by 5 inches tall
- No output to console is expected unless you add print statements

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 5.2: Scatter Plots for Training and Test Data (20 min)
**Objective:** Create a scatter plot showing training and test data with distinct visual styles
**Problem Statement:** Plot the training data points and test data points on the same axes, using different colors, markers, and labels.

**Requirements:**
1. Train the model (from Module 03) and split the data (from Module 02)
2. Plot training data: `ax.scatter(X_train, y_train, color="#e67e22", label="training days", s=55)`
3. Plot test data: `ax.scatter(X_test, y_test, color="#2c3e50", label="test days", s=55, marker="s")`
4. Add axis labels and a legend
5. Save to `outputs/scatter_exercise.png`

**Constraints:** Ensure X_train and y_train are 1D for scatter (use `.values.ravel()` on X if needed).

**Expected Behaviour:** A saved PNG file showing two clusters of points with a legend.

**Acceptance Criteria:**
- [ ] Training points are orange circles
- [ ] Test points are dark blue squares
- [ ] Legend shows "training days" and "test days"
- [ ] X-axis labeled "Temperature (C)" and y-axis labeled "Cups sold"
- [ ] File saved as `outputs/scatter_exercise.png`
- [ ] No errors during execution

**Hints:**
- `ax.scatter` needs 1D arrays; if `X_train` is a DataFrame, use `X_train["temperature_c"]` or `X_train.values.ravel()`
- `marker="s"` creates square markers; default is circle `"o"`
- `label=` sets the legend entry; you need `ax.legend()` to display the legend
- Ensure `OUT.mkdir(exist_ok=True)` is called before saving

**Difficulty:** Intermediate
**Estimated Completion Time:** 20 minutes

---

## Exercise 5.3: Regression Line and 35°C Prediction Marker (20 min)
**Objective:** Add the regression line and prediction marker to the scatter plot
**Problem Statement:** Extend your scatter plot by drawing the model's regression line across the full temperature range and marking the 35°C prediction with a red star.

**Requirements:**
1. Generate 100 evenly spaced x-values: `line_x = np.linspace(df["temperature_c"].min(), df["temperature_c"].max(), 100)`
2. Predict y-values along the line: `line_y = model.predict(pd.DataFrame({"temperature_c": line_x}))`
3. Plot the line: `ax.plot(line_x, line_y, color="#16a085", linewidth=2.5, label="learned trend line")`
4. Mark the prediction: `ax.scatter([35], [hot_prediction], color="#c0392b", s=140, marker="*", zorder=5, label="35 C prediction")`
5. Add legend and save

**Constraints:** The line must use the model's predictions (not the equation directly). The star marker must have `zorder=5`.

**Expected Behaviour:** A plot showing: orange circles (train), blue squares (test), green line (regression), red star (35°C prediction).

**Acceptance Criteria:**
- [ ] `line_x` has 100 values from min to max temperature
- [ ] `line_y` is computed via `model.predict()` on a DataFrame
- [ ] Regression line is green with width 2.5
- [ ] 35°C prediction is a red star with `zorder=5`
- [ ] Legend includes all four elements
- [ ] The star's y-value matches the model's prediction for 35°C

**Hints:**
- `np.linspace` generates evenly spaced values; passing a numpy array into a DataFrame works but creates a column with float dtype
- `ax.plot` draws a connected line; `ax.scatter` draws individual points
- `zorder=5` ensures the star appears on top of the line and other points
- The star is at coordinates (35, hot_prediction) where hot_prediction ≈ 44.6

**Difficulty:** Intermediate
**Estimated Completion Time:** 20 minutes

---

## Exercise 5.4: Complete Plot with Labels, Grid, and Save (15 min)
**Objective:** Finalize the plot with labels, title, legend, grid, and save it properly
**Problem Statement:** Add the final formatting touches to your plot and save it to the outputs directory with proper settings.

**Requirements:**
1. Add x-label "Temperature (C)" and y-label "Cups sold"
2. Add title "Lemonade sales vs. temperature"
3. Call `ax.legend()` to show the legend
4. Add a grid with `ax.grid(alpha=0.25)`
5. Call `fig.tight_layout()` to prevent clipping
6. Save with `fig.savefig(OUT / "lemonade_regression.png", dpi=150, bbox_inches="tight")`
7. Close the figure with `plt.close(fig)`

**Constraints:** Ensure the outputs directory exists before saving.

**Expected Behaviour:** A saved PNG file that opens correctly in an image viewer, showing all plot elements with proper labels.

**Acceptance Criteria:**
- [ ] Both axis labels are set correctly
- [ ] Title is "Lemonade sales vs. temperature"
- [ ] `ax.legend()` is called (after all scatter/plot calls)
- [ ] `ax.grid(alpha=0.25)` adds a light grid
- [ ] `fig.tight_layout()` is called before saving
- [ ] `fig.savefig` uses `dpi=150` and `bbox_inches="tight"`
- [ ] `plt.close(fig)` is called after saving
- [ ] The saved file is > 1KB (non-empty valid PNG)

**Hints:**
- `tight_layout()` should be called after all elements are added but before `savefig`
- `dpi=150` means 150 dots per inch — higher = more detail but larger file
- `bbox_inches="tight"` crops excess whitespace around the image
- `plt.close(fig)` prevents memory leaks; always call it after saving
- You can verify the file with `ls -la outputs/lemonade_regression.png`

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes