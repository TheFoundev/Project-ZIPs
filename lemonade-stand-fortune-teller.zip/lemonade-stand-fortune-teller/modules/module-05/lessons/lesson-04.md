# Lesson 04: Labels, Title, Grid, Legend, and Saving the Plot

**Lesson ID:** lesson-04
**Module:** module-05
**Duration:** 20-25 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Add axis labels, a title, a legend, and a grid to a matplotlib plot
- Use `fig.tight_layout()` to prevent label clipping
- Save a figure to a file with `fig.savefig()` using `dpi` and `bbox_inches` parameters
- Close the figure with `plt.close()` to free memory
- Verify the saved plot file and its location

## Prerequisites
- Module 05, Lesson 03 (scatter plot with regression line and prediction marker)
- Understanding that the plot elements are already drawn on `ax`

## Concept Explanation

### Axis labels and title
Every good plot needs clear labels:
- **`ax.set_xlabel("...")`** — labels the horizontal (x) axis
- **`ax.set_ylabel("...")`** — labels the vertical (y) axis
- **`ax.set_title("...")`** — sets the title displayed above the plot

These ensure that anyone viewing the plot understands what each axis represents and what the plot is about, even without additional context.

### Legend
A legend explains what the visual elements (colors, markers) mean. In matplotlib, you set a `label=` parameter on each plotting call (scatter, plot), then call `ax.legend()` to display the legend box. The legend will show each label with a small sample of the marker/line used.

### Grid
`ax.grid(alpha=0.25)` adds a light grid behind the data points. The `alpha=0.25` parameter controls transparency — a lower value makes the grid lighter so it doesn't overpower the data. Grids help readers trace values from points to axis tick marks.

### `fig.tight_layout()`
Matplotlib doesn't always leave enough room for axis labels and titles, especially when they are long. `fig.tight_layout()` automatically adjusts the spacing inside the figure so nothing gets cut off. It should be called after all elements are added but before saving.

### Saving the figure
`fig.savefig(path, dpi=150, bbox_inches="tight")` writes the plot to a file:
- **`path`**: the output file location (main.py uses `OUT / "lemonade_regression.png"`, where `OUT` is a pathlib `Path` object)
- **`dpi=150`**: dots per inch — higher values produce higher-resolution images (150 is good for screen viewing; 300+ is better for print)
- **`bbox_inches="tight"`**: crops extra whitespace around the saved image

### Closing the figure
`plt.close(fig)` releases the memory associated with the figure object. This is important in scripts that create multiple plots — without closing, memory usage accumulates and can become a problem.

## Relevant Code (from main.py, lines 66-74)
```python
ax.set_xlabel("Temperature (C)")
ax.set_ylabel("Cups sold")
ax.set_title("Lemonade sales vs. temperature")
ax.legend()
ax.grid(alpha=0.25)
fig.tight_layout()
fig.savefig(OUT / "lemonade_regression.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```

### Line-by-line explanation
- `ax.set_xlabel("Temperature (C)")` — labels the x-axis so viewers know it represents temperature in Celsius
- `ax.set_ylabel("Cups sold")` — labels the y-axis so viewers know it represents number of cups sold
- `ax.set_title("Lemonade sales vs. temperature")` — gives the plot a descriptive title
- `ax.legend()` — displays the legend box containing the labels set on each scatter and plot call
- `ax.grid(alpha=0.25)` — adds a semi-transparent grid for easier value reading
- `fig.tight_layout()` — adjusts subplot parameters so labels and title are not clipped
- `fig.savefig(OUT / "lemonade_regression.png", dpi=150, bbox_inches="tight")` — saves to the `outputs/` directory at 150 DPI with tight bounding box
- `plt.close(fig)` — closes the figure and frees memory

## Worked Example

```python
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

fig, ax = plt.subplots(figsize=(7, 5))

# (Imagine scatter and line plotting calls here from Lesson 03)

# Add labels, title, legend, grid
ax.set_xlabel("Temperature (C)")
ax.set_ylabel("Cups sold")
ax.set_title("My Lemonade Stand")
ax.legend()
ax.grid(alpha=0.25)

# Adjust layout and save
fig.tight_layout()
fig.savefig("my_plot.png", dpi=150, bbox_inches="tight")
plt.close(fig)

print("Plot saved to my_plot.png")
```

**Expected output:**
```
Plot saved to my_plot.png
```

A file `my_plot.png` appears in the working directory.

## Step-by-Step Student Instructions

1. **Add axis labels** — Call `ax.set_xlabel("Temperature (C)")` and `ax.set_ylabel("Cups sold")` after all plotting elements are on the axes.
2. **Add a title** — Call `ax.set_title("Lemonade sales vs. temperature")`.
3. **Add a legend** — Call `ax.legend()`. This will automatically use the `label=` values you set on each `scatter` and `plot` call.
4. **Add a grid** — Call `ax.grid(alpha=0.25)` for a light, non-distracting grid.
5. **Adjust layout** — Call `fig.tight_layout()` to prevent clipping.
6. **Save the figure** — Call `fig.savefig(path, dpi=150, bbox_inches="tight")` with the correct path.
7. **Close the figure** — Call `plt.close(fig)`.
8. **Verify** — Check that the file exists in the specified location.

## Expected Output or Observable Behaviour

- The plot window (if interactive) shows labeled axes, a title, a legend box, and grid lines
- A PNG file appears at the path specified in `savefig`
- The image has sufficient resolution (150 DPI) with no clipped labels or title
- No memory warnings appear (figure was properly closed)

## Practical Exercise (with Success Criteria)

**Task:** Take your plot from Lesson 03 and add all finishing touches: axis labels, title, legend, grid, tight layout, and save it to `outputs/finished_plot.png` with `dpi=150` and `bbox_inches="tight"`. Then close the figure.

**Success Criteria:**
- [ ] X-axis labeled "Temperature (C)"
- [ ] Y-axis labeled "Cups sold"
- [ ] A title is set
- [ ] `ax.legend()` is called and shows all plot elements
- [ ] `ax.grid(alpha=0.25)` is called
- [ ] `fig.tight_layout()` is called before saving
- [ ] `fig.savefig(...)` saves to the correct path with `dpi=150` and `bbox_inches="tight"`
- [ ] `plt.close(fig)` is called after saving
- [ ] The PNG file exists and is viewable

## Common Mistakes and Troubleshooting

| Mistake | Cause | Fix |
|---|---|---|
| Labels cut off in saved file | Forgot `tight_layout()` | Call `fig.tight_layout()` before `savefig` |
| Legend missing entries | `label=` not set on some plot calls | Ensure every `scatter` and `plot` call has a `label=` |
| Legend not showing at all | `ax.legend()` not called | Add the call after all plotting is done |
| Low-resolution saved image | Default dpi is 100 | Pass `dpi=150` or higher to `savefig` |
| File not found after save | Wrong path or directory doesn't exist | Use pathlib `OUT / "filename.png"` and ensure `OUT.mkdir(exist_ok=True)` was called |
| Memory warning on repeated plots | Figures not closed | Always call `plt.close(fig)` after `savefig` |

## Best Practices and Security Considerations

- **Always label plots**: A plot without labels or a title is not self-explanatory
- **Use `tight_layout()`**: It prevents common issues where labels are clipped at the edge of saved images
- **Choose appropriate DPI**: 150 DPI is good for screen viewing; use 300+ for print-quality images
- **Close figures**: Always call `plt.close()` to prevent memory accumulation in scripts
- **Use pathlib for paths**: `OUT / "filename.png"` works on all operating systems (unlike string concatenation with `/` or `\`)
- **No security risk**: Saving plots only writes numeric visualization data to a local file

## Summary

After plotting all data and lines, we add the finishing touches: axis labels tell viewers what each axis means, the title describes the plot, the legend explains the colors and markers, the grid aids readability, `tight_layout()` prevents clipping, and `savefig()` with proper DPI produces a high-quality file. Always close the figure afterward.

## Knowledge Check

1. What is the difference between `ax.set_xlabel()` and `ax.set_title()`?
2. When should you call `ax.legend()` — before or after adding labels to plot elements?
3. What does `bbox_inches="tight"` do in `savefig()`?
4. Why should you call `plt.close(fig)` after saving?

## References

- matplotlib `savefig` documentation: https://matplotlib.org/stable/api/_as_gen/matplotlib.figure.Figure.savefig.html
- matplotlib labeling documentation: https://matplotlib.org/stable/api/_as_gen/matplotlib.axes.Axes.set_xlabel.html
- matplotlib `tight_layout` documentation: https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.tight_layout.html
- main.py lines 66-74 (labels, title, legend, grid, save, close)