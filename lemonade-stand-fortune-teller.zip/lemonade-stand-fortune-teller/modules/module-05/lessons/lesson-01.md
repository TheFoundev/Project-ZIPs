# Lesson 01: Matplotlib Setup, Agg Backend, and Creating the Figure

**Lesson ID:** lesson-01
**Module:** module-05
**Duration:** 20-25 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain what a matplotlib backend is and why the choice matters for scripts
- Choose the Agg backend for non-interactive plotting
- Import matplotlib correctly so the backend is set before pyplot loads
- Create a figure and axis object (`fig, ax = plt.subplots`)
- Set the figure size for readable output

## Prerequisites
- Module 01 (basic Python and pandas)
- Module 04 (understanding how the model is trained and predictions are made)
- Understanding that main.py generates a visual scatter plot with a regression line

## Concept Explanation

### What is a backend?
Matplotlib can draw plots in two ways: it can open an interactive window on your screen (using your computer's display), or it can silently write an image file to disk without showing anything on screen. The mechanism that connects matplotlib to one of these behaviors is called a "backend."

Interactive backends — such as TkAgg, Qt5Agg, or GTK3Agg — open a window. They require a display server, which may not exist on a remote server, in a CI pipeline, or in some virtual environments. If you try to use an interactive backend without a display, your script will crash with an error like `no display name and no $DISPLAY environment variable`.

The **Agg** backend is a non-interactive, file-based backend. It renders plots directly to image files (PNG, JPEG, etc.) without ever trying to open a window. This makes it ideal for scripts that automatically generate and save plots — exactly what main.py does.

### Why must the backend be set before importing pyplot?
When you import `matplotlib.pyplot`, matplotlib automatically selects a default backend based on your system configuration. Once pyplot is imported, the backend is locked in. Calling `matplotlib.use("Agg")` *after* `import matplotlib.pyplot as plt` may print a warning and silently fail to switch backends. Therefore, the correct order in main.py is:

```python
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
```

### Creating a figure and axis
Matplotlib's object-oriented API uses two key objects:
- **Figure** (`fig`): the entire window or file that contains everything
- **Axes** (`ax`): the individual plot area with x-axis, y-axis, data, and labels

The function `plt.subplots(figsize=(width, height))` creates both a figure and a single axes object, returning them as a tuple. This is the recommended way to start a custom plot.

## Relevant Code (from main.py, lines 18-24)
```python
import matplotlib
matplotlib.use("Agg")   # non-interactive backend — save to file, no GUI window
import matplotlib.pyplot as plt
...
fig, ax = plt.subplots(figsize=(7, 5))
```

### Line-by-line explanation
- `import matplotlib` — loads the core matplotlib package without selecting a backend yet
- `matplotlib.use("Agg")` — sets the Agg backend **before** pyplot is loaded
- `import matplotlib.pyplot as plt` — imports the plotting interface; since backend is already Agg, no display is needed
- `fig, ax = plt.subplots(figsize=(7, 5))` — creates a figure 7 inches wide and 5 inches tall, plus a single axes object named `ax`

## Worked Example

Let's create a minimal plot that demonstrates the same setup main.py uses:

```python
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# Create a figure 7x5 inches
fig, ax = plt.subplots(figsize=(7, 5))

# Plot some sample data
temperatures = [20, 25, 30, 35]
sales = [20, 30, 35, 45]
ax.plot(temperatures, sales, marker='o', linestyle='--', color='green')

# Label the axes
ax.set_xlabel("Temperature (C)")
ax.set_ylabel("Cups Sold")
ax.set_title("Sample Lemonade Sales")

# Save to file — this is what Agg enables
fig.savefig("sample_plot.png", dpi=150, bbox_inches="tight")
plt.close(fig)  # always close to free memory
print("Plot saved to sample_plot.png")
```

**Expected output:**
```
Plot saved to sample_plot.png
```

And a file `sample_plot.png` appears in your working directory.

## Step-by-Step Student Instructions

1. **Set the backend** — In a new Python script, write the three import lines in the exact order main.py uses them. Put `matplotlib.use("Agg")` between the two imports.
2. **Create the figure** — Call `plt.subplots(figsize=(7, 5))` and unpack the result into `fig` and `ax`.
3. **Verify no display is needed** — Run the script on a machine without a display (or just run it; if it works, the Agg backend is set correctly). No window should open.
4. **(Optional) Add a test plot** — Plot a few points and save the figure to confirm the full pipeline works.
5. **Clean up** — Call `plt.close(fig)` after saving to release memory.

## Expected Output or Observable Behaviour

- The script runs without errors even if no display is available
- No pop-up window appears during execution
- A `.png` file is created when `fig.savefig(...)` is called
- The `fig` object has type `matplotlib.figure.Figure` and `ax` has type `matplotlib.axes.Axes`

## Practical Exercise (with Success Criteria)

**Task:** Write a script that replicates the matplotlib setup from main.py lines 12-13 and creates a figure/axes with `figsize=(7, 5)`. Add a simple line plot of two small arrays and save it to `outputs/test_plot.png`.

**Success Criteria:**
- [ ] `matplotlib.use("Agg")` is called before `import matplotlib.pyplot`
- [ ] `fig, ax = plt.subplots(figsize=(7, 5))` is present
- [ ] The plot file saves without errors
- [ ] `plt.close(fig)` is called after saving
- [ ] No GUI window opens

## Common Mistakes and Troubleshooting

| Mistake | Cause | Fix |
|---|---|---|
| RuntimeError about display/backend | Backend set after importing pyplot, or an interactive backend was selected | Move `matplotlib.use("Agg")` before `import matplotlib.pyplot as plt` |
| `plt.subplots()` returns unexpected type | Unpacking error | Ensure exactly `fig, ax = plt.subplots(...)` for a single axes |
| PNG file not created | `savefig` called before adding any plot elements, or wrong path | Ensure `fig.savefig(path)` runs and path directory exists |
| Plot window opens and freezes script | Agg backend not set, falling back to interactive backend | Double-check the order of imports |

## Best Practices and Security Considerations

- **Set backend before pyplot**: Always call `matplotlib.use()` before `import matplotlib.pyplot`
- **Close figures**: Use `plt.close(fig)` after `savefig` to prevent memory leaks in long-running scripts
- **Use pathlib for paths**: Use `OUT / "filename.png"` (as main.py does) instead of string concatenation to avoid cross-platform path issues
- **Use dpi and bbox_inches**: `dpi=150` improves resolution; `bbox_inches="tight"` prevents labels from being cut off
- **No security risk**: matplotlib does not execute code from data files; it only reads numeric/plot data

## Summary

The Agg backend allows main.py to create and save a scatter plot to a PNG file without requiring a graphical display. Setting the backend before importing pyplot is essential. The `fig, ax = plt.subplots(figsize=(7, 5))` pattern creates the canvas on which all subsequent plotting commands operate.

## Knowledge Check

1. What does a matplotlib backend control?
2. Why must `matplotlib.use("Agg")` come before `import matplotlib.pyplot as plt`?
3. What is the difference between `fig` and `ax` in `fig, ax = plt.subplots()`?
4. What does `figsize=(7, 5)` do?

## References

- matplotlib backends documentation: https://matplotlib.org/stable/users/explain/figure/backends.html
- Agg backend details: https://matplotlib.org/stable/gallery/user_interfaces/canvasagg.html
- main.py lines 12-13, 62