# Lesson 03: Drawing the Regression Line and Plotting the 35°C Prediction

**Lesson ID:** lesson-03
**Module:** module-05
**Duration:** 30-35 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain what a regression line represents in a scatter plot
- Generate a smooth sequence of x-values using `numpy.linspace()`
- Predict y-values along the line using `model.predict()` on a properly shaped DataFrame
- Draw a line plot with `ax.plot()` to overlay the regression trend
- Mark a specific prediction point (35°C) using a distinct marker, color, and size
- Use `zorder` to control which visual elements appear on top

## Prerequisites
- Module 03 (LinearRegression model has been trained; `coef_` and `intercept_` are known)
- Module 04 (making predictions with the model)
- Module 05, Lesson 02 (scatter plots of training and test data)
- Understanding that a linear regression model draws a straight line through the data points

## Concept Explanation

### What is a regression line?
A linear regression model learns the best-fit straight line through the training data. The line has the form:

```
y = slope × x + intercept
```

where `slope` (stored as `model.coef_[0]`) is the rate of change and `intercept` (stored as `model.intercept_`) is the predicted value when temperature is zero. The regression line visually summarizes the relationship the model learned: for every additional degree Celsius, sales increase by approximately `slope` cups.

### Why use `numpy.linspace()`?
To draw a smooth line, we need many points along the x-axis — not just the 16 data points from the dataset. `np.linspace(start, stop, num)` generates `num` evenly spaced values from `start` to `stop` (inclusive). In main.py:

```python
line_x = np.linspace(df["temperature_c"].min(), df["temperature_c"].max(), 100)
```

This creates 100 temperature values spanning the full range of the dataset, so the regression line appears smooth rather than jagged.

### Why predict with a DataFrame?
scikit-learn's `LinearRegression.predict()` expects input in the same 2D shape as the training features. Even though we are predicting 100 single-feature points, we must pass them as a DataFrame:

```python
line_y = model.predict(pd.DataFrame({"temperature_c": line_x}))
```

If we passed `line_x` (a numpy array of shape `(100,)`), sklearn would raise a `ValueError` about needing 2D input. By wrapping it in a DataFrame with the column name `temperature_c`, we match exactly what was used during training.

### What is `zorder`?
Matplotlib draws elements in the order they are called — later elements appear on top of earlier ones. `zorder` lets you override this: a higher `zorder` value brings an element to the front. The 35°C prediction star uses `zorder=5` so it always appears on top of the regression line and data points.

## Relevant Code (from main.py, lines 59-77, 91-94)
```python
# Generate 100 evenly spaced x values across the data range
line_x = np.linspace(df["temperature_c"].min(), df["temperature_c"].max(), 100)

# Predict y values along the line — must use a DataFrame, not a raw array
line_y = model.predict(pd.DataFrame({"temperature_c": line_x}))

# Draw the regression line
ax.plot(line_x, line_y, color="#16a085", linewidth=2.5, label="learned trend line")

# Mark the 35°C prediction with a prominent star
ax.scatter([35], [hot_prediction], color="#c0392b", s=140, marker="*",
           zorder=5, label="35 C prediction")
```

### Line-by-line explanation
- `np.linspace(df["temperature_c"].min(), df["temperature_c"].max(), 100)` — generates 100 temperatures from the coldest to the hottest day in the dataset
- `model.predict(pd.DataFrame({"temperature_c": line_x}))` — returns 100 predicted cup counts, one for each temperature along the line
- `ax.plot(line_x, line_y, ...)` — draws the green regression line connecting all 100 points; `linewidth=2.5` makes it thick and visible
- `ax.scatter([35], [hot_prediction], ...)` — places a large red star at the predicted sales for 35°C; `s=140` makes it bigger, `marker="*"` gives the star shape, `zorder=5` ensures it sits on top

## Worked Example

```python
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

# Load and prepare data
df = pd.read_csv("data/lemonade_days.csv")
X = df[["temperature_c"]]
y = df["cups_sold"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)

# Train model
model = LinearRegression()
model.fit(X_train, y_train)

# Make the 35°C prediction
hot_day = pd.DataFrame({"temperature_c": [35.0]})
hot_prediction = float(model.predict(hot_day)[0])

# Create the plot
fig, ax = plt.subplots(figsize=(7, 5))

# Plot data points
ax.scatter(X_train, y_train, color="#e67e22", label="training days", s=55)
ax.scatter(X_test, y_test, color="#2c3e50", label="test days", s=55, marker="s")

# Generate and plot the regression line
line_x = np.linspace(df["temperature_c"].min(), df["temperature_c"].max(), 100)
line_y = model.predict(pd.DataFrame({"temperature_c": line_x}))
ax.plot(line_x, line_y, color="#16a085", linewidth=2.5, label="learned trend line")

# Mark the 35°C prediction
ax.scatter([35], [hot_prediction], color="#c0392b", s=140, marker="*",
           zorder=5, label="35 C prediction")

# Labels and formatting
ax.set_xlabel("Temperature (C)")
ax.set_ylabel("Cups sold")
ax.set_title("Lemonade sales vs. temperature")
ax.legend()
ax.grid(alpha=0.25)

fig.savefig("regression_line_demo.png", dpi=150, bbox_inches="tight")
plt.close(fig)
print(f"Prediction for 35C: {hot_prediction:.1f} cups")
print("Plot saved.")
```

**Expected output:**
```
Prediction for 35C: 44.6 cups
Plot saved.
```

(The actual prediction in this project is ~44.6 cups based on the trained model.)

## Step-by-Step Student Instructions

1. **Train the model first** — Complete the data loading, splitting, and fitting steps from Modules 02-03 so `model` is ready.
2. **Generate the line x-values** — Type `line_x = np.linspace(df["temperature_c"].min(), df["temperature_c"].max(), 100)` and verify it's a numpy array with 100 elements.
3. **Predict along the line** — Call `model.predict(pd.DataFrame({"temperature_c": line_x}))` and store as `line_y`. Note: `line_y` is a numpy array with 100 predicted values.
4. **Draw the line** — Call `ax.plot(line_x, line_y, color="#16a085", linewidth=2.5, label="learned trend line")`.
5. **Mark the 35°C prediction** — Ensure you have `hot_prediction` from Module 04, then call `ax.scatter([35], [hot_prediction], color="#c0392b", s=140, marker="*", zorder=5, label="35 C prediction")`.
6. **Add labels and legend** — Call `ax.legend()` and add axis labels, title, and grid.
7. **Save and close** — `fig.savefig(...)` then `plt.close(fig)`.

## Expected Output or Observable Behaviour

- A smooth green line appears across the scatter plot, representing the linear trend the model learned
- A large red star appears at the point (35, ~44.6) on the far right of the plot
- The legend includes "training days", "test days", "learned trend line", and "35 C prediction"
- The line passes through the training points and extends across the full temperature range

## Practical Exercise (with Success Criteria)

**Task:** Add a regression line and 35°C prediction marker to your scatter plot from Lesson 02. The line should use `np.linspace` for 100 points and `model.predict` for the y-values. The prediction should be a red star (`marker="*"`) with a high `zorder`.

**Success Criteria:**
- [ ] Line uses `np.linspace` with 100 points across the data range
- [ ] Line y-values come from `model.predict(pd.DataFrame({"temperature_c": line_x}))`
- [ ] Line is drawn with `ax.plot()` and has a label for the legend
- [ ] 35°C prediction is plotted as a star with `marker="*"` and `zorder=5`
- [ ] The star's y-value matches the `hot_prediction` from the model
- [ ] Legend shows all four elements

## Common Mistakes and Troubleshooting

| Mistake | Cause | Fix |
|---|---|---|
| `ValueError: X has 1 feature but LinearRegression was trained on 1` | Passing a 1D numpy array instead of a DataFrame | Wrap in `pd.DataFrame({"temperature_c": line_x})` |
| Line appears jagged or short | Too few points in `linspace` | Use at least 50-100 points |
| Star marker hidden behind line | Low `zorder` value | Set `zorder=5` or higher for the prediction marker |
| Wrong column name in DataFrame | Typo in "temperature_c" | Copy the exact name from the training feature |
| `line_y` shape mismatch | Passing raw array to `predict` | Ensure DataFrame has one column named `temperature_c` |

## Best Practices and Security Considerations

- **Match training feature shape**: Always pass prediction inputs as 2D structures (DataFrame or 2D array) with the same column/feature names as training
- **Use enough points for smooth lines**: 100 points via `linspace` produces a clean line on any plot size
- **Control drawing order with `zorder`**: Important visual elements (like prediction markers) should have a high `zorder` so they are not hidden
- **No security risk**: Using `model.predict` on locally generated numeric data carries no security concerns

## Summary

The regression line visualizes the linear relationship the model learned. By generating 100 evenly spaced x-values and predicting corresponding y-values, we get a smooth trend line. The 35°C prediction is highlighted with a red star that uses `zorder` to stay visible on top of other elements.

## Knowledge Check

1. Why do we use 100 points from `linspace` instead of just the original data points?
2. Why must `line_y` be predicted using a DataFrame, not a raw numpy array?
3. What does `zorder=5` do for the prediction marker?
4. What does the regression line tell us about the relationship between temperature and sales?

## References

- numpy `linspace` documentation: https://numpy.org/doc/stable/reference/generated/numpy.linspace.html
- matplotlib `plot` documentation: https://matplotlib.org/stable/api/_as_gen/matplotlib.axes.Axes.plot.html
- scikit-learn LinearRegression.predict: https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html#sklearn.linear_model.LinearRegression.predict
- main.py lines 59-60 (line_x, line_y), 62-63 (hot_prediction), 64-65 (ax.plot), 66 (prediction marker)