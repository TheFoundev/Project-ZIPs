# Lesson 02: Scatter Plots — Visualising Training and Test Data

**Lesson ID:** lesson-02
**Module:** module-05
**Duration:** 25-30 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain why scatter plots are useful for bivariate data (two numeric variables)
- Distinguish between training data and test data visually using color and marker style
- Create scatter plots with `ax.scatter()` using custom colors, markers, and sizes
- Use legend labels to identify which points belong to which data split
- Interpret the relationship between points as the foundation for the regression line

## Prerequisites
- Module 01 (basic Python, pandas)
- Module 02 (train/test split with `train_test_split`)
- Module 05, Lesson 01 (matplotlib setup and Agg backend)
- Understanding that we have `X_train`, `y_train`, `X_test`, `y_test` from the split

## Concept Explanation

### What is a scatter plot?
A scatter plot displays individual data points as dots on a two-dimensional plane. Each dot's horizontal position corresponds to a value on the x-axis, and its vertical position corresponds to a value on the y-axis. For the Lemonade Stand project, we place **temperature** on the x-axis and **cups sold** on the y-axis.

Scatter plots reveal patterns in data:
- If the dots trend upward (left-to-right), the variables are positively correlated — as temperature increases, sales tend to increase
- If the dots trend downward, they are negatively correlated
- If the dots are scattered randomly with no clear direction, there is little or no linear relationship

### Why plot training and test data separately?
After calling `train_test_split`, we have two groups of data:
- **Training data** (`X_train`, `y_train`): the 75% of data the model learned from
- **Test data** (`X_test`, `y_test`): the 25% of data the model has not seen, used to evaluate performance

By plotting them in different colors and markers, we can visually confirm:
1. Both sets cover similar temperature ranges (the test set isn't in an unusual range)
2. The overall relationship (hotter = more sales) holds in both sets
3. We can later see how well the regression line (fit on training data) generalizes to test data

### Color, marker, and size parameters
In `ax.scatter()`:
- `color=` sets the dot color (hex codes like `"#e67e22"` produce consistent colors)
- `marker=` sets the dot shape (`"o"` = circle, `"s"` = square, `"^"` = triangle)
- `s=` sets the dot size in points squared
- `label=` sets the text that appears in the legend

## Relevant Code (from main.py, lines 26-27)
```python
ax.scatter(X_train, y_train, color="#e67e22", label="training days", s=55)
ax.scatter(X_test, y_test, color="#2c3e50", label="test days", s=55, marker="s")
```

### Line-by-line explanation
- `ax.scatter(X_train, y_train, ...)` — plots training data: x = each training temperature, y = each training cups-sold value
- `color="#e67e22"` — orange color for training points (the hex code `#e67e22` is a warm orange)
- `label="training days"` — text label that will appear in the legend
- `s=55` — marker size (slightly larger than default for visibility)
- `color="#2c3e50"` — dark blue color for test points (a cool, contrasting color)
- `marker="s"` — square markers, so test points look different from training points (which default to circles)
- `label="test days"` — legend label for test points

## Worked Example

```python
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.model_selection import train_test_split

# Simulate the lemonade data
data = {
    "temperature_c": [23.3, 30.0, 31.8, 21.5, 23.7, 37.7, 22.3, 23.3, 38.1, 32.2, 27.6, 30.2, 32.9, 26.0, 23.5, 35.2],
    "cups_sold":     [29, 38, 42, 25, 24, 48, 26, 24, 48, 40, 33, 35, 39, 32, 30, 48]
}
df = pd.DataFrame(data)

X = df[["temperature_c"]]
y = df["cups_sold"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)

fig, ax = plt.subplots(figsize=(7, 5))

# Plot training and test data with different styles
ax.scatter(X_train, y_train, color="#e67e22", label="training days", s=55)
ax.scatter(X_test, y_test, color="#2c3e50", label="test days", s=55, marker="s")

ax.set_xlabel("Temperature (C)")
ax.set_ylabel("Cups sold")
ax.set_title("Lemonade Sales: Training vs Test Data")
ax.legend()
ax.grid(alpha=0.25)

fig.savefig("scatter_demo.png", dpi=150, bbox_inches="tight")
plt.close(fig)
print("Scatter plot saved.")
```

**Expected output:**
```
Scatter plot saved.
```

A file `scatter_demo.png` appears showing orange circles (training data) and dark blue squares (test data) scattered across the plot, with both clusters trending upward from left to right — confirming that hotter temperatures are associated with more sales.

## Step-by-Step Student Instructions

1. **Start from your setup script** — Begin with the Agg backend imports and `fig, ax = plt.subplots(figsize=(7, 5))` from Lesson 01.
2. **Prepare the data** — Load `data/lemonade_days.csv`, create `X = df[["temperature_c"]]` and `y = df["cups_sold"]`, then split with `train_test_split(X, y, test_size=0.25, random_state=42)`.
3. **Plot training data** — Call `ax.scatter(X_train, y_train, color="#e67e22", label="training days", s=55)`.
4. **Plot test data** — Call `ax.scatter(X_test, y_test, color="#2c3e50", label="test days", s=55, marker="s")`.
5. **Add labels and legend** — Set x-label to "Temperature (C)", y-label to "Cups sold", add a title, and call `ax.legend()`.
6. **Save and close** — Save to a file and call `plt.close(fig)`.

## Expected Output or Observable Behaviour

- Two clusters of dots appear: orange circles for training data and dark blue squares for test data
- Both clusters trend upward (higher temperature → more sales)
- The legend shows "training days" and "test days" entries
- A saved PNG file is created

## Practical Exercise (with Success Criteria)

**Task:** Create a scatter plot of the lemonade data showing training and test points in different colors and markers. Add axis labels, a title, a legend, and a light grid. Save to `outputs/scatter_exercise.png`.

**Success Criteria:**
- [ ] Training points are one color (e.g., orange) with circle markers
- [ ] Test points are a different color (e.g., dark blue) with square markers
- [ ] A legend distinguishes the two sets
- [ ] X-axis labeled "Temperature (C)", y-axis labeled "Cups sold"
- [ ] A title is present
- [ ] File is saved as a PNG

## Common Mistakes and Troubleshooting

| Mistake | Cause | Fix |
|---|---|---|
| Passing a DataFrame to `scatter` | `X_train` is 2D; scatter needs 1D arrays | Use `X_train["temperature_c"]` or pass `X_train.values.ravel()` |
| Legend not showing entries | `label=` not set, or `ax.legend()` not called | Ensure each `scatter` call has a `label` and call `ax.legend()` once |
| Points overlapping and invisible | All points same color or too small | Use contrasting colors and `s=` large enough (e.g., 55+) |
| Error: "x and y must have same first dimension" | X and y shapes don't match | Verify `X_train` and `y_train` come from the same split call |

## Best Practices and Security Considerations

- **Use contrasting colors**: Choose colors that are distinguishable to colorblind viewers; avoid red/green pairs alone
- **Label everything**: Always include axis labels and legends so plots are self-explanatory
- **Use consistent hex colors**: Hex codes like `#e67e22` are reproducible across systems
- **No security risk**: Plotting data only involves reading numeric values from memory — no code execution from file contents

## Summary

Scatter plots let us see the relationship between temperature and lemonade sales. By plotting training and test data in different colors and markers, we can verify that both data splits cover similar ranges and show the same upward trend. This visual check is an essential part of exploratory data analysis and model diagnostics.

## Knowledge Check

1. What does each dot in a scatter plot represent?
2. Why do we use different colors/markers for training vs test data?
3. What does `label=` in `scatter()` control?
4. What does `s=55` control in `ax.scatter()`?

## References

- matplotlib `scatter` documentation: https://matplotlib.org/stable/api/_as_gen/matplotlib.axes.Axes.scatter.html
- seaborn-color palettes for accessible colors: https://seaborn.pydata.org/tutorial/color_palettes.html
- main.py lines 26-27 (scatter calls in the original project)
- main.py lines 14-15 (color constants: `#e67e22`, `#2c3e50`, `#16a085`, `#c0392b`)