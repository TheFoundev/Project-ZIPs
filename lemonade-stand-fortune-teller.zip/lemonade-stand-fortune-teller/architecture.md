# Architecture

## Pipeline (from main.py)
1. **Imports & Setup** - Use matplotlib Agg backend, import required libraries, create outputs dir
2. **Data Loading** - `pd.read_csv(DATA / "lemonade_days.csv")`
3. **Feature/Target** - X = `df[["temperature_c"]]`, y = `df["cups_sold"]`
4. **Train/Test Split** - `train_test_split(X, y, test_size=0.25, random_state=42)`
5. **Model Training** - `LinearRegression().fit(X_train, y_train)`
6. **Evaluation** - MAE on test set, R² score
7. **Prediction** - Predict for 35°C using DataFrame
8. **Visualization** - Scatter plots for train/test, regression line, prediction marker
9. **Output** - Save plot and prediction.txt

## Key Components
- **Data**: Historical temperature vs cups sold
- **Model**: Linear regression y = slope*x + intercept
- **Metrics**: MAE, R²
- **Visualization**: matplotlib plot

## Data Flow
CSV → pandas DataFrame → train/test split → LinearRegression → predictions + metrics → plot + files
