# All Correct Answers for Assessments
Project: The Lemonade Stand Fortune Teller
---

## Module 01
**q1-01.** In the Lemonade Stand project, what are we predicting?
   **Correct Answer:** b. Number of cups sold
   *Explanation:* The project predicts the number of cups sold from temperature.

**q1-02.** Which file contains the dataset used by main.py?
   **Correct Answer:** b. data/lemonade_days.csv
   *Explanation:* main.py reads data/lemonade_days.csv (line ~45).

**q1-03.** Which column is used as the feature (input)?
   **Correct Answer:** c. temperature_c
   *Explanation:* temperature_c is used as the feature X.

**q1-04.** Which column is used as the target (output)?
   **Correct Answer:** c. cups_sold
   *Explanation:* cups_sold is what we want to predict (target y).

**q1-05.** In main.py, how is X defined?
   **Correct Answer:** b. df[["temperature_c"]]
   *Explanation:* X = df[["temperature_c"]] uses double brackets.

**q1-06.** Why is X defined with double brackets in this project?
   **Correct Answer:** b. sklearn expects features in 2D shape (DataFrame)
   *Explanation:* scikit-learn expects features as 2D array/DataFrame (n_samples, n_features).

**q1-07.** This project is an example of:
   **Correct Answer:** c. Supervised regression
   *Explanation:* Labeled data (temperature + sales) used to predict continuous numeric value.

**q1-08.** The model predicts sales for what temperature?
   **Correct Answer:** c. 35°C
   *Explanation:* main.py creates hot_day DataFrame with 35.0 and predicts for it.

**q1-09.** Why is this called 'regression' rather than 'classification'?
   **Correct Answer:** b. We predict a continuous numeric value (number of cups)
   *Explanation:* Regression predicts continuous numeric values; classification predicts discrete categories.

**q1-10.** Which of the following best describes supervised learning here?
   **Correct Answer:** b. Learning from examples with known temperature and known cups sold
   *Explanation:* Supervised learning learns from labeled examples with known inputs and outputs.


## Module 02
**q2-01.** Which file does main.py read?
   **Correct Answer:** b. data/lemonade_days.csv
   *Explanation:* main.py reads data/lemonade_days.csv.

**q2-02.** What backend does main.py use for matplotlib?
   **Correct Answer:** c. Agg
   *Explanation:* matplotlib.use('Agg') sets non-interactive backend.

**q2-03.** In main.py, how is X created?
   **Correct Answer:** b. df[['temperature_c']]
   *Explanation:* X = df[['temperature_c']] uses double brackets for DataFrame.

**q2-04.** What is test_size in train_test_split?
   **Correct Answer:** b. 0.25
   *Explanation:* test_size=0.25 means 25% for testing.

**q2-05.** What is random_state=42 used for?
   **Correct Answer:** b. Reproducible train/test split
   *Explanation:* random_state ensures reproducible results.

**q2-06.** Why does main.py create outputs directory with mkdir(exist_ok=True)?
   **Correct Answer:** b. To ensure directory exists for saving outputs
   *Explanation:* Creates outputs directory if it doesn't exist for saving plot and prediction.txt.

**q2-07.** In main.py, y is assigned as:
   **Correct Answer:** b. df['cups_sold']
   *Explanation:* y = df['cups_sold'] uses single brackets for Series.

**q2-08.** What percentage of data is used for testing?
   **Correct Answer:** a. 25%
   *Explanation:* test_size=0.25 means 25% for testing.

**q2-09.** Why split data into train and test sets?
   **Correct Answer:** b. To evaluate model on unseen data
   *Explanation:* Testing on unseen data gives honest evaluation of model performance.

**q2-10.** After splitting with test_size=0.25, what goes to training?
   **Correct Answer:** b. 75%
   *Explanation:* If test is 25%, training is 75%.


## Module 03
**q3-01.** Which class is used to create the model?
   **Correct Answer:** b. LinearRegression
   *Explanation:* main.py uses sklearn.linear_model.LinearRegression.

**q3-02.** Which method trains the model?
   **Correct Answer:** b. fit()
   *Explanation:* fit() trains the model on training data.

**q3-03.** Where does main.py call fit()?
   **Correct Answer:** b. On X_train, y_train
   *Explanation:* model.fit(X_train, y_train)

**q3-04.** How does main.py get the slope?
   **Correct Answer:** b. model.coef_[0]
   *Explanation:* slope = float(model.coef_[0])

**q3-05.** How does main.py get the intercept?
   **Correct Answer:** a. model.intercept_
   *Explanation:* intercept = float(model.intercept_)

**q3-06.** The equation form is:
   **Correct Answer:** a. cups = slope * temperature + intercept
   *Explanation:* cups = slope * temperature + intercept

**q3-07.** What does coef_ contain?
   **Correct Answer:** a. The slope(s) for features
   *Explanation:* coef_ holds coefficients for each feature.

**q3-08.** According to main.py, slope means:
   **Correct Answer:** a. Each extra 1°C is associated with about slope more cups
   *Explanation:* Direct quote from main.py line 70.

**q3-09.** Why convert coef_[0] and intercept_ to float?
   **Correct Answer:** a. For string formatting in print statements
   *Explanation:* For clean string formatting in f-strings.

**q3-10.** When do we fit the model?
   **Correct Answer:** a. After splitting, before predicting/evaluating
   *Explanation:* Fit after split on training data, before prediction/evaluation.


## Module 04
**q4-01.** How does main.py predict for 35°C?
   **Correct Answer:** b. Creates DataFrame with temperature_c: [35.0] and calls predict()
   *Explanation:* main.py creates pd.DataFrame({'temperature_c': [35.0]}) and predicts.

**q4-02.** What method is used to predict?
   **Correct Answer:** b. predict()
   *Explanation:* predict() method makes predictions.

**q4-03.** Which function calculates MAE?
   **Correct Answer:** a. mean_absolute_error
   *Explanation:* from sklearn.metrics import mean_absolute_error

**q4-04.** Which function calculates R²?
   **Correct Answer:** a. r2_score
   *Explanation:* r2_score is imported and used.

**q4-05.** MAE is calculated on which data?
   **Correct Answer:** b. Test data (y_test vs test_predictions)
   *Explanation:* mae = mean_absolute_error(y_test, test_predictions)

**q4-06.** What does MAE measure?
   **Correct Answer:** a. Average absolute difference between predicted and actual
   *Explanation:* MAE = average of |y_true - y_pred|

**q4-07.** What does R² indicate?
   **Correct Answer:** a. Proportion of variance explained by the model
   *Explanation:* R² explains variance in target explained by model.

**q4-08.** hot_prediction is converted with float() because:
   **Correct Answer:** a. For formatting in output
   *Explanation:* For clean formatting in print statements.

**q4-09.** test_predictions comes from:
   **Correct Answer:** a. model.predict(X_test)
   *Explanation:* test_predictions = model.predict(X_test)

**q4-10.** Evaluating on test set is important because:
   **Correct Answer:** a. It shows performance on unseen data
   *Explanation:* Test set is unseen data, so gives unbiased performance estimate.


## Module 05
**q5-01.** What matplotlib backend does main.py use?
   **Correct Answer:** b. Agg
   *Explanation:* main.py sets matplotlib.use('Agg').

**q5-02.** Which file does main.py save the plot as?
   **Correct Answer:** b. lemonade_regression.png
   *Explanation:* Saved as outputs/lemonade_regression.png.

**q5-03.** How does main.py create the regression line x values?
   **Correct Answer:** a. np.linspace on temperature_c min and max
   *Explanation:* line_x = np.linspace(df['temperature_c'].min(), df['temperature_c'].max(), 100)

**q5-04.** Which data points does main.py plot as training data?
   **Correct Answer:** a. X_train, y_train
   *Explanation:* ax.scatter(X_train, y_train, color='#e67e22', label='training days', s=55)

**q5-05.** Which data points does main.py plot as test data?
   **Correct Answer:** a. X_test, y_test with different marker
   *Explanation:* Test points plotted with marker='s' and different color/label.

**q5-06.** How is the 35°C prediction marked on the plot?
   **Correct Answer:** a. Red star marker
   *Explanation:* ax.scatter([35], [hot_prediction], color='#c0392b', s=140, marker='*', ...)

**q5-07.** What does line_y represent?
   **Correct Answer:** a. Predictions from model.predict on line_x values
   *Explanation:* line_y = model.predict(pd.DataFrame({'temperature_c': line_x}))

**q5-08.** How does main.py save the figure?
   **Correct Answer:** a. fig.savefig with path to outputs/lemonade_regression.png
   *Explanation:* fig.savefig(OUT / 'lemonade_regression.png', dpi=150, bbox_inches='tight')

**q5-09.** Why use Agg backend in this script?
   **Correct Answer:** a. To save plots without opening a GUI window
   *Explanation:* Agg is a non-interactive backend for saving files without display.

**q5-10.** What label is used for the 35°C prediction in the legend?
   **Correct Answer:** a. "35 C prediction"
   *Explanation:* label='35 C prediction'


## Module 06
**q6-01.** What command runs the project?
   **Correct Answer:** a. python main.py
   *Explanation:* Run with 'python main.py' as stated in docstring.

**q6-02.** Which files are saved in outputs/?
   **Correct Answer:** a. lemonade_regression.png and prediction.txt
   *Explanation:* lemonade_regression.png and prediction.txt in outputs/.

**q6-03.** What does prediction.txt contain according to main.py?
   **Correct Answer:** a. Equation, prediction at 35 C, MAE, R-squared
   *Explanation:* Writes equation, prediction at 35 C, MAE, R-squared.

**q6-04.** What does console output show?
   **Correct Answer:** a. Model equation, meaning, MAE, R-squared, prediction for 35 C
   *Explanation:* Prints equation, meaning, MAE, R², and 35°C prediction.

**q6-05.** In main.py, after creating outputs dir, it saves files there. The path is built using:
   **Correct Answer:** a. OUT / filename
   *Explanation:* Uses pathlib OUT = BASE / 'outputs' and OUT / filename.

**q6-06.** The full pipeline order in main.py is:
   **Correct Answer:** a. Load data -> split -> fit -> predict/evaluate -> plot/save
   *Explanation:* Load, split, fit, predict/evaluate, plot/save.

**q6-07.** What happens if outputs/ doesn't exist?
   **Correct Answer:** a. main.py creates it with OUT.mkdir(exist_ok=True)
   *Explanation:* OUT.mkdir(exist_ok=True) creates it safely.

**q6-08.** The message printed includes:
   **Correct Answer:** a. "Saved: outputs/lemonade_regression.png, outputs/prediction.txt"
   *Explanation:* Last print statement shows saved files.

**q6-09.** To reproduce the project correctly, you should:
   **Correct Answer:** a. Follow the exact steps in main.py (imports, paths, split, fit, predict, plot, save)
   *Explanation:* Must follow the exact implementation pattern from main.py.

**q6-10.** Which of these is verified by running main.py successfully?
   **Correct Answer:** a. All dependencies installed, data exists, code runs, outputs created
   *Explanation:* Successful run confirms environment, data, and code are correct.

