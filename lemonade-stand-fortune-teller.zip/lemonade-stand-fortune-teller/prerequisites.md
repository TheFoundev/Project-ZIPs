# Prerequisites

## Skills Required
- Basic Python syntax (imports, functions, variables)
- Reading CSV files
- Basic understanding of variables and data
- Familiarity with command line

## Tools Required
- Python 3.7+
- pip
- Code editor (VS Code recommended)

## Packages
- pandas
- numpy
- matplotlib
- scikit-learn

## Knowledge to Review
- What is a dataset?
- Difference between input and output
- Basic plotting concepts
