# Glossary

| Term | Definition |
|---|---|
| Linear Regression | Predicts continuous value using linear equation y = mx + c |
| Supervised Learning | Learning from labeled data (features + target) |
| Feature (X) | Input variable used for prediction (temperature_c) |
| Target (y) | Output to predict (cups_sold) |
| Train/Test Split | Split data to train model and test on unseen data |
| Fit | Train model to learn coefficients |
| Predict | Use trained model to predict values |
| Slope (coef_) | Rate of change in target per unit change in feature |
| Intercept (intercept_) | Predicted value when feature is 0 |
| MAE (Mean Absolute Error) | Average absolute difference between predicted and actual |
| R² (R-squared) | Proportion of variance explained (0-1, higher better) |
| random_state | Seed for reproducible splits |
