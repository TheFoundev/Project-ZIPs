# Project Summary: The Exam Pass Predictor

## Overview
The Exam Pass Predictor utilizes **Logistic Regression** to classify whether a student will pass or fail an upcoming examination based on two input features: `hours_studied` and `attendance_percent`. Using historical records from 120 students in `data/student_results.csv` (referenced as `study_data.csv`), the project trains a binary classifier, interprets probability outputs, visualizes 2D decision contours, and investigates the trade-offs of shifting decision thresholds.

## Real-World Educational Use Case
Academic advisors and learning platforms can leverage probability estimates to deploy early-warning tutoring interventions. If a student's predicted probability of passing dips below 60%, advisors can reach out before midterms, allocating tutoring resources to students who need them most.

## Implemented Features
- Ingestion of 120 student academic records with 2 features and 1 binary target.
- Stratified 75/25 train/test split preserving the 77.5% pass / 22.5% fail class distribution.
- Logistic regression fitting with maximum iteration cap (`max_iter=1000`) for guaranteed solver convergence.
- Extraction of model weights: `hours_studied` weight $\approx 0.95$, `attendance_percent` weight $\approx 0.03$, intercept $\approx -5.10$.
- Continuous probability estimation via `model.predict_proba()`.
- Baseline test evaluation at 50% cutoff: Accuracy = 86.7%, Precision = 0.88, Recall = 0.96 for passing students.
- Analysis of 3 benchmark student profiles (6h/80% $\to$ 96%, 3h/60% $\to$ 44%, 8h/95% $\to$ 100%).
- Cutoff comparison: Raising threshold to 70% drops false positives from 3 to 0 and improves accuracy to 96.7%.
- 2D Decision boundary visualization using scikit-learn's `DecisionBoundaryDisplay`.
- Confusion matrix visualization using `ConfusionMatrixDisplay`.
- Textual metrics export to `outputs/metrics.txt`.

## Technical Stack
- **Language**: Python 3.8+
- **Data Analysis**: `pandas`
- **Visualization**: `matplotlib` (Agg backend)
- **Machine Learning**: `scikit-learn` (`LogisticRegression`, `train_test_split`, `metrics`, `inspection`)

## Project Structure
```
11_exam_pass_predictor/
├── main.py
├── data/
│   └── student_results.csv
└── outputs/
    ├── decision_boundary.png
    ├── confusion_matrix.png
    └── metrics.txt
```

## Concrete Model Parameters & Performance
- **Dataset Size**: 120 rows (93 passes [77.5%], 27 fails [22.5%])
- **Train/Test Split**: 90 training samples, 30 testing samples (`stratify=y`)
- **Hours Studied Weight**: +0.9516 (strongest predictor of exam success)
- **Attendance Percent Weight**: +0.0336 (moderate positive contribution)
- **Model Intercept**: -5.0964 (baseline log-odds at zero study and zero attendance)
- **Test Performance (0.5 Cutoff)**:
  - Accuracy: 86.7% (26 / 30 correct)
  - True Positives: 22
  - True Negatives: 4
  - False Positives: 3
  - False Negatives: 1
- **Benchmark Probabilities**:
  - Profile 1: 6 hours, 80% attendance $\to$ 96% pass probability
  - Profile 2: 3 hours, 60% attendance $\to$ 44% pass probability
  - Profile 3: 8 hours, 95% attendance $\to$ 100% pass probability
- **Cutoff 0.70 Performance**: 22 predicted passes, 0 false positives, 96.7% test accuracy

## Security & Ethics
- All computations are executed entirely locally with zero telemetry or network transmission.
- The dataset is synthetic and fully anonymized.
- In production, predictive models must guide constructive assistance rather than gatekeeping or punitive academic tracking.
