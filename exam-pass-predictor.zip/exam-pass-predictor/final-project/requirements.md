# Final Project Requirements: The Exam Pass Predictor

## Project Objective
Implement the complete Exam Pass Predictor binary classification pipeline from scratch, adhering to the architecture and methodology established in `main.py`. Your implementation must load the student dataset, train a logistic regression classifier, evaluate its predictive accuracy and confusion matrix, compute probability estimates for new student profiles, compare predictions across multiple probability cutoffs, render the 2D decision boundary visualization, and write all metrics to disk.

## Functional Requirements

### 1. Headless Setup and Library Ingestion
- Configure matplotlib with the non-interactive backend (`matplotlib.use("Agg")`) prior to importing `matplotlib.pyplot`.
- Import all required classes and functions from `pathlib`, `pandas`, `matplotlib`, and `sklearn`.
- Initialize directory paths using `pathlib.Path` relative to the script location.
- Ensure the destination `outputs/` folder is created safely with `mkdir(exist_ok=True)`.

### 2. Data Loading and Feature Matrix Assembly
- Load `student_results.csv` (or `study_data.csv`) from the `data/` subdirectory using `pd.read_csv()`.
- Construct the 2D feature matrix $X$ using double brackets: `df[["hours_studied", "attendance_percent"]]` (shape: 120 rows, 2 columns).
- Construct the 1D target vector $y$ using single brackets: `df["passed"]` (shape: 120 rows).

### 3. Stratified Data Partitioning
- Partition the dataset using `sklearn.model_selection.train_test_split`.
- Enforce `test_size=0.25`, `random_state=42`, and `stratify=y`.
- Verify that $X_{\text{train}}$ contains 90 rows (70 pass, 20 fail) and $X_{\text{test}}$ contains 30 rows (23 pass, 7 fail).

### 4. Classifier Training
- Instantiate `LogisticRegression(max_iter=1000)` from `sklearn.linear_model`.
- Fit the model using `model.fit(X_train, y_train)` on training data exclusively.
- Extract and format feature weights (`model.coef_[0, 0]` and `model.coef_[0, 1]`) and the intercept (`model.intercept_[0]`).

### 5. Probability Estimation and Inference
- Obtain test probabilities using `model.predict_proba(X_test)[:, 1]`.
- Convert probabilities to binary predictions using a 0.50 cutoff: `(probabilities >= 0.5).astype(int)`.
- Compute predicted probabilities for the 3 benchmark example student profiles:
  - Profile 1: 6 hours studied, 80% attendance (expected $\approx 96\%$)
  - Profile 2: 3 hours studied, 60% attendance (expected $\approx 44\%$)
  - Profile 3: 8 hours studied, 95% attendance (expected $\approx 100\%$)

### 6. Threshold Sensitivity Exploration
- Iterate over decision cutoffs 0.50 and 0.70.
- For each cutoff, compute predicted passes: `(probabilities >= cutoff).astype(int).sum()`.
- Display the total predicted passes out of the 30 test students.

### 7. Evaluation and Metrics Reporting
- Compute overall accuracy using `sklearn.metrics.accuracy_score(y_test, predictions)`.
- Generate the comprehensive text report using `sklearn.metrics.classification_report(y_test, predictions, zero_division=0)`.
- Compute the confusion matrix using `sklearn.metrics.confusion_matrix(y_test, predictions, labels=[0, 1])`.

### 8. Visualization Generation
- **Decision Surface Plot**:
  - Create figure with dimensions `figsize=(7.5, 5.5)`.
  - Use `DecisionBoundaryDisplay.from_estimator` with `response_method="predict_proba"`, `grid_resolution=250`, `cmap="RdYlBu_r"`, and `alpha=0.35`.
  - Superimpose scatter points for actual students color-coded by true pass/fail outcomes.
  - Configure titles, axis labels, legend for actual results, and save to `outputs/decision_boundary.png`.
- **Confusion Matrix Plot**:
  - Create figure with dimensions `figsize=(5, 4)`.
  - Use `ConfusionMatrixDisplay(cm, display_labels=["failed", "passed"]).plot(cmap="Blues", colorbar=False)`.
  - Add title and save to `outputs/confusion_matrix.png`.
  - Close all figures with `plt.close(fig)` to avoid memory leaks.

### 9. File Export
- Write `outputs/metrics.txt` containing the 0.5 cutoff accuracy score, the complete classification report, and probability predictions for each example student profile.

## Non-Functional Requirements
- **Reproducibility**: Use `random_state=42` during splitting to ensure identical test partitions across all runs.
- **Robust Path Resolution**: Avoid hardcoded path strings or OS-specific separators; use `pathlib.Path(__file__).resolve().parent`.
- **Numerical Integrity**: Ensure model predictions match the theoretical sigmoid function evaluations within standard floating-point precision.
- **Code Cleanliness**: Follow PEP 8 guidelines with clear docstrings, meaningful variable names, and explicit modular comments.

## Milestone Verification Checklist
| Milestone | Deliverable | Verification Check |
|---|---|---|
| M1: Ingestion | Data loaded into DataFrame | `df.shape == (120, 3)` |
| M2: Partitioning | Stratified train/test split | `X_train.shape == (90, 2)` and `X_test.shape == (30, 2)` |
| M3: Model Fitting | Converged LogisticRegression | `model.coef_.shape == (1, 2)` |
| M4: Probability Calc | `predict_proba` slice | `probabilities.min() >= 0.0` and `probabilities.max() <= 1.0` |
| M5: Cutoff Tuning | Cutoff comparison loop | 25 passes at 0.5 cutoff; 22 passes at 0.7 cutoff |
| M6: Decision Plot | 2D decision boundary PNG | File exists at `outputs/decision_boundary.png` |
| M7: Confusion Matrix | Confusion matrix PNG | File exists at `outputs/confusion_matrix.png` |
| M8: Metrics Export | Text summary file | File exists at `outputs/metrics.txt` with accuracy ~0.8667 |
