# Mentor Solution Guide: The Exam Pass Predictor

## Overview
This comprehensive guide provides mentors and instructors with the reference solution, implementation checkpoints, common student misconceptions, and verification standards for the Exam Pass Predictor project.

## Reference Implementation Walkthrough

```python
"""Project 11: Will You Pass? (logistic regression) - Reference Solution."""

from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.inspection import DecisionBoundaryDisplay
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay, confusion_matrix
from sklearn.model_selection import train_test_split

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)


def main() -> None:
    # 1. Ingestion
    df = pd.read_csv(DATA / "student_results.csv")
    X = df[["hours_studied", "attendance_percent"]]
    y = df["passed"]

    # 2. Stratified Split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )

    # 3. Model Training
    model = LogisticRegression(max_iter=1000)
    model.fit(X_train, y_train)

    # 4. Probabilities and Predictions
    probabilities = model.predict_proba(X_test)[:, 1]
    predictions = (probabilities >= 0.5).astype(int)
    accuracy = accuracy_score(y_test, predictions)

    print("=" * 60)
    print("WILL YOU PASS?")
    print("=" * 60)
    print(f"Accuracy at 50% cutoff: {accuracy:.1%}")
    print(f"Hours weight: {model.coef_[0, 0]:.2f}")
    print(f"Attendance weight: {model.coef_[0, 1]:.2f}")
    print("\nClassification report:\n")
    print(classification_report(y_test, predictions, zero_division=0))

    # 5. Benchmark Profiles
    examples = pd.DataFrame(
        [
            {"label": "6 hours, 80% attendance", "hours_studied": 6, "attendance_percent": 80},
            {"label": "3 hours, 60% attendance", "hours_studied": 3, "attendance_percent": 60},
            {"label": "8 hours, 95% attendance", "hours_studied": 8, "attendance_percent": 95},
        ]
    )
    example_probs = model.predict_proba(examples[["hours_studied", "attendance_percent"]])[:, 1]
    print("Example probabilities:")
    for label, probability in zip(examples["label"], example_probs):
        print(f"  {label:30s} -> {probability:.0%} chance of passing")

    # 6. Cutoff Exploration
    print("\nChanging the cutoff:")
    for cutoff in (0.5, 0.7):
        cutoff_predictions = (probabilities >= cutoff).astype(int)
        print(
            f"  cutoff {cutoff:.0%}: predicted {cutoff_predictions.sum()} passes "
            f"out of {len(cutoff_predictions)} test students"
        )

    # 7. Decision Boundary Plot
    fig, ax = plt.subplots(figsize=(7.5, 5.5))
    DecisionBoundaryDisplay.from_estimator(
        model,
        X,
        response_method="predict_proba",
        grid_resolution=250,
        cmap="RdYlBu_r",
        alpha=0.35,
        ax=ax,
    )
    scatter = ax.scatter(
        X["hours_studied"],
        X["attendance_percent"],
        c=y,
        cmap="RdYlBu_r",
        edgecolor="black",
        linewidth=0.5,
        s=55,
    )
    handles, _ = scatter.legend_elements()
    ax.legend(handles, ["failed", "passed"], title="actual result", loc="lower right")
    ax.set_xlabel("Hours studied")
    ax.set_ylabel("Attendance (%)")
    ax.set_title("The model learns a boundary between pass and fail")
    fig.tight_layout()
    fig.savefig(OUT / "decision_boundary.png", dpi=150, bbox_inches="tight")
    plt.close(fig)

    # 8. Confusion Matrix Plot
    cm = confusion_matrix(y_test, predictions, labels=[0, 1])
    fig, ax = plt.subplots(figsize=(5, 4))
    ConfusionMatrixDisplay(cm, display_labels=["failed", "passed"]).plot(
        ax=ax, cmap="Blues", colorbar=False
    )
    ax.set_title("Pass/fail predictions")
    fig.tight_layout()
    fig.savefig(OUT / "confusion_matrix.png", dpi=150, bbox_inches="tight")
    plt.close(fig)

    # 9. Text Export
    with open(OUT / "metrics.txt", "w", encoding="utf-8") as handle:
        handle.write(f"accuracy at 0.5 cutoff: {accuracy:.4f}\n\n")
        handle.write(classification_report(y_test, predictions, zero_division=0))
        handle.write("\nExample probabilities:\n")
        for label, probability in zip(examples["label"], example_probs):
            handle.write(f"{label}: {probability:.4f}\n")


if __name__ == "__main__":
    main()
```

## Detailed Mentor Checkpoints

### Checkpoint 1: Headless Backend Setting
- **Verification**: `matplotlib.use("Agg")` MUST precede `import matplotlib.pyplot as plt`.
- **Reason**: On remote Linux servers or Docker containers lacking display servers, importing pyplot before specifying the non-interactive Agg backend triggers graphical initialization warnings or errors.

### Checkpoint 2: Stratified Split Verification
- **Verification**: `stratify=y` must be specified inside `train_test_split`.
- **Validation Check**: Verify that `y_train.value_counts(normalize=True)` and `y_test.value_counts(normalize=True)` both match the raw dataset's 77.5% pass / 22.5% fail ratio.
- **Common Mistake**: Omitting `stratify=y`. In small datasets (120 rows with only 27 fail cases), random splitting can accidentally starve the test set of fail examples.

### Checkpoint 3: Probability Array Slicing
- **Verification**: `model.predict_proba(...)[:, 1]` must slice column index 1.
- **Explanation**: `predict_proba` returns an array of shape `(n_samples, 2)`. Column 0 corresponds to $P(y=0)$ (failing) and Column 1 corresponds to $P(y=1)$ (passing). Slicing column 0 would predict failing probability.

### Checkpoint 4: Understanding Cutoff Impact
- **At 0.50 cutoff**: 25 passes predicted, 5 fails. The model has 3 False Positives (predicts pass for 3 students who failed) and 1 False Negative. Overall accuracy = 86.7%.
- **At 0.70 cutoff**: 22 passes predicted, 8 fails. False Positives drop to 0! All 3 students who failed are now correctly flagged as failing. Accuracy rises to 96.7%.
- **Discussion Point**: In an academic intervention system, a False Positive is dangerous because an at-risk student is told "you're safe" and receives no tutoring. Raising the cutoff ensures that only students with strong probability are certified as safe.

### Checkpoint 5: Decision Boundary Surface
- **Verification**: `DecisionBoundaryDisplay.from_estimator` must use `response_method="predict_proba"`.
- **Styling**: `cmap="RdYlBu_r"` maps low probability (failing) to cool/red tones and high probability (passing) to blue tones.
