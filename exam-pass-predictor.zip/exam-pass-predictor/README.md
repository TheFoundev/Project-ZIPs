# The Exam Pass Predictor

**Category:** Supervised Binary Classification  
**Algorithm:** Logistic Regression  
**Style:** Low-code Python with scikit-learn & pandas  
**Dataset:** `data/student_results.csv` (120 student records)

## Project Overview
The Exam Pass Predictor addresses a critical challenge in educational analytics: predicting whether a student is likely to pass or fail an examination based on their preparation time (`hours_studied`) and course engagement (`attendance_percent`). 

Unlike continuous regression models that predict a numerical grade (e.g., 78.4 points), this project performs **binary classification**. Furthermore, rather than issuing a blind yes/no guess, the model outputs a **calibrated probability** (e.g., "96% chance of passing"). This enables students and educators to understand the degree of risk and make informed interventions.

## Key Learning Highlights
- **Binary Classification**: Understanding the distinct nature of categorical targets where outcomes are mutually exclusive (0 = fail, 1 = pass).
- **The Sigmoid Function**: How the logistic transformation turns linear combinations of study metrics into valid probabilities between 0.0 and 1.0.
- **Probabilistic Inference**: Contrasting discrete class decisions (`model.predict()`) with fine-grained risk estimates (`model.predict_proba()`).
- **Decision Boundaries**: Visualizing how machine learning draws a 2D separating boundary across features to distinguish pass and fail zones.
- **Cutoff Tuning**: Exploring how raising the passing threshold from 50% to 70% or 80% alters false alarms and missed warnings.
- **Comprehensive Evaluation**: Moving beyond raw accuracy to analyze confusion matrices, precision, recall, and F1-scores.

## Running the Project
```bash
cd "beginner-projects-main/AI-ML Beginners/projects/11_exam_pass_predictor"
python main.py
```

## Generated Artifacts
When executed, the pipeline creates:
- `outputs/decision_boundary.png`: 2D probability surface and actual student observations.
- `outputs/confusion_matrix.png`: Visual evaluation of true vs predicted passes and fails.
- `outputs/metrics.txt`: Model accuracy (86.7%), classification report, and probability predictions for student profiles.

## Package Structure
This comprehensive educational package contains 6 modular learning units:
1. **Module 01: Project Overview & Classification Fundamentals**
2. **Module 02: Data Ingestion & Binary Target Distributions**
3. **Module 03: The Mathematics of Logistic Regression & The Sigmoid Function**
4. **Module 04: Model Training, Inference & Probability Interpretation**
5. **Module 05: Evaluation Metrics, Confusion Matrix & Error Trade-offs**
6. **Module 06: Complete Pipeline, Decision Boundaries & Threshold Tuning**
