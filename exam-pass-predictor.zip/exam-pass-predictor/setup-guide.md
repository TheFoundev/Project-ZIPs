# Setup Guide

## Step 1: Navigate to Project Directory
Open your terminal or command prompt and change into the project workspace:
```bash
cd "beginner-projects-main/AI-ML Beginners/projects/11_exam_pass_predictor"
```

## Step 2: Set Up Python Environment
It is recommended to use a virtual environment to manage dependencies cleanly:
```bash
# Create virtual environment named venv
python3 -m venv venv

# Activate on Linux/macOS:
source venv/bin/activate

# Activate on Windows (Command Prompt):
# venv\Scripts\activate.bat

# Activate on Windows (PowerShell):
# venv\Scripts\Activate.ps1
```

## Step 3: Install Required Dependencies
Install the required scientific packages using `pip`:
```bash
pip install pandas matplotlib scikit-learn
```

Optionally, you can create a `requirements.txt` file:
```txt
pandas>=1.5.0
matplotlib>=3.6.0
scikit-learn>=1.2.0
```
And install via:
```bash
pip install -r requirements.txt
```

## Step 4: Verify the Dataset
Check the dataset located at `data/student_results.csv` (also referenced as `study_data.csv`):
```bash
head -n 5 data/student_results.csv
```
Expected output:
```text
hours_studied,attendance_percent,passed
9.5,98.0,1
4.2,63.0,1
8.1,62.0,1
6.3,81.0,1
```
Ensure that 120 student rows are present with columns `hours_studied`, `attendance_percent`, and `passed`.

## Step 5: Execute the Pipeline
Run the project script:
```bash
python main.py
```

## Step 6: Verify Generated Outputs
Confirm that the script completes with exit code 0 and populates the `outputs/` directory:
- `outputs/decision_boundary.png`: High-resolution plot illustrating the 2D decision boundary between pass and fail regions.
- `outputs/confusion_matrix.png`: Color-coded $2 \times 2$ confusion matrix showing test classifications.
- `outputs/metrics.txt`: Text file logging the 86.7% accuracy score, classification report, and probability predictions for benchmark student profiles.
