# Architecture

## End-to-End Pipeline (from main.py)
The Exam Pass Predictor executes a 9-stage supervised classification architecture:

1. **Environment & Backend Initialization**:
   - Explicitly sets `matplotlib.use("Agg")` prior to importing `pyplot` to guarantee headless server rendering without GUI dependencies.
   - Creates the `outputs/` directory safely using `Path.mkdir(exist_ok=True)`.

2. **Data Ingestion**:
   - Reads `student_results.csv` from the `data/` folder via `pd.read_csv()`.
   - Ingests 120 student observations consisting of `hours_studied`, `attendance_percent`, and `passed`.

3. **Feature-Target Decomposition**:
   - Feature Matrix ($X$): Selects `df[["hours_studied", "attendance_percent"]]` as a 2D pandas DataFrame of shape `(120, 2)`.
   - Target Vector ($y$): Selects `df["passed"]` as a 1D pandas Series of shape `(120,)` containing binary values $0$ and $1$.

4. **Stratified Train/Test Splitting**:
   - Calls `train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)`.
   - Stratification maintains the exact 77.5% pass / 22.5% fail ratio in both sets:
     - Training set ($X_{\text{train}}$, $y_{\text{train}}$): 90 samples (70 passed, 20 failed).
     - Testing set ($X_{\text{test}}$, $y_{\text{test}}$): 30 samples (23 passed, 7 failed).

5. **Model Instantiation & Training**:
   - Instantiates `LogisticRegression(max_iter=1000)` to ensure solver convergence.
   - Executes `model.fit(X_train, y_train)` on training data only.
   - Learns coefficients: $\beta_{\text{hours}} \approx 0.9516$, $\beta_{\text{attendance}} \approx 0.0336$, $\beta_0 \approx -5.0964$.

6. **Probabilistic Inference & Thresholding**:
   - Computes continuous probabilities on test set using `model.predict_proba(X_test)[:, 1]`.
   - Applies default 50% decision cutoff: $\hat{y} = (P \ge 0.50).\text{astype(int)}$.
   - Evaluates custom cutoffs at 70% and 80% to demonstrate threshold control.

7. **Performance Evaluation**:
   - Calculates overall test accuracy with `accuracy_score(y_test, predictions)` (86.7%).
   - Generates full precision, recall, and F1-score summary via `classification_report(y_test, predictions, zero_division=0)`.
   - Computes test confusion matrix via `confusion_matrix(y_test, predictions, labels=[0, 1])`.

8. **Visualization Generation**:
   - Decision Surface: Calls `DecisionBoundaryDisplay.from_estimator(model, X, response_method="predict_proba", cmap="RdYlBu_r")` and superimposes scatter points.
   - Confusion Matrix: Generates `ConfusionMatrixDisplay` plot with blue color intensity.

9. **Artifact Export & Cleanup**:
   - Writes metrics, classification report, and profile predictions to `outputs/metrics.txt`.
   - Saves figures to `outputs/decision_boundary.png` and `outputs/confusion_matrix.png`.
   - Calls `plt.close(fig)` to reclaim system graphical memory.

## Component Interaction Diagram
```
+-------------------------------------------------------+
|              student_results.csv (120 rows)           |
+-------------------------------------------------------+
                           |
                           v
      +--------------------+--------------------+
      |                                         |
      v                                         v
+---------------+                       +---------------+
| X (120, 2)    |                       | y (120,)      |
| hours, attend |                       | passed (0/1)  |
+---------------+                       +---------------+
      |                                         |
      +--------------------+--------------------+
                           |
                           v
        train_test_split(stratify=y, test_size=0.25)
                           |
          +----------------+----------------+
          |                                 |
          v                                 v
+-------------------+             +-------------------+
| X_train, y_train  |             | X_test, y_test    |
| (90 samples)      |             | (30 samples)      |
+-------------------+             +-------------------+
          |                                 |
          v                                 |
+-------------------+                       |
| LogisticRegression|                       |
| model.fit(...)    |                       |
+-------------------+                       |
          |                                 |
          +----------------+----------------+
                           |
                           v
            model.predict_proba(X_test)
                           |
         +-----------------+-----------------+
         |                                   |
         v                                   v
+------------------+               +------------------+
| Cutoff = 0.50    |               | Cutoff = 0.70    |
| 25 Pass / 5 Fail |               | 22 Pass / 8 Fail |
| Acc: 86.7%       |               | Acc: 96.7%       |
+------------------+               +------------------+
         |
         v
+-----------------------------------------------------+
| Outputs: decision_boundary.png, confusion_matrix.png|
|          metrics.txt                                |
+-----------------------------------------------------+
```
