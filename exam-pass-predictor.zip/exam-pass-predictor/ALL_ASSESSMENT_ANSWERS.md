# All Correct Answers for Assessments
Project: Exam Pass Predictor: Binary Classification & Probability Modeling with Logistic Regression
---

## Module 01: Project Overview & Binary Classification Foundations

**q1-01.** What is the primary prediction goal of the Exam Pass Predictor project?
   **Correct Answer:** b. To predict whether a student passes or fails based on study hours and attendance
   *Explanation:* The project uses hours studied and attendance percentage to classify whether a student passes (1) or fails (0) an examination.
   *Option Breakdown:*
   - **a (To predict the exact continuous test score (0-100) a student earns):** Predicting exact continuous test scores (0-100) is a regression task handled by the Exam Score Predictor, not binary pass/fail classification.
   - **c (To forecast the total number of students enrolled in the course):** The model does not forecast course enrollment counts; it models individual student exam outcomes.
   - **d (To cluster students into unsupervised study groups):** The project is supervised classification on labeled historical records, not unsupervised clustering.

**q1-02.** What type of machine learning problem does the Exam Pass Predictor represent?
   **Correct Answer:** c. Supervised binary classification
   *Explanation:* Because the outcome belongs to one of exactly two mutually exclusive categories (0 = fail, 1 = pass) with labeled training data, this is supervised binary classification.
   *Option Breakdown:*
   - **a (Unsupervised dimensionality reduction):** Dimensionality reduction compresses feature spaces without predicting an outcome label.
   - **b (Supervised continuous regression):** Continuous regression predicts real numbers like house prices or test scores, not discrete binary categories.
   - **d (Reinforcement learning):** Reinforcement learning learns through agent-environment rewards, not fixed tabular training records.

**q1-03.** Which CSV file in the project's data directory contains the 120 student training records?
   **Correct Answer:** a. data/student_results.csv
   *Explanation:* main.py line 29 explicitly reads data/student_results.csv using pd.read_csv(DATA / 'student_results.csv').
   *Option Breakdown:*
   - **b (data/exam_grades.csv):** exam_grades.csv does not exist in the project repository.
   - **c (data/lemonade_days.csv):** lemonade_days.csv is the dataset for the Lemonade Stand linear regression project.
   - **d (data/class_attendance.csv):** class_attendance.csv is an imaginary filename not used by main.py.

**q1-04.** Why is standard Ordinary Least Squares (OLS) linear regression unsuitable for predicting probability of passing?
   **Correct Answer:** b. Linear regression produces unconstrained outputs that can fall below 0.0 or exceed 1.0
   *Explanation:* A straight regression line extends toward positive and negative infinity, generating nonsensical predictions below 0.0 or above 1.0 for extreme inputs.
   *Option Breakdown:*
   - **a (Linear regression cannot run on datasets with more than 10 rows):** Linear regression can easily run on datasets with thousands or millions of rows; size is not the limiting factor.
   - **c (Linear regression requires all input features to be categorical strings):** Linear regression strictly requires numerical inputs, not categorical strings.
   - **d (Scikit-learn does not provide a linear regression class):** Scikit-learn provides LinearRegression in sklearn.linear_model, but its mathematical formulation is inappropriate for probabilities.

**q1-05.** Which scikit-learn class is imported in main.py to build the classification model?
   **Correct Answer:** b. sklearn.linear_model.LogisticRegression
   *Explanation:* main.py line 18 imports LogisticRegression from sklearn.linear_model to perform binary classification.
   *Option Breakdown:*
   - **a (sklearn.linear_model.LinearRegression):** LinearRegression is used for continuous targets, not binary classification.
   - **c (sklearn.cluster.KMeans):** KMeans is an unsupervised clustering algorithm.
   - **d (sklearn.tree.DecisionTreeRegressor):** DecisionTreeRegressor predicts continuous numbers using tree partitioning.

**q1-06.** Why is a probability estimate (e.g., 96% chance of passing) more valuable to an academic advisor than a simple 'PASS' label?
   **Correct Answer:** b. It quantifies the degree of student risk and certainty, enabling prioritized interventions
   *Explanation:* Probabilities quantify certainty and risk (e.g., 51% vs 99%), allowing advisors to allocate tutoring to borderline students who need it most.
   *Option Breakdown:*
   - **a (It guarantees that the student will get an A on the test):** A 96% probability is an estimate, not an absolute guarantee of obtaining an A grade.
   - **c (It eliminates the need to train a machine learning model):** Computing probabilities requires fitting a calibrated machine learning model; it does not eliminate modeling.
   - **d (It allows the school to replace human academic advisors completely):** AI models assist and empower human educators; they do not replace academic counselors.

**q1-07.** In supervised classification, what do the labeled historical records consist of?
   **Correct Answer:** b. Known input features paired with known ground-truth target outcomes
   *Explanation:* Supervised learning requires labeled examples where both explanatory inputs (features) and ground-truth targets (labels) are provided.
   *Option Breakdown:*
   - **a (Only independent input features with unknown outcomes):** Unlabeled inputs describe unsupervised learning, where target outcomes are absent.
   - **c (Randomly generated numbers without real-world context):** Machine learning relies on empirical real-world observations, not ungrounded random numbers.
   - **d (Only target labels with no recorded explanatory features):** Targets without features provide no input signals to learn predictive relationships.

**q1-08.** Which three files are generated in the outputs/ directory when main.py completes execution?
   **Correct Answer:** b. decision_boundary.png, confusion_matrix.png, and metrics.txt
   *Explanation:* main.py lines 98, 109, and 112 save decision_boundary.png, confusion_matrix.png, and metrics.txt to the outputs/ directory.
   *Option Breakdown:*
   - **a (model.pkl, weights.csv, and summary.html):** The script does not serialize weights to model.pkl or generate HTML summaries.
   - **c (report.pdf, predictions.csv, and chart.svg):** The pipeline generates PNG graphics and plain text, not PDF or SVG formats.
   - **d (output.log, regression_line.png, and results.json):** The script produces decision_boundary.png and metrics.txt, not output.log or results.json.

**q1-09.** If a linear model outputs a prediction of 1.35 for a student's pass status, what fundamental mathematical rule of probability is violated?
   **Correct Answer:** b. Probabilities must strictly reside in the interval between 0.0 and 1.0
   *Explanation:* By definition, probabilities represent values bounded strictly within the interval [0.0, 1.0]. A value of 1.35 violates fundamental probability axioms.
   *Option Breakdown:*
   - **a (Probabilities must be negative numbers):** Probabilities can never be negative; negative values are invalid probabilities.
   - **c (Probabilities must always be integers):** Probabilities are continuous real numbers between 0 and 1, not restricted to integers.
   - **d (Probabilities must sum to zero across all samples):** Probabilities of mutually exclusive events in a distribution sum to 1, but individual probabilities do not sum to 0.

**q1-10.** Why does main.py invoke matplotlib.use('Agg') before importing matplotlib.pyplot?
   **Correct Answer:** b. To select a headless non-interactive backend that saves images without requiring a GUI display
   *Explanation:* The 'Agg' backend renders raster charts into memory buffers without trying to open an interactive GUI window, enabling reliable headless script execution.
   *Option Breakdown:*
   - **a (To configure 3D graphic acceleration for video game rendering):** Agg is a 2D software rendering rasterizer (Anti-Grain Geometry), not a 3D hardware accelerator.
   - **c (To increase the numerical accuracy of scikit-learn's logistic regression solver):** The matplotlib backend only affects graphical rendering; it has zero impact on scikit-learn optimization solvers.
   - **d (To convert the pandas DataFrame into a NumPy array automatically):** Matplotlib does not convert pandas DataFrames to NumPy arrays; that is handled by pandas and sklearn.

## Module 02: Data Ingestion & Binary Target Distributions

**q2-01.** How many total student observations are contained in student_results.csv?
   **Correct Answer:** c. 120 students
   *Explanation:* The dataset student_results.csv contains exactly 120 student rows, with indices 0 through 119.
   *Option Breakdown:*
   - **a (28 students):** 28 students was the sample size in the continuous Exam Score Predictor project.
   - **b (90 students):** 90 students is the size of the training split, not the entire raw dataset.
   - **d (500 students):** 500 students is an exaggerated number; the file contains exactly 120 records.

**q2-02.** What are the two input features used in the feature matrix X?
   **Correct Answer:** a. hours_studied and attendance_percent
   *Explanation:* main.py line 30 explicitly selects hours_studied and attendance_percent as the input feature matrix X.
   *Option Breakdown:*
   - **b (student_id and exam_score):** student_id is not present in the dataset, and exam_score was the continuous target in project 06.
   - **c (grade_point_average and homework_completion):** grade_point_average and homework_completion are not columns in student_results.csv.
   - **d (temperature_c and cups_sold):** temperature_c and cups_sold are the features and target from the Lemonade Stand project.

**q2-03.** In main.py, how is the feature matrix X extracted from the DataFrame df?
   **Correct Answer:** b. X = df[['hours_studied', 'attendance_percent']]
   *Explanation:* Double square brackets df[['hours_studied', 'attendance_percent']] pass a list of column names, returning a 2D DataFrame required by scikit-learn.
   *Option Breakdown:*
   - **a (X = df['hours_studied', 'attendance_percent']):** df['col1', 'col2'] with single brackets is invalid syntax and raises a KeyError in pandas.
   - **c (X = df.hours_studied + df.attendance_percent):** Adding columns together creates a single 1D combined Series, losing independent feature weights.
   - **d (X = df.to_numpy()[:, 0]):** df.to_numpy()[:, 0] slices only the first column as a 1D NumPy array.

**q2-04.** What is the breakdown of the target variable passed across the 120 students?
   **Correct Answer:** b. 93 passed (77.5%) and 27 failed (22.5%)
   *Explanation:* Value counts on passed reveal 93 passes (77.5%) and 27 fails (22.5%), representing moderate class imbalance.
   *Option Breakdown:*
   - **a (60 passed (50%) and 60 failed (50%)):** 60/60 would represent a perfectly balanced dataset, which is not the case here.
   - **c (110 passed (91.7%) and 10 failed (8.3%)):** 110/10 represents extreme imbalance, which is not present in this dataset.
   - **d (45 passed (37.5%) and 75 failed (62.5%)):** 45/75 inverts the majority class; the majority of students passed.

**q2-05.** What proportion of the dataset is allocated to the test set during train_test_split in main.py?
   **Correct Answer:** b. 25% (30 test students)
   *Explanation:* test_size=0.25 reserves exactly 25% of the 120 samples (30 students) for testing, leaving 75% (90 students) for training.
   *Option Breakdown:*
   - **a (10% (12 test students)):** 10% would allocate only 12 test samples, which is too small for reliable test metrics.
   - **c (50% (60 test students)):** 50% would split the data in half (60 train / 60 test), needlessly reducing training data.
   - **d (33.3% (40 test students)):** 33.3% would allocate 40 test samples, which differs from test_size=0.25 used in main.py.

**q2-06.** Why is stratify=y specified inside train_test_split in main.py?
   **Correct Answer:** b. To guarantee that training and test sets maintain identical pass/fail class proportions
   *Explanation:* Stratification ensures that both the training set and testing set reflect the exact 77.5% pass / 22.5% fail class distribution of the original dataset.
   *Option Breakdown:*
   - **a (To sort the test records in descending numerical order by study hours):** Stratification does not sort records; it preserves class representation during random sampling.
   - **c (To remove duplicate student rows from the dataset automatically):** Duplicate removal is handled by drop_duplicates(), not train_test_split.
   - **d (To scale the attendance percentage feature between 0 and 1):** Feature scaling is performed by StandardScaler or MinMaxScaler, not train_test_split.

**q2-07.** What is the primary function of setting random_state=42 during data splitting?
   **Correct Answer:** b. To seed the random number generator, ensuring reproducible train and test splits
   *Explanation:* Setting random_state=42 fixes the pseudorandom seed, ensuring that the exact same random partition is reproduced every time the script is run.
   *Option Breakdown:*
   - **a (To train the model across 42 independent CPU threads):** Parallel CPU threads are configured via n_jobs, not random_state.
   - **c (To eliminate the first 42 rows of the dataset as an initial warmup):** random_state does not discard or drop any rows from the dataset.
   - **d (To restrict the logistic regression solver to 42 iterations):** Solver iterations are controlled by max_iter, not random_state.

**q2-08.** What are the dimensional shapes of the feature matrix X and target vector y before splitting?
   **Correct Answer:** b. X is (120, 2) and y is (120,)
   *Explanation:* Feature matrix X contains 120 samples across 2 columns (shape (120, 2)), while target Series y contains 120 binary values (shape (120,)).
   *Option Breakdown:*
   - **a (X is (120, 1) and y is (120, 2)):** X has 2 columns, not 1; y is 1D, not 2D.
   - **c (X is (90, 2) and y is (30,)):** 90 and 30 represent the split subsets after partitioning, not the pre-split arrays.
   - **d (X is (120,) and y is (120,)):** X is a 2D DataFrame with two columns, not a 1D vector.

**q2-09.** If an unstratified split randomly placed only 1 failing student into the test set instead of 7, what risk would emerge during model evaluation?
   **Correct Answer:** b. The test set would severely under-represent minority failures, making error metrics unreliable
   *Explanation:* If the test set has only 1 failing student due to unstratified split variation, error metrics like recall and precision for the minority class become statistically meaningless.
   *Option Breakdown:*
   - **a (The computer would run out of RAM during matrix multiplication):** Array dimensions remain identical regardless of class labels; RAM usage is completely unaffected.
   - **c (The logistic regression model would fail to calculate the intercept):** The model fits exclusively on the training set; the test set distribution has no effect on intercept calculation.
   - **d (The pandas DataFrame would convert all float values into strings):** Splitting data never alters numerical data types into strings.

**q2-10.** Why does scikit-learn require feature matrix X to be a 2D structure while accepting target y as a 1D vector?
   **Correct Answer:** b. Because estimators expect X to have shape (n_samples, n_features) while y has one label per sample
   *Explanation:* Scikit-learn expects X as a 2D matrix of shape (n_samples, n_features) to accommodate multiple features, whereas y represents a single scalar label per sample (1D vector of shape (n_samples,)).
   *Option Breakdown:*
   - **a (Because Python does not support multi-dimensional target arrays in any circumstance):** Python and NumPy support multi-dimensional target arrays for multi-output regression.
   - **c (Because pandas cannot compute statistics on 1D feature arrays):** Pandas can easily compute descriptive statistics on 1D Series.
   - **d (Because matplotlib cannot plot 2D target arrays):** Matplotlib can plot arrays of any dimensionality supported by NumPy.

## Module 03: Logistic Regression, Sigmoid Function & Decision Boundaries

**q3-01.** What is the mathematical equation for the sigmoid activation function?
   **Correct Answer:** b. sigma(z) = 1 / (1 + e^(-z))
   *Explanation:* The sigmoid function is defined as sigma(z) = 1 / (1 + e^(-z)), smoothly mapping any real number z to (0, 1).
   *Option Breakdown:*
   - **a (sigma(z) = z / (1 + z)):** z / (1 + z) is not the logistic function and can become negative for negative z.
   - **c (sigma(z) = e^z - e^(-z)):** e^z - e^(-z) is related to hyperbolic sine (sinh), not the sigmoid curve.
   - **d (sigma(z) = max(0, z)):** max(0, z) is the ReLU (Rectified Linear Unit) activation function used in deep learning.

**q3-02.** What is the output of the sigmoid function when the linear input z is exactly 0?
   **Correct Answer:** b. 0.5 (50% probability)
   *Explanation:* When z = 0, e^(-0) = 1, so sigma(0) = 1 / (1 + 1) = 0.5, representing a 50% probability.
   *Option Breakdown:*
   - **a (0.0 (0% probability)):** 0.0 occurs only as an asymptote when z approaches negative infinity.
   - **c (1.0 (100% probability)):** 1.0 occurs only as an asymptote when z approaches positive infinity.
   - **d (-1.0):** The sigmoid function is strictly positive and can never output negative values.

**q3-03.** What is the geometric definition of the decision boundary in logistic regression under a 50% cutoff?
   **Correct Answer:** a. The line where the predicted probability is exactly 0.50 (linear score z = 0)
   *Explanation:* The decision boundary is the line where the predicted probability equals 0.50, which occurs when the linear score z = w1*x1 + w2*x2 + b = 0.
   *Option Breakdown:*
   - **b (The circle connecting the maximum study hours and maximum attendance):** The boundary is a linear hyperplane, not an enclosing circle.
   - **c (The vertical line where hours studied equals 0):** The boundary is determined by both hours and attendance, not a single vertical line.
   - **d (The horizontal line where attendance percentage equals 100%):** The boundary spans across the feature plane with a diagonal slope, not a horizontal line.

**q3-04.** In logistic regression, what statistical quantity does the linear combination w1*x1 + w2*x2 + b directly model?
   **Correct Answer:** b. The log-odds (logit) of the positive class: ln(p / (1 - p))
   *Explanation:* Logistic regression models the log-odds (logit) of the positive class as a linear combination of features: ln(p / (1 - p)) = w*X + b.
   *Option Breakdown:*
   - **a (The raw percentage probability p):** The raw probability p is bounded by [0, 1] and cannot be directly equated to an unbounded linear function.
   - **c (The squared residual error):** Squared residual errors are minimized in linear regression, not modeled as log-odds.
   - **d (The standard deviation of attendance):** Standard deviations are descriptive statistics, not the quantity modeled by logistic regression.

**q3-05.** Why does main.py configure LogisticRegression with max_iter=1000?
   **Correct Answer:** a. To ensure the iterative optimization solver has sufficient iterations to reach convergence
   *Explanation:* Setting max_iter=1000 ensures that the iterative optimization solver (L-BFGS) has sufficient iterations to converge without raising a ConvergenceWarning.
   *Option Breakdown:*
   - **b (To generate 1,000 synthetic student profiles automatically):** max_iter controls solver optimization iterations; it does not generate synthetic data rows.
   - **c (To split the dataset into 1,000 cross-validation folds):** Cross-validation folds are controlled by cv in KFold or cross_val_score, not max_iter.
   - **d (To limit the maximum allowable study hours to 1,000):** Study hours are feature measurements in the dataset, not bounded by max_iter.

**q3-06.** In main.py, the model learns an hours weight of ~0.95 and attendance weight of ~0.03. What do their positive signs indicate?
   **Correct Answer:** b. That increases in either study hours or attendance increase the probability of passing
   *Explanation:* Positive coefficients mean that increasing the corresponding feature increases the log-odds and consequently increases the probability of passing.
   *Option Breakdown:*
   - **a (That studying more hours and attending more lectures decreases pass probability):** A positive weight increases pass probability; a negative weight would decrease it.
   - **c (That the dataset contains negative values):** Weight signs reflect relationship directions, not the sign of dataset values.
   - **d (That attendance has no statistical influence on student outcomes):** Attendance has a positive weight (+0.0336), indicating a meaningful positive contribution to passing.

**q3-07.** If a student's study metrics produce a linear score of z = -1.5, what does the sigmoid function predict for their pass probability?
   **Correct Answer:** b. A probability strictly less than 0.50 (~0.182)
   *Explanation:* When z is negative, sigma(z) is strictly less than 0.50. Specifically, sigma(-1.5) = 1 / (1 + e^(1.5)) = 1 / (1 + 4.4817) = 0.1824 (~18.2%).
   *Option Breakdown:*
   - **a (A probability strictly greater than 0.50):** Scores greater than 0.50 require positive z values.
   - **c (A negative probability (-150%)):** The sigmoid function cannot produce negative probabilities.
   - **d (An undefined error value):** The sigmoid function is defined and smooth for all real numbers, raising no errors.

**q3-08.** What does the intercept term (b ~ -5.10) represent in the Exam Pass Predictor model?
   **Correct Answer:** b. The baseline log-odds of passing for a student with 0 study hours and 0% attendance
   *Explanation:* The intercept b represents the log-odds of the positive class when all input features equal zero (hours = 0, attendance = 0).
   *Option Breakdown:*
   - **a (The minimum exam grade required to pass the course):** Course passing grade standards are external criteria, not model intercept parameters.
   - **c (The total number of students who failed the exam):** The count of failing students is 27, which is unrelated to the numerical intercept -5.10.
   - **d (The average study hours across all students):** Average study hours is 5.55, which is a feature summary statistic.

**q3-09.** How is the 2D linear decision boundary derived algebraically from the logistic regression model?
   **Correct Answer:** a. By setting the linear equation w1*x1 + w2*x2 + b = 0 and solving for x2 in terms of x1
   *Explanation:* Setting z = w1*x1 + w2*x2 + b = 0 yields the line where P = 0.50. Rearranging to isolate x2 produces x2 = (-w1/w2)*x1 - (b/w2).
   *Option Breakdown:*
   - **b (By setting the probability to 1.0 and dividing by the intercept):** Setting probability to 1.0 corresponds to z approaching infinity, which cannot produce a finite line equation.
   - **c (By taking the derivative of study hours with respect to attendance):** Taking derivatives of features does not define the classification decision boundary.
   - **d (By setting all model coefficients to zero):** Setting coefficients to zero eliminates the trained model entirely.

**q3-10.** Why must logistic regression use numerical solvers (such as L-BFGS) rather than an exact analytical formula?
   **Correct Answer:** b. Because the non-linear sigmoid transformation yields a likelihood function with no closed-form analytical solution
   *Explanation:* Passing a linear combination through the non-linear sigmoid produces a transcendental cross-entropy loss function whose gradient cannot be solved analytically for zero, requiring iterative numerical solvers.
   *Option Breakdown:*
   - **a (Because Python cannot perform matrix inversion on datasets with more than 10 columns):** Python handles matrix inversions of thousands of dimensions with ease.
   - **c (Because scikit-learn does not support calculus operations):** Scikit-learn implements analytical gradient computations throughout its algorithms.
   - **d (Because linear regression already uses all available analytical formulas):** Linear regression's analytical normal equation is irrelevant to logistic regression's non-linear formulation.

## Module 04: Model Training, Probability Inference & Student Profiles

**q4-01.** Which scikit-learn method executes the optimization routine to learn model parameters from labeled training data?
   **Correct Answer:** b. model.fit()
   *Explanation:* The fit() method trains the estimator on training data, optimizing parameters to minimize classification loss.
   *Option Breakdown:*
   - **a (model.predict()):** predict() performs inference on new data after the model has already been fitted.
   - **c (model.score()):** score() calculates the mean accuracy on given test data and labels.
   - **d (model.transform()):** transform() is used by data transformers (e.g. scalers), not predictors.

**q4-02.** What attribute of a fitted LogisticRegression model contains the learned feature weights?
   **Correct Answer:** b. model.coef_
   *Explanation:* In scikit-learn, learned feature weights are stored in the coef_ attribute with a trailing underscore.
   *Option Breakdown:*
   - **a (model.weights_):** weights_ is not a recognized attribute in scikit-learn linear models.
   - **c (model.slopes_):** slopes_ is not used in scikit-learn; slopes are called coefficients (coef_).
   - **d (model.parameters_):** parameters_ is not an attribute; model parameters are passed to __init__.

**q4-03.** What attribute of a fitted LogisticRegression model contains the learned intercept (bias) term?
   **Correct Answer:** b. model.intercept_
   *Explanation:* The intercept_ attribute stores the learned baseline bias term.
   *Option Breakdown:*
   - **a (model.bias_):** bias_ is commonly used in deep learning frameworks like PyTorch, but scikit-learn uses intercept_.
   - **c (model.constant_):** constant_ is not a scikit-learn attribute.
   - **d (model.origin_):** origin_ is not used in scikit-learn.

**q4-04.** What is the output shape of model.predict_proba(X_test) when X_test contains 30 student records for binary classification?
   **Correct Answer:** b. (30, 2)
   *Explanation:* For 30 samples and 2 binary classes, predict_proba returns a 2D array of shape (n_samples, n_classes), which is (30, 2).
   *Option Breakdown:*
   - **a ((30,)):** (30,) is a 1D array returned by predict() or after slicing predict_proba[:, 1].
   - **c ((2, 30)):** (2, 30) transposes the dimensions; scikit-learn puts samples in the first axis.
   - **d ((30, 1)):** (30, 1) is not used; scikit-learn provides probabilities for both class 0 and class 1.

**q4-05.** In the array returned by model.predict_proba(X_test), what does column index 1 represent?
   **Correct Answer:** b. The probability that the student will pass: P(y = 1)
   *Explanation:* Column index 1 corresponds to class 1 (passed), while column index 0 corresponds to class 0 (failed).
   *Option Breakdown:*
   - **a (The probability that the student will fail: P(y = 0)):** P(y = 0) is stored in column index 0.
   - **c (The student's attendance percentage):** Attendance is an input feature in X, not an output probability.
   - **d (The model's overall test error rate):** Overall error rate is a summary metric, not an element of predict_proba.

**q4-06.** In main.py, what probability of passing does the model predict for a student who studied 6 hours with 80% attendance?
   **Correct Answer:** c. 96%
   *Explanation:* main.py evaluates Persona 1 (6 hours, 80% attendance) to an exact probability of 0.9645, which displays as 96% chance of passing.
   *Option Breakdown:*
   - **a (44%):** 44% is the predicted probability for Persona 2 (3 hours, 60% attendance).
   - **b (80%):** 80% is the attendance percentage, not the predicted passing probability.
   - **d (100%):** 100% is the rounded probability for Persona 3 (8 hours, 95% attendance).

**q4-07.** In main.py, what probability of passing does the model predict for a student who studied 3 hours with 60% attendance?
   **Correct Answer:** a. 44%
   *Explanation:* main.py evaluates Persona 2 (3 hours, 60% attendance) to an exact probability of 0.4440, which displays as 44% chance of passing.
   *Option Breakdown:*
   - **b (50%):** 50% is the default cutoff threshold, not Persona 2's probability.
   - **c (72%):** 72% is the attendance percentage of an average student, not Persona 2's prediction.
   - **d (96%):** 96% is the prediction for Persona 1.

**q4-08.** In main.py, what probability of passing does the model predict for a student who studied 8 hours with 95% attendance?
   **Correct Answer:** d. 100% (rounds from 99.67%)
   *Explanation:* Persona 3 (8 hours, 95% attendance) achieves an exact probability of 0.9967, which rounds to 100% under integer percentage formatting (:.0%).
   *Option Breakdown:*
   - **a (44%):** 44% is Persona 2's prediction.
   - **b (86%):** 86% is the overall test set accuracy at 0.5 cutoff.
   - **c (96%):** 96% is Persona 1's prediction.

**q4-09.** When calling model.predict(X_test), what decision threshold is implicitly applied to convert probabilities to class labels?
   **Correct Answer:** a. A fixed probability cutoff of 0.50 (50%)
   *Explanation:* By default, scikit-learn's predict() converts probabilities to class labels by applying a fixed 50% cutoff: label = 1 if P >= 0.5 else 0.
   *Option Breakdown:*
   - **b (A dynamic threshold based on the median test score):** predict() uses a fixed 0.5 cutoff, not a dynamic median-based threshold.
   - **c (A strict threshold of 0.80 (80%)):** A strict 0.80 cutoff must be implemented manually via predict_proba() >= 0.8.
   - **d (A threshold of 0.0 (all students pass)):** A cutoff of 0.0 would classify every sample as positive regardless of features.

**q4-10.** Why does model.coef_ possess a 2-dimensional shape of (1, 2) rather than a 1D shape of (2,) in binary classification?
   **Correct Answer:** b. Because scikit-learn standardizes coefficients as (n_classes, n_features) to support multi-class extensions
   *Explanation:* Scikit-learn structures coef_ as a 2D matrix of shape (n_classes, n_features). For binary classification, n_classes is 1 (the single separating hyperplane), yielding (1, 2).
   *Option Breakdown:*
   - **a (Because NumPy cannot store floating-point numbers in 1D arrays):** NumPy handles 1D float arrays seamlessly.
   - **c (Because one row is reserved for the training set and one for the testing set):** Coefficients reflect feature weights, not train vs test sample partitions.
   - **d (Because pandas DataFrames cannot accept 1D arrays):** Pandas DataFrames accept arrays of any valid dimensionality.

## Module 05: Classification Evaluation & Error Analysis

**q5-01.** What is the mathematical formula for classification accuracy in terms of confusion matrix quadrants?
   **Correct Answer:** a. Accuracy = (TP + TN) / (TP + TN + FP + FN)
   *Explanation:* Accuracy is the ratio of all correct classifications (True Positives + True Negatives) to the total number of samples evaluated (TP + TN + FP + FN).
   *Option Breakdown:*
   - **b (Accuracy = TP / (TP + FP)):** TP / (TP + FP) defines Precision, not overall Accuracy.
   - **c (Accuracy = TN / (TN + FN)):** TN / (TN + FN) defines Negative Predictive Value, not Accuracy.
   - **d (Accuracy = (FP + FN) / (TP + TN)):** (FP + FN) / (TP + TN) is the ratio of errors to correct predictions, not Accuracy.

**q5-02.** In main.py, what overall test accuracy does the model achieve at the default 50% cutoff?
   **Correct Answer:** b. 86.7% (26 out of 30 correct)
   *Explanation:* main.py line 46 prints 'Accuracy at 50% cutoff: 86.7%', corresponding to 26 correct predictions out of 30 test students (26 / 30 = 0.8667).
   *Option Breakdown:*
   - **a (76.7%):** 76.7% is the naive baseline accuracy achieved by guessing 'Pass' for all test students.
   - **c (93.3%):** 93.3% would correspond to 28 correct predictions out of 30.
   - **d (100.0%):** 100.0% would require zero errors; the model has 4 misclassifications at 0.5 cutoff.

**q5-03.** What does a True Positive (TP) represent in the Exam Pass Predictor?
   **Correct Answer:** b. A student who actually passed and whom the model correctly predicted would pass
   *Explanation:* A True Positive occurs when a student who actually passed the exam is correctly predicted to pass by the model.
   *Option Breakdown:*
   - **a (A student who actually failed and whom the model predicted would fail):** A student who actually failed and is predicted to fail is a True Negative.
   - **c (A student who actually failed but was predicted to pass):** A student who actually failed but was predicted to pass is a False Positive.
   - **d (A student who dropped out of the course before the exam):** Dropouts are absent students, not classified as True Positives.

**q5-04.** In the test set confusion matrix from main.py at 0.5 cutoff, how many samples are in each quadrant (TN, FP, FN, TP)?
   **Correct Answer:** b. TN=4, FP=3, FN=1, TP=22
   *Explanation:* At the 0.5 cutoff, the confusion matrix contains TN=4, FP=3, FN=1, and TP=22, summing to 30 test samples.
   *Option Breakdown:*
   - **a (TN=0, FP=7, FN=0, TP=23):** TN=0, FP=7 corresponds to the dummy baseline that predicts Pass for everyone.
   - **c (TN=15, FP=0, FN=0, TP=15):** TN=15, TP=15 assumes an artificial 50/50 test set distribution.
   - **d (TN=7, FP=0, FN=1, TP=22):** TN=7, FP=0 corresponds to the model performance under the 0.70 cutoff, not the 0.50 cutoff.

**q5-05.** What is the precision for passing students (Class 1) reported in the classification report of main.py?
   **Correct Answer:** c. 0.88 (22 / 25)
   *Explanation:* For Class 1 (passing), precision is TP / (TP + FP) = 22 / 25 = 0.88 (88%), as printed in the classification report.
   *Option Breakdown:*
   - **a (0.57):** 0.57 is the recall for failing students (Class 0).
   - **b (0.80):** 0.80 is the precision for failing students (Class 0).
   - **d (0.96):** 0.96 is the recall for passing students (Class 1).

**q5-06.** What is the recall for passing students (Class 1) reported in the classification report of main.py?
   **Correct Answer:** d. 0.96 (22 / 23)
   *Explanation:* For Class 1 (passing), recall is TP / (TP + FN) = 22 / 23 = 0.9565, which rounds to 0.96 in the classification report.
   *Option Breakdown:*
   - **a (0.57):** 0.57 is the recall for failing students.
   - **b (0.80):** 0.80 is the precision for failing students.
   - **c (0.88):** 0.88 is the precision for passing students.

**q5-07.** What does a False Positive (Type I error) represent in an educational pass/fail prediction system?
   **Correct Answer:** a. Predicting that a student will pass when they actually end up failing
   *Explanation:* A False Positive represents a false pass: predicting that a student will pass (positive prediction) when their actual outcome is failure.
   *Option Breakdown:*
   - **b (Predicting that a student will fail when they actually end up passing):** Predicting fail when the student actually passes is a False Negative.
   - **c (Predicting that a student will achieve an exact grade of 100%):** Predicting exact numeric grades is regression, not binary classification.
   - **d (Predicting that a teacher will cancel the examination):** Exam cancellation is an external event, not a model error.

**q5-08.** What is the harmonic mean of precision and recall conventionally called?
   **Correct Answer:** b. The F1-score
   *Explanation:* The harmonic mean of precision and recall is the F1-score: 2 * (P * R) / (P + R).
   *Option Breakdown:*
   - **a (The ROC-AUC score):** ROC-AUC measures the area under the True Positive Rate vs False Positive Rate curve.
   - **c (The R-squared coefficient):** R-squared is the coefficient of determination used in continuous regression.
   - **d (The Mean Absolute Error):** Mean Absolute Error is a continuous regression error metric.

**q5-09.** Why is a False Positive (false pass) typically considered more harmful than a False Negative in an academic early warning system?
   **Correct Answer:** b. Because a false pass creates a false sense of security, preventing an at-risk student from getting tutoring, leading to course failure
   *Explanation:* In academic advising, a False Positive leads to a false sense of security where an at-risk student receives no help and ultimately fails. A False Negative merely provides extra tutoring to someone who passes.
   *Option Breakdown:*
   - **a (Because False Positives crash the Python runtime environment):** Classification mistakes are normal evaluation outcomes and never crash Python runtimes.
   - **c (Because universities are legally forbidden from calculating True Negatives):** Universities routinely compute confusion matrices and True Negatives in educational research.
   - **d (Because a False Negative immediately expels the student from university):** A False Negative flags a student for academic support; it never causes automatic expulsion.

**q5-10.** Why does main.py pass zero_division=0 to scikit-learn's classification_report function?
   **Correct Answer:** b. To return 0.0 instead of raising runtime warnings if a class has zero predicted samples
   *Explanation:* Passing zero_division=0 instructs scikit-learn to return 0.0 quietly instead of raising UndefinedMetricWarning when a class has zero positive predictions.
   *Option Breakdown:*
   - **a (To divide all probabilities by 100 automatically):** zero_division has no effect on probability scaling.
   - **c (To remove all students who have zero attendance):** Student data rows are never filtered or deleted by classification_report.
   - **d (To force the accuracy metric to equal exactly zero):** zero_division does not force accuracy to zero; it only handles division-by-zero edge cases.

## Module 06: Complete Pipeline, Visualization, Threshold Tuning & Extensions

**q6-01.** What scikit-learn display class is used in main.py to render the graphical confusion matrix?
   **Correct Answer:** b. ConfusionMatrixDisplay
   *Explanation:* main.py line 104 uses ConfusionMatrixDisplay to render the 2x2 confusion matrix visualization.
   *Option Breakdown:*
   - **a (RocCurveDisplay):** RocCurveDisplay plots True Positive Rate vs False Positive Rate curves.
   - **c (PrecisionRecallDisplay):** PrecisionRecallDisplay renders precision-recall curves.
   - **d (CalibrationDisplay):** CalibrationDisplay visualizes model probability calibration curves.

**q6-02.** In main.py, what matplotlib colormap is passed to ConfusionMatrixDisplay?
   **Correct Answer:** b. Blues
   *Explanation:* main.py line 105 specifies cmap='Blues' for the confusion matrix display.
   *Option Breakdown:*
   - **a (viridis):** viridis is matplotlib's default green-yellow colormap, not used here.
   - **c (hot):** hot is a black-red-yellow colormap.
   - **d (plasma):** plasma is a purple-orange-yellow colormap.

**q6-03.** When the decision cutoff is raised from 50% to 70% in main.py, how many passes are predicted out of the 30 test students?
   **Correct Answer:** c. 22 passes
   *Explanation:* main.py line 70 reports that under the 70% cutoff, 22 passes are predicted out of 30 test students.
   *Option Breakdown:*
   - **a (30 passes):** 30 passes would mean every test student was predicted to pass.
   - **b (25 passes):** 25 passes is the number predicted under the default 50% cutoff.
   - **d (15 passes):** 15 passes assumes a 50% pass rate, which does not match model predictions.

**q6-04.** What happens to the number of False Positives when the decision cutoff is shifted from 0.50 to 0.70?
   **Correct Answer:** b. False Positives drop from 3 down to 0
   *Explanation:* Raising the cutoff from 0.50 to 0.70 eliminates all 3 False Positives, reducing FP from 3 down to 0.
   *Option Breakdown:*
   - **a (False Positives increase from 3 to 10):** Raising thresholds reduces positive predictions, never increasing False Positives.
   - **c (False Positives remain unchanged at 3):** FP changes significantly from 3 to 0 because borderline failing students fall below 0.70.
   - **d (False Positives become negative numbers):** Counts of confusion matrix quadrants cannot be negative.

**q6-05.** What is the test set accuracy when the decision cutoff is set to 70% in this project?
   **Correct Answer:** c. 96.7% (29 out of 30 correct)
   *Explanation:* At the 0.70 cutoff, the model has TN=7, FP=0, FN=1, TP=22, correctly classifying 29 out of 30 students (29 / 30 = 0.9667 or 96.7%).
   *Option Breakdown:*
   - **a (76.7%):** 76.7% is the naive dummy baseline.
   - **b (86.7%):** 86.7% is the accuracy at the 0.50 cutoff.
   - **d (100.0%):** 100.0% would require zero errors; 1 False Negative remains.

**q6-06.** Why does DecisionBoundaryDisplay.from_estimator specify response_method='predict_proba' in main.py?
   **Correct Answer:** a. To render smooth continuous probability contours rather than a flat binary color split
   *Explanation:* Specifying response_method='predict_proba' maps continuous probability estimates to color contours, revealing confidence gradients.
   *Option Breakdown:*
   - **b (To increase the DPI of the saved image):** Image DPI is controlled by the dpi parameter in fig.savefig(), not DecisionBoundaryDisplay.
   - **c (To remove the scatter dots from the figure):** Scatter dots are added via ax.scatter(), independent of response_method.
   - **d (To compute cross-validation accuracy automatically):** Cross-validation is handled by model_selection, not visualization displays.

**q6-07.** In main.py, what grid resolution is specified for the decision boundary surface calculation?
   **Correct Answer:** c. 250 (evaluating 62,500 grid points)
   *Explanation:* main.py line 78 explicitly sets grid_resolution=250, creating a smooth 250 x 250 evaluation surface.
   *Option Breakdown:*
   - **a (10):** 10 would produce blocky, pixelated contours.
   - **b (50):** 50 is lower than the resolution used in main.py.
   - **d (1,000):** 1,000 would be computationally heavy without perceptible visual benefit.

**q6-08.** What resolution (DPI) and bounding box parameter are used when saving PNG figures to disk in main.py?
   **Correct Answer:** b. dpi=150 and bbox_inches='tight'
   *Explanation:* main.py lines 98 and 109 save figures using dpi=150 and bbox_inches='tight'.
   *Option Breakdown:*
   - **a (dpi=72 and bbox_inches='default'):** dpi=72 is standard screen resolution, but main.py specifies dpi=150.
   - **c (dpi=300 and bbox_inches='none'):** main.py uses bbox_inches='tight', not 'none'.
   - **d (dpi=600 and bbox_inches='expand'):** bbox_inches='expand' is invalid in matplotlib.

**q6-09.** If an academic institution wants to ensure that no at-risk student is mistakenly told they will pass, how should they adjust the decision threshold?
   **Correct Answer:** b. Raise the threshold (e.g. to 0.70 or 0.80) to require high confidence before predicting a pass
   *Explanation:* Raising the cutoff demands higher probabilistic certainty before classifying a student as safe (passing), eliminating false passes and ensuring all at-risk students are flagged for tutoring.
   *Option Breakdown:*
   - **a (Lower the threshold to 0.10):** Lowering the threshold to 0.10 predicts pass for almost everyone, maximizing dangerous False Positives.
   - **c (Remove the intercept term from the model):** Removing the intercept degrades model fit without addressing decision policy.
   - **d (Switch from logistic regression to unsupervised clustering):** Unsupervised clustering removes supervision labels, preventing targeted risk classification.

**q6-10.** Why is feature standardization (e.g., StandardScaler) recommended when extending logistic regression to include new features with disparate units?
   **Correct Answer:** b. Because regularization penalties penalize weights uniformly, unfairly shrinking features with small natural scales
   *Explanation:* L2 regularization penalizes the sum of squared weights uniformly. If features have different scales, weights for small-scale features become artificially large and are unfairly over-penalized unless standardized.
   *Option Breakdown:*
   - **a (Because logistic regression cannot run on positive numbers without scaling):** Logistic regression operates seamlessly on positive numbers of any magnitude.
   - **c (Because matplotlib cannot plot DataFrames that contain unscaled features):** Matplotlib plots any numerical array regardless of whether it is scaled.
   - **d (Because train_test_split requires all columns to have mean zero):** train_test_split functions identically on raw or scaled data.

