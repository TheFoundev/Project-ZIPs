# Lesson 03: `predict()` vs `predict_proba()`: Mechanics and Slicing

**Lesson ID:** lesson-03
**Module:** module-04
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Contrast the outputs and internal mechanisms of `model.predict()` and `model.predict_proba()`
- Explain the 2D array structure returned by `predict_proba()`: $[P(y=0), P(y=1)]$
- Justify the slicing syntax `predict_proba(...)[:, 1]` to isolate positive class probabilities
- Demonstrate that `model.predict(X)` is equivalent to `(model.predict_proba(X)[:, 1] >= 0.5).astype(int)`
- Apply custom decision cutoffs to probability arrays

## Prerequisites
- Familiarity with Lesson 01 and Lesson 02
- Basic understanding of 2D NumPy array slicing (`[:, 1]`)

## Concept Explanation

### Two Methods for Inference
Once an estimator is fitted, scikit-learn provides two primary methods for making predictions on new data:
1. `model.predict(X)`: Returns **discrete categorical class labels** (integers $0$ or $1$).
2. `model.predict_proba(X)`: Returns **calibrated continuous class probabilities** (floats between $0.0$ and $1.0$).

```
Comparison of Inference Methods:
                     Input Data X (Test Student)
                                  |
            +---------------------+---------------------+
            |                                           |
            v                                           v
   model.predict(X)                           model.predict_proba(X)
            |                                           |
            v                                           v
  Output: array([1])                         Output: array([[0.0355, 0.9645]])
  (Hard discrete label)                      (Calibrated probability distribution)
```

### The Structure of `predict_proba()`
When you pass a feature matrix $X$ with $N$ student records to `predict_proba(X)`, scikit-learn returns a 2D NumPy array of shape $(N, 2)$:
- **Row $i$**: Corresponds to student $i$.
- **Column 0**: Corresponds to $P(y = 0)$ — the probability that the student will **fail**.
- **Column 1**: Corresponds to $P(y = 1)$ — the probability that the student will **pass**.

Because failing and passing are mutually exclusive and exhaustive events, every row sums to exactly 1.0:
$$P(y = 0) + P(y = 1) = 1.0$$

```
Array Layout for predict_proba(X_test) [First 3 Test Students]:
                Col 0: P(fail)   Col 1: P(pass)     Row Sum
Student 0:    [    0.042,            0.958    ]   =  1.000
Student 1:    [    0.683,            0.317    ]   =  1.000
Student 2:    [    0.112,            0.888    ]   =  1.000
```

### Why We Slice `[:, 1]`
In binary classification, tracking both columns is redundant because $P(\text{fail}) = 1 - P(\text{pass})$. To focus on the likelihood of academic success, `main.py` extracts Column 1:
```python
probabilities = model.predict_proba(X_test)[:, 1]
```
The NumPy slice syntax `[:, 1]` means:
- `:`: Select all rows (all 30 test students).
- `1`: Select column index 1 (the probability of passing).
The result is a clean 1D array of 30 floating-point numbers.

### The Hidden Threshold in `predict()`
What does `model.predict(X)` actually do under the hood?
`model.predict(X)` internally computes `predict_proba(X)` and applies a fixed, hardcoded decision threshold of **0.50** (50%):
- If $P(\text{pass}) \ge 0.50$, it outputs `1`.
- If $P(\text{pass}) < 0.50$, it outputs `0`.

In `main.py`, line 40 makes this threshold explicit:
```python
predictions = (probabilities >= 0.5).astype(int)
```
Writing the threshold comparison explicitly provides practitioners with complete control: if you later wish to raise the cutoff to `0.7` or `0.8`, you simply change `0.5` to your desired threshold!

## Relevant Code (from main.py, lines 39-41)
```python
probabilities = model.predict_proba(X_test)[:, 1]
predictions = (probabilities >= 0.5).astype(int)
accuracy = accuracy_score(y_test, predictions)
```

## Code Explanation and Technical Walkthrough
- **Line 39**: Evaluates probabilities on `X_test` and slices column index 1.
- **Line 40**: Compares each probability against `0.5`, producing a boolean array (`[True, False, True, ...]`). Calling `.astype(int)` casts `True` to integer `1` (pass) and `False` to integer `0` (fail).
- **Line 41**: Computes overall test accuracy by comparing `predictions` against true labels `y_test`.

## Worked Example
**Task:** Prove that `model.predict(X_test)` produces the exact same results as `(model.predict_proba(X_test)[:, 1] >= 0.5).astype(int)`.

**Code:**
```python
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

df = pd.read_csv("data/student_results.csv")
X = df[["hours_studied", "attendance_percent"]]
y = df["passed"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

model = LogisticRegression(max_iter=1000)
model.fit(X_train, y_train)

# Compare direct predict against thresholded probabilities
direct_preds = model.predict(X_test)
thresholded_preds = (model.predict_proba(X_test)[:, 1] >= 0.5).astype(int)

identical = np.array_equal(direct_preds, thresholded_preds)
print(f"Are direct and thresholded predictions identical? {identical}")
print(f"Sample direct predictions:      {direct_preds[:5]}")
print(f"Sample thresholded predictions: {thresholded_preds[:5]}")
```
**Output:**
```text
Are direct and thresholded predictions identical? True
Sample direct predictions:      [1 1 1 1 1]
Sample thresholded predictions: [1 1 1 1 1]
```
The two approaches are mathematically and computationally identical!

## Step-by-Step Student Instructions
1. Open Python: `python3`.
2. Load and fit the model on `X_train` and `y_train`.
3. Obtain the raw 2D probability matrix:
   ```python
   raw_probs = model.predict_proba(X_test)
   print("Shape of raw_probs:", raw_probs.shape)
   print("First row:", raw_probs[0])
   ```
4. Verify that `raw_probs[0, 0] + raw_probs[0, 1]` equals `1.0`.
5. Slice column 1:
   ```python
   pass_probs = raw_probs[:, 1]
   print("Sliced shape:", pass_probs.shape)
   ```
6. Check how many students have pass probabilities $\ge 0.5$:
   ```python
   print("Predicted passes at 0.5 cutoff:", (pass_probs >= 0.5).sum())
   ```
7. Confirm that exactly 25 out of the 30 test students are predicted to pass.

## Expected Output or Observable Behaviour
Console outputs show:
```text
Shape of raw_probs: (30, 2)
First row: [0.03551532 0.96448468]
Sliced shape: (30,)
Predicted passes at 0.5 cutoff: 25
```
This confirms that 25 students pass and 5 students fail under the 50% cutoff.

## Practical Exercises
**Exercise 3.1:** What are the dimensions of the array returned by `model.predict_proba(X_test)` when `X_test` contains 30 rows?
**Exercise 3.2:** What does `raw_probs[:, 0]` contain?
**Exercise 3.3:** If you change the cutoff from 0.5 to 0.7: `(probabilities >= 0.7).astype(int)`, do predicted passes increase or decrease? Explain why.

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Slicing column 0 (`[:, 0]`) | Extracts the probability of failing, causing your threshold logic to predict fails as passes | Always slice `[:, 1]` for the positive class ($y = 1$) |
| Forgetting `.astype(int)` | Leaves predictions as boolean arrays (`[True, False]`), which can cause type mismatch warnings in metrics | Use `(probs >= cutoff).astype(int)` |
| Assuming `predict()` supports custom thresholds | `predict()` hardcodes 0.5; it does not take a `threshold` argument | Use `predict_proba(...)[:, 1] >= cutoff` for custom thresholds |

## Best Practices and Security Considerations
- **Explicit Thresholding**: When writing production decision engines, prefer `predict_proba() >= cutoff` over `predict()`. It makes the operational cutoff explicit, auditable, and configurable.
- **Dimensionality Safety**: Always verify that `predict_proba` inputs match the training feature count and column order exactly.

## Summary
`predict()` returns discrete class labels using a fixed 50% threshold, whereas `predict_proba()` returns a 2D array of continuous class probabilities $[P(y=0), P(y=1)]$. Slicing `[:, 1]` isolates the probability of passing, allowing practitioners to implement flexible, risk-adjusted decision thresholds.

## Knowledge-check Questions
1. What is the difference between the return type of `predict()` and `predict_proba()`?
2. What does each column represent in the array returned by `predict_proba()`?
3. What does the slice `[:, 1]` extract?
4. What implicit cutoff does scikit-learn's `predict()` apply?
5. How many test students are predicted to pass under the 50% cutoff in `main.py`?

## References
- Scikit-learn Classifier Interface (`predict` vs `predict_proba`): https://scikit-learn.org/stable/glossary.html#term-predict_proba
- `main.py` lines 39-41
