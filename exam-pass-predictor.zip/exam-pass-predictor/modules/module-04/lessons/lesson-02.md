# Lesson 02: Extracting & Interpreting Learned Weights (`coef_` and `intercept_`)

**Lesson ID:** lesson-02
**Module:** module-04
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Access and inspect the `coef_` array and `intercept_` array from a fitted model
- Explain the 2D dimensional shape of `model.coef_` (`(1, 2)`)
- Interpret the numerical values: hours studied weight $\approx 0.95$ and attendance weight $\approx 0.03$
- Interpret the intercept value: $b \approx -5.10$
- Formulate the complete mathematical linear log-odds equation learned by the model

## Prerequisites
- Familiarity with Lesson 01 (model fitting) and Module 03 (log-odds theory)
- Understanding of 2D NumPy array indexing

## Concept Explanation

### Accessing Learned Parameters
Upon successful completion of `model.fit(X_train, y_train)`, scikit-learn stores the optimization results in two primary attributes:
1. `model.coef_`: The learned feature weights (coefficients).
2. `model.intercept_`: The learned bias or baseline log-odds.

Let us inspect their exact values and data structures in `main.py`:
```python
print(model.coef_)
# Output: array([[0.95158285, 0.03361372]])

print(model.intercept_)
# Output: array([-5.09640366])
```

```
Weight Matrix Anatomy:
model.coef_ shape is (1, 2):
+-------------------------------+-----------------------------------+
| Index [0, 0]: hours_studied   | Index [0, 1]: attendance_percent  |
|          0.95158              |             0.03361               |
+-------------------------------+-----------------------------------+

model.intercept_ shape is (1,):
+-------------------------------+
| Index [0]: Baseline bias      |
|          -5.09640             |
+-------------------------------+
```

### Why is `model.coef_` a 2D Array?
Notice that `model.coef_` has shape `(1, 2)` rather than `(2,)`:
- Dimension 0 represents the target classes (for binary classification, scikit-learn models the single boundary between class 0 and class 1, so the first dimension is 1).
- Dimension 1 represents the features (feature 0 is `hours_studied` and feature 1 is `attendance_percent`).
- To access scalar float values cleanly for printing:
  - Hours weight: `model.coef_[0, 0]`
  - Attendance weight: `model.coef_[0, 1]`
  - Intercept: `model.intercept_[0]`

### Mathematical Reconstruction of the Model
With these extracted parameters, we can write down the exact mathematical formula that `main.py` uses to evaluate any student:

$$z = 0.95158(\text{hours}) + 0.03361(\text{attendance}) - 5.09640$$

$$P(\text{pass}) = \frac{1}{1 + e^{-\left(0.95158 \times \text{hours} + 0.03361 \times \text{attendance} - 5.09640\right)}}$$

### Comparing the Impact of Hours vs Attendance
Students often ask: *"Since 0.95 is much bigger than 0.03, does attendance barely matter?"*

To answer this question, we must look at the **typical range of variation** for each feature:
- An increase of **4 hours of study** (a standard revision increase) changes the linear score $z$ by:
  $$\Delta z_{\text{hours}} = 4 \times 0.9516 = +3.806$$
- An increase of **30% attendance** (e.g. going from 55% to 85% attendance) changes $z$ by:
  $$\Delta z_{\text{attendance}} = 30 \times 0.0336 = +1.008$$

Both features contribute meaningfully to passing! However, study dedication has roughly $3.8\times$ the leverage of lecture attendance over typical student ranges. A student who attends every lecture but never opens a textbook will still struggle to pass.

## Relevant Code (from main.py, lines 47-48)
```python
print(f"Hours weight: {model.coef_[0, 0]:.2f}")
print(f"Attendance weight: {model.coef_[0, 1]:.2f}")
```

## Code Explanation and Technical Walkthrough
- `model.coef_[0, 0]`: Indexes row 0, column 0 to retrieve the float weight for `hours_studied`.
- `model.coef_[0, 1]`: Indexes row 0, column 1 to retrieve the float weight for `attendance_percent`.
- `:.2f`: Formats the floating-point values to 2 decimal places: `0.95` and `0.03`.

## Worked Example
**Task:** Using the extracted coefficients, compute the predicted pass probability for a student who studied 5.0 hours and attended 70.0% of classes, and verify with `model.predict_proba`.

**Manual Calculation:**
1. Compute linear score $z$:
   $$z = (0.95158285 \times 5.0) + (0.03361372 \times 70.0) - 5.09640366$$
   $$z = 4.75791425 + 2.35296040 - 5.09640366 = 2.01447099$$
2. Compute sigmoid $\sigma(2.01447099)$:
   $$P = \frac{1}{1 + e^{-2.01447099}} = \frac{1}{1 + 0.133391} = \frac{1}{1.133391} \approx 0.8823 \quad (88.2\%)$$

**Programmatic Verification:**
```python
import pandas as pd
test_student = pd.DataFrame([{"hours_studied": 5.0, "attendance_percent": 70.0}])
prob = model.predict_proba(test_student)[0, 1]
print(f"Programmatic probability: {prob:.4f}")
```
**Output:**
```text
Programmatic probability: 0.8823
```
The manual mathematical evaluation matches scikit-learn's prediction to the fourth decimal place!

## Step-by-Step Student Instructions
1. Open terminal and run `python3`.
2. Re-fit the model on `X_train` and `y_train`.
3. Print the raw shapes:
   ```python
   print("coef_ shape:", model.coef_.shape)
   print("intercept_ shape:", model.intercept_.shape)
   ```
4. Extract the scalar floats:
   ```python
   w_hours = float(model.coef_[0, 0])
   w_attend = float(model.coef_[0, 1])
   bias = float(model.intercept_[0])
   print(f"w_hours: {w_hours:.4f}, w_attend: {w_attend:.4f}, bias: {bias:.4f}")
   ```
5. Confirm values: `w_hours ≈ 0.9516`, `w_attend ≈ 0.0336`, `bias ≈ -5.0964`.

## Expected Output or Observable Behaviour
Console outputs show:
```text
coef_ shape: (1, 2)
intercept_ shape: (1,)
w_hours: 0.9516, w_attend: 0.0336, bias: -5.0964
```
All parameters are extracted cleanly as floating-point scalars.

## Practical Exercises
**Exercise 2.1:** What is the dimensionality of `model.coef_` in a binary classification problem with 2 features?
**Exercise 2.2:** What does the sign of `model.intercept_` tell us about the pass probability of a student who has 0 study hours and 0% attendance?
**Exercise 2.3:** Calculate the change in log-odds if a student increases their revision by 2 hours.

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Indexing `model.coef_[0]` instead of `[0, 0]` | Returns the entire 1D array `[0.95, 0.03]` instead of the first scalar weight | Use 2D indexing: `model.coef_[0, 0]` and `model.coef_[0, 1]` |
| Assuming weights are percentages | Weights represent additive log-odds increments, not percentage probabilities | Understand that weights operate inside the linear score $z$ |
| Forgetting the intercept in manual calculations | Omitting $-5.10$ inflates linear scores, producing wildly inaccurate probability predictions | Always include `model.intercept_[0]` in manual calculations |

## Best Practices and Security Considerations
- **Floating Point Precision**: When persisting learned model weights to JSON or configuration files, store full float values rather than truncated two-decimal strings to preserve prediction accuracy.
- **Explainability**: Log-odds weights provide full explainability. For any prediction, an advisor can state exactly how many log-odds points were contributed by study hours versus attendance.

## Summary
The fitted logistic regression model parameters are accessible via `model.coef_` (shape `(1, 2)`) and `model.intercept_` (shape `(1,)`). In `main.py`, the model learns an hours weight of $+0.9516$, an attendance weight of $+0.0336$, and an intercept of $-5.0964$, establishing a transparent linear log-odds equation.

## Knowledge-check Questions
1. What is the shape of `model.coef_` in this project?
2. What feature corresponds to `model.coef_[0, 0]`?
3. What feature corresponds to `model.coef_[0, 1]`?
4. What is the approximate numerical value of the learned intercept?
5. How does a 2-hour increase in study time compare to a 10% increase in attendance in terms of linear score impact?

## References
- Scikit-learn LogisticRegression API (`coef_`, `intercept_`): https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegression.html
- `main.py` lines 47-48
