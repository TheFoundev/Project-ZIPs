# Lesson 01: Fitting Logistic Regression on Training Data

**Lesson ID:** lesson-01
**Module:** module-04
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Execute `model.fit(X_train, y_train)` to optimize classifier parameters
- Explain the strict separation between training data and testing data during fitting
- Understand how scikit-learn populates trailing-underscore attributes upon completion
- Verify that fitting runs without convergence warnings when `max_iter=1000` is set
- Recognize the state transition of an estimator from unfitted to fitted

## Prerequisites
- Completion of Module 02 (stratified splitting) and Module 03 (logistic regression theory)
- Understanding of feature matrix $X$ and target vector $y$

## Concept Explanation

### The Lifecycle of an Estimator: Unfitted vs Fitted
In scikit-learn, an estimator object undergoes a fundamental state transition when `fit()` is called:

```
Estimator State Transition:
+------------------------------+
|     LogisticRegression()     |  <-- Unfitted state: Contains only user
|       (max_iter=1000)        |      hyperparameters. No knowledge of data.
+------------------------------+
               |
    model.fit(X_train, y_train)
               |
               v
+------------------------------+
|       Fitted Estimator       |  <-- Fitted state: Contains learned attributes
|   coef_ = [[0.95, 0.03]]     |      (trailing underscores). Ready for
|   intercept_ = [-5.10]       |      predict() and predict_proba().
+------------------------------+
```

Before calling `fit()`:
- The estimator is purely a configuration template.
- Attempting to inspect `model.coef_` or call `model.predict()` raises a `NotFittedError: This LogisticRegression instance is not fitted yet`.

After calling `fit(X_train, y_train)`:
- Scikit-learn's optimization solver iterates over the 90 training samples.
- The learned parameters are stored in special public attributes ending with an underscore: `coef_`, `intercept_`, `classes_`, and `n_iter_`.
- The estimator is locked and ready for inference.

### Strict Data Encapsulation: Training Data Only
A critical rule of professional machine learning engineering is **data leakage prevention**:
- The model must NEVER see `X_test` or `y_test` during `fit()`.
- In `main.py`, line 38 calls:
  ```python
  model.fit(X_train, y_train)
  ```
- If you accidentally called `model.fit(X, y)` on the entire dataset, the model would memorize the test records. Subsequent evaluation would report artificially inflated accuracy that would collapse when deployed to future students.

## Relevant Code (from main.py, lines 37-38)
```python
model = LogisticRegression(max_iter=1000)
model.fit(X_train, y_train)
```

## Code Explanation and Technical Walkthrough
- **Line 37**: Instantiates the classifier with `max_iter=1000`.
- **Line 38**: Initiates the training routine.
  - `X_train`: 2D DataFrame of 90 rows containing `hours_studied` and `attendance_percent`.
  - `y_train`: 1D Series of 90 binary targets ($0$ and $1$).
  - Scikit-learn validates array shapes, initializes optimization weights, runs L-BFGS, and populates `model.coef_` and `model.intercept_`.
  - Execution completes in a few milliseconds on standard hardware.

## Worked Example
**Task:** Demonstrate that calling `predict()` before `fit()` raises an error, and verify that `fit()` successfully unlocks model attributes.

**Code:**
```python
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.exceptions import NotFittedError

model = LogisticRegression(max_iter=1000)

try:
    model.predict([[5.0, 75.0]])
except NotFittedError as e:
    print(f"Caught expected error: {e}")

# Now load data and fit
df = pd.read_csv("data/student_results.csv")
X = df[["hours_studied", "attendance_percent"]]
y = df["passed"]

model.fit(X, y)
print("Model successfully fitted!")
print(f"Classes discovered: {model.classes_}")
```
**Output:**
```text
Caught expected error: This LogisticRegression instance is not fitted yet. Call 'fit' with appropriate arguments before using this estimator.
Model successfully fitted!
Classes discovered: [0 1]
```

## Step-by-Step Student Instructions
1. Open interactive Python: `python3`.
2. Import dependencies and load `student_results.csv`.
3. Perform the stratified split using `test_size=0.25`, `random_state=42`, and `stratify=y`.
4. Instantiate `model = LogisticRegression(max_iter=1000)`.
5. Call `model.fit(X_train, y_train)`.
6. Inspect `model.classes_`: verify that it returns `array([0, 1])`.
7. Confirm that `fit()` completed cleanly without any warning messages.

## Expected Output or Observable Behaviour
Console outputs show:
```text
LogisticRegression(max_iter=1000)
```
The model object prints its representation, confirming successful parameter convergence.

## Practical Exercises
**Exercise 1.1:** What exception is raised if you call `predict()` on an unfitted scikit-learn estimator?
**Exercise 1.2:** Why is passing `X_test` into `model.fit()` considered a violation of machine learning methodology?
**Exercise 1.3:** What convention does scikit-learn use to name attributes that are estimated from training data?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Fitting on the whole dataset (`model.fit(X, y)`) | Leaks test samples into model parameters, corrupting generalization testing | Always fit strictly on `X_train, y_train` |
| Calling `fit()` multiple times with different data | Each call to `fit()` erases previously learned weights completely | Be aware that `fit()` resets parameters on each invocation |
| Swapping $X$ and $y$ in `fit(y_train, X_train)` | Scikit-learn expects features first and targets second | Maintain syntax: `model.fit(features, target)` |

## Best Practices and Security Considerations
- **Trailing Underscore Rule**: In scikit-learn, learned parameters always end with an underscore (e.g., `coef_`, `intercept_`). Attributes without trailing underscores (e.g., `max_iter`, `tol`) are user-specified hyperparameters.
- **Data Immobility**: After fitting, ensure the training dataset is not modified in memory if pipeline reproducibility is being logged.

## Summary
Fitting is the central training phase where logistic regression optimizes its weights to minimize cross-entropy loss on labeled student data. In `main.py`, calling `model.fit(X_train, y_train)` locks the estimator to 90 training samples, ensuring zero test data leakage while populating learned attributes (`coef_` and `intercept_`).

## Knowledge-check Questions
1. Which method trains a scikit-learn model on historical data?
2. What happens if you try to inspect `coef_` before calling `fit()`?
3. Why must `X_test` be excluded from the `model.fit()` call?
4. What attribute stores the target class labels identified during training?
5. How does scikit-learn syntactically differentiate learned attributes from user hyperparameters?

## References
- Scikit-learn Getting Started Guide: https://scikit-learn.org/stable/getting_started.html
- Scikit-learn Common Pitfalls (Data Leakage): https://scikit-learn.org/stable/common_pitfalls.html
- `main.py` lines 37-38
