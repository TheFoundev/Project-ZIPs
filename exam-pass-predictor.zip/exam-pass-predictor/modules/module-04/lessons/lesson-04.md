# Lesson 04: Benchmark Inference: Analyzing Three Student Academic Personas

**Lesson ID:** lesson-04
**Module:** module-04
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Construct new query DataFrames containing synthetic student profiles
- Feed new feature vectors to `model.predict_proba()` to perform forward inference
- Analyze the three benchmark student personas established in `main.py`
- Explain why Persona 1 achieves 96%, Persona 2 achieves 44%, and Persona 3 achieves 100%
- Formulate tailored academic advising recommendations for each persona

## Prerequisites
- Familiarity with Lesson 02 (learned weights) and Lesson 03 (`predict_proba`)
- Basic pandas knowledge of creating DataFrames from lists of dictionaries

## Concept Explanation

### Operational Inference on New Cases
The ultimate goal of training a machine learning model is deployment: evaluating incoming students who were not part of the historical training dataset.

In `main.py`, the pipeline demonstrates this capability by defining three distinct student personas spanning the realistic spectrum of undergraduate preparation:

```python
examples = pd.DataFrame(
    [
        {"label": "6 hours, 80% attendance", "hours_studied": 6, "attendance_percent": 80},
        {"label": "3 hours, 60% attendance", "hours_studied": 3, "attendance_percent": 60},
        {"label": "8 hours, 95% attendance", "hours_studied": 8, "attendance_percent": 95},
    ]
)
```

Notice that each dictionary includes an informative human-readable `"label"` along with the exact numerical feature columns expected by the model: `"hours_studied"` and `"attendance_percent"`.

```
Benchmark Personas Spectrum:
+-------------------------------+---------------+--------------------+-------------+
| Persona Label                 | hours_studied | attendance_percent | Pass Prob   |
+-------------------------------+---------------+--------------------+-------------+
| Persona 1: Solid Performer    |      6.0      |        80.0        | 96% (0.9645)|
| Persona 2: At-Risk Borderline |      3.0      |        60.0        | 44% (0.4440)|
| Persona 3: Academic Scholar   |      8.0      |        95.0        | 100% (0.9967|
+-------------------------------+---------------+--------------------+-------------+
```

### Deep Dive: Persona 1 (Solid Performer)
- **Inputs**: $6$ hours studied, $80\%$ attendance.
- **Linear Score Calculation**:
  $$z = (0.95158 \times 6) + (0.03361 \times 80) - 5.0964 = 5.7095 + 2.6891 - 5.0964 = +3.3022$$
- **Sigmoid Evaluation**:
  $$P(\text{pass}) = \frac{1}{1 + e^{-3.3022}} = \frac{1}{1 + 0.0368} \approx 0.9645 \quad (96.45\%)$$
- **Advising Takeaway**: This student demonstrates consistent commitment. With a 96% probability of passing, they require no special intervention.

### Deep Dive: Persona 2 (At-Risk Borderline)
- **Inputs**: $3$ hours studied, $60\%$ attendance.
- **Linear Score Calculation**:
  $$z = (0.95158 \times 3) + (0.03361 \times 60) - 5.0964 = 2.8547 + 2.0168 - 5.0964 = -0.2249$$
- **Sigmoid Evaluation**:
  $$P(\text{pass}) = \frac{1}{1 + e^{+0.2249}} = \frac{1}{1 + 1.2522} \approx 0.4440 \quad (44.40\%)$$
- **Advising Takeaway**: Persona 2 has a negative $z$ score ($-0.2249$), placing them in the fail territory ($< 50\%$). With only a 44% probability of passing, this student is at immediate risk. An automated system should trigger an urgent notification recommending at least 2 additional hours of tutoring per week.

### Deep Dive: Persona 3 (Academic Scholar)
- **Inputs**: $8$ hours studied, $95\%$ attendance.
- **Linear Score Calculation**:
  $$z = (0.95158 \times 8) + (0.03361 \times 95) - 5.0964 = 7.6126 + 3.1933 - 5.0964 = +5.7095$$
- **Sigmoid Evaluation**:
  $$P(\text{pass}) = \frac{1}{1 + e^{-5.7095}} = \frac{1}{1 + 0.0033} \approx 0.9967 \quad (99.67\%)$$
- **Advising Takeaway**: Persona 3's probability rounds to 100% in integer formatting (`:.0%`). Their outstanding study dedication and near-perfect attendance place them at the top of the class.

## Relevant Code (from main.py, lines 52-63)
```python
examples = pd.DataFrame(
    [
        {"label": "6 hours, 80% attendance", "hours_studied": 6, "attendance_percent": 80},
        {"label": "3 hours, 60% attendance", "hours_studied": 3, "attendance_percent": 60},
        {"label": "8 hours, 95% attendance", "hours_studied": 8, "attendance_percent": 95},
    ]
)
example_probs = model.predict_proba(examples[["hours_studied", "attendance_percent"]])[:, 1]
print("Example probabilities:")
for label, probability in zip(examples["label"], example_probs):
    print(f"  {label:30s} -> {probability:.0%} chance of passing")
```

## Code Explanation and Technical Walkthrough
- **Lines 52-58**: Creates the `examples` DataFrame containing the 3 benchmark student personas.
- **Line 59**: Passes only the two feature columns `examples[["hours_studied", "attendance_percent"]]` to `model.predict_proba()`. The `"label"` column is excluded from the model input. Slices `[:, 1]` to extract passing probabilities.
- **Lines 60-63**: Uses `zip()` to iterate simultaneously over the labels and computed probabilities, printing each aligned with format specifiers `{label:30s}` and `{probability:.0%}`.

## Worked Example
**Task:** How much would Persona 2's pass probability improve if they increased their study time from 3 hours to 5 hours while keeping attendance at 60%?

**Solution:**
1. Initial state (3 hours, 60% attendance):
   $$z_{\text{old}} = -0.2249 \implies P_{\text{old}} = 44.4\%$$
2. Increased study time (5 hours, 60% attendance):
   $$z_{\text{new}} = (0.95158 \times 5) + (0.03361 \times 60) - 5.0964$$
   $$z_{\text{new}} = 4.7579 + 2.0168 - 5.0964 = +1.6783$$
3. New Sigmoid Evaluation:
   $$P_{\text{new}} = \sigma(1.6783) = \frac{1}{1 + e^{-1.6783}} = \frac{1}{1 + 0.1867} \approx 0.8427 \quad (84.3\%)$$
4. **Advising Impact:** By dedicating just 2 additional study hours, Persona 2 transforms from an at-risk failing student (44.4%) into a secure, passing student with an **84.3% success probability**!

## Step-by-Step Student Instructions
1. Run `python main.py` in your terminal.
2. Observe the terminal output under `Example probabilities:`.
3. Check `outputs/metrics.txt` using `cat outputs/metrics.txt`.
4. Verify the exact floating-point probabilities written to disk:
   - 6 hours, 80% attendance: `0.9645`
   - 3 hours, 60% attendance: `0.4440`
   - 8 hours, 95% attendance: `0.9967`
5. Confirm that `0.9645` formats as `96%`, `0.4440` formats as `44%`, and `0.9967` formats as `100%`.

## Expected Output or Observable Behaviour
Console outputs show:
```text
Example probabilities:
  6 hours, 80% attendance        -> 96% chance of passing
  3 hours, 60% attendance        -> 44% chance of passing
  8 hours, 95% attendance        -> 100% chance of passing
```
File `outputs/metrics.txt` logs:
```text
Example probabilities:
6 hours, 80% attendance: 0.9645
3 hours, 60% attendance: 0.4440
8 hours, 95% attendance: 0.9967
```

## Practical Exercises
**Exercise 4.1:** What is the predicted pass probability for Persona 2 in `main.py`? Does this student pass or fail under a 50% cutoff?
**Exercise 4.2:** Why does Persona 3 display `100% chance of passing` when its raw probability is `0.9967`?
**Exercise 4.3:** If an advisor has a limited budget to fund tutoring for only one student, which of the three personas should be chosen, and why?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Passing the `"label"` column to `model.predict_proba()` | The model was trained on 2 numeric columns; passing 3 columns with strings raises `ValueError` | Select only feature columns: `examples[["hours_studied", "attendance_percent"]]` |
| Believing 100% means zero chance of failure | Probability rounding (`:.0%`) rounds 99.67% to 100%; real probabilities are never exactly 1.0 in logistic regression | Check the unrounded float in `metrics.txt` |
| Overlooking borderline students | Classifying Persona 2 as simply "FAIL" ignores that they are within striking distance of passing with just 2 extra study hours | Use the continuous probability to design targeted improvement plans |

## Best Practices and Security Considerations
- **Constructive Student Feedback**: When reporting probabilities to students, provide actionable guidance (e.g. "Adding 2 hours of study boosts your success rate to 84%") to inspire effort.
- **Input Validation**: When accepting user inputs in interactive advisory portals, enforce bounds (e.g., hours $\ge 0$, attendance between $0$ and $100$).

## Summary
Inference on synthetic benchmark student personas demonstrates the practical utility of the Exam Pass Predictor. While Persona 1 (6h/80% $\to$ 96%) and Persona 3 (8h/95% $\to$ 100%) demonstrate strong preparation, Persona 2 (3h/60% $\to$ 44%) is identified as at-risk, demonstrating how probability outputs enable timely, targeted academic interventions.

## Knowledge-check Questions
1. What are the three benchmark student personas evaluated in `main.py`?
2. What is the predicted pass probability for 6 hours studied and 80% attendance?
3. What is the predicted pass probability for 3 hours studied and 60% attendance?
4. What is the predicted pass probability for 8 hours studied and 95% attendance?
5. Why is the label column excluded when passing the examples DataFrame to `predict_proba()`?

## References
- Scikit-learn Model Persistence and Inference: https://scikit-learn.org/stable/model_persistence.html
- `main.py` lines 52-63
