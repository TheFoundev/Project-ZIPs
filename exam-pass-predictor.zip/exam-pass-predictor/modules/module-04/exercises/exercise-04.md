# Module 4 Exercises: Model Training, Inference & Personas

## Exercise 4.1: Training State and Attribute Inspection (10 min)
**Objective:** Verify model fitting and extract learned parameters from training data.
**Problem Statement:** Train `LogisticRegression` on the 90 training samples and inspect its internal state attributes.

**Requirements:**
1. Instantiate `LogisticRegression(max_iter=1000)`.
2. Fit the model strictly on `X_train` and `y_train`.
3. Extract `model.coef_`, `model.intercept_`, `model.classes_`, and `model.n_iter_`.
4. Output each parameter with descriptive labels.

**Constraints:** Use scikit-learn on the project dataset.
**Expected Behaviour:** Printout confirming coefficients `[[0.9516, 0.0336]]`, intercept `[-5.0964]`, classes `[0, 1]`, and iterations `[18]`.

**Acceptance Criteria:**
- [ ] Confirms hours weight ~0.95.
- [ ] Confirms attendance weight ~0.03.
- [ ] Confirms intercept ~ -5.10.
- [ ] Confirms convergence in under 50 iterations.

---

## Exercise 4.2: Probability Matrix Slicing (15 min)
**Objective:** Master the structure and slicing of `predict_proba` outputs.
**Problem Statement:** Examine the 2D array returned by `model.predict_proba()` and demonstrate why column slicing is required.

**Requirements:**
1. Generate probabilities for the 30 test students using `model.predict_proba(X_test)`.
2. Verify that the output array shape is `(30, 2)`.
3. Check that the sum of each row across column 0 and column 1 equals 1.0.
4. Extract the passing probabilities using `[:, 1]` and verify the shape is `(30,)`.

**Constraints:** Use NumPy array operations.
**Expected Behaviour:** Proof that rows sum to 1.0 and verification of 1D sliced vector.

**Acceptance Criteria:**
- [ ] Shape verified as (30, 2).
- [ ] Row sum equality to 1.0 verified.
- [ ] Sliced shape verified as (30,).

---

## Exercise 4.3: Reproducing Benchmark Personas (15 min)
**Objective:** Replicate the 3 benchmark student persona predictions from `main.py`.
**Problem Statement:** Construct the exact `examples` DataFrame and execute probabilistic inference.

**Requirements:**
1. Construct the `examples` DataFrame with the 3 benchmark personas:
   - 6 hours, 80% attendance
   - 3 hours, 60% attendance
   - 8 hours, 95% attendance
2. Pass the feature columns to `model.predict_proba()`.
3. Format and print the probabilities as both raw floats and percentages.
4. Confirm values match `outputs/metrics.txt` (0.9645, 0.4440, 0.9967).

**Constraints:** Follow the syntax of `main.py` lines 52-63.
**Expected Behaviour:** Output displaying 96%, 44%, and 100%.

**Acceptance Criteria:**
- [ ] Persona 1 matches 0.9645 (96%).
- [ ] Persona 2 matches 0.4440 (44%).
- [ ] Persona 3 matches 0.9967 (100%).

---

## Exercise 4.4: Custom Persona Advisory Design (15 min)
**Objective:** Evaluate a novel student profile and prescribe a concrete improvement path.
**Problem Statement:** A student approaches an advisor who studied 4.0 hours and attended 50% of classes. You must evaluate their risk and determine how much additional study time is required to reach a 75% pass probability.

**Requirements:**
1. Predict the pass probability for a student with 4 hours and 50% attendance.
2. Determine whether this student passes under a default 50% cutoff.
3. Calculate the study hours needed to reach a 75% pass probability while keeping attendance at 50%.

**Constraints:** Show both programmatic code and algebraic formula steps.
**Expected Behaviour:** Calculate initial probability ~59.6%. To reach 75% ($z \approx 1.0986$), required hours is approximately 4.75 hours (an extra 45 minutes of study).

**Acceptance Criteria:**
- [ ] Initial probability correctly calculated (~59.6%).
- [ ] Student passes at 50% threshold.
- [ ] Additional study time correctly calculated (~0.75 hours / 45 mins).
