# Lesson 03: Calibrated Probabilities vs Discrete Labels

**Lesson ID:** lesson-03
**Module:** module-01
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why probability outputs provide richer decision support than hard binary classifications
- Compare the weather forecasting probability analogy to student academic risk modeling
- Explain how a continuous probability distribution is converted into a categorical prediction using a threshold
- Identify the benchmark probability predictions in `main.py` for three student profiles
- Discuss how probability thresholds enable risk-adjusted decision making

## Prerequisites
- Familiarity with percentages and probabilities from Lesson 02
- Basic understanding of decision thresholds (e.g. cutoffs at 50%)

## Concept Explanation

### The Limitations of Hard Discrete Labels
Imagine an academic advising platform that only provides hard binary outputs:
- Student 1: **PASS**
- Student 2: **PASS**

On the surface, both students appear identical. However, what if their underlying statistical probabilities are:
- Student 1: **99.4% probability of passing**
- Student 2: **51.2% probability of passing**

Treating both students as identical "Passes" hides critical operational context:
- Student 1 is virtually guaranteed to pass; they need zero intervention.
- Student 2 is teetering on the knife-edge of failure; a single bad homework grade or missed lecture could push them into failing territory.

By reporting **calibrated probabilities** rather than crude binary labels, machine learning empowers humans to assess risk and confidence.

### The Weather Forecast Analogy
Consider how weather forecasts communicate precipitation risk. A weather app rarely says simply: *"It will rain"* or *"It will not rain"*. Instead, meteorologists report:
- *"80% chance of rain"* $	o$ You bring an umbrella and reschedule outdoor events.
- *"20% chance of rain"* $	o$ You might leave the umbrella at home, accepting a slight risk of a passing shower.
- *"50% chance of rain"* $	o$ You monitor the weather radar closely because conditions are uncertain.

In `main.py`, logistic regression functions exactly like an educational weather station. It takes a student's study metrics and estimates the percentage likelihood of exam success.

```
Probability Spectrum:
0% ------------- 44% --------- 50% ---------------- 96% ------ 100%
|                 |             |                    |           |
High Risk      Profile 2     Cutoff              Profile 1   Profile 3
(Immediate     (Needs Help)  Threshold          (Confident) (Excellent)
 Tutoring)
```

### From Continuous Probability to Categorical Decision
While probabilities provide rich context, real-world systems eventually need to take concrete actions (e.g., admitting a student to an advanced seminar, certifying a diploma). To convert a continuous probability $P$ into a categorical label $\hat{y}$, we apply a **decision cutoff** (threshold) $\tau$:

$$\hat{y} = \begin{cases} 1 & \text{if } P(\text{pass}) \ge \tau \\ 0 & \text{if } P(\text{pass}) < \tau \end{cases}$$

By default, most machine learning software sets $\tau = 0.50$ (50%). However, as explored in `main.py`, $\tau$ is a flexible tuning dial that practitioners can adjust to match institutional risk tolerance.

## Relevant Code (from main.py, lines 39-40, 52-63)
```python
# Compute continuous probabilities and apply default 50% threshold
probabilities = model.predict_proba(X_test)[:, 1]
predictions = (probabilities >= 0.5).astype(int)

# Benchmark example student profiles
examples = pd.DataFrame(
    [
        {"label": "6 hours, 80% attendance", "hours_studied": 6, "attendance_percent": 80},
        {"label": "3 hours, 60% attendance", "hours_studied": 3, "attendance_percent": 60},
        {"label": "8 hours, 95% attendance", "hours_studied": 8, "attendance_percent": 95},
    ]
)
example_probs = model.predict_proba(examples[["hours_studied", "attendance_percent"]])[:, 1]
print("Example probabilities:")
for label, probability in zip(examples["label"], example_probs):
    print(f"  {label:30s} -> {probability:.0%} chance of passing")
```

## Code Explanation and Technical Walkthrough
- **Line 39**: Calls `model.predict_proba(X_test)[:, 1]`. The method `predict_proba` returns an array of shape `(n_samples, 2)` containing $[P(y=0), P(y=1)]$. Slicing `[:, 1]` extracts the probability of passing for each student.
- **Line 40**: Compares each probability against `0.5`. If `probability >= 0.5`, the boolean expression evaluates to `True`, which `.astype(int)` converts to `1` (Pass); otherwise it converts to `0` (Fail).
- **Lines 52-58**: Defines three representative student personas spanning the performance spectrum:
  1. Average study and good attendance ($6$ hours, $80\%$).
  2. Inadequate study and marginal attendance ($3$ hours, $60\%$).
  3. Extensive preparation and near-perfect attendance ($8$ hours, $95\%$).
- **Lines 59-63**: Incurs predictions on these personas and prints them formatted as percentages (`{probability:.0%}`).

## Worked Example
**Task:** Examine the three benchmark personas and interpret their academic risk based on the model's output:
1. Persona 1: $6$ hours, $80\%$ attendance $\to$ **96% chance of passing**.
2. Persona 2: $3$ hours, $60\%$ attendance $\to$ **44% chance of passing**.
3. Persona 3: $8$ hours, $95\%$ attendance $\to$ **100% chance of passing** (rounds to 100% from 99.67%).

**Advisory Interpretation:**
- Persona 3 is on track for academic honors.
- Persona 1 is solidly prepared with a 96% success probability.
- Persona 2 falls below the 50% line with a 44% probability of passing. If this student does not increase their study time or attend review sessions, they are more likely to fail than pass. An automated system should flag Persona 2 for immediate tutoring intervention.

## Step-by-Step Student Instructions
1. Open terminal and run `main.py`: `python main.py`.
2. Locate the console section titled `Example probabilities:`.
3. Verify that Persona 1 displays `96% chance of passing`.
4. Verify that Persona 2 displays `44% chance of passing`.
5. Verify that Persona 3 displays `100% chance of passing`.
6. Reflect on what would happen to Persona 2's classification if the school set a strict 50% pass threshold versus a lenient 40% threshold.

## Expected Output or Observable Behaviour
Console output shows:
```text
Example probabilities:
  6 hours, 80% attendance        -> 96% chance of passing
  3 hours, 60% attendance        -> 44% chance of passing
  8 hours, 95% attendance        -> 100% chance of passing
```
This confirms that the model calculates nuanced, distinct risk tiers across different combinations of student effort.

## Practical Exercises
**Exercise 3.1:** Why is a predicted probability of 44% more informative to an advisor than simply outputting a label of "0" (fail)?
**Exercise 3.2:** If a medical AI predicts that a patient has a 15% probability of a malignant tumor, why might doctors choose a cutoff lower than 50% to order a biopsy? How does this concept apply to failing exams?
**Exercise 3.3:** In `main.py`, what does `[:, 1]` do when applied to `model.predict_proba()`?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Forgetting to slice column index 1 | Slicing `[:, 0]` gives the probability of failing ($y=0$), inverting the meaning of your threshold | Always use `[:, 1]` to extract the probability of the positive class ($y=1$, pass) |
| Assuming 50% is a fixed mathematical law | 50% is merely an arbitrary convention; thresholds should be chosen based on real-world error costs | Treat the cutoff as an adjustable decision parameter |
| Confusing `predict()` with `predict_proba()` | `predict()` returns discrete integers [0, 1]; `predict_proba()` returns continuous floats [0.0 to 1.0] | Use `predict_proba()` when you need risk estimates or custom cutoffs |

## Best Practices and Security Considerations
- **Transparent Communication**: When presenting automated risk scores to students, always present them as supportive probabilities (e.g. "Historical trends indicate students with similar hours succeed 44% of the time") rather than definitive deterministic verdicts.
- **Calibration Verification**: Regularly verify that predicted probabilities reflect actual historical base rates (e.g., among students predicted at ~80%, roughly 80% actually pass).
- **Numerical Formatting**: When logging probabilities to audit files, retain multiple decimal places (e.g., 0.9645) to prevent rounding errors.

## Summary
Calibrated probabilities provide nuanced risk intelligence that simple yes/no labels obscure. In `main.py`, logistic regression computes probabilities that reflect varying degrees of confidence. Practitioners convert these probabilities into operational decisions by applying adjustable cutoffs tailored to institutional goals.

## Knowledge-check Questions
1. How does the weather forecast analogy illustrate the advantage of probability outputs?
2. What are the predicted pass probabilities for the three benchmark student personas in `main.py`?
3. What scikit-learn method is called to obtain continuous probability estimates?
4. What does the slice `[:, 1]` extract from the output of `predict_proba()`?
5. If the pass threshold is set to 50%, what binary label is assigned to a student with a 44% probability of passing?

## References
- Scikit-learn Probability Calibration: https://scikit-learn.org/stable/modules/calibration.html
- Fawcett, T. (2006). "An introduction to ROC analysis". Pattern Recognition Letters.
- `main.py` source code (lines 39-40, 52-63)
