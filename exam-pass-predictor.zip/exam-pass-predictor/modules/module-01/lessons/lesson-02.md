# Lesson 02: Logistic Regression vs Linear Regression: Modeling Probabilities

**Lesson ID:** lesson-02
**Module:** module-01
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why standard Ordinary Least Squares (OLS) linear regression fails for binary classification
- Describe the bounding problem of linear models (producing values $< 0$ or $> 1$)
- Define the logistic function (sigmoid) and explain how it compresses any real number into the interval $(0, 1)$
- Compare linear regression equations with logistic regression log-odds formulations
- Justify the selection of `LogisticRegression` for pass/fail classification

## Prerequisites
- Familiarity with the equation of a line: $y = mx + b$
- Understanding of fractions, decimals, and percentage probabilities between 0% and 100%

## Concept Explanation

### Why Not Use Linear Regression?
When beginners encounter binary classification for the first time, a natural initial thought is: *"Why not just code the outcomes as numbers ($0$ for fail, $1$ for pass) and fit a standard linear regression line through them?"*

While mathematically you can run linear regression on $0$ and $1$ values, doing so introduces severe theoretical and practical flaws:

```
Linear Regression on Binary Data:
Predicted Value
      ^
  1.4 |                                  * * (Predictions > 1.0!)
  1.0 |-----------------------------*--*---- Passed (y = 1)
      |                          *
  0.5 |-----------------------*------------- Decision Threshold (0.5)
      |                    *
  0.0 |-------*---*------------------------- Failed (y = 0)
 -0.2 |    * (Predictions < 0.0!)
      +------------------------------------> Hours Studied
```

1. **Unbounded Predictions**: A straight regression line extends infinitely in both directions: $\hat{y} = w_1 x_1 + w_2 x_2 + b$. If a student studies 15 hours and has 100% attendance, the linear model might predict $\hat{y} = 1.45$. Conversely, if a student studies 0.5 hours with 30% attendance, the model might predict $\hat{y} = -0.30$. Probabilities represent physical certainties that strictly cannot fall below $0.0$ ($0\%$) or exceed $1.0$ ($100\%$). A prediction of $145\%$ chance of passing is mathematically nonsensical.
2. **Violated Assumptions (Heteroskedasticity)**: In Ordinary Least Squares (OLS) linear regression, the error terms are assumed to have constant variance (homoskedasticity). With binary data, the variance of the residuals is $p(1-p)$, which varies systematically depending on the feature values, violating core statistical assumptions and invalidating standard error estimates.
3. **Extreme Outlier Sensitivity**: Adding a few students who studied exceptionally long hours pulls the linear regression slope dramatically, shifting the decision threshold and misclassifying students near the boundary.

### The Solution: The Sigmoid (Logistic) Function
To overcome the limitations of linear regression, statistician David Cox and machine learning pioneers introduced **logistic regression**. Instead of fitting an unconstrained straight line directly to the target, logistic regression passes a linear combination of inputs through a non-linear S-shaped mathematical activation curve known as the **sigmoid function** (denoted by $\sigma$):

$$\sigma(z) = \frac{1}{1 + e^{-z}}$$

Where $z$ is the standard linear combination:
$$z = w_1 x_1 + w_2 x_2 + b$$

Let us analyze the behavior of $\sigma(z)$ as $z$ varies:
- When $z \to +\infty$, $e^{-z} \to 0$, so $\sigma(z) \to \frac{1}{1 + 0} = 1.0$.
- When $z \to -\infty$, $e^{-z} \to +\infty$, so $\sigma(z) \to \frac{1}{\infty} = 0.0$.
- When $z = 0$, $e^{0} = 1$, so $\sigma(0) = \frac{1}{1 + 1} = 0.5$ (exactly 50% probability).

```
The Sigmoid Curve:
Probability P(y=1)
  1.0 |                          ..----''''
      |                    .---''
  0.5 |---------------:---'----------------- Threshold (z = 0 -> P = 0.5)
      |           _.-'
  0.0 | ...----'''
      +---------------:--------------------> Linear Score z
                     z=0
```

The sigmoid function smoothly and naturally compresses any real number from negative infinity to positive infinity into an elegant, valid probability strictly within $(0, 1)$.

## Relevant Code (from main.py, lines 18, 37-38)
```python
from sklearn.linear_model import LogisticRegression

# Model instantiation and fitting
model = LogisticRegression(max_iter=1000)
model.fit(X_train, y_train)
```

## Code Explanation and Technical Walkthrough
- **Line 18**: Imports `LogisticRegression` from scikit-learn's `linear_model` module. Notice that despite its historical name containing the word "Regression", in machine learning taxonomy it is an industry-standard **classifier**.
- **Line 37**: Instantiates the classifier with `max_iter=1000`. Logistic regression uses iterative numerical optimization (such as the L-BFGS algorithm) rather than closed-form normal equations. Setting `max_iter=1000` guarantees the solver has ample iterations to converge to optimal weights.
- **Line 38**: Fits the model on `X_train` and `y_train`, learning the weights $w_1$, $w_2$ and the bias $b$.

## Worked Example
**Problem:** In `main.py`, the trained model learns the following parameters:
- Hours studied weight: $w_1 \approx 0.9516$
- Attendance percent weight: $w_2 \approx 0.0336$
- Intercept (bias): $b \approx -5.0964$

Calculate the linear score $z$ and the predicted pass probability for a student who studied $6$ hours with $80\%$ attendance.

**Solution:**
1. Compute the linear score $z$:
   $$z = (0.9516 \times 6) + (0.0336 \times 80) + (-5.0964)$$
   $$z = 5.7096 + 2.6880 - 5.0964 = 3.3012$$
2. Apply the sigmoid function:
   $$P(\text{pass}) = \sigma(3.3012) = \frac{1}{1 + e^{-3.3012}}$$
   $$e^{-3.3012} \approx 0.03683$$
   $$P(\text{pass}) = \frac{1}{1 + 0.03683} = \frac{1}{1.03683} \approx 0.9645 \quad (96.45\%)$$

3. Notice how this manual calculation exactly matches the script output:
   `6 hours, 80% attendance -> 96% chance of passing`!

## Step-by-Step Student Instructions
1. Open Python in your terminal or an interactive notebook.
2. Define a simple sigmoid function in Python:
   ```python
   import math
   def sigmoid(z):
       return 1 / (1 + math.exp(-z))
   ```
3. Test extreme inputs: calculate `sigmoid(-10)`, `sigmoid(0)`, and `sigmoid(10)`.
4. Observe that `sigmoid(-10)` yields $0.000045$, `sigmoid(0)` yields $0.5$, and `sigmoid(10)` yields $0.999955$.
5. Confirm that no input value can ever produce an output less than $0.0$ or greater than $1.0$.

## Expected Output or Observable Behaviour
When executing the sigmoid test script, you observe:
```text
sigmoid(-10) = 0.0000453999
sigmoid(0)   = 0.5000000000
sigmoid(10)  = 0.9999546021
```
This confirms that the sigmoid curve enforces strict bounds between 0 and 1 across any magnitude of input score.

## Practical Exercises
**Exercise 2.1:** What mathematical problem arises if standard linear regression is applied to binary pass/fail targets for students with extreme study hours?
**Exercise 2.2:** What is the value of the sigmoid function when its linear input $z$ is exactly zero? What does this mean in terms of pass/fail classification?
**Exercise 2.3:** If a student has a calculated linear score of $z = -2.5$, will their predicted probability of passing be greater than or less than 50%? Calculate the exact probability.

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Confusing Logistic Regression with Linear Regression | Linear regression predicts continuous real numbers; logistic regression predicts probabilities for classes | Use `LinearRegression` for numeric grades (e.g. 82.5) and `LogisticRegression` for pass/fail (0 or 1) |
| Assuming the sigmoid function outputs negative numbers | The exponential function $e^{-z}$ is always positive, making $1 / (1 + e^{-z})$ strictly $> 0$ | Recognize that sigmoid outputs are mathematically bounded in the open interval $(0, 1)$ |
| Neglecting the intercept term | Omitting the intercept forces $z = 0$ when features are 0, artificially setting baseline probability to 50% | Always include the intercept (scikit-learn does this automatically with `fit_intercept=True`) |

## Best Practices and Security Considerations
- **Solver Convergence Monitoring**: Always specify an adequate iteration limit (`max_iter=1000`) to avoid `ConvergenceWarning` when features have differing scales or when datasets are small.
- **Model Interpretability**: Logistic regression coefficients provide direct insight into feature importance through log-odds ratios, ensuring models in sensitive domains like education remain fully explainable.
- **Data Integrity**: Ensure input values for attendance percentage and study hours do not contain corrupt negative values before fitting.

## Summary
Linear regression is fundamentally ill-suited for binary classification because its unconstrained predictions can fall below 0 or exceed 1, violating probability axioms. Logistic regression resolves this by wrapping a linear combination of features in the non-linear sigmoid function, smoothly transforming inputs into valid probabilities bounded between 0 and 1.

## Knowledge-check Questions
1. Why does an OLS regression line fail when predicting probabilities for extreme feature values?
2. Write the mathematical formula for the sigmoid activation function.
3. At what value of the linear score $z$ does the sigmoid function output exactly 0.5?
4. In `main.py`, what parameter in `LogisticRegression(max_iter=1000)` ensures solver convergence?
5. How does the calculated probability for a student with $z = 3.30$ compare with the output printed in `main.py`?

## References
- Scikit-learn Logistic Regression Guide: https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
- The Origin of the Logistic Function (Cramer, 2002): https://doi.org/10.1007/978-1-4612-0051-2_6
- Stanford CS229 Machine Learning Lecture Notes on Classification and Logistic Regression
