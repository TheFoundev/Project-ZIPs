# Lesson 04: System Architecture, Dependencies & Project Pipeline

**Lesson ID:** lesson-04
**Module:** module-01
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Trace the execution flow of `main.py` from library imports to file exports
- Explain the role of each third-party dependency (`pandas`, `matplotlib`, `scikit-learn`)
- Justify the use of `pathlib.Path` for cross-platform file system navigation
- Explain why the non-interactive `matplotlib.use("Agg")` backend is essential in headless pipelines
- Identify all artifact files saved by the script in the `outputs/` directory

## Prerequisites
- Basic familiarity with Python file structure and terminal execution
- Understanding of modules and packages in Python

## Concept Explanation

### End-to-End Pipeline Overview
Modern machine learning applications are structured as reproducible data pipelines. `main.py` in the Exam Pass Predictor is designed as a self-contained, robust script that coordinates data ingestion, data splitting, model training, evaluation, visualization, and disk export.

```
Pipeline Flow:
+-------------+     +--------------+     +---------------+
| Read CSV    | --> | Stratified   | --> | Train Logistic|
| (120 rows)  |     | Split (75/25)|     | Regression    |
+-------------+     +--------------+     +---------------+
                                                 |
       +-----------------------------------------+
       v
+-------------+     +--------------+     +---------------+
| Probability | --> | Threshold    | --> | Decision & CM |
| Inference   |     | Comparison   |     | Plots & Text  |
+-------------+     +--------------+     +---------------+
```

### Dependency Architecture
The project leverages four primary Python modules:
1. **`pathlib.Path`**: Standard library module that provides object-oriented filesystem paths. Using `Path(__file__).resolve().parent` guarantees that relative directory references always resolve correctly regardless of which folder the user launches Python from.
2. **`pandas`**: The industry standard for tabular data manipulation. It reads the CSV into a DataFrame, validates column structures, and extracts feature matrices.
3. **`matplotlib`**: Creates high-resolution publication-quality graphics. In our script, it renders both the 2D decision boundary plot and the confusion matrix display.
4. **`scikit-learn` (`sklearn`)**: Provides machine learning algorithms and diagnostics:
   - `LogisticRegression`: The classification model.
   - `train_test_split`: Partitions data with stratification.
   - `accuracy_score`, `classification_report`, `confusion_matrix`: Statistical diagnostics.
   - `ConfusionMatrixDisplay`, `DecisionBoundaryDisplay`: Built-in visualization helpers.

### Headless Rendering with the "Agg" Backend
Notice line 14 of `main.py`:
```python
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
```
In default Python desktop environments, matplotlib initializes GUI windowing toolkits (such as Tkinter, Qt, or Cocoa) so users can interact with pop-up chart windows. However, in production servers, cloud containers (Docker), automated CI/CD pipelines, or SSH terminal sessions, there is no physical monitor or X11 graphical display server attached. Attempting to open a GUI window triggers severe crashes (`TclError: no display name`).

By setting `matplotlib.use("Agg")` **before** importing `pyplot`, we configure matplotlib to render raster images directly to internal byte buffers (the Anti-Grain Geometry engine). Plots are generated and written straight to disk as PNG files without ever attempting to open a window.

## Relevant Code (from main.py, lines 10-26, 112-120)
```python
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.inspection import DecisionBoundaryDisplay
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay, confusion_matrix
from sklearn.model_selection import train_test_split

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)

# ... [Pipeline execution] ...

# Save textual metrics to outputs/metrics.txt
with open(OUT / "metrics.txt", "w", encoding="utf-8") as handle:
    handle.write(f"accuracy at 0.5 cutoff: {accuracy:.4f}\n\n")
    handle.write(classification_report(y_test, predictions, zero_division=0))
    handle.write("\nExample probabilities:\n")
    for label, probability in zip(examples["label"], example_probs):
        handle.write(f"{label}: {probability:.4f}\n")
```

## Code Explanation and Technical Walkthrough
- **Lines 10-20**: Imports all required tools in logical groups: standard libraries (`pathlib`), headless visualization configuration (`matplotlib`, `matplotlib.pyplot`), tabular data (`pandas`), and machine learning components (`sklearn`).
- **Lines 22-25**: Establishes `BASE` path pointing to the script directory, establishes paths for `data/` and `outputs/`, and executes `OUT.mkdir(exist_ok=True)`. The parameter `exist_ok=True` ensures the script does not crash if the directory already exists.
- **Lines 112-118**: Opens `outputs/metrics.txt` using the UTF-8 text encoding and logs the final accuracy, classification report table, and numerical probabilities for all example student personas.

## Worked Example
**Scenario:** A student tries to run `python projects/11_exam_pass_predictor/main.py` from their home directory, but written without `pathlib`, using raw string `"data/student_results.csv"`.
**What happens?**
Python looks for `data/student_results.csv` inside their current working directory (`~`), fails to locate the file, and raises:
`FileNotFoundError: [Errno 2] No such file or directory: 'data/student_results.csv'`
**How `pathlib` resolves it:**
By defining:
`BASE = Path(__file__).resolve().parent`
`DATA = BASE / "data"`
`Path(__file__)` references the physical script file on disk. `DATA / "student_results.csv"` resolves to the absolute filesystem location:
`/home/.../projects/11_exam_pass_predictor/data/student_results.csv`.
The script runs flawlessly from any directory!

## Step-by-Step Student Instructions
1. In your terminal, check the contents of the project folder:
   `ls -la "beginner-projects-main/AI-ML Beginners/projects/11_exam_pass_predictor"`
2. Verify the existence of `main.py`, the `data/` directory, and the `outputs/` directory.
3. Run the script: `python main.py`.
4. Inspect the generated files in `outputs/`:
   `ls -la outputs/`
5. Read the contents of `outputs/metrics.txt`:
   `cat outputs/metrics.txt`
6. Verify that `outputs/decision_boundary.png` and `outputs/confusion_matrix.png` are present.

## Expected Output or Observable Behaviour
Running `cat outputs/metrics.txt` reveals:
```text
accuracy at 0.5 cutoff: 0.8667

              precision    recall  f1-score   support

           0       0.80      0.57      0.67         7
           1       0.88      0.96      0.92        23

    accuracy                           0.87        30
   macro avg       0.84      0.76      0.79        30
weighted avg       0.86      0.87      0.86        30

Example probabilities:
6 hours, 80% attendance: 0.9645
3 hours, 60% attendance: 0.4440
8 hours, 95% attendance: 0.9967
```

## Practical Exercises
**Exercise 4.1:** Why must `matplotlib.use("Agg")` be called before importing `matplotlib.pyplot`?
**Exercise 4.2:** Explain why using `Path(__file__).resolve().parent` is superior to hardcoding relative string paths like `"./data"`.
**Exercise 4.3:** What happens if `mkdir(exist_ok=True)` is called when the `outputs/` directory already exists? What would happen if `exist_ok=False` was used instead?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Placing `matplotlib.use("Agg")` after `import pyplot` | Matplotlib will have already initialized default GUI backends, causing configuration warnings or ignoring the setting | Place `matplotlib.use("Agg")` immediately after `import matplotlib` |
| Forgetting `encoding="utf-8"` when writing files | Default system encodings vary (especially on Windows), potentially creating corrupted text files | Always specify `encoding="utf-8"` in Python `open()` calls |
| Omitting `plt.close(fig)` | Open figure objects accumulate in system memory, causing memory bloat during large runs | Call `plt.close(fig)` immediately after saving each image |

## Best Practices and Security Considerations
- **Resource Cleanup**: Always call `plt.close(fig)` after saving plots to free memory buffers.
- **Defensive Directory Creation**: Always use `mkdir(exist_ok=True)` to ensure scripts can be rerun repeatedly without manual cleanup.
- **Portability**: Never hardcode Windows backslashes (`\`) or Linux slashes (`/`) manually; use `pathlib.Path`'s `/` operator.

## Summary
The Exam Pass Predictor architecture demonstrates modern, clean software engineering standards. It utilizes `pathlib` for robust path resolution, configures matplotlib with the headless `Agg` backend for reliable background rendering, and packages data ingestion, model fitting, evaluation, and artifact generation into a clean, reproducible script.

## Knowledge-check Questions
1. What three artifact files are written to the `outputs/` directory?
2. Why is the `Agg` matplotlib backend required in headless server environments?
3. What is the role of `Path(__file__).resolve().parent` in building robust file paths?
4. What parameter prevents `Path.mkdir` from raising an error if a directory already exists?
5. Which scikit-learn module contains the `LogisticRegression` class?

## References
- Matplotlib Backends Documentation: https://matplotlib.org/stable/users/explain/backends.html
- Python Pathlib Documentation: https://docs.python.org/3/library/pathlib.html
- Scikit-learn Model Evaluation Guide: https://scikit-learn.org/stable/modules/model_evaluation.html
