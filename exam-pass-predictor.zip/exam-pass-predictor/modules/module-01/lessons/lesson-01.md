# Lesson 01: The Pass/Fail Prediction Problem & Educational Analytics

**Lesson ID:** lesson-01
**Module:** module-01
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Formulate the educational and business challenge that the Exam Pass Predictor addresses
- Explain how predictive modeling is applied to student retention and early academic warning systems
- Define supervised binary classification using student academic performance metrics
- Identify the features (`hours_studied`, `attendance_percent`) and target (`passed`) used in the project
- Contrast the goals of score forecasting with pass/fail qualification

## Prerequisites
- Basic familiarity with high school or college grading criteria (pass/fail thresholds)
- General understanding of how personal preparation influences test performance

## Concept Explanation

### The Educational Problem
In higher education and secondary schooling, academic underperformance frequently goes unnoticed until it is too late—after final examinations have taken place. When a student fails a course, the consequences are severe: delayed graduation, financial strain from repeating coursework, and diminished self-confidence.

For universities and academic advisors, early identification of struggling students is paramount. If an automated decision-support system can detect early warning signals—such as inadequate revision hours or dipping lecture attendance—academic counselors can reach out weeks before finals with targeted interventions like peer tutoring, structured study halls, or time-management coaching.

The **Exam Pass Predictor** project builds exactly such a predictive tool. By analyzing historical records from 120 students who documented their study dedication and classroom attendance alongside their final exam outcome, we train a machine learning system to estimate whether future students are on track to pass.

### What Makes This "Supervised Binary Classification"?
In machine learning, algorithms learn from data according to the structure of the supervision signal:
- **Supervised Learning**: The learning algorithm is supplied with a historical collection of *labeled training instances*. Each training record contains input characteristics (called **features**) alongside the observed ground-truth answer (called the **label** or **target**). The algorithm optimizes its internal weights to map inputs to outputs.
- **Binary Classification**: When the target variable is categorical and restricted to exactly two mutually exclusive possibilities (e.g., $0$ for failure, $1$ for success; True vs False; Healthy vs Sick), the supervised problem is categorized as binary classification.

In our project, the dataset `student_results.csv` contains 120 student rows. The target column `passed` contains integer values where `0` designates a failing outcome and `1` designates a passing outcome. Because there are exactly two categories, this is a binary classification task.

### Features vs Target in Educational Analytics
- **Features ($X$)**: The explanatory independent variables observed prior to the exam. In this project, we observe two numerical indicators:
  1. `hours_studied`: The total cumulative hours a student devoted to independent study and exam preparation.
  2. `attendance_percent`: The percentage of scheduled lectures and laboratory sessions the student attended throughout the semester.
- **Target ($y$)**: The dependent outcome variable: `passed` ($0 = \text{Fail}$, $1 = \text{Pass}$).

### Score Prediction vs Pass/Fail Prediction
Earlier projects, such as the *Exam Score Predictor*, treated exam performance as a continuous numeric score between $0$ and $100$ using linear regression. While knowing that a student might score $67.5$ points is helpful, educational policies typically operate on clear credentialing thresholds: a student either meets the prerequisite standard to progress (Pass) or does not (Fail). Binary classification directly addresses the qualification decision.

## Relevant Code (from main.py, lines 1-8, 28-32)
```python
"""Project 11: Will You Pass? (logistic regression).

Run:
    python main.py

Logistic regression predicts a probability, not just a yes/no label. The
script also shows how changing the cutoff changes the decisions.
"""

def main() -> None:
    df = pd.read_csv(DATA / "student_results.csv")
    X = df[["hours_studied", "attendance_percent"]]
    y = df["passed"]
```

## Code Explanation and Technical Walkthrough
- **Lines 1-8**: The module docstring immediately frames the algorithm as **logistic regression** and highlights a central pedagogical distinction: the model predicts a calibrated continuous probability rather than merely spitting out an arbitrary discrete label.
- **Lines 28-29**: The `main()` entrypoint ingests `student_results.csv` from the data directory using pandas.
- **Lines 30-31**: The feature matrix $X$ is assembled by selecting two input columns (`hours_studied` and `attendance_percent`) as a two-dimensional DataFrame, while the target vector $y$ is isolated as a one-dimensional Series representing binary qualification.

## Worked Example
**Scenario:** An academic counselor is evaluating two students midway through the term:
- Student A: Studied 8 hours, 92% attendance.
- Student B: Studied 2 hours, 48% attendance.

**Task:** How does the counselor formulate this as a machine learning classification query?
**Solution:**
1. Formulate input vector $X_A = [8.0, 92.0]$ and $X_B = [2.0, 48.0]$.
2. The supervised learning model evaluates these feature combinations against patterns learned from the 120 historical student examples.
3. For Student A, the model outputs a high probability of passing (approaching 100%), signaling minimal intervention needed.
4. For Student B, the model outputs a low probability of passing (well below 50%), triggering an immediate notification to the student's academic advisor.

## Step-by-Step Student Instructions
1. Navigate to the project root directory: `cd "beginner-projects-main/AI-ML Beginners/projects/11_exam_pass_predictor"`.
2. Inspect the project script `main.py` using your preferred editor or command line utility (`cat main.py`).
3. Locate lines 1 through 8 to verify the declared project purpose and algorithm.
4. Locate line 29 where pandas loads the CSV file.
5. Identify the exact variable names chosen for the feature matrix $X$ and target vector $y$.
6. Note how the target variable `passed` represents a binary outcome rather than a continuous test score.

## Expected Output or Observable Behaviour
When running `python main.py`, the terminal displays the project banner and classification results:
```text
============================================================
WILL YOU PASS?
============================================================
Accuracy at 50% cutoff: 86.7%
Hours weight: 0.95
Attendance weight: 0.03

Classification report:

              precision    recall  f1-score   support

           0       0.80      0.57      0.67         7
           1       0.88      0.96      0.92        23

    accuracy                           0.87        30
```
This demonstrates that the system has ingested the features, trained on historical academic data, and produced a classification accuracy of 86.7% across the held-out test students.

## Practical Exercises
**Exercise 1.1:** What fundamental property distinguishes binary classification from multi-class classification and continuous regression?
**Exercise 1.2:** In your own words, explain why academic institutions benefit from classifying students into pass/fail categories rather than solely estimating numeric grade points.
**Exercise 1.3:** If an institution wanted to predict three letter grades (A, B, and F), would binary logistic regression remain appropriate without modification? Explain why or why not.

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Treating pass/fail as continuous regression | Linear regression can predict outputs like -0.4 or 1.35, which make no sense for categories | Use binary classification (logistic regression) where outputs are bounded between 0 and 1 |
| Swapping features and target | Predicting hours studied from pass status is useless for pre-exam student advisory | Set features $X$ to preparation inputs (`hours_studied`, `attendance_percent`) and target $y$ to `passed` |
| Assuming classification only provides hard 0 or 1 labels | Logistic regression intrinsically calculates continuous probabilities prior to thresholding | Leverage `predict_proba()` to evaluate confidence rather than relying only on `predict()` |

## Best Practices and Security Considerations
- **Student Data Privacy**: Academic records are governed by privacy regulations (such as FERPA in the United States and GDPR in Europe). Datasets used for predictive analytics must be anonymized and stripped of personally identifiable information (PII).
- **Constructive Advisory Ethics**: Predictive models must be utilized exclusively to offer supportive academic interventions, never to discourage students, restrict course access, or justify punitive actions.
- **Local Execution Safety**: All data processing in this project is executed on your local machine with no cloud transmissions or third-party tracking.

## Summary
The Exam Pass Predictor applies supervised binary classification to forecast whether a student will pass or fail based on study hours and attendance percentage. By framing the academic challenge as a classification problem, the system provides early warning intelligence to empower proactive academic counseling.

## Knowledge-check Questions
1. What are the two independent features used as input variables in this project?
2. What values does the binary target column `passed` contain?
3. What is the fundamental difference between supervised learning and unsupervised learning?
4. Why is linear regression inappropriate for direct pass/fail classification?
5. What overall accuracy does `main.py` achieve on the test set at the default 50% cutoff?

## References
- Project script `main.py` (lines 1-8, 28-32)
- Scikit-learn Supervised Learning Overview: https://scikit-learn.org/stable/supervised_learning.html
- Educational Data Mining Society: https://educationaldatamining.org/
