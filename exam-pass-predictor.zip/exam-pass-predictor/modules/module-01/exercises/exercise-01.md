# Module 1 Exercises: Classification Foundations & Architecture

## Exercise 1.1: Problem Type Classification (10 min)
**Objective:** Distinguish supervised binary classification from regression and unsupervised clustering.
**Problem Statement:** A university data science intern is tasked with designing an AI system to analyze student outcomes. You must formally classify the Exam Pass Predictor task according to machine learning taxonomy and justify your categorization.

**Requirements:**
1. Define supervised learning: learning an input-to-output mapping function from historical records containing both features and ground-truth targets.
2. Define binary classification: predicting which of two discrete, mutually exclusive classes an instance belongs to ($0$ vs $1$).
3. Define continuous regression: predicting an unbounded numerical quantity (such as exam score in points).
4. Apply these definitions to `hours_studied`, `attendance_percent`, and `passed`.

**Constraints:** Base your justification on the codebase and data structure of `11_exam_pass_predictor`.
**Expected Behaviour:** A written explanation of 4-6 sentences accurately identifying the problem type.

**Acceptance Criteria:**
- [ ] Correctly identifies the task as supervised binary classification.
- [ ] Explicitly identifies the features ($X$) as `hours_studied` and `attendance_percent`.
- [ ] Explicitly identifies the target ($y$) as `passed` ($0 = \text{Fail}$, $1 = \text{Pass}$).
- [ ] Explains why predicting pass/fail is classification rather than regression.

---

## Exercise 1.2: Exploring Probability Bounds (15 min)
**Objective:** Verify the mathematical bounding properties of the sigmoid activation function.
**Problem Statement:** Linear regression can output negative probabilities or values exceeding 100%. In this exercise, you will implement the mathematical sigmoid function and demonstrate how it compresses extreme linear values.

**Requirements:**
1. Write a Python function `sigmoid(z)` implementing $\sigma(z) = \frac{1}{1 + e^{-z}}$.
2. Evaluate `sigmoid(z)` for $z = -100$, $z = -5$, $z = 0$, $z = 5$, and $z = 100$.
3. Document how the function behaves as $z$ approaches negative and positive infinity.

**Constraints:** Use standard Python `math` module.
**Expected Behaviour:** Print the computed output values and confirm that all outputs remain strictly between $0.0$ and $1.0$.

**Acceptance Criteria:**
- [ ] Function correctly computes `1 / (1 + math.exp(-z))`.
- [ ] At $z = 0$, output is exactly $0.5$.
- [ ] At $z = -100$, output approaches $0.0$ without going negative.
- [ ] At $z = 100$, output approaches $1.0$ without exceeding $1.0$.

---

## Exercise 1.3: Interpreting Student Risk Personas (10 min)
**Objective:** Analyze probability outputs across different student commitment levels.
**Problem Statement:** In `main.py`, three example personas are evaluated. You need to inspect their predicted probabilities and explain how an academic advisor should respond.

**Requirements:**
1. Retrieve the probability predictions for:
   - 6 hours, 80% attendance
   - 3 hours, 60% attendance
   - 8 hours, 95% attendance
2. For each persona, state whether they pass or fail under a default 50% cutoff.
3. Identify which persona is most at risk and recommend an intervention strategy.

**Constraints:** Reference the exact numerical probabilities reported in `outputs/metrics.txt`.
**Expected Behaviour:** A structured summary table and 3-4 sentence interpretation.

**Acceptance Criteria:**
- [ ] Persona 1 identified as 96% pass probability (Pass).
- [ ] Persona 2 identified as 44% pass probability (Fail under 50% cutoff).
- [ ] Persona 3 identified as 100% pass probability (Pass).
- [ ] Clear academic recommendation provided for Persona 2.

---

## Exercise 1.4: Pipeline Verification & Output Inspection (15 min)
**Objective:** Run the end-to-end pipeline and verify all generated output files.
**Problem Statement:** Execute `main.py` in your environment and inspect the created artifacts to ensure pipeline integrity.

**Requirements:**
1. Execute `python main.py` from the project directory.
2. Verify that the `outputs/` directory is created.
3. Confirm that `outputs/decision_boundary.png`, `outputs/confusion_matrix.png`, and `outputs/metrics.txt` exist and are non-empty.
4. Extract the test accuracy logged in `metrics.txt` and report its exact numerical value.

**Constraints:** Do not modify `main.py`.
**Expected Behaviour:** Successful script execution with exit code 0 and all 3 output files populated.

**Acceptance Criteria:**
- [ ] All 3 files present in `outputs/`.
- [ ] Accuracy reported as 86.7% (or 0.8667).
- [ ] Verification that `matplotlib.use("Agg")` enabled headless execution without GUI errors.
