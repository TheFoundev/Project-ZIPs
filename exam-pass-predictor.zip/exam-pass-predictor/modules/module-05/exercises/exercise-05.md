# Module 5 Exercises: Evaluation, Confusion Matrices & Error Costs

## Exercise 5.1: Manual Accuracy & Error Rate Calculation (10 min)
**Objective:** Calculate test accuracy and error rate from raw prediction matches.
**Problem Statement:** On the 30-sample test set, the model correctly classifies 26 students and misclassifies 4 students. Calculate the exact performance metrics.

**Requirements:**
1. State the formula for classification accuracy: $\text{Acc} = \frac{\text{Correct}}{N}$.
2. State the formula for classification error rate: $\text{Err} = \frac{\text{Incorrect}}{N} = 1 - \text{Acc}$.
3. Compute accuracy and error rate for $26$ correct out of $30$ samples.
4. Express both as percentages to one decimal place.

**Constraints:** Calculate directly from fractions.
**Expected Behaviour:** Accuracy verified as 86.7% (0.8667) and error rate verified as 13.3% (0.1333).

**Acceptance Criteria:**
- [ ] Accuracy formula correctly stated.
- [ ] Accuracy computed as 86.7%.
- [ ] Error rate computed as 13.3%.

---

## Exercise 5.2: Confusion Matrix Construction & Extraction (15 min)
**Objective:** Construct the 2x2 confusion matrix and extract TP, TN, FP, and FN.
**Problem Statement:** Use `sklearn.metrics.confusion_matrix` to generate the test matrix and unpack its cells.

**Requirements:**
1. Call `confusion_matrix(y_test, predictions, labels=[0, 1])`.
2. Extract `tn, fp, fn, tp = cm.ravel()`.
3. Verify that $\text{TN}=4$, $\text{FP}=3$, $\text{FN}=1$, and $\text{TP}=22$.
4. Verify that $\text{TN} + \text{FP} = 7$ (actual fails) and $\text{FN} + \text{TP} = 23$ (actual passes).

**Constraints:** Use scikit-learn on the project test split.
**Expected Behaviour:** Printout confirming the four quadrant values.

**Acceptance Criteria:**
- [ ] TN confirmed as 4.
- [ ] FP confirmed as 3.
- [ ] FN confirmed as 1.
- [ ] TP confirmed as 22.

---

## Exercise 5.3: Manual Classification Report Derivation (15 min)
**Objective:** Derive precision, recall, and F1-score from the confusion matrix.
**Problem Statement:** Using the confusion matrix from Exercise 5.2, manually calculate the complete classification report table.

**Requirements:**
1. Compute Precision for Class 1: $\frac{\text{TP}}{\text{TP} + \text{FP}} = \frac{22}{25}$.
2. Compute Recall for Class 1: $\frac{\text{TP}}{\text{TP} + \text{FN}} = \frac{22}{23}$.
3. Compute F1-score for Class 1: $2 \times \frac{P \times R}{P + R}$.
4. Compute Precision, Recall, and F1-score for Class 0.
5. Compare your manual calculations against `classification_report(y_test, predictions)`.

**Constraints:** Show all intermediate fraction arithmetic.
**Expected Behaviour:** Values matching the console: Class 1 (0.88, 0.96, 0.92); Class 0 (0.80, 0.57, 0.67).

**Acceptance Criteria:**
- [ ] Class 1 precision, recall, and F1 correctly derived.
- [ ] Class 0 precision, recall, and F1 correctly derived.
- [ ] Match with scikit-learn's classification report verified.

---

## Exercise 5.4: Error Cost Matrix Analysis (15 min)
**Objective:** Quantify the institutional cost of classification mistakes under different policies.
**Problem Statement:** An academic department assigns costs to classification outcomes:
- True Positive (TP): Cost = $0 (student passes normally)
- True Negative (TN): Cost = $100 (tutoring cost for failing student who is caught)
- False Negative (FN): Cost = $100 (tutoring cost for passing student who didn't strictly need it)
- False Positive (FP): Cost = $1,500 (tuition loss and remediation cost when student fails unassisted)

**Requirements:**
1. Calculate total institutional cost at 50% cutoff ($	ext{TN}=4, 	ext{FP}=3, 	ext{FN}=1, 	ext{TP}=22$).
2. Calculate total institutional cost at 70% cutoff ($	ext{TN}=7, 	ext{FP}=0, 	ext{FN}=1, 	ext{TP}=22$).
3. Compare the financial and educational outcomes of the two policies.

**Constraints:** Apply the cost weights defined above.
**Expected Behaviour:** Cost at 50% cutoff = $5,000. Cost at 70% cutoff = $800. Raising the cutoff saves $4,200 while preventing 3 student course failures!

**Acceptance Criteria:**
- [ ] Cost at 50% cutoff correctly calculated ($5,000).
- [ ] Cost at 70% cutoff correctly calculated ($800).
- [ ] Compelling written justification for adopting the 70% cutoff.
