# Lesson 01: Classification Accuracy & Baseline Performance

**Lesson ID:** lesson-01
**Module:** module-05
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define classification accuracy and calculate it using the standard formula
- Call `sklearn.metrics.accuracy_score` on true labels and test predictions
- Interpret the 86.7% test accuracy achieved by `main.py` at the 0.50 cutoff
- Compare classifier accuracy against the 76.7% test baseline majority guesser
- Explain when accuracy is informative and identify its limitations in imbalanced scenarios

## Prerequisites
- Completion of Module 02 (train-test splitting) and Module 04 (predictions)
- Basic understanding of fractions and percentages

## Concept Explanation

### What is Classification Accuracy?
In machine learning, **accuracy** is the most intuitive and widely used evaluation metric. It answers a fundamental question: *"Out of all the predictions the model made, what fraction was correct?"*

Mathematically, accuracy is defined as:

$$\text{Accuracy} = \frac{\text{Number of Correct Predictions}}{\text{Total Number of Predictions}} = \frac{\text{True Positives} + \text{True Negatives}}{N}$$

Where $N$ is the total count of test samples.

### Accuracy in `main.py`
In our test set, `X_test` consists of 30 students whose true outcomes (`y_test`) are:
- **23 Passing Students** ($y = 1$)
- **7 Failing Students** ($y = 0$)

When `main.py` generates predictions using the default 50% cutoff, the model achieves:
- **22 True Positives**: Correctly predicted 22 passing students.
- **4 True Negatives**: Correctly predicted 4 failing students.
- **Total Correct**: $22 + 4 = 26$ correct classifications out of 30.

Calculating accuracy:
$$\text{Accuracy} = \frac{26}{30} \approx 0.86666... \implies \mathbf{86.7\%}$$

```
Test Set Outcome Breakdown (30 Students):
+-------------------------------+-------------------------------+
| Correct: 26 Students (86.7%)  | Incorrect: 4 Students (13.3%) |
| - 22 True Passes (TP)         | - 3 False Passes (FP)         |
| -  4 True Fails (TN)          | - 1 False Fail (FN)           |
+-------------------------------+-------------------------------+
```

### Comparing Against the Baseline Floor
In Module 02, we noted that the dataset exhibits class imbalance. A naive baseline model that simply guesses "PASS" for every student in the test set would achieve:
$$\text{Baseline Accuracy} = \frac{23}{30} \approx 76.67\% \quad (76.7\%)$$

Why is this comparison crucial?
- An accuracy of 76.7% requires **zero intelligence**—a broken clock guessing "Pass" gets 76.7% automatically!
- Our logistic regression model achieves **86.7%**, delivering a net improvement of **+10.0 percentage points** over the baseline.
- More importantly, while the dummy model gets 0% of failing students right (0/7), our model successfully identifies 4 out of the 7 failing students, demonstrating genuine discriminative intelligence.

## Relevant Code (from main.py, lines 19, 40-41, 46)
```python
from sklearn.metrics import accuracy_score

# Compute test predictions at 0.50 cutoff
predictions = (probabilities >= 0.5).astype(int)
accuracy = accuracy_score(y_test, predictions)

print(f"Accuracy at 50% cutoff: {accuracy:.1%}")
```

## Code Explanation and Technical Walkthrough
- **Line 19**: Imports `accuracy_score` from `sklearn.metrics`.
- **Line 40**: Applies the 0.50 threshold to continuous probabilities, producing binary integer predictions (`0` or `1`).
- **Line 41**: Computes accuracy by comparing true labels `y_test` against `predictions`.
- **Line 46**: Formats the floating-point result as a percentage with one decimal place (`{accuracy:.1%}`), printing `86.7%`.

## Worked Example
**Task:** Calculate accuracy by hand given the raw prediction array and ground truth labels.

**Data:**
- True labels: `y_test = np.array([1, 1, 1, 0, 1, 0, 1, 1, 1, 0])` (10 samples: 7 passes, 3 fails)
- Model predictions: `preds = np.array([1, 1, 0, 0, 1, 0, 1, 1, 1, 1])`

**Step-by-step Solution:**
1. Compare each prediction with ground truth:
   - Index 0: True=1, Pred=1 $	o$ Correct
   - Index 1: True=1, Pred=1 $	o$ Correct
   - Index 2: True=1, Pred=0 $	o$ Error (False Negative)
   - Index 3: True=0, Pred=0 $	o$ Correct
   - Index 4: True=1, Pred=1 $	o$ Correct
   - Index 5: True=0, Pred=0 $	o$ Correct
   - Index 6: True=1, Pred=1 $	o$ Correct
   - Index 7: True=1, Pred=1 $	o$ Correct
   - Index 8: True=1, Pred=1 $	o$ Correct
   - Index 9: True=0, Pred=1 $	o$ Error (False Positive)
2. Count correct: $8$ out of $10$.
3. Compute accuracy: $\frac{8}{10} = 0.80 = 80.0\%$.
4. Both errors are clearly isolated: 1 missed pass and 1 missed fail.

## Step-by-Step Student Instructions
1. Open interactive Python in terminal: `python3`.
2. Load data and split with `test_size=0.25`, `random_state=42`, and `stratify=y`.
3. Train `model = LogisticRegression(max_iter=1000).fit(X_train, y_train)`.
4. Generate test predictions:
   ```python
   from sklearn.metrics import accuracy_score
   probs = model.predict_proba(X_test)[:, 1]
   preds = (probs >= 0.5).astype(int)
   acc = accuracy_score(y_test, preds)
   print(f"Accuracy: {acc:.4f} ({acc:.1%})")
   ```
5. Verify that `acc` evaluates to `0.8667` (86.7%).
6. Count matches directly using NumPy: `print((y_test.values == preds).sum(), "out of", len(y_test))`. Confirm 26 out of 30.

## Expected Output or Observable Behaviour
Interactive console output:
```text
Accuracy: 0.8667 (86.7%)
26 out of 30
```
This confirms that the model correctly classifies 26 out of 30 test students under the default 50% cutoff.

## Practical Exercises
**Exercise 1.1:** What is the formula for classification accuracy?
**Exercise 1.2:** In a test set of 50 students where 40 pass and 10 fail, what is the accuracy of a dummy model that predicts "Pass" for all 50 students?
**Exercise 1.3:** If a model achieves 90% accuracy on a dataset with 95% passing students, has it demonstrated superior performance over a baseline guesser? Explain why or why not.

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Relying solely on accuracy in imbalanced sets | High accuracy can mask complete failure to detect the minority class | Supplement accuracy with confusion matrices, precision, and recall |
| Swapping arguments in `accuracy_score` | Although symmetric for accuracy, scikit-learn standardizes `(y_true, y_pred)` across all metric functions | Always write `accuracy_score(y_test, predictions)` |
| Confusing percentage formatting | Formatting 0.8667 with `:.2f` prints `0.87`, while `:.1%` prints `86.7%` | Choose clear percentage formatting for stakeholder communication |

## Best Practices and Security Considerations
- **Baseline Requirement**: Always report the majority class baseline alongside accuracy to provide meaningful context.
- **Confidence Intervals**: In small test sets ($N=30$), recognize that a single misclassified student alters accuracy by $3.33\%$. Supplement test set accuracy with cross-validation.

## Summary
Classification accuracy measures the proportion of correct classifications over all predictions. In `main.py`, the model achieves 86.7% accuracy (26 out of 30 correct), decisively surpassing the 76.7% dummy baseline and correctly identifying both passing and at-risk students.

## Knowledge-check Questions
1. What mathematical formula defines classification accuracy?
2. How many students in the test set were classified correctly at the 50% cutoff?
3. What is the test set accuracy formatted to one decimal place?
4. What is the baseline accuracy of a naive classifier that predicts "Pass" for all test students?
5. By how many percentage points does the model outperform the naive baseline?

## References
- Scikit-learn Accuracy Metric: https://scikit-learn.org/stable/modules/generated/sklearn.metrics.accuracy_score.html
- `main.py` lines 40-46
