# Lesson 03: Precision, Recall & F1-Score Breakdown

**Lesson ID:** lesson-03
**Module:** module-05
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define **precision**, **recall**, and **F1-score** using confusion matrix quadrants
- Calculate precision and recall manually for both class 0 (fail) and class 1 (pass)
- Interpret every column and row in scikit-learn's `classification_report`
- Explain the difference between **macro average** and **weighted average**
- Explain why the parameter `zero_division=0` is included in `main.py`

## Prerequisites
- Familiarity with Lesson 02 (confusion matrix decomposition: TP, TN, FP, FN)
- Basic understanding of harmonic means

## Concept Explanation

### Why Do We Need More Than Accuracy?
In Lesson 01 and Lesson 02, we discovered that our test set has 23 passes and only 7 fails. In imbalanced scenarios, accuracy can conceal poor minority-class performance. To evaluate model quality thoroughly, machine learning relies on three complementary metrics: **precision**, **recall**, and the **F1-score**.

### 1. Precision: Quality of Positive Predictions
Precision answers: *"When the model predicts that a student will pass, how often is it right?"*

$$\text{Precision} = \frac{\text{True Positives}}{\text{Predicted Positives}} = \frac{\text{TP}}{\text{TP} + \text{FP}}$$

In `main.py`:
- Model predicted **25 students** would pass ($\text{TP} + \text{FP} = 22 + 3 = 25$).
- Out of those 25, **22 students** actually passed.
- $\text{Precision}_{\text{pass}} = \frac{22}{25} = 0.8800 \implies \mathbf{88.0\%}$.

### 2. Recall (Sensitivity): Completeness of Detection
Recall answers: *"Out of all the students who actually passed, what fraction did the model find?"*

$$\text{Recall} = \frac{\text{True Positives}}{\text{Actual Positives}} = \frac{\text{TP}}{\text{TP} + \text{FN}}$$

In `main.py`:
- There were **23 actual passing students** ($\text{TP} + \text{FN} = 22 + 1 = 23$).
- The model successfully retrieved **22** of them.
- $\text{Recall}_{\text{pass}} = \frac{22}{23} \approx 0.9565 \implies \mathbf{95.7\%}$ (rounds to **96%**).

### 3. F1-Score: The Balanced Harmonic Mean
Precision and recall exist in constant tension: you can artificially maximize recall by predicting "Pass" for everyone (achieving 100% recall), but precision will plunge.

The **F1-score** is the harmonic mean of precision and recall, penalizing extreme trade-offs:

$$\text{F1} = 2 \times \frac{\text{Precision} \times \text{Recall}}{\text{Precision} + \text{Recall}}$$

For the passing class:
$$\text{F1}_{\text{pass}} = 2 \times \frac{0.8800 \times 0.9565}{0.8800 + 0.9565} = 2 \times \frac{0.8417}{1.8365} \approx 0.9167 \implies \mathbf{0.92}$$

```
Metric Matrix Summary:
+-------------+-----------+--------+----------+---------+
| Class       | Precision | Recall | F1-Score | Support |
+-------------+-----------+--------+----------+---------+
| 0 (Failed)  |   0.80    |  0.57  |   0.67   |    7    |
| 1 (Passed)  |   0.88    |  0.96  |   0.92   |   23    |
+-------------+-----------+--------+----------+---------+
| Accuracy    |           |        |   0.87   |   30    |
| Macro Avg   |   0.84    |  0.76  |   0.79   |   30    |
| Weighted Avg|   0.86    |  0.87  |   0.86   |   30    |
+-------------+-----------+--------+----------+---------+
```

### Decoding the Summary Averages
At the bottom of the classification report, two aggregate rows summarize performance:
1. **Macro Average**: The unweighted arithmetic mean across classes:
   $$\text{Macro Precision} = \frac{0.80 + 0.88}{2} = 0.84$$
   $$\text{Macro Recall} = \frac{0.57 + 0.96}{2} = 0.765 \implies 0.76$$
   Macro average treats each class equally, regardless of how few samples it has.
2. **Weighted Average**: Averages metrics weighted by the **support** (number of true instances) of each class:
   $$\text{Weighted Precision} = \frac{(7 \times 0.80) + (23 \times 0.88)}{30} = \frac{5.60 + 20.24}{30} = 0.8613 \implies 0.86$$
   Weighted average reflects performance proportional to real-world class frequency.

## Relevant Code (from main.py, lines 49-50)
```python
from sklearn.metrics import classification_report

print("
Classification report:
")
print(classification_report(y_test, predictions, zero_division=0))
```

## Code Explanation and Technical Walkthrough
- **Line 50**: Calls `classification_report(y_test, predictions, zero_division=0)`.
- **`zero_division=0`**: In edge cases where a model predicts zero positive samples for a class, the precision denominator $(\text{TP} + \text{FP})$ is zero. Setting `zero_division=0` prevents Python from raising zero-division warnings and cleanly assigns `0.0`.

## Worked Example
**Task:** Calculate the precision and recall for **Class 0 (Failed)** using the confusion matrix values ($	ext{TN}=4, 	ext{FP}=3, 	ext{FN}=1, 	ext{TP}=22$).

**Solution:**
For Class 0, a "positive" outcome is defined as failing ($y = 0$):
- True detections of failure: $\text{TN} = 4$.
- Total predicted failures: $\text{TN} + \text{FN} = 4 + 1 = 5$.
$$\text{Precision}_{\text{fail}} = \frac{\text{TN}}{\text{TN} + \text{FN}} = \frac{4}{5} = 0.8000 \implies \mathbf{0.80}$$

- Total actual failures: $\text{TN} + \text{FP} = 4 + 3 = 7$.
$$\text{Recall}_{\text{fail}} = \frac{\text{TN}}{\text{TN} + \text{FP}} = \frac{4}{7} \approx 0.5714 \implies \mathbf{0.57}$$

- Harmonic F1-Score:
$$\text{F1}_{\text{fail}} = 2 \times \frac{0.80 \times 0.5714}{0.80 + 0.5714} = 2 \times \frac{0.4571}{1.3714} \approx 0.6667 \implies \mathbf{0.67}$$

Notice that these exact values ($0.80$, $0.57$, $0.67$) match line 0 of the classification report printed in `main.py`!

## Step-by-Step Student Instructions
1. Run `python main.py` in your terminal.
2. Locate the console table under `Classification report:`.
3. Locate row `0` (failing students): verify precision is `0.80`, recall is `0.57`, and f1-score is `0.67`.
4. Locate row `1` (passing students): verify precision is `0.88`, recall is `0.96`, and f1-score is `0.92`.
5. Check the `support` column: verify that row 0 shows `7` and row 1 shows `23`.
6. Verify that macro avg f1-score is `0.79` and weighted avg f1-score is `0.86`.

## Expected Output or Observable Behaviour
The terminal outputs:
```text
Classification report:

              precision    recall  f1-score   support

           0       0.80      0.57      0.67         7
           1       0.88      0.96      0.92        23

    accuracy                           0.87        30
   macro avg       0.84      0.76      0.79        30
weighted avg       0.86      0.87      0.86        30
```
Every metric aligns with our manual calculations.

## Practical Exercises
**Exercise 3.1:** What does the `support` column represent in a classification report?
**Exercise 3.2:** Why is the recall for Class 0 (0.57) noticeably lower than the recall for Class 1 (0.96)?
**Exercise 3.3:** If precision is 1.0 and recall is 0.5, what is the harmonic F1-score?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Confusing precision with recall | Precision evaluates prediction accuracy; recall evaluates retrieval completeness | Remember: Precision = TP / (All Predicted Positives); Recall = TP / (All Actual Positives) |
| Using arithmetic mean instead of harmonic mean for F1 | An arithmetic mean of 1.0 and 0.0 is 0.5, concealing total failure; harmonic mean correctly yields 0.0 | Always compute F1 using harmonic mean: $2PR / (P + R)$ |
| Neglecting `zero_division=0` | Triggers ugly terminal warnings if a threshold results in zero predictions for a class | Always pass `zero_division=0` to `classification_report` |

## Best Practices and Security Considerations
- **Comprehensive Reporting**: Never report accuracy alone in academic or production settings; always publish the complete classification report.
- **Support Validation**: Check support numbers to verify that sample sizes are sufficient for statistical significance.

## Summary
The classification report provides a granular diagnostic evaluation: precision (quality of positive predictions), recall (coverage of actual cases), and F1-score (harmonic mean). In `main.py`, the model achieves 0.88 precision and 0.96 recall for passing students, alongside 0.80 precision and 0.57 recall for failing students.

## Knowledge-check Questions
1. What formula defines precision?
2. What formula defines recall?
3. What is the precision and recall for passing students ($y = 1$) in `main.py`?
4. What does the `support` value of 23 indicate?
5. How does the macro average differ from the weighted average in the report?

## References
- Scikit-learn Classification Report Guide: https://scikit-learn.org/stable/modules/generated/sklearn.metrics.classification_report.html
- `main.py` lines 49-51
