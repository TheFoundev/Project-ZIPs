# Lesson 02: The Confusion Matrix Demystified

**Lesson ID:** lesson-02
**Module:** module-05
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Deconstruct the $2 \times 2$ confusion matrix into its four fundamental quadrants
- Define True Positives (TP), True Negatives (TN), False Positives (FP), and False Negatives (FN)
- Extract and verify the exact confusion matrix values in `main.py`: TN=4, FP=3, FN=1, TP=22
- Render confusion matrix visualizations using `ConfusionMatrixDisplay`
- Explain why confusion matrices provide far deeper diagnostic insight than accuracy alone

## Prerequisites
- Familiarity with Lesson 01 (accuracy and test set predictions)
- Basic understanding of tabular layouts and coordinates

## Concept Explanation

### Beyond Single-Number Summaries
While overall accuracy tells us that the model was correct 86.7% of the time, it fails to answer critical operational questions:
- *When the model made mistakes, what kind of mistakes were they?*
- *Did it mistakenly fail students who actually passed, or did it mistakenly pass students who actually failed?*

To diagnose classifier decisions transparently, machine learning practitioners use the **confusion matrix**—a cross-tabulation of actual ground-truth outcomes against model predictions.

### The Four Quadrants of a Binary Confusion Matrix
In binary classification with classes $0$ (Failed) and $1$ (Passed), the confusion matrix forms a $2 \times 2$ grid:

```
                          PREDICTED CLASS
                      Predicted 0      Predicted 1
                      (Fail)           (Pass)
ACTUAL   Actual 0   +---------------+---------------+
CLASS    (Fail)     | True Negative | False Positive|
                    |     (TN)      |  (FP, Type I) |
                    +---------------+---------------+
         Actual 1   | False Negative| True Positive |
         (Pass)     | (FN, Type II) |     (TP)      |
                    +---------------+---------------+
```

Let us define each quadrant precisely in the context of student examinations:
1. **True Negative (TN)**: A student who actually **failed**, and whom the model correctly predicted would **fail**. (Correct rejection).
2. **False Positive (FP - Type I Error)**: A student who actually **failed**, but whom the model incorrectly predicted would **pass**. (False alarm / false pass).
3. **False Negative (FN - Type II Error)**: A student who actually **passed**, but whom the model incorrectly predicted would **fail**. (Missed success / false fail).
4. **True Positive (TP)**: A student who actually **passed**, and whom the model correctly predicted would **pass**. (Correct detection).

### Deconstructing the Numbers in `main.py`
Executing `confusion_matrix(y_test, predictions, labels=[0, 1])` in `main.py` outputs:

```python
[[ 4,  3],
 [ 1, 22]]
```

```
Exam Pass Predictor Confusion Matrix:
                   Predicted Fail (0)   Predicted Pass (1)     Total Actual
Actual Fail (0):           4                    3             =  7 Failing
Actual Pass (1):           1                   22             = 23 Passing
Total Predicted:           5                   25             = 30 Students
```

Let us analyze these four numbers:
- **$\text{TN} = 4$**: Out of 7 failing students, 4 were correctly flagged for intervention.
- **$\text{FP} = 3$**: 3 failing students were mistakenly predicted to pass under the 50% cutoff.
- **$\text{FN} = 1$**: Only 1 passing student was mistakenly flagged as failing.
- **$\text{TP} = 22$**: Out of 23 passing students, 22 were correctly predicted to pass.
- **Total Correct**: $\text{TN} + \text{TP} = 4 + 22 = 26$.
- **Total Errors**: $\text{FP} + \text{FN} = 3 + 1 = 4$.

## Relevant Code (from main.py, lines 101-110)
```python
from sklearn.metrics import ConfusionMatrixDisplay, confusion_matrix

# Compute 2x2 confusion matrix with explicit labels
cm = confusion_matrix(y_test, predictions, labels=[0, 1])

# Render graphical display
fig, ax = plt.subplots(figsize=(5, 4))
ConfusionMatrixDisplay(cm, display_labels=["failed", "passed"]).plot(
    ax=ax, cmap="Blues", colorbar=False
)
ax.set_title("Pass/fail predictions")
fig.tight_layout()
fig.savefig(OUT / "confusion_matrix.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```

## Code Explanation and Technical Walkthrough
- **Line 102**: Computes the confusion matrix. The parameter `labels=[0, 1]` explicitly specifies that row 0 represents class 0 (`failed`) and row 1 represents class 1 (`passed`).
- **Line 103**: Creates a compact matplotlib figure with dimensions `5 x 4` inches.
- **Lines 104-106**: Uses `ConfusionMatrixDisplay` with `display_labels=["failed", "passed"]` and shades cells using the `Blues` colormap. Cells with higher counts receive deeper blue shading.
- **Lines 107-110**: Adds a clean title, adjusts layout padding, saves to `outputs/confusion_matrix.png`, and frees memory with `plt.close(fig)`.

## Worked Example
**Task:** Flatten the confusion matrix using `.ravel()` and verify that the quadrant values match individual boolean masks.

**Code:**
```python
import numpy as np

# Flatten 2x2 matrix to scalar variables
tn, fp, fn, tp = cm.ravel()

print(f"True Negatives:  {tn}")
print(f"False Positives: {fp}")
print(f"False Negatives: {fn}")
print(f"True Positives:  {tp}")

# Verify consistency
print(f"Total test students: {tn + fp + fn + tp}")
print(f"Accuracy calculation: {(tp + tn) / (tn + fp + fn + tp):.4f}")
```
**Output:**
```text
True Negatives:  4
False Positives: 3
False Negatives: 1
True Positives:  22
Total test students: 30
Accuracy calculation: 0.8667
```

## Step-by-Step Student Instructions
1. Open terminal and run `python main.py`.
2. Locate the generated image at `outputs/confusion_matrix.png`.
3. Open the image in an image viewer or VS Code.
4. Verify the top-left cell: labeled `failed`, showing `4`.
5. Verify the top-right cell: showing `3`.
6. Verify the bottom-left cell: showing `1`.
7. Verify the bottom-right cell: showing `22` in dark blue.
8. Confirm that the diagonal cells (4 and 22) represent all correct predictions.

## Expected Output or Observable Behaviour
Viewing `outputs/confusion_matrix.png` shows:
- Row 0 (True failed): 4 in light blue, 3 in lighter blue.
- Row 1 (True passed): 1 in white, 22 in intense dark blue.
- Clear axes: "Predicted label" on the horizontal axis and "True label" on the vertical axis.

## Practical Exercises
**Exercise 2.1:** What is the value of True Negatives (TN) in `outputs/confusion_matrix.png`?
**Exercise 2.2:** What does the sum of the top row ($4 + 3 = 7$) represent?
**Exercise 2.3:** What does the sum of the right column ($3 + 22 = 25$) represent?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Omitting `labels=[0, 1]` | Scikit-learn orders rows by sorted unique labels, which can lead to ambiguity if a test set happens to lack a class | Always pass `labels=[0, 1]` explicitly |
| Confusing rows and columns | Standard convention has True labels on rows and Predicted labels on columns; confusing them inverts FP and FN | Read rows as actual ground truth and columns as model predictions |
| Forgetting `plt.close(fig)` | Open figures remain in memory, causing resource leakage | Always close matplotlib figures after `savefig()` |

## Best Practices and Security Considerations
- **Auditable Visual Reporting**: Save confusion matrices as image artifacts in model governance repositories to allow non-technical stakeholders to audit errors visually.
- **Color Accessibility**: Blue and neutral monochrome colormaps (`Blues`, `Greys`) are generally accessible to individuals with red-green color blindness.

## Summary
The confusion matrix partitions classification outcomes into a $2 \times 2$ grid: True Positives (22), True Negatives (4), False Positives (3), and False Negatives (1). In `main.py`, the diagonal elements ($22 + 4 = 26$) represent accurate predictions, while the off-diagonal elements isolate the exact distribution of model errors.

## Knowledge-check Questions
1. What does the top-left quadrant of a binary confusion matrix represent?
2. In `main.py`, how many students were True Positives?
3. How many students were False Positives under the default 50% cutoff?
4. How many students were False Negatives?
5. What scikit-learn class is used to plot confusion matrices graphically?

## References
- Scikit-learn `confusion_matrix` API: https://scikit-learn.org/stable/modules/generated/sklearn.metrics.confusion_matrix.html
- Scikit-learn `ConfusionMatrixDisplay`: https://scikit-learn.org/stable/modules/generated/sklearn.metrics.ConfusionMatrixDisplay.html
- `main.py` lines 101-110
