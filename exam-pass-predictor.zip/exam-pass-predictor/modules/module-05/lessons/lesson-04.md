# Lesson 04: Evaluating Real-World Mistake Costs: False Positives vs False Negatives

**Lesson ID:** lesson-04
**Module:** module-05
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Compare Type I errors (False Positives) and Type II errors (False Negatives) in educational analytics
- Analyze the human, academic, and financial costs of each mistake type
- Explain why a False Positive (false pass) is more dangerous than a False Negative in an advisory system
- Connect threshold adjustments to the trade-off between False Positives and False Negatives
- Formulate ethical guidelines for deploying predictive models in student support programs

## Prerequisites
- Familiarity with Lesson 02 (confusion matrix) and Lesson 03 (precision and recall)
- Understanding of decision cutoffs

## Concept Explanation

### Not All Mistakes Are Equal
In introductory math, making any mistake is treated equally—a wrong answer is a wrong answer. In real-world data science, however, **different types of mistakes carry vastly different consequences**.

In our binary classifier:
- **Class 0**: Student will fail the exam.
- **Class 1**: Student will pass the exam.

```
Mistake Matrix in Educational Analytics:
+---------------------------------------+---------------------------------------+
| False Positive (Type I Error)         | False Negative (Type II Error)        |
| - Model predicts: PASS                | - Model predicts: FAIL                |
| - Actual truth:   FAIL                | - Actual truth:   PASS                |
+---------------------------------------+---------------------------------------+
| Human Consequence:                    | Human Consequence:                    |
| - False sense of security             | - Slight unnecessary stress           |
| - Student skips tutoring & review     | - Student attends extra tutoring      |
| - Student ultimately FAILS course!    | - Student still PASSES course         |
| SEVERITY: SEVERE HARM                 | SEVERITY: BENIGN / BENEFICIAL         |
+---------------------------------------+---------------------------------------+
```

### The Anatomy of a False Positive (False Pass)
Consider a False Positive in our test set:
- A student studied 4.3 hours with 82% attendance.
- Under the default 50% cutoff, the model predicts $P(\text{pass}) = 0.58 \implies \mathbf{PASS}$.
- **What happens in the real world?**
  1. The academic advisory system looks at the prediction and concludes: *"This student is safe. No intervention needed."*
  2. The student receives a notification saying they are on track to pass.
  3. The student relaxes their revision schedule and attends no tutoring sessions.
  4. On exam day, the student **fails the exam**!
  5. The student must repeat the entire semester, pay thousands in tuition, and delay their graduation.

In an educational retention system, **a False Positive is a catastrophic failure of the early-warning promise**!

### The Anatomy of a False Negative (False Fail)
Now consider the complementary error—a False Negative:
- A student studied 3.0 hours with 63% attendance.
- The model predicts $P(\text{pass}) = 0.44 \implies \mathbf{FAIL}$.
- **What happens in the real world?**
  1. The advisory system flags the student as at-risk.
  2. The advisor invites the student to a supportive study workshop.
  3. The student receives high-yield review materials and study strategies.
  4. On exam day, the student **passes the exam**!
  5. The student benefited from extra reinforcement, and the worst consequence was spending a few extra hours studying.

### The Asymmetric Cost Principle
Because a False Positive causes severe harm (preventing needed help) while a False Negative causes benign outcomes (providing extra help), **the cost of a False Positive is far higher than the cost of a False Negative**.

This crucial asymmetry directly motivates the threshold exploration in `main.py`:
- In lines 64-70, `main.py` investigates what happens when we raise the passing cutoff from **50% to 70%**.
- Raising the cutoff demands stronger evidence before certifying a student as "passing".
- As explored in Module 06, raising the cutoff to 70% drops False Positives from **3 down to 0**, completely eliminating dangerous false passes!

## Relevant Code (from main.py, lines 64-70, 120)
```python
print("
Changing the cutoff:")
for cutoff in (0.5, 0.7):
    cutoff_predictions = (probabilities >= cutoff).astype(int)
    print(
        f"  cutoff {cutoff:.0%}: predicted {cutoff_predictions.sum()} passes "
        f"out of {len(cutoff_predictions)} test students"
    )

# Educational discussion prompt in main.py:
print("Try this: change the cutoff to 0.8 and discuss which mistake is worse.")
```

## Code Explanation and Technical Walkthrough
- **Line 65**: Iterates over decision cutoffs `0.5` and `0.7`.
- **Line 66**: Generates predictions under each cutoff: `(probabilities >= cutoff).astype(int)`.
- **Lines 67-70**: Counts predicted passes:
  - At 50% cutoff: 25 predicted passes (contains 3 False Positives).
  - At 70% cutoff: 22 predicted passes (contains 0 False Positives!).
- **Line 120**: Explicitly challenges students to reflect on the moral and operational implications of classification mistakes.

## Worked Example
**Scenario:** A university with 1,000 students deploys our Exam Pass Predictor.
- If the model produces 3 False Positives per 30 students (a 10% false pass rate):
  $$1,000 \times 0.10 = 100 \text{ students}$$
  Approximately **100 struggling students** would be told they are safe, denied tutoring, and subsequently fail!
- If the university raises the cutoff to 70%, False Positives drop to 0%, ensuring that **zero at-risk students are left behind without tutoring**.

## Step-by-Step Student Instructions
1. Run `main.py`: `python main.py`.
2. Locate the console section titled `Changing the cutoff:`.
3. Note that at 50% cutoff, the model predicted 25 passes out of 30 test students.
4. Note that at 70% cutoff, predicted passes dropped to 22.
5. In interactive Python, compute the confusion matrix at cutoff 0.70:
   ```python
   preds_70 = (probabilities >= 0.7).astype(int)
   cm_70 = confusion_matrix(y_test, preds_70, labels=[0, 1])
   print("Confusion matrix at 70% cutoff:\n", cm_70)
   ```
6. Verify that False Positives (top-right cell) dropped from `3` to `0`!

## Expected Output or Observable Behaviour
Interactive console output at 70% cutoff:
```text
Confusion matrix at 70% cutoff:
 [[ 7  0]
 [ 1 22]]
```
True Negatives rose from 4 to 7, False Positives dropped from 3 to 0, and False Negatives remained at 1. Total test accuracy increased from 86.7% to 96.7%!

## Practical Exercises
**Exercise 4.1:** In an airport security luggage scanner predicting "Has Explosives" (1) vs "Clear" (0), which mistake is worse: a False Positive or a False Negative? Explain why.
**Exercise 4.2:** In the Exam Pass Predictor, why does raising the passing threshold from 0.5 to 0.7 eliminate False Positives?
**Exercise 4.3:** What is the trade-off of raising the cutoff to 0.99? (Think about what happens to True Positives).

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Assuming 50% is always the optimal cutoff | 50% treats FP and FN errors as having identical costs, which is rarely true in real life | Select cutoffs based on the relative real-world costs of FP vs FN |
| Believing False Negatives in education are fatal | Telling a student they need extra tutoring rarely causes harm, but telling a failing student they are safe causes failure | Prioritize minimizing False Positives (false passes) |
| Setting cutoff to 1.0 | Requires 100% certainty to predict pass, causing almost all students to be classified as failing | Balance thresholds pragmatically |

## Best Practices and Security Considerations
- **Human-in-the-Loop Governance**: Automated early-warning systems should recommend human advisor reviews, never make automated administrative exclusions.
- **Explainable Advisory**: When a student is flagged as needing help, the advisor should explain the specific contributory factors (e.g., "Increasing attendance above 75% will help secure your pass").

## Summary
In educational analytics, classification mistakes carry asymmetric costs: a False Positive (falsely predicting a pass) deprives an at-risk student of necessary tutoring, while a False Negative (falsely predicting a fail) merely offers extra academic support. In `main.py`, raising the decision cutoff from 50% to 70% eliminates False Positives entirely, illustrating how threshold engineering aligns AI models with human institutional goals.

## Knowledge-check Questions
1. What is the definition of a False Positive in the Exam Pass Predictor?
2. What is the definition of a False Negative?
3. Why is a False Positive generally considered more dangerous in an academic warning system?
4. How many False Positives occur at the default 50% cutoff in `main.py`?
5. What happens to the number of False Positives when the cutoff is raised to 70%?

## References
- Provost, F., & Fawcett, T. (2013). Data Science for Business. O'Reilly Media (Chapter 8: Visualizing Model Performance).
- `main.py` lines 64-70, 120
