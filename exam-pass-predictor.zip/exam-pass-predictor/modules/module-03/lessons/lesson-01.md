# Lesson 01: The Mathematical Sigmoid Function

**Lesson ID:** lesson-01
**Module:** module-03
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- State the mathematical equation of the sigmoid (logistic) activation function
- Trace the behavior of $\sigma(z)$ as $z$ approaches $-\infty$, $0$, and $+\infty$
- Calculate sigmoid outputs for positive, negative, and zero inputs using Python
- Explain why the sigmoid function acts as a differentiable probability squeezer
- Graphically describe the characteristic S-shaped curve of the logistic function

## Prerequisites
- Basic exponential mathematics ($e^x$, where Euler's number $e \approx 2.71828$)
- Concept of limits and asymptotes in high-school algebra

## Concept Explanation

### The Squeezer: From Infinite Scores to Bounded Probabilities
In machine learning classification, we frequently calculate a linear score $z$ by weighting various student signals:
$$z = w_1 x_1 + w_2 x_2 + b$$
Because study hours and attendance can take a wide variety of values, $z$ can be any real number: $+15.4$, $-8.2$, $0.0$, or $+100.0$.

To interpret this arbitrary score as a valid probability $P(\text{pass})$, we require a mathematical function that maps the entire real number line $(-\infty, +\infty)$ onto the open interval $(0, 1)$. The standard mathematical choice for binary classification is the **sigmoid function**, conventionally represented by the Greek letter $\sigma$ (sigma):

$$\sigma(z) = \frac{1}{1 + e^{-z}}$$

Where:
- $z$ is the input linear score (also known as the logit or log-odds).
- $e$ is Euler's constant (base of the natural logarithm, $\approx 2.71828$).
- $e^{-z} = \frac{1}{e^z}$.

### Asymptotic Properties of the Sigmoid Curve
Let us examine the behavior of $\sigma(z)$ across three critical zones:

```
            Sigmoid Function Curve: sigma(z) = 1 / (1 + e^-z)
  1.0 |                                     ............... Asymptote y = 1.0
      |                              _..---'
      |                          _.-'
  0.5 |-----------------------.-'-------------------------- Midpoint (z=0, P=0.5)
      |                   _.-'
      |            _..---'
  0.0 | ...........                                         Asymptote y = 0.0
      +-----------------------+---------------------------> z (Linear Score)
                            z = 0
```

1. **The Neutral Midpoint ($z = 0$)**:
   $$\sigma(0) = \frac{1}{1 + e^{-0}} = \frac{1}{1 + 1} = \frac{1}{2} = 0.5$$
   When the linear score is exactly $0$, the model is completely uncertain, assigning an exact 50% probability to passing and 50% to failing.
2. **Positive Scores ($z > 0$)**:
   As $z$ increases positively, $e^{-z}$ decays toward $0$:
   - For $z = +2$: $\sigma(2) = \frac{1}{1 + e^{-2}} = \frac{1}{1 + 0.1353} \approx 0.8808$ (88.1% pass probability)
   - For $z = +5$: $\sigma(5) = \frac{1}{1 + e^{-5}} = \frac{1}{1 + 0.0067} \approx 0.9933$ (99.3% pass probability)
   - As $z \to +\infty$: $e^{-z} \to 0$, so $\sigma(z) \to 1.0$. The horizontal line $y = 1.0$ is the upper asymptote.
3. **Negative Scores ($z < 0$)**:
   As $z$ decreases negatively, $e^{-z}$ grows rapidly toward $+\infty$:
   - For $z = -2$: $\sigma(-2) = \frac{1}{1 + e^{2}} = \frac{1}{1 + 7.3891} \approx 0.1192$ (11.9% pass probability)
   - For $z = -5$: $\sigma(-5) = \frac{1}{1 + e^{5}} = \frac{1}{1 + 148.41} \approx 0.0067$ (0.67% pass probability)
   - As $z \to -\infty$: $e^{-z} \to +\infty$, so $\sigma(z) \to 0.0$. The horizontal line $y = 0.0$ is the lower asymptote.

### Mathematical Symmetry
The sigmoid function possesses an elegant mathematical symmetry:
$$\sigma(-z) = 1 - \sigma(z)$$
For example:
- $\sigma(2) \approx 0.8808$
- $\sigma(-2) \approx 0.1192 = 1 - 0.8808$

This property ensures that the probability of failing ($1 - P(\text{pass})$) is mathematically complementary and balanced at every point.

## Relevant Code (from main.py, lines 37-40)
```python
# The model fits weights and applies the sigmoid function internally
model = LogisticRegression(max_iter=1000)
model.fit(X_train, y_train)
probabilities = model.predict_proba(X_test)[:, 1]
```

## Code Explanation and Technical Walkthrough
- Scikit-learn's `LogisticRegression` optimizes the linear score $z = w_1 x_1 + w_2 x_2 + b$.
- When `predict_proba(X_test)` is called, scikit-learn computes $z$ for every student row in `X_test` and evaluates the sigmoid function $\sigma(z)$ internally using optimized C/Cython numerical routines.
- Column 1 of the returned array contains the exact sigmoid evaluation for each student.

## Worked Example
**Problem:** A student has $z = 1.15$. Calculate their exact probability of passing using the sigmoid equation by hand.

**Solution:**
1. Formula: $\sigma(z) = \frac{1}{1 + e^{-z}}$
2. Substitute $z = 1.15$:
   $$\sigma(1.15) = \frac{1}{1 + e^{-1.15}}$$
3. Compute $e^{-1.15}$:
   $$e^{-1.15} \approx 0.316637$$
4. Add 1 to denominator:
   $$1 + 0.316637 = 1.316637$$
5. Divide 1 by 1.316637:
   $$\sigma(1.15) = \frac{1}{1.316637} \approx 0.7595$$
6. **Result:** The student has an estimated **76.0% probability** of passing the examination!

## Step-by-Step Student Instructions
1. Open Python interactive shell in terminal: `python3`.
2. Import `math` and define the sigmoid function:
   ```python
   import math
   def sigmoid(z):
       return 1.0 / (1.0 + math.exp(-z))
   ```
3. Test key values:
   ```python
   for val in [-5, -2, -1, 0, 1, 2, 5]:
       print(f"z = {val:2d} -> sigma(z) = {sigmoid(val):.4f}")
   ```
4. Verify that $z=0$ outputs `0.5000`.
5. Verify that $\sigma(-2) + \sigma(2) == 1.0$.

## Expected Output or Observable Behaviour
Output of the interactive loop:
```text
z = -5 -> sigma(z) = 0.0067
z = -2 -> sigma(z) = 0.1192
z = -1 -> sigma(z) = 0.2689
z =  0 -> sigma(z) = 0.5000
z =  1 -> sigma(z) = 0.7311
z =  2 -> sigma(z) = 0.8808
z =  5 -> sigma(z) = 0.9933
```
Notice how smoothly the values transition from nearly 0 to nearly 1.

## Practical Exercises
**Exercise 1.1:** What is the value of $\sigma(0)$? What physical meaning does this hold in a binary exam pass predictor?
**Exercise 1.2:** If a student's study metrics produce a linear score of $z = -3.0$, calculate their pass probability to four decimal places.
**Exercise 1.3:** Prove that $\sigma(-z) = 1 - \sigma(z)$ algebraically.

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Writing `1 / (1 + math.exp(z))` | Omitting the negative sign in the exponent inverts the curve, predicting failure for high scores | Always write $e^{-z}$: `1 / (1 + math.exp(-z))` |
| Numerical overflow with large negative numbers | For $z = -1000$, $e^{1000}$ triggers Python `OverflowError` | In production, use robust implementations like `scipy.special.expit(z)` |
| Assuming sigmoid outputs can reach exactly 1.0 or 0.0 | Sigmoid asymptotes approach 0 and 1 but never touch them for finite real values | Recognize that probabilities approach 0% and 100% asymptotically |

## Best Practices and Security Considerations
- **Differentiability**: The sigmoid function has a smooth, well-behaved derivative: $\sigma'(z) = \sigma(z)(1 - \sigma(z))$. This makes gradient-based optimization computationally efficient.
- **Robust Libraries**: While writing `sigmoid` in pure Python is instructive, in production always use vectorized library implementations such as `scipy.special.expit` or scikit-learn's internal C solvers.

## Summary
The sigmoid function $\sigma(z) = \frac{1}{1 + e^{-z}}$ is the mathematical engine of logistic regression. It converts unconstrained linear combinations of student features into smooth, calibrated probabilities bounded strictly between 0 and 1, with $z=0$ mapping to exactly 50% probability.

## Knowledge-check Questions
1. What is the mathematical formula for the sigmoid activation function?
2. What value does the sigmoid function yield when $z = 0$?
3. What are the horizontal asymptotes of the sigmoid curve as $z \to +\infty$ and $z \to -\infty$?
4. What mathematical symmetry relates $\sigma(-z)$ and $\sigma(z)$?
5. Which scikit-learn method evaluates the sigmoid function on test data to return probabilities?

## References
- Scikit-learn Logistic Regression Mathematical Formulation: https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
- Weisstein, Eric W. "Sigmoid Function." From MathWorld--A Wolfram Web Resource.
- `main.py` lines 37-40
