# Lesson 03: The 2D Geometric Decision Boundary

**Lesson ID:** lesson-03
**Module:** module-03
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define the geometric **decision boundary** in a multi-dimensional feature space
- Derive the linear equation of the decision boundary line where $P(\text{pass}) = 0.50$ ($z = 0$)
- Express attendance as a function of study hours along the decision line
- Explain how the 2D feature plane is partitioned into "predicted pass" and "predicted fail" regions
- Interpret the decision boundary visualization produced in `outputs/decision_boundary.png`

## Prerequisites
- Familiarity with Lesson 01 (sigmoid function) and Lesson 02 (log-odds equation)
- Basic knowledge of graphing linear equations in two variables ($y = mx + b$)

## Concept Explanation

### The Boundary Between Pass and Fail
When a classifier is deployed, it must draw a line (or surface) in the sand that separates instances predicted to fail from instances predicted to pass. This separating geometric surface is called the **decision boundary**.

Under the default decision cutoff of $50\%$ ($\tau = 0.50$), a student is classified as passing if:
$$P(\text{pass}) \ge 0.50$$
From Lesson 01, we know that the sigmoid function outputs $0.50$ if and only if the underlying linear score $z$ is exactly zero:
$$\sigma(z) = 0.50 \iff z = 0$$

Therefore, the mathematical condition that defines the decision boundary is simply:
$$w_1 x_1 + w_2 x_2 + b = 0$$

```
2D Feature Space and Decision Boundary:
Attendance (%)
  100 |                     . o  o   o    o (Passed: y = 1)
      |                  .  o   o   o
   80 |               .   o   o    o
      |            .    x   o   o
   60 |         .     x   x   o
      |      .      x   x                 (Failed: y = 0)
   40 |   .       x   x
      +-----------------------------------> Hours Studied
      0   2       4       6       8      10
          <-- Fail Zone | Pass Zone -->
                 Decision Boundary (z = 0, P = 0.5)
```

### Deriving the 2D Boundary Line
In our Exam Pass Predictor:
- $x_1$: `hours_studied`
- $x_2$: `attendance_percent`
- $w_1 \approx 0.9516$
- $w_2 \approx 0.0336$
- $b \approx -5.0964$

Setting $z = 0$:
$$0.9516(\text{hours}) + 0.0336(\text{attendance}) - 5.0964 = 0$$

To plot this boundary on a standard 2D scatter plot where attendance is on the vertical axis ($y$-axis) and study hours are on the horizontal axis ($x$-axis), we rearrange the equation to isolate `attendance`:
$$0.0336(\text{attendance}) = -0.9516(\text{hours}) + 5.0964$$
$$\text{attendance} = -\left(\frac{0.9516}{0.0336}\right)\text{hours} + \left(\frac{5.0964}{0.0336}\right)$$
$$\text{attendance} \approx -28.32(\text{hours}) + 151.68$$

### Interpreting the Geometry
1. **Negative Slope in Feature Space**: Notice that the boundary line has a negative slope ($-28.32$). This means that as study hours increase, the required attendance needed to pass decreases! A student who studies 6 hours only needs minimal attendance to pass, whereas a student who studies only 3 hours needs much higher attendance to compensate.
2. **The Two Halves of the Map**:
   - Any student whose coordinate $(\text{hours}, \text{attendance})$ falls **above and to the right** of the boundary line has $z > 0 \implies P(\text{pass}) > 0.50$, so the model predicts **PASS**.
   - Any student whose coordinate falls **below and to the left** of the boundary line has $z < 0 \implies P(\text{pass}) < 0.50$, so the model predicts **FAIL**.

## Relevant Code (from main.py, lines 73-82)
```python
# Render the 2D decision boundary visualization
fig, ax = plt.subplots(figsize=(7.5, 5.5))
DecisionBoundaryDisplay.from_estimator(
    model,
    X,
    response_method="predict_proba",
    grid_resolution=250,
    cmap="RdYlBu_r",
    alpha=0.35,
    ax=ax,
)
```

## Code Explanation and Technical Walkthrough
- **Line 73**: Initializes a matplotlib figure with width 7.5 inches and height 5.5 inches.
- **Line 74**: Calls scikit-learn's built-in `DecisionBoundaryDisplay.from_estimator`.
- **`response_method="predict_proba"`**: Instead of drawing just a harsh binary black line, this computes smooth probability contours across the entire 2D feature grid.
- **`grid_resolution=250`**: Creates a dense $250 \times 250$ grid (62,500 test points) to generate smooth, continuous visual gradients.
- **`cmap="RdYlBu_r"`**: The reversed Red-Yellow-Blue colormap shades the low-probability fail region in cool tones and the high-probability pass region in warm/blue tones.
- **`alpha=0.35`**: Sets background opacity so overlay scatter points remain clearly visible.

## Worked Example
**Problem:** Calculate the minimum attendance percentage a student needs to achieve at least a 50% pass probability if they study exactly 4 hours.

**Solution:**
1. At the 50% boundary, $z = 0$:
   $$0.9516(4) + 0.0336(\text{attendance}) - 5.0964 = 0$$
2. Multiply hours:
   $$3.8064 + 0.0336(\text{attendance}) - 5.0964 = 0$$
3. Combine constants:
   $$-1.2900 + 0.0336(\text{attendance}) = 0$$
4. Solve for attendance:
   $$0.0336(\text{attendance}) = 1.2900$$
   $$\text{attendance} = \frac{1.2900}{0.0336} \approx 38.39\%$$
5. **Interpretation:** If a student studies 4 hours, they need at least **38.4% attendance** to reach the 50% pass threshold. Since our course attendance floor in the dataset is 41%, almost any student with 4 hours and reasonable attendance will cross the boundary!

## Step-by-Step Student Instructions
1. Run `python main.py` in your terminal to ensure `outputs/decision_boundary.png` is generated.
2. View the image using an image viewer (e.g. `xdg-open outputs/decision_boundary.png` on Linux or opening the file in VS Code).
3. Observe the continuous color transition from red/yellow (fail zone) to deep blue (pass zone).
4. Locate the actual student dots: notice that yellow/red dots (failed students) concentrate in the lower-left, while blue dots (passed students) dominate the upper-right.
5. Identify any overlapping dots near the boundary line (borderline cases).

## Expected Output or Observable Behaviour
Inspecting `outputs/decision_boundary.png` reveals:
- A clear diagonal separating transition across the 2D feature plane.
- The title: `"The model learns a boundary between pass and fail"`.
- Clean axis labels: `"Hours studied"` (x-axis) and `"Attendance (%)"` (y-axis).
- An informative legend in the lower-right distinguishing actual failed students from passed students.

## Practical Exercises
**Exercise 3.1:** What mathematical condition on $z$ defines the 50% decision boundary?
**Exercise 3.2:** If a student studies 2 hours, what attendance percentage would they need to achieve a 50% pass probability based on the model's equation? Is that attendance percentage practically achievable?
**Exercise 3.3:** Why is the decision boundary in standard logistic regression a straight line (linear hyperplane) rather than a curve?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Assuming the boundary requires 100% certainty | The decision boundary marks the 50% threshold where the model transitions from fail to pass | Recognize that on the boundary line, $P(\text{pass}) = 0.50$ ($z=0$) |
| Using `response_method="predict"` in visualization | Draws a flat two-tone color block without showing probability gradients | Use `response_method="predict_proba"` to visualize confidence contours |
| Confusing feature axes | Swapping hours on the y-axis and attendance on the x-axis causes equations to appear inverted | Consistently track which column represents $x_1$ and $x_2$ |

## Best Practices and Security Considerations
- **Visual Diagnostics**: Plotting decision boundaries in 2D is the single best diagnostic for verifying whether linear models adequately separate classes or if non-linear interactions are needed.
- **High-Resolution Export**: Always specify `dpi=150` or higher and `bbox_inches="tight"` to ensure boundary plots are legible in academic presentations.

## Summary
In a two-dimensional feature space, logistic regression constructs a linear decision boundary defined by $w_1 x_1 + w_2 x_2 + b = 0$ where $P(\text{pass}) = 0.50$. In the Exam Pass Predictor, this boundary forms a diagonal line partitioning the plane into pass and fail regions, illustrating the compensatory trade-off between study hours and classroom attendance.

## Knowledge-check Questions
1. What is the value of the linear score $z$ everywhere along the 50% decision boundary?
2. What is the geometric shape of the decision boundary in a 2-feature logistic regression model?
3. If a student's coordinate falls into the deep blue region of `decision_boundary.png`, what does the model predict?
4. What scikit-learn helper class is used in `main.py` to render the decision boundary?
5. Why does the decision boundary line have a negative slope in this project?

## References
- Scikit-learn `DecisionBoundaryDisplay` API: https://scikit-learn.org/stable/modules/generated/sklearn.inspection.DecisionBoundaryDisplay.html
- Bishop, C. M. (2006). Pattern Recognition and Machine Learning. Springer (Chapter 4: Linear Models for Classification).
- `main.py` lines 72-99
