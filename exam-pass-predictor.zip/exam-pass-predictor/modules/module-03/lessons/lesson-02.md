# Lesson 02: Log-Odds, Logits & Feature Weight Interpretability

**Lesson ID:** lesson-02
**Module:** module-03
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define **odds** and explain how odds differ from probabilities
- Define the **logit** (natural logarithm of the odds)
- Express logistic regression as a linear model of log-odds
- Interpret the signs and magnitudes of learned feature weights
- Interpret the learned weights in `main.py`: hours weight $\approx 0.95$ and attendance weight $\approx 0.03$

## Prerequisites
- Familiarity with Lesson 01 (sigmoid function)
- Basic understanding of the natural logarithm ($\\ln(x)$)

## Concept Explanation

### Odds vs Probability
In everyday language, people often treat "odds" and "probability" as synonyms. In probability theory and statistics, however, they represent distinct mathematical quantities:
- **Probability ($p$)**: The ratio of favorable outcomes to all possible outcomes. Bounded between $0.0$ and $1.0$:
  $$p = \frac{\text{Passes}}{\text{Total Students}}$$
- **Odds ($O$)**: The ratio of the probability of success to the probability of failure:
  $$\text{Odds} = \frac{p}{1 - p}$$

For example:
- If a student has an $80\%$ probability of passing ($p = 0.80$):
  $$\text{Odds} = \frac{0.80}{1 - 0.80} = \frac{0.80}{0.20} = 4.0 \quad (\text{Odds of 4 to 1})$$
- If a student has a $50\%$ probability of passing ($p = 0.50$):
  $$\text{Odds} = \frac{0.50}{0.50} = 1.0 \quad (\text{Even odds, 1 to 1})$$
- If a student has a $20\%$ probability of passing ($p = 0.20$):
  $$\text{Odds} = \frac{0.20}{0.80} = 0.25 \quad (\text{Odds of 1 to 4})$$

While probability is restricted to $[0, 1]$, odds range from $0$ to $+\infty$.

### The Logit Transformation (Log-Odds)
If we take the natural logarithm of the odds, we obtain the **logit** function:
$$\text{logit}(p) = \ln\left(\frac{p}{1 - p}\right)$$

Let us observe what the natural logarithm does to odds:
- If Odds $= 1.0$ ($p = 0.50$): $\ln(1.0) = 0$
- If Odds $> 1.0$ ($p > 0.50$): $\ln(\text{Odds})$ is a positive number ranging from $0$ to $+\infty$
- If Odds $< 1.0$ ($p < 0.50$): $\ln(\text{Odds})$ is a negative number ranging from $-\infty$ to $0$

The logit transformation maps probabilities from $[0, 1]$ onto the entire real number line $(-\infty, +\infty)$!

```
Probability -> Odds -> Log-Odds (Logit):
Probability p:  0.01  ---  0.10  ---  0.50  ---  0.90  ---  0.99
Odds p/(1-p):   0.01  ---  0.11  ---  1.00  ---  9.00  ---  99.0
Logit ln(Odds): -4.60 ---  -2.20 ---  0.00  ---  +2.20 ---  +4.60
```

### Logistic Regression as Linear Log-Odds
Now the core mathematical breakthrough of logistic regression becomes crystal clear:
Instead of trying to model the bounded probability $p$ directly with a straight line, **logistic regression models the log-odds as a linear equation**:

$$\ln\left(\frac{p}{1 - p}\right) = w_1 x_1 + w_2 x_2 + b$$

By solving for $p$ algebraically:
1. Exponentiate both sides: $\frac{p}{1 - p} = e^{w_1 x_1 + w_2 x_2 + b} = e^z$
2. Multiply by $(1 - p)$: $p = e^z (1 - p) = e^z - p e^z$
3. Rearrange: $p + p e^z = e^z \implies p(1 + e^z) = e^z$
4. Divide by $(1 + e^z)$: $p = \frac{e^z}{1 + e^z} = \frac{1}{1 + e^{-z}} = \sigma(z)$!

The linear model of log-odds and the sigmoid probability model are two sides of the exact same coin!

### Interpreting Feature Weights in main.py
In `main.py`, the console prints:
```text
Hours weight: 0.95
Attendance weight: 0.03
```
What do these numbers tell us?
1. **Positive Signs**: Both weights are positive ($+0.95$ and $+0.03$). This confirms that increases in study hours and increases in lecture attendance both increase the log-odds (and therefore the probability) of passing.
2. **Odds Ratio for Hours Studied ($e^{0.9516} \approx 2.59$)**: For every additional 1 hour a student studies, holding attendance constant, their odds of passing are multiplied by $e^{0.9516} \approx 2.59$ (an increase of approximately 159% in the odds of passing!).
3. **Odds Ratio for Attendance ($e^{0.0336} \approx 1.034$)**: For every additional 1% increase in attendance, holding study hours constant, their odds of passing are multiplied by approximately $1.034$ (a 3.4% increase in the odds of passing).
4. **Intercept ($b \approx -5.0964$)**: Represents the log-odds of passing for a student with zero study hours and zero attendance. $e^{-5.0964} \approx 0.0061$, corresponding to a baseline probability of $\sigma(-5.0964) \approx 0.6\%$.

## Relevant Code (from main.py, lines 47-48)
```python
print(f"Hours weight: {model.coef_[0, 0]:.2f}")
print(f"Attendance weight: {model.coef_[0, 1]:.2f}")
```

## Code Explanation and Technical Walkthrough
- `model.coef_`: A 2D array of shape `(1, 2)`.
- `model.coef_[0, 0]`: Extracts the weight for feature 0 (`hours_studied`), approximately $0.9516$.
- `model.coef_[0, 1]`: Extracts the weight for feature 1 (`attendance_percent`), approximately $0.0336$.
- `:.2f`: Formats both weights to 2 decimal places for clean console presentation.

## Worked Example
**Task:** If a student currently has a 50% probability of passing, how does their probability change if they study 1 additional hour?

**Solution:**
1. At 50% probability, Odds $= \frac{0.50}{0.50} = 1.0$. Log-odds $= \ln(1.0) = 0$.
2. Studying 1 extra hour increases the log-odds by the weight $w_1 = 0.9516$:
   $$\text{New Log-Odds} = 0 + 0.9516 = 0.9516$$
3. Convert new log-odds back to probability using the sigmoid function:
   $$p_{\text{new}} = \sigma(0.9516) = \frac{1}{1 + e^{-0.9516}} = \frac{1}{1 + 0.3861} \approx 0.7214 \quad (72.1\%)$$
4. **Conclusion:** For a borderline student, investing just 1 extra hour of revision boosts their passing probability from **50.0% up to 72.1%**!

## Step-by-Step Student Instructions
1. Open Python: `python3`.
2. Compute odds from probability:
   ```python
   import math
   p = 0.80
   odds = p / (1 - p)
   logit = math.log(odds)
   print(f"Probability: {p}, Odds: {odds}, Logit: {logit:.4f}")
   ```
3. Exponentiate the weights from `main.py`:
   ```python
   hours_odds_multiplier = math.exp(0.9516)
   attend_odds_multiplier = math.exp(0.0336)
   print(f"1 extra hour multiplies pass odds by: {hours_odds_multiplier:.2f}x")
   print(f"1% extra attendance multiplies pass odds by: {attend_odds_multiplier:.3f}x")
   ```

## Expected Output or Observable Behaviour
Console outputs show:
```text
1 extra hour multiplies pass odds by: 2.59x
1% extra attendance multiplies pass odds by: 1.034x
```
This confirms that study hours exert a massive multiplier on the student's chances of academic success.

## Practical Exercises
**Exercise 2.1:** If an event has a probability of 0.75, what are its odds?
**Exercise 2.2:** What does a negative weight signify in a logistic regression model? (e.g., if we added a feature `hours_spent_gaming` with weight $-0.45$).
**Exercise 2.3:** Calculate the baseline pass probability for a student who has 0 study hours and 0 attendance using intercept $b = -5.0964$.

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Interpreting weights as percentage probability increases | Logistic regression weights represent changes in *log-odds*, not linear changes in percentage probability | Use $e^w$ to interpret weights as odds ratios, or pass inputs through $\sigma(z)$ |
| Confusing odds with probability | A probability of 0.5 equals odds of 1.0, not odds of 0.5 | Remember $\text{Odds} = p / (1 - p)$ |
| Slicing `coef_` as a 1D array (`model.coef_[0]`) | In scikit-learn, `coef_` is a 2D array of shape `(1, n_features)`; `coef_[0]` returns an array `[0.95, 0.03]` | Use `model.coef_[0, 0]` and `model.coef_[0, 1]` to access individual scalar floats |

## Best Practices and Security Considerations
- **Transparent Model Governance**: The direct link between feature weights and log-odds makes logistic regression an "auditable model"—ideal for educational systems where decisions must be justified to students and parents.
- **Feature Scaling Context**: When comparing weight magnitudes, remember that feature scales matter: hours range from 1 to 10, while attendance ranges from 40 to 100.

## Summary
Logistic regression fits a linear equation to the log-odds (logit) of success: $\ln(p / (1-p)) = w_1 x_1 + w_2 x_2 + b$. Feature weights represent the additive change in log-odds per unit increase in the feature, or equivalently, an odds multiplier of $e^w$. In our model, each extra study hour multiplies passing odds by $\approx 2.59\times$, while each percentage of attendance multiplies odds by $\approx 1.034\times$.

## Knowledge-check Questions
1. How is the odds of an event calculated from its probability $p$?
2. What is the definition of the logit function?
3. What is the value of the logit when the probability of passing is exactly 0.5?
4. In `main.py`, what are the numerical values of the hours weight and attendance weight?
5. By what factor does an additional hour of study multiply a student's passing odds?

## References
- Hosmer, D. W., Lemeshow, S., & Sturdivant, R. X. (2013). Applied Logistic Regression. John Wiley & Sons.
- Scikit-learn Linear Model Documentation: https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
- `main.py` lines 47-48
