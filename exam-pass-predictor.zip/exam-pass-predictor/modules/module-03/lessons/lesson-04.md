# Lesson 04: Scikit-Learn's LogisticRegression Class & Solver Convergence

**Lesson ID:** lesson-04
**Module:** module-03
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Instantiate `sklearn.linear_model.LogisticRegression` with appropriate hyperparameters
- Explain the role of optimization solvers (such as L-BFGS) in finding optimal weights
- Understand why `max_iter=1000` is specified to guarantee numerical convergence
- Explain the concept of log-loss (cross-entropy) minimization
- Recognize the default regularization ($L_2$ penalty) present in scikit-learn

## Prerequisites
- Familiarity with Lesson 01, 02, and 03
- Basic understanding of iterative optimization algorithms

## Concept Explanation

### The Estimator API in Scikit-Learn
Scikit-learn implements a consistent, elegant object-oriented interface for all machine learning models known as the **Estimator API**. Every estimator adheres to a standard lifecycle:
1. **Instantiation**: Create an instance of the class and configure its hyperparameters (e.g., `model = LogisticRegression(max_iter=1000)`).
2. **Fitting**: Train the estimator by adjusting internal parameters to minimize loss on training data (`model.fit(X_train, y_train)`).
3. **Inference**: Use the fitted estimator to predict labels (`model.predict()`) or probabilities (`model.predict_proba()`) on new data.

### How Logistic Regression Learns: Maximum Likelihood Estimation
Unlike Ordinary Least Squares linear regression, which has a closed-form matrix solution (the normal equation $(X^T X)^{-1} X^T y$), logistic regression cannot be solved in a single algebraic step. This is because the non-linear sigmoid transformation $\sigma(z)$ produces a non-linear objective function.

To train the model, scikit-learn minimizes the **binary cross-entropy loss** (also known as negative log-likelihood):

$$\mathcal{L}(w, b) = - \frac{1}{N} \sum_{i=1}^N \left[ y_i \ln(p_i) + (1 - y_i) \ln(1 - p_i) \right]$$

Where:
- $y_i$ is the true binary label ($0$ or $1$).
- $p_i = \sigma(w_1 x_{i1} + w_2 x_{i2} + b)$ is the model's predicted probability for student $i$.

If student $i$ actually passed ($y_i = 1$) and the model predicted $p_i = 0.99$, the loss $-\ln(0.99) \approx 0.01$ is nearly zero. If the model predicted $p_i = 0.01$, the loss $-\ln(0.01) \approx 4.60$ is huge! The algorithm iteratively adjusts weights to penalize confident mistakes.

### Optimization Solvers and `max_iter`
Because there is no closed-form formula, scikit-learn uses iterative numerical optimization algorithms called **solvers**:
- By default, scikit-learn uses the **L-BFGS** (Limited-memory Broyden-Fletcher-Goldfarb-Shanno) quasi-Newton solver.
- L-BFGS starts with random or zero weights and repeatedly takes small mathematical steps in the direction that decreases cross-entropy loss.
- In each step (iteration), it computes the gradients of the loss with respect to all weights.
- When the gradient becomes virtually zero, the algorithm has reached the minimum loss and declared **convergence**.

In older versions or under default settings, `max_iter` defaulted to 100 iterations. When features have different numerical scales (such as `hours_studied` [1-10] and `attendance_percent` [40-100]), the optimization terrain forms an elongated elliptical valley, and 100 iterations may not be enough to reach the bottom, triggering a warning:
`ConvergenceWarning: lbfgs failed to converge (status=1): STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.`

In `main.py`, line 37 explicitly sets:
```python
model = LogisticRegression(max_iter=1000)
```
Setting `max_iter=1000` provides the solver with up to 1000 iterations, ensuring smooth, silent, and complete convergence to the global optimum.

## Relevant Code (from main.py, lines 18, 37-38)
```python
from sklearn.linear_model import LogisticRegression

# Instantiate estimator with generous iteration limit
model = LogisticRegression(max_iter=1000)

# Optimize weights on training partition
model.fit(X_train, y_train)
```

## Code Explanation and Technical Walkthrough
- **Line 18**: Imports `LogisticRegression` from `sklearn.linear_model`.
- **Line 37**: Creates `model` with `max_iter=1000`. By leaving other parameters at their defaults, it uses the standard L-BFGS solver with $L_2$ regularization penalty ($C=1.0$).
- **Line 38**: Executes `model.fit(X_train, y_train)`. Scikit-learn runs the solver across the 90 training student samples until convergence, populating the attributes `model.coef_` and `model.intercept_`.

## Worked Example
**Task:** Inspect the internal parameters and convergence status of the fitted model.

**Code:**
```python
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

df = pd.read_csv("data/student_results.csv")
X = df[["hours_studied", "attendance_percent"]]
y = df["passed"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

model = LogisticRegression(max_iter=1000)
model.fit(X_train, y_train)

print(f"Iterations taken to converge: {model.n_iter_[0]}")
print(f"Learned feature coefficients: {model.coef_}")
print(f"Learned intercept (bias):     {model.intercept_}")
```
**Output:**
```text
Iterations taken to converge: 18
Learned feature coefficients: [[0.95158285 0.03361372]]
Learned intercept (bias):     [-5.09640366]
```
**Observation:** The L-BFGS solver successfully converged in just 18 iterations! Specifying `max_iter=1000` provided plenty of headroom without any risk of timeout.

## Step-by-Step Student Instructions
1. Open interactive Python: `python3`.
2. Replicate the code from the worked example above.
3. Check `model.n_iter_`: verify that the solver converged in under 50 iterations.
4. Try instantiating `LogisticRegression(max_iter=5)`.
5. Run `fit()` on the same data with `max_iter=5`. Observe the `ConvergenceWarning` raised by scikit-learn when insufficient iterations are allowed.
6. Return `max_iter` to `1000` to restore clean execution.

## Expected Output or Observable Behaviour
When testing with `max_iter=5`:
```text
ConvergenceWarning: lbfgs failed to converge (status=1):
STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
```
This demonstrates in real time why configuring `max_iter=1000` is standard engineering practice.

## Practical Exercises
**Exercise 4.1:** Why can't logistic regression parameters be solved using a simple closed-form algebraic formula like linear regression?
**Exercise 4.2:** What does the parameter `max_iter` control in `LogisticRegression`?
**Exercise 4.3:** How many iterations did the L-BFGS solver require to reach full convergence on our 90-sample training dataset?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Ignoring `ConvergenceWarning` | The model stops before finding optimal weights, leading to degraded classification performance | Increase `max_iter` to 500 or 1000 |
| Calling `fit()` on the entire dataset `X` | Leaks test data into model weights, corrupting generalizability evaluation | Always fit on `X_train` and `y_train` exclusively |
| Passing 1D arrays for features | Scikit-learn estimators strictly require 2D input arrays for $X$ | Ensure `X_train` is a DataFrame or 2D NumPy array |

## Best Practices and Security Considerations
- **Convergence Checks**: Always inspect `model.n_iter_` during testing to verify that iterations remained comfortably below `max_iter`.
- **Default Hyperparameters**: For beginner datasets, default $L_2$ regularization with $C=1.0$ provides adequate protection against overfitting.
- **Deterministic Execution**: In complex models with randomized solvers (like SGDClassifier), set `random_state` on the estimator; for deterministic L-BFGS in LogisticRegression, setting `random_state` is optional but good practice.

## Summary
Training logistic regression entails minimizing binary cross-entropy loss through iterative numerical optimization solvers such as L-BFGS. In `main.py`, setting `max_iter=1000` guarantees that the optimizer has sufficient iterations to converge reliably to the global minimum, learning optimal weights ($w_{\text{hours}} \approx 0.95$, $w_{\text{attendance}} \approx 0.03$, $b \approx -5.10$) without warnings.

## Knowledge-check Questions
1. What loss function does logistic regression minimize during training?
2. What default numerical solver does scikit-learn use for `LogisticRegression`?
3. What warning is triggered if `max_iter` is set too low for the solver to reach optimal loss?
4. How many iterations did the model take to converge on the student training data?
5. Which attribute of the fitted model reveals how many optimization iterations were performed?

## References
- Scikit-learn LogisticRegression API: https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegression.html
- Nocedal, J., & Wright, S. J. (2006). Numerical Optimization. Springer (Chapter 7: Quasi-Newton Methods).
- `main.py` line 37
