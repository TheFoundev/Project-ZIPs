# Module 3 Exercises: Logistic Regression Math & Estimators

## Exercise 3.1: Manual Sigmoid Calculation (15 min)
**Objective:** Hand-calculate sigmoid probabilities and compare against Python output.
**Problem Statement:** Verify the mathematical behavior of the sigmoid activation function across positive, negative, and zero linear scores.

**Requirements:**
1. Given $z_1 = -2.0$, $z_2 = 0.0$, and $z_3 = 2.5$, compute $\sigma(z)$ by hand using $\sigma(z) = \frac{1}{1 + e^{-z}}$.
2. Write a Python snippet to verify your manual calculations to 4 decimal places.
3. Confirm that $\sigma(0) == 0.5000$.

**Constraints:** Use standard Python math module.
**Expected Behaviour:** Accurate calculations matching: $\sigma(-2) \approx 0.1192$, $\sigma(0) = 0.5000$, $\sigma(2.5) \approx 0.9241$.

**Acceptance Criteria:**
- [ ] Correct manual work shown for all 3 values.
- [ ] Python verification matches within 0.0001.
- [ ] Clear explanation of why $z=0$ outputs 0.5.

---

## Exercise 3.2: Log-Odds and Odds Multipliers (15 min)
**Objective:** Convert feature weights into interpretable odds multipliers.
**Problem Statement:** Model weights in logistic regression represent changes in log-odds. You need to calculate the odds ratio for `hours_studied` and `attendance_percent`.

**Requirements:**
1. Take the learned hours weight $w_1 = 0.9516$ and compute its odds multiplier: $\text{OR}_1 = e^{w_1}$.
2. Take the learned attendance weight $w_2 = 0.0336$ and compute its odds multiplier: $\text{OR}_2 = e^{w_2}$.
3. Write a short paragraph explaining what these multipliers mean in plain English for a student planning their revision schedule.

**Constraints:** Use $e \approx 2.71828$.
**Expected Behaviour:** Calculate $\text{OR}_1 \approx 2.59$ and $\text{OR}_2 \approx 1.034$.

**Acceptance Criteria:**
- [ ] Odds ratio for hours verified as ~2.59.
- [ ] Odds ratio for attendance verified as ~1.034.
- [ ] Clear plain-English interpretation provided.

---

## Exercise 3.3: Decision Boundary Line Formula (15 min)
**Objective:** Calculate the linear equation of the decision boundary line.
**Problem Statement:** Using the learned weights and intercept from `main.py`, solve for the 2D boundary equation where $P(\text{pass}) = 0.50$.

**Requirements:**
1. State the condition for the 50% boundary: $w_1 x_1 + w_2 x_2 + b = 0$.
2. Substitute $w_1 = 0.9516$, $w_2 = 0.0336$, and $b = -5.0964$.
3. Express `attendance_percent` ($x_2$) in terms of `hours_studied` ($x_1$): $x_2 = m x_1 + c$.
4. Calculate the attendance required for a student who studied 5 hours.

**Constraints:** Show all algebraic rearrangement steps.
**Expected Behaviour:** Linear equation $x_2 = -28.32 x_1 + 151.68$. For 5 hours, required attendance is approximately 10.1%.

**Acceptance Criteria:**
- [ ] Correct derivation showing slope $m \approx -28.32$.
- [ ] Correct intercept $c \approx 151.68$.
- [ ] Required attendance for 5 hours correctly calculated.

---

## Exercise 3.4: Investigating Estimator Convergence (10 min)
**Objective:** Observe the effect of `max_iter` on solver convergence.
**Problem Statement:** Experiment with different `max_iter` values to understand why `main.py` specifies `max_iter=1000`.

**Requirements:**
1. Train `LogisticRegression` on `X_train` and `y_train` with `max_iter=5`. Document the warning message.
2. Train `LogisticRegression` with `max_iter=1000`. Verify that no warning is raised.
3. Check `model.n_iter_[0]` to record the exact number of iterations needed for full convergence.

**Constraints:** Use scikit-learn and the project dataset.
**Expected Behaviour:** Warning observed at `max_iter=5`; clean convergence at `max_iter=1000` within ~18 iterations.

**Acceptance Criteria:**
- [ ] ConvergenceWarning observed and documented.
- [ ] Clean run verified with `max_iter=1000`.
- [ ] Actual convergence iteration count recorded (~18).
