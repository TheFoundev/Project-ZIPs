# Lesson 02: Decision Cutoffs & Threshold Tuning: Eliminating False Passes

**Lesson ID:** lesson-02
**Module:** module-06
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain how shifting the probability cutoff alters classifier predictions
- Trace the cutoff comparison in `main.py` between 50% and 70% thresholds
- Explain why raising the cutoff to 0.70 reduces predicted passes from 25 to 22
- Verify that raising the cutoff to 0.70 eliminates all 3 False Positives
- Explain the trade-offs of setting an aggressive cutoff of 0.80

## Prerequisites
- Familiarity with Lesson 01 and Module 05 (False Positives vs False Negatives)
- Understanding of boolean array thresholding in Python

## Concept Explanation

### The Cutoff as a Control Dial
In standard machine learning tutorials, classification is often presented as rigid: if probability $\ge 0.5$, predict 1; otherwise predict 0. In real-world engineering, however, **the decision cutoff $\tau$ is an adjustable tuning dial**:

$$\hat{y} = \begin{cases} 1 & \text{if } P(\text{pass}) \ge \tau \\ 0 & \text{if } P(\text{pass}) < \tau \end{cases}$$

```
Cutoff Tuning Spectrum:
Cutoff = 0.30: Lenient (Almost everyone passes. High False Positives, Low False Negatives)
Cutoff = 0.50: Default Balance (25 predicted passes, 3 False Positives, 1 False Negative)
Cutoff = 0.70: Conservative (22 predicted passes, 0 False Positives, 1 False Negative)
Cutoff = 0.90: Extremely Strict (Few predicted passes. High False Negatives, Low True Positives)
```

### The Cutoff Experiment in `main.py`
In `main.py`, lines 64-70 implement a direct threshold comparison:
```python
print("
Changing the cutoff:")
for cutoff in (0.5, 0.7):
    cutoff_predictions = (probabilities >= cutoff).astype(int)
    print(
        f"  cutoff {cutoff:.0%}: predicted {cutoff_predictions.sum()} passes "
        f"out of {len(cutoff_predictions)} test students"
    )
```

Let us examine what occurs across the 30 test students:
1. **At Cutoff 0.50 (50%)**:
   - The model predicts **25 passes** and **5 fails**.
   - Performance: $\text{TP} = 22$, $\text{TN} = 4$, $\mathbf{FP = 3}$, $\text{FN} = 1$.
   - Accuracy: $26 / 30 = \mathbf{86.7\%}$.
   - Concern: 3 students who actually failed were told they would pass!
2. **At Cutoff 0.70 (70%)**:
   - The model requires at least a 70% probability to certify a student as "passing".
   - The model predicts **22 passes** and **8 fails**.
   - Performance: $\text{TP} = 22$, $\text{TN} = 7$, $\mathbf{FP = 0}$, $\text{FN} = 1$.
   - Accuracy: $29 / 30 = \mathbf{96.7\%}$!

### Why Did False Positives Vanish?
Let us look at the predicted probabilities for the 3 students who failed but were misclassified at the 0.5 cutoff:
- Student A: Probability $= 0.58$ (58%)
- Student B: Probability $= 0.62$ (62%)
- Student C: Probability $= 0.67$ (67%)

Under a 50% cutoff, all three exceeded 0.50, so the model predicted pass (creating 3 False Positives).
When the cutoff was raised to 70%:
- All three students fall below 0.70!
- The model now correctly predicts **FAIL** for all three!
- False Positives drop from $3$ straight to **$0$**!
- True Negatives jump from $4$ to **$7$** (100% of failing students detected!).

### What Happens at an 80% Cutoff?
Line 120 of `main.py` challenges the student: *"Try this: change the cutoff to 0.8 and discuss which mistake is worse."*
Evaluating at cutoff 0.80:
```python
cutoff_08 = (probabilities >= 0.8).astype(int)
# Still predicts 22 passes out of 30!
# TN = 7, FP = 0, FN = 1, TP = 22 (Accuracy = 96.7%)
```
In this dataset, the 22 genuinely passing students have probabilities exceeding 85%, so raising the cutoff to 0.8 maintains high accuracy while maintaining zero false passes.

## Relevant Code (from main.py, lines 64-70, 120)
```python
print("
Changing the cutoff:")
for cutoff in (0.5, 0.7):
    cutoff_predictions = (probabilities >= cutoff).astype(int)
    print(
        f"  cutoff {cutoff:.0%}: predicted {cutoff_predictions.sum()} passes "
        f"out of {len(cutoff_predictions)} test students"
    )

print("
Saved: outputs/decision_boundary.png, outputs/confusion_matrix.png, outputs/metrics.txt")
print("Try this: change the cutoff to 0.8 and discuss which mistake is worse.")
```

## Code Explanation and Technical Walkthrough
- **Line 65**: Iterates through cutoff values `0.5` and `0.7`.
- **Line 66**: Generates boolean arrays with `probabilities >= cutoff` and converts to integers (`0` or `1`).
- **Line 68**: `cutoff_predictions.sum()` sums the 1s, counting the total predicted passes.
- **Line 69**: Prints formatted output: `cutoff 50%: predicted 25 passes` and `cutoff 70%: predicted 22 passes`.

## Worked Example
**Task:** Write a Python verification script that calculates confusion matrices across cutoffs 0.4, 0.5, 0.6, 0.7, 0.8, and 0.9.

**Code:**
```python
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split

df = pd.read_csv("data/student_results.csv")
X = df[["hours_studied", "attendance_percent"]]
y = df["passed"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

model = LogisticRegression(max_iter=1000).fit(X_train, y_train)
probs = model.predict_proba(X_test)[:, 1]

for cut in [0.4, 0.5, 0.6, 0.7, 0.8, 0.9]:
    preds = (probs >= cut).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_test, preds, labels=[0, 1]).ravel()
    acc = (tp + tn) / len(y_test)
    print(f"Cutoff {cut:.1f} | Passes: {preds.sum():2d} | TN: {tn} FP: {fp} FN: {fn} TP: {tp} | Acc: {acc:.1%}")
```
**Output:**
```text
Cutoff 0.4 | Passes: 26 | TN: 3 FP: 4 FN: 1 TP: 22 | Acc: 83.3%
Cutoff 0.5 | Passes: 25 | TN: 4 FP: 3 FN: 1 TP: 22 | Acc: 86.7%
Cutoff 0.6 | Passes: 23 | TN: 6 FP: 1 FN: 1 TP: 22 | Acc: 93.3%
Cutoff 0.7 | Passes: 22 | TN: 7 FP: 0 FN: 1 TP: 22 | Acc: 96.7%
Cutoff 0.8 | Passes: 22 | TN: 7 FP: 0 FN: 1 TP: 22 | Acc: 96.7%
Cutoff 0.9 | Passes: 20 | TN: 7 FP: 0 FN: 3 TP: 20 | Acc: 90.0%
```
**Key Takeaway:** Notice the sweet spot between 0.7 and 0.8, where False Positives drop to 0 and accuracy reaches peak performance (96.7%)! At 0.9, False Negatives begin to rise as passing students are penalized.

## Step-by-Step Student Instructions
1. Open terminal and run `python main.py`.
2. Inspect the lines under `Changing the cutoff:`.
3. Verify that cutoff 50% predicted 25 passes out of 30 test students.
4. Verify that cutoff 70% predicted 22 passes out of 30 test students.
5. In interactive Python, replicate the threshold sweep from the worked example.
6. Observe how the 70% threshold optimizes error elimination.

## Expected Output or Observable Behaviour
Console outputs show:
```text
Changing the cutoff:
  cutoff 50%: predicted 25 passes out of 30 test students
  cutoff 70%: predicted 22 passes out of 30 test students
```

## Practical Exercises
**Exercise 2.1:** What happens to the number of predicted passes when the decision cutoff is raised from 50% to 70%?
**Exercise 2.2:** Why does raising the cutoff eliminate False Positives in this dataset?
**Exercise 2.3:** What risk arises if the cutoff is set too high (e.g. 0.95)?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Thinking cutoffs must stay at 50% | 50% is merely a default convention, not an immutable law | Adjust cutoffs based on domain error costs |
| Believing higher cutoffs always increase accuracy | If set too high, False Negatives spike, reducing accuracy | Perform a threshold sweep to find the empirical optimum |
| Applying cutoffs to logits instead of probabilities | Logits range from -inf to +inf; a cutoff of 0.7 on logits means a probability of 66.8% | Always apply cutoffs to probabilities in [0, 1] |

## Best Practices and Security Considerations
- **Threshold Documentation**: In production AI systems, never bury thresholds in code; declare decision cutoffs in configuration files and document the ethical rationale.
- **Stakeholder Alignment**: Academic administrators and teaching staff should jointly review threshold policies before deploying automated early warning tools.

## Summary
Threshold tuning allows machine learning practitioners to align model behavior with domain priorities. In `main.py`, shifting the decision cutoff from 50% to 70% reduces predicted passes from 25 to 22, completely eliminates False Positives (dropping from 3 to 0), and elevates overall test accuracy from 86.7% to 96.7%.

## Knowledge-check Questions
1. How many passes are predicted at the 50% cutoff in `main.py`?
2. How many passes are predicted at the 70% cutoff?
3. What happens to the number of False Positives when the cutoff is raised to 70%?
4. What test accuracy is achieved at the 70% cutoff?
5. Why is an 80% cutoff viable in this dataset without sacrificing passing students?

## References
- Scikit-learn Threshold Tuning Guide: https://scikit-learn.org/stable/modules/classification_threshold.html
- `main.py` lines 64-70, 120
