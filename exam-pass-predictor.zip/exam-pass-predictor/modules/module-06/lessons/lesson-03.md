# Lesson 03: Running the Complete Pipeline & File Artifact Export

**Lesson ID:** lesson-03
**Module:** module-06
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Execute the complete `main.py` script from the terminal and audit console outputs
- Inspect and verify the contents of `outputs/metrics.txt`
- Correlate console printed metrics with exported file metrics
- Verify memory cleanup using `plt.close(fig)`
- Perform quality assurance on all generated output artifacts

## Prerequisites
- Familiarity with Lesson 01 and Lesson 02
- Basic understanding of command-line execution and file reading

## Concept Explanation

### The Importance of Automated Pipeline Auditing
A robust machine learning pipeline does not merely print numbers to an ephemeral terminal window. In production environments, pipelines must generate persistent, auditable file artifacts that can be reviewed by data engineers, domain experts, and automated verification suites.

`main.py` implements a complete export lifecycle:
1. **Console Feedback**: Immediate textual confirmation for developers.
2. **Graphical Artifacts**: `outputs/decision_boundary.png` and `outputs/confusion_matrix.png`.
3. **Structured Metrics Log**: `outputs/metrics.txt` recording all critical statistical benchmarks.

```
Complete Pipeline Execution Artifacts:
+-----------------------------------------------------------------+
|                       python main.py                            |
+-----------------------------------------------------------------+
                                |
       +------------------------+------------------------+
       |                                                 |
       v                                                 v
+-----------------------------+   +-----------------------------+
| Graphical Artifacts (PNG)   |   | Persistent Text Log         |
| - outputs/                  |   | - outputs/metrics.txt       |
|   decision_boundary.png     |   |   - Accuracy: 0.8667        |
| - outputs/                  |   |   - Classification Report   |
|   confusion_matrix.png      |   |   - Persona Probabilities   |
+-----------------------------+   +-----------------------------+
```

### Deconstructing `outputs/metrics.txt`
Lines 112-118 in `main.py` write the summary file:
```python
with open(OUT / "metrics.txt", "w", encoding="utf-8") as handle:
    handle.write(f"accuracy at 0.5 cutoff: {accuracy:.4f}

")
    handle.write(classification_report(y_test, predictions, zero_division=0))
    handle.write("
Example probabilities:
")
    for label, probability in zip(examples["label"], example_probs):
        handle.write(f"{label}: {probability:.4f}
")
```

Let us audit the exact contents of this file on disk:
- **Header Line**: `accuracy at 0.5 cutoff: 0.8667` (exact floating-point accuracy to 4 decimal places).
- **Classification Table**: The complete precision, recall, f1-score, and support table for both classes.
- **Example Probabilities Section**:
  - `6 hours, 80% attendance: 0.9645`
  - `3 hours, 60% attendance: 0.4440`
  - `8 hours, 95% attendance: 0.9967`

Notice that in `metrics.txt`, probabilities are recorded with 4 decimal places (`0.9645`), whereas the console formats them as integer percentages (`96%`). Storing high-precision numbers in artifacts ensures reproducibility for downstream automated systems.

## Relevant Code (from main.py, lines 112-120)
```python
with open(OUT / "metrics.txt", "w", encoding="utf-8") as handle:
    handle.write(f"accuracy at 0.5 cutoff: {accuracy:.4f}

")
    handle.write(classification_report(y_test, predictions, zero_division=0))
    handle.write("
Example probabilities:
")
    for label, probability in zip(examples["label"], example_probs):
        handle.write(f"{label}: {probability:.4f}
")

print("
Saved: outputs/decision_boundary.png, outputs/confusion_matrix.png, outputs/metrics.txt")
print("Try this: change the cutoff to 0.8 and discuss which mistake is worse.")
```

## Code Explanation and Technical Walkthrough
- **Line 112**: Opens `OUT / "metrics.txt"` with write mode (`"w"`) and explicit UTF-8 encoding.
- **Line 113**: Writes the four-decimal accuracy string.
- **Line 114**: Writes the formatted classification report directly into the file.
- **Lines 115-117**: Iterates through benchmark personas and writes four-decimal probabilities.
- **Line 119**: Prints a confirmation message listing the paths of all three saved artifacts.

## Worked Example
**Task:** Execute `main.py` and write a bash command pipeline to verify file sizes and line counts of all generated artifacts.

**Terminal Execution:**
```bash
python main.py
ls -lh outputs/
wc -l outputs/metrics.txt
```
**Output:**
```text
============================================================
WILL YOU PASS?
============================================================
Accuracy at 50% cutoff: 86.7%
Hours weight: 0.95
Attendance weight: 0.03

Classification report:

              precision    recall  f1-score   support

           0       0.80      0.57      0.67         7
           1       0.88      0.96      0.92        23

    accuracy                           0.87        30
   macro avg       0.84      0.76      0.79        30
weighted avg       0.86      0.87      0.86        30

Example probabilities:
  6 hours, 80% attendance        -> 96% chance of passing
  3 hours, 60% attendance        -> 44% chance of passing
  8 hours, 95% attendance        -> 100% chance of passing

Changing the cutoff:
  cutoff 50%: predicted 25 passes out of 30 test students
  cutoff 70%: predicted 22 passes out of 30 test students

Saved: outputs/decision_boundary.png, outputs/confusion_matrix.png, outputs/metrics.txt
Try this: change the cutoff to 0.8 and discuss which mistake is worse.

total 228K
-rw-r--r-- 1 aziz aziz 182K Oct 28 08:23 decision_boundary.png
-rw-r--r-- 1 aziz aziz  41K Oct 28 08:23 confusion_matrix.png
-rw-r--r-- 1 aziz aziz  625 Oct 28 08:23 metrics.txt

15 outputs/metrics.txt
```
All three files are created, non-empty, and perfectly formatted.

## Step-by-Step Student Instructions
1. Navigate to the project folder:
   `cd "beginner-projects-main/AI-ML Beginners/projects/11_exam_pass_predictor"`
2. Execute the script: `python main.py`.
3. Check the exit code: `echo $?` (must return `0`).
4. Read `outputs/metrics.txt` using `cat outputs/metrics.txt`.
5. Verify that accuracy is logged as `0.8667`.
6. Verify that the three persona probabilities match `0.9645`, `0.4440`, and `0.9967`.

## Expected Output or Observable Behaviour
All three files are updated in `outputs/`. The console output matches the verified project run, confirming complete pipeline health.

## Practical Exercises
**Exercise 3.1:** What are the three output files generated in `outputs/`?
**Exercise 3.2:** What is the exact floating-point accuracy recorded on the first line of `outputs/metrics.txt`?
**Exercise 3.3:** Why is specifying `encoding="utf-8"` standard best practice when writing text artifacts in Python?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Running the script from outside the project directory without pathlib | Relative paths like `"outputs/metrics.txt"` can fail if the working directory differs | Always use `Path(__file__).resolve().parent` for absolute directory anchoring |
| Forgetting to call `plt.close(fig)` | Memory leaks occur as unclosed figures remain allocated in RAM | Always close matplotlib figures after saving |
| Omitting directory creation (`mkdir(exist_ok=True)`) | The script crashes on initial run if `outputs/` does not exist | Ensure `OUT.mkdir(exist_ok=True)` precedes all file writing |

## Best Practices and Security Considerations
- **Deterministic File Generation**: Ensure that re-running the script safely overwrites existing output files without crashing or requiring manual deletion.
- **Automated Validation**: Write automated integration tests that check for the existence and non-zero size of all expected output files.

## Summary
The complete Exam Pass Predictor pipeline coordinates data ingestion, stratified splitting, model fitting, probabilistic thresholding, graphical rendering, and file export. Executing `main.py` produces three verifiable artifacts: `decision_boundary.png`, `confusion_matrix.png`, and `metrics.txt`.

## Knowledge-check Questions
1. How many total lines are written to `outputs/metrics.txt`?
2. What accuracy value is recorded in `metrics.txt`?
3. What are the four-decimal probabilities recorded for the three student personas?
4. What matplotlib function prevents memory bloat by closing figure handles?
5. What confirmation message is printed at the end of `main.py`?

## References
- Python Context Managers (`with open`): https://docs.python.org/3/reference/compound_stmts.html#the-with-statement
- `main.py` lines 112-120
