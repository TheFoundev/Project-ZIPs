# Lesson 04: Expanding the Predictor: Scaling, New Features & Production Readiness

**Lesson ID:** lesson-04
**Module:** module-06
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why feature scaling (e.g. `StandardScaler`) is beneficial when expanding feature sets
- Design multi-feature expansions incorporating homework completion and practice tests
- Evaluate the role of regularization hyperparameters ($C$ parameter) in logistic regression
- Implement cross-validation to assess model variance across multiple data splits
- Formulate ethical and governance guidelines for deploying educational AI systems

## Prerequisites
- Completion of all prior lessons in Modules 01 through 06
- Broad understanding of machine learning pipelines

## Concept Explanation

### Taking the Model to Production
The Exam Pass Predictor in `main.py` demonstrates a complete, elegant two-feature classification pipeline. In modern institutional production environments, however, predictive models evolve to incorporate richer feature spaces, feature scaling, cross-validation, and governance safeguards.

```
Extended Production Pipeline:
+-----------------------------------------------------------------+
| Input Features:                                                 |
| - hours_studied       - attendance_percent                      |
| - practice_tests      - homework_completion_rate                |
+-----------------------------------------------------------------+
                                |
                                v
+-----------------------------------------------------------------+
| Feature Standardization (StandardScaler):                       |
| Transformed features have Mean = 0, Std Dev = 1                 |
+-----------------------------------------------------------------+
                                |
                                v
+-----------------------------------------------------------------+
| Regularized Logistic Regression (C=1.0) + 5-Fold Stratified CV  |
+-----------------------------------------------------------------+
                                |
                                v
+-----------------------------------------------------------------+
| Calibrated Probability Output -> Advisor Early Warning Alert    |
+-----------------------------------------------------------------+
```

### 1. Feature Standardization with `StandardScaler`
In Module 02, we observed that `hours_studied` spans $1$ to $10$, while `attendance_percent` spans $40$ to $100$.

When expanding the model to include features like `practice_tests` (ranging from $0$ to $5$) or `prior_gpa` (ranging from $0.0$ to $4.0$):
- Features on larger numerical scales dominate gradient descent optimization.
- More importantly, **regularization** ($L_2$ penalty) in scikit-learn penalizes large weights uniformly. If a feature has tiny values, its learned weight must be large to compensate, causing the regularizer to unfairly shrink it!
- Applying `StandardScaler` standardizes every feature to have zero mean and unit variance:
  $$x_{\text{scaled}} = \frac{x - \mu}{\sigma}$$
This places all academic indicators on an equal footing.

### 2. Incorporating Additional Academic Features
While study hours and attendance explain 86.7% of pass/fail variation, other student engagement indicators can capture the remaining variance:
- **`practice_tests_completed`**: Measures active recall and self-assessment dedication.
- **`homework_completion_rate`**: Measures consistent term-time effort.
- **`prior_prerequisite_grade`**: Controls for baseline subject aptitude.

### 3. Cross-Validation for Robust Evaluation
In `main.py`, we evaluated on a single test split of 30 students. In production:
- A single split can have minor sampling variance.
- **Stratified $K$-Fold Cross-Validation** (e.g. 5 folds) trains and tests the model 5 times across different subsets of data, reporting mean accuracy and standard deviation (e.g. $88.3\% \pm 3.1\%$).

### 4. Ethical Deployment Principles in Education
Deploying predictive AI in education carries profound ethical responsibilities:
1. **No Algorithmic Tracking or Gatekeeping**: Models must never be used to lock students out of courses, discourage ambitions, or justify lower expectations.
2. **Actionable Recommendations**: An advisory system should not just say "You have a 44% chance of passing." It should say: *"Students who complete 2 more hours of review and attend the Friday workshop boost their success probability to 84%."*
3. **Data Anonymization**: Student records must be stripped of names, student IDs, and demographic identifiers to protect privacy under FERPA/GDPR regulations.

## Relevant Code (Extension Example)
```python
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import cross_val_score

# Production pipeline combining scaling and regularized logistic regression
pipeline = make_pipeline(
    StandardScaler(),
    LogisticRegression(max_iter=1000, C=1.0)
)

# 5-fold stratified cross-validation
cv_scores = cross_val_score(pipeline, X, y, cv=5, scoring="accuracy")
print(f"5-Fold Cross-Validation Accuracy: {cv_scores.mean():.1%} (+/- {cv_scores.std():.1%})")
```

## Code Explanation and Technical Walkthrough
- `make_pipeline`: Chains `StandardScaler` and `LogisticRegression` together. Crucially, the scaler fits only on the training folds inside each cross-validation split, preventing data leakage.
- `cross_val_score`: Automatically partitions data into 5 stratified folds, trains on 4 folds, tests on the 5th, and repeats 5 times.
- `cv_scores.mean()`: Reports robust, generalized accuracy across the entire 120-student dataset.

## Worked Example
**Task:** Run 5-fold cross-validation on our project dataset and observe model stability.

**Code:**
```python
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

df = pd.read_csv("data/student_results.csv")
X = df[["hours_studied", "attendance_percent"]]
y = df["passed"]

pipeline = make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000))
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
scores = cross_val_score(pipeline, X, y, cv=cv, scoring="accuracy")

print("Folds accuracy:", [round(s, 3) for s in scores])
print(f"Mean CV Accuracy: {scores.mean():.1%}")
print(f"Standard Deviation: {scores.std():.1%}")
```
**Output:**
```text
Folds accuracy: [0.875, 0.917, 0.833, 0.875, 0.875]
Mean CV Accuracy: 87.5%
Standard Deviation: 2.6%
```
**Interpretation:** Across all 5 folds, accuracy remains tightly clustered between 83.3% and 91.7%, with an overall mean of **87.5%**. This proves that the logistic regression model is stable, robust, and reliable!

## Step-by-Step Student Instructions
1. Open interactive Python: `python3`.
2. Import `make_pipeline`, `StandardScaler`, and `LogisticRegression`.
3. Build the pipeline and run 5-fold cross-validation as shown above.
4. Verify that mean cross-validation accuracy is approximately 87.5%.
5. Reflect on how adding active recall indicators (such as practice tests) could push accuracy above 90%.

## Expected Output or Observable Behaviour
Console outputs show consistent accuracy across all 5 cross-validation folds, confirming model generalizability.

## Practical Exercises
**Exercise 4.1:** Why does feature standardization prevent unscaled features with large ranges from distorting regularization?
**Exercise 4.2:** Why is `make_pipeline` preferred over manually scaling the entire dataset before splitting?
**Exercise 4.3:** List three ethical safeguards an educational institution must enforce before deploying a predictive student model.

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Scaling the entire dataset before `train_test_split` | Leaks test set mean and standard deviation into the training set | Fit the scaler strictly on training folds via `make_pipeline` |
| Using machine learning to gatekeep admissions | Restricts educational opportunities based on historical correlation | Deploy predictive AI solely for supportive coaching |
| Over-relying on a single test partition | Small test sets can have sampling variance | Use $K$-fold cross-validation for definitive benchmarking |

## Best Practices and Security Considerations
- **Pipeline Encapsulation**: Always wrap preprocessing and estimators in scikit-learn `Pipeline` objects to eliminate data leakage.
- **Regularization Tuning**: Tune the inverse regularization strength $C$ (default $1.0$) using `GridSearchCV` when adding many correlated features.

## Summary
To extend the Exam Pass Predictor for production readiness, practitioners combine feature standardization (`StandardScaler`), multi-feature expansion (e.g. practice tests, homework), and stratified $K$-fold cross-validation. Above all, predictive educational models must be deployed with strict ethical safeguards aimed at student empowerment.

## Knowledge-check Questions
1. Why is feature scaling recommended when adding features with diverse numerical scales?
2. What scikit-learn class chains data preprocessing and model estimation into an atomic unit?
3. What is the average accuracy achieved by the model under 5-fold cross-validation?
4. What data leakage bug occurs if a scaler is fit on the full dataset before splitting?
5. What is the primary ethical purpose of predictive analytics in education?

## References
- Scikit-learn Pipeline and Feature Union: https://scikit-learn.org/stable/modules/compose.html#pipeline
- Scikit-learn Cross-Validation: https://scikit-learn.org/stable/modules/cross_validation.html
- U.S. Department of Education: Artificial Intelligence and the Future of Teaching and Learning (2023)
