# Lesson 01: Visualizing Decision Boundaries & Probability Gradients

**Lesson ID:** lesson-01
**Module:** module-06
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain how `DecisionBoundaryDisplay.from_estimator` generates 2D probability surfaces
- Configure grid resolution, response methods, and colormaps in scikit-learn visualizations
- Interpret the color gradient produced by `cmap="RdYlBu_r"` from fail (cool/red) to pass (blue)
- Superimpose empirical student scatter points with color-coded ground-truth labels
- Save high-resolution publication-ready PNG graphics using `dpi=150` and `bbox_inches="tight"`

## Prerequisites
- Completion of Module 03 (decision boundary mathematics) and Module 05 (evaluation)
- Basic familiarity with matplotlib figures, axes, and colormaps

## Concept Explanation

### The Power of 2D Visual Diagnostic Surfaces
While numerical evaluation tables (accuracy, confusion matrix, precision) provide statistical evidence, nothing compares to seeing the geometric behavior of a trained model across the continuous feature landscape.

In `main.py`, lines 72-99 generate `outputs/decision_boundary.png`. This visualization accomplishes three vital diagnostic tasks simultaneously:
1. **Renders the Continuous Probability Field**: It computes and visualizes the model's confidence across every possible combination of study hours (0 to 10) and attendance (40% to 100%).
2. **Exhibits the Separating Boundary**: It highlights the critical line where $P(\text{pass}) = 0.50$ ($z = 0$).
3. **Overlays Real Students**: It plots all 120 actual student data points directly onto the probability map, allowing immediate visual inspection of correct classifications and misclassified outliers.

```
Visual Architecture of DecisionBoundaryDisplay:
+-------------------------------------------------------------------+
| Background: 250 x 250 Grid of Evaluated Probabilities (RdYlBu_r)  |
| - Low Probability Zone (< 50%): Red / Warm tones (Failing)        |
| - Transition Zone (~ 50%):      Yellow / Neutral                  |
| - High Probability Zone (> 50%): Blue / Cool tones (Passing)      |
+-------------------------------------------------------------------+
                                 ^
                                 | Superimposed
+-------------------------------------------------------------------+
| Foreground: ax.scatter(hours, attendance, c=y, edgecolor="black")  |
| - Actual Failed Students (0): Highlighted dots                    |
| - Actual Passed Students (1): Highlighted dots                    |
+-------------------------------------------------------------------+
```

### The Mechanics of `DecisionBoundaryDisplay`
Scikit-learn's `DecisionBoundaryDisplay.from_estimator` automates the generation of dense prediction grids:
- **`model`**: The fitted `LogisticRegression` estimator.
- **`X`**: The 2D DataFrame containing `hours_studied` and `attendance_percent`. The display automatically determines axis limits from $X$'s minimums and maximums.
- **`response_method="predict_proba"`**: Evaluates continuous probabilities ($0.0$ to $1.0$) rather than discrete labels.
- **`grid_resolution=250`**: Evaluates $250 \times 250 = 62,500$ points across the coordinate space, producing an ultra-smooth visual gradient.
- **`cmap="RdYlBu_r"`**: The reversed Red-Yellow-Blue colormap maps low values to red, middle values to yellow, and high values to deep blue.
- **`alpha=0.35`**: Renders the background at 35% opacity so that data points plotted on top remain distinct and readable.

## Relevant Code (from main.py, lines 72-99)
```python
# ---- Decision boundary --------------------------------------------
fig, ax = plt.subplots(figsize=(7.5, 5.5))
DecisionBoundaryDisplay.from_estimator(
    model,
    X,
    response_method="predict_proba",
    grid_resolution=250,
    cmap="RdYlBu_r",
    alpha=0.35,
    ax=ax,
)
scatter = ax.scatter(
    X["hours_studied"],
    X["attendance_percent"],
    c=y,
    cmap="RdYlBu_r",
    edgecolor="black",
    linewidth=0.5,
    s=55,
)
handles, _ = scatter.legend_elements()
ax.legend(handles, ["failed", "passed"], title="actual result", loc="lower right")
ax.set_xlabel("Hours studied")
ax.set_ylabel("Attendance (%)")
ax.set_title("The model learns a boundary between pass and fail")
fig.tight_layout()
fig.savefig(OUT / "decision_boundary.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```

## Code Explanation and Technical Walkthrough
- **Lines 73-82**: Prepares the figure and generates the smooth continuous probability background using `DecisionBoundaryDisplay`.
- **Lines 83-91**: Draws scatter points for all 120 students. `c=y` colors each dot by their true academic result ($0$ for fail, $1$ for pass). `edgecolor="black"` and `linewidth=0.5` add crisp circular borders.
- **Lines 92-93**: Uses `scatter.legend_elements()` to automatically build legend markers matching the scatter colors.
- **Lines 94-96**: Configures descriptive axis labels and the overarching title: *"The model learns a boundary between pass and fail"*.
- **Lines 97-99**: Calls `tight_layout()`, saves the image at 150 DPI resolution, and safely closes the figure handle.

## Worked Example
**Task:** Inspect `outputs/decision_boundary.png` and identify students near the decision threshold.

**Observations:**
1. In the upper-right corner ($> 6$ hours, $> 80\%$ attendance), the background is deep solid blue, and all student dots are blue. Every single student in this region passed.
2. In the lower-left corner ($< 3$ hours, $< 60\%$ attendance), the background is red/orange, and student dots are red/yellow. These students failed.
3. Near the center ($3.5$ to $4.5$ hours, $60\%$ to $75\%$ attendance), the background shifts through yellow. Here, a few red dots (failed students) sit close to blue dots (passing students). This is the transition zone where probability sits between 40% and 60%, showing where classification mistakes are most likely to occur.

## Step-by-Step Student Instructions
1. In terminal, run `python main.py`.
2. Verify that `outputs/decision_boundary.png` has been created:
   `ls -lh outputs/decision_boundary.png`
3. Open the file in an image viewer or desktop environment.
4. Verify the dimensions and visual elements:
   - Horizontal axis labeled `"Hours studied"` (spanning ~1 to 10).
   - Vertical axis labeled `"Attendance (%)"` (spanning ~40 to 100).
   - Legend in the lower right labeled `"actual result"`.
   - Smooth diagonal transition dividing the red/yellow region from the blue region.

## Expected Output or Observable Behaviour
The image displays a clean, high-resolution graphic. The diagonal separating boundary demonstrates that study hours and attendance jointly determine the probability of passing.

## Practical Exercises
**Exercise 1.1:** Why does `DecisionBoundaryDisplay` use `response_method="predict_proba"` instead of `response_method="predict"`?
**Exercise 1.2:** If `grid_resolution=10` was used instead of `250`, what visual defect would appear in the decision boundary plot?
**Exercise 1.3:** What does the parameter `alpha=0.35` accomplish?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Omitting `ax=ax` | `from_estimator` creates its own standalone figure, breaking subsequent customizations on `ax` | Always pass `ax=ax` to bind the display to your figure |
| Forgetting `bbox_inches="tight"` | Title or axis labels can get clipped off at the image margins when saving | Always specify `bbox_inches="tight"` in `savefig()` |
| Misinterpreting scatter dot colors vs background colors | The background reflects *model predictions*; the dots reflect *actual student reality* | Use discrepancies (e.g. red dot in blue zone) to spot classifier errors |

## Best Practices and Security Considerations
- **Vector-Ready Raster DPI**: 150 DPI represents the ideal sweet spot for technical reports: sharp enough for presentation slides while keeping file sizes lightweight (< 150 KB).
- **Accessible Colormaps**: Colormaps like `RdYlBu_r` or `viridis` provide clear perceptual ordering from low to high intensity.

## Summary
Visualizing decision boundaries transforms abstract mathematical weights into an intuitive 2D map. In `main.py`, `DecisionBoundaryDisplay.from_estimator` creates a smooth 62,500-point probability surface, overlaid with actual student records to clearly reveal the boundary separating pass and fail outcomes.

## Knowledge-check Questions
1. What scikit-learn class is used to render the 2D decision boundary?
2. What colormap is specified in `main.py` for the probability surface?
3. What is the grid resolution used to compute the decision surface?
4. What do the individual scatter points represent on the plot?
5. Why is `alpha=0.35` applied to the background display?

## References
- Scikit-learn Decision Boundary Display: https://scikit-learn.org/stable/modules/generated/sklearn.inspection.DecisionBoundaryDisplay.html
- Matplotlib `scatter` Documentation: https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.scatter.html
- `main.py` lines 72-99
