# Module 6 Exercises: Visualizations, Thresholds & Extensions

## Exercise 6.1: Visualizing Decision Boundary Contours (15 min)
**Objective:** Customize and analyze the 2D decision boundary plot.
**Problem Statement:** Re-create the decision boundary visualization from `main.py` and inspect how probability contours radiate away from the 50% boundary.

**Requirements:**
1. Generate the decision boundary plot using `DecisionBoundaryDisplay.from_estimator`.
2. Overlay scatter points for actual students color-coded by true pass/fail status.
3. Locate the 50% boundary line where the display transitions through yellow.
4. Identify at least one borderline student near the boundary.

**Constraints:** Follow matplotlib and scikit-learn specifications in `main.py`.
**Expected Behaviour:** High-resolution plot showing diagonal separation between pass and fail zones.

**Acceptance Criteria:**
- [ ] Decision boundary cleanly generated.
- [ ] Scatter points overlayed with correct colors.
- [ ] Correct identification of transition zone.

---

## Exercise 6.2: Threshold Sensitivity Sweep (15 min)
**Objective:** Systematically sweep cutoffs from 0.30 to 0.90 and measure impact on False Positives and False Negatives.
**Problem Statement:** In `main.py`, cutoffs 0.50 and 0.70 are compared. Extend this analysis to evaluate cutoffs 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, and 0.90.

**Requirements:**
1. Compute predictions across cutoffs 0.30 to 0.90 in increments of 0.10.
2. For each cutoff, compute TN, FP, FN, TP, and overall accuracy.
3. Record the cutoff where False Positives drop to zero.
4. Record the cutoff where False Negatives begin to increase.

**Constraints:** Use the 30-sample test set.
**Expected Behaviour:** Tabular sweep showing FP drops to 0 at cutoff 0.70, while FN remains 1 until cutoff 0.90.

**Acceptance Criteria:**
- [ ] Complete threshold sweep table generated.
- [ ] FP=0 identified at cutoff 0.70.
- [ ] Peak accuracy identified as 96.7% at cutoffs 0.70 and 0.80.

---

## Exercise 6.3: Auditing Pipeline Artifacts (10 min)
**Objective:** Verify disk artifacts created by running `main.py`.
**Problem Statement:** Execute `main.py` and write an automated verification script to confirm that all required output files exist and contain expected statistical values.

**Requirements:**
1. Run `python main.py`.
2. Verify existence of `outputs/decision_boundary.png`, `outputs/confusion_matrix.png`, and `outputs/metrics.txt`.
3. Parse `outputs/metrics.txt` and confirm that line 1 contains `accuracy at 0.5 cutoff: 0.8667`.
4. Confirm that benchmark probabilities match 0.9645, 0.4440, and 0.9967.

**Constraints:** Use Python standard library `pathlib`.
**Expected Behaviour:** Automated test confirming that all three artifacts exist and pass verification.

**Acceptance Criteria:**
- [ ] All 3 files present on disk.
- [ ] Accuracy string verified.
- [ ] Persona probabilities verified.

---

## Exercise 6.4: Pipeline Standardization & Cross-Validation (15 min)
**Objective:** Implement a scaled pipeline with 5-fold stratified cross-validation.
**Problem Statement:** Build a production-grade scikit-learn `Pipeline` that scales features using `StandardScaler` and fits `LogisticRegression`.

**Requirements:**
1. Create a pipeline using `make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000))`.
2. Evaluate the pipeline using `StratifiedKFold(n_splits=5, shuffle=True, random_state=42)`.
3. Compute the accuracy scores across all 5 folds.
4. Report the mean accuracy and standard deviation.

**Constraints:** Use scikit-learn's `cross_val_score`.
**Expected Behaviour:** Printout showing 5 fold scores averaging ~87.5% with std dev ~2.6%.

**Acceptance Criteria:**
- [ ] Pipeline properly assembled with scaler and estimator.
- [ ] Stratified 5-fold cross-validation executed.
- [ ] Mean accuracy reported as ~87.5%.
