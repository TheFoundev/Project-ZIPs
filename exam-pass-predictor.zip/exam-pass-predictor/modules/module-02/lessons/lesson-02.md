# Lesson 02: The Binary Target Column (`passed`) & Class Balance Analysis

**Lesson ID:** lesson-02
**Module:** module-02
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Isolate the binary target variable `passed` as a 1D pandas Series
- Calculate the frequency counts and percentage distribution of passes vs fails
- Identify the 77.5% pass to 22.5% fail class distribution in `student_results.csv`
- Explain the concept of class imbalance and its implications for classifier evaluation
- Distinguish between balanced datasets and real-world skewed academic distributions

## Prerequisites
- Familiarity with Lesson 01 (dataset loading)
- Basic understanding of percentages and frequency tables

## Concept Explanation

### The Binary Target Variable
In `main.py`, the target variable $y$ is isolated on line 31:
```python
y = df["passed"]
```
Notice the syntax: single square brackets `df["passed"]` extract a single column as a one-dimensional pandas **Series** of length 120. In scikit-learn, target vectors are expected to be 1D arrays or Series.

The `passed` column contains binary integers:
- `0`: The student failed the examination.
- `1`: The student passed the examination.

### Calculating Class Distributions
To understand the nature of the target variable, we run `df["passed"].value_counts()`:

```python
counts = df["passed"].value_counts()
percentages = df["passed"].value_counts(normalize=True) * 100
```

Executing this on the 120 student records yields:
- **Class 1 (Passed)**: 93 students $	o$ **77.5%**
- **Class 0 (Failed)**: 27 students $	o$ **22.5%**
- **Total**: 120 students $	o$ **100.0%**

```
Class Balance Visualization:
Passed (1): [=============================================] 93 students (77.5%)
Failed (0): [=============] 27 students (22.5%)
```

### The Concept of Class Imbalance
In an ideally balanced dataset, each class represents exactly 50% of the observations (e.g., 60 passes and 60 fails). However, educational datasets rarely conform to a 50/50 split. In most academic courses, the majority of students who enroll and attend lectures manage to pass, while a smaller subset underperforms and fails.

A 77.5% / 22.5% split represents **moderate class imbalance**:
1. **Majority Class**: Passing students ($y = 1$).
2. **Minority Class**: Failing students ($y = 0$).

### Why Class Imbalance Matters for Machine Learning
Understanding class imbalance is vital for evaluating machine learning models:
- **The Majority Class Baseline**: If a naive dummy model simply guessed "PASS" for every single student without even looking at their study hours or attendance, that useless model would achieve:
  $$\text{Accuracy} = \frac{93}{120} = 77.5\%$$
- Consequently, an accuracy score of 77.5% is the **baseline floor**! Any trained machine learning classifier must perform significantly better than 77.5% to prove that it has learned meaningful predictive patterns.
- In our project, the trained logistic regression model achieves **86.7% accuracy**, decisively beating the 77.5% baseline and correctly detecting minority failing students.

## Relevant Code (from main.py, lines 30-31)
```python
X = df[["hours_studied", "attendance_percent"]]
y = df["passed"]
```

## Code Explanation and Technical Walkthrough
- **Line 30**: Selects the input features using double brackets `df[["hours_studied", "attendance_percent"]]`. This preserves the 2D DataFrame shape `(120, 2)` required for the feature matrix $X$.
- **Line 31**: Selects the target label using single brackets `df["passed"]`. This creates a 1D Series of shape `(120,)` representing $y$.

## Worked Example
**Task:** Calculate the baseline accuracy of a trivial majority classifier on the test set of 30 students.
**Solution:**
1. In the stratified test set of 30 students, exactly 77.5% are passing students:
   $$30 \times 0.775 = 23 \text{ passing students}$$
   $$30 \times 0.225 = 7 \text{ failing students}$$
2. If a dummy algorithm predicts "1" (pass) for all 30 test students:
   - Correct predictions: 23
   - Incorrect predictions: 7
   - Baseline Accuracy: $\frac{23}{30} = 76.67\%$ (rounds to 76.7%).
3. The logistic regression model correctly classifies 26 out of 30 students:
   $$\text{Model Accuracy} = \frac{26}{30} = 86.67\% \quad (86.7\%)$$
4. The model improves over the baseline by 10 percentage points and correctly detects 4 out of the 7 failing students!

## Step-by-Step Student Instructions
1. Open interactive Python in your terminal: `python3`.
2. Load the data:
   ```python
   import pandas as pd
   df = pd.read_csv("data/student_results.csv")
   ```
3. Compute the raw count of passes and fails:
   ```python
   print(df["passed"].value_counts())
   ```
4. Compute the normalized percentages:
   ```python
   print(df["passed"].value_counts(normalize=True))
   ```
5. Confirm that Class 1 is 0.775 (77.5%) and Class 0 is 0.225 (22.5%).

## Expected Output or Observable Behaviour
Interactive console output:
```text
passed
1    93
0    27
Name: count, dtype: int64

passed
1    0.775
0    0.225
Name: proportion, dtype: float64
```
This confirms that 93 students passed and 27 failed out of 120 observations.

## Practical Exercises
**Exercise 2.1:** What is the exact ratio of passing students to failing students in `student_results.csv`?
**Exercise 2.2:** Why is overall accuracy alone an incomplete metric when evaluating classifiers trained on imbalanced datasets?
**Exercise 2.3:** If a medical dataset had 99 healthy patients and 1 patient with cancer, what accuracy would a dummy model achieve by always predicting "Healthy"? Why would that model be dangerous?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Using double brackets for $y$ (`df[["passed"]]`) | Double brackets return a 2D DataFrame `(120, 1)`, triggering scikit-learn `DataConversionWarning` | Use single brackets `df["passed"]` to return a 1D Series `(120,)` |
| Assuming 50% pass and 50% fail | Ignores the empirical 77.5% / 22.5% distribution in the data | Always check `value_counts()` before training classifiers |
| Celebrating 78% accuracy on this dataset | 78% is essentially no better than guessing the majority class | Aim for models that surpass baseline accuracy and detect minority fails |

## Best Practices and Security Considerations
- **Baseline Awareness**: Always calculate the majority class percentage before evaluating machine learning accuracy.
- **Metric Selection**: In imbalanced classification problems, supplement accuracy with confusion matrices, precision, recall, and F1-scores.
- **Fairness & Bias**: In educational analytics, verify whether the majority class distribution disproportionately impacts specific demographic subgroups.

## Summary
The target variable `passed` records binary exam outcomes across 120 students. Analysis reveals that 93 students (77.5%) passed while 27 students (22.5%) failed. This moderate class imbalance establishes a baseline accuracy of 77.5%, proving that any effective predictive model must surpass this benchmark while accurately flagging at-risk failing students.

## Knowledge-check Questions
1. How many students in the dataset passed their examination?
2. How many students in the dataset failed their examination?
3. What percentage of the dataset represents passing students?
4. What would the accuracy of a naive classifier be if it predicted 'Pass' for every student?
5. Why does `main.py` extract $y$ using single brackets `df["passed"]` rather than double brackets?

## References
- Scikit-learn Guide on Imbalanced Data: https://scikit-learn.org/stable/modules/classification_threshold.html
- Pandas Series `value_counts` API: https://pandas.pydata.org/docs/reference/api/pandas.Series.value_counts.html
- `main.py` lines 30-31
