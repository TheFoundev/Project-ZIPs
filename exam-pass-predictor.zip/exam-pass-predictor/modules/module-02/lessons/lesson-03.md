# Lesson 03: Feature Distributions: Hours Studied & Attendance Percentage

**Lesson ID:** lesson-03
**Module:** module-02
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Extract and analyze descriptive summary statistics for `hours_studied` and `attendance_percent`
- Identify minimum, maximum, mean, median, and standard deviation for both features
- Explain the physical scale difference between hours (1.2 to 9.9) and attendance percentages (41% to 100%)
- Examine the correlation between study features and examination success
- Construct the two-dimensional feature matrix $X$ using double-bracket DataFrame indexing

## Prerequisites
- Familiarity with basic statistics: mean, standard deviation, quartiles, and range
- Understanding of Lesson 01 and Lesson 02

## Concept Explanation

### Descriptive Statistics of Input Features
The Exam Pass Predictor relies on two explanatory numerical features:
1. `hours_studied`: Continuous measurement of revision hours dedicated to exam preparation.
2. `attendance_percent`: Continuous percentage representing classroom presence throughout the academic term.

Calling `df[["hours_studied", "attendance_percent"]].describe()` provides summary statistics across all 120 students:

```
Summary Statistics Table:
+-------------------+-----------------+--------------------+
| Statistic         |  hours_studied  | attendance_percent |
+-------------------+-----------------+--------------------+
| Count             |      120.0      |       120.0        |
| Mean              |      5.55       |       70.29        |
| Std Deviation     |      2.59       |       17.85        |
| Min               |      1.20       |       41.00        |
| 25% (1st Quartile)|      3.53       |       55.75        |
| 50% (Median)      |      5.35       |       68.50        |
| 75% (3rd Quartile)|      7.70       |       87.25        |
| Max               |      9.90       |      100.00        |
+-------------------+-----------------+--------------------+
```

### Key Statistical Insights
1. **Study Hours Distribution**:
   - The minimum study duration is **1.2 hours**, representing an unprepared student.
   - The maximum study duration is **9.9 hours**, representing an intensively prepared student.
   - The average (mean) study time is **5.55 hours** (median 5.35 hours), indicating that student study hours are approximately normally distributed around 5.5 hours.
2. **Attendance Percentage Distribution**:
   - The lowest attendance recorded is **41.0%**, representing chronic absenteeism.
   - The highest attendance recorded is **100.0%**, representing perfect attendance.
   - The average attendance is **70.29%** (median 68.50%), showing a typical college attendance pattern.

### The Scale Disparity Between Features
Notice the difference in scale between our two features:
- `hours_studied` ranges from **1.2 to 9.9** (a span of roughly 8.7 units).
- `attendance_percent` ranges from **41.0 to 100.0** (a span of 59.0 units).

Because attendance numbers are roughly an order of magnitude larger than study hours, the raw numerical coefficients learned by logistic regression will reflect this scale difference:
- In `main.py`, the model learns an hours weight of **0.95** and an attendance weight of **0.03**.
- A 1-hour increase in study time has a much larger impact per unit than a 1% increase in attendance.

### Feature Separation with Double Brackets
In `main.py`, feature matrix extraction is executed as:
```python
X = df[["hours_studied", "attendance_percent"]]
```
Scikit-learn requires feature matrices to possess a two-dimensional shape: `(n_samples, n_features)`. By passing a Python list of column names `["hours_studied", "attendance_percent"]` inside the DataFrame square brackets, pandas returns a 2D DataFrame of shape `(120, 2)`.

## Relevant Code (from main.py, line 30)
```python
X = df[["hours_studied", "attendance_percent"]]
```

## Code Explanation and Technical Walkthrough
- `df[...]`: Outer square brackets indicate pandas column selection.
- `["hours_studied", "attendance_percent"]`: Inner square brackets define a Python list containing the names of the two features.
- The resulting object `X` is a `pandas.DataFrame` containing 120 rows and 2 columns.
- `X.shape` evaluates to `(120, 2)`.

## Worked Example
**Task:** Compare the average study hours and attendance for students who passed versus students who failed.

**Code:**
```python
import pandas as pd
df = pd.read_csv("data/student_results.csv")
grouped = df.groupby("passed")[["hours_studied", "attendance_percent"]].mean()
print(grouped)
```
**Output:**
```text
        hours_studied  attendance_percent
passed                                   
0            2.677778           55.703704
1            6.386022           74.526882
```
**Interpretation:**
- Students who **failed** studied an average of only **2.68 hours** and attended only **55.7%** of classes.
- Students who **passed** studied an average of **6.39 hours** and attended **74.5%** of classes.
- This dramatic contrast confirms that both features possess strong discriminatory power to separate passes from fails!

## Step-by-Step Student Instructions
1. Open interactive Python: `python3`.
2. Load the dataset into `df`.
3. Generate descriptive statistics:
   ```python
   print(df.describe())
   ```
4. Verify the minimum and maximum study hours (`1.2` and `9.9`).
5. Verify the minimum and maximum attendance (`41.0` and `100.0`).
6. Inspect the shape of $X$:
   ```python
   X = df[["hours_studied", "attendance_percent"]]
   print(f"X shape: {X.shape}")
   print(f"X type: {type(X)}")
   ```
7. Confirm that `X.shape == (120, 2)`.

## Expected Output or Observable Behaviour
Console outputs confirm the 2D DataFrame structure:
```text
X shape: (120, 2)
X type: <class 'pandas.core.frame.DataFrame'>
```
The two input features are properly isolated into a 2D matrix ready for train-test splitting.

## Practical Exercises
**Exercise 3.1:** What is the median value of `hours_studied` across the 120 students?
**Exercise 3.2:** Why does a 1% increase in attendance have a smaller weight in the model than a 1-hour increase in study time?
**Exercise 3.3:** If you used single brackets `X = df["hours_studied"]`, what would `X.shape` be, and how would scikit-learn respond?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Passing a 1D Series as $X$ | Scikit-learn estimators expect 2D inputs of shape `(n_samples, n_features)`; a 1D Series raises `ValueError: Expected 2D array, got 1D array instead` | Always use double brackets `df[["feature1", "feature2"]]` |
| Misspelling column names | Typos like `"hour_studied"` raise `KeyError` | Inspect `df.columns` to ensure exact column spelling |
| Ignoring scale differences | When features have vastly different scales, unregularized weights reflect units rather than intrinsic importance | Understand how feature magnitude influences regression coefficients |

## Best Practices and Security Considerations
- **Exploratory Data Analysis (EDA)**: Always compute summary statistics (`mean`, `min`, `max`, `std`) before training models to spot potential outliers or data corruption.
- **Double Bracket Discipline**: Keep the rule in mind: Single brackets `df['col']` produce a 1D Series for target $y$; double brackets `df[['col1', 'col2']]` produce a 2D DataFrame for feature matrix $X$.
- **Boundary Verification**: Ensure feature ranges make physical sense (e.g., attendance cannot exceed 100%, hours studied cannot be negative).

## Summary
The Exam Pass Predictor utilizes two input features: `hours_studied` (ranging from 1.2 to 9.9 hours, mean 5.55) and `attendance_percent` (ranging from 41% to 100%, mean 70.29%). Analysis shows that passing students average 6.39 study hours and 74.5% attendance, compared to 2.68 hours and 55.7% for failing students. Double-bracket indexing cleanly extracts the 2D feature matrix of shape `(120, 2)`.

## Knowledge-check Questions
1. What is the minimum and maximum number of hours studied in the dataset?
2. What is the average (mean) attendance percentage across all 120 students?
3. What is the average study duration for failing students versus passing students?
4. What is the dimensions (shape) of the feature matrix $X$?
5. Why does pandas return a DataFrame when double brackets are used?

## References
- Pandas `describe` Documentation: https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.describe.html
- Scikit-learn Data Representation: https://scikit-learn.org/stable/modules/generated/sklearn.utils.check_array.html
- `main.py` line 30
