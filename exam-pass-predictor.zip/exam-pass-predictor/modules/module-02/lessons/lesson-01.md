# Lesson 01: Tabular Data Ingestion with Pandas and Pathlib

**Lesson ID:** lesson-01
**Module:** module-02
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Use `pandas.read_csv()` combined with `pathlib.Path` to load academic records
- Inspect the schema, dimensions, and memory usage of the loaded DataFrame
- Verify that `student_results.csv` contains exactly 120 student rows and 3 columns
- Distinguish between DataFrame structures and Series structures in pandas
- Detect and verify the absence of missing values (`null` or `NaN`) in raw data

## Prerequisites
- Familiarity with CSV file formats (comma-separated values)
- Basic Python knowledge of importing third-party libraries

## Concept Explanation

### Locating and Ingesting Educational Data
Data in real-world educational research typically originates from school student information systems (SIS) or learning management systems (LMS) exported as tabular CSV files. In our project, student study metrics are recorded in `student_results.csv` within the `data/` folder.

To ingest this data cleanly across operating systems (Linux, macOS, Windows), `main.py` combines `pathlib.Path` with `pandas.read_csv`:

```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
df = pd.read_csv(DATA / "student_results.csv")
```

Using `pathlib.Path(__file__).resolve().parent` anchors all path lookups directly to the folder housing `main.py`. This avoids fragile relative path bugs where scripts fail if executed from parent or subdirectories.

### DataFrame Inspection and Dimensions
Once loaded into memory as a pandas DataFrame (`df`), the table exhibits specific dimensions:
- `df.shape`: Returns a tuple `(120, 3)`, confirming 120 student observations across 3 distinct columns.
- `df.columns`: Returns the list of header names: `['hours_studied', 'attendance_percent', 'passed']`.
- `df.dtypes`: Verifies that `hours_studied` is a 64-bit float (`float64`), `attendance_percent` is a 64-bit float (`float64`), and `passed` is a 64-bit integer (`int64`).

```
Dataset Layout (First 4 Rows):
+----------------+--------------------+--------+
| hours_studied  | attendance_percent | passed |
+----------------+--------------------+--------+
|      9.5       |        98.0        |   1    |
|      4.2       |        63.0        |   1    |
|      8.1       |        62.0        |   1    |
|      6.3       |        81.0        |   1    |
+----------------+--------------------+--------+
```

### Data Cleanliness and Integrity Checks
Before any machine learning model is trained, verifying data integrity is an indispensable engineering step. Missing values (`NaN` or `None`) will cause scikit-learn estimators to raise runtime exceptions during `fit()`. Executing `df.isna().sum()` confirms that all 120 rows contain complete, non-null numerical values.

## Relevant Code (from main.py, lines 22-23, 29)
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"

def main() -> None:
    df = pd.read_csv(DATA / "student_results.csv")
```

## Code Explanation and Technical Walkthrough
- **Line 22**: `Path(__file__)` references the current script path. Calling `.resolve()` evaluates any symbolic links, and `.parent` extracts the absolute containing directory path.
- **Line 23**: The `/` operator in `pathlib` concatenates directory names safely, creating the path `DATA` pointing to the `data/` subdirectory.
- **Line 29**: `pd.read_csv(DATA / "student_results.csv")` parses the comma-delimited text file and builds an in-memory 2D DataFrame.

## Worked Example
**Task:** Write a Python verification snippet to confirm that `student_results.csv` contains no nulls, has the expected 120 rows, and correctly identifies column data types.

**Solution:**
```python
from pathlib import Path
import pandas as pd

data_path = Path("data/student_results.csv")
df = pd.read_csv(data_path)

print(f"Shape: {df.shape}")
print(f"Missing values:\n{df.isnull().sum()}")
print(f"Data types:\n{df.dtypes}")
```
**Output:**
```text
Shape: (120, 3)
Missing values:
hours_studied         0
attendance_percent    0
passed                0
dtype: int64
Data types:
hours_studied         float64
attendance_percent    float64
passed                  int64
dtype: object
```
This confirms that the dataset is clean, complete, and ready for modeling.

## Step-by-Step Student Instructions
1. Open a terminal and navigate to the project directory.
2. Launch Python interactive mode: `python3`.
3. Ingest the dataset manually:
   ```python
   from pathlib import Path
   import pandas as pd
   df = pd.read_csv(Path("data/student_results.csv"))
   ```
4. Verify the shape: `print(df.shape)`. Confirm that the tuple `(120, 3)` is printed.
5. Print the first 5 records: `print(df.head())`.
6. Inspect summary memory usage: `df.info()`.
7. Exit interactive Python: `exit()`.

## Expected Output or Observable Behaviour
When executing `df.head()` in interactive Python:
```text
   hours_studied  attendance_percent  passed
0            9.5                98.0       1
1            4.2                63.0       1
2            8.1                62.0       1
3            6.3                81.0       1
4            3.6                56.0       1
```
All records display non-empty numerical values across all three columns.

## Practical Exercises
**Exercise 1.1:** How many total data values (cells) exist in `student_results.csv` across all rows and columns?
**Exercise 1.2:** If a new student record had a missing value for `attendance_percent`, what would `df.isna().sum()` report, and what would scikit-learn do if you attempted to train a model?
**Exercise 1.3:** Explain the difference between `Path(__file__).resolve().parent` and `os.getcwd()`.

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Hardcoding string paths like `"C:\\data\\student.csv"` | Fails immediately on Linux or macOS systems | Use `pathlib.Path` for cross-platform portability |
| Assuming the file has an index column | Adding `index_col=0` would turn `hours_studied` into the row index rather than a feature | Ingest with standard `pd.read_csv(path)` |
| Omitting data validation before modeling | Corrupted or missing values crash model training silently or with confusing errors | Always inspect `df.shape` and `df.isnull().sum()` first |

## Best Practices and Security Considerations
- **Immutable Raw Data**: Treat raw dataset files as read-only assets; never overwrite `data/student_results.csv` with transformed data.
- **Cross-Platform Path Hygiene**: Always use `pathlib.Path` with the `/` operator rather than manual string concatenation with forward slashes or backslashes.
- **Safe Memory Limits**: For beginner projects, 120 rows consume trivial memory (< 5 KB), but in production, check dataset file sizes before loading entire tables into RAM.

## Summary
The Exam Pass Predictor begins with robust data ingestion. Using `pathlib.Path` combined with `pandas.read_csv()`, the pipeline loads 120 student academic observations across 3 columns (`hours_studied`, `attendance_percent`, `passed`). Inspecting dimensions and null counts confirms clean data ready for classification.

## Knowledge-check Questions
1. How many rows and columns are present in `student_results.csv`?
2. What are the names of the three columns in the dataset?
3. What data type does pandas assign to `hours_studied` and `attendance_percent`?
4. What data type does pandas assign to `passed`?
5. Why is `pathlib.Path(__file__).resolve().parent` preferred over raw relative strings?

## References
- Pandas `read_csv` Documentation: https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html
- Python `pathlib` Guide: https://docs.python.org/3/library/pathlib.html
- `main.py` lines 22-29
