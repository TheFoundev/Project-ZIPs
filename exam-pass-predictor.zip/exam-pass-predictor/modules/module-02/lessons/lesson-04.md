# Lesson 04: Stratified Train-Test Splitting with Scikit-Learn

**Lesson ID:** lesson-04
**Module:** module-02
**Duration:** 15-20 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why datasets must be split into training and testing partitions
- Implement `sklearn.model_selection.train_test_split` with `test_size=0.25`
- Explain the role of `random_state=42` in ensuring experimental reproducibility
- Define **stratified sampling** and explain why `stratify=y` is mandatory for imbalanced classification
- Verify the exact sample counts and class balance in $X_{\text{train}}$, $X_{\text{test}}$, $y_{\text{train}}$, and $y_{\text{test}}$

## Prerequisites
- Familiarity with Lesson 02 (class balance) and Lesson 03 (feature extraction)
- Understanding of pseudorandom seeds in computing

## Concept Explanation

### The Necessity of Train/Test Splitting
In machine learning, our primary objective is to build a model that **generalizes** to new, unseen student data. If we were to train our model on all 120 students and evaluate its accuracy on those exact same 120 students, the evaluation would be dishonest—like giving a student the final exam questions with answers the night before and then claiming they are a genius because they scored 100%.

To obtain an honest, unbiased assessment of model performance:
1. **Training Set ($75\%$)**: Used by the algorithm during `model.fit()` to learn optimal feature weights and intercept.
2. **Testing Set ($25\%$)**: Held back in complete isolation during training. Once the model is locked, we feed $X_{\text{test}}$ to the model and compare its predictions against true $y_{\text{test}}$.

```
Dataset Splitting (120 Total Samples):
+-------------------------------------------------------------+
|               All Student Data (120 Rows)                   |
+-------------------------------------------------------------+
                              |
            train_test_split(test_size=0.25)
                              |
       +----------------------+----------------------+
       |                                             |
       v                                             v
+-------------------------------+             +---------------+
| Training Set (90 Rows, 75%)   |             | Test Set      |
| Used for model.fit()          |             | (30 Rows, 25%)|
+-------------------------------+             | Unseen eval   |
                                              +---------------+
```

### The Peril of Random Splitting: Why Stratification is Essential
In Lesson 02, we discovered that our dataset is moderately imbalanced: 93 passes (77.5%) and only 27 fails (22.5%).

If we perform a standard random train/test split without stratification, the random number generator might accidentally distribute the 27 minority failing students unevenly. For instance:
- Training set might get 25 failing students.
- Test set might get only 2 failing students out of 30!

If the test set contains only 2 failing students, our test metrics (precision, recall, confusion matrix) become statistically unstable and unreliable.

### The Solution: `stratify=y`
By adding the argument `stratify=y` to `train_test_split`, scikit-learn enforces **stratified sampling**. It calculates the proportion of passes and fails in the original dataset and guarantees that both the training set and the testing set mirror that exact proportion:
- **Original Dataset (120 rows)**: 77.5% pass, 22.5% fail
- **Training Set (90 rows)**: Exactly 70 passes (77.8%) and 20 fails (22.2%)
- **Test Set (30 rows)**: Exactly 23 passes (76.7%) and 7 fails (23.3%)

Stratification guarantees that the test set has a sufficient, representative sample of minority failing students to evaluate real-world error rates.

### The Role of `random_state=42`
Because data splitting involves shuffling, different runs would produce slightly different train/test splits if left unseeded. Setting `random_state=42` fixes the seed of the pseudorandom number generator, guaranteeing that every student, researcher, and automated grader obtains the exact same 90 training students and 30 test students every single time.

## Relevant Code (from main.py, lines 20, 33-35)
```python
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)
```

## Code Explanation and Technical Walkthrough
- **Line 20**: Imports `train_test_split` from `sklearn.model_selection`.
- **Line 33**: Calls the function, passing feature matrix `X` and target vector `y`.
- **`test_size=0.25`**: Designates 25% of data (30 samples) for testing and the remaining 75% (90 samples) for training.
- **`random_state=42`**: Provides deterministic reproducibility.
- **`stratify=y`**: Enforces balanced class proportions across both subsets.
- The function returns four objects unpacked in exact order: `X_train`, `X_test`, `y_train`, `y_test`.

## Worked Example
**Task:** Verify the exact dimensions and class counts of the four partitioned subsets produced by `train_test_split`.

**Code:**
```python
import pandas as pd
from sklearn.model_selection import train_test_split

df = pd.read_csv("data/student_results.csv")
X = df[["hours_studied", "attendance_percent"]]
y = df["passed"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

print(f"X_train shape: {X_train.shape}, y_train shape: {y_train.shape}")
print(f"X_test shape:  {X_test.shape},  y_test shape:  {y_test.shape}")
print(f"y_train counts:\n{y_train.value_counts()}")
print(f"y_test counts:\n{y_test.value_counts()}")
```
**Output:**
```text
X_train shape: (90, 2), y_train shape: (90,)
X_test shape:  (30, 2),  y_test shape:  (30,)
y_train counts:
passed
1    70
0    20
Name: count, dtype: int64
y_test counts:
passed
1    23
0     7
Name: count, dtype: int64
```
Both subsets maintain the ~77.5% / 22.5% ratio perfectly!

## Step-by-Step Student Instructions
1. Open interactive Python in terminal: `python3`.
2. Load data, build $X$ and $y$, and run `train_test_split` with `test_size=0.25`, `random_state=42`, and `stratify=y`.
3. Check the length of `X_train`: `len(X_train)` $	o$ confirms 90.
4. Check the length of `X_test`: `len(X_test)` $	o$ confirms 30.
5. Check `y_test.value_counts()`: confirm that exactly 23 passed and 7 failed.
6. Verify what happens if you omit `stratify=y` by running a test without it and observing random fluctuations in class counts.

## Expected Output or Observable Behaviour
Console outputs show:
- Training rows: 90 (70 pass, 20 fail)
- Testing rows: 30 (23 pass, 7 fail)
- The test set contains an ideal balance to evaluate classifier accuracy.

## Practical Exercises
**Exercise 4.1:** Why would evaluating a model only on training data lead to an overoptimistic assessment of its accuracy?
**Exercise 4.2:** In a small dataset with 20 failing students, what danger arises if an unstratified split places 18 of them in the training set and only 2 in the test set?
**Exercise 4.3:** If `test_size=0.20` had been used instead of `0.25`, how many samples would be in the training and testing sets?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Forgetting `stratify=y` | Test set can suffer from random class starvation, skewing evaluation metrics | Always specify `stratify=y` when performing classification splits |
| Unpacking variables in wrong order | e.g. `X_train, y_train, X_test, y_test = ...` swaps features and targets | Unpack in strict order: `X_train, X_test, y_train, y_test` |
| Omitting `random_state` | Results will vary on every run, breaking automated tests and reproducibility | Always set `random_state=42` (or a chosen constant integer) |

## Best Practices and Security Considerations
- **Strict Data Segregation**: Never allow any test set data to touch model fitting, feature scaling, or imputation. Test data must remain strictly unseen.
- **Reproducibility Guarantee**: In educational and scientific research, always publish the `random_state` parameter to enable independent replication.
- **Stratification as Standard**: Make `stratify=y` the default practice for all classification workflows.

## Summary
To measure generalizability, `main.py` splits the 120 student records into a 90-sample training set (75%) and a 30-sample testing set (25%). By applying `stratify=y`, the pipeline guarantees that the training set (70 pass, 20 fail) and testing set (23 pass, 7 fail) strictly preserve the dataset's natural 77.5% pass / 22.5% fail class distribution.

## Knowledge-check Questions
1. How many students are placed in the training set and how many in the test set?
2. What is the purpose of setting `random_state=42` in `train_test_split`?
3. What does `stratify=y` ensure during data partitioning?
4. How many passing students and failing students are present in the test set?
5. What is the danger of evaluating a machine learning model on the same data it was trained on?

## References
- Scikit-learn `train_test_split` Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html
- Cross-validation and Data Partitioning Principles: https://scikit-learn.org/stable/modules/cross_validation.html
- `main.py` lines 33-35
