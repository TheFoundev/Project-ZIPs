# Module 2 Exercises: Data Exploration & Stratified Partitioning

## Exercise 2.1: Dataset Inspection and Null Verification (15 min)
**Objective:** Load and validate the integrity of `student_results.csv` using pandas.
**Problem Statement:** Before feeding student records to a machine learning classifier, you must verify that the dataset contains no corrupted rows or missing values.

**Requirements:**
1. Ingest `student_results.csv` into a pandas DataFrame.
2. Output the DataFrame shape, column names, and data types.
3. Check for null or NaN values in each column using `isna().sum()`.
4. Verify that total rows equal 120 and columns equal 3.

**Constraints:** Use pandas and pathlib.
**Expected Behaviour:** Printout verifying zero missing values across all columns and confirming shape `(120, 3)`.

**Acceptance Criteria:**
- [ ] Confirms 120 rows and 3 columns.
- [ ] Confirms 0 missing values across `hours_studied`, `attendance_percent`, and `passed`.
- [ ] Correctly identifies data types as float64, float64, and int64.

---

## Exercise 2.2: Class Imbalance Computation (10 min)
**Objective:** Quantify the majority and minority class frequencies in the target column.
**Problem Statement:** Educational datasets often feature more passing students than failing students. You need to calculate exact frequencies and percentages to establish the baseline accuracy floor.

**Requirements:**
1. Extract `y = df["passed"]` as a 1D Series.
2. Compute the value counts for Class 1 (Pass) and Class 0 (Fail).
3. Compute the normalized proportions as percentages.
4. State the baseline accuracy of a naive majority guesser.

**Constraints:** Calculate directly from the dataset.
**Expected Behaviour:** Structured output showing 93 passes (77.5%) and 27 fails (22.5%).

**Acceptance Criteria:**
- [ ] Class 1 count verified as 93.
- [ ] Class 0 count verified as 27.
- [ ] Baseline accuracy correctly identified as 77.5%.

---

## Exercise 2.3: Feature Contrast Analysis (15 min)
**Objective:** Compare feature averages across passing and failing students.
**Problem Statement:** To confirm that `hours_studied` and `attendance_percent` are viable predictors, compute group means for passing and failing students.

**Requirements:**
1. Group the DataFrame by `passed` using `df.groupby("passed")`.
2. Compute the mean of `hours_studied` and `attendance_percent` for both groups.
3. Compare the mean values and write a 2-3 sentence summary explaining whether study hours and attendance appear correlated with exam success.

**Constraints:** Use pandas groupby aggregation.
**Expected Behaviour:** Clear table showing failing students average 2.68 hours / 55.7% attendance, while passing students average 6.39 hours / 74.5% attendance.

**Acceptance Criteria:**
- [ ] Correct mean values calculated for failing students.
- [ ] Correct mean values calculated for passing students.
- [ ] Logical deduction explaining why these features are discriminative.

---

## Exercise 2.4: Implementing Stratified Splitting (15 min)
**Objective:** Execute and verify a reproducible stratified train-test split.
**Problem Statement:** Implement the exact data splitting logic from `main.py` and prove that stratification preserved class balance.

**Requirements:**
1. Split $X$ and $y$ using `train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)`.
2. Output the shapes of `X_train`, `X_test`, `y_train`, and `y_test`.
3. Verify that `y_train` contains 70 passes and 20 fails.
4. Verify that `y_test` contains 23 passes and 7 fails.

**Constraints:** Must match parameters in `main.py`.
**Expected Behaviour:** Subset shapes `(90, 2)`, `(30, 2)`, `(90,)`, `(30,)` and verified class counts.

**Acceptance Criteria:**
- [ ] `X_train` has shape `(90, 2)`.
- [ ] `X_test` has shape `(30, 2)`.
- [ ] Class balance in test set confirmed as 23 pass / 7 fail.
