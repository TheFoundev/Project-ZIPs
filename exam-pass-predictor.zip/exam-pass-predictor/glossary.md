# Glossary

| Term | Definition |
|---|---|
| Binary Classification | A supervised machine learning task where the target output belongs to one of exactly two distinct categories (e.g., 0 = fail, 1 = pass). |
| Logistic Regression | A classification algorithm that models the probability of a binary outcome by fitting a linear combination of input features passed through a sigmoid function. |
| Sigmoid Function | An S-shaped mathematical activation curve defined as $\sigma(z) = \frac{1}{1 + e^{-z}}$ that maps any real number to a probability value strictly between 0 and 1. |
| Log-Odds (Logit) | The natural logarithm of the odds ratio, calculated as $\ln(p / (1 - p)) = w_1 x_1 + w_2 x_2 + b$, representing the underlying linear model in logistic regression. |
| Feature ($X$) | An independent input variable used by the model to infer predictions (e.g., `hours_studied` and `attendance_percent`). |
| Target ($y$) | The dependent outcome variable to predict, represented here as binary labels in the `passed` column (0 = fail, 1 = pass). |
| `predict()` | A scikit-learn method that outputs discrete class labels (0 or 1) by applying a fixed 50% probability threshold. |
| `predict_proba()` | A scikit-learn method that outputs the estimated class probabilities for each sample as an array $[P(y=0), P(y=1)]$. |
| Decision Boundary | The geometric line or hyperplane in feature space where the predicted probability is exactly 0.5, partitioning predictions into pass and fail regions. |
| Decision Cutoff (Threshold) | The numerical probability value used to separate positive from negative classifications (e.g., classifying as pass if probability $\ge 0.70$). |
| Stratified Split | A data partitioning technique in `train_test_split` that preserves the exact proportion of each target class across training and test subsets. |
| Confusion Matrix | A $2 \times 2$ table tabulating true positives, false positives, true negatives, and false negatives to evaluate classifier decisions. |
| True Positive (TP) | A student who actually passed and whom the model correctly predicted would pass (22 students in test set). |
| True Negative (TN) | A student who actually failed and whom the model correctly predicted would fail (4 students in test set). |
| False Positive (FP) | Type I error: A student who actually failed but whom the model incorrectly predicted would pass (3 students in test set at 0.5 cutoff). |
| False Negative (FN) | Type II error: A student who actually passed but whom the model incorrectly predicted would fail (1 student in test set). |
| Precision | The fraction of positive predictions that were correct: $\text{Precision} = \frac{\text{TP}}{\text{TP} + \text{FP}}$ (0.88 for pass class). |
| Recall (Sensitivity) | The fraction of actual positive cases that were correctly retrieved: $\text{Recall} = \frac{\text{TP}}{\text{TP} + \text{FN}}$ (0.96 for pass class). |
| F1-Score | The harmonic mean of precision and recall: $\text{F1} = 2 \times \frac{\text{Precision} \times \text{Recall}}{\text{Precision} + \text{Recall}}$ (0.92 for pass class). |
| Accuracy | The overall percentage of correct predictions: $\text{Accuracy} = \frac{\text{TP} + \text{TN}}{\text{Total Samples}}$ (86.7% at 0.5 cutoff). |
