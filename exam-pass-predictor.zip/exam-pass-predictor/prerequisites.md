# Prerequisites

## Skills Required
- **Python Fundamentals**: Understanding variables, data types (integers, floats, booleans, strings), lists, dictionaries, conditionals, loops, and functions.
- **Data Manipulation with pandas**: Basic loading of CSV files with `pd.read_csv`, DataFrame indexing, column selection (single vs double brackets), and summary statistics (`describe()`, `value_counts()`).
- **Basic Mathematical Concepts**: Familiarity with linear equations ($y = mx + b$), fractions, percentages, and the intuitive concept of probability (values bounded between 0% and 100%).
- **Command Line Basics**: Navigating directories with `cd`, viewing directory contents with `ls` or `dir`, and executing Python scripts using `python main.py`.

## Tools and Environment
- **Python 3.8+**: Installed locally or accessible via a hosted Jupyter/Colab environment.
- **Python Package Manager (`pip`)**: Used to install required third-party libraries.
- **Code Editor**: VS Code, PyCharm, Jupyter Notebook, or any text editor with syntax highlighting.

## Required Libraries
- `pandas`: For loading student CSV records and managing tabular feature matrices.
- `numpy`: For numerical computations and array operations.
- `matplotlib`: For generating decision boundary contours and confusion matrix figures.
- `scikit-learn`: For `LogisticRegression`, `train_test_split`, `accuracy_score`, `classification_report`, `confusion_matrix`, `ConfusionMatrixDisplay`, and `DecisionBoundaryDisplay`.

## Knowledge to Review Before Starting
- **Continuous vs Discrete Variables**: Understanding why exam scores (0-100 continuous points) require linear regression, whereas pass/fail results (0 or 1 binary categories) require logistic regression.
- **Basic Probability Notation**: Grasping that $P(\text{pass}) = 0.85$ means an 85% probability of passing, and the complementary event is $P(\text{fail}) = 1 - 0.85 = 0.15$ (15%).
