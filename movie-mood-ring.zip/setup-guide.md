# Setup Guide: The Movie Review Mood Ring

Follow this comprehensive guide to set up your local development environment, verify dataset integrity, execute the Movie Review Mood Ring pipeline, and inspect the resulting visual and text artifacts.

---

## Step 1: Navigate to the Project Directory

Open your command-line terminal and navigate to the project directory:

```bash
cd "beginner-projects-main/AI-ML Beginners/projects/16_movie_mood_ring"
```

Verify that the expected project layout is present:
```text
16_movie_mood_ring/
├── data/
│   └── movie_reviews.csv
├── main.py
└── README.md
```

---

## Step 2: Environment Configuration

It is recommended to use a clean virtual environment using Python 3.9 or higher:

```bash
# Create a virtual environment named .venv
python3 -m venv .venv

# Activate the virtual environment (Linux/macOS)
source .venv/bin/activate

# Or on Windows:
# .venv\Scripts\activate
```

---

## Step 3: Install Required Dependencies

Install the four core data science libraries:

```bash
pip install pandas numpy scikit-learn matplotlib
```

Verify your installed versions:
```bash
python3 -c "import pandas, numpy, sklearn, matplotlib; print('Pandas:', pandas.__version__, '| Scikit-Learn:', sklearn.__version__)"
```

---

## Step 4: Verify Dataset Integrity

Run a brief Python one-liner to verify that `data/movie_reviews.csv` contains the expected 90 records with 3 balanced classes:

```bash
python3 -c "
import pandas as pd
df = pd.read_csv('data/movie_reviews.csv')
print(f'Rows: {len(df)}, Columns: {list(df.columns)}')
print(df['mood'].value_counts())
"
```

Expected output:
```text
Rows: 90, Columns: ['review', 'mood']
mood
negative    30
positive    30
mixed       30
Name: count, dtype: int64
```

---

## Step 5: Execute the Pipeline

Run the main pipeline script:

```bash
python3 main.py
```

Observe the console output confirming:
- Dataset shape: `(90, 2)`
- Split sizes: 67 training reviews, 23 test reviews
- Vocabulary size: 254 features
- Model test accuracy: `100.0%`
- Predictions and confidence scores on novel reviews

---

## Step 6: Verify Generated Output Artifacts

Confirm that the `outputs/` directory was created and populated with the following 3 artifacts:

```bash
ls -la outputs/
```

- `outputs/confusion_matrix.png`: Heatmap graphic showing zero off-diagonal misclassifications.
- `outputs/mood_meter.png`: 3-bar vertical chart displaying prediction confidence for review 0 (89% mixed).
- `outputs/predictions.txt`: Plaintext report containing accuracy, metrics, top words, and novel review predictions.

---

## Step 7: Troubleshooting Common Issues

### Issue 1: GUI / Display Crash on Headless Server
- **Error**: `_tkinter.TclError: no display name and no $DISPLAY environment variable`
- **Resolution**: Ensure `matplotlib.use("Agg")` is executed **before** `import matplotlib.pyplot as plt`.

### Issue 2: FileNotFoundError for `movie_reviews.csv`
- **Error**: `FileNotFoundError: [Errno 2] No such file or directory: 'data/movie_reviews.csv'`
- **Resolution**: Use `pathlib.Path(__file__).resolve().parent` to resolve paths relative to the script file rather than current working directory.

### Issue 3: Incompatible scikit-learn Version
- **Error**: `AttributeError: 'CountVectorizer' object has no attribute 'get_feature_names_out'`
- **Resolution**: Upgrade scikit-learn (`pip install --upgrade scikit-learn`). Old versions (< 1.0) used `get_feature_names()`.
