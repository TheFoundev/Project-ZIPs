# Module 2 Exercises: Data Exploration & Pipeline Environment Setup

## Exercise 2.1: Dataset Schema Verification & Hygiene Audit (10 min)
**Objective:** Write a Python verification script that audits `data/movie_reviews.csv` for data completeness, column integrity, and schema compliance.

**Problem Statement:** Before feeding external datasets into machine learning pipelines, production teams run automated data validation gates. Implement a Python script using pandas and pathlib that audits `movie_reviews.csv`.

**Requirements:**
1. Dynamically resolve the path to `data/movie_reviews.csv` using `pathlib.Path`.
2. Load the CSV into a DataFrame and assert that it contains exactly 90 rows and 2 columns.
3. Verify that the columns are named exactly `review` and `mood`.
4. Check that there are zero null or NaN values in either column.
5. Print the exact counts of unique values in the `mood` column.

**Constraints:** Do not use hardcoded relative path strings; use `Path(__file__).resolve().parent`.

**Expected Behaviour:** A standalone Python script that executes the verification and prints confirmation messages or raises descriptive AssertionErrors.

**Acceptance Criteria:**
- [ ] Correctly asserts DataFrame dimensions are `(90, 2)`.
- [ ] Confirms columns are `['review', 'mood']`.
- [ ] Verifies total null count is 0.
- [ ] Prints 30 reviews for each of `positive`, `negative`, and `mixed`.

**Hints:**
- Use `assert df.shape == (90, 2), "Unexpected shape"` for defensive checks.
- Review Lesson 01 on dataset anatomy.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes

---

## Exercise 2.2: Stratified vs Unstratified Sampling Simulation (15 min)
**Objective:** Empirically demonstrate why stratified sampling is necessary for balanced multi-class datasets.

**Problem Statement:** A developer on your team argues: *"With 90 rows, random train_test_split without stratification is fast and good enough."* Write an empirical test comparing 10 random splits against 10 stratified splits to demonstrate the risk of sampling skew.

**Requirements:**
1. Perform 10 iterations of `train_test_split(df["review"], df["mood"], test_size=0.25, random_state=i)` without `stratify`.
2. Record the class counts in `y_test` across iterations and identify the minimum and maximum representation for any class.
3. Perform 10 iterations of `train_test_split(df["review"], df["mood"], test_size=0.25, random_state=i, stratify=df["mood"])`.
4. Compare the variance in test class representation between both methods.

**Constraints:** Use pandas and scikit-learn's `train_test_split`.

**Expected Behaviour:** A tabular summary or printed report showing variance under unstratified splits versus zero variance under stratified splits.

**Acceptance Criteria:**
- [ ] Demonstrates that unstratified splits cause test class counts to fluctuate (e.g., from 4 to 12).
- [ ] Confirms that stratified splits lock test class counts stably at 8 negative, 8 positive, and 7 mixed across all random seeds.
- [ ] Explains why preserving class proportions in testing prevents biased evaluation.

**Hints:**
- Review Lesson 02 on stratified splitting and sampling variance.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 2.3: Synthesizing Film Review Lexicons (15 min)
**Objective:** Categorize film critique expressions into positive delight, negative fatigue, and contrastive pivots.

**Problem Statement:** Design a domain-specific vocabulary reference table for entertainment sentiment analysis. From `data/movie_reviews.csv`, extract 15 distinct phrases (5 positive, 5 negative, 5 mixed).

**Requirements:**
1. Extract 5 verbatim phrases representing positive sentiment, identifying whether they praise acting, soundtrack, or writing.
2. Extract 5 verbatim phrases representing negative sentiment, identifying whether they criticize pacing, dialogue, or plot.
3. Extract 5 verbatim phrases representing mixed sentiment, identifying the contrastive conjunction used to bridge opposing clauses.
4. Construct a comprehensive Markdown table comparing these 15 phrases.

**Constraints:** Cite only authentic text from `data/movie_reviews.csv`.

**Expected Behaviour:** A structured comparative Markdown table with columns: `Sentiment Category`, `Review Excerpt`, `Filmmaking Dimension`, and `Key Stylistic Marker`.

**Acceptance Criteria:**
- [ ] Contains 15 accurate excerpts directly cited from the dataset.
- [ ] Mixed category excerpts feature contrastive transitions ("but", "though", "however").
- [ ] Correctly links phrases to filmmaking dimensions (acting, pacing, humor, score).

**Hints:**
- Look at phrases like "soundtrack I want to replay", "kept checking the time", "story dragged. I liked the ending, though".

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 2.4: Headless Plotting & Directory Resilience Harness (20 min)
**Objective:** Construct a bulletproof headless visualization execution harness using `pathlib` and `matplotlib.use("Agg")`.

**Problem Statement:** Build a reusable utility script that creates an output directory safely, renders a test 3-bar diagnostic chart representing class distribution, and saves it to disk without opening any GUI window or throwing headless errors.

**Requirements:**
1. Configure `matplotlib.use("Agg")` strictly before importing `pyplot`.
2. Resolve base, data, and output paths dynamically using `pathlib.Path(__file__).resolve().parent`.
3. Create `outputs/` safely using `mkdir(exist_ok=True)`.
4. Plot a bar chart showing the count of reviews in each mood class, coloring each bar with the project palette (`#27ae60`, `#c0392b`, `#e67e22`).
5. Save the figure to `outputs/class_distribution.png` at 150 DPI and close the figure cleanly with `plt.close()`.

**Constraints:** The script must run without error from any arbitrary working directory in the terminal.

**Expected Behaviour:** A robust Python script that executes cleanly on headless servers and produces a publication-quality chart.

**Acceptance Criteria:**
- [ ] Backend is explicitly configured as "Agg" prior to pyplot import.
- [ ] Paths are completely decoupled from terminal working directories.
- [ ] Figure closes cleanly without memory leakage.
- [ ] Correct hex colors are applied to positive, negative, and mixed bars.

**Hints:**
- Review Lesson 04 on path management and headless plotting configuration.

**Difficulty:** Advanced  
**Estimated Completion Time:** 20 minutes
