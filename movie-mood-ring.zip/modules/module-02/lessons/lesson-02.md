# Lesson 02: Balanced Classes & Stratified Splitting for 3-Class Data

**Lesson ID:** lesson-02
**Module:** module-02
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define class balance and explain why an equal distribution of classes is advantageous in supervised learning.
- Explain the risks of class imbalance and how it distorts standard evaluation metrics like accuracy.
- Describe the mechanism of stratified sampling and why `stratify=df["mood"]` is critical during train/test splits.
- Calculate the exact train and test split sample counts for the 90-sample movie review dataset under a 75/25 partition.

## 2. Prerequisites
- Completion of Lesson 01.
- Understanding of training sets versus testing sets in machine learning.

## 3. Real-World Context & Business Motivation
In many real-world machine learning applications, datasets suffer from severe **class imbalance**. For instance, in credit card fraud detection, 99.9% of transactions are legitimate and only 0.1% are fraudulent. In such cases, a useless dummy model that simply predicts "legitimate" for every transaction achieves 99.9% accuracy while catching zero fraud.

Fortunately, in `data/movie_reviews.csv`, we have an intentionally balanced educational dataset: exactly 30 reviews for each of the three moods (`positive`, `negative`, and `mixed`). However, when partitioning this data into a training set (to teach the model) and a test set (to evaluate generalization), a random split could accidentally draw 20 positive reviews into the test set and only 3 into the training set. Such an unrepresentative split would cripple the model's ability to learn positive vocabulary. To prevent this, we must employ **stratified splitting**.

## 4. Concept Explanation
### Class Balance in movie_reviews.csv
Executing `df["mood"].value_counts()` yields:
```text
mood
negative    30
positive    30
mixed       30
Name: count, dtype: int64
```
Each class accounts for exactly $rac{30}{90} = 33.3\%$ of the dataset.

### The Mechanics of Stratified Splitting
A standard random split shuffles all 90 rows into an urn and draws 25% for testing without regard to class identity. Under small sample sizes, random sampling introduces substantial sampling variance.

**Stratified sampling**, in contrast, divides the dataset into discrete strata (subgroups) based on the target label:
1. Stratum 1: 30 Negative reviews
2. Stratum 2: 30 Positive reviews
3. Stratum 3: 30 Mixed reviews

The algorithm then independently samples 75% for training and 25% for testing *within each individual stratum*. This guarantees that both the training partition and the testing partition mirror the exact population proportions of the original dataset.

### Partition Calculations for main.py
In `main.py`, the split is configured as:
- Total rows: $N = 90$
- Test size: $25\%$ ($0.25 	imes 90 = 22.5 \implies 23$ test samples)
- Training size: $75\%$ ($90 - 23 = 67$ training samples)

Because 30 does not divide evenly into 25%, scikit-learn allocates test samples across classes as follows:
- Negative: 8 test samples, 22 train samples
- Positive: 8 test samples, 22 train samples
- Mixed: 7 test samples, 23 train samples
Total test samples: $8 + 8 + 7 = 23$. Total train samples: $22 + 22 + 23 = 67$.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 32-34 execute the stratified split:
```python
    X_train, X_test, y_train, y_test = train_test_split(
        df["review"], df["mood"], test_size=0.25, random_state=42, stratify=df["mood"]
    )
```
- `df["review"]`: The feature Series containing the text strings.
- `df["mood"]`: The target Series containing the class labels.
- `test_size=0.25`: Allocates 25% of the data to testing.
- `random_state=42`: Seeds the pseudorandom number generator, ensuring identical splits across all runs.
- `stratify=df["mood"]`: Enforces proportional class representation in both splits.

## 6. Worked Example
Let us verify the exact distribution of classes across `y_train` and `y_test` by running a verification snippet:
```python
import pandas as pd
from sklearn.model_selection import train_test_split

df = pd.read_csv("data/movie_reviews.csv")
X_train, X_test, y_train, y_test = train_test_split(
    df["review"], df["mood"], test_size=0.25, random_state=42, stratify=df["mood"]
)

print("--- Training Set Distribution (Total: 67) ---")
print(y_train.value_counts())

print("
--- Testing Set Distribution (Total: 23) ---")
print(y_test.value_counts())
```
**Console Output:**
```text
--- Training Set Distribution (Total: 67) ---
mood
mixed       23
negative    22
positive    22
Name: count, dtype: int64

--- Testing Set Distribution (Total: 23) ---
mood
negative    8
positive    8
mixed       7
Name: count, dtype: int64
```
Notice how each class represents approximately $rac{1}{3}$ of the training set and $rac{1}{3}$ of the testing set.

## 7. Step-by-Step Student Instructions
1. Open terminal and run Python.
2. Import `pandas` and `train_test_split`:
   ```python
   import pandas as pd
   from sklearn.model_selection import train_test_split
   df = pd.read_csv("data/movie_reviews.csv")
   ```
3. Run `train_test_split` without `stratify`:
   ```python
   _, _, _, y_test_unstratified = train_test_split(
       df["review"], df["mood"], test_size=0.25, random_state=10
   )
   print("Unstratified test counts:
", y_test_unstratified.value_counts())
   ```
4. Observe that under random split without stratification, the class counts skew (e.g., 10 negative, 8 positive, 5 mixed).
5. Now run with `stratify=df["mood"]` and note the balanced preservation of classes.

## 8. Expected Output or Observable Behaviour
When observing the classification report output during `main.py` execution:
```text
              precision    recall  f1-score   support

       mixed       1.00      1.00      1.00         7
    negative       1.00      1.00      1.00         8
    positive       1.00      1.00      1.00         8

    accuracy                           1.00        23
```
Notice the `support` column: `mixed: 7`, `negative: 8`, `positive: 8`. Total support: 23. This matches the exact stratified test partition.

## 9. Practical Exercises (with Success Criteria)
- **Task 2.1:** If a dataset has 120 samples with 40 positive, 40 negative, and 40 mixed reviews, calculate the exact number of training and test samples per class under a stratified 80/20 train/test split.
- **Task 2.2:** Explain why omitting `random_state=42` makes it impossible to reproduce identical evaluation metrics across multiple experiment runs.
- *Success Criteria:* Calculations yield exactly 32 train and 8 test samples per class; explanations clearly connect pseudorandom seeds to scientific reproducibility.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Omitting `stratify=df["mood"]` on small multi-class datasets | Risk of drawing a test set with very few examples of a specific class | Always stratify classification splits unless class distributions are massive ($>10^6$). |
| Passing `stratify=df["review"]` instead of `df["mood"]` | Causes an error or stratifies on unique text strings instead of target labels | Stratification must be based on the categorical target variable $y$. |
| Changing `random_state` and wondering why metrics shift slightly | Different random seeds draw different sample partitions | Fix `random_state` during development to benchmark model changes consistently. |

## 11. Best Practices and Code Quality
- Always inspect class counts in both training and test partitions before initiating model fitting.
- Use explicit keyword arguments (`test_size=0.25`, `random_state=42`, `stratify=...`) rather than positional parameters.
- Verify that the sum of training and test lengths equals the total original DataFrame length.

## 12. Security, Ethics, and Fair AI Considerations
In real-world applications (such as credit lending or medical diagnosis), demographic subgroups can be severely underrepresented. Unstratified splits can completely erase minority subgroups from test sets, blinding evaluators to catastrophic model failure on vulnerable populations. Stratification is an ethical imperative for fair evaluation.

## 13. Summary and Key Takeaways
The `data/movie_reviews.csv` dataset contains an equal balance of 30 reviews per mood class. Using `train_test_split` with `stratify=df["mood"]` and `test_size=0.25` partitions the 90 rows into 67 training samples and 23 test samples while preserving balanced class representation.

## 14. Knowledge Check Questions
1. How many reviews per mood class exist in `data/movie_reviews.csv`?
2. What does the `stratify` parameter in `train_test_split` accomplish?
3. How many total samples are allocated to the training set and testing set in `main.py`?
4. What is the test set `support` for mixed, negative, and positive classes respectively?

## 15. References and Further Reading
- Scikit-learn Documentation: `train_test_split` (https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html).
- Kuhn, M., & Johnson, K. (2013). *Applied Predictive Modeling.* (Chapter 3: Data Pre-processing and Splitting).
