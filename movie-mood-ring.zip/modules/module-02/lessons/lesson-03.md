# Lesson 03: The Linguistic Anatomy of Film Reviews

**Lesson ID:** lesson-03
**Module:** module-02
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Identify the vocabulary, adjectives, and idioms that characterize positive, negative, and mixed film reviews.
- Explain the role of contrastive conjunctions ("but", "however", "though") in shifting sentence polarity.
- Understand how negation words ("not", "never") modify the sentiment of adjacent adjectives.
- Analyze how repeated linguistic structures form statistical clues that Naive Bayes classifiers exploit.

## 2. Prerequisites
- Completion of Lessons 01 and 02.
- Basic familiarity with English grammar (nouns, adjectives, verbs, conjunctions).

## 3. Real-World Context & Business Motivation
Natural language processing does not read text the way a human literary critic does. It does not visualize the actors on a screen or feel visceral emotions. Instead, statistical NLP algorithms operate on lexical distributions: the frequency with which particular words, pairs of words, and syntactic structures occur within labeled categories.

To understand why our machine learning model succeeds or fails on movie reviews, we must examine the **linguistic anatomy** of film critiques. Why does the phrase *"a soundtrack I want to replay"* immediately signal a positive mood? Why does *"I kept checking the time"* signal a negative mood? And how does a single word like *"but"* bridge the gap between admiration and frustration? Unpacking these linguistic structures prepares us for the feature extraction mechanics of `CountVectorizer`.

## 4. Concept Explanation
### Linguistic Profile 1: Positive Reviews (Delight & Warmth)
Positive reviews in `data/movie_reviews.csv` are characterized by adjectives expressing aesthetic satisfaction, emotional connection, and enthusiasm:
- Key vocabulary: *"chemistry"*, *"delightful"*, *"great"*, *"joyful"*, *"moving"*, *"soundtrack"*, *"warmth"*, *"wonderful"*.
- Common idioms: *"jokes landed every time"*, *"kept me smiling"*, *"soundtrack I want to replay"*, *"warm characters"*.
- Structural trait: Unidirectional praise; every clause reinforces viewer enjoyment.

### Linguistic Profile 2: Negative Reviews (Boredom & Frustration)
Negative reviews reflect viewer fatigue, narrative incoherence, and poor pacing:
- Key vocabulary: *"awful"*, *"boring"*, *"confusing"*, *"disappointing"*, *"dull"*, *"flat"*, *"mess"*, *"predictable"*, *"wooden"*.
- Common idioms: *"kept checking the time"*, *"made no sense"*, *"pacing was awful"*, *"wasted a talented cast"*.
- Structural trait: Decisive condemnation; verbs indicate cognitive disconnection (*"lost me"*, *"hated"*).

### Linguistic Profile 3: Mixed Reviews (Nuance & Contrast)
Mixed reviews are the most linguistically intriguing category in the dataset. They are defined by **adversative balance**:
- Key vocabulary: *"acting"*, *"beautiful"*, *"comedy"*, *"dragged"*, *"ending"*, *"holes"*, *"plot"*, *"score"*, *"stunning"*.
- Structural trait: The presence of contrasting clauses joined by coordinating or subordinating conjunctions:
  - *"The comedy worked, **but** the emotional moments felt forced."*
  - *"The visuals were stunning, **but** the story dragged. I liked the ending, **though**."*
  - *"Great acting and a beautiful score, **but** the plot had several holes."*
  - *"I am glad I watched it, **but** I would not rush to see it again."*

Notice that in mixed reviews, positive words (*"great"*, *"beautiful"*, *"stunning"*) and negative words (*"holes"*, *"dragged"*, *"forced"*) appear within the same sentence, held in tension by *"but"*.

### The Power of Negation
Consider the word *"recommend"*:
- Positive: *"I recommend it."*
- Negative: *"I would **not** recommend it."*

If an NLP model only counts individual words (unigrams), both sentences contain the word *"recommend"*, potentially misleading the classifier. Capturing word pairs (bigrams like *"not recommend"*) is vital for handling linguistic negation.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 56-60 expose the top predictive vocabulary discovered by the model:
```python
    vectorizer = model.named_steps["vectorizer"]
    classifier = model.named_steps["classifier"]
    feature_names = vectorizer.get_feature_names_out()
    classes = list(classifier.classes_)
    print("Top words per mood:")
    for index, mood in enumerate(classes):
        top = np.argsort(classifier.feature_log_prob_[index])[-8:][::-1]
        print(f"  {mood:8s}: {', '.join(feature_names[top])}")
```
When executed, the top learned features reflect our linguistic analysis perfectly:
- `mixed`: `score`, `score plot`, `plot holes`, `plot`, `great acting`, `holes`, `acting`, `acting beautiful`
- `negative`: `time`, `time jokes`, `pacing`, `pacing awful`, `jokes flat`, `checking time`, `checking`, `awful`
- `positive`: `time`, `wonderful`, `great`, `movie`, `chemistry`, `jokes landed`, `cast`, `cast great`

## 6. Worked Example
Let us trace the linguistic decomposition of a real review:
*"Great acting and a beautiful score, but the plot had several holes."*

1. **Clause 1 (Praise):** *"Great acting and a beautiful score"*
   - Praise tokens: `great`, `acting`, `beautiful`, `score`
   - Polarity: Strongly Positive
2. **Conjunction (Pivot):** *"but"*
   - Signals a reversal of valence.
3. **Clause 2 (Critique):** *"the plot had several holes"*
   - Critique tokens: `plot`, `holes`
   - Polarity: Moderately Negative
4. **Aggregate Sentiment:** The two clauses counterbalance each other. The model associates the combination of `great acting` and `plot holes` with the `mixed` mood category.

## 7. Step-by-Step Student Instructions
1. Open `data/movie_reviews.csv` in your editor.
2. Read through rows 1 to 20.
3. In a text document, create three columns: `Positive Cues`, `Negative Cues`, and `Contrastive Cues`.
4. As you read, sort key adjectives and phrases into your three columns.
5. Identify any phrase where a positive adjective is inverted by a negation word (e.g., *"not recommend"*).

## 8. Expected Output or Observable Behaviour
Students will observe clear lexical separation:
```text
Positive: chemistry, delightful, moving, smiling, warm, wonderful
Negative: awful, boring, checking time, confusing, dull, flat, wooden
Mixed:    acting beautiful, comedy worked, plot holes, rushed, story dragged
```
This lexical clustering forms the statistical signal that Naive Bayes uses to achieve 100% classification accuracy on the test set.

## 9. Practical Exercises (with Success Criteria)
- **Task 3.1:** Write two synthetic reviews that describe a film's soundtrack: one purely positive, and one mixed (praising the soundtrack but criticizing the dialogue).
- **Task 3.2:** Explain why the phrase *"I kept checking the time"* conveys negative sentiment without containing traditional negative adjectives like "bad" or "awful".
- *Success Criteria:* Explanations correctly recognize that idioms and behavioral descriptions carry strong emotional sentiment in natural language.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Assuming sentiment is only carried by simple adjectives ("good", "bad") | Misses idioms, behavioral descriptions ("checking the time"), and metaphor | Natural language expresses emotion through vivid phrases and idioms. |
| Ignoring bigrams when processing negation | Treats "not recommend" the same as "recommend" | N-grams preserve negation context by binding "not" to the following word. |
| Believing that all occurrences of "but" guarantee mixed sentiment | A review could say "I had high doubts, but it was amazing!" (Positive) | "But" signals a shift; the sentiment depends on the polarities of both clauses. |

## 11. Best Practices and Code Quality
- Inspect raw text samples qualitatively to build intuition about your domain's vocabulary before tuning hyperparameters.
- Look out for domain-specific idioms (in film: "chemistry", "wooden acting", "pacing", "third act").
- Consider n-gram ranges that capture multi-word phrases.

## 12. Security, Ethics, and Fair AI Considerations
Cultural idioms vary across English-speaking regions (e.g., American vs British vs Indian English). A phrase that is complimentary in one dialect (e.g., "wicked good") might be flagged as negative by a naive keyword filter. Understanding linguistic context prevents dialectal discrimination in sentiment analysis.

## 13. Summary and Key Takeaways
Film reviews exhibit rich linguistic patterns: positive reviews emphasize warmth and chemistry, negative reviews express boredom and disappointment, and mixed reviews use contrastive conjunctions ("but", "though") to balance praise and critique. Statistical text classifiers leverage these recurring phrases to categorize reviews.

## 14. Knowledge Check Questions
1. What role do contrastive conjunctions like "but" play in mixed film reviews?
2. Why is the idiom "I kept checking the time" an effective indicator of negative sentiment?
3. How does the bigram "not recommend" change the meaning of the unigram "recommend"?
4. What are three positive idioms or phrases found in `data/movie_reviews.csv`?

## 15. References and Further Reading
- Jurafsky, D., & Martin, J. H. *Speech and Language Processing.* (Chapter 4: Naive Bayes and Sentiment Classification).
- Potts, C. (2011). *On the negativity of negation.* Proceedings of SALT 20, 636-659.
