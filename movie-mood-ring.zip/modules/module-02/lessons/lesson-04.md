# Lesson 04: Robust Path Management and Headless Plotting Configuration

**Lesson ID:** lesson-04
**Module:** module-02
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Implement portable, operating-system-agnostic filesystem path resolution using Python's standard `pathlib.Path`.
- Explain why hardcoded relative paths like `open("data/reviews.csv")` fail when scripts are executed from different working directories.
- Configure matplotlib for headless execution using `matplotlib.use("Agg")` to avoid GUI display errors in automated environments.
- Ensure automated output directories are created safely using `mkdir(exist_ok=True)`.

## 2. Prerequisites
- Completion of Lessons 01, 02, and 03.
- Basic familiarity with Python file imports and the operating system command line.

## 3. Real-World Context & Business Motivation
In professional software development and production machine learning, code does not run solely in an interactive notebook or a developer's local terminal. ML pipelines are deployed inside Docker containers, automated CI/CD testing runners (such as GitHub Actions), cloud virtual machines, and scheduled background cron jobs.

In these automated environments, two pervasive errors crash naive scripts:
1. **Working Directory Mismatches:** If a script uses `pd.read_csv("data/movie_reviews.csv")`, it only works if the terminal's current working directory is the script's root folder. If an automated runner executes the script from `/home/user` or a parent repository, Python throws `FileNotFoundError`.
2. **Headless Display Failures:** In automated servers without an attached graphical monitor, importing `matplotlib.pyplot` may cause matplotlib to attempt opening an X11 or Wayland window, crashing with `TclError: no display name and no $DISPLAY environment variable`.

In `main.py`, both issues are solved elegantly using professional software engineering standards.

## 4. Concept Explanation
### OS-Agnostic Path Anchoring with pathlib
Python 3 introduced `pathlib`, an object-oriented approach to filesystem paths that automatically handles OS-specific directory separators (`/` on Linux/macOS, `\` on Windows).

To make a script self-anchoring, `main.py` defines:
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)
```
- `__file__`: A built-in Python variable containing the path of the currently executing script.
- `.resolve()`: Resolves any symbolic links and returns an absolute path.
- `.parent`: Navigates to the directory containing `main.py`.
- `/`: The slash operator is overloaded by `Path` objects to safely join path components across Windows, Linux, and macOS.
- `OUT.mkdir(exist_ok=True)`: Creates the `outputs/` folder if it does not already exist, and does not throw an error if it already exists.

Because all file reads and writes are anchored to `BASE`, the script runs identically whether invoked from inside the folder or from the root of the server filesystem.

### Headless Plotting with Matplotlib Agg
By default, matplotlib attempts to use an interactive GUI backend (such as `TkAgg`, `QtAgg`, or `MacOSX`) so users can view plots in pop-up windows. On headless Linux servers or containerized microservices, this triggers display crashes.

To configure headless rendering, we set the backend to `"Agg"` (Anti-Grain Geometry, a high-performance raster rendering engine that renders directly to memory buffers and image files):
```python
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
```
**CRITICAL RULE:** `matplotlib.use("Agg")` must be executed **before** importing `matplotlib.pyplot`. If `pyplot` is imported first, matplotlib initializes the default display backend, rendering the subsequent configuration call ineffective or raising warnings.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 10-27 establish this robust architecture:
```python
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)
```
Notice the precise sequence:
1. Import `matplotlib`.
2. Configure `matplotlib.use("Agg")`.
3. Import `matplotlib.pyplot as plt`.
4. Define `BASE`, `DATA`, `OUT`.
5. Ensure `OUT` directory exists.

## 6. Worked Example
Let us demonstrate the vulnerability of relative paths and the robustness of `pathlib`:

**Vulnerable Approach:**
```python
# Fails if run from any other directory!
df = pd.read_csv("data/movie_reviews.csv")
plt.savefig("outputs/mood_meter.png")
```
If you run `cd .. && python 16_movie_mood_ring/main.py`, Python crashes:
```text
FileNotFoundError: [Errno 2] No such file or directory: 'data/movie_reviews.csv'
```

**Robust Approach (from main.py):**
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)

df = pd.read_csv(DATA / "movie_reviews.csv")
plt.savefig(OUT / "mood_meter.png")
```
Now, whether you invoke the script from `/home/user`, `/tmp`, or `/var/www`, it resolves `BASE` relative to `main.py`'s physical location on disk and succeeds every time.

## 7. Step-by-Step Student Instructions
1. Open terminal and navigate to your home directory (`cd ~`).
2. Run `main.py` using its full absolute path:
   ```bash
   python3 "/home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/16_movie_mood_ring/main.py"
   ```
3. Observe that even though your terminal working directory is `~`, the script runs without errors and finds `data/movie_reviews.csv`.
4. Inspect the `outputs/` folder inside the project to confirm `mood_meter.png` and `confusion_matrix.png` were successfully created.

## 8. Expected Output or Observable Behaviour
When executing `main.py` from an external directory:
```text
============================================================
THE MOVIE REVIEW MOOD RING
============================================================
Accuracy: 100.0%
...
Saved: outputs/mood_meter.png, outputs/confusion_matrix.png, outputs/predictions.txt
```
The script runs cleanly without any `FileNotFoundError` or display warnings.

## 9. Practical Exercises (with Success Criteria)
- **Task 4.1:** Write a Python script that uses `pathlib.Path` to locate and list all `.png` files in the `outputs/` directory, printing their absolute paths and file sizes in kilobytes.
- **Task 4.2:** Explain what happens if `matplotlib.pyplot` is imported before `matplotlib.use("Agg")` in a server environment that lacks a GUI display.
- *Success Criteria:* Code correctly leverages `Path.glob("*.png")` and `.stat().st_size`; explanation demonstrates clear understanding of matplotlib backend initialization.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Importing `matplotlib.pyplot` before `matplotlib.use("Agg")` | Matplotlib binds to the default display backend before the switch, risking crash | Always call `matplotlib.use("Agg")` immediately after `import matplotlib`. |
| Using string concatenation for paths (`BASE + "/data"`) | Fails on Windows due to forward/backward slash incompatibilities | Use `pathlib.Path` with the `/` operator for clean, cross-platform paths. |
| Forgetting `exist_ok=True` when creating directories | Throws `FileExistsError` on subsequent script runs when the folder exists | `mkdir(exist_ok=True)` is safe and idempotent across repeated script executions. |

## 11. Best Practices and Code Quality
- Follow PEP 8 import formatting: standard library first, third-party libraries second, local modules third.
- Use `Path.resolve()` to ensure symlinks are properly resolved to canonical absolute paths.
- Always close figures with `plt.close(fig)` after saving to prevent memory leaks during batch rendering.

## 12. Security, Ethics, and Fair AI Considerations
Allowing arbitrary user-supplied file paths in scripts can expose applications to directory traversal vulnerabilities (e.g., `../../etc/passwd`). Using anchored `pathlib.Path` structures ensures that file operations are constrained to intended application directories.

## 13. Summary and Key Takeaways
Robust production machine learning requires portable filesystem management and headless graphic rendering. By leveraging `pathlib.Path(__file__).resolve().parent` and calling `matplotlib.use("Agg")` before importing `pyplot`, `main.py` guarantees reliable execution across local machines, remote servers, and automated pipelines.

## 14. Knowledge Check Questions
1. Why does `Path(__file__).resolve().parent` provide more reliable path resolution than relative strings?
2. What happens if `matplotlib.use("Agg")` is called after `import matplotlib.pyplot as plt`?
3. What is the purpose of `exist_ok=True` in `Path.mkdir()`?
4. What does the "Agg" backend in matplotlib stand for and why is it preferred on headless servers?

## 15. References and Further Reading
- Python Documentation: `pathlib` — Object-oriented filesystem paths (https://docs.python.org/3/library/pathlib.html).
- Matplotlib Documentation: What is a backend? (https://matplotlib.org/stable/users/explain/backends.html).
