# Lesson 01: Anatomy of the Movie Reviews Dataset

**Lesson ID:** lesson-01
**Module:** module-02
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Inspect the schema, column names, and row count of `data/movie_reviews.csv` using pandas.
- Verify data hygiene, checking for missing values (`NaN`), malformed quotes, and formatting artifacts.
- Describe how raw text strings and categorical target labels are structured in tabular form.
- Contrast clean, curated educational datasets with messy production web scrapes.

## 2. Prerequisites
- Completion of Module 01.
- Basic understanding of comma-separated values (CSV) files and pandas DataFrames.

## 3. Real-World Context & Business Motivation
Every data science and machine learning project begins with data ingestion. In commercial natural language processing, data often arrives from disparate and noisy sources: user comment forms, mobile app store APIs, scraped blogs, and syndication feeds. If a model is trained on corrupted data—such as truncated sentences, misaligned CSV columns, or null rows—the resulting classifier will fail in unpredictable ways.

In the Movie Review Mood Ring project, our starting asset is `data/movie_reviews.csv`. Before writing feature extraction code or configuring machine learning estimators, an engineer must inspect the raw text data: How many reviews exist? Are the columns clearly delimited? Are special characters or quotation marks properly escaped? Validating these fundamental data properties ensures our downstream NLP pipeline operates on a stable, verified foundation.

## 4. Concept Explanation
### Schema of movie_reviews.csv
The dataset is stored in standard RFC 4180 CSV format. It features two columns:
1. `review`: A text string containing a customer or critic review of a film. Reviews range from short one-sentence impressions to multi-clause critiques.
2. `mood`: A categorical string representing the human-annotated sentiment mood. The valid values are `"positive"`, `"negative"`, and `"mixed"`.

### Handling Quotation Marks and Delimiters in Text CSVs
Because natural language sentences frequently contain commas (e.g., *"A dull, confusing film that wasted a talented cast."*), CSV files must wrap text fields in double quotes:
```csv
review,mood
"A dull, confusing film that wasted a talented cast.",negative
"The cast had great chemistry, and the jokes landed every time.",positive
```
When pandas reads this file via `pd.read_csv`, the CSV parser automatically handles the quotation escaping, treating the entire enclosed phrase as a single string and splitting strictly on the unquoted comma separating the review from the mood label.

### Dataset Dimensions and Integrity
Inspection reveals that `movie_reviews.csv` contains exactly 90 data rows plus 1 header row:
- Total rows: 90
- Total columns: 2 (`review`, `mood`)
- Missing values: 0 (no null or NaN cells in either column)
- Class balance: exactly 30 reviews per mood class

This perfect balance makes the dataset ideal for studying multi-class classification principles without the distorting effects of extreme class imbalance.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 30-34 perform dataset loading and feature-target separation:
```python
def main() -> None:
    df = pd.read_csv(DATA / "movie_reviews.csv")
    X_train, X_test, y_train, y_test = train_test_split(
        df["review"], df["mood"], test_size=0.25, random_state=42, stratify=df["mood"]
    )
```
- `pd.read_csv(DATA / "movie_reviews.csv")` reads the file into a DataFrame `df`.
- `df["review"]` accesses the feature column as a pandas Series of strings.
- `df["mood"]` accesses the ground truth label column as a pandas Series of strings.

## 6. Worked Example
Let us execute a complete data inspection script in Python to verify the dataset attributes:
```python
import pandas as pd
from pathlib import Path

DATA_PATH = Path("data/movie_reviews.csv")
df = pd.read_csv(DATA_PATH)

print("--- Dataset Dimensions ---")
print(f"Rows: {df.shape[0]}, Columns: {df.shape[1]}")

print("
--- Column Information ---")
print(df.info())

print("
--- Missing Values ---")
print(df.isnull().sum())

print("
--- First 3 Rows ---")
for idx, row in df.head(3).iterrows():
    print(f"[{row['mood'].upper()}] {row['review']}")
```
**Expected Output:**
```text
--- Dataset Dimensions ---
Rows: 90, Columns: 2

--- Column Information ---
<class 'pandas.core.frame.DataFrame'>
RangeIndex: 90 entries, 0 to 89
Data columns (total 2 columns):
 #   Column  Non-Null Count  Dtype 
---  ------  --------------  ----- 
 0   review  90 non-null     object
 1   mood    90 non-null     object
dtypes: object(2)

--- Missing Values ---
review    0
mood      0
dtype: int64

--- First 3 Rows ---
[NEGATIVE] A dull, confusing film that wasted a talented cast.
[POSITIVE] The cast had great chemistry, and the jokes landed every time.
[NEGATIVE] Boring, predictable, and far too long. I would not recommend it.
```

## 7. Step-by-Step Student Instructions
1. Open a terminal and navigate to the project directory.
2. Launch Python interactive shell (`python3`).
3. Load the dataset using pandas:
   ```python
   import pandas as pd
   df = pd.read_csv("data/movie_reviews.csv")
   ```
4. Check the shape: `df.shape`. Confirm it outputs `(90, 2)`.
5. Check for null values: `df.isnull().sum()`. Confirm both columns show `0`.
6. Print the distribution of review lengths in characters:
   ```python
   df["review"].str.len().describe()
   ```
7. Exit the interactive shell (`exit()`).

## 8. Expected Output or Observable Behaviour
When checking review character lengths:
```text
count     90.000000
mean      67.855556
std       12.435812
min       48.000000
50%       68.000000
max       98.000000
```
Notice that the reviews are concise, focused sentences ranging between 48 and 98 characters, ensuring fast vectorization and consistent token distributions.

## 9. Practical Exercises (with Success Criteria)
- **Task 1.1:** Write a Python function `inspect_dataset(path: Path) -> dict` that returns the row count, column names, and count of missing values for any CSV file.
- **Task 1.2:** Inspect the 5 longest reviews in `movie_reviews.csv` and report whether long reviews correlate with any specific mood category.
- *Success Criteria:* Code correctly identifies zero missing values and accurately reports dataset dimensions.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Hardcoding absolute file paths like `C:\Users\...` | Breaks code when executed on other developer machines or Linux servers | Use `pathlib.Path(__file__).resolve().parent` for dynamic path resolution. |
| Forgetting to quote text containing commas in raw CSVs | Splinters text across multiple nonexistent columns, corrupting the DataFrame | Always let standard CSV writers handle quoting, and verify DataFrame shape after loading. |
| Neglecting to verify null values before feeding into NLP models | Scikit-learn vectorizers throw `AttributeError` when encountering `float` or `NaN` in text columns | Always assert `df.isnull().sum().sum() == 0` during data ingestion. |

## 11. Best Practices and Code Quality
- Always inspect `.shape`, `.dtypes`, and `.isnull().sum()` immediately after loading any new tabular dataset.
- Keep raw datasets immutable in a dedicated `data/` folder; never overwrite raw data with processed outputs.
- Use explicit column indexing (`df["review"]`, `df["mood"]`) rather than ambiguous positional slicing (`df.iloc[:, 0]`).

## 12. Security, Ethics, and Fair AI Considerations
Text datasets harvested from the public web may contain personally identifiable information (PII) such as reviewer real names, email addresses, or social media handles. Responsible ML engineering requires scrubbing PII before storing or sharing datasets. In `movie_reviews.csv`, all data has been anonymized to protect user privacy.

## 13. Summary and Key Takeaways
The `data/movie_reviews.csv` dataset contains exactly 90 clean, labeled movie review records across two columns: `review` and `mood`. It has zero missing values and clear CSV quoting. Performing systematic exploratory data analysis verifies that the data is ready for machine learning feature extraction.

## 14. Knowledge Check Questions
1. How many total rows and columns are present in `data/movie_reviews.csv`?
2. What are the exact names of the two columns in the dataset?
3. How does pandas handle commas within review text when parsing CSV files?
4. What error does scikit-learn throw if a text column contains unhandled `NaN` values during vectorization?

## 15. References and Further Reading
- Pandas Documentation: `read_csv` (https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html).
- RFC 4180: Common Format and MIME Type for Comma-Separated Values (CSV) Files.
