# Lesson 01: Bayes' Theorem Applied to Multi-Class Text Classification

**Lesson ID:** lesson-01
**Module:** module-04
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- State Bayes' Theorem in mathematical notation and explain its conceptual role in machine learning.
- Identify the four mathematical terms in Bayes' formula: prior probability, likelihood, evidence, and posterior probability.
- Explain how Bayes' Theorem inverts conditional probabilities to infer hidden sentiment moods from observable words.
- Extend Bayes' formula from binary classification to a 3-class target space ($\{\text{mixed}, \text{negative}, \text{positive}\}$).

## 2. Prerequisites
- Completion of Module 03.
- Familiarity with basic probability notation ($P(A)$, $P(A \mid B)$) and fractions.

## 3. Real-World Context & Business Motivation
When human moviegoers read a review that says *"The soundtrack was magnificent and the chemistry was electrifying"*, our minds perform an intuitive deduction: given that someone used those specific glowing words, how likely is it that they loved the movie?

In probabilistic machine learning, this inductive reasoning is formalized by **Bayes' Theorem**, formulated by the 18th-century mathematician Thomas Bayes. In natural language processing, we cannot directly measure the author's internal emotional mood; we can only observe the text they wrote. Bayes' Theorem provides the exact mathematical bridge allowing an algorithm to reason backward: using the observable words as evidence to calculate the probability of each hidden emotional state.

## 4. Concept Explanation
### Bayes' Theorem Formulated
Bayes' Theorem calculates the conditional probability of an event given prior knowledge of conditions related to the event:
$$P(C \mid \mathbf{x}) = \frac{P(\mathbf{x} \mid C) \cdot P(C)}{P(\mathbf{x})}$$

In the context of the Movie Review Mood Ring:
- **$C$ (Class / Hypothesis):** One of the three possible mood categories: $C \in \{\text{mixed}, \text{negative}, \text{positive}\}$.
- **$\mathbf{x}$ (Evidence / Features):** The set of word tokens present in the review (e.g., $\mathbf{x} = \{\text{"acting"}, \text{"beautiful"}, \text{"plot holes"}\}$).

### Deconstructing the Four Components
1. **Posterior Probability ($P(C \mid \mathbf{x})$):** The updated probability that the review belongs to mood $C$ *after* reading all the words $\mathbf{x}$. This is what the model solves for.
2. **Prior Probability ($P(C)$):** The baseline probability of mood $C$ *before* reading any text. In a balanced dataset where each class has 30 out of 90 reviews, the prior is simply $P(C) = \frac{1}{3} \approx 0.333$.
3. **Likelihood ($P(\mathbf{x} \mid C)$):** The probability that an author writing in mood $C$ would choose this specific combination of words.
4. **Marginal Evidence ($P(\mathbf{x})$):** The total probability of observing word set $\mathbf{x}$ across all possible moods:
   $$P(\mathbf{x}) = \sum_{k \in \{\text{mixed}, \text{neg}, \text{pos}\}} P(\mathbf{x} \mid C_k) \cdot P(C_k)$$
   Because $P(\mathbf{x})$ is identical for all three candidate classes during a single prediction, it acts merely as a normalizing constant ensuring that probabilities sum to 1.0.

### The Decision Rule: Maximum A Posteriori (MAP)
To make a hard discrete prediction $\hat{y}$, the classifier selects the class that maximizes the posterior:
$$\hat{y} = \arg\max_{C} P(C \mid \mathbf{x}) = \arg\max_{C} P(\mathbf{x} \mid C) \cdot P(C)$$

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 36-44 instantiate and train this Bayesian architecture:
```python
    model = Pipeline(
        [
            ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
            ("classifier", MultinomialNB()),
        ]
    )
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
```
When `model.fit(X_train, y_train)` executes:
- It counts the occurrences of each class in `y_train` to establish priors $P(C)$.
- It counts feature frequencies within each class partition to calculate likelihood tables $P(w_j \mid C)$.
- When `predict_proba` or `predict` is invoked on test reviews, it evaluates Bayes' formula across all three classes.

## 6. Worked Example
Suppose we want to classify a mini-review containing just two words: `["delightful", "chemistry"]`.
Assume the learned likelihoods and equal priors are:
- $P(\text{positive}) = 0.333$, $P(\text{"delightful", "chemistry"} \mid \text{positive}) = 0.080$
- $P(\text{negative}) = 0.333$, $P(\text{"delightful", "chemistry"} \mid \text{negative}) = 0.001$
- $P(\text{mixed}) = 0.333$, $P(\text{"delightful", "chemistry"} \mid \text{mixed}) = 0.010$

**Step 1: Compute Unnormalized Numerators ($P(\mathbf{x} \mid C) \cdot P(C)$):**
- Positive: $0.080 \times 0.333 = 0.02664$
- Negative: $0.001 \times 0.333 = 0.00033$
- Mixed: $0.010 \times 0.333 = 0.00333$

**Step 2: Compute Evidence $P(\mathbf{x})$ (Sum of numerators):**
$$P(\mathbf{x}) = 0.02664 + 0.00033 + 0.00333 = 0.03030$$

**Step 3: Normalize to Obtain Posterior Probabilities ($P(C \mid \mathbf{x})$):**
- $P(\text{positive} \mid \mathbf{x}) = \frac{0.02664}{0.03030} \approx \mathbf{87.9\%}$
- $P(\text{mixed} \mid \mathbf{x}) = \frac{0.00333}{0.03030} \approx \mathbf{11.0\%}$
- $P(\text{negative} \mid \mathbf{x}) = \frac{0.00033}{0.03030} \approx \mathbf{1.1\%}$

The model decides that the movie mood is **positive** with ~88% confidence.

## 7. Step-by-Step Student Instructions
1. Open Python interactive console.
2. Verify the class prior probabilities stored in the trained classifier:
   ```python
   import numpy as np
   from sklearn.naive_bayes import MultinomialNB
   # In main.py, model is trained on X_train, y_train
   classifier = model.named_steps["classifier"]
   print("Classes:", classifier.classes_)
   print("Class log priors:", classifier.class_log_prob_)
   print("Priors (linear):", np.exp(classifier.class_log_prob_))
   ```
3. Observe that the prior probabilities are close to $[0.343, 0.328, 0.328]$ reflecting the 23/22/22 training split.

## 8. Expected Output or Observable Behaviour
When checking class priors in the terminal:
```text
Classes: ['mixed', 'negative', 'positive']
Class log priors: [-1.06915264 -1.11354314 -1.11354314]
Priors (linear): [0.34328358 0.32835821 0.32835821]
```
The three values sum to 1.0, accurately reflecting the training distribution.

## 9. Practical Exercises (with Success Criteria)
- **Task 1.1:** Calculate the posterior probability $P(\text{negative} \mid \text{"boring"})$ given $P(\text{negative})=0.33$, $P(\text{"boring"} \mid \text{negative})=0.12$, $P(\text{positive})=0.33$, $P(\text{"boring"} \mid \text{positive})=0.005$, $P(\text{mixed})=0.33$, $P(\text{"boring"} \mid \text{mixed})=0.02$.
- **Task 1.2:** Explain why the denominator $P(\mathbf{x})$ can be omitted if we only need the hard argmax prediction $\hat{y}$, but cannot be omitted if we need the mood meter probabilities.
- *Success Criteria:* Posterior calculation yields $\approx 82.8\%$ for negative; explanation clearly distinguishes between relative ranking and normalized probability calibration.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Confusing $P(C \mid \mathbf{x})$ with $P(\mathbf{x} \mid C)$ | Swaps the condition and consequence; predicting words from mood instead of mood from words | Bayes' theorem specifically inverts $P(\mathbf{x} \mid C)$ to get $P(C \mid \mathbf{x})$. |
| Assuming priors are always 50/50 | Ignores class imbalance in real-world distributions | Priors must reflect actual historical class proportions in the training data. |
| Forgetting to normalize posteriors | Results in numbers that do not sum to 1.0, distorting probability visualizations | Always divide joint likelihoods by marginal evidence $P(\mathbf{x})$. |

## 11. Best Practices and Code Quality
- Let scikit-learn handle probability normalization via `predict_proba`.
- Store and compute probabilities in log-space to prevent floating-point underflow.
- Confirm that class priors align with the true operational environment.

## 12. Security, Ethics, and Fair AI Considerations
If class priors are skewed (e.g., 90% positive in an e-commerce platform), Bayes' theorem will require overwhelming negative textual evidence to overcome the strong positive prior. Developers must ensure priors reflect fair assumptions when evaluating critical feedback.

## 13. Summary and Key Takeaways
Bayes' Theorem provides the principled mathematical framework for text classification, updating prior beliefs with lexical evidence to compute posterior class probabilities. By evaluating likelihoods across positive, negative, and mixed categories, the model determines both the predicted mood and its associated confidence.

## 14. Knowledge Check Questions
1. Write down Bayes' Theorem for a text document $\mathbf{x}$ and class $C$.
2. What is the difference between prior probability and posterior probability?
3. What role does the denominator $P(\mathbf{x})$ play in Bayes' formula?
4. How does Bayes' Theorem enable 3-class classification?

## 15. References and Further Reading
- Bayes, T. (1763). *An Essay towards solving a Problem in the Doctrine of Chances.* Philosophical Transactions of the Royal Society.
- Hastie, T., Tibshirani, R., & Friedman, J. *The Elements of Statistical Learning.* (Chapter 6.6.3: Naive Bayes Classifier).
