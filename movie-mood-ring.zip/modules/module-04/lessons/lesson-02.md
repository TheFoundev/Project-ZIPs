# Lesson 02: The Multinomial Naive Bayes Model & Conditional Independence

**Lesson ID:** lesson-02
**Module:** module-04
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain the "naive" conditional independence assumption and its mathematical expression.
- Understand why joint word likelihoods decompose into a product of individual token probabilities.
- Explain the Multinomial distribution and why it is tailored for integer word counts in text classification.
- Explain why log-probabilities ($\log P$) are used in implementation to avoid floating-point underflow.

## 2. Prerequisites
- Completion of Lesson 01.
- Understanding of properties of logarithms ($\log(a \cdot b) = \log a + \log b$).

## 3. Real-World Context & Business Motivation
In the previous lesson, we learned that Bayes' Theorem requires computing the likelihood $P(\mathbf{x} \mid C)$, where $\mathbf{x}$ is the full combination of words in a review. But consider: if a review contains 15 words, the number of possible word combinations across a vocabulary of 254 terms is astronomically larger than the number of atoms in the known universe! We could never collect enough training reviews to estimate the joint probability of every unique 15-word sentence directly.

To overcome this curse of dimensionality, machine learning researchers introduced a simplifying assumption: **conditional independence**. While linguistically unrealistic (words obviously depend on each other), this assumption makes text classification computationally tractable, blisteringly fast, and astonishingly accurate in practice.

## 4. Concept Explanation
### The "Naive" Conditional Independence Assumption
The Naive Bayes model assumes that **given the class label $C$, the occurrence of each word $w_j$ is completely independent of the occurrence of every other word $w_k$**:
$$P(\mathbf{x} \mid C) = P(w_1, w_2, \dots, w_M \mid C) = \prod_{j=1}^{M} P(w_j \mid C)$$

Instead of needing an intractable joint probability table for entire sentences, the algorithm only needs to learn a simple 1D table of individual word probabilities for each class: $P(w_j \mid \text{mixed})$, $P(w_j \mid \text{negative})$, and $P(w_j \mid \text{positive})$.

### Why is it Called "Multinomial"?
Different Naive Bayes variants model different data types:
- **GaussianNB:** Assumes continuous features following a bell curve (e.g., height, temperature).
- **BernoulliNB:** Assumes binary indicator features (word present: 1, word absent: 0).
- **MultinomialNB:** Models discrete feature counts representing the number of times token $w_j$ appears in the document.

Because text documents are collections of word counts, `MultinomialNB` is the standard, mathematically appropriate algorithm for Bag-of-Words text classification.

### The Problem of Floating-Point Underflow
In standard arithmetic, multiplying dozens of small probabilities ($0.001 \times 0.004 \times 0.0005 \dots$) rapidly shrinks toward zero, dropping below the minimum float precision of computer hardware ($\approx 10^{-308}$). When this happens, the computer encounters **floating-point underflow** and rounds the product to `0.0`, destroying all information.

To prevent underflow, `MultinomialNB` converts all multiplications into **log-space additions**:
$$\log \left( \prod_{j=1}^M P(w_j \mid C) \right) = \sum_{j=1}^M \log P(w_j \mid C)$$
Instead of multiplying tiny fractions, the computer adds negative numbers:
$$\log P(C \mid \mathbf{x}) \propto \log P(C) + \sum_{j=1}^M \log P(w_j \mid C)$$
Addition is numerically stable, fast, and immune to underflow!

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 52-59 inspect the model's internal log-probability tables directly:
```python
    vectorizer = model.named_steps["vectorizer"]
    classifier = model.named_steps["classifier"]
    feature_names = vectorizer.get_feature_names_out()
    classes = list(classifier.classes_)
    print("Top words per mood:")
    for index, mood in enumerate(classes):
        top = np.argsort(classifier.feature_log_prob_[index])[-8:][::-1]
        print(f"  {mood:8s}: {', '.join(feature_names[top])}")
```
- `classifier.feature_log_prob_`: A 2D NumPy array of shape $(3, 254)$ storing $\log P(w_j \mid C)$.
- Every cell contains the natural logarithm of the token likelihood for that mood class.

## 6. Worked Example
Let us compute the log-likelihood of a sentence under the `positive` class using log-space additions:
- Review tokens: `["great", "acting"]`
- Model parameters:
  - $\log P(\text{positive}) = -1.1135$
  - $\log P(\text{"great"} \mid \text{positive}) = -2.8541$
  - $\log P(\text{"acting"} \mid \text{positive}) = -3.5472$

**Log-Space Sum:**
$$\text{Total Score} = -1.1135 + (-2.8541) + (-3.5472) = \mathbf{-7.5148}$$

To convert back to unnormalized linear probability:
$$e^{-7.5148} \approx 0.000545$$

Because computers can easily add negative floats like $-2.8541$, log-space calculations never suffer from underflow.

## 7. Step-by-Step Student Instructions
1. Open Python interactive console.
2. Inspect the shape and values of `classifier.feature_log_prob_`:
   ```python
   # Assuming model is fitted from main.py
   clf = model.named_steps["classifier"]
   print("feature_log_prob_ shape:", clf.feature_log_prob_.shape)
   print("Sample log probs (first 5 features of class 0):", clf.feature_log_prob_[0, :5])
   ```
3. Verify that all values in `feature_log_prob_` are negative numbers (since $\log(p) \le 0$ for any $0 < p \le 1$).

## 8. Expected Output or Observable Behaviour
From the interactive console:
```text
feature_log_prob_ shape: (3, 254)
Sample log probs (first 5 features of class 0): [-4.70048037 -5.39362755 -5.39362755 -5.39362755 -4.70048037]
```
The shape $(3, 254)$ confirms that for each of the 3 classes, the model maintains log-probabilities across all 254 vocabulary features.

## 9. Practical Exercises (with Success Criteria)
- **Task 2.1:** Explain why the conditional independence assumption is linguistically false in English (give an example of two words whose occurrences are strongly dependent).
- **Task 2.2:** Despite violating linguistic reality, why does Naive Bayes remain one of the most effective and popular text classifiers in real-world production systems?
- *Success Criteria:* Identifies that words in phrases like "Hong Kong" or "ice cream" are strictly dependent; explains that Naive Bayes only needs to rank relative class likelihoods correctly, which often holds even when absolute probability estimates are slightly miscalibrated.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Using `GaussianNB` for text Bag-of-Words count data | Gaussian assumes a continuous normal distribution, distorting discrete word counts | Always use `MultinomialNB` for discrete word count vectors. |
| Multiplying probabilities in linear space for long reviews | Causes floating-point underflow and crashes predictions to zero | Always compute in log-space: $\sum \log P$. |
| Believing Naive Bayes fails because words are not independent | Overlooks the empirical robustness of Bayesian decision boundaries | Naive Bayes predicts the correct argmax even when independence is violated. |

## 11. Best Practices and Code Quality
- Rely on scikit-learn's optimized `MultinomialNB`, which implements log-space calculations natively in C/Cython.
- Access `feature_log_prob_` directly when ranking influential words or debugging feature contributions.
- Check that feature shapes match vocabulary sizes ($3 \times V$).

## 12. Security, Ethics, and Fair AI Considerations
Because Naive Bayes treats words independently, it cannot comprehend compositional nuance or double negatives (e.g., "not not bad"). In sensitive contexts (such as hate speech moderation), this blind spot can lead to false accusations if malicious actors employ syntactic evasion.

## 13. Summary and Key Takeaways
Multinomial Naive Bayes models discrete word count distributions under the naive assumption that words are conditionally independent given the class label. By converting product likelihoods into log-space additions, the algorithm avoids floating-point underflow and achieves rapid, robust multi-class classification.

## 14. Knowledge Check Questions
1. What does the "naive" conditional independence assumption state mathematically?
2. Why is `MultinomialNB` chosen over `GaussianNB` or `BernoulliNB` for text counts?
3. What is floating-point underflow, and how do logarithms solve it?
4. What is the shape of `classifier.feature_log_prob_` in the Movie Review Mood Ring project?

## 15. References and Further Reading
- McCallum, A., & Nigam, K. (1998). *A comparison of event models for Naive Bayes text classification.* AAAI-98 Workshop on Learning for Text Categorization.
- Scikit-learn Documentation: `MultinomialNB` (https://scikit-learn.org/stable/modules/generated/sklearn.naive_bayes.MultinomialNB.html).
