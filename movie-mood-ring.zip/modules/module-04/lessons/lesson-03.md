# Lesson 03: Zero Probabilities and Laplace Smoothing

**Lesson ID:** lesson-03
**Module:** module-04
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain the "zero-probability problem" in Naive Bayes and why a single unseen word can destroy a classification prediction.
- Define Laplace (additive) smoothing and state its mathematical formula with smoothing parameter $\alpha$.
- Explain the role of the default parameter `alpha=1.0` in scikit-learn's `MultinomialNB`.
- Calculate smoothed token probabilities by hand on a toy corpus.

## 2. Prerequisites
- Completion of Lessons 01 and 02.
- Basic understanding of likelihood fractions and the product rule of probability.

## 3. Real-World Context & Business Motivation
Imagine our model is trained on 67 movie reviews. During training, the word *"masterpiece"* appears three times in positive reviews, but it happens to appear zero times in mixed reviews.

Now, a user submits a new review: *"A fascinating, ambitious masterpiece that fell apart in the final act."*
If the model uses standard frequency counting without smoothing:
$$P(\text{"masterpiece"} \mid \text{mixed}) = \frac{0}{\text{Total Words in Mixed}} = 0$$

When the Naive Bayes algorithm multiplies all the word likelihoods together:
$$P(\text{Review} \mid \text{mixed}) = P(\text{"fascinating"} \mid \text{mixed}) \times \dots \times P(\text{"masterpiece"} \mid \text{mixed}) \times \dots$$
Because anything multiplied by zero is zero, the entire likelihood for the `mixed` class collapses to **0.0**! The presence of a single novel word completely obliterates all other evidence, making it impossible for the model to predict `mixed`, even though the rest of the sentence strongly indicates a mixed review.

To prevent this catastrophic failure, we must apply **Laplace smoothing**.

## 4. Concept Explanation
### The Zero-Frequency Dilemma
In statistical estimation, observing an event zero times in a finite training sample does *not* mean the event has a true zero probability in the real world. It simply means our training sample was finite. Treating an unobserved event as an impossibility ($P=0$) is a fatal flaw known as the **zero-frequency problem** (or the black swan fallacy).

### Laplace Additive Smoothing Formulated
Laplace smoothing (also called add-one smoothing) resolves this by adding a small pseudo-count $\alpha > 0$ to the count of every vocabulary word across all classes:
$$P(w_j \mid C) = \frac{N_{C, j} + \alpha}{N_C + \alpha \cdot |V|}$$

Where:
- $N_{C, j}$: The observed count of word $w_j$ in training documents of class $C$.
- $N_C$: The total count of all words in training documents of class $C$.
- $|V|$: The total vocabulary size (number of unique features in the dictionary, here 254).
- $\alpha$: The smoothing hyperparameter (typically $\alpha = 1.0$).

### How the Formula Prevents Zero Probabilities
Let us examine what happens when an unseen word has count $N_{C, j} = 0$:
$$P(w_j \mid C) = \frac{0 + \alpha}{N_C + \alpha \cdot |V|} = \frac{\alpha}{N_C + \alpha \cdot |V|} > 0$$
Because the numerator is $\alpha > 0$, the probability is guaranteed to be strictly positive! The likelihood never collapses to zero, and the model can evaluate all words gracefully.

### The Role of $\alpha$ in Scikit-Learn
In `MultinomialNB`, the parameter `alpha` controls the strength of smoothing:
- `alpha=1.0` (Default): Standard Laplace smoothing. Adds 1 virtual count to every word.
- `0 < alpha < 1.0`: Lidstone smoothing (gentler smoothing).
- `alpha=0.0`: No smoothing (reintroduces the zero-probability failure mode).

In `main.py`, `MultinomialNB()` runs with the robust default `alpha=1.0`.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, line 39 instantiates the smoothed classifier:
```python
    model = Pipeline(
        [
            ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
            ("classifier", MultinomialNB()),
        ]
    )
```
Because no arguments are passed to `MultinomialNB()`, it defaults to `alpha=1.0`.
Let us inspect lines 61-71 where novel reviews are scored:
```python
    new_reviews = [
        "I loved the acting and the story was beautiful, but the ending felt rushed.",
        "A boring, confusing mess. I kept checking the time.",
        "A delightful film with warm characters and a happy ending.",
    ]
    new_predictions = model.predict(new_reviews)
    new_probabilities = model.predict_proba(new_reviews)
```
Even if some words or bigrams in these new reviews appeared zero times in certain classes during training, Laplace smoothing ensures that every class retains a valid non-zero probability, enabling stable confidence calculation.

## 6. Worked Example
Let us trace Laplace smoothing on a toy dataset:
- Vocabulary: `["acting", "boring", "great", "plot"]` ($|V| = 4$).
- Positive class word counts: `acting: 3, boring: 0, great: 5, plot: 2`.
- Total words in positive class: $N_{\text{pos}} = 3 + 0 + 5 + 2 = 10$.
- Smoothing parameter: $\alpha = 1.0$.

Let us calculate the smoothed probability for each word under the positive class:
Denominator $= N_{\text{pos}} + \alpha \cdot |V| = 10 + (1.0 \times 4) = 14$.

1. **"acting"** (observed 3 times):
   $$P(\text{"acting"} \mid \text{pos}) = \frac{3 + 1}{14} = \frac{4}{14} \approx 0.286$$
2. **"boring"** (observed 0 times):
   $$P(\text{"boring"} \mid \text{pos}) = \frac{0 + 1}{14} = \frac{1}{14} \approx \mathbf{0.071}$$
3. **"great"** (observed 5 times):
   $$P(\text{"great"} \mid \text{pos}) = \frac{5 + 1}{14} = \frac{6}{14} \approx 0.429$$
4. **"plot"** (observed 2 times):
   $$P(\text{"plot"} \mid \text{pos}) = \frac{2 + 1}{14} = \frac{3}{14} \approx 0.214$$

**Check Sum:** $\frac{4}{14} + \frac{1}{14} + \frac{6}{14} + \frac{3}{14} = \frac{14}{14} = 1.00$.
Notice that *"boring"* receives a non-zero probability ($\frac{1}{14}$), preventing arithmetic collapse while correctly remaining the least likely word in the positive class!

## 7. Step-by-Step Student Instructions
1. Open Python interactive console.
2. Verify the alpha parameter of the fitted classifier:
   ```python
   clf = model.named_steps["classifier"]
   print("Alpha hyperparameter:", clf.alpha)
   ```
3. Test training a model with `alpha=0.0` on synthetic data and observe the warnings or zero-probability errors when predicting on novel words.

## 8. Expected Output or Observable Behaviour
From the interactive terminal:
```text
Alpha hyperparameter: 1.0
```
This confirms that scikit-learn initializes `alpha=1.0` by default, protecting all downstream probability estimations.

## 9. Practical Exercises (with Success Criteria)
- **Task 3.1:** Using the toy example above, calculate what happens if $\alpha = 10.0$. How does a large $\alpha$ affect the probability distribution across words?
- **Task 3.2:** Explain why setting $\alpha = 0.0$ in `MultinomialNB` leads to runtime warnings or degenerate predictions on real-world test sets.
- *Success Criteria:* Identifies that large $\alpha$ flattens the distribution toward a uniform distribution ($\frac{1}{|V|}$); explains that $\alpha=0.0$ causes $\log(0) = -\infty$ in log-space.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Setting `alpha=0` to "avoid biasing the data" | Causes $\log(0) = -\infty$, collapsing probabilities on any unseen word | Smoothing is mathematically essential for finite sample generalization. |
| Setting `alpha` excessively high (e.g., $\alpha=1000$) | Washes out all learned differences, pushing every word probability to $\frac{1}{|V|}$ | Keep $\alpha \approx 1.0$ to preserve learned empirical distinctions. |
| Forgetting to add $\alpha \cdot |V|$ to the denominator | Fails to normalize probabilities, causing them to sum to $> 1.0$ | The denominator must add $\alpha$ for every word in the vocabulary. |

## 11. Best Practices and Code Quality
- Retain `alpha=1.0` as the robust, production-tested default for text classification.
- If tuning hyperparameters with `GridSearchCV`, test $\alpha \in [0.1, 0.5, 1.0, 2.0]$.
- Ensure that vocabulary size $|V|$ is defined consistently across training splits.

## 12. Security, Ethics, and Fair AI Considerations
Laplace smoothing embodies epistemic humility: acknowledging that our training observations do not encompass the entirety of human expression. By ensuring unobserved words receive non-zero probabilities, smoothing prevents catastrophic overconfidence on rare dialects or novel slang.

## 13. Summary and Key Takeaways
The zero-frequency problem occurs when an unseen word has a zero training count, collapsing the entire Naive Bayes likelihood product to zero. Laplace smoothing ($\alpha=1.0$) adds a virtual count to every vocabulary term, guaranteeing strictly positive probabilities while preserving the empirical frequency ordering of the training data.

## 14. Knowledge Check Questions
1. Why does a single unseen word with count 0 break standard Naive Bayes?
2. State the Laplace smoothing formula for $P(w_j \mid C)$.
3. What is the default value of the `alpha` hyperparameter in scikit-learn's `MultinomialNB`?
4. What happens to the denominator when Laplace smoothing is applied across a vocabulary of size $|V|$?

## 15. References and Further Reading
- Laplace, P. S. (1814). *Essai philosophique sur les probabilités.*
- Scikit-learn User Guide: Naive Bayes (https://scikit-learn.org/stable/modules/naive_bayes.html#multinomial-naive-bayes).
