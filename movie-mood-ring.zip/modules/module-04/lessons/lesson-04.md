# Lesson 04: Assembling and Fitting the Scikit-Learn Pipeline

**Lesson ID:** lesson-04
**Module:** module-04
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain what a scikit-learn `Pipeline` is and why it represents software engineering best practice in machine learning.
- Assemble a multi-stage NLP pipeline containing a feature transformer (`CountVectorizer`) and an estimator (`MultinomialNB`).
- Explain how `Pipeline.fit()` prevents data leakage during training and validation.
- Access individual named pipeline steps to extract learned vocabularies and model parameters.

## 2. Prerequisites
- Completion of Lessons 01, 02, and 03.
- Familiarity with object-oriented programming concepts in Python (classes, instances, method chaining).

## 3. Real-World Context & Business Motivation
In beginner machine learning code, developers often vectorize text and train models as disconnected, manual steps:
```python
# The Fragile, Error-Prone Anti-Pattern:
vec = CountVectorizer(...)
X_train_vec = vec.fit_transform(X_train)
clf = MultinomialNB(...)
clf.fit(X_train_vec, y_train)

# Later in production...
new_review = ["The movie was great!"]
# Bug: Developer forgets to transform new_review with vec, passing raw text to clf!
clf.predict(new_review) # CRASH!
```
This manual approach is fraught with danger:
1. When evaluating test sets or deploying to production, developers often forget to transform new inputs, passing raw strings into estimators.
2. In cross-validation, manual vectorization frequently leaks test set vocabulary into training folds.

To eliminate these bugs, professional ML engineers wrap feature extractors and classifiers into an atomic, unified **Pipeline**.

## 4. Concept Explanation
### What is a Scikit-Learn Pipeline?
A `Pipeline` is a container object in `sklearn.pipeline` that chains together a sequence of data transformers with a final estimator. It behaves as a single unified estimator:
```mermaid
flowchart LR
    A["Raw Text String: 'Loved the acting...'"] --> B["Stage 1: 'vectorizer'\n(CountVectorizer)"]
    B -->|"Sparse Vector (1x254)"| C["Stage 2: 'classifier'\n(MultinomialNB)"]
    C --> D["Output: 'mixed' (89%)"]
```

### The Structure of a Pipeline
A Pipeline is defined as a list of `(name, object)` tuples:
```python
model = Pipeline(
    [
        ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
        ("classifier", MultinomialNB()),
    ]
)
```
- Each intermediate stage must be a **Transformer** implementing `.fit()` and `.transform()`.
- The final stage must be an **Estimator** implementing `.fit()` and optionally `.predict()` / `.predict_proba()`.

### The Lifecycle of Pipeline Methods
1. **`model.fit(X_train, y_train)`:**
   - Calls `vectorizer.fit_transform(X_train)` to learn the vocabulary and build the training matrix.
   - Passes the resulting sparse matrix and `y_train` into `classifier.fit()`.
2. **`model.predict(X_test)`:**
   - Calls `vectorizer.transform(X_test)` using the *frozen training vocabulary*.
   - Passes the transformed test matrix into `classifier.predict()`.
3. **`model.predict_proba(new_reviews)`:**
   - Calls `vectorizer.transform(new_reviews)`.
   - Passes the matrix into `classifier.predict_proba()` to output posterior probabilities.

### Accessing Internal Pipeline Components
You can inspect any stage in the pipeline using the `named_steps` dictionary:
```python
vectorizer = model.named_steps["vectorizer"]
classifier = model.named_steps["classifier"]
```
This allows direct access to `vectorizer.get_feature_names_out()` and `classifier.feature_log_prob_`.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 36-43 assemble and fit the pipeline, and lines 52-55 extract internal stages:
```python
    model = Pipeline(
        [
            ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
            ("classifier", MultinomialNB()),
        ]
    )
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)

    # Accessing named steps
    vectorizer = model.named_steps["vectorizer"]
    classifier = model.named_steps["classifier"]
    feature_names = vectorizer.get_feature_names_out()
    classes = list(classifier.classes_)
```
Notice how cleanly `model.predict(X_test)` handles the entire workflow: the caller simply passes raw text strings, and the Pipeline handles the internal transformations automatically.

## 6. Worked Example
Let us demonstrate how a fitted Pipeline handles novel raw review strings directly:
```python
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split

df = pd.read_csv("data/movie_reviews.csv")
X_train, X_test, y_train, y_test = train_test_split(
    df["review"], df["mood"], test_size=0.25, random_state=42, stratify=df["mood"]
)

model = Pipeline([
    ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
    ("classifier", MultinomialNB())
])

model.fit(X_train, y_train)

# Test inference on raw strings without manual vectorization:
test_string = ["A delightful film with warm characters and a happy ending."]
pred = model.predict(test_string)
probs = model.predict_proba(test_string)

print("Predicted Mood:", pred[0])
print("Classes:", model.named_steps["classifier"].classes_)
print("Probabilities:", probs[0])
```
**Console Output:**
```text
Predicted Mood: positive
Classes: ['mixed' 'negative' 'positive']
Probabilities: [0.0412 0.0403 0.9185]
```
The Pipeline ingested a raw string, vectorized it against the training vocabulary, evaluated Bayes' rule, and returned a ~92% confident positive prediction.

## 7. Step-by-Step Student Instructions
1. Run `python main.py` in your terminal.
2. Verify that the console displays:
   ```text
   Accuracy: 100.0%
   ```
3. Observe how the pipeline trains and evaluates without any intermediate variables exposing raw matrix arrays to the global scope.
4. Open Python and verify you can access `model.named_steps.keys()`: confirm it returns `dict_keys(['vectorizer', 'classifier'])`.

## 8. Expected Output or Observable Behaviour
When executing `main.py`, the pipeline completes all operations instantaneously:
```text
============================================================
THE MOVIE REVIEW MOOD RING
============================================================
Accuracy: 100.0%

              precision    recall  f1-score   support

       mixed       1.00      1.00      1.00         7
    negative       1.00      1.00      1.00         8
    positive       1.00      1.00      1.00         8
```
All 23 test reviews are classified with 100% precision and recall.

## 9. Practical Exercises (with Success Criteria)
- **Task 4.1:** Write a Python function that accepts a fitted pipeline and a text string, returning a dictionary mapping class names to formatted percentage probabilities.
- **Task 4.2:** Explain what would happen if you tried to add `StandardScaler()` into this pipeline between `CountVectorizer` and `MultinomialNB`. Why does `StandardScaler` violate `MultinomialNB`'s input assumptions?
- *Success Criteria:* Function cleanly extracts `predict_proba` and `classifier.classes_`; explanation notes that `StandardScaler` produces negative numbers and destroys matrix sparsity, whereas `MultinomialNB` requires non-negative counts.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Putting an estimator in the middle of a pipeline | Intermediate pipeline steps must be transformers with `.transform()` | Only the final step in a pipeline can be an estimator. |
| Forgetting step names when accessing `named_steps` | Accessing `model.named_steps['vect']` when named `'vectorizer'` raises `KeyError` | Use exact name strings defined during Pipeline instantiation. |
| Saving only the classifier without the vectorizer | Inability to vectorize new production text without the original vocabulary | Always serialize the entire `Pipeline` object with `joblib.dump(model, 'model.joblib')`. |

## 11. Best Practices and Code Quality
- Always package multi-stage ML workflows inside scikit-learn `Pipeline` objects.
- Give pipeline steps clear, descriptive names (`"vectorizer"`, `"classifier"`).
- Serialize the entire fitted pipeline as a single artifact for production deployment.

## 12. Security, Ethics, and Fair AI Considerations
Pipeline encapsulation ensures that test data cannot leak into preprocessing steps, enforcing unbiased scientific evaluation. Shipping reproducible pipelines guarantees that model predictions in production behave identically to training benchmarks.

## 13. Summary and Key Takeaways
A scikit-learn `Pipeline` chains together data transformers and a final estimator into a single, cohesive object. In the Movie Review Mood Ring, encapsulating `CountVectorizer` and `MultinomialNB` prevents data leakage, automates inference on raw text strings, and provides transparent access to learned model parameters.

## 14. Knowledge Check Questions
1. What are the two named steps in the Movie Review Mood Ring pipeline?
2. What method does a Pipeline invoke on intermediate steps during `fit()`?
3. How do you access the fitted `CountVectorizer` from a trained pipeline object?
4. Why does wrapping vectorization and modeling in a Pipeline prevent data leakage?

## 15. References and Further Reading
- Scikit-learn Pipeline User Guide: https://scikit-learn.org/stable/modules/compose.html#pipeline
- Buitinck, L., et al. (2013). *API design for machine learning software: experiences from the scikit-learn project.*
