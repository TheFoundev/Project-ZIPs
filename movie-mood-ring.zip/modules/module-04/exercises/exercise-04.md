# Module 4 Exercises: Multinomial Naive Bayes & Pipeline Assembly

## Exercise 4.1: Manual Bayesian Posterior Computation (10 min)
**Objective:** Manually apply Bayes' Theorem with Laplace smoothing on a mini-corpus to calculate posterior class probabilities.

**Problem Statement:** You have trained a Naive Bayes model on a movie review dataset with 2 classes: `positive` and `negative`.
Given:
- Vocabulary: `["acting", "boring", "great", "plot"]` ($|V| = 4$)
- Total word counts in training: $N_{	ext{pos}} = 20$, $N_{	ext{neg}} = 20$
- Word counts for `"great"`: $N_{	ext{pos, great}} = 8$, $N_{	ext{neg, great}} = 1$
- Priors: $P(	ext{pos}) = 0.5$, $P(	ext{neg}) = 0.5$
- Laplace smoothing: $lpha = 1.0$

Calculate the smoothed posterior probability $P(	ext{positive} \mid 	ext{"great"})$.

**Requirements:**
1. State the smoothed likelihood formula for $P(	ext{"great"} \mid 	ext{pos})$ and $P(	ext{"great"} \mid 	ext{neg})$.
2. Calculate the numerical likelihoods with $lpha = 1.0$.
3. Compute the unnormalized numerators for each class.
4. Normalize to calculate $P(	ext{pos} \mid 	ext{"great"})$ and $P(	ext{neg} \mid 	ext{"great"})$.

**Constraints:** Show all arithmetic fractions and percentages clearly.

**Expected Behaviour:** Step-by-step mathematical proof yielding normalized posterior probabilities.

**Acceptance Criteria:**
- [ ] Denominator calculated as $20 + (1 	imes 4) = 24$.
- [ ] $P(	ext{"great"} \mid 	ext{pos}) = rac{8+1}{24} = rac{9}{24} = 0.375$.
- [ ] $P(	ext{"great"} \mid 	ext{neg}) = rac{1+1}{24} = rac{2}{24} = 0.0833$.
- [ ] Posterior $P(	ext{pos} \mid 	ext{"great"}) = rac{0.375 	imes 0.5}{(0.375 	imes 0.5) + (0.0833 	imes 0.5)} = rac{0.1875}{0.22916} = \mathbf{81.8\%}$.

**Hints:**
- Don't forget to add $lpha \cdot |V| = 4$ to the count denominators.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes

---

## Exercise 4.2: Assembling and Inspecting the Pipeline (15 min)
**Objective:** Assemble an atomic scikit-learn Pipeline and inspect internal parameters via `named_steps`.

**Problem Statement:** Write a Python script that constructs the exact Movie Review Mood Ring pipeline, fits it on `X_train` and `y_train`, and programmatically inspects internal states.

**Requirements:**
1. Construct a Pipeline with stages `("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2)))` and `("classifier", MultinomialNB())`.
2. Fit the pipeline on the training split from `data/movie_reviews.csv`.
3. Extract `classifier.classes_` and verify that the 3 classes are listed alphabetically: `['mixed', 'negative', 'positive']`.
4. Extract the vocabulary size from `vectorizer` and confirm it equals 254.
5. Print the shape of `classifier.feature_log_prob_`.

**Constraints:** Use standard scikit-learn Pipeline syntax.

**Expected Behaviour:** A standalone script that outputs verified model metadata.

**Acceptance Criteria:**
- [ ] Successfully builds and fits the Pipeline.
- [ ] Confirms classes are `['mixed', 'negative', 'positive']`.
- [ ] Confirms 254 vocabulary features.
- [ ] Confirms `feature_log_prob_` shape is `(3, 254)`.

**Hints:**
- Review Lesson 04 on accessing named steps.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 4.3: Exploring the Zero-Frequency Trap & Alpha Tuning (15 min)
**Objective:** Empirically demonstrate the zero-frequency failure mode when $lpha = 0.0$ versus $lpha = 1.0$.

**Problem Statement:** Train two `MultinomialNB` classifiers on a restricted subset of reviews: one with `alpha=0.0` (no smoothing) and one with `alpha=1.0` (Laplace smoothing). Test both models on a review containing a word that did not appear in one of the training classes.

**Requirements:**
1. Train both models on the training partition.
2. Evaluate both models on the test review: *"A boring, confusing mess. I kept checking the time."*
3. Observe and document any warnings, `-inf` values in `feature_log_prob_`, or degenerate probability outputs.
4. Explain how `alpha=1.0` guarantees mathematical stability in production.

**Constraints:** Use Python and scikit-learn.

**Expected Behaviour:** A comparison demonstrating that `alpha=0.0` produces runtime warnings and arithmetic breakdown, while `alpha=1.0` computes stable probabilities.

**Acceptance Criteria:**
- [ ] Documents `RuntimeWarning: divide by zero encountered in log` when `alpha=0.0`.
- [ ] Shows that unobserved words yield $-\infty$ log-probabilities under `alpha=0.0`.
- [ ] Concludes that Laplace smoothing is an essential safety mechanism in production NLP.

**Hints:**
- Review Lesson 03 on Laplace smoothing.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 4.4: Custom Pipeline Transformer Architecture (20 min)
**Objective:** Design a custom text preprocessor transformer that integrates into a scikit-learn Pipeline before `CountVectorizer`.

**Problem Statement:** A security audit requires stripping all email addresses, URLs, and excess whitespace from review text before it reaches `CountVectorizer`. Create a custom scikit-learn transformer class `TextSanitizer` inheriting from `BaseEstimator` and `TransformerMixin` and insert it into the pipeline.

**Requirements:**
1. Implement `TextSanitizer` with `.fit()` returning `self` and `.transform()` applying regex cleaning to input text series.
2. Build a 3-stage Pipeline:
   `[("sanitizer", TextSanitizer()), ("vectorizer", CountVectorizer(...)), ("classifier", MultinomialNB())]`.
3. Train the 3-stage pipeline on `X_train, y_train`.
4. Test inference on a review containing noisy formatting: *"Loved the cast! Contact me at fan@movies.com https://reviews.org"*.
5. Verify that the output prediction and probability scores are unaffected by the sanitized URLs.

**Constraints:** Inherit cleanly from scikit-learn's base transformer classes.

**Expected Behaviour:** A robust 3-stage Pipeline implementing secure text preprocessing.

**Acceptance Criteria:**
- [ ] `TextSanitizer` implements standard `fit` and `transform` methods.
- [ ] Successfully integrates into `Pipeline`.
- [ ] Regex cleanly removes email addresses and URLs.
- [ ] End-to-end pipeline executes `fit` and `predict` seamlessly.

**Hints:**
- Review Lesson 04 on Pipeline design and composability.

**Difficulty:** Advanced  
**Estimated Completion Time:** 20 minutes
