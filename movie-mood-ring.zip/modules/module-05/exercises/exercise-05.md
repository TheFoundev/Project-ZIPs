# Module 5 Exercises: Multi-Class Evaluation & Feature Log-Probabilities

## Exercise 5.1: Multi-Class Metric Calculation from Confusion Matrix (10 min)
**Objective:** Manually compute accuracy, macro precision, macro recall, and macro F1-score from a given $3 	imes 3$ confusion matrix.

**Problem Statement:** A candidate sentiment classifier evaluated on a held-out test partition produces the following $3 	imes 3$ confusion matrix (rows = actual, columns = predicted, classes = `['mixed', 'negative', 'positive']`):
```text
               Predicted: mixed   Predicted: negative   Predicted: positive
Actual: mixed         6                    1                    0
Actual: negative      1                    7                    0
Actual: positive      0                    1                    7
```
Calculate the performance metrics by hand.

**Requirements:**
1. Calculate the overall classification accuracy across all 22 test samples.
2. Calculate precision, recall, and F1-score for each of the three classes individually.
3. Calculate the unweighted macro-averaged precision, recall, and F1-score across all three classes.
4. Identify which class experienced the lowest recall, and explain why.

**Constraints:** Show all arithmetic formulas and fractions clearly.

**Expected Behaviour:** Step-by-step mathematical derivation yielding exact percentages.

**Acceptance Criteria:**
- [ ] Overall accuracy calculated as $rac{6 + 7 + 7}{22} = rac{20}{22} pprox \mathbf{90.9\%}$.
- [ ] Individual metrics derived:
  - Mixed: Precision $rac{6}{7} pprox 85.7\%$, Recall $rac{6}{7} pprox 85.7\%$, F1 $pprox 85.7\%$.
  - Negative: Precision $rac{7}{9} pprox 77.8\%$, Recall $rac{7}{8} = 87.5\%$, F1 $pprox 82.4\%$.
  - Positive: Precision $rac{7}{7} = 100\%$, Recall $rac{7}{8} = 87.5\%$, F1 $pprox 93.3\%$.
- [ ] Macro averages computed accurately.

**Hints:**
- Row sums equal actual class support; column sums equal total model predictions for that class.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes

---

## Exercise 5.2: Implementing Top Words Extraction with NumPy (15 min)
**Objective:** Implement a reusable Python function that extracts top $K$ features from a trained scikit-learn Pipeline using `np.argsort`.

**Problem Statement:** Write a standalone Python function `extract_top_words(pipeline, k=8)` that programmatically inspects any fitted Pipeline containing a vectorizer and a Naive Bayes classifier, returning a structured dictionary of top features.

**Requirements:**
1. Extract `vectorizer = pipeline.named_steps["vectorizer"]` and `classifier = pipeline.named_steps["classifier"]`.
2. Retrieve the feature vocabulary names using `vectorizer.get_feature_names_out()`.
3. For each class index and class label in `classifier.classes_`, use `np.argsort` to retrieve the top $k$ features in descending order of log-probability.
4. Return a dictionary of the form `{"class_name": ["word1", "word2", ...]}`.
5. Verify that running the function on the Movie Mood Ring pipeline returns the exact 8 top words per mood printed in `main.py`.

**Constraints:** Use vectorized NumPy array operations; do not use slow Python loops over individual array cells.

**Expected Behaviour:** A clean, reusable Python utility function with docstrings and type annotations.

**Acceptance Criteria:**
- [ ] Implements `np.argsort(classifier.feature_log_prob_[index])[-k:][::-1]`.
- [ ] Returns valid dictionary matching `main.py` output.
- [ ] Handles arbitrary $k$ parameter values gracefully.

**Hints:**
- Review Lesson 03 on decoding `feature_log_prob_`.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 5.3: Diagnosing Sub-Optimal Confusion Matrices (15 min)
**Objective:** Analyze a simulated confusion matrix showing off-diagonal misclassifications and diagnose the underlying NLP causes.

**Problem Statement:** An updated sentiment model trained on web reviews achieves the following confusion matrix:
```text
               Predicted: mixed   Predicted: negative   Predicted: positive
Actual: mixed         3                    8                    9
Actual: negative      0                   18                    2
Actual: positive      1                    1                   18
```
Notice that out of 20 actual `mixed` reviews, only 3 were predicted as mixed, while 8 were predicted as negative and 9 as positive! Write a root-cause diagnostic memo explaining why the model failed on mixed reviews.

**Requirements:**
1. Calculate the recall for the `mixed` class ($rac{3}{20} = 15\%$).
2. Explain the structural NLP reason why a Bag-of-Words Naive Bayes model would split mixed reviews across positive and negative classes.
3. Propose two specific feature engineering enhancements (e.g., custom contrastive conjunction features, negation scoping, or clause weighting) to help the model identify mixed sentiment.
4. Explain how threshold calibration on `predict_proba` could be adjusted to catch ambivalent reviews.

**Constraints:** Base your analysis on linguistic and probabilistic principles.

**Expected Behaviour:** A structured engineering diagnostic memo with actionable recommendations.

**Acceptance Criteria:**
- [ ] Identifies the collapse of mixed class recall (15%).
- [ ] Explains that mixed reviews contain competing positive and negative tokens that cancel out or pull the likelihood toward one extreme.
- [ ] Recommends contrastive clause splitting or bigram weighting around "but" / "however".

**Hints:**
- Review Lesson 04 on distinctive vocabulary and the balance between praise and critique.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 5.4: Feature Log-Ratio Ranking & Contrastive Visualization (20 min)
**Objective:** Compute log-likelihood ratios to identify features that discriminate *between* two specific mood classes.

**Problem Statement:** While `feature_log_prob_[i]` reveals which words are frequent within class $i$, a word could be frequent in *both* classes (like `"movie"`). To discover words that uniquely separate positive reviews from negative reviews, we calculate the **log-likelihood ratio**:
$$	ext{Ratio}_j = \log P(w_j \mid 	ext{positive}) - \log P(w_j \mid 	ext{negative})$$
Write a Python script that computes this difference for all 254 vocabulary features, ranks them, and renders a horizontal bar chart of the top 5 most positive and top 5 most negative discriminative features.

**Requirements:**
1. Compute `ratio = clf.feature_log_prob_[pos_idx] - clf.feature_log_prob_[neg_idx]`.
2. Extract the 5 largest positive differences (words most uniquely positive) and 5 largest negative differences (words most uniquely negative).
3. Plot a horizontal bar chart using matplotlib (configured with `Agg`), coloring positive bars green (`#27ae60`) and negative bars red (`#c0392b`).
4. Save the chart to `outputs/discriminative_features.png` and close the figure cleanly.

**Constraints:** Use headless matplotlib and dynamic `pathlib` paths.

**Expected Behaviour:** A Python script generating a high-resolution horizontal bar chart displaying pure discriminative features.

**Acceptance Criteria:**
- [ ] Correctly calculates log-ratio difference vectors.
- [ ] Extracts top discriminative features without errors.
- [ ] Saves graphic safely to `outputs/discriminative_features.png`.
- [ ] Closes plot cleanly with `plt.close()`.

**Hints:**
- High positive ratio means the word is vastly more likely in positive than negative; large negative ratio means vastly more likely in negative.

**Difficulty:** Advanced  
**Estimated Completion Time:** 20 minutes
