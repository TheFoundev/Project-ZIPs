# Lesson 01: Multi-Class Evaluation Metrics

**Lesson ID:** lesson-01
**Module:** module-05
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define accuracy, precision, recall, and F1-score in the context of multi-class classification.
- Explain the difference between macro-averaged and weighted-averaged metrics in scikit-learn.
- Interpret the four columns of `classification_report`: precision, recall, f1-score, and support.
- Analyze the 100% test accuracy achieved by the Movie Review Mood Ring model on its 23 test samples.

## 2. Prerequisites
- Completion of Module 04.
- Basic understanding of test splits and ground-truth validation.

## 3. Real-World Context & Business Motivation
In binary classification, evaluation is relatively straightforward: you count True Positives, False Positives, True Negatives, and False Negatives for a single positive class. But when building multi-class systems—such as our 3-class Movie Mood Ring—evaluating model performance requires examining each class individually as well as in aggregate.

Imagine a model deployed by a movie recommendation engine that achieves 90% overall accuracy, but its recall on `"mixed"` reviews is 0%. In production, that model will mislabel every single ambivalent critique as either ecstatic praise or hostile rejection, corrupting user recommendations. By mastering multi-class evaluation metrics, data scientists identify blind spots that global accuracy scores hide.

## 4. Concept Explanation
### Deconstructing the Metrics for Multi-Class Tasks
In a 3-class problem ($\{\text{mixed}, \text{negative}, \text{positive}\}$), metrics are calculated by treating each class $C$ as "positive" and all other classes as "negative" (One-vs-Rest):

1. **Precision for Class $C$:**
   $$\text{Precision}_C = \frac{\text{True Positives}_C}{\text{True Positives}_C + \text{False Positives}_C}$$
   *Interpretation:* "When the model predicts mood $C$, how often is it actually mood $C$?"
2. **Recall for Class $C$:**
   $$\text{Recall}_C = \frac{\text{True Positives}_C}{\text{True Positives}_C + \text{False Negatives}_C}$$
   *Interpretation:* "Out of all actual reviews with ground-truth mood $C$, what fraction did the model catch?"
3. **F1-Score for Class $C$:**
   The harmonic mean of precision and recall:
   $$\text{F1}_C = 2 \cdot \frac{\text{Precision}_C \cdot \text{Recall}_C}{\text{Precision}_C + \text{Recall}_C}$$
   The harmonic mean penalizes extreme imbalances between precision and recall.
4. **Support:**
   The actual ground-truth count of samples belonging to class $C$ in the test set.

### Averaging Across Multiple Classes
To summarize performance across all three classes into a single benchmark, scikit-learn provides two primary aggregation strategies:
- **Macro Average:** Computes the unweighted arithmetic mean of the metric across all classes:
  $$\text{Macro Precision} = \frac{\text{Precision}_{\text{mixed}} + \text{Precision}_{\text{neg}} + \text{Precision}_{\text{pos}}}{3}$$
  Macro averaging treats all classes equally, regardless of sample size.
- **Weighted Average:** Computes the mean weighted by the support of each class:
  $$\text{Weighted Precision} = \sum_{k} \left( \frac{\text{Support}_k}{N_{\text{total}}} \cdot \text{Precision}_k \right)$$
  Weighted averaging accounts for class imbalance in the test partition.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 43-50 compute and print the evaluation suite:
```python
    predictions = model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)

    print("=" * 60)
    print("THE MOVIE REVIEW MOOD RING")
    print("=" * 60)
    print(f"Accuracy: {accuracy:.1%}\n")
    print(classification_report(y_test, predictions, zero_division=0))
```
When executed, this code outputs:
```text
Accuracy: 100.0%

              precision    recall  f1-score   support

       mixed       1.00      1.00      1.00         7
    negative       1.00      1.00      1.00         8
    positive       1.00      1.00      1.00         8

    accuracy                           1.00        23
   macro avg       1.00      1.00      1.00        23
weighted avg       1.00      1.00      1.00        23
```
Notice:
- `accuracy_score(y_test, predictions)`: $\frac{23}{23} = 1.000$ (100.0%).
- `support`: Exactly 7 mixed, 8 negative, and 8 positive reviews (total 23 test reviews).
- `zero_division=0`: Explicitly prevents warnings or division-by-zero errors if any class had zero predictions.

## 6. Worked Example
Suppose a model was tested on a dataset of 20 reviews with the following hypothetical results:
- Class `positive`: True Positives = 6, False Positives = 1, False Negatives = 2, Support = 8.
- Precision: $\frac{6}{6 + 1} = \frac{6}{7} \approx 0.857$.
- Recall: $\frac{6}{6 + 2} = \frac{6}{8} = 0.750$.
- F1-Score: $2 \cdot \frac{0.857 \times 0.750}{0.857 + 0.750} = 2 \cdot \frac{0.64275}{1.607} = \mathbf{0.800}$.

In our actual Movie Mood Ring project, every single test prediction is correct, meaning False Positives = 0 and False Negatives = 0 across all three classes, resulting in 1.00 (100%) precision, recall, and F1 across the board.

## 7. Step-by-Step Student Instructions
1. Run `python main.py` in your terminal.
2. Locate the printed `classification_report` table.
3. Verify that the sum of the numbers in the `support` column equals the total test sample count ($7 + 8 + 8 = 23$).
4. Calculate the unweighted macro average of the three F1-scores manually: $\frac{1.00 + 1.00 + 1.00}{3} = 1.00$.
5. Inspect the `predictions.txt` file in `outputs/` to verify that the report was also saved to disk.

## 8. Expected Output or Observable Behaviour
Console printout from running `main.py`:
```text
Accuracy: 100.0%

              precision    recall  f1-score   support

       mixed       1.00      1.00      1.00         7
    negative       1.00      1.00      1.00         8
    positive       1.00      1.00      1.00         8

    accuracy                           1.00        23
   macro avg       1.00      1.00      1.00        23
weighted avg       1.00      1.00      1.00        23
```
This confirms that the model generalizes cleanly to all 23 held-out reviews.

## 9. Practical Exercises (with Success Criteria)
- **Task 1.1:** If a model has 8 positive test reviews, predicting 7 correctly as positive and 1 incorrectly as mixed, calculate the precision and recall for the positive class (assuming no other reviews were predicted as positive).
- **Task 1.2:** Explain why an executive reading an aggregate accuracy of 95% might still be dissatisfied if the macro-averaged recall across minor classes is only 40%.
- *Success Criteria:* Precision calculated as 100% ($\frac{7}{7}$), recall as 87.5% ($\frac{7}{8}$); explanation highlights that global accuracy can hide total failure on rare critical classes.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Relying solely on overall accuracy for evaluation | Hides class-specific failure modes when classes are imbalanced | Always inspect per-class precision, recall, and macro averages. |
| Forgetting `zero_division=0` in `classification_report` | Emits ugly runtime warnings or crashes if a class receives zero predictions | `zero_division=0` sets undefined metrics to 0.0 cleanly. |
| Confusing macro average with weighted average | Macro treats rare and common classes equally; weighted weights by support | Use macro average when performance on all classes is equally important. |

## 11. Best Practices and Code Quality
- Always output the full `classification_report` alongside a headline accuracy percentage.
- Inspect the `support` column to verify that test splits contain adequate sample counts for every class.
- Persist evaluation reports to automated text files for CI/CD tracking.

## 12. Security, Ethics, and Fair AI Considerations
A model that achieves high overall accuracy by systematically misclassifying nuanced feedback can silence thoughtful criticism. Evaluating per-class recall ensures that ambivalent or minority viewpoints are faithfully captured.

## 13. Summary and Key Takeaways
Multi-class model evaluation requires examining precision, recall, F1-score, and support across every individual class. Macro and weighted averages summarize multi-class performance into holistic indicators. In the Movie Review Mood Ring, the model achieves 100% precision, recall, and F1 across all 23 test samples.

## 14. Knowledge Check Questions
1. What does the `support` column in a scikit-learn classification report represent?
2. What is the mathematical difference between macro average and weighted average?
3. What are the support values for mixed, negative, and positive classes in `main.py`?
4. What does the parameter `zero_division=0` accomplish?

## 15. References and Further Reading
- Scikit-learn Documentation: `classification_report` (https://scikit-learn.org/stable/modules/generated/sklearn.metrics.classification_report.html).
- Powers, D. M. (2011). *Evaluation: from precision, recall and F-measure to ROC, informedness, markedness and correlation.*
