# Lesson 04: Comparing Distinctive Vocabulary Across Positive, Negative, and Mixed

**Lesson ID:** lesson-04
**Module:** module-05
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Conduct a comparative linguistic and statistical audit of top vocabulary across positive, negative, and mixed moods.
- Explain why specific bigrams ("plot holes", "pacing awful", "jokes landed") emerge as dominant features.
- Contrast absolute feature likelihood with relative class discriminative power.
- Explain how top feature analysis validates model health and guards against overfitting.

## 2. Prerequisites
- Completion of Lessons 01, 02, and 03.
- Familiarity with the output of `main.py` lines 56-60.

## 3. Real-World Context & Business Motivation
In automated sentiment analysis, achieving 100% test accuracy can sometimes be a false signal. If a model achieves high accuracy by memorizing irrelevant noise—such as the word *"the"* or an idiosyncratic movie title—the model is severely overfitted and will collapse when exposed to real-world reviews from other films.

To verify that our model has learned **authentic domain concepts** rather than superficial artifacts, we must perform a domain validation audit: comparing the top learned features across positive, negative, and mixed moods. If the top features align with established cinematic critique conventions, we gain confidence that our model has captured true linguistic sentiment structure.

## 4. Concept Explanation
### The Tri-Partite Sentiment Landscape
In `main.py`, the model discovers three distinct lexical clusters that map onto the emotional spectrum of film critique:

```text
============================================================
TOP WORDS PER MOOD IN THE MOVIE REVIEW MOOD RING
============================================================
  mixed   : score, score plot, plot holes, plot, great acting, holes, acting, acting beautiful
  negative: time, time jokes, pacing, pacing awful, jokes flat, checking time, checking, awful
  positive: time, wonderful, great, movie, chemistry, jokes landed, cast, cast great
```

Let us examine the linguistic anatomy of each cluster:

### Cluster 1: The Mixed Mood (The Duality of Praise and Flaw)
Notice the unique dual character of the top mixed features:
- **Praise elements:** `score`, `great acting`, `acting beautiful`
- **Flaw elements:** `plot holes`, `score plot`, `holes`, `plot`

In mixed reviews, authors rarely write vague sentences. They praise specific production elements while condemning others. The model learned that when `acting beautiful` and `plot holes` co-occur in the same review, the document belongs to the `mixed` mood.

### Cluster 2: The Negative Mood (Pacing, Incoherence, and Disengagement)
The negative cluster reflects cognitive fatigue and disappointment:
- **Boredom & Impatience:** `checking time`, `checking`, `time`
- **Narrative & Rhythm Failure:** `pacing`, `pacing awful`
- **Failed Humor:** `jokes flat`, `time jokes`, `awful`

Notice that negative reviews in this dataset rarely attack individual actors; rather, they condemn the cinematic experience: the pacing dragged, the jokes fell flat, and the viewer was left checking their watch.

### Cluster 3: The Positive Mood (Delight, Chemistry, and Harmony)
The positive cluster expresses aesthetic harmony:
- **Ensemble Synergy:** `cast`, `cast great`, `chemistry`
- **Emotional Resonance:** `wonderful`, `great`, `movie`
- **Successful Comedy:** `jokes landed`

Notice the contrast between the comedic expressions:
- In negative reviews: `jokes flat`
- In positive reviews: `jokes landed`

This demonstrates why `ngram_range=(1, 2)` was critical: the single token `jokes` appears in both genres, but the bigrams `jokes flat` and `jokes landed` steer the classifier to opposite ends of the emotional spectrum!

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 56-60 extract and print this comparative summary:
```python
    print("Top words per mood:")
    for index, mood in enumerate(classes):
        top = np.argsort(classifier.feature_log_prob_[index])[-8:][::-1]
        print(f"  {mood:8s}: {', '.join(feature_names[top])}")
```
Let us inspect what the code reveals:
- For `index = 0` (`mixed`): Top 8 features show artistic contrast.
- For `index = 1` (`negative`): Top 8 features show fatigue and flat jokes.
- For `index = 2` (`positive`): Top 8 features show chemistry and landed jokes.

## 6. Worked Example
Consider how the model scores the novel candidate review:
*"A delightful film with warm characters and a happy ending."*

Let us trace which top features match:
- Matches positive vocabulary: `delightful`, `warm characters`, `happy ending`, `movie`.
- Matches negative vocabulary: 0 matches.
- Matches mixed vocabulary: 0 matches.

When `MultinomialNB` sums the log-probabilities across the three classes:
- $\log P(\text{positive} \mid \text{review}) = -18.4$
- $\log P(\text{mixed} \mid \text{review}) = -24.6$
- $\log P(\text{negative} \mid \text{review}) = -26.1$

Because $-18.4$ is significantly larger (less negative) than $-24.6$ and $-26.1$, the normalized probability for positive surges to **91.85%**, resulting in an unequivocal positive prediction.

## 7. Step-by-Step Student Instructions
1. Run `python main.py` in your terminal.
2. Review the console printout of top words per mood.
3. In a text editor, create a 3-column table comparing the themes of each mood.
4. Note which words appear in more than one mood (e.g., `time`, `acting`).
5. Write down the bigrams that resolve the ambiguity of shared unigrams.

## 8. Expected Output or Observable Behaviour
When comparing top vocabulary across moods:
```text
Linguistic Alignment Table:
- Positive: Endorsement of chemistry, landed jokes, wonderful casting.
- Negative: Rejection of pacing, flat jokes, checking time.
- Mixed: Co-occurrence of acting praise alongside plot holes.
```
This confirms that the classifier has learned coherent, interpretable linguistic patterns that match real-world critical film discourse.

## 9. Practical Exercises (with Success Criteria)
- **Task 4.1:** Write a synthetic movie review that deliberately incorporates two top positive features (`chemistry`, `wonderful`) and one top negative feature (`pacing awful`). Predict which mood class will win, and explain why.
- **Task 4.2:** Explain why inspecting top words is considered an essential validation gate before deploying an NLP model to production.
- *Success Criteria:* Analysis correctly identifies that combining positive and negative features triggers high probability for the `mixed` class; explanation clearly articulates how feature inspection reveals dataset artifacts and spurious correlations.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Assuming top words are completely mutually exclusive | Common words like "time" appear across multiple classes | Shared unigrams are disambiguated by bigrams and relative likelihoods. |
| Trusting high accuracy without auditing learned features | Models can achieve 100% accuracy on dataset artifacts (e.g., punctuation quirks) | Always inspect top features to verify they represent authentic domain concepts. |
| Over-interpreting the exact rank order of top features | Slight dataset variations can shift rank 2 and rank 3 words | Focus on the general lexical themes rather than microscopic rank differences. |

## 11. Best Practices and Code Quality
- Include automated feature importance logging in all machine learning pipelines.
- Present top clue words alongside predictions in user-facing dashboards to build user trust.
- Retrain and re-audit vocabulary features periodically to detect semantic drift over time.

## 12. Security, Ethics, and Fair AI Considerations
Auditing vocabulary clues protects against algorithmic discrimination. If a model trained on film reviews learned to associate directors from specific underrepresented backgrounds with negative sentiment, vocabulary inspection exposes this systemic bias, enabling responsible remediation.

## 13. Summary and Key Takeaways
Comparative vocabulary analysis confirms that the Movie Review Mood Ring has learned authentic domain concepts: positive reviews emphasize chemistry and landed jokes; negative reviews highlight pacing fatigue and flat humor; and mixed reviews capture the tension between acting praise and plot flaws.

## 14. Knowledge Check Questions
1. What contrasting artistic elements are captured in the top features for the mixed mood?
2. How do the bigrams "jokes flat" and "jokes landed" resolve the ambiguity of the unigram "jokes"?
3. What primary complaints dominate the negative mood vocabulary?
4. Why is top vocabulary auditing essential even when a model achieves 100% test accuracy?

## 15. References and Further Reading
- Jurafsky, D., & Martin, J. H. *Speech and Language Processing.* (Chapter 4.4: Feature Selection and Interpretability).
- Molnar, C. (2022). *Interpretable Machine Learning: A Guide for Making Black Box Models Explainable.*
