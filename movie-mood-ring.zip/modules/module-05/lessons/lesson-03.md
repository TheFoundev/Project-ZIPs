# Lesson 03: Decoding feature_log_prob_ to Extract Top Clue Words

**Lesson ID:** lesson-03
**Module:** module-05
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain what the attribute `classifier.feature_log_prob_` represents in a fitted `MultinomialNB` model.
- Use NumPy's `np.argsort()` to rank vocabulary features by statistical importance.
- Align numerical column indices with human-readable word tokens using `vectorizer.get_feature_names_out()`.
- Extract and format the top $K$ most probable words for any target mood class.

## 2. Prerequisites
- Completion of Lessons 01 and 02.
- Basic understanding of NumPy array indexing and sorting (`np.argsort`).

## 3. Real-World Context & Business Motivation
In many commercial machine learning projects, stakeholders are not satisfied with a black-box model that merely outputs predictions. Film directors, studio marketing executives, and content creators want to know **why** the model made a prediction. What specific words or phrases convinced the AI that audiences felt mixed about the movie?

Fortunately, Naive Bayes is an intrinsically interpretable model. Because it explicitly estimates the probability of every word given each class, we can open the model's internal parameter tables and inspect its learned vocabulary distributions directly. In this lesson, we will decode `feature_log_prob_` to extract the most influential vocabulary clues that drive the model's decisions.

## 4. Concept Explanation
### What is `feature_log_prob_`?
When `MultinomialNB` trains, it computes the smoothed conditional probability of every feature for every class:
$$P(w_j \mid C_i) = \frac{N_{C_i, j} + \alpha}{N_{C_i} + \alpha \cdot |V|}$$
To prevent numerical underflow, scikit-learn stores the natural logarithm of this value:
$$\text{feature\_log\_prob\_}[i, j] = \log P(w_j \mid C_i)$$

The attribute `classifier.feature_log_prob_` is a 2D NumPy array:
- Number of rows: 3 (corresponding to `classifier.classes_`: `mixed`, `negative`, `positive`).
- Number of columns: 254 (corresponding to the 254 vocabulary tokens in `vectorizer`).

Higher (less negative) values in `feature_log_prob_[i]` correspond to words that occur with higher frequency within class $i$.

### Sorting with NumPy argsort
To find the top words for a class, we need to sort the log-probabilities from largest to smallest.
In Python and NumPy:
- `np.argsort(array)`: Returns the array of *indices* that would sort the array in **ascending** order (smallest to largest).
- Slicing `[-8:]`: Extracts the indices of the 8 largest elements.
- Slicing `[::-1]`: Reverses the extracted slice so the very largest element comes first (descending order).

Combining these operations:
```python
top_indices = np.argsort(classifier.feature_log_prob_[index])[-8:][::-1]
```
`top_indices` now contains the 8 column numbers corresponding to the most frequent and diagnostic features for class `index`.

### Mapping Indices to Word Strings
To convert column numbers (e.g., `42`, `105`) into human-readable words, we use:
```python
feature_names = vectorizer.get_feature_names_out()
top_words = feature_names[top_indices]
```
`feature_names` maps every column index $j$ back to its exact unigram or bigram string.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 52-60 implement this exact feature extraction logic:
```python
    vectorizer = model.named_steps["vectorizer"]
    classifier = model.named_steps["classifier"]
    feature_names = vectorizer.get_feature_names_out()
    classes = list(classifier.classes_)
    print("Top words per mood:")
    for index, mood in enumerate(classes):
        top = np.argsort(classifier.feature_log_prob_[index])[-8:][::-1]
        print(f"  {mood:8s}: {', '.join(feature_names[top])}")
```
Let us trace what this loop does:
1. `enumerate(classes)` iterates through index `0` (`mixed`), `1` (`negative`), and `2` (`positive`).
2. For each class, it finds the 8 highest log-probability feature indices using `np.argsort(...)`.
3. It retrieves the word strings from `feature_names[top]` and prints them formatted as a clean comma-separated list.

## 6. Worked Example
Let us trace this step-by-step on a mini toy model:
- `feature_names`: `["acting", "boring", "delightful", "plot"]`
- `feature_log_prob_[0]` (for positive class): `[-2.5, -6.1, -1.8, -3.2]`

1. **Apply `np.argsort`:**
   Sorting `[-2.5, -6.1, -1.8, -3.2]` from smallest to largest:
   - Smallest is index 1 (`-6.1`)
   - Next is index 3 (`-3.2`)
   - Next is index 0 (`-2.5`)
   - Largest is index 2 (`-1.8`)
   `np.argsort(...)` returns `[1, 3, 0, 2]`.
2. **Extract Top 2 and Reverse (`[-2:][::-1]`):**
   - Last two indices: `[0, 2]`
   - Reversed: `[2, 0]`
3. **Map to Words:**
   - Index 2 $\implies$ `"delightful"`
   - Index 0 $\implies$ `"acting"`
   Result: `"delightful, acting"`!

The top learned clue words for the positive class are `"delightful"` and `"acting"`.

## 7. Step-by-Step Student Instructions
1. Open Python interactive shell in the project directory.
2. Load the project pipeline:
   ```python
   # Run the training steps from main.py
   from main import main
   # Or extract model manually
   vec = model.named_steps["vectorizer"]
   clf = model.named_steps["classifier"]
   names = vec.get_feature_names_out()
   ```
3. Print the top 3 features for class 0 (`mixed`):
   ```python
   top_mixed = np.argsort(clf.feature_log_prob_[0])[-3:][::-1]
   print("Top 3 mixed words:", names[top_mixed])
   print("Their log probabilities:", clf.feature_log_prob_[0][top_mixed])
   ```
4. Verify that the log-probabilities are the least negative values in that row.

## 8. Expected Output or Observable Behaviour
Console printout:
```text
Top words per mood:
  mixed   : score, score plot, plot holes, plot, great acting, holes, acting, acting beautiful
  negative: time, time jokes, pacing, pacing awful, jokes flat, checking time, checking, awful
  positive: time, wonderful, great, movie, chemistry, jokes landed, cast, cast great
```
Notice how each mood class reveals its core vocabulary signatures:
- `mixed` is dominated by artistic components (`score`, `plot`, `acting`) paired with critique tokens (`holes`).
- `negative` is dominated by pacing complaints (`time`, `pacing awful`, `jokes flat`).
- `positive` is dominated by aesthetic praise (`wonderful`, `chemistry`, `jokes landed`).

## 9. Practical Exercises (with Success Criteria)
- **Task 3.1:** Write a Python function `get_top_features(model, n=5)` that returns a dictionary mapping each mood class name to a list of its top $n$ features.
- **Task 3.2:** Explain why `time` appears in both `negative` and `positive` top words, and identify the bigrams that disambiguate it.
- *Success Criteria:* Function correctly implements `np.argsort`; explanation identifies that "time" is ambiguous alone, but disambiguated by bigrams like "checking time" (negative) and "every time" (positive).

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Forgetting `[::-1]` after slicing `[-8:]` | Lists the 8th-best word first and the 1st-best word last | Slicing `[-8:]` extracts ascending order; `[::-1]` reverses to descending order. |
| Using `np.sort` instead of `np.argsort` | Returns the sorted floating-point numbers instead of the integer indices | `np.argsort` returns indices needed to look up words in `feature_names`. |
| Indexing `feature_names` with raw floats | Raises `IndexError: arrays used as indices must be of integer type` | Only integer index arrays from `argsort` can slice `feature_names`. |

## 11. Best Practices and Code Quality
- Use `get_feature_names_out()` (modern scikit-learn standard) rather than the deprecated `get_feature_names()`.
- Format feature printouts with fixed column widths (`f"{mood:8s}"`) for clean terminal alignment.
- When explaining model behavior to non-technical stakeholders, present top words as evidence of model reasoning.

## 12. Security, Ethics, and Fair AI Considerations
Feature inspection is a cornerstone of Explainable AI (XAI). Inspecting top predictive words allows engineers to audit models for spurious correlations (e.g., if a model learned to associate a specific actor's name with negative reviews due to dataset bias) and remove biased features before production release.

## 13. Summary and Key Takeaways
Scikit-learn's `MultinomialNB` stores log feature likelihoods in `classifier.feature_log_prob_`. By applying `np.argsort(classifier.feature_log_prob_[index])[-K:][::-1]` and indexing `vectorizer.get_feature_names_out()`, we extract the top $K$ predictive vocabulary clues for each mood class, unlocking complete model interpretability.

## 14. Knowledge Check Questions
1. What does each cell `[i, j]` in `classifier.feature_log_prob_` store?
2. What is the difference between `np.sort()` and `np.argsort()`?
3. Why is the slice `[-8:][::-1]` used when extracting the top 8 features?
4. What method on `CountVectorizer` returns the array of vocabulary strings?

## 15. References and Further Reading
- NumPy Documentation: `np.argsort` (https://numpy.org/doc/stable/reference/generated/numpy.argsort.html).
- Ribeiro, M. T., Singh, S., & Guestrin, C. (2016). *"Why Should I Trust You?": Explaining the Predictions of Any Classifier.* KDD.
