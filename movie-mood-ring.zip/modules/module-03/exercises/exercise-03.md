# Module 3 Exercises: Text Vectorization & Feature Engineering

## Exercise 3.1: Manual Document-Term Matrix Computation (10 min)
**Objective:** Manually compute token counts, dictionary mappings, and document-term row vectors for a small text corpus.

**Problem Statement:** Given the following three mini-reviews:
- Review 1: *"delightful acting"*
- Review 2: *"boring acting"*
- Review 3: *"delightful story"*
Calculate the vocabulary mapping, document-term matrix dimensions, and row representations by hand.

**Requirements:**
1. Extract the unique tokens in alphabetical order and assign zero-based indices.
2. State the matrix dimensions $(N 	imes V)$.
3. Write down the 2D matrix array as a Python list of lists.
4. Verify your manual calculations using `CountVectorizer` in Python.

**Constraints:** Treat all words in lowercase and assume no stop words are filtered for this mini corpus.

**Expected Behaviour:** A step-by-step arithmetic derivation matching `CountVectorizer.toarray()`.

**Acceptance Criteria:**
- [ ] Vocabulary identified: `{'acting': 0, 'boring': 1, 'delightful': 2, 'story': 3}`.
- [ ] Matrix dimensions correctly stated as $3 	imes 4$.
- [ ] Matrix rows calculated as:
  - Row 1: `[1, 0, 1, 0]`
  - Row 2: `[1, 1, 0, 0]`
  - Row 3: `[0, 0, 1, 1]`

**Hints:**
- Alphabetize tokens before assigning column numbers.
- Count occurrences of each token per document.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes

---

## Exercise 3.2: Stop Word Pruning Impact Analysis (15 min)
**Objective:** Measure the mathematical and vocabulary impact of activating `stop_words="english"` on the movie review dataset.

**Problem Statement:** Write a Python evaluation script that loads `data/movie_reviews.csv` and compares `CountVectorizer(ngram_range=(1, 2))` with and without `stop_words="english"`.

**Requirements:**
1. Instantiate two vectorizers: one with `stop_words="english"` and one without `stop_words`.
2. Fit both on `df["review"]`.
3. Compare total vocabulary size, number of unigrams, and number of bigrams between both configurations.
4. Extract 5 common bigrams present in the unpruned vectorizer that consist purely of stop words (e.g., "in the", "it was") and explain why they waste model capacity.

**Constraints:** Use standard scikit-learn and pandas methods.

**Expected Behaviour:** A comparative analysis script that outputs a clean Markdown table summarizing feature dimensions.

**Acceptance Criteria:**
- [ ] Accurately measures vocabulary expansion when stop words are retained.
- [ ] Demonstrates that unpruned models create useless bigrams like "and the", "was a".
- [ ] Explains how stop word pruning concentrates model weights on expressive adjectives.

**Hints:**
- Review Lesson 02 on stop words elimination.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 3.3: Dissecting Negation & Context Preservation with N-Grams (15 min)
**Objective:** Contrast unigram and bigram feature representations for sentiment sentences containing linguistic negation.

**Problem Statement:** Consider two movie review sentences:
- Sentence A: *"I recommend this movie."*
- Sentence B: *"I would not recommend this movie."*
Demonstrate computationally why a unigram model struggles to separate their sentiment, and show how `ngram_range=(1, 2)` solves the challenge.

**Requirements:**
1. Fit a `CountVectorizer(ngram_range=(1, 1))` on the two sentences and display the resulting matrix.
2. Fit a `CountVectorizer(ngram_range=(1, 2))` on the two sentences and display the resulting matrix.
3. Identify the specific bigram token that distinguishes Sentence B from Sentence A.
4. Explain how a Naive Bayes classifier assigns opposite weights to `recommend` vs `not recommend`.

**Constraints:** Explain the mathematical mechanism of feature assignment.

**Expected Behaviour:** A concise technical report illustrating the vector representations and explaining how bigrams resolve polarity inversion.

**Acceptance Criteria:**
- [ ] Shows that under unigrams, both sentences share the token `recommend`.
- [ ] Demonstrates that under bigrams, Sentence B acquires unique tokens like `not recommend`.
- [ ] Explains how the presence of `not recommend` enables the classifier to separate positive praise from decisive rejection.

**Hints:**
- Notice what happens to "not" if stop words are enabled vs disabled. How does scikit-learn handle "not" in bigrams?

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 3.4: Sparse Matrix Storage & Memory Scaling Audit (20 min)
**Objective:** Analyze memory scaling and sparsity calculations for large-scale NLP corpora using SciPy sparse matrices.

**Problem Statement:** A media intelligence company plans to scale the Movie Review Mood Ring classifier to process 5,000,000 streaming reviews per day, with an estimated vocabulary of 100,000 n-gram features and an average of 20 non-zero features per review. Conduct a memory scaling audit comparing dense NumPy arrays to SciPy CSR sparse matrices.

**Requirements:**
1. Calculate the theoretical memory required to store the full $5,000,000 	imes 100,000$ matrix as a standard 64-bit float NumPy dense array (in gigabytes or terabytes).
2. Calculate the sparsity percentage of this matrix.
3. Calculate the memory required to store the matrix as a SciPy `csr_matrix` storing 64-bit float data values, 32-bit integer indices, and 64-bit row pointers.
4. Write a brief executive summary explaining why sparse matrix structures are mandatory for production NLP systems.

**Constraints:** Show all arithmetic steps clearly ($1	ext{ GB} = 10^9	ext{ bytes}$, $1	ext{ TB} = 10^{12}	ext{ bytes}$).

**Expected Behaviour:** A formal engineering memo with precise memory calculations and hardware recommendations.

**Acceptance Criteria:**
- [ ] Dense memory calculated as $5 	imes 10^6 	imes 10^5 	imes 8	ext{ bytes} = 4 	imes 10^{12}	ext{ bytes} = 4.0	ext{ TB}$.
- [ ] Sparsity calculated as $1 - rac{20}{100,000} = 99.98\%$.
- [ ] Sparse memory calculated for $10^8$ non-zeros ($8	ext{ bytes data} + 4	ext{ bytes indices} = 12	ext{ bytes} 	imes 10^8 = 1.2	ext{ GB} + 	ext{pointers} pprox 1.24	ext{ GB}$).
- [ ] Explains that sparse matrices reduce RAM requirements from an impossible 4 TB cluster to a standard 2 GB laptop instance.

**Hints:**
- Review Lesson 04 on Document-Term Matrices and SciPy CSR sparse mechanics.

**Difficulty:** Advanced  
**Estimated Completion Time:** 20 minutes
