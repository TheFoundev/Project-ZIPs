# Lesson 01: The Bag-of-Words Representation for Movie Reviews

**Lesson ID:** lesson-01
**Module:** module-03
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain the fundamental limitation that prevents machine learning algorithms from processing raw strings directly.
- Describe the Bag-of-Words (BoW) text representation and how it transforms text into fixed-length numeric vectors.
- Trace the three core steps of BoW: tokenization, vocabulary assembly, and frequency counting.
- Understand the trade-offs of BoW (discarding word order and syntax while preserving lexical occurrence frequencies).

## 2. Prerequisites
- Completion of Module 02.
- Basic understanding of vectors, matrices, and arrays in Python.

## 3. Real-World Context & Business Motivation
Machine learning algorithms—whether linear classifiers, neural networks, or Naive Bayes estimators—are purely mathematical engines. They compute dot products, calculate likelihood probabilities, and multiply floating-point numbers. They have no innate capacity to ingest a raw English string such as *"A delightful film with warm characters"*.

To bridge the gap between human language and linear algebra, Natural Language Processing requires a vectorization layer: a mathematical mapping that converts variable-length text documents into structured numerical vectors of uniform dimension. In the Movie Review Mood Ring, the foundational vectorization technique is the **Bag-of-Words (BoW)** model. Despite its conceptual simplicity, BoW remains one of the most effective and computationally efficient baseline techniques for text classification.

## 4. Concept Explanation
### What is the "Bag-of-Words"?
Imagine taking a printed movie review, cutting out every word with scissors, and tossing all the individual words into a physical burlap bag. In doing so:
1. You completely discard the grammatical syntax, sentence structure, and original word order.
2. You retain the exact count of how many times each unique word appears in the bag.

The central hypothesis of the Bag-of-Words model is that **the distribution and frequency of vocabulary words alone carries substantial semantic signal**. A review containing the words *"delightful"*, *"warm"*, and *"smiling"* is overwhelmingly likely to express a positive mood, regardless of the grammatical structure of the sentence.

### The Mechanics of Vectorization
Vectorizing a corpus of documents via Bag-of-Words involves three deterministic phases:
1. **Tokenization & Normalization:** Splitting text documents into individual word tokens, removing punctuation, and converting all characters to lowercase (so that *"Great"*, *"great"*, and *"GREAT"* map to the identical token).
2. **Vocabulary Building:** Scanning all training documents to compile a master dictionary of unique tokens, assigning each token a unique column index $j \in \{0, 1, \dots, V-1\}$, where $V$ is vocabulary size.
3. **Vector Construction:** Transforming each document $i$ into a $V$-dimensional row vector $\mathbf{x}_i$, where each component $x_{ij}$ represents the count of token $j$ in document $i$.

### Trade-offs of the BoW Model
While BoW is fast, interpretable, and computationally lightweight, it has well-known limitations:
- **Loss of Syntax & Word Order:** *"The film was not bad, it was good"* and *"The film was not good, it was bad"* contain identical words and thus produce identical BoW representations, despite expressing opposite sentiments.
- **High Dimensionality:** As vocabulary grows, feature vectors become wide and predominantly filled with zeros.

As we will see in Lesson 03, incorporating **n-grams** mitigates the word order limitation.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 36-41 construct the vectorization and modeling pipeline:
```python
    model = Pipeline(
        [
            ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
            ("classifier", MultinomialNB()),
        ]
    )
    model.fit(X_train, y_train)
```
- `CountVectorizer` is scikit-learn's premier implementation of the Bag-of-Words model.
- When `model.fit(X_train, y_train)` is executed, `CountVectorizer` reads the 67 training reviews, establishes the vocabulary dictionary, and builds the document-term matrix.

## 6. Worked Example
Let us trace BoW vectorization on a toy corpus of 3 mini-reviews:
- Doc 1: *"Great movie, loved it."*
- Doc 2: *"Boring movie, hated it."*
- Doc 3: *"Great acting, but boring plot."*

**Step 1: Normalization & Tokenization:**
- Doc 1: `[great, movie, loved, it]`
- Doc 2: `[boring, movie, hated, it]`
- Doc 3: `[great, acting, but, boring, plot]`

**Step 2: Master Vocabulary (Alphabetical):**
`{acting: 0, boring: 1, but: 2, great: 3, hated: 4, it: 5, loved: 6, movie: 7, plot: 8}` ($V = 9$).

**Step 3: Document Vectors ($1 	imes 9$):**
- Doc 1: `[0, 0, 0, 1, 0, 1, 1, 1, 0]`
- Doc 2: `[0, 1, 0, 0, 1, 1, 0, 1, 0]`
- Doc 3: `[1, 1, 1, 1, 0, 0, 0, 0, 1]`

Each document is now a fixed 9-dimensional numerical array, ready for mathematical operations!

## 7. Step-by-Step Student Instructions
1. Open Python in your terminal.
2. Import `CountVectorizer` from `sklearn.feature_extraction.text`:
   ```python
   from sklearn.feature_extraction.text import CountVectorizer
   corpus = [
       "Great movie, loved it.",
       "Boring movie, hated it.",
       "Great acting, but boring plot."
   ]
   vec = CountVectorizer()
   X = vec.fit_transform(corpus)
   print("Vocabulary:", vec.vocabulary_)
   print("Matrix array:
", X.toarray())
   ```
3. Observe how each word is assigned an integer index and each sentence becomes a row vector of 1s and 0s.

## 8. Expected Output or Observable Behaviour
Console output from the interactive session:
```text
Vocabulary: {'great': 3, 'movie': 7, 'loved': 6, 'it': 5, 'boring': 1, 'hated': 4, 'acting': 0, 'but': 2, 'plot': 8}
Matrix array:
 [[0 0 0 1 0 1 1 1 0]
  [0 1 0 0 1 1 0 1 0]
  [1 1 1 1 0 0 0 0 1]]
```
Notice how `X.toarray()` matches our manual worked example perfectly.

## 9. Practical Exercises (with Success Criteria)
- **Task 1.1:** Vectorize the sentence *"A boring, confusing mess. I kept checking the time."* using the toy vocabulary above. Explain why words like "confusing" and "time" result in zero columns if they were not in the vocabulary.
- **Task 1.2:** Write a 2-paragraph critique of why the Bag-of-Words representation fails on sarcastic reviews like *"Oh wonderful, another masterpiece that put me to sleep."*
- *Success Criteria:* Explanations clearly demonstrate that BoW counts tokens without understanding context, negation, or tonal sarcasm.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Calling `fit_transform` on test data | Causes catastrophic data leakage by updating the vocabulary with test words | Call `fit` or `fit_transform` ONLY on training data; call `transform` on test data. |
| Expecting BoW to preserve sentence grammar | BoW explicitly discards word order and syntax | BoW is a frequency-based bag representation, not a syntactic tree parser. |
| Forgetting that out-of-vocabulary (OOV) words are ignored | New words in unseen reviews that were absent during training contribute 0 counts | BoW models can only evaluate features that existed in the training dictionary. |

## 11. Best Practices and Code Quality
- Always encapsulate vectorization inside a scikit-learn `Pipeline` to ensure `fit` is only called on training folds.
- Lowercase all tokens during preprocessing to prevent vocabulary fragmentation across uppercase variants.
- Strip trailing whitespace and normalize unicode characters.

## 12. Security, Ethics, and Fair AI Considerations
Bag-of-Words models are vulnerable to keyword-stuffing attacks: an adversary can repeatedly inject positive keywords into a negative review to trick the classifier. Security-conscious deployments pair BoW classifiers with text length ratios and token diversity checks.

## 13. Summary and Key Takeaways
The Bag-of-Words model converts variable-length text into fixed-length numeric vectors by counting token occurrences against a learned vocabulary dictionary. While it discards syntax and word order, it provides an effective, fast, and transparent foundation for text classification.

## 14. Knowledge Check Questions
1. Why cannot machine learning algorithms process raw English strings directly?
2. What are the three primary steps of the Bag-of-Words model?
3. What happens to words in a new review that did not exist in the training vocabulary?
4. What is the fundamental linguistic limitation of discarding word order?

## 15. References and Further Reading
- Scikit-learn Documentation: `CountVectorizer` (https://scikit-learn.org/stable/modules/generated/sklearn.feature_extraction.text.CountVectorizer.html).
- Harris, Z. S. (1954). *Distributional structure.* Word, 10(2-3), 146-162.
