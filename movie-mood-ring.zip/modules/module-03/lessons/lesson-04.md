# Lesson 04: The Document-Term Matrix and Sparse Memory Management

**Lesson ID:** lesson-04
**Module:** module-03
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define the Document-Term Matrix (DTM) and describe its row and column dimensions.
- Calculate the sparsity percentage of a text feature matrix.
- Explain why standard dense NumPy arrays cause catastrophic memory exhaustion on large text corpora.
- Understand how SciPy Compressed Sparse Row (`csr_matrix`) data structures store sparse text data efficiently.

## 2. Prerequisites
- Completion of Lessons 01, 02, and 03.
- Basic understanding of 2D arrays, memory allocation, and matrix dimensions.

## 3. Real-World Context & Business Motivation
In natural language processing, when we transform hundreds or thousands of documents into a Bag-of-Words matrix, we encounter a fundamental structural property of human language: **sparsity**.

A typical vocabulary might contain 254 unique terms. However, any individual movie review is only 10 to 15 words long. That means in any given row of the feature matrix, roughly 10 cells contain non-zero word counts, while the remaining 244 cells are filled with zeros! If we store all those zeros in standard 64-bit floating point arrays, our programs waste 95% of their memory storing nothing.

In production NLP systems processing millions of reviews, storing text matrices as dense arrays would require terabytes of RAM, crashing servers. By understanding how scikit-learn leverages SciPy **sparse matrices**, we unlock high-speed, memory-efficient machine learning.

## 4. Concept Explanation
### The Document-Term Matrix (DTM)
The **Document-Term Matrix** is the foundational 2D data structure produced by `CountVectorizer`:
- **Rows ($N$):** Each row represents a single document (review). In our training set, $N = 67$.
- **Columns ($V$):** Each column represents a unique feature (unigram or bigram) in the vocabulary dictionary. In our training set, $V = 254$.
- **Cells ($M_{ij}$):** The integer count of feature $j$ occurring in document $i$.

The matrix dimensions are therefore:
$$\mathbf{X} \in \mathbb{R}^{67 	imes 254}$$

### What is Sparsity?
**Sparsity** measures the proportion of matrix cells that contain zero:
$$	ext{Sparsity} = 1 - rac{	ext{Number of Non-Zero Elements}}{	ext{Total Number of Elements}} = 1 - rac{	ext{NNZ}}{N 	imes V}$$

Let us calculate the exact sparsity for our project's training matrix:
- Total rows $N = 67$
- Total features $V = 254$
- Total cells $= 67 	imes 254 = 17,018$ cells
- Non-Zero Elements ($	ext{NNZ}$) $= 710$
- Number of zero cells $= 17,018 - 710 = 16,308$ zeros!

$$	ext{Sparsity} = 1 - rac{710}{17,018} = 1 - 0.04172 = 0.95828 \implies \mathbf{95.83\%}$$
Over 95.8% of the training matrix consists of zeros!

### How SciPy CSR Sparse Matrices Work
Rather than allocating memory for 16,308 useless zeros, `CountVectorizer` outputs a **Compressed Sparse Row (`csr_matrix`)** from the `scipy.sparse` library.

Instead of a $67 	imes 254$ grid, a CSR matrix stores only three compact 1D arrays:
1. `data`: The actual non-zero values (e.g., `[1, 1, 2, 1, ...]`).
2. `indices`: The column index for each non-zero value.
3. `indptr`: The index pointers marking where each row begins and ends in `data`.

By storing only the 710 non-zero values and their coordinates, memory usage drops by over 90%. Furthermore, mathematical operations like matrix multiplication skip all zero cells entirely, yielding massive speedups.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 36-42 instantiate and fit the pipeline:
```python
    model = Pipeline(
        [
            ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
            ("classifier", MultinomialNB()),
        ]
    )
    model.fit(X_train, y_train)
```
Behind the scenes, the `vectorizer` transforms `X_train` into a `scipy.sparse.csr_matrix` and feeds it directly into `MultinomialNB()`. Neither scikit-learn nor `main.py` ever converts the matrix to a dense NumPy array, maintaining maximum computational and memory efficiency throughout the lifecycle of the script.

## 6. Worked Example
Let us write a diagnostic Python script to inspect the sparse matrix structure produced by the project's vectorizer:
```python
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split

df = pd.read_csv("data/movie_reviews.csv")
X_train, X_test, y_train, y_test = train_test_split(
    df["review"], df["mood"], test_size=0.25, random_state=42, stratify=df["mood"]
)

vec = CountVectorizer(stop_words="english", ngram_range=(1, 2))
X_train_sparse = vec.fit_transform(X_train)

total_cells = X_train_sparse.shape[0] * X_train_sparse.shape[1]
nnz = X_train_sparse.nnz
sparsity = (1.0 - nnz / total_cells) * 100

print(f"Matrix Type: {type(X_train_sparse)}")
print(f"Matrix Shape: {X_train_sparse.shape}")
print(f"Non-Zero Elements (NNZ): {nnz}")
print(f"Total Elements: {total_cells}")
print(f"Matrix Sparsity: {sparsity:.2f}%")
```
**Console Output:**
```text
Matrix Type: <class 'scipy.sparse._csr.csr_matrix'>
Matrix Shape: (67, 254)
Non-Zero Elements (NNZ): 710
Total Elements: 17018
Matrix Sparsity: 95.83%
```

## 7. Step-by-Step Student Instructions
1. Open Python interactive shell in your project environment.
2. Replicate the code from the worked example above.
3. Access the first training review's sparse representation:
   ```python
   row_0 = X_train_sparse[0]
   print("Row 0 representation:
", row_0)
   print("Non-zeros in row 0:", row_0.nnz)
   ```
4. Observe that only the non-zero feature coordinates and counts are printed (e.g., `(0, 42) 1`, `(0, 105) 1`), completely omitting all zero columns.

## 8. Expected Output or Observable Behaviour
When inspecting a single sparse row:
```text
  (0, 31)	1
  (0, 78)	1
  (0, 112)	1
  (0, 154)	1
  (0, 189)	1
Non-zeros in row 0: 5
```
Out of 254 possible features, this review activated exactly 5 features. The remaining 249 columns occupy zero bytes in the `data` array.

## 9. Practical Exercises (with Success Criteria)
- **Task 4.1:** If an industrial NLP dataset contains 1,000,000 reviews and a vocabulary of 50,000 terms with 99.5% sparsity, calculate the RAM required to store it as a dense 64-bit float matrix versus a sparse matrix storing only non-zeros and 32-bit indices.
- **Task 4.2:** Explain why calling `.toarray()` on a massive `scipy.sparse` matrix can trigger an immediate `MemoryError` crash.
- *Success Criteria:* Calculations reveal dense array requires $pprox 400	ext{ GB}$ of RAM, while sparse requires $pprox 3	ext{ GB}$; explanations clearly identify the danger of forcing sparse matrices into dense memory.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Calling `.toarray()` or `.todense()` on feature matrices | Converts memory-efficient sparse matrices into massive dense arrays, risking OOM crashes | Keep matrices in sparse format; scikit-learn estimators natively accept sparse inputs. |
| Confusing rows with features | Rows represent documents (samples); columns represent vocabulary features | In scikit-learn convention, matrix dimensions are always $(N_{	ext{samples}}, N_{	ext{features}})$. |
| Manually iterating over sparse matrices with Python `for` loops | Extremely slow due to index pointer lookups | Use vectorized SciPy and scikit-learn linear algebra methods. |

## 11. Best Practices and Code Quality
- Always keep feature extraction outputs in sparse format when interfacing with scikit-learn models.
- Inspect matrix sparsity as a standard quality check during exploratory text analysis.
- Use `scipy.sparse.save_npz` and `load_npz` if you need to serialize large sparse matrices directly to disk.

## 12. Security, Ethics, and Fair AI Considerations
Handling memory efficiently is a prerequisite for deploying models on low-power edge devices and micro-instances, reducing the carbon footprint of AI workloads and making machine learning tools accessible on low-cost computing hardware.

## 13. Summary and Key Takeaways
The Document-Term Matrix (DTM) maps text documents to numerical frequency vectors. In movie review classification, text matrices are over 95.8% sparse. By utilizing SciPy's Compressed Sparse Row (`csr_matrix`), scikit-learn conserves memory and accelerates model training by storing only non-zero coordinates.

## 14. Knowledge Check Questions
1. What do the rows and columns of a Document-Term Matrix represent?
2. What is the exact shape of the training matrix in `main.py` ($N 	imes V$)?
3. What is the sparsity percentage of the Movie Review Mood Ring training matrix?
4. What data structure from SciPy does `CountVectorizer` return by default?

## 15. References and Further Reading
- SciPy Documentation: Compressed Sparse Row Matrix (`scipy.sparse.csr_matrix`).
- Saad, Y. (2003). *Iterative Methods for Sparse Linear Systems.* (Chapter 3: Sparse Matrices).
