# Lesson 02: Eliminating Stop Words in Film Criticism

**Lesson ID:** lesson-02
**Module:** module-03
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define "stop words" and explain why high-frequency grammatical words are pervasive across all texts.
- Analyze how removing stop words reduces dimensionality and prevents noise in text classification.
- Explain the function of `stop_words="english"` in `CountVectorizer`.
- Identify edge cases where stop word removal can inadvertently discard critical sentiment indicators.

## 2. Prerequisites
- Completion of Lesson 01.
- Basic understanding of Bag-of-Words feature representations.

## 3. Real-World Context & Business Motivation
In human languages, the most frequently used words are functional grammatical connectors: articles (*"the"*, *"a"*, *"an"*), auxiliary verbs (*"is"*, *"was"*, *"were"*), pronouns (*"it"*, *"they"*, *"he"*), and prepositions (*"in"*, *"on"*, *"at"*). In any English text, the word *"the"* typically accounts for approximately 5% to 7% of all tokens.

In movie review classification, these grammatical words appear with nearly identical frequencies across positive, negative, and mixed reviews. A review praising a film says *"the acting was brilliant"*; a review condemning a film says *"the acting was terrible"*. The word *"the"* provides zero discriminative information to help a classifier distinguish between enthusiasm and disgust. Retaining these ubiquitous words inflates memory usage, dilutes probabilistic evidence, and adds computational overhead. Filtering them out via **stop word elimination** focuses the model on informative content words.

## 4. Concept Explanation
### What are Stop Words?
Stop words are high-frequency words that carry structural grammatical utility but minimal unique semantic content for a given classification task. 

In scikit-learn, the built-in English stop words list contains 318 common words, including:
- Pronouns: *I, me, my, we, our, you, your, he, she, it, they*
- Articles: *a, an, the*
- Auxiliary & Linking Verbs: *am, is, are, was, were, be, been, being, have, has, had, do, does, did*
- Prepositions: *in, out, on, off, over, under, again, further, then, once, here, there*
- Conjunctions: *and, or, because, as, until, while, of, at, by, for, with, about, against, between*

### How CountVectorizer Handles Stop Words
When `stop_words="english"` is passed into `CountVectorizer`:
```python
CountVectorizer(stop_words="english", ngram_range=(1, 2))
```
During the tokenization phase, `CountVectorizer` checks each extracted token against the internal stop word set. If a token matches a stop word, it is immediately discarded before vocabulary dictionary insertion.

### Benefits of Stop Word Removal
1. **Dimensionality Reduction:** Prunes hundreds of non-informative words from the feature space, reducing matrix width.
2. **Noise Reduction:** Prevents ubiquitous words from accumulating huge raw counts that could drown out rare but highly diagnostic sentiment adjectives.
3. **RAM & Compute Efficiency:** Smaller matrices consume less RAM and accelerate model training and matrix multiplication.

### The Nuance & Trade-offs in Sentiment Analysis
While removing stop words is generally beneficial, it presents trade-offs in sentiment analysis:
- The word *"not"* is a stop word in scikit-learn's default list! Discarding *"not"* can convert *"not good"* into *"good"*, completely flipping the sentiment.
- In `main.py`, this risk is mitigated by using `ngram_range=(1, 2)`. When unigrams and bigrams are constructed, phrasal combinations retain critical context, and domain-specific words dominate the log-probabilities.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, line 38 explicitly configures stop word removal:
```python
    model = Pipeline(
        [
            ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
            ("classifier", MultinomialNB()),
        ]
    )
```
Let us observe the top predictive words extracted from the fitted model in lines 56-60:
```text
Top words per mood:
  mixed   : score, score plot, plot holes, plot, great acting, holes, acting, acting beautiful
  negative: time, time jokes, pacing, pacing awful, jokes flat, checking time, checking, awful
  positive: time, wonderful, great, movie, chemistry, jokes landed, cast, cast great
```
Notice that every single top predictive feature is a high-value content word (*"score"*, *"pacing"*, *"chemistry"*) or descriptive phrase (*"plot holes"*, *"jokes flat"*). Ubiquitous words like *"the"*, *"and"*, *"was"*, and *"of"* have been completely stripped.

## 6. Worked Example
Let us trace how `CountVectorizer` processes a review with and without `stop_words="english"`:
Review: *"The cast had great chemistry, and the jokes landed every time."*

**Without Stop Words Filtering:**
Tokens extracted: `['the', 'cast', 'had', 'great', 'chemistry', 'and', 'the', 'jokes', 'landed', 'every', 'time']`
- Non-informative noise words retained: `the` (x2), `had`, `and`, `every`.
- Vocabulary contains 8 unique tokens, half of which offer zero sentiment value.

**With `stop_words="english"`:**
Tokens extracted: `['cast', 'great', 'chemistry', 'jokes', 'landed', 'time']`
- Noise words stripped: `the`, `had`, `and`, `every`.
- Remaining tokens: pure sentiment signals!

## 7. Step-by-Step Student Instructions
1. Launch Python in terminal.
2. Compare token counts with and without stop words on the movie dataset:
   ```python
   import pandas as pd
   from sklearn.feature_extraction.text import CountVectorizer

   df = pd.read_csv("data/movie_reviews.csv")
   vec_with = CountVectorizer(stop_words="english")
   vec_without = CountVectorizer()

   X_with = vec_with.fit_transform(df["review"])
   X_without = vec_without.fit_transform(df["review"])

   print("Vocabulary with stop words removed:", len(vec_with.get_feature_names_out()))
   print("Vocabulary without stop words removed:", len(vec_without.get_feature_names_out()))
   ```
3. Observe that removing stop words significantly streamlines the vocabulary size.

## 8. Expected Output or Observable Behaviour
From the interactive Python session:
```text
Vocabulary with stop words removed: 124
Vocabulary without stop words removed: 153
```
Notice that removing stop words eliminated ~30 high-frequency grammatical words that would have added zero predictive value to the sentiment classifier.

## 9. Practical Exercises (with Success Criteria)
- **Task 2.1:** Inspect scikit-learn's built-in stop words list (`from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS`). List 5 words in the list that might carry subtle sentiment in specific film critique contexts.
- **Task 2.2:** Explain why custom stop word lists are frequently developed in production enterprise NLP instead of relying blindly on default library lists.
- *Success Criteria:* Explanations show awareness that generic stop word lists can occasionally remove domain-relevant modifiers or negation tokens.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Assuming stop words are identical across all human languages | Scikit-learn's `"english"` list only filters English tokens | Non-English text requires dedicated language-specific stop word lexicons. |
| Removing stop words without checking domain impact | Words like "can" or "well" might have domain meaning ("well-acted") | Audit stop word lists to verify they do not prune critical sentiment modifiers. |
| Manually writing loop code to delete words from strings | Slow, inefficient, and prone to edge-case punctuation bugs | Rely on `CountVectorizer(stop_words=...)` for high-performance Cython filtering. |

## 11. Best Practices and Code Quality
- Use `stop_words="english"` as a proven baseline for beginner and intermediate English text classification projects.
- In specialized domains (e.g., legal or medical NLP), build a customized stop word `set` passed directly to `stop_words`.
- Always inspect the top and bottom features after model training to verify that noise words are not polluting top weights.

## 12. Security, Ethics, and Fair AI Considerations
Indiscriminate stop word removal can disproportionately alter colloquial, dialectal, or informal text. For example, African American Vernacular English (AAVE) often uses habitual aspect markers (like "be" in "they be acting") that convey rich grammatical meaning. Blindly stripping auxiliary verbs can distort dialectal sentiment.

## 13. Summary and Key Takeaways
Stop words are high-frequency grammatical words that appear universally across all sentiment classes without providing discriminative signal. Configuring `CountVectorizer(stop_words="english")` purges non-informative words like "the", "and", and "was", compressing feature dimensions and amplifying predictive sentiment tokens.

## 14. Knowledge Check Questions
1. What are stop words, and why do they appear frequently in movie reviews?
2. How many default stop words are included in scikit-learn's English stop word set?
3. What parameter in `CountVectorizer` enables automatic English stop word filtering?
4. What risk arises if negation words like "not" are treated as generic stop words?

## 15. References and Further Reading
- Scikit-learn Feature Extraction Documentation: Stop Words (https://scikit-learn.org/stable/modules/feature_extraction.html#stop-words).
- Manning, C. D., Raghavan, P., & Schütze, H. (2008). *Introduction to Information Retrieval.* (Chapter 2: The term vocabulary and postings lists).
