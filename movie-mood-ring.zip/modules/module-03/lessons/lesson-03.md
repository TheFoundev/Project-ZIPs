# Lesson 03: Capturing Phrasal Context with N-Grams

**Lesson ID:** lesson-03
**Module:** module-03
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define unigrams, bigrams, and higher-order n-grams in computational linguistics.
- Explain how `ngram_range=(1, 2)` extracts both single words and contiguous two-word phrases.
- Demonstrate how bigrams solve the Bag-of-Words blindness to word order and local phrasal context.
- Analyze the exact top bigrams discovered by the Movie Mood Ring model (e.g., "plot holes", "jokes landed").

## 2. Prerequisites
- Completion of Lessons 01 and 02.
- Understanding of the Bag-of-Words model and vocabulary indices.

## 3. Real-World Context & Business Motivation
Consider the phrase: *"The jokes landed every time."*
Under a unigram-only model (single words), the model sees three isolated tokens: `jokes`, `landed`, `time`. While `jokes` and `landed` might suggest humor, the isolated word `time` appears in both positive reviews (*"jokes landed every time"*) and negative reviews (*"I kept checking the time"*).

Now consider what happens when we enable **bigrams** (contiguous pairs of adjacent words):
- Positive review yields: `jokes landed`, `landed time`
- Negative review yields: `checking time`, `kept checking`

Suddenly, the ambiguity disappears! The bigram `jokes landed` is 100% indicative of delightful comedy, while `checking time` is 100% indicative of excruciating boredom. By configuring `ngram_range=(1, 2)`, our classifier captures both single words and two-word phrases, dramatically boosting its ability to discern nuanced sentiment.

## 4. Concept Explanation
### What is an N-gram?
An **n-gram** is a contiguous sequence of $n$ items from a given sample of text or speech:
- **Unigram ($n = 1$):** A single word. Example: `"acting"`, `"beautiful"`, `"score"`.
- **Bigram ($n = 2$):** A pair of consecutive words. Example: `"great acting"`, `"plot holes"`, `"acting beautiful"`.
- **Trigram ($n = 3$):** A triplet of consecutive words. Example: `"soundtrack want replay"`, `"kept checking time"`.

### The `ngram_range` Parameter in CountVectorizer
The `ngram_range` tuple `(min_n, max_n)` controls the range of n-gram lengths to extract:
- `ngram_range=(1, 1)`: Extracts only unigrams (standard Bag-of-Words).
- `ngram_range=(2, 2)`: Extracts only bigrams.
- `ngram_range=(1, 2)`: Extracts **both unigrams and bigrams** simultaneously.

When configured as `(1, 2)`, `CountVectorizer` first tokenizes individual words, then generates every adjacent two-word combination.

### Why (1, 2) is the Golden Standard for Shallow NLP
Combining unigrams and bigrams provides the optimal balance for classical text classification:
1. **Retains Individual Word Power:** Strong single sentiment words (e.g., `"wonderful"`, `"awful"`, `"delightful"`) are retained as unigrams.
2. **Captures Phrasal Meaning:** Complex idioms and collocations (e.g., `"plot holes"`, `"pacing awful"`, `"chemistry jokes"`) are captured as bigrams.
3. **Controls Dimensional Explosion:** While trigrams and 4-grams increase vocabulary size exponentially, bigrams add manageable feature dimensions that standard classifiers handle with ease.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, line 38 configures the n-gram range:
```python
    model = Pipeline(
        [
            ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
            ("classifier", MultinomialNB()),
        ]
    )
```
Let us examine the top 8 predictive features per mood displayed by `main.py` in lines 56-60:
```text
Top words per mood:
  mixed   : score, score plot, plot holes, plot, great acting, holes, acting, acting beautiful
  negative: time, time jokes, pacing, pacing awful, jokes flat, checking time, checking, awful
  positive: time, wonderful, great, movie, chemistry, jokes landed, cast, cast great
```
Look closely at these top features:
- In `mixed`: Notice bigrams `score plot`, `plot holes`, `great acting`, and `acting beautiful`!
- In `negative`: Notice bigrams `pacing awful`, `jokes flat`, and `checking time`!
- In `positive`: Notice bigrams `jokes landed` and `cast great`!

Without `ngram_range=(1, 2)`, none of these rich phrasal features would exist in the model's feature space.

## 6. Worked Example
Let us trace the exact extraction of unigrams and bigrams on a sample sentence with stop words removed:
Sentence: *"Great acting and a beautiful score, but the plot had several holes."*

**Step 1: Stop words filtered:**
Remaining tokens: `['great', 'acting', 'beautiful', 'score', 'plot', 'holes']`

**Step 2: Unigrams ($n=1$):**
`['great', 'acting', 'beautiful', 'score', 'plot', 'holes']`

**Step 3: Bigrams ($n=2$):**
`['great acting', 'acting beautiful', 'beautiful score', 'score plot', 'plot holes']`

**Step 4: Combined Feature Set (11 features):**
`great`, `acting`, `beautiful`, `score`, `plot`, `holes`, `great acting`, `acting beautiful`, `beautiful score`, `score plot`, `plot holes`.

Notice how the extracted bigrams `great acting` and `plot holes` appear verbatim in `main.py`'s top predictive words for the `mixed` mood!

## 7. Step-by-Step Student Instructions
1. Open Python interactive terminal.
2. Run a comparison script to inspect the vocabulary growth from unigrams to unigrams + bigrams:
   ```python
   import pandas as pd
   from sklearn.feature_extraction.text import CountVectorizer

   df = pd.read_csv("data/movie_reviews.csv")
   vec_uni = CountVectorizer(stop_words="english", ngram_range=(1, 1))
   vec_bi = CountVectorizer(stop_words="english", ngram_range=(1, 2))

   vec_uni.fit(df["review"])
   vec_bi.fit(df["review"])

   print("Unigram-only vocabulary size:", len(vec_uni.get_feature_names_out()))
   print("Unigram + Bigram vocabulary size:", len(vec_bi.get_feature_names_out()))
   ```
3. Print 10 sample bigrams from `vec_bi`:
   ```python
   bigrams = [f for f in vec_bi.get_feature_names_out() if " " in f]
   print("Sample bigrams:", bigrams[:10])
   ```

## 8. Expected Output or Observable Behaviour
From the interactive console:
```text
Unigram-only vocabulary size: 124
Unigram + Bigram vocabulary size: 301
Sample bigrams: ['acting beautiful', 'acting felt', 'acting wonderful', 'beautiful score', 'beautifully shot', 'boring confusing', 'boring far', 'boring predictable', 'cast chemistry', 'cast great']
```
Adding bigrams expanded the vocabulary from 124 unigrams to 301 total features, capturing rich expressions like `"beautifully shot"` and `"boring confusing"`.

## 9. Practical Exercises (with Success Criteria)
- **Task 3.1:** Write down 3 movie review phrases where a single unigram is ambiguous, but a bigram resolves the sentiment decisively.
- **Task 3.2:** If a document contains 6 words after stop word filtering, how many unigrams and how many bigrams will be extracted? State the general mathematical formula for $K$ words.
- *Success Criteria:* Mathematical formula correctly identifies $K$ unigrams and $K-1$ bigrams (total $2K - 1$ features); examples clearly illustrate disambiguation.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Setting `ngram_range=(2, 2)` thinking it includes unigrams | Only extracts two-word phrases, discarding powerful single words like "wonderful" | Use `(1, 2)` to capture both unigrams and bigrams together. |
| Setting `ngram_range=(1, 5)` on large corpora | Triggers combinatorial explosion in feature dimensions, causing RAM exhaustion | Limit classical n-grams to $(1, 2)$ or $(1, 3)$ unless using feature selection. |
| Expecting bigrams to connect words separated by sentences | Standard vectorizers do not span n-grams across punctuation boundaries | Sentence boundaries are respected during regex tokenization. |

## 11. Best Practices and Code Quality
- Standardize on `ngram_range=(1, 2)` for sentiment classification baselines.
- Combine n-grams with stop word removal to prevent useless bigrams like `"of the"` or `"in a"`.
- Use `get_feature_names_out()` to inspect the learned n-grams and ensure domain relevance.

## 12. Security, Ethics, and Fair AI Considerations
Adversarial text attacks can manipulate bigrams by inserting neutral words between sentiment pairs (e.g., inserting "honestly" into "not good" -> "not honestly good") to disrupt n-gram detection. Robust systems account for syntactic variations.

## 13. Summary and Key Takeaways
N-grams capture contiguous sequences of words, overcoming the Bag-of-Words blindness to word order. Setting `ngram_range=(1, 2)` in `CountVectorizer` extracts both unigrams and bigrams, capturing nuanced phrases like `"plot holes"`, `"jokes landed"`, and `"checking time"` that decisively differentiate movie moods.

## 14. Knowledge Check Questions
1. What is the difference between a unigram and a bigram?
2. What does `ngram_range=(1, 2)` instruct `CountVectorizer` to do?
3. In `main.py`, what are two top bigrams discovered for the `negative` mood?
4. How many total features (unigrams + bigrams) are generated across the full movie review dataset?

## 15. References and Further Reading
- Cavnar, W. B., & Trenkle, J. M. (1994). *N-gram-based text categorization.* Proceedings of SDAIR-94, 161-175.
- Scikit-learn Documentation: `ngram_range` parameter in `CountVectorizer`.
