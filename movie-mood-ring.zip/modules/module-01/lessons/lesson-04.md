# Lesson 04: Framing the Task: Supervised Multi-Class NLP Classification

**Lesson ID:** lesson-04
**Module:** module-01
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Formally define the components of a supervised machine learning text classification problem.
- Define feature space $X$ (raw text strings) and target space $y$ (categorical mood labels).
- Distinguish between supervised learning, unsupervised learning, and reinforcement learning in NLP.
- Outline the end-to-end data processing and modeling stages implemented in `main.py`.

## 2. Prerequisites
- Completion of Lessons 01, 02, and 03.
- Familiarity with basic variable assignments and tabular datasets in Python.

## 3. Real-World Context & Business Motivation
Before writing a single line of machine learning code, professional data scientists and ML engineers must formally define their problem. Jumping directly into model training without clear mathematical framing leads to misaligned metrics, data leakage, and flawed deployments.

In the Movie Review Mood Ring, we seek an automated algorithm that can accept any arbitrary English sentence describing a movie and output its emotional mood: `positive`, `negative`, or `mixed`. To build this system, we frame the challenge as a **supervised multi-class classification** problem. By defining the exact inputs, outputs, loss objectives, and evaluation bounds upfront, we ensure that every subsequent step—from text vectorization to confusion matrix plotting—serves a cohesive engineering goal.

## 4. Concept Explanation
### Supervised Learning Defined
In **supervised learning**, an algorithm learns a mapping function $f: X 	o y$ from a collection of labeled training pairs:
$$\mathcal{D}_{	ext{train}} = \{(x_1, y_1), (x_2, y_2), \dots, (x_N, y_N)\}$$
- **Input Features ($X$):** The raw review text strings (e.g., $x_1 =$ *"A dull, confusing film that wasted a talented cast."*).
- **Ground Truth Target ($y$):** The verified mood label assigned to that review ($y_1 \in \{	ext{'mixed'}, 	ext{'negative'}, 	ext{'positive'}\}$).

The algorithm observes hundreds of these pairs, calculates statistical correlations between words and classes, and minimizes classification errors so that when presented with a novel, unseen review $x_{	ext{new}}$, it correctly predicts $\hat{y}_{	ext{new}} = f(x_{	ext{new}})$.

### Classification vs. Regression vs. Clustering
To appreciate why this project is framed as multi-class classification, consider how it compares to other ML paradigms:
| ML Paradigm | Input $X$ | Target $y$ | Project Example |
|---|---|---|---|
| **Multi-Class Classification (Our Task)** | Review text string | Discrete category from $\{C_1, C_2, C_3\}$ | Movie Mood Ring (`mixed`, `negative`, `positive`) |
| **Binary Classification** | Review text string | Binary category from $\{0, 1\}$ | Spam Detective (`spam`, `ham`) |
| **Regression** | Film budget, runtime, cast size | Continuous numeric scalar | Box Office Revenue Predictor ($\$124.5	ext{M}$) |
| **Unsupervised Clustering** | Unlabeled review text | None (finds inherent clusters) | Topic modeling (LDA / K-Means) |

Because our target variable consists of three distinct categorical states without an inherent continuous mathematical scale, classification is the correct paradigm.

### The Pipeline Architecture in main.py
The project solves this supervised classification problem through an integrated four-stage pipeline:
1. **Data Ingestion & Splitting:** Load `movie_reviews.csv`, isolate $X$ and $y$, and partition into training and test sets using stratification.
2. **Feature Extraction (`CountVectorizer`):** Convert variable-length text strings into fixed-dimensional numerical count vectors (n-grams, stop-word filtering).
3. **Probabilistic Estimation (`MultinomialNB`):** Fit class priors and feature likelihoods using Bayes' theorem with Laplace smoothing.
4. **Evaluation & Visualization:** Measure accuracy, precision, recall, confusion matrix, top clue words, and mood meter bar charts.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 31-42 assemble this supervised classification workflow:
```python
def main() -> None:
    df = pd.read_csv(DATA / "movie_reviews.csv")
    X_train, X_test, y_train, y_test = train_test_split(
        df["review"], df["mood"], test_size=0.25, random_state=42, stratify=df["mood"]
    )

    model = Pipeline(
        [
            ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
            ("classifier", MultinomialNB()),
        ]
    )
    model.fit(X_train, y_train)
```
- `df["review"]` serves as the feature Series $X$.
- `df["mood"]` serves as the target label Series $y$.
- `model.fit(X_train, y_train)` executes supervised training across the paired training inputs.

## 6. Worked Example
Let us trace what happens during `model.fit(X_train, y_train)`:
1. The `vectorizer` reads all 67 training review texts in `X_train`. It extracts every unique unigram and bigram (excluding English stop words) and creates a vocabulary dictionary.
2. Each training text is transformed into a row vector of token counts.
3. The `classifier` (`MultinomialNB`) counts how many times each token appears within each of the three target mood classes in `y_train`.
4. It computes:
   - Prior probabilities: $P(	ext{mood} = c)$
   - Feature likelihoods: $P(	ext{word}_j \mid 	ext{mood} = c)$
5. Once fitted, the pipeline is ready to ingest any new text string and calculate posterior class probabilities.

## 7. Step-by-Step Student Instructions
1. Open terminal and navigate to the project root directory.
2. Open Python in interactive mode by typing `python3`.
3. Import pandas and scikit-learn:
   ```python
   import pandas as pd
   df = pd.read_csv("data/movie_reviews.csv")
   print("Features shape:", df["review"].shape)
   print("Target shape:", df["mood"].shape)
   print("Classes:", df["mood"].unique())
   ```
4. Verify that `df["review"]` contains 90 text strings and `df["mood"]` contains 90 corresponding labels across three unique classes.

## 8. Expected Output or Observable Behaviour
In the interactive Python shell:
```text
Features shape: (90,)
Target shape: (90,)
Classes: ['negative' 'positive' 'mixed']
```
This confirms that the data structure matches the formal supervised learning requirement: 90 paired input-output observations.

## 9. Practical Exercises (with Success Criteria)
- **Task 4.1:** Formally express the feature matrix $X$ and label vector $y$ in mathematical notation for a mini-dataset containing 3 reviews.
- **Task 4.2:** Explain why passing `df["mood"]` into both `X_train` and `y_train` would constitute severe data leakage, and why features and targets must remain strictly separated.
- *Success Criteria:* Answers accurately identify $X$ as input features and $y$ as supervisory ground-truth signals, explaining that data leakage destroys real-world evaluation validity.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Treating the target mood as a continuous number (e.g., negative=0, mixed=1, positive=2) | Implies mixed is equidistant between negative and positive in metric space | Categorical classification avoids false arithmetic assumptions about ordinal distances. |
| Splitting data without labels ($X$ only) | Prevents supervised learning because the algorithm cannot calculate error gradients or class priors | Supervised learning fundamentally requires paired $(X, y)$ observations. |
| Forgetting to separate training features from test targets | Causes data contamination where test information leaks into model fitting | Strict partitioning preserves unbiased generalization evaluation. |

## 11. Best Practices and Code Quality
- Encapsulate transformations and estimators in a single `Pipeline` object to prevent data leakage.
- Clearly annotate the shapes and types of features $X$ and targets $y$ in your codebase documentation.
- Maintain reproducibility by seeding random operations (`random_state=42`).

## 12. Security, Ethics, and Fair AI Considerations
Supervised NLP models mirror the biases present in their training labels. If annotators systematically tag foreign cultural references or non-standard dialects as "confusing" or "negative", the model will institutionalize those prejudices. Dataset curation requires diverse review sources and rigorous annotation standards.

## 13. Summary and Key Takeaways
The Movie Review Mood Ring is formulated as a supervised multi-class natural language processing problem. The model learns from labeled pairs of review texts ($X$) and 3-class mood targets ($y \in \{	ext{mixed}, 	ext{negative}, 	ext{positive}\}$). By packaging vectorization and classification inside a scikit-learn Pipeline, the system reliably maps raw text to probability distributions over mood classes.

## 14. Knowledge Check Questions
1. In supervised learning, what are $X$ and $y$?
2. Why is movie mood prediction framed as classification rather than regression?
3. How many classes are present in the Movie Review Mood Ring target space?
4. What role does `Pipeline` play in scikit-learn workflow management?

## 15. References and Further Reading
- Russell, S., & Norvig, P. *Artificial Intelligence: A Modern Approach.* (Chapter 18: Learning from Examples).
- Scikit-learn Pipeline documentation: https://scikit-learn.org/stable/modules/generated/sklearn.pipeline.Pipeline.html
