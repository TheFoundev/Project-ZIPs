# Lesson 03: The Mood Ring Metaphor: Continuous Probabilities vs Discrete Labels

**Lesson ID:** lesson-03
**Module:** module-01
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain the "Mood Ring" metaphor and how it illustrates continuous probability distributions in sentiment analysis.
- Differentiate between a hard discrete classification decision and a soft probability vector.
- Understand how `predict_proba()` generates confidence distributions across multiple classes.
- Interpret how probability distributions communicate uncertainty and ambivalence in NLP models.

## 2. Prerequisites
- Completion of Lessons 01 and 02.
- Basic understanding of probabilities (values between 0.0 and 1.0 that sum to 1.0).

## 3. Real-World Context & Business Motivation
In popular culture, a "mood ring" is a novelty piece of jewelry containing thermochromic liquid crystals that change color in response to body temperature—shifting across greens, blues, ambers, and reds to symbolize shifting emotional states. In this machine learning project, the "Mood Ring" serves as an intuitive metaphor for **probabilistic sentiment analysis**.

When humans evaluate a film, our feelings are rarely monolithic. We might be 70% thrilled by the action sequences, 20% disappointed by the shallow dialogue, and 10% undecided about the ending. If an AI system simply outputs a single word—such as `"mixed"`—it conceals this delicate internal balance. By analyzing the model's full probability distribution across all three moods (positive, negative, and mixed), we can visualize the viewer's emotional spectrum as a vibrant "mood meter" chart.

## 4. Concept Explanation
### Hard vs Soft Predictions
Machine learning classifiers provide two fundamental types of outputs:
1. **Hard Prediction (`predict`):** Returns the single class label that achieved the highest probability (the *argmax*).
   $$\hat{y} = rg\max_{c \in C} P(y = c \mid X)$$
2. **Soft Prediction (`predict_proba`):** Returns a vector of probability values across all candidate classes:
   $$\mathbf{p} = [P(	ext{mixed} \mid X), P(	ext{negative} \mid X), P(	ext{positive} \mid X)]$$
   where $\sum_{c \in C} P(y = c \mid X) = 1.0$ and $0 \le P(y = c \mid X) \le 1$.

### Why Probabilities Matter in Production
Consider two different reviews, both classified as `"positive"` by hard prediction:
- Review 1: $P(	ext{positive}) = 0.98, P(	ext{negative}) = 0.01, P(	ext{mixed}) = 0.01$
- Review 2: $P(	ext{positive}) = 0.36, P(	ext{negative}) = 0.31, P(	ext{mixed}) = 0.33$

In Review 1, the model is almost completely certain of overwhelming praise. In Review 2, the model barely chose "positive" over the other two classes; it is deeply uncertain. If an automated system treats both reviews identically simply because their hard labels match, it ignores crucial operational confidence signals.

### The Mood Meter Chart
To make these probabilities intuitive, `main.py` renders a custom bar chart known as the **Mood Meter**:
- Green bar (`#27ae60`): Probability of Positive mood
- Red bar (`#c0392b`): Probability of Negative mood
- Orange/Amber bar (`#e67e22`): Probability of Mixed mood

The height of each bar directly reflects the model's posterior probability, providing an immediate visual diagnostic of review sentiment.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 73-87 build the mood meter visualization for a sample review:
```python
    # ---- Mood meter for one review ------------------------------------
    sample_review = new_reviews[0]
    sample_probabilities = model.predict_proba([sample_review])[0]
    fig, ax = plt.subplots(figsize=(6, 4))
    colours = {"positive": "#27ae60", "negative": "#c0392b", "mixed": "#e67e22"}
    ax.bar(classes, sample_probabilities, color=[colours[c] for c in classes])
    ax.set_ylim(0, 1)
    ax.set_ylabel("probability")
    ax.set_title("Mood meter for: 'I loved the acting... but the ending felt rushed'")
    for i, probability in enumerate(sample_probabilities):
        ax.text(i, probability + 0.02, f"{probability:.0%}", ha="center")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(OUT / "mood_meter.png", dpi=150, bbox_inches="tight")
    plt.close(fig)
```
Notice how `model.predict_proba([sample_review])[0]` extracts the exact 3-element probability array, and matplotlib dynamically colors each bar using the dictionary `colours`.

## 6. Worked Example
Suppose a model evaluates the review:
*"I loved the acting and the story was beautiful, but the ending felt rushed."*

The model's `predict_proba` returns:
- `classes`: `['mixed', 'negative', 'positive']`
- `sample_probabilities`: `[0.8897, 0.0125, 0.0978]`

Let us interpret this mood distribution:
- **Mixed (88.97% / ~89%):** The vast majority of the probability mass falls into the mixed class because the review couples strong praise ("loved", "beautiful") with a critical concession ("but the ending felt rushed").
- **Positive (~10%):** A modest secondary slice of probability reflects the presence of glowing positive vocabulary.
- **Negative (~1%):** Very little probability is assigned to pure negativity because the overall tone is not hostile.

The hard prediction selects `"mixed"` (since $0.8897 > 0.0978 > 0.0125$), and the mood meter displays a towering orange bar at 89%.

## 7. Step-by-Step Student Instructions
1. Run `python main.py` in your terminal.
2. Open the generated image file `outputs/mood_meter.png` in an image viewer.
3. Observe the three bars corresponding to `mixed`, `negative`, and `positive`.
4. Verify that the sum of the percentages displayed above each bar equals 100% (within rounding).
5. Compare the visual bar heights with the console output: `mixed (89%)`.

## 8. Expected Output or Observable Behaviour
When executing the mood meter code, `main.py` writes:
```text
Saved: outputs/mood_meter.png, outputs/confusion_matrix.png, outputs/predictions.txt
```
Opening `outputs/mood_meter.png` reveals:
- A bar for `mixed` reaching ~0.89 (89%)
- A bar for `negative` near 0.01 (1%)
- A bar for `positive` near 0.10 (10%)
- Clean y-axis bounds from 0.0 to 1.0 with a subtle grid.

## 9. Practical Exercises (with Success Criteria)
- **Task 3.1:** Given the probability distribution $[P(	ext{mixed})=0.45, P(	ext{negative})=0.10, P(	ext{positive})=0.45]$, explain what the hard prediction would be in scikit-learn when classes are tied, and why inspecting the probability vector is superior to the hard label.
- **Task 3.2:** Modify the sample review in `main.py` locally to an overwhelmingly positive quote and describe how you expect the three bars in `outputs/mood_meter.png` to change.
- *Success Criteria:* Explanations correctly demonstrate that probabilities reveal model certainty, ambivalence, and borderline predictions that hard labels hide.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Assuming probabilities are raw counts | Probabilities are normalized between 0 and 1 and must sum to 1.0 across classes | Scikit-learn's `predict_proba` uses the softmax/normalization of log-likelihoods. |
| Forgetting to match class names with probabilities | `classifier.classes_` defines the exact order of columns in `predict_proba` | In scikit-learn, classes are sorted alphabetically: `['mixed', 'negative', 'positive']`. |
| Discarding probabilities after calling `predict` | Sacrifices valuable confidence calibration and risk management data | Production systems log prediction probabilities for monitoring drift and uncertainty. |

## 11. Best Practices and Code Quality
- Always align visual bar chart colors with intuitive psychological associations (green for positive, red for negative, amber for mixed).
- Always set explicit plot bounds (`ax.set_ylim(0, 1)`) when displaying probability distributions so viewers can visually gauge certainty against the full scale.
- Include data labels directly on top of bars (`ax.text`) for rapid readability.

## 12. Security, Ethics, and Fair AI Considerations
Presenting probability scores alongside predictions fosters transparency and trust with human decision-makers. Rather than presenting an AI system as an infallible oracle, displaying a probability distribution makes the model's confidence and doubts explicit, enabling human-in-the-loop review for ambiguous cases.

## 13. Summary and Key Takeaways
The Mood Ring metaphor captures the continuous, probabilistic nature of machine learning predictions. While hard predictions pick a single label, `predict_proba` computes posterior probabilities across all classes. Visualizing these probabilities in a 3-class Mood Meter chart offers deep visibility into model confidence, nuance, and emotional ambivalence.

## 14. Knowledge Check Questions
1. What is the key mathematical difference between `model.predict()` and `model.predict_proba()`?
2. What do the values in the `predict_proba` array sum to for any single input sample?
3. In what alphabetical order does scikit-learn sort the class labels in `classifier.classes_`?
4. Why is a probability distribution more informative to an analyst than a discrete class label?

## 15. References and Further Reading
- Scikit-learn documentation on `predict_proba`: https://scikit-learn.org/stable/glossary.html#term-predict_proba
- Niculescu-Mizil, A., & Caruana, R. (2005). *Predicting good probabilities with supervised learning.* ICML.
