# Lesson 02: Moving Beyond Binary: Why "Mixed" Reviews Matter

**Lesson ID:** lesson-02
**Module:** module-01
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Contrast binary classification (positive vs negative) with 3-class sentiment classification (positive, negative, mixed).
- Explain why forcing nuanced human commentary into binary buckets creates information loss and classification errors.
- Identify the linguistic structure of mixed sentiment reviews (contrastive conjunctions and competing polarities).
- Analyze how 3-class classification improves decision-making in content recommendation and creative development.

## 2. Prerequisites
- Completion of Lesson 01.
- Understanding of basic classification concepts (input text mapped to categorical labels).

## 3. Real-World Context & Business Motivation
Most introductory machine learning tutorials teach sentiment analysis as a binary classification problem: a review is either labeled `1` (positive) or `0` (negative). While binary classification works reasonably well for simple product endorsements ("The charger arrived broken" vs "The charger works perfectly"), it breaks down completely when applied to artistic and creative media.

Consider a film review that states: *"The acting was superb and the cinematography was gorgeous, but the script was predictable and the ending made no sense."* If forced into a binary classifier, the model is compelled to make a coin-toss decision. If it predicts "positive", it ignores the viewer's intense dissatisfaction with the storyline. If it predicts "negative", it discards the viewer's praise for the actors and cinematographer. In either case, the binary classification is objectively wrong and misleading. Introducing a dedicated `"mixed"` category preserves the integrity of ambivalent feedback.

## 4. Concept Explanation
### The Information Loss of Binary Bucketing
When a classification taxonomy excludes intermediate categories, it introduces systemic bias:
1. **Forced Extremism:** Ambivalent reviewers who rated a movie 3 out of 5 stars are arbitrarily pushed into extreme camps.
2. **Reduced Trust:** Users reading the system's output lose faith when a nuanced, thoughtful critique is tagged with a blanket "negative" or "positive" badge.
3. **Impaired Recommendations:** Recommendation engines might recommend a film to a viewer who hates bad scripts simply because the binary classifier labeled the review as "positive" based on acting keywords.

### Linguistic Structure of Mixed Sentiment
Mixed reviews possess unique syntactic and lexical properties. They typically feature **contrastive transitions** that link opposing sentiment clauses:
- Subordinating conjunctions: *"although"*, *"even though"*, *"while"*
- Coordinating conjunctions: *"but"*, *"yet"*
- Adversative adverbs: *"however"*, *"nevertheless"*, *"on the other hand"*

Notice the clause dynamics:
```text
[Positive Clause: "Great performances, a clever plot"] 
       + [Contrastive Conjunction: "but"] 
              + [Negative Clause: "the ending felt rushed"]
```
In statistical text classification, words from both positive and negative vocabularies appear in close proximity within the same document.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 55-60 and lines 61-65 demonstrate how 3 distinct classes are processed and predicted:
```python
    vectorizer = model.named_steps["vectorizer"]
    classifier = model.named_steps["classifier"]
    feature_names = vectorizer.get_feature_names_out()
    classes = list(classifier.classes_)
    print("Top words per mood:")
    for index, mood in enumerate(classes):
        top = np.argsort(classifier.feature_log_prob_[index])[-8:][::-1]
        print(f"  {mood:8s}: {', '.join(feature_names[top])}")

    new_reviews = [
        "I loved the acting and the story was beautiful, but the ending felt rushed.",
        "A boring, confusing mess. I kept checking the time.",
        "A delightful film with warm characters and a happy ending.",
    ]
```
The script explicitly tracks three distinct classes: `['mixed', 'negative', 'positive']`. When testing on `new_reviews[0]`, the model identifies the presence of both admiration and criticism, correctly predicting the `mixed` mood.

## 6. Worked Example
Let us trace how different models evaluate the sentence:
*"The comedy worked, but the emotional moments felt forced."*

- **Binary Classifier (Positive or Negative):**
  - Word count: "comedy worked" (+1 positive), "emotional moments felt forced" (-1 negative).
  - Score: $1 - 1 = 0$. The model has no neutral or mixed class, so it arbitrarily predicts either Positive or Negative based on slight feature weights. A user looking at the output sees a misclassified review.
- **3-Class Classifier (Positive, Negative, Mixed):**
  - Evaluates likelihood across all three models: $P(	ext{positive})$, $P(	ext{negative})$, and $P(	ext{mixed})$.
  - Learns that the co-occurrence of praise tokens and critique tokens separated by "but" has high statistical probability under the `mixed` distribution.
  - Predicts `mixed`, preserving the reviewer's true sentiment.

## 7. Step-by-Step Student Instructions
1. Inspect the dataset `movie_reviews.csv` in your terminal or text editor.
2. Filter or search for rows where the mood is labeled `mixed`.
3. Count how many of these mixed reviews contain the word "but" or "though".
4. Compare these to reviews labeled `positive` and `negative`.
5. Observe that while pure reviews tend to maintain consistent polarity throughout, mixed reviews pivot halfway through the sentence.

## 8. Expected Output or Observable Behaviour
When examining `data/movie_reviews.csv`, students will see:
```text
Sample Mixed Reviews:
- "The comedy worked, but the emotional moments felt forced." -> mixed
- "I am glad I watched it, but I would not rush to see it again." -> mixed
- "The visuals were stunning, but the story dragged. I liked the ending, though." -> mixed
- "Great acting and a beautiful score, but the plot had several holes." -> mixed
```
Notice how each sample contains both complimentary and critical phrasing.

## 9. Practical Exercises (with Success Criteria)
- **Task 2.1:** Write two synthetic movie reviews: one that expresses unconditional enthusiasm, and one that expresses mixed feelings about acting vs plot.
- **Task 2.2:** Explain why an e-commerce platform selling consumer electronics might tolerate binary sentiment, whereas a film discussion forum benefits significantly from 3-class sentiment.
- *Success Criteria:* Explanations highlight the multi-attribute nature of artistic works and the linguistic presence of contrasting clauses.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Thinking "mixed" means neutral or emotionless | Neutral text is factual/objective; mixed text contains intense but conflicting emotions | "Mixed" captures the tension between strong positive and strong negative reactions. |
| Dropping the "mixed" class to achieve higher apparent accuracy | Artificially inflating metrics by oversimplifying the problem degrades real-world utility | A 3-class model solving the real problem is far more valuable than a brittle binary model. |
| Treating "mixed" as an error or garbage collection bucket | Fails to recognize that mixed reviews often contain the most actionable creative critiques | Mixed reviews pinpoint exact areas where an artwork succeeded or failed. |

## 11. Best Practices and Code Quality
- Design your target label taxonomy to reflect actual user behavior and real-world domain requirements.
- When creating multi-class target labels, ensure clear annotation guidelines so human labelers agree on what constitutes "mixed".
- Validate that all classes have sufficient representation in your training dataset.

## 12. Security, Ethics, and Fair AI Considerations
In recommendation systems, forcing reviews into binary buckets can polarize content presentation, nudging users toward polarizing echo chambers. Supporting a middle, mixed tier promotes balanced consumption and nuanced critical evaluation.

## 13. Summary and Key Takeaways
Binary classification is insufficient for evaluating creative arts because human critique frequently combines praise and criticism in the same review. The 3-class sentiment paradigm—distinguishing positive, negative, and mixed sentiments—captures authentic audience nuance and prevents misleading classifications.

## 14. Knowledge Check Questions
1. Why does binary classification fail when applied to reviews that balance praise for acting with criticism of plot?
2. What grammatical elements typically signal mixed sentiment in English reviews?
3. What is the fundamental difference between "neutral" text and "mixed" text?
4. How does retaining a "mixed" sentiment class benefit film recommendation algorithms?

## 15. References and Further Reading
- Taboada, M., Brooke, J., Tofiloski, M., Voll, K., & Stede, M. (2011). *Lexicon-based methods for sentiment analysis.* Computational Linguistics, 37(2), 267-307.
- Scikit-learn Multi-class and Multi-label algorithms documentation (https://scikit-learn.org/stable/modules/multiclass.html).
