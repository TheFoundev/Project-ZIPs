# Module 6 Exercises: Probability Distributions, Mood Meter, and Extensions

## Exercise 6.1: Soft Probabilities vs Hard Predictions (15 min)
**Objective:** Extract, normalize, and interpret continuous class probability vectors using `model.predict_proba()` versus discrete predictions from `model.predict()`.

**Problem Statement:** A production sentiment classifier outputs class predictions. A product manager requests confidence flags so that ambiguous reviews (where no single mood exceeds 50% probability) are routed to human moderators rather than automated dashboards.

**Requirements:**
1. Given a trained MultinomialNB pipeline, write a function `classify_with_confidence(text, model, vectorizer, threshold=0.50)` that returns a dictionary containing:
   - `predicted_class`: the argmax class label (`'mixed'`, `'negative'`, or `'positive'`)
   - `confidence`: the float probability of the predicted class rounded to 4 decimals
   - `probabilities`: dictionary mapping class names to their respective probabilities
   - `needs_human_review`: boolean flag, `True` if `confidence < threshold`, else `False`
2. Test the function on three distinct sentences:
   - "Absolute masterpiece from start to finish."
   - "Unbearable waste of two hours of my life."
   - "The cinematography was gorgeous but the pacing was sluggish and the plot was confusing."
3. Verify that the sum of probabilities across all classes equals $1.0 \pm 10^{-6}$.

**Constraints:** Use standard Python, NumPy, and scikit-learn. Do not hardcode class names; retrieve them dynamically from `model.classes_`.

**Expected Behaviour:** The function returns structured confidence scores and correctly flags ambiguous reviews for manual inspection.

**Acceptance Criteria:**
- [ ] Retrieves class order dynamically using `model.classes_`.
- [ ] Returns valid probability distribution summing to 1.0.
- [ ] Sets `needs_human_review` to `True` only when maximum class probability falls below the specified threshold.
- [ ] Handles unseen out-of-vocabulary words gracefully without throwing exceptions.

---

## Exercise 6.2: Custom Mood Meter Matplotlib Bar Chart Generation (20 min)
**Objective:** Build and customize a publication-ready horizontal or vertical Mood Meter visualization using Matplotlib's object-oriented API.

**Problem Statement:** In `main.py`, the mood meter renders a 3-bar vertical chart for review 0 ("I loved the acting and the story was beautiful, but the ending felt rushed."). You must create an enhanced, standalone generator function `render_mood_meter(probabilities, review_text, output_path)` that produces an informative, aesthetically refined artifact.

**Requirements:**
1. Configure Matplotlib to use the headless `'Agg'` backend prior to importing pyplot.
2. Accept a probability dictionary `{ 'mixed': 0.89, 'negative': 0.01, 'positive': 0.10 }` and snippet string.
3. Apply standard project color codes:
   - Positive: `#27ae60` (forest green)
   - Negative: `#c0392b` (deep red)
   - Mixed: `#e67e22` (vibrant amber / orange)
4. Implement the following styling specifications:
   - Vertical bars with bar width `0.55` and alpha `0.9`.
   - Set fixed y-axis limits to `(0, 1.05)` with percentage formatting (`0%`, `20%`, ..., `100%`).
   - Draw subtle horizontal grid lines (`alpha=0.3`, `linestyle='--'`) behind bars using `ax.set_axisbelow(True)`.
   - Annotate each bar top with bold percentage text (e.g., `89.0%`) centered above the bar.
   - Include a wrapped title with review excerpt in italics.
5. Save the figure to `output_path` at 300 DPI with `bbox_inches='tight'` and close the figure to free memory.

**Constraints:** Use Matplotlib's explicit object-oriented API (`fig, ax = plt.subplots(...)`). Avoid state-machine calls (`plt.bar`, `plt.title`).

**Expected Behaviour:** An image file is written to disk displaying a polished Mood Meter bar chart with readable labels and clear visual hierarchy.

**Acceptance Criteria:**
- [ ] Uses headless backend `matplotlib.use('Agg')`.
- [ ] Matches required hex color mapping `#27ae60`, `#c0392b`, and `#e67e22`.
- [ ] Correctly places dynamic text annotations above each bar based on bar heights.
- [ ] Calls `plt.close(fig)` to eliminate memory leaks.

---

## Exercise 6.3: Sarcasm and Lexical Negation Stress Testing (15 min)
**Objective:** Construct a linguistic stress-test suite to identify Bag-of-Words Naive Bayes classification blind spots caused by irony, sarcasm, and negation.

**Problem Statement:** Bag-of-Words and unigram/bigram tokenizers treat text as unordered bags of tokens. Sarcastic sentences often use intensely positive vocabulary to express negative sentiment. You need to analyze why the model misclassifies these inputs.

**Requirements:**
1. Define a list of 5 sarcastic or subtly ironic movie review test cases:
   - "Oh great, another two hours of mind-numbing dialogue."
   - "Truly a masterclass in how to waste fifty million dollars."
   - "I couldn't have been more thrilled when the credits finally rolled."
   - "A real stroke of genius to make every character utterly unlikable."
   - "Fast-paced if you consider watching paint dry exhilarating."
2. Pass these test cases through the trained `MovieMoodRing` pipeline to obtain predicted classes and probability distributions.
3. For each misclassified review:
   - Extract the active features detected by `CountVectorizer`.
   - Print the log-probability of those features under each class.
   - Explain mathematically why the Naive Bayes argmax selected the incorrect class.
4. Document at least two algorithmic modifications (e.g., sentiment lexicons, negation tagging like `NOT_great`, transformer embeddings) that would resolve this limitation.

**Constraints:** Document feature contributions using the model's learned `feature_log_prob_` matrix.

**Expected Behaviour:** Detailed diagnostic output demonstrating how positive keywords mislead the Bag-of-Words Naive Bayes model.

**Acceptance Criteria:**
- [ ] Successfully runs all 5 sarcastic test sentences through vectorizer and classifier.
- [ ] Identifies specific high-weight positive tokens (e.g., `'great'`, `'masterclass'`, `'thrilled'`, `'genius'`) triggering false positives.
- [ ] Explains the structural cause: absence of word order and semantic context in Bag-of-Words representation.
- [ ] Proposes concrete, actionable engineering enhancements.

---

## Exercise 6.4: Pipeline Serialization and Production Reporting (20 min)
**Objective:** Export trained models using `joblib` and construct an end-to-end report generator matching the formatting of `outputs/predictions.txt`.

**Problem Statement:** In production, retraining a model on every inference request is inefficient. You need to serialize the trained vectorizer and classifier to disk, reload them, and generate a standardized prediction summary report.

**Requirements:**
1. Serialize the trained vectorizer and MultinomialNB classifier into a single composite dictionary or tuple artifact `outputs/mood_ring_model.joblib`.
2. Write a verification loader function that:
   - Loads the saved `.joblib` file.
   - Asserts that reloaded model parameters and predictions match the in-memory model identically.
3. Write a report generator function `generate_predictions_report(test_reviews, true_labels, predictions, probabilities, output_file)` that formats and saves an exact replica of `outputs/predictions.txt`:
   - Header with project title and execution timestamp.
   - Overall accuracy, test set size, and confusion matrix summary.
   - Per-review breakdown containing: review text, predicted mood, true mood (if available), status (`[CORRECT]` or `[MISMATCH]`), and individual class probability percentages.
4. Ensure the output file uses proper utf-8 encoding and handles directory creation with `pathlib.Path.mkdir(parents=True, exist_ok=True)`.

**Constraints:** Use `joblib` for model serialization. Do not rely on insecure `pickle` loads from untrusted sources.

**Expected Behaviour:** Creates `outputs/mood_ring_model.joblib` and `outputs/predictions.txt` with formatted columns and clear reporting sections.

**Acceptance Criteria:**
- [ ] Serialized artifact contains both vocabulary and trained classifier state.
- [ ] Reloaded model produces identical predictions on all test samples.
- [ ] Generated text report matches formatting in `outputs/predictions.txt`.
- [ ] All parent directories created automatically without throwing `FileNotFoundError`.
