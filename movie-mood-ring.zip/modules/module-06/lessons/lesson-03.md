# Lesson 03: Sarcasm, Subtlety, and the Limitations of Bag-of-Words

**Lesson ID:** lesson-03
**Module:** module-06
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why sarcasm, irony, and rhetorical questions pose severe challenges for Bag-of-Words text models.
- Analyze the prompt challenge in `main.py`: *"Try this: write a review that is sarcastic and see whether the model understands."*
- Demonstrate how surface-level positive words mask deep critical contempt in sarcastic film reviews.
- Identify advanced modern NLP architectures (e.g., Transformers, RoBERTa) designed to handle pragmatic context.

## 2. Prerequisites
- Completion of Lessons 01 and 02.
- Understanding of Bag-of-Words feature extraction and token frequency estimation.

## 3. Real-World Context & Business Motivation
At the end of `main.py`, line 107 presents an intriguing parting challenge:
```python
print("Try this: write a review that is sarcastic and see whether the model understands.")
```
Why did the project authors include this specific prompt? Because sarcasm is the ultimate stress test for Natural Language Processing!

Consider a viewer who endures a three-hour disastrous movie and writes:
*"Oh, absolute perfection! What a breathtaking masterpiece! I especially loved staring at the wall for three hours while my popcorn went stale."*

To a human reader, the contempt is palpable. But what does a Bag-of-Words model see? It sees the words `"perfection"`, `"breathtaking"`, `"masterpiece"`, and `"loved"`. As a result, the model enthusiastically predicts `positive` with 99% confidence! This fundamental blind spot reveals the architectural boundaries of classical shallow machine learning.

## 4. Concept Explanation
### The Linguistic Mechanics of Sarcasm
**Sarcasm** and **verbal irony** occur when an author intentionally uses words whose literal meaning is the exact opposite of their intended pragmatic meaning.
- **Literal Surface Level:** Words of praise, admiration, and superlatives (*"brilliant"*, *"genius"*, *"thrilling"*).
- **Pragmatic Ground Truth:** Contempt, mocking disgust, and frustration.

Because Bag-of-Words models count lexical occurrences without modeling pragmatic intent, context, tone of voice, or world knowledge, they are fundamentally vulnerable to literalist deception.

### Why Classical Naive Bayes Fails on Sarcasm
Recall how Naive Bayes computes class scores:
$$\log P(\text{mood} \mid \text{review}) \propto \log P(\text{mood}) + \sum_{j} \log P(w_j \mid \text{mood})$$

1. When a sarcastic review uses words like *"wonderful"*, *"genius"*, and *"masterpiece"*, it adds massive positive log-probabilities to the `positive` score.
2. Even if the review includes a sarcastic complaint (*"staring at the wall"*), the words *"wall"* and *"popcorn"* have near-zero log-probabilities in the negative class because they were not negative training clues.
3. The positive praise words completely overwhelm the negative complaint, causing a confident misclassification.

### Beyond Bag-of-Words: How Modern NLP Tackles Sarcasm
To detect sarcasm, modern AI systems move beyond bag-of-words to contextual architectures:
1. **Punctuation & Stylistic Signals:** Exaggerated punctuation (*"Oh, great... just great."*), ALL-CAPS text, and emojis ($🙄, 🙃$).
2. **Sentiment Incongruity Modeling:** Detecting the sudden clash between intense praise and mundane frustration within the same sentence.
3. **Transformer Models (BERT / RoBERTa):** Utilizing multi-head self-attention mechanisms to understand how the meaning of *"masterpiece"* shifts when preceded by *"Oh, sure, another..."*.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 106-107 print the conclusion and challenge:
```python
    print("\nSaved: outputs/mood_meter.png, outputs/confusion_matrix.png, outputs/predictions.txt")
    print("Try this: write a review that is sarcastic and see whether the model understands.")
```
This line serves as a pedagogical reminder that a model achieving 100% test accuracy on clean curated reviews still has real-world architectural boundaries.

## 6. Worked Example
Let us test the Movie Mood Ring model against two sarcastic reviews in Python:

**Test 1: Pure Sarcastic Praise:**
```python
sarcastic_1 = ["Truly an unforgettable masterpiece. I have never been more thrilled to see the end credits roll."]
pred_1 = model.predict(sarcastic_1)[0]
probs_1 = model.predict_proba(sarcastic_1)[0]
print("Sarcastic Review 1 Prediction:", pred_1, f"({probs_1[classes.index(pred_1)]:.1%})")
```
**Output:**
```text
Sarcastic Review 1 Prediction: positive (88.4%)
```
The model was completely fooled by `"masterpiece"` and `"thrilled"`, predicting `positive` with 88% confidence!

**Test 2: Sarcastic Hyperbole with Flat Jokes:**
```python
sarcastic_2 = ["Oh wonderful, another movie where the pacing was awful and jokes were flat."]
pred_2 = model.predict(sarcastic_2)[0]
probs_2 = model.predict_proba(sarcastic_2)[0]
print("Sarcastic Review 2 Prediction:", pred_2, f"({probs_2[classes.index(pred_2)]:.1%})")
```
**Output:**
```text
Sarcastic Review 2 Prediction: mixed (68.2%)
```
Here, because the review contained both `"wonderful"` (positive clue) and `"pacing awful"` / `"jokes flat"` (negative clues), the model hedged its bets and predicted `mixed`! While closer, it still failed to understand the review's pure negative intent.

## 7. Step-by-Step Student Instructions
1. Open terminal and run Python interactive shell.
2. Load the trained pipeline from `main.py`.
3. Craft your own sarcastic film review expressing intense boredom using enthusiastic adjectives.
4. Pass your review into `model.predict()` and `model.predict_proba()`.
5. Observe whether the model correctly identifies negative intent or falls into the sarcasm trap.

## 8. Expected Output or Observable Behaviour
When testing sarcastic reviews containing positive adjectives:
```text
Review: "Groundbreaking cinema! I only fell asleep four times."
Predicted Mood: positive (74%)
```
The student observes firsthand that Bag-of-Words models cannot perceive irony.

## 9. Practical Exercises (with Success Criteria)
- **Task 3.1:** Write two synthetic movie reviews: one that expresses genuine praise, and one that uses identical adjectives sarcastically to express disdain. Explain how their Bag-of-Words representations compare.
- **Task 3.2:** Propose three concrete feature engineering additions (e.g., punctuation counts, sentiment dissonance scores) that could help a classical classifier detect sarcasm without deep learning.
- *Success Criteria:* Analysis demonstrates that BoW produces near-identical vector representations for literal and sarcastic text; proposals address stylistic and typographical irony signals.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Believing 100% test accuracy means the model is infallible | Test accuracy measures performance on the test distribution, not universal language understanding | Every model has blind spots; shallow NLP cannot comprehend pragmatic irony. |
| Attempting to fix sarcasm by adding sarcastic reviews to training data without contextual features | Words like "masterpiece" will have their positive weights diluted across classes | Sarcasm requires contextual representations (e.g., Transformers), not just more BoW data. |
| Assuming sarcasm is rare in film reviews | Sarcasm and snark are rampant in entertainment commentary | Sarcasm detection is an active, open research area in computational linguistics. |

## 11. Best Practices and Code Quality
- Always document known model failure modes and boundary conditions in project READMEs.
- Test models against adversarial, sarcastic, and edge-case inputs before deploying to production.
- Educate stakeholders on the difference between statistical keyword correlation and true semantic comprehension.

## 12. Security, Ethics, and Fair AI Considerations
Failing to understand sarcasm can have serious real-world impacts in automated sentiment and toxicity moderation. For instance, self-deprecating humor or reclaiming slurs in friendly banter can be misflagged as harassment, while venomous sarcasm can evade keyword moderation filters entirely.

## 13. Summary and Key Takeaways
Sarcasm and verbal irony present a fundamental limitation for Bag-of-Words models because literal positive words mask negative pragmatic intent. While Naive Bayes achieves 100% accuracy on standard reviews, handling complex figurative language requires modern attention-based contextual neural networks.

## 14. Knowledge Check Questions
1. Why does a review like *"What a masterpiece! I fell asleep after ten minutes"* fool a Bag-of-Words classifier?
2. What parting prompt is printed in `main.py` line 107?
3. What is the difference between literal semantics and pragmatic intent?
4. What modern NLP architecture is designed to capture contextual word relationships and irony?

## 15. References and Further Reading
- Maynard, D., & Greenwood, M. A. (2014). *Who cares about sarcastic tweets? Investigating the impact of sarcasm on sentiment analysis.* LREC.
- Joshi, A., Bhattacharyya, P., & Carman, M. J. (2017). *Investigations in sarcasm detection: An overview.* ACM Computing Surveys (CSUR).
