# Lesson 02: Crafting the Mood Meter Visualization with Matplotlib

**Lesson ID:** lesson-02
**Module:** module-06
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Construct a publication-quality 3-class probability bar chart using matplotlib.
- Apply psychological color palettes (`#27ae60` green, `#c0392b` red, `#e67e22` amber) mapped to target classes.
- Format chart axes, title, y-limits ($[0, 1]$), and background grid lines for visual clarity.
- Annotate bar charts with centered data labels displaying exact percentage values using `ax.text`.

## 2. Prerequisites
- Completion of Lesson 01.
- Basic familiarity with matplotlib figure and axis objects (`fig, ax = plt.subplots`).

## 3. Real-World Context & Business Motivation
Data science is not merely about calculating numbers; it is about communicating insights effectively to human decision-makers. In an executive boardroom or on a consumer-facing streaming app, showing a raw Python array like `array([0.8897, 0.0125, 0.0978])` creates cognitive friction and confusion.

To transform cold mathematical probabilities into an intuitive emotional dashboard, `main.py` builds the **Mood Meter**: a customized horizontal bar chart where probability bars correspond to the familiar colors of a mood ring. By mastering matplotlib styling techniques—custom color dictionaries, percentage annotations, and clean framing—you bridge the gap between machine learning algorithms and executive storytelling.

## 4. Concept Explanation
### The Mood Meter Chart Architecture
The Mood Meter chart is constructed around five core design principles:
1. **Psychological Color Mapping:**
   Colors evoke immediate intuitive meaning:
   - Positive $\to$ Emerald Green (`#27ae60`): Signals delight, approval, and success.
   - Negative $\to$ Pomegranate Red (`#c0392b`): Signals frustration, rejection, and critique.
   - Mixed $\to$ Tangerine Amber (`#e67e22`): Signals nuance, caution, and ambivalence.
2. **Fixed Probability Scale ($[0, 1]$):**
   Setting `ax.set_ylim(0, 1)` anchors the vertical axis to the full theoretical probability range. Without this, matplotlib would auto-scale the y-axis to the maximum value (e.g., 0.89), exaggerating smaller bars and distorting visual comparisons.
3. **Subtle Background Grid:**
   A light horizontal grid (`ax.grid(axis="y", alpha=0.25)`) allows viewers to track bar heights without visual clutter.
4. **Direct Bar Labeling (`ax.text`):**
   Placing data labels directly above each bar eliminates the need for viewers to squint at the y-axis ticks.

### Programmatic Construction of ax.text
To print percentage text centered above each bar:
```python
for i, probability in enumerate(sample_probabilities):
    ax.text(i, probability + 0.02, f"{probability:.0%}", ha="center")
```
- `i`: The horizontal x-coordinate of the bar (0 for mixed, 1 for negative, 2 for positive).
- `probability + 0.02`: The vertical y-coordinate, positioned slightly above the bar top.
- `f"{probability:.0%}"`: Python format specifier converting `0.8897` to `"89%"`.
- `ha="center"`: Horizontally centers the text string over the bar.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 73-87 render the complete Mood Meter artifact:
```python
    # ---- Mood meter for one review ------------------------------------
    sample_review = new_reviews[0]
    sample_probabilities = model.predict_proba([sample_review])[0]
    fig, ax = plt.subplots(figsize=(6, 4))
    colours = {"positive": "#27ae60", "negative": "#c0392b", "mixed": "#e67e22"}
    ax.bar(classes, sample_probabilities, color=[colours[c] for c in classes])
    ax.set_ylim(0, 1)
    ax.set_ylabel("probability")
    ax.set_title("Mood meter for: 'I loved the acting... but the ending felt rushed'")
    for i, probability in enumerate(sample_probabilities):
        ax.text(i, probability + 0.02, f"{probability:.0%}", ha="center")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(OUT / "mood_meter.png", dpi=150, bbox_inches="tight")
    plt.close(fig)
```
Let us trace each line:
- `fig, ax = plt.subplots(figsize=(6, 4))`: Allocates a 6x4 inch canvas.
- `color=[colours[c] for c in classes]`: List comprehension ensuring each bar's color matches its class name dynamically.
- `fig.savefig(..., dpi=150, bbox_inches="tight")`: Saves a crisp, high-DPI image with cropped whitespace.
- `plt.close(fig)`: Closes the figure immediately, reclaiming memory.

## 6. Worked Example
Let us trace what matplotlib renders for `sample_review = new_reviews[0]`:
- Review: *"I loved the acting and the story was beautiful, but the ending felt rushed."*
- `sample_probabilities`: `[0.8897, 0.0125, 0.0978]`
- `classes`: `['mixed', 'negative', 'positive']`

1. **Bar 1 (`mixed`):**
   - Height: 0.8897
   - Color: `#e67e22` (Amber)
   - Text label: `"89%"` positioned at $(0, 0.9097)$
2. **Bar 2 (`negative`):**
   - Height: 0.0125
   - Color: `#c0392b` (Red)
   - Text label: `"1%"` positioned at $(1, 0.0325)$
3. **Bar 3 (`positive`):**
   - Height: 0.0978
   - Color: `#27ae60` (Green)
   - Text label: `"10%"` positioned at $(2, 0.1178)$

The resulting image displays a towering amber bar, visually communicating strong ambivalence.

## 7. Step-by-Step Student Instructions
1. Run `python main.py` in your terminal.
2. Navigate to `outputs/` and open `mood_meter.png`.
3. Verify that the three bars are labeled `mixed`, `negative`, and `positive`.
4. Confirm that the amber bar reaches ~89%, the green bar reaches ~10%, and the red bar reaches ~1%.
5. Check that the y-axis spans exactly from 0.0 to 1.0.

## 8. Expected Output or Observable Behaviour
When opening `outputs/mood_meter.png`:
- Title: *"Mood meter for: 'I loved the acting... but the ending felt rushed'"*
- Vertical axis: "probability" spanning 0.0 to 1.0.
- Three cleanly spaced bars: Amber (89%), Red (1%), Green (10%).
- Crisp rendering at 150 DPI without clipped borders.

## 9. Practical Exercises (with Success Criteria)
- **Task 2.1:** Modify the code locally to generate a mood meter chart for `new_reviews[2]` (*"A delightful film with warm characters and a happy ending."*). Describe the bar heights and colors in the resulting image.
- **Task 2.2:** Explain why setting `ax.set_ylim(0, 1)` is critical when comparing probability charts across different reviews.
- *Success Criteria:* Identifies that review 2 produces a 92% green bar; explains that fixed y-axis limits preserve relative visual scale across multiple chart comparisons.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Omitting `ax.set_ylim(0, 1)` | Auto-scaling zooms in on small probabilities, making a 35% probability look like 100% | Always anchor probability plots to the fixed $[0, 1]$ mathematical scale. |
| Hardcoding bar colors as a static list `["red", "green", "blue"]` | Breaks if class order shifts or new classes are added | Use a dictionary `colours[c]` mapped dynamically to `classes`. |
| Placing data labels exactly at `y = probability` | The text string overlaps the top edge of the colored bar, making it unreadable | Add an offset like `probability + 0.02` to float the text cleanly above the bar. |

## 11. Best Practices and Code Quality
- Use hex color strings for consistent branding and visual appeal across operating systems.
- Use `bbox_inches="tight"` in `savefig` to prevent title or axis labels from being clipped.
- Always call `plt.close(fig)` after saving figures in production scripts to prevent memory leaks.

## 12. Security, Ethics, and Fair AI Considerations
Data visualization choices can subtly mislead audiences. Auto-scaling a y-axis from 0.88 to 0.90 to make a tiny 2% difference look massive is a common form of deceptive chart design. Setting honest, fixed axes ensures ethical data transparency.

## 13. Summary and Key Takeaways
The Mood Meter transforms abstract probability arrays into an intuitive visual artifact. By mapping class names to semantic colors (`#27ae60`, `#c0392b`, `#e67e22`), setting fixed $[0, 1]$ bounds, and rendering centered data labels, `main.py` provides an interpretable dashboard of viewer mood.

## 14. Knowledge Check Questions
1. What hex color codes are used in `main.py` for positive, negative, and mixed moods?
2. Why is `ax.set_ylim(0, 1)` explicitly set on the probability axis?
3. What does `ax.text(i, probability + 0.02, f"{probability:.0%}", ha="center")` accomplish?
4. What resolution (DPI) is configured when saving `outputs/mood_meter.png`?

## 15. References and Further Reading
- Matplotlib Bar Chart Documentation: https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.bar.html
- Tufte, E. R. (2001). *The Visual Display of Quantitative Information.*
