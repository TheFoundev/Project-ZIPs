# Lesson 01: Discrete Decisions vs Continuous Confidence

**Lesson ID:** lesson-01
**Module:** module-06
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Contrast discrete classification decisions from `model.predict()` with continuous probability vectors from `model.predict_proba()`.
- Explain how scikit-learn aligns probability array columns with `classifier.classes_`.
- Extract predicted class labels alongside associated confidence percentages for novel review strings.
- Evaluate how confidence metrics inform decision thresholds and automated escalation workflows.

## 2. Prerequisites
- Completion of Module 05.
- Understanding of posterior probabilities in Bayes' Theorem.

## 3. Real-World Context & Business Motivation
In consumer-facing software applications, presenting users with an uncalibrated, blunt categorical badge—such as slapping `"mixed"` on a review without context—can feel robotic and unhelpful. An entertainment analyst reviewing thousands of film comments wants to know not just what the model guessed, but **how confident** the model was in that guess.

Did the model predict `"mixed"` because it saw an overwhelming 89% probability of balanced pros and cons? Or did it predict `"mixed"` with a razor-thin 34% plurality where `"positive"` was 33% and `"negative"` was 33%? In automated content moderation, fraud detection, and recommendation systems, distinguishing high-confidence certainty from borderline ambivalence is critical.

## 4. Concept Explanation
### Hard vs Soft Prediction Mechanics
In scikit-learn classifiers:
1. **`model.predict(X)` (Hard Classification):**
   Computes the posterior probabilities for each class and selects the class with the highest probability value:
   $$\hat{y} = \arg\max_{c \in C} P(y = c \mid X)$$
   Returns a 1D NumPy array of string labels (e.g., `['mixed', 'negative', 'positive']`).
2. **`model.predict_proba(X)` (Soft Probabilistic Classification):**
   Computes the normalized posterior probability distribution across all candidate classes:
   $$\mathbf{P}(X) = [P(y = c_0 \mid X), P(y = c_1 \mid X), \dots, P(y = c_{K-1} \mid X)]$$
   Returns a 2D NumPy array of shape $(N_{\text{samples}}, K_{\text{classes}})$, where each row sums to $1.0$.

### Aligning Classes with Probabilities
A frequent source of bugs in beginner code is assuming the order of columns in `predict_proba()` matches the order classes appeared in the training file. In scikit-learn:
**Columns in `predict_proba()` are strictly ordered by `classifier.classes_`!**

For the Movie Mood Ring:
`classifier.classes_` is sorted alphabetically:
- Column index 0: `mixed`
- Column index 1: `negative`
- Column index 2: `positive`

To retrieve the model's confidence in its top predicted class:
```python
prediction = model.predict([review])[0]
probabilities = model.predict_proba([review])[0]
class_idx = list(classifier.classes_).index(prediction)
confidence = probabilities[class_idx]
```

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 61-71 execute this paired inference workflow:
```python
    new_reviews = [
        "I loved the acting and the story was beautiful, but the ending felt rushed.",
        "A boring, confusing mess. I kept checking the time.",
        "A delightful film with warm characters and a happy ending.",
    ]
    new_predictions = model.predict(new_reviews)
    new_probabilities = model.predict_proba(new_reviews)
    print("\nNew review predictions:")
    for review, prediction, probability in zip(new_reviews, new_predictions, new_probabilities):
        confidence = probability[classes.index(prediction)]
        print(f"  {prediction:8s} ({confidence:.0%}) -> {review}")
```
Let us examine the resulting console output:
```text
New review predictions:
  mixed    (89%) -> I loved the acting and the story was beautiful, but the ending felt rushed.
  negative (100%) -> A boring, confusing mess. I kept checking the time.
  positive (92%) -> A delightful film with warm characters and a happy ending.
```
Notice how `confidence` formats the winning probability percentage directly, providing an immediate gauge of model certainty.

## 6. Worked Example
Let us trace the raw 3-element probability array for Review 1:
- Input text: *"I loved the acting and the story was beautiful, but the ending felt rushed."*
- `new_probabilities[0]`: `[0.8897, 0.0125, 0.0978]`
- `classes`: `['mixed', 'negative', 'positive']`

1. **Class 0 (`mixed`):** $0.8897 \implies \mathbf{88.97\%} \approx 89\%$
2. **Class 1 (`negative`):** $0.0125 \implies \mathbf{1.25\%} \approx 1\%$
3. **Class 2 (`positive`):** $0.0978 \implies \mathbf{9.78\%} \approx 10\%$

The highest value is $0.8897$ at index 0 (`mixed`).
The hard prediction selects `"mixed"`, and the confidence score reports **89%**.

## 7. Step-by-Step Student Instructions
1. Open Python interactive console.
2. Load the trained pipeline and define a test sentence:
   ```python
   sample = ["A truly wonderful masterpiece with great cast chemistry."]
   pred = model.predict(sample)[0]
   probs = model.predict_proba(sample)[0]
   print("Prediction:", pred)
   for cls, p in zip(model.named_steps["classifier"].classes_, probs):
       print(f"  {cls:10s}: {p:.4f} ({p:.1%})")
   ```
3. Observe how probability concentrates heavily on the `positive` class ($>90\%$).

## 8. Expected Output or Observable Behaviour
From the interactive console:
```text
Prediction: positive
  mixed     : 0.0412 (4.1%)
  negative  : 0.0403 (4.0%)
  positive  : 0.9185 (91.9%)
```
The predicted mood is `"positive"` with 91.9% confidence.

## 9. Practical Exercises (with Success Criteria)
- **Task 1.1:** Write a Python function `predict_with_threshold(pipeline, text: str, threshold: float = 0.60)` that returns the predicted class if confidence $\ge \text{threshold}$, and returns `"uncertain"` otherwise.
- **Task 1.2:** Explain why an e-commerce platform might want to route all reviews where confidence $< 50\%$ to human content curators.
- *Success Criteria:* Code correctly compares winning probability against threshold; explanation highlights that low confidence indicates semantic ambiguity or mixed signals requiring human review.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Assuming `probabilities[0]` is always the positive class | In scikit-learn, index 0 corresponds to the first alphabetical class (`mixed`) | Always look up class indices dynamically via `list(classifier.classes_).index(...)`. |
| Rounding probabilities before calculating argmax | Can cause false ties if probabilities are close (e.g., 0.34 and 0.33 both round to 0.3) | Always perform argmax on raw floating-point probabilities. |
| Forgetting that `predict_proba` expects a 2D iterable | Passing a single string `model.predict_proba("great film")` tokenizes characters, raising errors | Always wrap single strings in a list: `model.predict_proba(["great film"])`. |

## 11. Best Practices and Code Quality
- Always pass a list of strings (`[review]`) to `.predict()` and `.predict_proba()`.
- Use `classes.index(prediction)` to reliably pair predicted labels with their corresponding confidence scores.
- Store confidence percentages alongside predictions in log files and databases.

## 12. Security, Ethics, and Fair AI Considerations
Relying solely on discrete predictions can lead to brittle automated decision-making. Exposing confidence scores allows organizations to establish conservative decision thresholds, avoiding premature or unfair automated actions on borderline cases.

## 13. Summary and Key Takeaways
While `predict()` returns a discrete argmax class label, `predict_proba()` calculates the full posterior probability vector across all classes. Accessing `classifier.classes_` enables accurate mapping between class names and probabilities, unlocking calibrated confidence scoring for novel reviews.

## 14. Knowledge Check Questions
1. What does `model.predict_proba()` return for a 3-class model?
2. In what order are class probabilities arranged in the `predict_proba` output array?
3. What is the confidence percentage for the review *"A boring, confusing mess. I kept checking the time."* in `main.py`?
4. Why must single review strings be wrapped in a list when calling `model.predict()`?

## 15. References and Further Reading
- Scikit-learn Glossary: `predict_proba` (https://scikit-learn.org/stable/glossary.html#term-predict_proba).
- Zadrozny, B., & Elkan, C. (2002). *Transforming classifier scores into accurate multiclass probability estimates.* KDD.
