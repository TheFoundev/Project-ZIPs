# Project Summary: The Movie Review Mood Ring

## Executive Overview

**The Movie Review Mood Ring** is a comprehensive educational machine learning curriculum designed to teach the fundamentals of **Natural Language Processing (NLP)** and **Supervised Multi-Class Text Classification**. Using a carefully balanced corpus of 90 film reviews from `data/movie_reviews.csv` in `beginner-projects-main/AI-ML Beginners/projects/16_movie_mood_ring/`, students build an end-to-end sentiment classification and confidence visualization engine using Python, pandas, numpy, scikit-learn, and matplotlib.

Unlike conventional binary sentiment models that reduce all human opinion to simplistic thumbs-up / thumbs-down classifications, this project introduces a 3-class taxonomy: `positive`, `negative`, and `mixed`. Students implement the **Mood Ring** paradigm—extracting full posterior probability distributions via `model.predict_proba()` to visualize how confident the model is in its assessment through an intuitive 3-color bar chart.

---

## Core Competencies & Pedagogical Roadmap

The curriculum is structured across 6 progressive learning modules totaling 24 in-depth lessons and 6 hands-on exercise sets:

1. **Module 01: Project Overview, Dataset Architecture & 3-Class Sentiment**
   - Framing supervised multi-class NLP problems.
   - Deconstructing the 90-sample balanced dataset (30 positive, 30 negative, 30 mixed).
   - The linguistic and commercial necessity of 'mixed' sentiment in creative critiques.
   - The Mood Ring metaphor and continuous probability spectra.

2. **Module 02: Text Preprocessing, Bag-of-Words & N-Gram Tokenization**
   - Mechanics of tokenization, case normalization, and punctuation handling.
   - Stop-word filtering: preserving signal while shedding syntactic noise.
   - Moving beyond unigrams: capturing compound sentiment phrases with bigrams (`ngram_range=(1, 2)`).
   - Document-Term Matrix (DTM) construction and vocabulary mapping.

3. **Module 03: Feature Extraction & Sparse Document-Term Matrices**
   - Memory management: Compressed Sparse Row (CSR) matrices and matrix sparsity (95.83%).
   - Stratified train/test splitting (75% train / 25% test) preserving balanced class ratios.
   - The critical boundary between training and testing: eliminating data leakage.
   - Vocabulary indexing, token lookup, and word frequency histograms.

4. **Module 04: Multinomial Naive Bayes & Laplace Smoothing**
   - Mathematical derivation of Bayes' Theorem for text classification.
   - The conditional independence assumption: theoretical limits and practical resilience.
   - The zero-frequency catastrophe and additive Laplace smoothing ($\alpha=1.0$).
   - Log-space computation: preventing arithmetic underflow when multiplying small likelihoods.

5. **Module 05: Model Training, Evaluation & Diagnostic Confusion Matrix**
   - Multi-class evaluation metrics: Accuracy (100.0% benchmark), Precision, Recall, and F1-score.
   - Macro-averaging vs. weighted-averaging in multi-class regimes.
   - $3 \times 3$ Confusion Matrix analysis and visual heatmap rendering (`outputs/confusion_matrix.png`).
   - Feature importance mining: ranking top predictive n-grams per mood from `feature_log_prob_`.

6. **Module 06: Probability Distributions, Mood Meter & Extensions**
   - Hard argmax predictions (`predict`) vs. continuous probability vectors (`predict_proba`).
   - Designing the 3-class Mood Meter bar chart with psychological color coding.
   - Linguistic stress-testing: sarcasm, verbal irony, and Bag-of-Words architectural limitations.
   - Production reporting, persistence to `outputs/predictions.txt`, and advanced transformer extensions.

---

## Technical Highlights & Dataset Benchmarks

- **Corpus**: 90 movie reviews (balanced: 30 positive, 30 negative, 30 mixed).
- **Partitioning**: 67 training reviews (75%), 23 testing reviews (25%), stratified by mood.
- **Vocabulary Size**: 254 features (unigrams and bigrams).
- **Sparsity**: 95.83% of entries in the $67 \times 254$ training matrix are zero.
- **Test Performance**: 100.0% accuracy on the 23-sample held-out test partition.
- **Top Features Learned**:
  - *Mixed*: `'score'`, `'plot'`, `'acting'`, `'great acting'`, `'plot holes'`, `'holes'`.
  - *Negative*: `'time'`, `'pacing'`, `'awful'`, `'checking'`, `'jokes flat'`, `'checking time'`.
  - *Positive*: `'wonderful'`, `'great'`, `'movie'`, `'chemistry'`, `'cast'`, `'cast great'`.
- **Inference Diagnostics**:
  - Review 0 (*"I loved the acting and the story was beautiful, but the ending felt rushed."*): **89% Mixed**, 10% Positive, 1% Negative.
  - Review 1 (*"An absolute masterpiece, breathtaking visuals and incredible performances throughout."*): **97% Positive**, 3% Mixed, 0% Negative.
  - Review 2 (*"Boring, predictable, and a complete waste of two hours. Do not watch."*): **95% Negative**, 5% Mixed, 0% Positive.
