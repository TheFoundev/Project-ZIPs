# Prerequisites: The Movie Review Mood Ring

Before beginning **The Movie Review Mood Ring** project, review the technical requirements, software libraries, and conceptual foundations detailed below.

---

## 1. Technical Skills Required

- **Python Programming Fundamentals**:
  - Functions, arguments, keyword arguments, and return types.
  - Basic data structures: lists, dictionaries, tuples, and sets.
  - String manipulation methods: lowercasing, splitting, stripping, and f-string formatting (`f"{accuracy:.1%}"`).
  - Object-oriented programming basics: instantiating classes and invoking methods (`model.fit()`, `model.predict()`).
  - Defensive filesystem operations with `pathlib.Path` (`ROOT / "outputs"`, `.mkdir(parents=True, exist_ok=True)`).
- **Tabular Data Operations (pandas & numpy)**:
  - Loading CSV files into DataFrames with `pd.read_csv()`.
  - Checking dataset shape (`df.shape`), missing values (`df.isna().sum()`), and distributions (`df['mood'].value_counts()`).
  - Series indexing and NumPy array manipulations (`np.argsort()`, array slicing `[::-1]`).
- **Introductory Machine Learning Concepts**:
  - Supervised learning workflow: separating inputs ($X$) from targets ($y$).
  - Train/test partitioning to prevent memorization and assess out-of-sample generalization.
  - Classification vs. regression distinctions.

---

## 2. Mathematical Foundations

- **Probability Fundamentals**:
  - Probability axioms: $0.0 \le P(E) \le 1.0$ and $\sum_i P(E_i) = 1.0$.
  - Joint and conditional probability: $P(A \cap B)$ and $P(A \mid B)$.
- **Logarithmic Arithmetic**:
  - Understanding why $\ln(A \times B) = \ln(A) + \ln(B)$.
  - Motivation for working in log-space: preventing arithmetic floating-point underflow when multiplying many small fractions.
- **Evaluation Arithmetic**:
  - Fractions and percentages for accuracy, precision, recall, and harmonic mean (F1-score).

---

## 3. Software Environment & Dependencies

To execute the project pipeline successfully, ensure your environment meets the following specifications:

- **Python Interpreter**: Python 3.9, 3.10, 3.11, or 3.12.
- **Core Libraries**:
  - `pandas` (>= 1.5.0)
  - `numpy` (>= 1.22.0)
  - `scikit-learn` (>= 1.2.0)
  - `matplotlib` (>= 3.6.0)

Installation command:
```bash
pip install pandas numpy scikit-learn matplotlib
```

---

## 4. Hardware Requirements

- **Processor**: Any standard x86-64 or ARM64 processor (Intel, AMD, Apple Silicon).
- **RAM**: Minimum 512 MB available system RAM (dataset and pipeline require < 50 MB total memory).
- **Storage**: Minimum 50 MB free disk space for repository files and generated visual artifacts.
- **Display**: No GUI display required; pipeline uses headless Matplotlib rendering (`matplotlib.use('Agg')`).
