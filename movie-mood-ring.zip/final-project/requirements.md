# Final Project Requirements: The Movie Review Mood Ring

## Project Objective
Reproduce the complete **Movie Review Mood Ring** natural language processing and machine learning pipeline from scratch, adhering to the architecture, software design, and implementation standards established in `main.py`.

Your completed implementation must ingest 3-class film review data, perform stratified train/test partitioning, vectorize text into unigram and bigram frequency features with stop-word filtering, train and evaluate a Multinomial Naive Bayes classifier, compute multi-class metrics (accuracy, precision, recall, F1, confusion matrix), extract top predictive lexical features per mood, evaluate novel complex reviews with continuous confidence probability vectors, render publication-ready visualization artifacts (`mood_meter.png` and `confusion_matrix.png`), and export a persistent formatted text evaluation summary (`predictions.txt`).

---

## Functional Requirements

### 1. Environment and Library Imports
- Configure the non-interactive headless Matplotlib backend prior to importing `pyplot`:
  ```python
  import matplotlib
  matplotlib.use("Agg")
  import matplotlib.pyplot as plt
  ```
- Import standard data manipulation and scientific libraries:
  - `pandas` for CSV ingestion and tabular exploration
  - `numpy` for array indexing, probability ranking, and matrix manipulations
  - `pathlib.Path` for cross-platform file system path resolution
- Import core scikit-learn modules:
  - `sklearn.model_selection.train_test_split`
  - `sklearn.feature_extraction.text.CountVectorizer`
  - `sklearn.naive_bayes.MultinomialNB`
  - `sklearn.metrics.accuracy_score`, `classification_report`, `confusion_matrix`, `ConfusionMatrixDisplay`

### 2. Filesystem Paths & Directory Management
- Define root and subfolder paths dynamically using `pathlib.Path(__file__).resolve().parent`:
  - `DATA_PATH`: points to `data/movie_reviews.csv`
  - `OUTPUT_DIR`: points to `outputs/`
- Ensure that the destination directory `OUTPUT_DIR` is created automatically using `.mkdir(parents=True, exist_ok=True)`.

### 3. Data Ingestion & Integrity Verification
- Load `movie_reviews.csv` into a pandas DataFrame.
- Verify the following schema and dataset properties:
  - Exactly 90 rows and 2 columns: `review` (string text) and `mood` (target label).
  - Class distribution is strictly balanced with 30 reviews each for `'positive'`, `'negative'`, and `'mixed'`.
  - Zero null or missing values across all records.

### 4. Stratified Dataset Partitioning
- Split the dataset into feature series `X = df['review']` and target series `y = df['mood']`.
- Execute a 75/25 split using `train_test_split`:
  - `test_size=0.25`
  - `random_state=42`
  - `stratify=y`
- Confirm resulting partition shapes:
  - Training partition: 67 reviews (23 negative, 22 mixed, 22 positive)
  - Testing partition: 23 reviews (8 negative, 8 positive, 7 mixed)

### 5. Text Vectorization & Feature Engineering
- Instantiate a `CountVectorizer` with the following parameters:
  - `stop_words="english"` to eliminate non-informative grammatical noise
  - `ngram_range=(1, 2)` to capture single words and contiguous 2-word combinations
- Fit the vectorizer exclusively on `X_train` and transform both partitions:
  - `X_train_vec`: shape `(67, 254)`
  - `X_test_vec`: shape `(23, 254)`
- Prevent data leakage by ensuring `vectorizer.fit()` is never invoked on `X_test`.

### 6. Multinomial Naive Bayes Modeling
- Instantiate `MultinomialNB(alpha=1.0)` applying standard Laplace smoothing.
- Fit the classifier on `(X_train_vec, y_train)`.
- Confirm model classes are ordered alphabetically: `['mixed', 'negative', 'positive']`.

### 7. Evaluation & Multi-Class Metrics
- Predict categorical mood labels on the held-out test partition `X_test_vec`.
- Calculate and display:
  - Overall accuracy using `accuracy_score` (target benchmark: 100.0% on this corpus).
  - Detailed classification report using `classification_report(y_test, y_pred, zero_division=0)`.
  - $3 \times 3$ confusion matrix with rows representing actual moods and columns representing predicted moods.

### 8. Feature Importance & Lexical Ranking
- Extract the top 8 most influential words/n-grams for each of the 3 sentiment classes using `model.feature_log_prob_`.
- For each class, sort log-probabilities in descending order using `np.argsort()` and display the top features.

### 9. Novel Review Inference & Confidence Scoring
- Evaluate the model on 3 challenging novel test reviews:
  1. `"I loved the acting and the story was beautiful, but the ending felt rushed."`
  2. `"An absolute masterpiece, breathtaking visuals and incredible performances throughout."`
  3. `"Boring, predictable, and a complete waste of two hours. Do not watch."`
- For each review:
  - Vectorize using the fitted `CountVectorizer.transform()`.
  - Predict discrete mood label with `.predict()`.
  - Extract continuous class probabilities with `.predict_proba()`.
  - Format output showing confidence percentage for each mood state.

### 10. Publication-Quality Visualizations
- **Confusion Matrix Plot (`outputs/confusion_matrix.png`)**:
  - Render using `ConfusionMatrixDisplay`.
  - Colormap: `cmap="YlGnBu"`.
  - Save at 150+ DPI with `bbox_inches="tight"`.
- **Mood Meter Bar Chart (`outputs/mood_meter.png`)**:
  - Visualize the 3-class probability distribution for Review 0.
  - Colors: Positive = `#27ae60` (green), Negative = `#c0392b` (red), Mixed = `#e67e22` (amber).
  - Set fixed y-axis limits `(0, 1.05)` with horizontal dashed grid lines.
  - Render exact percentage labels (e.g., `89.0%`) above each bar.
  - Title includes the reviewed text snippet.

### 11. Persistent Reporting
- Write a structured evaluation summary to `outputs/predictions.txt`.
- Include overall test metrics, confusion matrix, top vocabulary features, and test review predictions with probabilities.
