# Mentor Solution Guide: The Movie Review Mood Ring

## Overview
This guide provides mentors and instructors with complete reference implementations, validation checkpoints, step-by-step code annotations, and troubleshooting advice for evaluating student implementations of **The Movie Review Mood Ring** final project.

---

## Reference Implementation Checkpoints

### Checkpoint 1: Headless Matplotlib & Pathlib Imports
```python
import matplotlib
matplotlib.use("Agg")  # Must be invoked prior to importing pyplot
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pathlib import Path

from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    ConfusionMatrixDisplay,
)
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
```
*Verification*: Ensure `matplotlib.use("Agg")` executes before `import matplotlib.pyplot as plt` to prevent GUI backend crashes in headless environments.

---

### Checkpoint 2: Path Management & Data Ingestion
```python
ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "data" / "movie_reviews.csv"
OUTPUT_DIR = ROOT / "outputs"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

df = pd.read_csv(DATA_PATH)
```
*Verification*:
- `df.shape` must equal `(90, 2)`.
- `df['mood'].value_counts().to_dict()` must equal `{'positive': 30, 'negative': 30, 'mixed': 30}`.
- `df.isna().sum().sum()` must equal `0`.

---

### Checkpoint 3: Stratified Train/Test Split
```python
X = df["review"]
y = df["mood"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)
```
*Verification*:
- `len(X_train)` is 67; `len(X_test)` is 23.
- Class distribution in `y_train`: 23 negative, 22 mixed, 22 positive.
- Class distribution in `y_test`: 8 negative, 8 positive, 7 mixed.

---

### Checkpoint 4: CountVectorizer with Unigrams & Bigrams
```python
vectorizer = CountVectorizer(stop_words="english", ngram_range=(1, 2))
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)
```
*Verification*:
- Vocabulary size `len(vectorizer.vocabulary_)` must be exactly 254 features.
- `X_train_vec.shape` is `(67, 254)`.
- `X_test_vec.shape` is `(23, 254)`.
- `vectorizer.fit_transform()` is called ONLY on `X_train`.

---

### Checkpoint 5: Multinomial Naive Bayes Training & Evaluation
```python
model = MultinomialNB(alpha=1.0)
model.fit(X_train_vec, y_train)

y_pred = model.predict(X_test_vec)
accuracy = accuracy_score(y_test, y_pred)
report = classification_report(y_test, y_pred, zero_division=0)
cm = confusion_matrix(y_test, y_pred, labels=model.classes_)
```
*Verification*:
- `accuracy` on this test set is `1.0` (100.0%).
- `cm` is a diagonal matrix: `[[7, 0, 0], [0, 8, 0], [0, 0, 8]]`.
- `model.classes_` is `array(['mixed', 'negative', 'positive'])`.

---

### Checkpoint 6: Top Words Extraction per Mood
```python
feature_names = np.array(vectorizer.get_feature_names_out())
top_features = {}
for i, class_label in enumerate(model.classes_):
    top_indices = np.argsort(model.feature_log_prob_[i])[::-1][:8]
    top_features[class_label] = feature_names[top_indices]
```
*Verification*:
- `top_features['mixed']`: includes `'score'`, `'plot'`, `'acting'`, `'great acting'`, `'holes'`.
- `top_features['negative']`: includes `'time'`, `'pacing'`, `'awful'`, `'checking'`, `'jokes flat'`.
- `top_features['positive']`: includes `'wonderful'`, `'great'`, `'movie'`, `'chemistry'`, `'cast'`.

---

### Checkpoint 7: Novel Reviews & Probability Diagnostics
```python
new_reviews = [
    "I loved the acting and the story was beautiful, but the ending felt rushed.",
    "An absolute masterpiece, breathtaking visuals and incredible performances throughout.",
    "Boring, predictable, and a complete waste of two hours. Do not watch.",
]

new_X = vectorizer.transform(new_reviews)
new_preds = model.predict(new_X)
new_probs = model.predict_proba(new_X)
```
*Verification*:
- Review 0: Predicted `'mixed'`, mixed probability $\approx 89\%$.
- Review 1: Predicted `'positive'`, positive probability $\approx 97\%$.
- Review 2: Predicted `'negative'`, negative probability $\approx 95\%$.

---

### Checkpoint 8: Matplotlib Mood Meter Generation
```python
fig, ax = plt.subplots(figsize=(7, 4.5))
classes = model.classes_
probs = new_probs[0]
colors = [
    "#27ae60" if c == "positive" else "#c0392b" if c == "negative" else "#e67e22"
    for c in classes
]

bars = ax.bar(classes, probs, color=colors, width=0.55, edgecolor="black", linewidth=0.8)
ax.set_ylim(0, 1.05)
ax.set_ylabel("Probability", fontsize=11)
ax.set_title("Mood Meter: Review 1", fontsize=13, fontweight="bold")
for bar, p in zip(bars, probs):
    ax.text(
        bar.get_x() + bar.get_width() / 2,
        bar.get_height() + 0.02,
        f"{p:.1%}",
        ha="center",
        fontweight="bold",
    )
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "mood_meter.png", dpi=150)
plt.close()
```
*Verification*: Image saved to `outputs/mood_meter.png` at 150 DPI without clipping.

---

## Common Student Pitfalls & Debugging Strategies

1. **Data Leakage via Vectorizer**:
   - *Symptom*: Student calls `vectorizer.fit_transform(df['review'])` before splitting.
   - *Fix*: Fit the vectorizer strictly on `X_train`.

2. **Inverted or Unordered Confusion Matrix**:
   - *Symptom*: Labels in confusion matrix do not align with `model.classes_`.
   - *Fix*: Pass `labels=model.classes_` to both `confusion_matrix()` and `ConfusionMatrixDisplay()`.

3. **Matplotlib Memory Leak / GUI Freeze**:
   - *Symptom*: Script blocks on headless server or consumes memory during repeated runs.
   - *Fix*: Enforce `matplotlib.use("Agg")` and call `plt.close()` after each `savefig()`.
