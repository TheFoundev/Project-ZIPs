# The Movie Review Mood Ring: 3-Class Sentiment Analysis & NLP Educational Package

Welcome to **The Movie Review Mood Ring** educational project. This curriculum guides beginner AI, machine learning, and data science students through the end-to-end design, implementation, and operationalization of a **Supervised Multi-Class Natural Language Processing (NLP)** pipeline in Python.

---

## Project At A Glance

- **Domain**: Natural Language Processing & Sentiment Analysis
- **Problem**: 3-Class Sentiment Classification (`mixed`, `negative`, `positive`)
- **Dataset**: `data/movie_reviews.csv` (90 balanced film reviews, 30 per class)
- **Feature Extraction**: `CountVectorizer(stop_words='english', ngram_range=(1, 2))` (254 n-gram features)
- **Classifier**: `MultinomialNB(alpha=1.0)` (Multinomial Naive Bayes with Laplace Smoothing)
- **Visual Artifacts**:
  - `outputs/confusion_matrix.png` (Diagnostic $3 \times 3$ confusion matrix heatmap)
  - `outputs/mood_meter.png` (Publication-grade 3-bar confidence distribution chart)
- **Text Artifact**: `outputs/predictions.txt` (Structured evaluation metrics and novel review predictions)

---

## Curriculum Structure

This educational package contains 6 comprehensive modules, each comprising 4 structured lessons, a practical exercise suite, an assessment, and an answer key:

- **Module 01**: Project Overview, Dataset Architecture & 3-Class Sentiment
- **Module 02**: Text Preprocessing, Bag-of-Words & N-Gram Tokenization
- **Module 03**: Feature Extraction & Sparse Document-Term Matrices
- **Module 04**: Multinomial Naive Bayes & Laplace Smoothing
- **Module 05**: Model Training, Evaluation & Diagnostic Confusion Matrix
- **Module 06**: Probability Distributions, Mood Meter & Extensions

Additionally, the package includes:
- `final-project/`: Project requirements, mentor solution guide, and 105-point evaluation rubric.
- `ALL_ASSESSMENT_ANSWERS.md`: Complete compilation of all 60 assessment questions and solutions.
- `architecture.md`: Visual and analytical system architecture specification.
- `glossary.md`: Comprehensive reference table of technical terms.
- `setup-guide.md`: Step-by-step installation and environment execution guide.

---

## Quickstart Instructions

### 1. Environment Setup
Ensure Python 3.9+ is installed, then install required dependencies:
```bash
pip install pandas numpy scikit-learn matplotlib
```

### 2. Execute the Pipeline
Navigate to the project root directory and execute `main.py`:
```bash
python main.py
```

### 3. Expected Console Output
```text
Dataset shape: (90, 2)

Mood distribution:
mood
negative    30
positive    30
mixed       30
Name: count, dtype: int64

Training set: 67 reviews
Test set:     23 reviews
Vocabulary size: 254 features

Accuracy: 100.0%

Classification Report:
              precision    recall  f1-score   support

       mixed       1.00      1.00      1.00         7
    negative       1.00      1.00      1.00         8
    positive       1.00      1.00      1.00         8

    accuracy                           1.00        23
   macro avg       1.00      1.00      1.00        23
weighted avg       1.00      1.00      1.00        23

Top words per mood:
  mixed: score, score plot, plot holes, plot, great acting, holes, acting, acting beautiful
  negative: time, time jokes, pacing, pacing awful, jokes flat, checking time, checking, awful
  positive: time, wonderful, great, movie, chemistry, jokes landed, cast, cast great

New Review Predictions:
  "I loved the acting and the story was beautiful, but the ending felt rushed."
    --> Predicted Mood: mixed (mixed: 89%, negative: 1%, positive: 10%)
  "An absolute masterpiece, breathtaking visuals and incredible performances throughout."
    --> Predicted Mood: positive (mixed: 3%, negative: 0%, positive: 97%)
  "Boring, predictable, and a complete waste of two hours. Do not watch."
    --> Predicted Mood: negative (mixed: 5%, negative: 95%, positive: 0%)
```

### 4. Generated Artifacts
Check the `outputs/` folder for generated artifacts:
- `outputs/confusion_matrix.png`
- `outputs/mood_meter.png`
- `outputs/predictions.txt`
