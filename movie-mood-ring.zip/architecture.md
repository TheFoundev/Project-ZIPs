# Architecture & Data Flow: The Movie Review Mood Ring

## 1. Pipeline Overview

The **Movie Review Mood Ring** implements an end-to-end natural language processing and supervised machine learning classification pipeline. The architecture takes raw unstructured film review texts, transforms them into numerical n-gram frequency features, fits a Multinomial Naive Bayes classifier with additive Laplace smoothing, evaluates performance across 3 balanced sentiment classes (`mixed`, `negative`, `positive`), and exports both visual diagnostic artifacts and formatted text prediction reports.

```mermaid
flowchart TD
    A[data/movie_reviews.csv<br/>90 Balanced Reviews] --> B[Data Ingestion & Integrity Check<br/>pandas.read_csv]
    B --> C[Stratified Train/Test Split<br/>75% Train : 25% Test<br/>random_state=42]
    C --> D1[Training Partition<br/>67 Reviews]
    C --> D2[Testing Partition<br/>23 Reviews]
    D1 --> E[CountVectorizer Fit & Transform<br/>ngram_range=1,2 | stop_words=english]
    E --> F1[X_train_vec<br/>67 x 254 Sparse Matrix]
    D2 --> G[CountVectorizer Transform Only<br/>No Data Leakage]
    G --> F2[X_test_vec<br/>23 x 254 Sparse Matrix]
    F1 --> H[MultinomialNB Fit<br/>alpha=1.0 Laplace Smoothing]
    H --> I[Model Evaluation on X_test_vec]
    I --> J1[Overall Accuracy: 100.0%]
    I --> J2[Classification Report<br/>Precision, Recall, F1]
    I --> J3[Confusion Matrix<br/>3x3 Diagonal Matrix]
    H --> K[Feature Importance Extraction<br/>model.feature_log_prob_]
    H --> L[Novel Review Inference<br/>predict & predict_proba]
    J3 --> M1[outputs/confusion_matrix.png<br/>Matplotlib / YlGnBu Heatmap]
    L --> M2[outputs/mood_meter.png<br/>3-Bar Mood Meter Chart]
    J1 & J2 & K & L --> M3[outputs/predictions.txt<br/>Comprehensive Evaluation Report]
```

---

## 2. Architectural Components & Data Contracts

### Component 1: Data Ingestion & Validation
- **Input Contract**: `data/movie_reviews.csv` with columns `['review', 'mood']`.
- **Validation Rules**:
  - Exact row count: 90 records.
  - Absence of null values in both columns.
  - Equal class representation: exactly 30 reviews each for `positive`, `negative`, and `mixed`.
- **Output Contract**: Pandas DataFrame `df` of shape `(90, 2)`.

### Component 2: Stratified Partitioning
- **Mechanism**: `train_test_split(df['review'], df['mood'], test_size=0.25, random_state=42, stratify=df['mood'])`.
- **Guarantee**: Preserves identical 1:1:1 class proportions across both training and test partitions.
- **Output Contracts**:
  - `X_train`: Series of length 67.
  - `y_train`: Series of length 67 (23 negative, 22 mixed, 22 positive).
  - `X_test`: Series of length 23.
  - `y_test`: Series of length 23 (8 negative, 8 positive, 7 mixed).

### Component 3: N-Gram Vectorization Engine
- **Mechanism**: `sklearn.feature_extraction.text.CountVectorizer(stop_words='english', ngram_range=(1, 2))`.
- **Leakage Prevention Contract**:
  - `vectorizer.fit_transform(X_train)` establishes fixed vocabulary of 254 features.
  - `vectorizer.transform(X_test)` projects test data into the identical 254-dimensional feature space without vocabulary updates.
- **Output Contracts**:
  - `X_train_vec`: Scipy CSR matrix of shape `(67, 254)`, containing 710 stored elements (95.83% sparsity).
  - `X_test_vec`: Scipy CSR matrix of shape `(23, 254)`.

### Component 4: Multinomial Naive Bayes Estimator
- **Model**: `sklearn.naive_bayes.MultinomialNB(alpha=1.0)`.
- **Mathematical Specification**:
  $$\hat{y} = \arg\max_{c \in C} \left[ \ln P(y=c) + \sum_{i=1}^{V} x_i \ln P(w_i | y=c) \right]$$
  where smoothed conditional likelihoods are computed via:
  $$P(w_i | y=c) = \frac{N_{ci} + \alpha}{N_c + \alpha V}$$
- **State Attributes**:
  - `model.classes_`: Alphabetically indexed `array(['mixed', 'negative', 'positive'])`.
  - `model.class_log_prior_`: Uniform class prior log-probabilities.
  - `model.feature_log_prob_`: Matrix of shape `(3, 254)` representing log likelihoods of each n-gram per sentiment class.

### Component 5: Evaluation & Diagnostic Visualizations
- **Headless Backend**: `matplotlib.use('Agg')` guarantees deterministic execution on headless servers and CI/CD pipelines.
- **Confusion Matrix**: Rendered via `ConfusionMatrixDisplay` using colormap `YlGnBu`.
- **Mood Meter Bar Chart**:
  - Visualizes continuous output of `model.predict_proba(new_X)[0]`.
  - Maps classes to distinct semantic hex codes: `#27ae60` (positive), `#c0392b` (negative), `#e67e22` (mixed).
  - Enforces fixed axis `ax.set_ylim(0, 1.05)` to ensure proportional visual comparison.

---

## 3. Data Transformations & Shape Traceability

| Step | Operation | Input Shape | Output Shape | Output Type |
|---|---|---|---|---|
| 1 | CSV Ingestion | File (90 rows) | `(90, 2)` | `pd.DataFrame` |
| 2 | Series Extraction | `(90, 2)` | `(90,)`, `(90,)` | `pd.Series` |
| 3 | Stratified Split | `(90,)` | Train: `(67,)`, Test: `(23,)` | `pd.Series` |
| 4 | Vectorizer Fit/Transform | `(67,)` | `(67, 254)` | `scipy.sparse.csr_matrix` |
| 5 | Vectorizer Transform | `(23,)` | `(23, 254)` | `scipy.sparse.csr_matrix` |
| 6 | Model Fit | `(67, 254)`, `(67,)` | Fitted Estimator | `MultinomialNB` |
| 7 | Predict Labels | `(23, 254)` | `(23,)` | `np.ndarray` (str) |
| 8 | Predict Probabilities | `(3, 254)` | `(3, 3)` | `np.ndarray` (float) |
| 9 | Feature Log-Probabilities | Parameter | `(3, 254)` | `np.ndarray` (float) |

---

## 4. Design Tradeoffs & Architectural Boundaries

1. **Bag-of-Words vs. Contextual Embeddings**:
   - *Advantage*: Extremely fast training (<5ms), near-zero memory footprint, zero GPU requirements, high interpretability via `feature_log_prob_`.
   - *Limitation*: Syntactic blind spot regarding sarcasm and complex negation where positive words are used ironically.

2. **Stratified Holdout vs. Cross-Validation**:
   - *Advantage*: Transparent demonstration of training/testing isolation and straightforward confusion matrix generation.
   - *Future Direction*: $K$-fold stratified cross-validation ($k=5$) for robust variance estimation on small corpora.

3. **Additive Laplace Smoothing ($\alpha=1.0$)**:
   - *Advantage*: Solves the zero-frequency problem mathematically without arbitrary heuristics.
   - *Limitation*: Mildly regresses probability estimates toward uniform distributions, resulting in poorly calibrated raw probabilities (overconfident posteriors).
