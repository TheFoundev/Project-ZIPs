# The Chatbot That Guesses Your Favorite Subject

## Overview
**The Chatbot That Guesses Your Favorite Subject** bridges classical artificial intelligence (expert systems and rule-based decision logic) and modern machine learning (supervised classification with Decision Trees). Rather than hand-coding dozens of brittle `if/else` conditions to build a career counseling quiz, we train a decision tree on 90 empirical student survey responses. The algorithm automatically induces the optimal flowchart of questions, which our Python script deploys as an automated batch evaluator and a live interactive conversational agent.

---

## Real-World Use Case
Personalized recommendation systems, educational diagnostic quizzes, triage bots in healthcare, and automated customer service routing all rely on classification engines that ask targeted qualifying questions to guide users toward an optimal solution. This project demonstrates how an interpretable machine learning model can serve as the core reasoning engine of an interactive conversational assistant.

---

## Key Features Implemented
1. **Dataset Loading & Preprocessing**:
   - Ingests `data/subject_answers.csv` containing 90 student profiles.
   - Extracts 6 binary preference features ($X$) and the academic subject target ($y$).
2. **Stratified Partitioning**:
   - Implements `train_test_split(..., test_size=0.25, random_state=42, stratify=y)`.
   - Protects minority class ratios across 67 training and 23 testing instances.
3. **Decision Tree Classification**:
   - Configures `DecisionTreeClassifier(max_depth=4, random_state=42)`.
   - Balances predictive expressiveness against tree complexity to ensure fast, intuitive Q&A paths.
4. **Comprehensive Evaluation**:
   - Computes overall classification accuracy (~78.3%).
   - Generates a per-class `classification_report` detailing precision, recall, and F1-scores.
5. **Model Interpretability & Visualization**:
   - Exports the tree's logical branch hierarchy into indented text rules (`outputs/rules.txt`).
   - Renders a complete decision flowchart as a high-resolution graphic (`outputs/chatbot_tree.png`).
6. **Dual Execution Architecture**:
   - **Scripted Demo Mode**: Instantly evaluates three distinct synthetic student personas.
   - **Interactive CLI Mode (`--interactive`)**: Engages the user in a 6-question terminal dialogue with robust input sanitization, returning a predicted subject and confidence score.

---

## Technology Stack
- **Python 3.8+**
- **pandas** (Data manipulation and ingestion)
- **matplotlib** (Headless chart and tree rendering with `Agg` backend)
- **scikit-learn** (Machine learning algorithms, validation, and evaluation metrics)

---

## Directory Layout
```
17_subject_chatbot/
├── data/
│   └── subject_answers.csv     # 90 student survey profiles
├── outputs/
│   ├── chatbot_tree.png        # Rendered decision tree flowchart
│   └── rules.txt               # Text decision rules, metrics, demo predictions
├── main.py                     # Primary pipeline script
└── README.md                   # Project instructions
```

---

## Verification & Expected Output
When running `python main.py`:
- Accuracy reported: **78.3%**
- Test set size: **23 samples** (Biology: 6, Literature: 8, Math: 9)
- Scripted Demo Predictions:
  - Student 1 (`[1, 0, 0, 1, 0, 1]`): **Math**
  - Student 2 (`[0, 1, 0, 1, 0, 0]`): **Biology**
  - Student 3 (`[0, 0, 1, 0, 1, 0]`): **Literature**
- Outputs created: `outputs/chatbot_tree.png` and `outputs/rules.txt`.
