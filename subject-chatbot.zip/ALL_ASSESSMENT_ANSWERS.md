# All Correct Answers for Assessments
Project: The Chatbot That Guesses Your Favorite Subject
---

## Module 01
**q1-01.** What type of machine learning task is implemented in The Subject Chatbot?
   **Correct Answer:** b. Supervised multiclass classification
   *Explanation:* The project uses historical survey answers to classify users into one of three discrete academic categories (Math, Biology, Literature). Because the target consists of distinct categories, this is a supervised multiclass classification problem.

**q1-02.** How many binary survey questions does the chatbot ask the user?
   **Correct Answer:** c. 6 questions
   *Explanation:* The project defines exactly 6 binary questions in the QUESTIONS list, corresponding to the 6 features: likes_numbers, likes_living_things, likes_stories, enjoys_experiments, enjoys_debate, and likes_programming.

**q1-03.** Which historical conversational program used simple pattern matching and keyword substitution in 1966?
   **Correct Answer:** c. ELIZA
   *Explanation:* Joseph Weizenbaum created ELIZA at MIT in 1966. It used pattern matching and keyword substitution to simulate a Rogerian psychotherapist.

**q1-04.** Why does main.py call matplotlib.use('Agg') before importing pyplot?
   **Correct Answer:** b. To allow headless rendering without requiring a GUI display server
   *Explanation:* Calling matplotlib.use('Agg') configures matplotlib to use the non-interactive Anti-Grain Geometry raster engine, enabling plot generation on headless servers without display servers (X11/Wayland).

**q1-05.** In a decision tree trained on binary features (0 and 1), why is the split threshold typically set to 0.50?
   **Correct Answer:** b. Because 0.50 is the exact midpoint between the binary values 0 and 1
   *Explanation:* For binary features that take values of 0 or 1, the midpoint boundary separating them is (0 + 1) / 2 = 0.50. Thus, feature <= 0.50 represents 0 ('No') and feature > 0.50 represents 1 ('Yes').

**q1-06.** What does a leaf node (terminal node) in our Subject Chatbot's decision tree represent?
   **Correct Answer:** b. The final predicted academic subject class
   *Explanation:* In a decision tree, leaf nodes are terminal nodes where splitting stops; they store and return the final predicted class label (e.g., 'class: Math').

**q1-07.** What is the primary advantage of pathlib.Path over string concatenation for file paths?
   **Correct Answer:** b. It handles operating-system-specific path separators and resolves absolute locations reliably
   *Explanation:* pathlib.Path provides an object-oriented interface that abstracts operating system differences (handling forward slashes on POSIX and backslashes on Windows) and resolves absolute script locations.

**q1-08.** If a user answers 'No' to a binary feature, which branch does scikit-learn traverse?
   **Correct Answer:** b. The branch where feature <= 0.50
   *Explanation:* Since 'No' is encoded as 0, and 0 is less than or equal to 0.50, the algorithm traverses the left branch: feature <= 0.50.

**q1-09.** What is the knowledge acquisition bottleneck in traditional expert systems?
   **Correct Answer:** b. The difficulty and labor-intensive overhead of manually extracting, codifying, and debugging complex human rules
   *Explanation:* The knowledge acquisition bottleneck describes the immense difficulty human experts and knowledge engineers faced when attempting to manually specify, maintain, and harmonize thousands of IF-THEN rules.

**q1-10.** Why is a Decision Tree preferable to a deep neural network when building an auditable guidance chatbot?
   **Correct Answer:** b. Decision trees provide transparent, human-readable logic rules where every decision path can be audited
   *Explanation:* Decision trees produce an explicit, transparent flowchart of IF-THEN rules where every prediction path can be inspected, explained, and audited for educational fairness.


## Module 02
**q2-01.** How many total student survey response rows are in subject_answers.csv?
   **Correct Answer:** c. 90 rows
   *Explanation:* The dataset contains exactly 90 student survey response rows (plus 1 header row, for 91 lines total in subject_answers.csv).

**q2-02.** What are the allowed values in the 6 feature columns of subject_answers.csv?
   **Correct Answer:** b. Binary integers: strictly 0 or 1
   *Explanation:* All 6 survey questions are encoded as binary integers: 1 represents Yes (affinity present) and 0 represents No (affinity absent).

**q2-03.** Which academic subject has the highest number of student responses in the dataset?
   **Correct Answer:** c. Math
   *Explanation:* In subject_answers.csv, Math has 35 rows, Literature has 29 rows, and Biology has 26 rows. Math is the most frequent category.

**q2-04.** What is the majority-class baseline accuracy for subject_answers.csv?
   **Correct Answer:** b. 38.9%
   *Explanation:* The majority class is Math with 35 samples out of 90 total. The naive majority-class baseline is 35 / 90 = 38.88% (rounded to 38.9%).

**q2-05.** In main.py, how is the feature matrix X created?
   **Correct Answer:** b. X = df[FEATURES]
   *Explanation:* In main.py line 65, X is extracted by subsetting the DataFrame using the list of 6 feature names: X = df[FEATURES].

**q2-06.** What is the mathematical shape of X in our project?
   **Correct Answer:** b. (90, 6)
   *Explanation:* X contains 90 rows (samples) and 6 columns (the 6 survey features), giving it a 2D shape of (90, 6).

**q2-07.** Why does main.py use stratify=y in train_test_split()?
   **Correct Answer:** b. To guarantee that both train and test splits preserve the exact class proportions of Math, Literature, and Biology
   *Explanation:* Stratified sampling (stratify=y) guarantees that both the training set (67 samples) and test set (23 samples) contain the exact same proportions of Math, Literature, and Biology as the original 90 samples.

**q2-08.** What percentage of students who prefer Math answered Yes (1) to likes_programming in the dataset?
   **Correct Answer:** d. 100%
   *Explanation:* In subject_answers.csv, all 35 students who identified Math as their favorite subject answered 1 (Yes) to likes_programming (100% positive rate).

**q2-09.** What severe error occurs if you mistakenly include df['subject'] inside the feature matrix X during model training?
   **Correct Answer:** b. Data leakage occurs, allowing the model to achieve trivial 100% training accuracy by simply memorizing the target column
   *Explanation:* Including the target column inside the feature matrix is known as data leakage. The decision tree will immediately place 'subject' at the root node and achieve 100% fake accuracy by cheating.

**q2-10.** Why are forced-choice binary questions (0/1) often preferred over 1-to-5 Likert scales in quick conversational diagnostic bots?
   **Correct Answer:** b. Because binary questions eliminate subjective rating scale calibration differences and create clean, fast branching paths
   *Explanation:* Binary forced-choice questions eliminate the subjective bias of numerical rating scales (e.g., what does a '3 out of 5' mean?) and directly produce simple binary decision splits (<= 0.50 vs > 0.50).


## Module 03
**q3-01.** What is the Gini impurity of a perfectly pure decision tree node containing only Math students?
   **Correct Answer:** c. 0.0
   *Explanation:* When all samples in a node belong to a single class, p_1 = 1.0 and all other p_i = 0.0. Gini impurity is 1 - (1.0)^2 = 0.0, representing complete purity.

**q3-02.** What is the value of max_depth used in main.py for DecisionTreeClassifier?
   **Correct Answer:** b. max_depth=4
   *Explanation:* main.py line 72 explicitly sets max_depth=4: model = DecisionTreeClassifier(max_depth=4, random_state=42).

**q3-03.** How many demo student personas are evaluated in the default scripted demo mode?
   **Correct Answer:** b. 3 students
   *Explanation:* Lines 85-91 of main.py define exactly three synthetic student personas in demo_profiles to evaluate Math, Biology, and Literature predictions.

**q3-04.** What is the maximum possible Gini impurity for a node in a dataset with 3 equally distributed classes?
   **Correct Answer:** c. 0.667
   *Explanation:* For 3 classes with equal proportions (1/3 each), Gini impurity is 1 - 3*(1/3)^2 = 1 - 3*(1/9) = 1 - 1/3 = 2/3 ≈ 0.667.

**q3-05.** What is the primary danger of leaving max_depth set to None in a DecisionTreeClassifier?
   **Correct Answer:** b. The tree will grow arbitrarily deep, memorizing training noise and overfitting
   *Explanation:* Leaving max_depth=None permits the tree to split until every leaf is pure, memorizing training noise and reducing generalization accuracy on unseen test data.

**q3-06.** Which single question is selected by the CART algorithm as the Root Node in main.py?
   **Correct Answer:** b. likes_programming
   *Explanation:* In outputs/rules.txt and outputs/chatbot_tree.png, the root split is 'likes_programming <= 0.50'. Programming affinity provides the highest initial Information Gain.

**q3-07.** In a decision tree chatbot, what practical user-experience parameter does max_depth directly control?
   **Correct Answer:** b. The maximum number of sequential questions the chatbot will ask any user
   *Explanation:* Each level of depth corresponds to one question asked. Setting max_depth=4 guarantees that no user will ever be asked more than 4 consecutive questions before receiving a prediction.

**q3-08.** What subject does the decision tree predict for Student 1 in demo_profiles ([1, 0, 0, 1, 0, 1])?
   **Correct Answer:** c. Math
   *Explanation:* Student 1 likes numbers (1), experiments (1), and programming (1). The model predicts 'Math', as printed in lines 94-95 of main.py.

**q3-09.** How does the CART algorithm decide which feature to split on at any internal node?
   **Correct Answer:** a. It selects the feature that maximizes Information Gain (greatest reduction in weighted Gini impurity)
   *Explanation:* The CART algorithm evaluates every candidate feature split and chooses the one that maximizes Information Gain (the greatest weighted reduction in Gini impurity).

**q3-10.** Why is separating scripted demo evaluation from interactive Q&A considered an essential software engineering pattern for ML pipelines?
   **Correct Answer:** b. Because automated CI/CD test runners and grading scripts require non-blocking execution, while users require an interactive interface
   *Explanation:* Automated build runners, CI/CD pipelines, and grading test suites cannot interact with human prompts and would hang indefinitely if interactive mode were mandatory.


## Module 04
**q4-01.** What overall accuracy does the trained DecisionTreeClassifier achieve on the 23 test profiles?
   **Correct Answer:** c. 78.3%
   *Explanation:* The trained model correctly classifies 18 out of the 23 test profiles, achieving an accuracy score of 18/23 ≈ 78.26%, formatted as 78.3% in console output.

**q4-02.** How many samples from the 90-profile dataset are allocated to the test set when test_size=0.25?
   **Correct Answer:** b. 23 samples
   *Explanation:* When 90 rows are partitioned with test_size=0.25, 25% of 90 is 22.5, which rounds to exactly 23 test samples (and 67 training samples).

**q4-03.** Which matplotlib function is used in main.py to render the decision tree flowchart onto an axis?
   **Correct Answer:** b. plot_tree()
   *Explanation:* plot_tree() from sklearn.tree renders the decision tree as a graphical flowchart onto a matplotlib axis.

**q4-04.** In the classification report, which academic subject achieved the highest recall (89%)?
   **Correct Answer:** c. Math
   *Explanation:* In the classification report, Math achieved 89% recall (0.89), correctly identifying 8 of the 9 true Math students in the test set.

**q4-05.** What does a high precision score of 0.86 for Literature indicate about the chatbot?
   **Correct Answer:** a. When the chatbot predicts Literature, it is correct 86% of the time
   *Explanation:* Precision is TP / (TP + FP). A precision of 0.86 means that out of all times the chatbot guessed Literature, it was correct 86% of the time.

**q4-06.** Why is plt.close(fig) called after fig.savefig() in main.py?
   **Correct Answer:** b. To release system graphics memory and prevent matplotlib resource leaks
   *Explanation:* Matplotlib figures persist in memory until explicitly closed. Calling plt.close(fig) frees system graphics memory and prevents memory leaks.

**q4-07.** What does setting filled=True do in plot_tree()?
   **Correct Answer:** a. It paints nodes with colors indicating their majority class, with saturation reflecting purity
   *Explanation:* Setting filled=True paints each node box with a color representing its dominant class, where deep saturation indicates high purity (low Gini) and pale colors indicate high uncertainty.

**q4-08.** What subject does the decision tree predict for Student 2 ([0, 1, 0, 1, 0, 0])?
   **Correct Answer:** b. Biology
   *Explanation:* Student 2 likes living things (1) and experiments (1). Following the tree branch leads to class: Biology, as verified in demo predictions.

**q4-09.** What does the 'support' column in scikit-learn's classification report represent?
   **Correct Answer:** b. The actual number of true instances belonging to each class in the test dataset
   *Explanation:* The support column indicates the true frequency count of actual samples belonging to each target class in the test dataset (6 Biology, 8 Literature, 9 Math = 23 total).

**q4-10.** When tracing Student 3 ([0, 0, 1, 0, 1, 0]), why does the tree never evaluate 'likes_numbers'?
   **Correct Answer:** b. Because Student 3 took the left branch at the root (likes_programming <= 0.50), and likes_numbers is only evaluated on the right branch
   *Explanation:* At the root node, Student 3 answered 0 to likes_programming, routing left. In our trained tree, likes_numbers is only evaluated along the right branch (programming > 0.50), so Student 3's path never reaches that question.


## Module 05
**q5-01.** What does sys.argv[0] contain when executing a Python script?
   **Correct Answer:** b. The script name or path itself
   *Explanation:* In Python, sys.argv[0] always stores the script name or execution path (e.g., 'main.py'). Any additional command-line flags begin at index 1.

**q5-02.** Which string methods are chained to sanitize user keyboard input in ask_profile()?
   **Correct Answer:** b. .strip() and .lower()
   *Explanation:* main.py line 52 chains .strip().lower() to remove leading/trailing whitespace and convert the string to lowercase before validation.

**q5-03.** What scikit-learn method returns the estimated probability distribution across classes?
   **Correct Answer:** b. model.predict_proba()
   *Explanation:* model.predict_proba() returns estimated class probabilities for input samples based on training class proportions at terminal leaf nodes.

**q5-04.** Why is 'if "--interactive" in sys.argv:' safer than checking 'if sys.argv[1] == "--interactive":'?
   **Correct Answer:** b. Because accessing sys.argv[1] raises an IndexError if the user passes no arguments
   *Explanation:* When no arguments are passed, sys.argv contains only 1 element (['main.py']). Indexing sys.argv[1] raises an IndexError, whereas 'in' safely returns False.

**q5-05.** In ask_profile(), which tuple defines acceptable affirmative inputs?
   **Correct Answer:** b. ('y', 'yes', '1')
   *Explanation:* main.py line 53 checks if answer in ('y', 'yes', '1') to map common affirmative user entries to binary 1.

**q5-06.** What Python construct pairs the FEATURES list with user answers to create a dictionary in line 60?
   **Correct Answer:** a. dict(zip(FEATURES, answers))
   *Explanation:* zip(FEATURES, answers) pairs each feature header with its corresponding response, and dict() converts the pairs into a dictionary.

**q5-07.** Why must the dictionary be enclosed in a list: pd.DataFrame([dict(...)])?
   **Correct Answer:** b. Because pandas requires a sequence of records when constructing a DataFrame from a dictionary to define rows
   *Explanation:* Wrapping the dictionary in a list [dict(...)] specifies that the dictionary represents a single row (record) of data, producing a DataFrame with shape (1, 6).

**q5-08.** How is prediction confidence computed in main.py line 128?
   **Correct Answer:** b. confidence = probabilities.max()
   *Explanation:* main.py line 128 extracts the highest probability value from the distribution using probabilities.max().

**q5-09.** If a user lands in a leaf node with value = [0, 4, 16], what is the model's confidence for Math?
   **Correct Answer:** c. 80%
   *Explanation:* The total samples in the leaf are 0 + 4 + 16 = 20. The Math probability is 16 / 20 = 0.80 = 80%.

**q5-10.** What happens if a user repeatedly types invalid nonsense like 'asdf' into ask_profile()?
   **Correct Answer:** b. The program prints 'Please type y or n.' and continues looping indefinitely until a valid response is provided
   *Explanation:* The while True loop catches all invalid responses, prints 'Please type y or n.', and re-prompts the user without crashing.


## Module 06
**q6-01.** What flag must be passed to main.py to activate live conversational Q&A?
   **Correct Answer:** b. --interactive
   *Explanation:* Passing the command-line flag --interactive triggers lines 123-129 of main.py, launching the live conversational Q&A loop.

**q6-02.** Out of the 23 test profiles evaluated in main.py, how many were misclassified by the Decision Tree?
   **Correct Answer:** b. 5 profiles
   *Explanation:* The test set has 23 profiles. With 78.3% accuracy, 18 were classified correctly and exactly 5 profiles were misclassified.

**q6-03.** What challenge is presented to students in the project README.md under 'Try this'?
   **Correct Answer:** b. Add a new subject and 20 example profiles
   *Explanation:* The project README.md line 38 explicitly challenges students under 'Try this' to add a new subject and 20 example profiles.

**q6-04.** Why do real-world human preference datasets rarely achieve 100% test accuracy?
   **Correct Answer:** b. Because human interests are complex, interdisciplinary, and occasionally contradictory relative to fixed survey features
   *Explanation:* Human preferences are multifaceted, interdisciplinary, and subjective. When an individual student exhibits atypical preferences across fixed binary survey questions, the model naturally predicts the majority preference.

**q6-05.** If you add a new subject category to subject_answers.csv, what must you ensure about the survey features?
   **Correct Answer:** b. The survey must include discriminatory features that capture the unique characteristics of the new subject
   *Explanation:* If a new category shares identical feature vectors with an existing class, the algorithm cannot separate them. Discriminatory features with distinct affinity profiles are required.

**q6-06.** What is the primary risk of using an unconstrained Generative LLM instead of a Decision Tree for student subject diagnosis?
   **Correct Answer:** b. The LLM can hallucinate non-existent subjects, invent arbitrary rules, and produce un-auditable outputs
   *Explanation:* Generative LLMs are prone to hallucinations, non-deterministic reasoning, and opaque black-box behavior, whereas decision trees provide strict, bounded, auditable classifications.

**q6-07.** In a hybrid neuro-symbolic chatbot architecture, what role does the Decision Tree play?
   **Correct Answer:** b. It serves as the deterministic, auditable decision engine that evaluates extracted feature attributes without hallucination
   *Explanation:* In a neuro-symbolic hybrid, the Decision Tree serves as the deterministic, fully auditable reasoning core that evaluates extracted attributes and guarantees non-hallucinatory outcomes.

**q6-08.** What tool or technique allows developers to inspect exactly which test profiles were misclassified by the model?
   **Correct Answer:** a. Filtering the test DataFrame where model.predict(X_test) != y_test
   *Explanation:* Boolean indexing in pandas with X_test[model.predict(X_test) != y_test] isolates the exact feature rows where predictions differed from ground truth.

**q6-09.** How does a Confusion Matrix help developers diagnose multiclass classification errors?
   **Correct Answer:** b. It cross-tabulates actual vs. predicted class labels, showing exactly which classes are being confused with one another
   *Explanation:* A confusion matrix cross-tabulates actual target classes against predicted classes in a 2D grid, clearly showing where off-diagonal misclassifications occur.

**q6-10.** Why is the Subject Chatbot considered a white-box AI model rather than a black-box model?
   **Correct Answer:** b. Because every decision path can be fully traced, visualized, audited, and explained in human-readable logic rules
   *Explanation:* White-box models provide complete transparency where every prediction can be traced through explicit, human-readable logic rules and visual flowcharts.

