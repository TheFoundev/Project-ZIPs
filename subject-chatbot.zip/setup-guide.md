# Setup Guide

This guide walks you through setting up the runtime environment, verifying the dataset, and executing **The Chatbot That Guesses Your Favorite Subject**.

---

## Step 1: Navigate to the Project Directory
Open your terminal and change directory to the project repository:
```bash
cd beginner-projects-main/AI-ML\ Beginners/projects/17_subject_chatbot
```

Verify your current directory contains `main.py`, `data/`, and `README.md`:
```bash
ls -la
```

---

## Step 2: Set Up a Virtual Environment (Recommended)
Creating an isolated virtual environment prevents library version conflicts:
```bash
# Create a virtual environment named .venv
python -m venv .venv

# Activate the virtual environment
# On Linux / macOS:
source .venv/bin/activate
# On Windows (Command Prompt):
# .venv\Scripts\activate.bat
# On Windows (PowerShell):
# .venv\Scripts\Activate.ps1
```

---

## Step 3: Install Required Dependencies
Install the required packages using `pip`:
```bash
pip install pandas matplotlib scikit-learn
```

Verify the installed packages:
```bash
python -c "import pandas, matplotlib, sklearn; print('All libraries imported successfully!')"
```

---

## Step 4: Verify the Dataset
Inspect the first few lines of the dataset to ensure the CSV file is intact:
```bash
head -n 5 data/subject_answers.csv
```
You should see the 6 binary features (`likes_numbers`, `likes_living_things`, `likes_stories`, `enjoys_experiments`, `enjoys_debate`, `likes_programming`) and the `subject` target column.

---

## Step 5: Run the Project in Scripted Demo Mode
Execute `main.py` without flags to train the decision tree, print evaluation metrics, evaluate demo student profiles, and render outputs:
```bash
python main.py
```

Expected outputs generated in the terminal:
- Model accuracy (~78.3%)
- Classification report (precision, recall, f1-score for Biology, Literature, Math)
- Learned question path in text rule format
- Three simulated demo student predictions

Expected output files generated in `outputs/`:
- `outputs/chatbot_tree.png`: Graphical visualization of the trained decision tree.
- `outputs/rules.txt`: Accuracy, text rules, demo predictions, and full classification report.

---

## Step 6: Run the Project in Live Interactive Mode
Run the script with the `--interactive` flag to experience the chatbot firsthand:
```bash
python main.py --interactive
```
The terminal will prompt you through 6 sequential yes/no questions, construct your preference profile, predict your favorite subject, and report the model's confidence percentage!
