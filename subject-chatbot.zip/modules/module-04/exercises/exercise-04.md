# Module 4 Exercises: Training, Evaluation & Tree Visualization

## Exercise 4.1: Stratified Splitting and Model Training
**Objective:** Replicate the training sequence from `main.py` and verify partition sizes.
**Problem Statement:** Write a Python script to ingest `data/subject_answers.csv`, split the data into training and test sets using `test_size=0.25, random_state=42, stratify=y`, and fit a `DecisionTreeClassifier(max_depth=4, random_state=42)`.

**Requirements:**
1. Verify `X_train.shape` is `(67, 6)` and `X_test.shape` is `(23, 6)`.
2. Verify class counts in `y_test` match Math (9), Literature (8), Biology (6).
3. Confirm that the model fits without raising warnings or errors.

**Acceptance Criteria:**
- [ ] Script executes and prints split shapes.
- [ ] Confirms exact class counts in train and test sets.
- [ ] Model is successfully trained and stored in a variable.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes

---

## Exercise 4.2: Deciphering the Classification Report
**Objective:** Calculate precision, recall, and accuracy from a confusion matrix.
**Problem Statement:** Given the test set predictions from `main.py`, construct a confusion matrix using `sklearn.metrics.confusion_matrix` and verify how precision and recall are calculated for Biology.

**Requirements:**
1. Compute the test set predictions: `predictions = model.predict(X_test)`.
2. Generate and print the confusion matrix using `confusion_matrix(y_test, predictions)`.
3. Locate the True Positives, False Positives, and False Negatives for Biology.
4. Calculate Biology Precision ($TP / (TP + FP)$) and Recall ($TP / (TP + FN)$) by hand and verify they equal 0.67.

**Acceptance Criteria:**
- [ ] Prints valid 3x3 confusion matrix.
- [ ] Correctly identifies TP, FP, and FN for Biology.
- [ ] Confirms precision and recall match the classification report.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 20 minutes

---

## Exercise 4.3: Customizing the Tree Flowchart Graphic
**Objective:** Generate and customize `outputs/chatbot_tree.png`.
**Problem Statement:** Replicate lines 98-111 of `main.py` with custom visual parameters.

**Requirements:**
1. Create a figure with `figsize=(16, 9)` and set the title to "Subject Chatbot Decision Logic".
2. Use `plot_tree()` with `feature_names=FEATURES`, `class_names=list(model.classes_)`, `filled=True`, and `rounded=True`.
3. Save the image to `outputs/custom_tree.png` with `dpi=200`.
4. Call `plt.close(fig)`.

**Acceptance Criteria:**
- [ ] `outputs/custom_tree.png` is created and readable.
- [ ] Uses 200 DPI resolution.
- [ ] Memory is cleaned up using `plt.close()`.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 4.4: Manual Path Tracing for Complex Profiles
**Objective:** Trace an ambiguous student profile through the text rules.
**Problem Statement:** A student answers Yes to `likes_numbers` ($1$), Yes to `likes_stories` ($1$), Yes to `enjoys_debate` ($1$), but No to `likes_programming` ($0$), No to `likes_living_things` ($0$), and No to `enjoys_experiments` ($0$).

**Requirements:**
1. Formulate the student's 6-element feature vector.
2. Manually step through `outputs/rules.txt` from the root node to the final leaf.
3. Record each condition evaluated and the direction taken.
4. State the predicted subject and verify it using `model.predict()`.

**Acceptance Criteria:**
- [ ] Correctly formulates feature vector `[1, 0, 1, 0, 1, 0]`.
- [ ] Traces: `likes_programming <= 0.50` $\longrightarrow$ `likes_stories > 0.50` $\longrightarrow$ `likes_living_things <= 0.50` $\longrightarrow$ `class: Literature`.
- [ ] Confirms prediction is Literature.

**Difficulty:** Advanced  
**Estimated Completion Time:** 15 minutes
