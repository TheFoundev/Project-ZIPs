# Lesson 02: Multiclass Evaluation Metrics: Accuracy, Precision, Recall, and Classification Report

**Lesson ID:** lesson-02
**Module:** module-04
**Duration:** 20 minutes

## Purpose and Learning Objectives
This lesson explains how to evaluate multiclass classification models using overall accuracy and detailed per-class diagnostic metrics (precision, recall, and F1-score).

By the end of this lesson, you will be able to:
- Calculate overall classification accuracy and understand its limitations.
- Define **Precision**, **Recall**, and **F1-Score** for individual classes.
- Interpret the full output of scikit-learn's `classification_report()`.
- Explain the role of `zero_division=0` in preventing division-by-zero runtime warnings.

## Prerequisites
- Completion of Lesson 01.
- Understanding of fractions, percentages, and true vs. false predictions.

## Concept Explanation
### Beyond Raw Accuracy
Overall accuracy is simple:
$$\text{Accuracy} = \frac{\text{Number of Correct Predictions}}{\text{Total Number of Test Samples}}$$
In our test set of 23 students:
- Correct Predictions: 18 students.
- Incorrect Predictions: 5 students.
$$\text{Accuracy} = \frac{18}{23} \approx 78.26\% \implies \mathbf{78.3\%}$$

While $78.3\%$ is a strong score, raw accuracy hides critical details: *Did the model perform equally well on Math, Biology, and Literature, or was it biased toward one subject?*
To answer this, we inspect **per-class precision and recall**.

### Precision: Quality of Predictions
$$\text{Precision} = \frac{\text{True Positives (Correctly Guessed Class)}}{\text{Total Times Model Guessed That Class}}$$
- Question answered: *"When the chatbot guesses Literature, how often is it actually right?"*
- From our run: Literature precision is **$86\%$** ($0.86$). When the chatbot says you love literature, you can trust it!

### Recall: Completeness of Identification
$$\text{Recall} = \frac{\text{True Positives (Correctly Guessed Class)}}{\text{Actual Total Number of Students in That Class}}$$
- Question answered: *"Out of all real Literature lovers, how many did the chatbot successfully find?"*
- From our run: Literature recall is **$75\%$** ($0.75$). The chatbot found 6 out of the 8 literature students, missing 2.

### F1-Score: The Harmonic Balance
$$\text{F1-Score} = 2 \times \frac{\text{Precision} \times \text{Recall}}{\text{Precision} + \text{Recall}}$$
The F1-score provides a single balanced metric that penalizes extreme imbalances between precision and recall.

## Theoretical & Real-World Context
In industry, the choice between optimizing precision or recall depends on the business consequences of errors:
- **Spam Filtering**: Optimize for **Precision**. You never want an important business email sent to the Spam folder (false positive).
- **Disease Screening**: Optimize for **Recall**. You cannot afford to miss a patient who has a dangerous illness (false negative).
- **Educational Chatbots**: Aim for balanced **F1-Scores** so no subject is systematically neglected or over-recommended.

## Relevant Code (from main.py)
In `main.py`, lines 74-81 compute and display these metrics:
```python
# Lines 74-81 of main.py
predictions = model.predict(X_test)
accuracy = accuracy_score(y_test, predictions)

print("=" * 60)
print("THE FAVORITE-SUBJECT CHATBOT")
print("=" * 60)
print(f"Accuracy: {accuracy:.1%}\n")
print(classification_report(y_test, predictions, zero_division=0))
```

## Code Explanation & Line-by-Line Breakdown
- **Line 74 (`model.predict(X_test)`)**: Evaluates all 23 test profiles against the decision tree rules.
- **Line 75 (`accuracy_score(...)`)**: Compares predictions against true `y_test`.
- **Line 80 (`f"Accuracy: {accuracy:.1%}"`)**: Formats floating-point $0.7826$ into the string `"78.3%"`.
- **Line 81 (`classification_report(...)`)**: Builds the formatted summary table.
- **`zero_division=0`**: Ensures that if a class receives zero predictions, scikit-learn returns $0.0$ precision instead of raising an ugly runtime warning.

## Worked Example
Let us analyze the exact classification report printed by `main.py`:
```
              precision    recall  f1-score   support

     Biology       0.67      0.67      0.67         6
  Literature       0.86      0.75      0.80         8
        Math       0.80      0.89      0.84         9

    accuracy                           0.78        23
   macro avg       0.77      0.77      0.77        23
weighted avg       0.79      0.78      0.78        23
```

Let's dissect each row:
1. **Support**: The actual number of test students in each class ($6$ Biology, $8$ Literature, $9$ Math = $23$ total).
2. **Biology**: Precision $0.67$, Recall $0.67$. The model correctly identified 4 out of 6 Biology students.
3. **Literature**: Precision $0.86$, Recall $0.75$. High precision means few false alarms.
4. **Math**: Precision $0.80$, Recall $0.89$. High recall ($89\%$) means the chatbot identified 8 out of 9 Math students!
5. **Macro Average**: Unweighted average of metrics across the 3 classes ($0.77$).
6. **Weighted Average**: Average weighted by class support ($0.78$).

## Step-by-Step Student Instructions
1. Run `python main.py` in your terminal.
2. Examine the printed classification report.
3. Calculate the harmonic mean F1-score for Math by hand:
   $$F_1 = 2 \times \frac{0.80 \times 0.89}{0.80 + 0.89} = 2 \times \frac{0.712}{1.69} \approx \mathbf{0.842}$$
4. Confirm that this matches the report's `0.84`.

## Expected Output or Observable Behaviour
You will see:
```
Accuracy: 78.3%
```
Followed by the clean ASCII table displayed above.

## Verification & Testing Methods
Verify the number of correct predictions programmatically:
```python
import numpy as np
correct_count = np.sum(predictions == y_test)
print(f"Correct: {correct_count} out of {len(y_test)}")
print(f"Calculated accuracy: {correct_count / len(y_test):.4f}")
```
Output:
```
Correct: 18 out of 23
Calculated accuracy: 0.7826
```

## Practical Exercises
- **Exercise 2.1**: Which subject achieved the highest recall in our test set? What does this mean in plain English?
- **Exercise 2.2**: Why is the harmonic mean (F1-score) used instead of the standard arithmetic average when combining precision and recall?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Correction |
|---|---|---|
| Confusing precision with recall | Mixing up the denominator | Precision divides by total *predictions* of that class; Recall divides by total *actual* samples of that class. |
| Forgetting `zero_division=0` | Scikit-learn issues warnings if a class has 0 predictions | Always include `zero_division=0` in `classification_report()` for robust production logging. |

## Best Practices and Security Considerations
- **Transparent Performance Reporting**: Never report accuracy alone in multiclass settings; always publish the complete per-class breakdown.
- **Fair Model Auditing**: Check whether any subject suffers from unacceptably low recall, which could indicate demographic bias in training questions.

## Summary & Key Takeaways
- Overall accuracy measures the proportion of total correct predictions ($18/23 \approx 78.3\%$).
- Precision measures predictive reliability; Recall measures completeness; F1-score harmonizes both.
- `classification_report()` provides a comprehensive per-class audit.
- In our project, Math achieved the highest recall ($89\%$) and Literature achieved the highest precision ($86\%$).

## Knowledge-check Questions and References
1. What was the exact test accuracy achieved by the model on the 23 test profiles?
2. Which class achieved the highest precision in the classification report?
3. What does the "support" column represent in a classification report?

**References:**
- Powers, D. M. (2020). *Evaluation: from precision, recall and F-measure to ROC, informedness, markedness and correlation.* arXiv preprint arXiv:2010.16061.
- Scikit-learn documentation: *Classification metrics.* https://scikit-learn.org/stable/modules/model_evaluation.html#classification-metrics
