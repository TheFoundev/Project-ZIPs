# Lesson 01: Model Fitting: Stratified Splitting and DecisionTreeClassifier Training

**Lesson ID:** lesson-01
**Module:** module-04
**Duration:** 20 minutes

## Purpose and Learning Objectives
This lesson guides you through the machine learning training pipeline in `main.py`, focusing on dataset partitioning and fitting the `DecisionTreeClassifier`.

By the end of this lesson, you will be able to:
- Explain why datasets must be split into independent training and testing sets.
- Understand the mechanics of `train_test_split(..., test_size=0.25, random_state=42, stratify=y)`.
- Execute `model.fit(X_train, y_train)` and describe the internal state changes that occur.
- Verify that the training set contains 67 instances and the testing set contains 23 instances.

## Prerequisites
- Completion of Modules 01, 02, and 03.
- Basic understanding of supervised learning (training vs. testing).

## Concept Explanation
### The Golden Rule of Machine Learning: Never Test on Training Data
If a teacher gives students the exact questions and answers to tomorrow's exam, students who memorize the exam will score $100\%$ without understanding the subject matter.
Similarly, if you evaluate a machine learning model on the exact same data it was trained on, you are testing **memorization**, not **generalization**.

To obtain an honest, unbiased assessment of how well our chatbot will guess the favorite subjects of future, unseen students, we must split our 90 historical profiles into:
1. **Training Set ($75\% = 67$ students)**: Given to the decision tree algorithm to learn question rules.
2. **Testing Set ($25\% = 23$ students)**: Locked in a vault during training; used exclusively to evaluate accuracy.

### Stratification in Action
Because 90 does not divide evenly by 4:
- $90 \times 0.25 = 22.5 \implies 23$ test samples.
- $90 - 23 = 67$ training samples.

Passing `stratify=y` instructs scikit-learn to sample from each subject class independently:
- **Math**: 35 total $\longrightarrow 26$ train ($74.3\%$), $9$ test ($25.7\%$).
- **Literature**: 29 total $\longrightarrow 21$ train ($72.4\%$), $8$ test ($27.6\%$).
- **Biology**: 26 total $\longrightarrow 20$ train ($76.9\%$), $6$ test ($23.1\%$).

Every class is represented with faithful proportionality in both partitions.

### What Happens During `model.fit()`?
When `model.fit(X_train, y_train)` is called:
1. Scikit-learn creates the root node containing all 67 training instances.
2. It calculates Gini impurity for all 6 features across all splits.
3. It creates left and right child nodes for the winning split (`likes_programming`).
4. It repeats this process recursively down each path until nodes are pure or the path reaches `depth = 4`.
5. It compiles the resulting tree graph into internal memory structures (`model.tree_`).

## Theoretical & Real-World Context
In large-scale AI applications, data splitting strategies are paramount. While beginner projects use simple train/test splits, production systems often use **k-fold cross-validation** or **temporal splits** (training on past months, testing on future months). In all cases, strict separation between training and evaluation partitions is required to guard against data snooping.

## Relevant Code (from main.py)
In `main.py`, lines 68-73 implement this exact training sequence:
```python
# Lines 68-73 of main.py
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

model = DecisionTreeClassifier(max_depth=4, random_state=42)
model.fit(X_train, y_train)
```

## Code Explanation & Line-by-Line Breakdown
- **Line 68 (`train_test_split(...)`)**: Unpacks four objects: feature training matrix, feature test matrix, target training series, and target test series.
- **`test_size=0.25`**: Designates $25\%$ of data for testing.
- **`random_state=42`**: Seeds the pseudorandom number generator for reproducibility.
- **`stratify=y`**: Enforces balanced class proportions across partitions.
- **Line 72 (`DecisionTreeClassifier(...)`)**: Configures the estimator with maximum depth 4.
- **Line 73 (`model.fit(...)`)**: Executes the CART training algorithm.

## Worked Example
Let us verify the exact shapes of our splits using Python:
```python
import pandas as pd
from sklearn.model_selection import train_test_split

df = pd.read_csv("data/subject_answers.csv")
X = df[["likes_numbers", "likes_living_things", "likes_stories", "enjoys_experiments", "enjoys_debate", "likes_programming"]]
y = df["subject"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)
print("X_train shape:", X_train.shape)
print("X_test shape :", X_test.shape)
print("y_train shape:", y_train.shape)
print("y_test shape :", y_test.shape)
```
Output:
```
X_train shape: (67, 6)
X_test shape : (23, 6)
y_train shape: (67,)
y_test shape : (23,)
```
The sample counts sum exactly to 90 ($67 + 23 = 90$).

## Step-by-Step Student Instructions
1. Open your terminal in the project directory.
2. Launch Python.
3. Import `train_test_split` and verify the test set distribution:
   ```python
   import pandas as pd
   from sklearn.model_selection import train_test_split
   df = pd.read_csv("data/subject_answers.csv")
   _, _, _, y_test = train_test_split(df.iloc[:, :6], df["subject"], test_size=0.25, random_state=42, stratify=df["subject"])
   print(y_test.value_counts())
   ```
4. Confirm: Math has 9, Literature has 8, and Biology has 6.

## Expected Output or Observable Behaviour
You will observe:
```
Math          9
Literature    8
Biology       6
Name: subject, dtype: int64
```
This confirms that the test set has balanced representation across all three target disciplines.

## Verification & Testing Methods
Verify that the model has been fitted by checking scikit-learn's trailing underscore attribute `model.classes_`:
```python
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(max_depth=4, random_state=42).fit(X_train, y_train)
print("Fitted class labels:", model.classes_)
```
Output:
```
Fitted class labels: ['Biology' 'Literature' 'Math']
```
(Notice that scikit-learn sorts class names alphabetically).

## Practical Exercises
- **Exercise 1.1**: What happens if you change `test_size=0.50`? How many samples go to train and test?
- **Exercise 1.2**: Explain why passing `X_test` to `model.fit()` would constitute a critical methodological flaw.

## Common Mistakes and Debugging
| Mistake | Why It Happens | Correction |
|---|---|---|
| Swapping the order of unpacked variables | Writing `X_train, y_train, X_test, y_test = train_test_split(...)` | `train_test_split` returns `X_train, X_test, y_train, y_test` in that strict order. Swapping them causes dimensional mismatch errors. |
| Fitting on the full dataset $X$ before testing | Confusing full deployment with validation | Never evaluate a model on data it was trained on. Always fit on `X_train` and test on `X_test`. |

## Best Practices and Security Considerations
- **Deterministic Random Seeds**: Always supply `random_state` so experimental results can be reproduced by peers and auditors.
- **Preventing Target Leakage**: Ensure target column $y$ is never accessible to the feature matrix $X$ during splitting.

## Summary & Key Takeaways
- Supervised models must be evaluated on unseen test data to assess true generalization.
- `train_test_split(..., test_size=0.25, stratify=y)` partitions our 90 students into 67 training and 23 testing instances.
- Stratification maintains consistent class ratios across splits.
- `model.fit(X_train, y_train)` constructs the decision tree rules in memory.

## Knowledge-check Questions and References
1. How many students are in the training set and testing set respectively?
2. Why does scikit-learn sort `model.classes_` alphabetically?
3. What is the consequence of evaluating a model on its training data?

**References:**
- Kohavi, R. (1995). *A study of cross-validation and bootstrap for accuracy estimation and model selection.* IJCAI, 14(2), 1137-1145.
- Scikit-learn documentation: *train_test_split.* https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html
