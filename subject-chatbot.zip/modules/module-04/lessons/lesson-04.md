# Lesson 04: Tracing Predictions: Step-by-Step Tree Traversal for Scripted Demo Students

**Lesson ID:** lesson-04
**Module:** module-04
**Duration:** 20 minutes

## Purpose and Learning Objectives
This lesson teaches you how to trace feature vectors through a trained decision tree manually, verifying exactly why the chatbot arrives at its predictions for the three scripted demo students.

By the end of this lesson, you will be able to:
- Trace any input feature vector through a decision tree step-by-step.
- Understand the exact conditional path leading to Student 1 (Math), Student 2 (Biology), and Student 3 (Literature).
- Validate algorithmic predictions against manual flowchart traversal.
- Debug why a particular combination of answers leads to an unexpected subject classification.

## Prerequisites
- Completion of Lessons 01, 02, and 03.
- Ability to read the tree rules in `outputs/rules.txt` or flowchart in `outputs/chatbot_tree.png`.

## Concept Explanation
### The Determinism of Tree Traversal
In a decision tree, inference is $100\%$ deterministic. Given an input vector $\mathbf{x}$, there is exactly **one unique path** from the root node to a leaf.
At every internal node:
- If $x_{\text{feature}} \le 0.50$ (User answered No), take the **Left Branch**.
- If $x_{\text{feature}} > 0.50$ (User answered Yes), take the **Right Branch**.

When a leaf node is reached, the class stored at that leaf is returned as the model's prediction.

### The Three Scripted Demo Students
In `main.py`, lines 85-91 define three distinct student personas:

```python
demo_profiles = pd.DataFrame(
    [
        {"likes_numbers": 1, "likes_living_things": 0, "likes_stories": 0, "enjoys_experiments": 1, "enjoys_debate": 0, "likes_programming": 1},
        {"likes_numbers": 0, "likes_living_things": 1, "likes_stories": 0, "enjoys_experiments": 1, "enjoys_debate": 0, "likes_programming": 0},
        {"likes_numbers": 0, "likes_living_things": 0, "likes_stories": 1, "enjoys_experiments": 0, "enjoys_debate": 1, "likes_programming": 0},
    ]
)
```

Let us trace each student through the learned tree structure.

## Theoretical & Real-World Context
In software quality assurance for machine learning, manual traversal of test cases is known as **model walking**. Model walking allows domain experts to sanity-check decision boundaries. If a student who says they love numbers and coding was classified as Literature, model walking would instantly pinpoint the exact erroneous split in the tree.

## Relevant Code (from main.py)
In `main.py`, lines 92-96 execute and display these predictions:
```python
# Lines 92-96 of main.py
demo_predictions = model.predict(demo_profiles)
print("Demo profiles:")
for index, prediction in enumerate(demo_predictions, start=1):
    print(f"  Student {index}: {prediction}")
```

## Code Explanation & Line-by-Line Breakdown
- **Line 92 (`demo_predictions = model.predict(demo_profiles)`)**: Feeds all 3 persona rows to the model. Scikit-learn traverses the tree for each row and returns a numpy array of string labels.
- **Line 94 (`enumerate(demo_predictions, start=1)`)**: Iterates with human-friendly 1-based indexing (`Student 1`, `Student 2`, `Student 3`).
- **Line 95**: Prints the resulting prediction for each student.

## Worked Example: Tracing All Three Students

### Tracing Student 1: The Quantitative Coder
- **Feature Vector**: `[numbers=1, bio=0, stories=0, experiments=1, debate=0, programming=1]`
- **Step 1 (Root Node)**: Check `likes_programming`. Value is $1$ ($> 0.50$).
  $\longrightarrow$ **Take Right Branch**.
- **Step 2 (Depth 1)**: Check `likes_numbers`. Value is $1$ ($> 0.50$).
  $\longrightarrow$ **Take Right Branch**.
- **Step 3 (Depth 2)**: Check `likes_living_things`. Value is $0$ ($\le 0.50$).
  $\longrightarrow$ **Take Left Branch**.
- **Step 4 (Depth 3)**: Reach terminal leaf node!
  $\longrightarrow$ **Leaf Class: `Math`**.
- **Result**: `Student 1: Math`. Verified!

---

### Tracing Student 2: The Natural Scientist
- **Feature Vector**: `[numbers=0, bio=1, stories=0, experiments=1, debate=0, programming=0]`
- **Step 1 (Root Node)**: Check `likes_programming`. Value is $0$ ($\le 0.50$).
  $\longrightarrow$ **Take Left Branch**.
- **Step 2 (Depth 1)**: Check `likes_stories`. Value is $0$ ($\le 0.50$).
  $\longrightarrow$ **Take Left Branch**.
- **Step 3 (Depth 2)**: Check `enjoys_experiments`. Value is $1$ ($> 0.50$).
  $\longrightarrow$ **Take Right Branch**.
- **Step 4 (Depth 3)**: Reach terminal leaf node!
  $\longrightarrow$ **Leaf Class: `Biology`**.
- **Result**: `Student 2: Biology`. Verified!

---

### Tracing Student 3: The Humanist
- **Feature Vector**: `[numbers=0, bio=0, stories=1, experiments=0, debate=1, programming=0]`
- **Step 1 (Root Node)**: Check `likes_programming`. Value is $0$ ($\le 0.50$).
  $\longrightarrow$ **Take Left Branch**.
- **Step 2 (Depth 1)**: Check `likes_stories`. Value is $1$ ($> 0.50$).
  $\longrightarrow$ **Take Right Branch**.
- **Step 3 (Depth 2)**: Check `likes_living_things`. Value is $0$ ($\le 0.50$).
  $\longrightarrow$ **Take Left Branch**.
- **Step 4 (Depth 3)**: Reach terminal leaf node!
  $\longrightarrow$ **Leaf Class: `Literature`**.
- **Result**: `Student 3: Literature`. Verified!

## Step-by-Step Student Instructions
1. Open `outputs/rules.txt` in your editor.
2. Place your finger at the top of the rules.
3. Follow the rules for Student 2:
   - `likes_programming <= 0.50`
   - `likes_stories <= 0.50`
   - `enjoys_experiments > 0.50`
4. Confirm that the rule terminates at `class: Biology`.
5. Run `python main.py` in your terminal and verify that the printed output matches your manual trace:
   ```
   Demo profiles:
     Student 1: Math
     Student 2: Biology
     Student 3: Literature
   ```

## Expected Output or Observable Behaviour
Console output:
```
Demo profiles:
  Student 1: Math
  Student 2: Biology
  Student 3: Literature
```
Every persona correctly resolves to its designated subject.

## Verification & Testing Methods
Verify with a direct programmatic assertion in Python:
```python
import pandas as pd
from sklearn.tree import DecisionTreeClassifier

# Replicate training
df = pd.read_csv("data/subject_answers.csv")
FEATURES = ["likes_numbers", "likes_living_things", "likes_stories", "enjoys_experiments", "enjoys_debate", "likes_programming"]
model = DecisionTreeClassifier(max_depth=4, random_state=42).fit(df[FEATURES], df["subject"])

# Test Student 1
s1 = pd.DataFrame([{"likes_numbers": 1, "likes_living_things": 0, "likes_stories": 0, "enjoys_experiments": 1, "enjoys_debate": 0, "likes_programming": 1}])
assert model.predict(s1)[0] == "Math"
print("Manual tracing perfectly validated by automated assertion.")
```

## Practical Exercises
- **Exercise 4.1**: Create a new student persona who likes programming ($1$) and likes stories ($1$), but dislikes numbers ($0$). Manually trace this student through `outputs/rules.txt` and determine which subject the chatbot predicts.
- **Exercise 4.2**: Can two students with completely different answer profiles end up at the exact same leaf node? Explain why or why not.

## Common Mistakes and Debugging
| Mistake | Why It Happens | Correction |
|---|---|---|
| Taking the right branch for `<= 0.50` | Habit of reading left-to-right or associating right with positive | In scikit-learn, the **Left branch is ALWAYS True for the inequality** (`<= 0.50`), meaning left is No ($0$) and right is Yes ($1$). |
| Evaluating features not tested along the active path | Wondering why `enjoys_debate` wasn't checked for Student 1 | Decision trees only evaluate features on the active branch; irrelevant features are completely ignored. |

## Best Practices and Security Considerations
- **Transparent Logic Verification**: Step-by-step tracing allows developers to guarantee that no hidden biases or unintended logical shortcuts exist along key decision pathways.
- **Edge-Case Persona Testing**: Always test personas with conflicting or ambiguous affinities before releasing educational bots to students.

## Summary & Key Takeaways
- Manual decision tree traversal is deterministic and 100% reproducible.
- At each node: $\le 0.50$ branches left ("No"); $> 0.50$ branches right ("Yes").
- Student 1 resolves to Math; Student 2 resolves to Biology; Student 3 resolves to Literature.
- Decision trees efficiently bypass unneeded questions once a conclusive branch is identified.

## Knowledge-check Questions and References
1. Why does Student 2 bypass the `likes_numbers` question entirely?
2. Which direction (left or right) does a student traverse when answering "No" ($0$) to an inequality test?
3. What is the predicted subject for a student who likes programming, dislikes numbers, and likes stories?

**References:**
- Russell, S., & Norvig, P. *Artificial Intelligence: A Modern Approach (4th ed.).* Chapter 19: Learning from Examples.
- Scikit-learn documentation: *Understanding the decision tree structure.* https://scikit-learn.org/stable/auto_examples/tree/plot_unveil_tree_structure.html
