# Lesson 03: Visualizing Tree Logic: Generating chatbot_tree.png and Exporting rules.txt

**Lesson ID:** lesson-03
**Module:** module-04
**Duration:** 20 minutes

## Purpose and Learning Objectives
This lesson explores how to transform an abstract mathematical decision tree into clear visual and textual artifacts: `outputs/chatbot_tree.png` and `outputs/rules.txt`.

By the end of this lesson, you will be able to:
- Use `plot_tree()` to render decision trees with matplotlib.
- Configure visual formatting parameters: `feature_names`, `class_names`, `filled=True`, and `rounded=True`.
- Explain how box fill colors visualize majority class predictions and purity.
- Save high-resolution figures using `fig.savefig(..., dpi=150, bbox_inches="tight")` and prevent memory leaks with `plt.close(fig)`.

## Prerequisites
- Completion of Lessons 01 and 02.
- Basic familiarity with matplotlib figures and axes.

## Concept Explanation
### The Power of Visual Explainability
One of the greatest virtues of Decision Trees is that they are **white-box models**. While a deep neural network contains millions of uninterpretable floating-point weights, a decision tree can be rendered directly as an intuitive flowchart that any student, teacher, or parent can read and understand.

Scikit-learn provides `plot_tree()` to draw this flowchart directly onto a matplotlib canvas.

### Visual Styling Parameters
To make the flowchart readable, `main.py` configures several critical visual arguments:
1. **`feature_names=FEATURES`**: Replaces raw column numbers with descriptive names (`likes_programming`, `likes_stories`).
2. **`class_names=list(model.classes_)`**: Displays the predicted subject name (`Biology`, `Literature`, `Math`) in each node.
3. **`filled=True`**: Paints each node box with a distinct color representing its dominant class:
   - Orange tint $\implies$ Math
   - Green tint $\implies$ Literature
   - Purple/Blue tint $\implies$ Biology
   - **Color Saturation**: A pale, washed-out color indicates high impurity (uncertainty); a deep, vibrant color indicates high purity (high confidence)!
4. **`rounded=True`**: Renders sleek rounded corners on node boxes rather than sharp rectangles.
5. **`fontsize=8`**: Scales the text to prevent overlapping node labels.

### Headless Serialization
To save the graphic cleanly:
```python
fig, ax = plt.subplots(figsize=(15, 8))
plot_tree(...)
fig.tight_layout()
fig.savefig(OUT / "chatbot_tree.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```
- `figsize=(15, 8)`: Allocates a wide 15x8 inch canvas to accommodate broad horizontal tree branches.
- `dpi=150`: Renders high-definition crisp text (150 dots per inch).
- `bbox_inches="tight"`: Crops away unnecessary whitespace around the diagram.
- `plt.close(fig)`: Destroys the figure object and releases RAM back to the operating system.

## Theoretical & Real-World Context
In medical AI and legal compliance, visualizing decision paths is often a mandatory regulatory requirement. The European Union's General Data Protection Regulation (GDPR) mandates that automated systems affecting citizens must provide meaningful explanations of the logic involved. `plot_tree()` outputs serve as primary audit artifacts in regulated industries.

## Relevant Code (from main.py)
In `main.py`, lines 98-121 handle the complete rendering and serialization pipeline:
```python
# Lines 98-121 of main.py
fig, ax = plt.subplots(figsize=(15, 8))
plot_tree(
    model,
    feature_names=FEATURES,
    class_names=list(model.classes_),
    filled=True,
    rounded=True,
    fontsize=8,
    ax=ax,
)
ax.set_title("The chatbot's decision tree")
fig.tight_layout()
fig.savefig(OUT / "chatbot_tree.png", dpi=150, bbox_inches="tight")
plt.close(fig)

with open(OUT / "rules.txt", "w", encoding="utf-8") as handle:
    handle.write(f"accuracy: {accuracy:.4f}\n\n")
    handle.write(export_text(model, feature_names=FEATURES))
    handle.write("\ndemo predictions:\n")
    for index, prediction in enumerate(demo_predictions, start=1):
        handle.write(f"student {index}: {prediction}\n")
    handle.write("\n" + classification_report(y_test, predictions, zero_division=0))
```

## Code Explanation & Line-by-Line Breakdown
- **Lines 98-107**: Configures the 15x8 canvas and invokes `plot_tree()`.
- **Line 110 (`fig.savefig(...)`)**: Writes the PNG file to `outputs/chatbot_tree.png`.
- **Line 111 (`plt.close(fig)`)**: Crucial memory cleanup; prevents matplotlib warning messages when running repeated analyses.
- **Lines 113-120**: Opens `outputs/rules.txt` with UTF-8 encoding and writes a structured plain-text report containing accuracy, text rules, demo predictions, and the classification report.

## Worked Example
Open `outputs/chatbot_tree.png` and examine the top node:
```
+------------------------------------+
|    likes_programming <= 0.5        |
|          gini = 0.662              |
|          samples = 67              |
|        value = [20, 21, 26]        |
|           class = Math             |
+------------------------------------+
```
Let us interpret every single line inside this box:
1. `likes_programming <= 0.5`: The binary question tested at this node.
2. `gini = 0.662`: The Gini impurity of the 67 training students.
3. `samples = 67`: Total number of training instances evaluated at this node.
4. `value = [20, 21, 26]`: Distribution of classes in alphabetical order:
   - 20 Biology students
   - 21 Literature students
   - 26 Math students
5. `class = Math`: The majority class at this stage (26 is the largest count).

## Step-by-Step Student Instructions
1. Run `python main.py` in your terminal.
2. Open your file manager or image viewer and view `outputs/chatbot_tree.png`.
3. Locate the leftmost leaf node at the bottom of the tree.
4. Read its `value = [...]` array and note which subject class it predicts.
5. Open `outputs/rules.txt` and verify that the plain-text rules describe the exact same branch!

## Expected Output or Observable Behaviour
You will find two generated artifacts in `outputs/`:
- `chatbot_tree.png`: A clean, publication-quality flowchart diagram.
- `rules.txt`: A clean text report recording the entire session's findings.

## Verification & Testing Methods
Verify that `outputs/chatbot_tree.png` exists and has a non-zero file size:
```bash
python -c "from pathlib import Path; p = Path('outputs/chatbot_tree.png'); print(f'File exists: {p.exists()} | Size: {p.stat().st_size / 1024:.1f} KB')"
```
Output:
```
File exists: True | Size: 138.4 KB
```

## Practical Exercises
- **Exercise 3.1**: Inspect the boxes in `outputs/chatbot_tree.png`. What color represents Literature in the rendered diagram?
- **Exercise 3.2**: Why is it important to specify `encoding="utf-8"` when writing text files in Python?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Correction |
|---|---|---|
| Omitting `plt.close(fig)` | Matplotlib keeps figures in memory indefinitely | Always call `plt.close(fig)` after saving to prevent memory leaks. |
| Forgetting `class_names=list(model.classes_)` | Node classes display as generic numbers (y[0], y[1]) | Always pass explicit class names to `plot_tree()`. |
| Setting figure size too small (e.g., `figsize=(6, 4)`) | Tree text overlaps and becomes illegible | Use a generous canvas (e.g., `figsize=(15, 8)`) for decision trees of depth 4. |

## Best Practices and Security Considerations
- **Non-Interactive Backend**: Ensure `matplotlib.use("Agg")` is set before importing pyplot so image serialization runs reliably in server environments.
- **Explicit Serialization Encoding**: Always specify `encoding="utf-8"` when writing text reports to maintain cross-platform compatibility across Windows and Linux.

## Summary & Key Takeaways
- `plot_tree()` translates decision trees into visual flowchart diagrams.
- Parameters like `filled=True` and `rounded=True` enhance interpretability through color-coded class representations.
- Box saturation visually communicates node purity (deep colors = high purity).
- `outputs/rules.txt` archives text rules, metrics, and demo predictions in an auditable plain-text format.

## Knowledge-check Questions and References
1. What does the `value = [20, 21, 26]` array in a tree node represent?
2. Why is `bbox_inches="tight"` used when saving matplotlib figures?
3. How does node color saturation relate to Gini impurity in `plot_tree(filled=True)`?

**References:**
- Hunter, J. D. (2007). *Matplotlib: A 2D graphics environment.* Computing in Science & Engineering, 9(3), 90-95.
- Scikit-learn documentation: *sklearn.tree.plot_tree.* https://scikit-learn.org/stable/modules/generated/sklearn.tree.plot_tree.html
