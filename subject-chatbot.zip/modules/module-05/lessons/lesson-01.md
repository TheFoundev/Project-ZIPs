# Lesson 01: CLI Arguments: Detecting and Handling the --interactive Flag via sys.argv

**Lesson ID:** lesson-01
**Module:** module-05
**Duration:** 20 minutes

## Purpose and Learning Objectives
This lesson explores command-line interface (CLI) engineering in Python, focusing on how `sys.argv` allows a single script to dynamically switch between automated batch execution and live interactive Q&A.

By the end of this lesson, you will be able to:
- Explain what `sys.argv` is and how Python captures terminal arguments.
- Understand the membership test `"--interactive" in sys.argv`.
- Compare lightweight `sys.argv` inspection with heavyweight CLI parsers (like `argparse` and `click`).
- Design clean user-facing help messages that guide users on how to enable interactive features.

## Prerequisites
- Completion of Modules 01 through 04.
- Familiarity with running scripts from the terminal with flags.

## Concept Explanation
### What is `sys.argv`?
When you launch a Python script from your terminal:
```bash
python main.py --interactive
```
The operating system shell splits the command into individual string tokens and hands them to the Python runtime. The standard library module `sys` exposes these tokens as a simple Python list of strings named `sys.argv` (short for "argument vector").

In the command above:
- `sys.argv[0]`: `"main.py"` (the name of the script being executed).
- `sys.argv[1]`: `"--interactive"` (the first argument passed by the user).

If the user simply runs:
```bash
python main.py
```
Then `sys.argv` contains only a single element: `["main.py"]`.

### Detecting Feature Flags
To toggle features based on user intent, we can use Python's membership operator `in`:
```python
if "--interactive" in sys.argv:
    # Launch conversational Q&A
else:
    # Run default demo & print instructions
```
Why is `"--interactive" in sys.argv` superior to checking `sys.argv[1] == "--interactive"`?
1. **Index Safety**: If the user provides no arguments, `sys.argv` has length 1. Accessing `sys.argv[1]` raises an `IndexError: list index out of range`!
2. **Positional Flexibility**: Using `in` allows the user to pass the flag anywhere (e.g., `python main.py --verbose --interactive`).

### Lightweight vs. Full Argument Parsers
Python offers robust CLI parsing libraries such as `argparse`, `click`, and `typer`. While those tools are indispensable for complex utilities with dozens of subcommands and typed flags, `sys.argv` is the cleanest, zero-dependency solution for binary toggles.

## Theoretical & Real-World Context
In production microservices and CLI developer tools (such as `git`, `docker`, and `kubectl`), command-line flags control execution modes (e.g., `docker run -it` for interactive terminal vs. `docker run -d` for detached background daemon). Providing interactive CLI flags allows developers to manually debug an algorithm while preserving non-interactive defaults for automated cron jobs and server scripts.

## Relevant Code (from main.py)
In `main.py`, lines 13 and 123-133 demonstrate this logic:
```python
# Line 13 of main.py
import sys

# Lines 123-133 of main.py
if "--interactive" in sys.argv:
    print("\nAnswer six questions and the chatbot will guess your subject.\n")
    profile = ask_profile()
    prediction = model.predict(profile)[0]
    probabilities = model.predict_proba(profile)[0]
    confidence = probabilities.max()
    print(f"\nThe chatbot guesses: {prediction} ({confidence:.0%} confident)")
else:
    print("Run `python main.py --interactive` to chat with it yourself.")
    print("Try this: add a new subject and 20 example profiles.")
```

## Code Explanation & Line-by-Line Breakdown
- **Line 13 (`import sys`)**: Imports the standard system module.
- **Line 123 (`if "--interactive" in sys.argv:`)**: Evaluates whether the string `"--interactive"` exists anywhere in the argument vector.
- **Lines 124-129**: Executes interactive Q&A only if the flag was supplied.
- **Lines 130-132**: If the flag was omitted, prints helpful hints instructing the user on how to run interactive mode.

## Worked Example
Let us write a small test script to inspect `sys.argv` directly:
```python
# test_args.py
import sys

print("Argument list:", sys.argv)
print("Interactive enabled?", "--interactive" in sys.argv)
```

Now run it with different terminal invocations:
```bash
$ python test_args.py
Argument list: ['test_args.py']
Interactive enabled? False

$ python test_args.py --interactive
Argument list: ['test_args.py', '--interactive']
Interactive enabled? True

$ python test_args.py --debug --interactive --fast
Argument list: ['test_args.py', '--debug', '--interactive', '--fast']
Interactive enabled? True
```
Notice how safely and reliably the membership check works regardless of flag count or position.

## Step-by-Step Student Instructions
1. Open your terminal in `17_subject_chatbot`.
2. Run `python main.py`. Note that the script finishes without asking you any questions.
3. Observe the final line printed:
   ```
   Run `python main.py --interactive` to chat with it yourself.
   ```
4. Now run `python main.py --interactive`.
5. Notice that the script immediately displays:
   ```
   Answer six questions and the chatbot will guess your subject.

   Do you enjoy working with numbers? (y/n):
   ```
6. Press `Ctrl+C` to cancel for now.

## Expected Output or Observable Behaviour
When executed with `--interactive`, the program transitions from batch evaluation to interactive dialogue.

## Verification & Testing Methods
Verify argument detection behavior with Python inline:
```bash
python -c "import sys; print('Interactive mode active!' if '--interactive' in sys.argv else 'Batch mode active!')" --interactive
```
Output:
```
Interactive mode active!
```

## Practical Exercises
- **Exercise 1.1**: What happens if a user types `python main.py -i` instead of `--interactive`? How could you modify line 123 of `main.py` to support both `--interactive` and `-i`?
- **Exercise 1.2**: Write a short Python condition that checks if either `"-h"` or `"--help"` is passed, and prints a custom help message.

## Common Mistakes and Debugging
| Mistake | Why It Happens | Correction |
|---|---|---|
| Checking `sys.argv[1] == "--interactive"` directly | Crashes with `IndexError` when no arguments are provided | Always use `if "--interactive" in sys.argv:` to guarantee index safety. |
| Expecting boolean types in `sys.argv` | `sys.argv` contains raw strings only | Never check `if sys.argv[1] == True`; check string equality `if "--interactive" in sys.argv`. |

## Best Practices and Security Considerations
- **Non-Breaking Defaults**: Always ensure scripts run successfully without requiring command-line flags. Interactive input should be opt-in.
- **Helpful Guidance**: When interactive mode is available but not triggered, print friendly console hints to inform users of the feature.

## Summary & Key Takeaways
- `sys.argv` captures terminal command-line tokens as a list of strings.
- Using `"--interactive" in sys.argv` is an index-safe pattern for toggling interactive features.
- Default execution remains non-blocking for automated testing, while `--interactive` unlocks live conversational Q&A.

## Knowledge-check Questions and References
1. What is stored at index 0 of `sys.argv`?
2. What error occurs if you access `sys.argv[1]` when no command-line flags were passed?
3. How can you update the check to support both `-i` and `--interactive`?

**References:**
- Python standard library documentation: *sys.argv.* https://docs.python.org/3/library/sys.html#sys.argv
- Lutz, M. (2013). *Learning Python (5th ed.).* Chapter 24: Module Packages and System Integration.
