# Lesson 04: Confidence Scores: Interpreting model.predict_proba() and Probability Calibration

**Lesson ID:** lesson-04
**Module:** module-05
**Duration:** 20 minutes

## Purpose and Learning Objectives
This lesson explores probabilistic inference in classification models, explaining how `model.predict_proba()` calculates class confidence percentages and how this enhances the chatbot's conversational personality.

By the end of this lesson, you will be able to:
- Explain how decision tree leaf nodes estimate posterior class probabilities.
- Use `model.predict_proba()` to extract probability distributions across all target classes.
- Extract the winning confidence score using `.max()`.
- Format confidence scores as percentages in conversational output (e.g., `"(100% confident)"`).

## Prerequisites
- Completion of Lessons 01, 02, and 03.
- Basic understanding of fractions and percentages.

## Concept Explanation
### Beyond Hard Labels: How Sure is the Chatbot?
When a chatbot makes a recommendation, saying:
*"The chatbot guesses: Math"*
leaves the user wondering: *Is the chatbot $100\%$ certain, or was it a $51/49$ coin flip?*

In machine learning, models provide not just a **hard prediction** (`model.predict()`), but also a **probability distribution** across all possible classes (`model.predict_proba()`).

### How Decision Trees Compute Probabilities
In a decision tree, every leaf node contains a subset of training samples that landed in that leaf.
Look at the leaf node in `outputs/chatbot_tree.png`:
```
value = [0, 1, 7]  (0 Biology, 1 Literature, 7 Math)
total samples = 8
```
When an unseen user profile traverses into this leaf node, the tree calculates the probability for each class by taking the proportion of training samples in that leaf:
- $P(\text{Biology}) = \frac{0}{8} = 0.0 \implies 0\%$
- $P(\text{Literature}) = \frac{1}{8} = 0.125 \implies 12.5\%$
- $P(\text{Math}) = \frac{7}{8} = 0.875 \implies 87.5\%$

The class with the highest probability is Math ($87.5\%$). The model predicts **Math**, and its **confidence** is **$88\%$**!

If a user lands in a perfectly pure leaf where `value = [0, 0, 12]`:
- $P(\text{Math}) = \frac{12}{12} = 1.0 \implies \mathbf{100\%\text{ confident}}$.

### Extracting the Maximum Probability
`model.predict_proba(profile)` returns a 2D numpy array of shape `(1, 3)`:
```python
probabilities = model.predict_proba(profile)[0]
# probabilities might be: array([0.0, 0.0, 1.0])
confidence = probabilities.max()
# confidence is: 1.0
```
Formatting this in Python with `{confidence:.0%}` formats `1.0` as `"100%"`.

## Theoretical & Real-World Context
In high-stakes decision systems (such as medical diagnosis or credit lending), prediction probabilities are critical:
- If a diagnostic bot has $99\%$ confidence, it can take automated action.
- If a diagnostic bot has only $38\%$ confidence (borderline decision), it can say: *"I am not sure. Let me connect you with a human specialist."*

Calibrated probabilities allow conversational systems to know when they are uncertain.

## Relevant Code (from main.py)
In `main.py`, lines 126-129 extract and format these probabilities:
```python
# Lines 126-129 of main.py
prediction = model.predict(profile)[0]
probabilities = model.predict_proba(profile)[0]
confidence = probabilities.max()
print(f"\nThe chatbot guesses: {prediction} ({confidence:.0%} confident)")
```

## Code Explanation & Line-by-Line Breakdown
- **Line 126 (`model.predict(profile)[0]`)**: Predicts the winning class label (`"Math"`).
- **Line 127 (`probabilities = model.predict_proba(profile)[0]`)**: Extracts the 1D probability array corresponding to `model.classes_` (`['Biology', 'Literature', 'Math']`).
- **Line 128 (`confidence = probabilities.max()`)**: Extracts the highest probability value from the array.
- **Line 129**: Prints the prediction and confidence formatted with zero decimal places (`{confidence:.0%}`).

## Worked Example
Let us test `predict_proba()` on our three scripted demo student profiles:
```python
import pandas as pd
from sklearn.tree import DecisionTreeClassifier

df = pd.read_csv("data/subject_answers.csv")
FEATURES = ["likes_numbers", "likes_living_things", "likes_stories", "enjoys_experiments", "enjoys_debate", "likes_programming"]
model = DecisionTreeClassifier(max_depth=4, random_state=42).fit(df[FEATURES], df["subject"])

demo_profiles = pd.DataFrame([
    {"likes_numbers": 1, "likes_living_things": 0, "likes_stories": 0, "enjoys_experiments": 1, "enjoys_debate": 0, "likes_programming": 1},
    {"likes_numbers": 0, "likes_living_things": 1, "likes_stories": 0, "enjoys_experiments": 1, "enjoys_debate": 0, "likes_programming": 0},
    {"likes_numbers": 0, "likes_living_things": 0, "likes_stories": 1, "enjoys_experiments": 0, "enjoys_debate": 1, "likes_programming": 0},
])

for i, row in demo_profiles.iterrows():
    sample = pd.DataFrame([row])
    pred = model.predict(sample)[0]
    probs = model.predict_proba(sample)[0]
    conf = probs.max()
    print(f"Student {i+1}: {pred:10s} | Probs: {probs.round(2)} | Confidence: {conf:.0%}")
```
Output:
```
Student 1: Math       | Probs: [0. 0. 1.] | Confidence: 100%
Student 2: Biology    | Probs: [1. 0. 0.] | Confidence: 100%
Student 3: Literature | Probs: [0. 1. 0.] | Confidence: 100%
```
All three demo profiles land in completely pure leaf nodes, yielding $100\%$ confidence!

## Step-by-Step Student Instructions
1. Run `python main.py --interactive` in your terminal.
2. Answer the questions to describe an ambiguous profile:
   - Numbers: Yes
   - Living things: Yes
   - Stories: Yes
   - Experiments: Yes
   - Debate: Yes
   - Programming: Yes
3. Observe the chatbot's guess and reported confidence percentage.
4. Try answering No to all questions and observe the confidence.

## Expected Output or Observable Behaviour
When running interactively, the terminal prints:
```
The chatbot guesses: Math (100% confident)
```
Or for ambiguous profiles, confidence might be $67\%$ or $75\%$.

## Verification & Testing Methods
Verify that probabilities always sum to 1.0:
```python
probs = model.predict_proba(sample)[0]
assert abs(sum(probs) - 1.0) < 1e-6, "Probabilities must sum to 1.0!"
print("Probability conservation law verified.")
```

## Practical Exercises
- **Exercise 4.1**: Find an answer profile that produces less than 100% confidence. What are the probabilities for each class?
- **Exercise 4.2**: Why should a chatbot report confidence to a user rather than just a raw prediction?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Correction |
|---|---|---|
| Assuming `predict_proba()` returns probabilities in arbitrary order | Scikit-learn always sorts classes alphabetically | Probabilities correspond strictly to `model.classes_` (Index 0 = Biology, Index 1 = Literature, Index 2 = Math). |
| Forgetting `[0]` on `predict_proba()` | `predict_proba()` returns a 2D array | Index `[0]` to access the 1D probability distribution of a single sample. |

## Best Practices and Security Considerations
- **Confidence Thresholding**: Set an alert or fallback prompt when prediction confidence drops below $50\%$.
- **Transparent Communication**: Explicitly showing confidence prevents users from over-trusting borderline AI predictions.

## Summary & Key Takeaways
- `model.predict_proba()` returns class probability distributions computed from leaf sample ratios.
- The maximum probability (`probabilities.max()`) represents model confidence.
- `{confidence:.0%}` formats decimal probabilities as readable percentages.
- Communicating confidence enhances chatbot trust and transparent conversational UX.

## Knowledge-check Questions and References
1. How does a decision tree leaf calculate class probabilities?
2. In what order are the probabilities returned by `predict_proba()`?
3. What is the confidence score of a leaf containing `value = [0, 0, 10]`?

**References:**
- Niculescu-Mizil, A., & Caruana, R. (2005). *Predicting good probabilities with supervised learning.* ICML, 625-632.
- Scikit-learn documentation: *Probability calibration.* https://scikit-learn.org/stable/modules/calibration.html
