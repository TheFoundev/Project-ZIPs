# Lesson 02: Input Sanitization: Implementing the ask_profile() Validation Loop

**Lesson ID:** lesson-02
**Module:** module-05
**Duration:** 20 minutes

## Purpose and Learning Objectives
This lesson analyzes user input sanitization and defensive programming in conversational CLI systems, focusing on the `ask_profile()` function.

By the end of this lesson, you will be able to:
- Explain why user input must be sanitized and validated before entering machine learning pipelines.
- Implement an infinite `while True` loop with `break` conditions to reject invalid responses.
- Use `.strip()` and `.lower()` to normalize human keyboard input.
- Map diverse affirmative and negative user responses (`"y"`, `"yes"`, `"1"`, `"n"`, `"no"`, `"0"`) to clean binary integers.

## Prerequisites
- Completion of Lesson 01.
- Basic familiarity with Python `while` loops and string methods.

## Concept Explanation
### The Unpredictability of Human Input
When an application prompts a human user with:
`"Do you enjoy working with numbers? (y/n): "`
Human users will type unpredictable responses:
- `"Y"` (uppercase)
- `"  yes  "` (leading/trailing whitespace)
- `"1"` (numeric boolean)
- `"No"` (capitalized)
- `"maybe"` (ambiguous)
- `""` (hitting enter accidentally)
- `"asdfghjkl"` (keyboard smash)

If an application feeds unvalidated text like `"maybe"` directly into `model.predict()`, `scikit-learn` will crash with a fatal `ValueError: could not convert string to float`.

### Defensive Input Sanitization
To build a resilient chatbot, we must implement **defensive input validation**:
1. **Normalize**: Remove extraneous spaces with `.strip()` and convert all characters to lowercase with `.lower()`.
2. **Whitelist**: Compare the cleaned string against an explicit whitelist of acceptable affirmative and negative tokens.
3. **Loop Until Valid**: If the response is valid, record the binary encoding ($1$ or $0$) and `break` out of the loop. If invalid, inform the user and reprompt without crashing!

```
                   +---------------------------+
                   |  Display Question (y/n)   |
                   +---------------------------+
                                 |
                                 v
                   +---------------------------+
                   |  Collect input() String   |
                   +---------------------------+
                                 |
                                 v
                   +---------------------------+
                   | answer.strip().lower()    |
                   +---------------------------+
                                 |
                     +-----------+-----------+
                     |                       |
            In ('y', 'yes', '1')?   In ('n', 'no', '0')?
                     |                       |
               YES   v                 YES   v
            Append 1 & BREAK        Append 0 & BREAK
                     |                       |
                     +-----------+-----------+
                                 |
                                 v NO TO BOTH
                   +---------------------------+
                   | "Please type y or n."     |
                   | (Loop continues...)       |
                   +---------------------------+
```

## Theoretical & Real-World Context
In cybersecurity and software reliability, **input validation** is the first line of defense. Accepting raw user input without strict type and range constraints is a primary cause of injection attacks, memory corruption, and application crashes. In conversational AI, input normalization ensures that minor variations in user typing do not corrupt the mathematical feature vector.

## Relevant Code (from main.py)
In `main.py`, lines 48-60 implement this exact loop:
```python
# Lines 48-60 of main.py
def ask_profile() -> pd.DataFrame:
    answers = []
    for question in QUESTIONS:
        while True:
            answer = input(f"{question} (y/n): ").strip().lower()
            if answer in ("y", "yes", "1"):
                answers.append(1)
                break
            if answer in ("n", "no", "0"):
                answers.append(0)
                break
            print("Please type y or n.")
    return pd.DataFrame([dict(zip(FEATURES, answers))])
```

## Code Explanation & Line-by-Line Breakdown
- **Line 48 (`def ask_profile() -> pd.DataFrame:`)**: Function signature declaring that the interactive dialogue returns a formatted pandas DataFrame.
- **Line 49 (`answers = []`)**: Initializes an empty list to collect the 6 binary responses.
- **Line 50 (`for question in QUESTIONS:`)**: Iterates sequentially through all 6 survey questions.
- **Line 51 (`while True:`)**: Establishes an infinite loop that will not exit until the user provides a valid answer.
- **Line 52 (`input(...).strip().lower()`)**: Prompts the user, strips whitespace, and converts to lowercase in a single chained expression.
- **Lines 53-55**: If affirmative (`"y"`, `"yes"`, `"1"`), appends `1` and breaks the inner `while` loop.
- **Lines 56-58**: If negative (`"n"`, `"no"`, `"0"`), appends `0` and breaks the inner `while` loop.
- **Line 59 (`print("Please type y or n.")`)**: Executed only if neither condition matched. Informs the user and restarts the `while` loop.

## Worked Example
Let us trace what happens when an indecisive user responds to question 1:
```
Do you enjoy working with numbers? (y/n): maybe
Please type y or n.
Do you enjoy working with numbers? (y/n):   YES  
```
1. Turn 1: `"maybe"`. Neither `if` condition matches. Python prints `"Please type y or n."`. Loop repeats.
2. Turn 2: `"  YES  "`. `.strip()` turns it into `"YES"`. `.lower()` turns it into `"yes"`.
3. `"yes"` matches `("y", "yes", "1")`!
4. `answers.append(1)` executes. `break` terminates the loop.
5. The chatbot advances smoothly to question 2.

## Step-by-Step Student Instructions
1. In your terminal, run `python main.py --interactive`.
2. When asked the first question, type `hello` and press Enter.
3. Verify that the terminal reprompts with `"Please type y or n."`.
4. Type `   Y   ` with lots of spaces and press Enter.
5. Notice that it accepts your answer and moves to question 2!
6. Finish answering all 6 questions to receive your prediction.

## Expected Output or Observable Behaviour
```
Do you enjoy working with numbers? (y/n): foo
Please type y or n.
Do you enjoy working with numbers? (y/n): y
Do you like learning about living things? (y/n): n
...
The chatbot guesses: Math (100% confident)
```
The program never crashes, regardless of invalid keyboard inputs.

## Verification & Testing Methods
Test string sanitization logic using Python interactive shell:
```python
raw_inputs = ["  YES ", "Y", "1", "NO", "  0  ", "invalid"]
for raw in raw_inputs:
    clean = raw.strip().lower()
    if clean in ("y", "yes", "1"):
        val = 1
    elif clean in ("n", "no", "0"):
        val = 0
    else:
        val = "REJECTED"
    print(f"Raw: {raw!r:12s} -> Clean: {clean!r:10s} -> Value: {val}")
```
Output:
```
Raw: '  YES '     -> Clean: 'yes'      -> Value: 1
Raw: 'Y'          -> Clean: 'y'        -> Value: 1
Raw: '1'          -> Clean: '1'        -> Value: 1
Raw: 'NO'         -> Clean: 'no'       -> Value: 0
Raw: '  0  '      -> Clean: '0'        -> Value: 0
Raw: 'invalid'    -> Clean: 'invalid'  -> Value: REJECTED
```

## Practical Exercises
- **Exercise 2.1**: How would you expand the affirmative tuple to support Spanish responses like `"si"`?
- **Exercise 2.2**: What would happen if line 51 had `while False:` instead of `while True:`?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Correction |
|---|---|---|
| Forgetting `break` inside the validation block | The loop appends 1 and keeps asking the same question forever | Always call `break` immediately after appending a valid answer. |
| Forgetting `.strip()` | User typing `" y "` is rejected as invalid | Always chain `.strip().lower()` on raw input strings. |
| Checking `if answer == "y" or "yes":` | Python evaluates `"yes"` as truthy, so the condition is always True! | Use tuple membership: `if answer in ("y", "yes", "1"):`. |

## Best Practices and Security Considerations
- **Defensive Type Coercion**: Never pass raw terminal strings directly to machine learning estimators. Always map them to verified numeric types.
- **Graceful Error Recovery**: Always provide clear feedback explaining what input is expected when a user enters invalid data.

## Summary & Key Takeaways
- `ask_profile()` safeguards the ML model from invalid user input.
- `.strip().lower()` normalizes whitespace and casing.
- An infinite `while True` loop reprompts until a valid answer is provided.
- Affirmative inputs map to `1`; negative inputs map to `0`.

## Knowledge-check Questions and References
1. What does `.strip()` do to a string in Python?
2. Why is `if answer in ("y", "yes", "1"):` correct while `if answer == "y" or "yes":` is a serious bug?
3. What causes the `while True` loop to terminate when a valid response is entered?

**References:**
- Python documentation: *Common String Operations.* https://docs.python.org/3/library/stdtypes.html#string-methods
- van Rossum, G. *The Python Tutorial: Errors and Exceptions.* Python Software Foundation.
