# Lesson 03: Real-Time Inference: Packaging User Responses into a Feature DataFrame

**Lesson ID:** lesson-03
**Module:** module-05
**Duration:** 20 minutes

## Purpose and Learning Objectives
This lesson explains how `main.py` converts an ephemeral list of conversational user responses into a structured pandas DataFrame that scikit-learn's `predict()` method can evaluate in real time.

By the end of this lesson, you will be able to:
- Explain the role of `zip()` and dictionary comprehension in binding feature names to values.
- Construct a single-row pandas `DataFrame` matching the model's expected 2D input schema.
- Trace how `model.predict(profile)[0]` executes real-time inference on a live user.
- Explain why passing feature names inside a DataFrame avoids scikit-learn feature-alignment warnings.

## Prerequisites
- Completion of Lessons 01 and 02.
- Basic understanding of Python dictionaries and the built-in `zip()` function.

## Concept Explanation
### The Bridge Between Conversation and Math
At the end of the `for question in QUESTIONS:` loop in `ask_profile()`, the chatbot has collected a list of 6 binary integers:
```python
answers = [1, 0, 0, 1, 0, 1]
```
However, `model.predict()` cannot accept a plain 1D list of numbers. Scikit-learn requires:
1. A **2-Dimensional structure** of shape `(1, 6)`.
2. Explicit **feature column headers** matching the exact names used during training (`likes_numbers`, `likes_living_things`, etc.).

If you pass a plain list or unlabelled numpy array, modern versions of scikit-learn issue a warning:
`UserWarning: X does not have valid feature names, but DecisionTreeClassifier was fitted with feature names`.

### The Elegant `dict(zip(...))` Pattern
To pair the column names with the user's answers, `main.py` uses a classic Python idiom:
```python
dict(zip(FEATURES, answers))
```
Let us see what `zip()` does:
- Pair 0: `("likes_numbers", 1)`
- Pair 1: `("likes_living_things", 0)`
- Pair 2: `("likes_stories", 0)`
- Pair 3: `("enjoys_experiments", 1)`
- Pair 4: `("enjoys_debate", 0)`
- Pair 5: `("likes_programming", 1)`

Wrapping this in `dict(...)` produces a single dictionary:
```python
{
    "likes_numbers": 1,
    "likes_living_things": 0,
    "likes_stories": 0,
    "enjoys_experiments": 1,
    "enjoys_debate": 0,
    "likes_programming": 1,
}
```

### Wrapping into a Single-Row DataFrame
Finally, wrapping the dictionary in a list and passing it to `pd.DataFrame()`:
```python
pd.DataFrame([dict(zip(FEATURES, answers))])
```
Creates a DataFrame with shape `(1, 6)`:
```
   likes_numbers  likes_living_things  likes_stories  enjoys_experiments  enjoys_debate  likes_programming
0              1                    0              0                   1              0                  1
```
This structure is $100\%$ compliant with scikit-learn's schema requirements!

## Theoretical & Real-World Context
In production web APIs (built with FastAPI or Flask), incoming JSON payloads from web clients arrive as dictionaries. Data engineers use this exact pattern to deserialize JSON requests into tabular feature records for inference engines. Preserving explicit feature names protects production models from feature permutation bugs.

## Relevant Code (from main.py)
In `main.py`, line 60 and lines 125-126 implement this assembly and inference:
```python
# Line 60 of main.py
return pd.DataFrame([dict(zip(FEATURES, answers))])

# Lines 125-126 of main.py
profile = ask_profile()
prediction = model.predict(profile)[0]
```

## Code Explanation & Line-by-Line Breakdown
- **Line 60**: Returns the single-row DataFrame representing the user's answers.
- **Line 125 (`profile = ask_profile()`)**: Invokes the Q&A loop and captures the resulting DataFrame.
- **Line 126 (`model.predict(profile)[0]`)**:
  - `model.predict(profile)` returns a numpy array containing predictions for all rows: `array(['Math'], dtype=object)`.
  - The `[0]` index extracts the first (and only) string element: `'Math'`.

## Worked Example
Let us run this assembly in Python interactive mode:
```python
import pandas as pd

FEATURES = ["likes_numbers", "likes_living_things", "likes_stories", "enjoys_experiments", "enjoys_debate", "likes_programming"]
answers = [0, 1, 0, 1, 0, 0]

# Step 1: Zip and dictionary
profile_dict = dict(zip(FEATURES, answers))
print("Profile dict:", profile_dict)

# Step 2: DataFrame
profile_df = pd.DataFrame([profile_dict])
print("DataFrame shape:", profile_df.shape)
print(profile_df)
```
Output:
```
Profile dict: {'likes_numbers': 0, 'likes_living_things': 1, 'likes_stories': 0, 'enjoys_experiments': 1, 'enjoys_debate': 0, 'likes_programming': 0}
DataFrame shape: (1, 6)
   likes_numbers  likes_living_things  likes_stories  enjoys_experiments  enjoys_debate  likes_programming
0              0                    1              0                   1              0                  0
```
The resulting DataFrame is ready for instant inference.

## Step-by-Step Student Instructions
1. Open Python in your project folder.
2. Replicate the code snippet from the Worked Example above.
3. Check `type(profile_df)`. Verify it is a `pandas.core.frame.DataFrame`.
4. Verify that `len(profile_df)` is 1 and `profile_df.shape[1]` is 6.

## Expected Output or Observable Behaviour
You have assembled a valid, named 2D feature matrix in a single line of Python.

## Verification & Testing Methods
Verify that passing this DataFrame to `model.predict()` works without warnings:
```python
from sklearn.tree import DecisionTreeClassifier
df = pd.read_csv("data/subject_answers.csv")
model = DecisionTreeClassifier(max_depth=4, random_state=42).fit(df[FEATURES], df["subject"])
pred = model.predict(profile_df)[0]
print("Prediction on profile_df:", pred)
```
Output:
```
Prediction on profile_df: Biology
```

## Practical Exercises
- **Exercise 3.1**: What happens if you forget the list brackets around the dictionary, writing `pd.DataFrame(dict(zip(FEATURES, answers)))`? Try it and observe the error.
- **Exercise 3.2**: Why is `prediction = model.predict(profile)[0]` used instead of just `prediction = model.predict(profile)`?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Correction |
|---|---|---|
| Omitting the list brackets: `pd.DataFrame(d)` | Pandas expects a dictionary of lists when creating from a bare dict | Wrap single-row dictionaries in list brackets: `pd.DataFrame([d])`. |
| Forgetting `[0]` on the prediction output | Forgetting that `model.predict()` always returns an array | Always index `[0]` when predicting on a single sample to extract the scalar string label. |

## Best Practices and Security Considerations
- **Explicit Schema Validation**: Passing DataFrames with named columns ensures that scikit-learn verifies that feature column order matches training data.
- **Single-Sample Memory Efficiency**: Creating small single-row DataFrames on the fly has negligible memory footprint (<1 KB).

## Summary & Key Takeaways
- `dict(zip(FEATURES, answers))` cleanly binds question names to user responses.
- `pd.DataFrame([d])` constructs a valid 2D feature DataFrame of shape `(1, 6)`.
- `model.predict(profile)[0]` extracts the final predicted subject string.
- This pattern ensures seamless real-time inference without feature-alignment warnings.

## Knowledge-check Questions and References
1. What does `zip(FEATURES, answers)` produce?
2. Why must the dictionary be enclosed in a list `[dict(...)]` when passed to `pd.DataFrame`?
3. Why does `model.predict()` return a 1D array rather than a single string?

**References:**
- Python documentation: *Built-in Functions — zip.* https://docs.python.org/3/library/functions.html#zip
- Pandas documentation: *DataFrame constructor from list of dicts.* https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.html
