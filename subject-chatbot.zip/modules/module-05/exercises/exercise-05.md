# Module 5 Exercises: CLI Logic & Interactive Q&A Engine

## Exercise 5.1: Command-Line Argument Inspection
**Objective:** Experiment with `sys.argv` and build a multi-flag CLI parser.
**Problem Statement:** Write a standalone Python script `cli_tester.py` that inspects `sys.argv` and supports three flags: `--interactive`, `--verbose`, and `--help`.

**Requirements:**
1. Check `sys.argv` safely without triggering `IndexError`.
2. If `--help` is present, display a usage guide and exit.
3. If `--verbose` is present, print all received arguments.
4. If `--interactive` is present, print "Entering conversational mode".

**Acceptance Criteria:**
- [ ] Script runs without errors when no arguments are provided.
- [ ] Handles multiple flags in any order.
- [ ] Accurately triggers corresponding behaviors.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes

---

## Exercise 5.2: Implementing Defensive Input Validation
**Objective:** Build a robust `ask_choice()` function from scratch.
**Problem Statement:** Write a Python function that prompts the user for their preferred study time (`morning`, `afternoon`, `night`).

**Requirements:**
1. Use an infinite `while True` loop.
2. Strip whitespace and convert input to lowercase.
3. Accept aliases:
   - Morning: `"m"`, `"morning"`, `"am"`
   - Afternoon: `"a"`, `"afternoon"`, `"pm"`
   - Night: `"n"`, `"night"`, `"late"`
4. Reject invalid strings and reprompt until valid.
5. Return the normalized label.

**Acceptance Criteria:**
- [ ] Normalizes inputs with `.strip().lower()`.
- [ ] Handles invalid inputs gracefully.
- [ ] Returns valid standardized strings.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes

---

## Exercise 5.3: DataFrame Assembly and Real-Time Inference
**Objective:** Assemble a user profile DataFrame and generate a real-time prediction.
**Problem Statement:** Write a script that fits a decision tree on `data/subject_answers.csv`, constructs a simulated user response list `[1, 1, 0, 1, 0, 1]`, and passes it through `pd.DataFrame([dict(zip(FEATURES, answers))])`.

**Requirements:**
1. Replicate lines 30-37 and 60 of `main.py`.
2. Generate prediction with `model.predict(profile)[0]`.
3. Verify that scikit-learn does not issue feature-name warnings.
4. Print the predicted subject.

**Acceptance Criteria:**
- [ ] Assembles DataFrame with correct column names.
- [ ] Predicts without warnings.
- [ ] Outputs predicted subject.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 5.4: Probability Distribution and Confidence Analysis
**Objective:** Extract and display the complete 3-class probability distribution for a profile.
**Problem Statement:** Write a function `diagnose_student(profile)` that prints the model's confidence for all three subjects in descending order.

**Requirements:**
1. Call `model.predict_proba(profile)[0]`.
2. Pair probabilities with `model.classes_`.
3. Sort the classes from highest probability to lowest probability.
4. Format and print each subject with its percentage.

**Acceptance Criteria:**
- [ ] Correctly associates probabilities with class names.
- [ ] Sorts in descending order.
- [ ] Formats percentages cleanly (e.g., `Math: 85%`).

**Difficulty:** Advanced  
**Estimated Completion Time:** 20 minutes
