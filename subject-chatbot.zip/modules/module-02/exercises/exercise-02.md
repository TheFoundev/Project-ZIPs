# Module 2 Exercises: Profile Data Analysis & Feature Engineering

## Exercise 2.1: Loading and Inspecting subject_answers.csv
**Objective:** Load the project dataset using pandas and verify its dimensions and integrity.
**Problem Statement:** Write a Python script to ingest `data/subject_answers.csv`, print its row and column dimensions, and verify that there are no missing (`NaN`) values.

**Requirements:**
1. Use `pathlib.Path` to resolve the path to `data/subject_answers.csv`.
2. Load the CSV into a pandas DataFrame named `df`.
3. Print `df.shape` and assert that it equals `(90, 7)`.
4. Calculate and print the total number of null values across the entire DataFrame.

**Acceptance Criteria:**
- [ ] Script executes without errors.
- [ ] Outputs shape: `(90, 7)`.
- [ ] Confirms total null count is `0`.
- [ ] Uses `pathlib.Path` rather than raw hardcoded strings.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes

---

## Exercise 2.2: Computing Positive Feature Frequencies
**Objective:** Calculate the positive response rate for all 6 binary survey questions.
**Problem Statement:** Analyze the percentage of students who answered "Yes" ($1$) to each question in `data/subject_answers.csv`.

**Requirements:**
1. Isolate the 6 feature columns using the `FEATURES` list.
2. Compute the mean of each feature column.
3. Multiply by 100 to convert to percentages.
4. Format and print each feature name alongside its percentage rounded to 1 decimal place.

**Acceptance Criteria:**
- [ ] Correctly computes means for all 6 features.
- [ ] Values match known benchmarks (all between 42.0% and 56.0%).
- [ ] Output is neatly formatted in a clean table or aligned lines.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes

---

## Exercise 2.3: Analyzing Class Balance & Baseline Accuracy
**Objective:** Compute class distribution and determine the majority-class baseline.
**Problem Statement:** Evaluate the target column `subject` to determine class counts, class percentages, and the baseline accuracy that any predictive model must beat.

**Requirements:**
1. Extract `df["subject"]`.
2. Compute value counts for Math, Literature, and Biology.
3. Compute the proportion of the most frequent class (Math).
4. Print a 3-sentence summary explaining why an ML model achieving 50% accuracy on this dataset would still be better than random guessing (33.3%) and majority guessing (38.9%).

**Acceptance Criteria:**
- [ ] Identifies Math (35), Literature (29), Biology (26).
- [ ] Calculates baseline accuracy of ~38.9%.
- [ ] Justifies the baseline comparison in clear written text.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 2.4: Feature Matrix X and Target y Separation
**Objective:** Separate features and target while verifying data types and shapes.
**Problem Statement:** Replicate lines 64-67 of `main.py` and write assertions verifying scikit-learn compliance.

**Requirements:**
1. Extract `X = df[FEATURES]` and `y = df["subject"]`.
2. Verify `type(X)` is `pd.DataFrame` and `X.shape == (90, 6)`.
3. Verify `type(y)` is `pd.Series` and `y.shape == (90,)`.
4. Demonstrate that `X` contains only integer types and `y` contains string/object types.

**Acceptance Criteria:**
- [ ] All assertions pass without raising `AssertionError`.
- [ ] Demonstrates mastery of 2D feature matrices vs 1D target series.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes
