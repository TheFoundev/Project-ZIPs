# Lesson 03: Subject Distribution and Class Balance (Math, Biology, Literature)

**Lesson ID:** lesson-03
**Module:** module-02
**Duration:** 20 minutes

## Purpose and Learning Objectives
This lesson explores class distribution in multiclass datasets, examining the balance between Math, Biology, and Literature students in `subject_answers.csv` and establishing the concept of baseline accuracy.

By the end of this lesson, you will be able to:
- Compute the exact frequencies and proportions of target classes in `subject_answers.csv`.
- Define **class balance** and contrast it with **imbalanced datasets**.
- Calculate the **majority-class baseline accuracy** (the benchmark any machine learning model must beat).
- Understand why stratified sampling is essential when splitting multiclass datasets.

## Prerequisites
- Completion of Lessons 01 and 02.
- Basic arithmetic and percentage calculations.

## Concept Explanation
### Class Distribution in `subject_answers.csv`
In any classification project, the first diagnostic step after data loading is inspecting the distribution of target classes.
Let us examine the counts in `data/subject_answers.csv`:

```python
import pandas as pd
df = pd.read_csv("data/subject_answers.csv")
print(df["subject"].value_counts())
print(df["subject"].value_counts(normalize=True).round(3))
```
Output:
```
Math          35
Literature    29
Biology       26
Name: subject, dtype: int64

Math          0.389
Literature    0.322
Biology       0.289
Name: subject, dtype: float64
```

Out of 90 total students:
- **Math**: 35 students ($38.9\%$)
- **Literature**: 29 students ($32.2\%$)
- **Biology**: 26 students ($28.9\%$)

### What is Class Balance?
A dataset is **balanced** when all target classes have approximately equal representation.
- A perfectly balanced 3-class dataset would have $33.3\%$ in each class ($30 / 30 / 30$).
- Our dataset has a ratio of $35 : 29 : 26$. This is **highly balanced**. No class dominates the dataset, and no class is a rare minority.

In contrast, an **imbalanced dataset** might have $98\%$ non-fraud transactions and $2\%$ fraud transactions, requiring specialized sampling techniques (like SMOTE or class-weighting).

### The Baseline Classifier: The Majority-Class Rule
Before celebrating that your machine learning model achieves $78.3\%$ accuracy, you must always ask: *"What accuracy would a completely naive model get without learning anything?"*

The simplest possible classifier is the **Zero-Rule (Majority Class) Baseline**: it ignores all user answers and blindly guesses the most frequent class every single time.
In our dataset, the most frequent class is **Math** ($35$ out of $90$).
$$\text{Baseline Accuracy} = \frac{35}{90} \approx 38.9\%$$

- If you built a "dumb" chatbot that simply answered *"You love Math!"* to every user regardless of what they typed, it would be correct $38.9\%$ of the time!
- Therefore, our Decision Tree's test accuracy of **$78.3\%$** represents a dramatic improvement of $+39.4\%$ over the naive baseline.

## Theoretical & Real-World Context
In production machine learning, reporting raw accuracy without context can be deceptive:
- In cancer screening where $99\%$ of patients are healthy, a model predicting "Healthy" for everyone achieves $99\%$ accuracy while failing to detect a single sick patient!
- In our subject chatbot, because classes are evenly balanced, accuracy is a trustworthy and meaningful metric. A random guesser would achieve $33.3\%$, the majority baseline achieves $38.9\%$, and our trained model achieves $78.3\%$.

## Relevant Code (from main.py)
In `main.py`, lines 68-70 apply **stratification** during the train/test split:
```python
# Lines 68-70 of main.py
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)
```

## Code Explanation & Line-by-Line Breakdown
- **`stratify=y`**: Instructs scikit-learn to divide the data such that both `y_train` and `y_test` contain the exact same class proportions as the full dataset ($~39\%$ Math, $~32\%$ Literature, $~29\%$ Biology).
- **Why this matters**: With only 23 samples in the test set, random unstratified splitting could accidentally put 15 Math samples and only 2 Biology samples in the test set, distorting evaluation metrics.

## Worked Example
Let us verify the class counts in the test split (`y_test`):
- Total test samples: $23$ (which is $25\%$ of 90, rounded).
- Stratified test counts:
  - Math: $9$ samples ($9 / 23 \approx 39.1\%$)
  - Literature: $8$ samples ($8 / 23 \approx 34.8\%$)
  - Biology: $6$ samples ($6 / 23 \approx 26.1\%$)

Notice how closely these match the original distribution ($38.9\%$, $32.2\%$, $28.9\%$). Stratification guarantees fair evaluation.

## Step-by-Step Student Instructions
1. Open Python in the project directory.
2. Load the dataset and inspect target counts:
   ```python
   import pandas as pd
   df = pd.read_csv("data/subject_answers.csv")
   counts = df["subject"].value_counts()
   print(counts)
   ```
3. Calculate the percentage of each class:
   ```python
   print((counts / len(df) * 100).round(1))
   ```
4. Verify that Math is 35, Literature is 29, and Biology is 26.

## Expected Output or Observable Behaviour
You will observe:
```
Math          38.9%
Literature    32.2%
Biology       28.9%
```
The sum equals $100.0\%$.

## Verification & Testing Methods
Verify the baseline accuracy programmatically:
```python
baseline_acc = df["subject"].value_counts().max() / len(df)
print(f"Majority Baseline Accuracy: {baseline_acc:.1%}")
```
Output:
```
Majority Baseline Accuracy: 38.9%
```

## Practical Exercises
- **Exercise 3.1**: What would the expected accuracy be of an agent that rolls a fair 3-sided die to guess the subject?
- **Exercise 3.2**: Why is `stratify=y` especially critical when working with small datasets (like $N=90$) compared to massive datasets (like $N=1,000,000$)?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Correction |
|---|---|---|
| Omitting `stratify=y` in `train_test_split` | Forgetting the parameter exists | Always include `stratify=y` in classification tasks to ensure train and test sets have identical class distributions. |
| Evaluating accuracy without a baseline | Thinking 70% accuracy is always good | If the majority class makes up 80% of data, 70% is terrible. Always compare model accuracy to the majority-class baseline. |

## Best Practices and Security Considerations
- **Stratified Partitioning**: Always enforce stratified sampling for categorical target labels.
- **Fair Representation**: Ensure training datasets do not under-represent specific user demographics or academic interests.

## Summary & Key Takeaways
- `subject_answers.csv` contains 35 Math ($38.9\%$), 29 Literature ($32.2\%$), and 26 Biology ($28.9\%$) student profiles.
- The dataset is well-balanced across all three target disciplines.
- The majority-class baseline accuracy is $38.9\%$; our Decision Tree achieves $78.3\%$, demonstrating true learned intelligence.
- `stratify=y` preserves class ratios across training (67 samples) and test (23 samples) partitions.

## Knowledge-check Questions and References
1. What is the most frequent class in `subject_answers.csv`, and how many rows belong to it?
2. What is the accuracy of a naive classifier that guesses the majority class every time?
3. What parameter in `train_test_split` guarantees identical class proportions in the test split?

**References:**
- Chawla, N. V., et al. (2002). *SMOTE: Synthetic minority over-sampling technique.* Journal of Artificial Intelligence Research, 16, 321-357.
- Scikit-learn documentation: *Stratified Shuffle Split.* https://scikit-learn.org/stable/modules/cross_validation.html#stratification
