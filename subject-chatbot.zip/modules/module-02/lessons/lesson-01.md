# Lesson 01: Dataset Deep Dive: Structure and Schema of subject_answers.csv

**Lesson ID:** lesson-01
**Module:** module-02
**Duration:** 20 minutes

## Purpose and Learning Objectives
The purpose of this lesson is to examine the structure, format, and statistical integrity of `data/subject_answers.csv`.

By the end of this lesson, you will be able to:
- Verify the dimensions, column headers, and data types of `data/subject_answers.csv`.
- Inspect raw CSV records and recognize the tabular organization of machine learning datasets.
- Confirm the cleanliness and absence of missing values (`NaN`) in the dataset.
- Explain why consistent schema definitions are essential before model training.

## Prerequisites
- Completion of Module 01.
- Basic understanding of comma-separated values (CSV) files.

## Concept Explanation
### Tabular Representation in Machine Learning
In supervised machine learning, datasets are almost universally structured as two-dimensional tables:
- **Rows (Instances / Samples)**: Each row corresponds to a single observed individual or event. In our project, each row represents one student's survey submission.
- **Columns (Attributes / Features & Target)**: Each column represents a measurable characteristic or the outcome label.

### The Schema of `subject_answers.csv`
Let us inspect the exact header and first few lines of `data/subject_answers.csv`:
```csv
likes_numbers,likes_living_things,likes_stories,enjoys_experiments,enjoys_debate,likes_programming,subject
1,0,1,0,1,1,Math
0,0,0,1,0,0,Biology
0,1,0,0,1,0,Literature
1,0,1,1,0,0,Literature
```

The dataset consists of:
1. **Total Records**: Exactly 90 student response rows (plus 1 header row = 91 lines total).
2. **Total Columns**: 7 columns total.
   - 6 Input Features: `likes_numbers`, `likes_living_things`, `likes_stories`, `enjoys_experiments`, `enjoys_debate`, `likes_programming`.
   - 1 Output Target: `subject`.

### Data Types and Memory Representation
When pandas reads `subject_answers.csv`:
- The 6 feature columns contain integer values (`0` or `1`), loaded by pandas as `int64`.
- The target column `subject` contains text strings (`"Math"`, `"Biology"`, `"Literature"`), loaded by pandas as `object` (string).

## Theoretical & Real-World Context
In real-world data science, real datasets are rarely this tidy. They often contain missing values, inconsistent casing (`"math"`, `"Math"`, `"MATH"`), corrupt rows, and trailing commas. Ensuring data cleanliness before modeling is known as **data validation**.

Because `subject_answers.csv` is curated for educational clarity, it is completely free of null values, allowing students to focus on core algorithmic principles rather than complex data imputation techniques.

## Relevant Code (from main.py)
In `main.py`, lines 64-67 handle the ingestion of this dataset:
```python
# Lines 64-67 of main.py
def main() -> None:
    df = pd.read_csv(DATA / "subject_answers.csv")
    X = df[FEATURES]
    y = df["subject"]
```

## Code Explanation & Line-by-Line Breakdown
- **Line 64 (`pd.read_csv(DATA / "subject_answers.csv")`)**: Uses pandas' fast C-based CSV parser to load the file into memory as a `DataFrame`.
- **`DATA / "subject_answers.csv"`**: Utilizes the `pathlib.Path` pointer established earlier.
- **Line 65 (`X = df[FEATURES]`)**: Subsets the DataFrame to extract only the 6 specified predictive columns.
- **Line 66 (`y = df["subject"]`)**: Extracts the ground-truth target labels.

## Worked Example
Let us verify the properties of the dataset directly using Python in the terminal:
```python
import pandas as pd
from pathlib import Path

df = pd.read_csv("data/subject_answers.csv")
print("Shape of dataset:", df.shape)
print("Data types:\n", df.dtypes)
print("Null values count:\n", df.isnull().sum())
```
Output:
```
Shape of dataset: (90, 7)
Data types:
 likes_numbers          int64
likes_living_things    int64
likes_stories          int64
enjoys_experiments     int64
enjoys_debate          int64
likes_programming      int64
subject               object
dtype: object
Null values count:
 likes_numbers          0
likes_living_things    0
likes_stories          0
enjoys_experiments     0
enjoys_debate          0
likes_programming      0
subject                0
dtype: int64
```
This confirms that the dataset contains exactly 90 observations and 0 missing values.

## Step-by-Step Student Instructions
1. Open your terminal and change directory to `beginner-projects-main/AI-ML Beginners/projects/17_subject_chatbot`.
2. Inspect the first 10 rows using the shell command:
   ```bash
   head -n 11 data/subject_answers.csv
   ```
3. Count the total lines in the file using:
   ```bash
   wc -l data/subject_answers.csv
   ```
   (Verify it reports 91 lines: 1 header line + 90 data rows).

## Expected Output or Observable Behaviour
Running `wc -l data/subject_answers.csv` outputs:
```
91 data/subject_answers.csv
```
This confirms 90 student profiles are available for training and testing.

## Verification & Testing Methods
Run a one-line Python command to verify that all values in the feature columns are strictly 0 or 1:
```bash
python -c "import pandas as pd; df = pd.read_csv('data/subject_answers.csv'); print(set(df.iloc[:, :6].values.flatten()))"
```
Expected output:
```
{0, 1}
```
This confirms there are no erroneous values (such as 2, -1, or text strings) in the feature matrix.

## Practical Exercises
- **Exercise 1.1**: Open Python and write a script to display the summary statistics (`df.describe()`) of the 6 features.
- **Exercise 1.2**: Calculate the mean of each feature column. What does the mean of a binary 0/1 column represent? (Hint: It represents the proportion of students who answered "Yes"!).

## Common Mistakes and Debugging
| Mistake | Why It Happens | Correction |
|---|---|---|
| Assuming `df.shape[0]` equals 91 | Counting the CSV header as a data sample | Pandas automatically treats the first row as column names, so `df.shape` is `(90, 7)`. |
| Modifying the CSV file with Excel | Excel can silently convert binary values or alter text encodings | Always inspect and edit ML CSV datasets using plain-text editors (VS Code, nano) or pandas scripts. |
| Looking for `subject_answers.csv` in the root folder | File is located inside the `data/` subdirectory | Always reference `DATA / "subject_answers.csv"`. |

## Best Practices and Security Considerations
- **Data Integrity Verification**: Always verify that `df.isnull().sum().sum() == 0` before training any scikit-learn model, as standard decision trees in scikit-learn reject missing values.
- **Immutable Raw Data**: Treat `data/subject_answers.csv` as read-only raw input. Never overwrite raw data directly.

## Summary & Key Takeaways
- `data/subject_answers.csv` contains 90 rows and 7 columns (6 binary features and 1 target).
- All 6 feature columns are clean integers ($0$ or $1$) with zero missing values.
- The target column `subject` contains three distinct text labels (`Math`, `Biology`, `Literature`).
- In pandas, the dataset occupies a $(90, 7)$ DataFrame.

## Knowledge-check Questions and References
1. How many total student profiles are contained in `subject_answers.csv`?
2. What are the two data types present in the DataFrame?
3. What does a value of `0` in `df.isnull().sum()` signify?

**References:**
- McKinney, W. (2022). *Python for Data Analysis: Data Wrangling with pandas, NumPy, and Jupyter (3rd ed.).* O'Reilly Media.
- Pandas documentation: *pandas.read_csv.* https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html
