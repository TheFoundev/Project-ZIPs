# Lesson 04: Loading and Structuring Data: Pandas Extraction, Feature Matrix X, and Target y

**Lesson ID:** lesson-04
**Module:** module-02
**Duration:** 20 minutes

## Purpose and Learning Objectives
This lesson guides you through the practical pandas operations required to load `data/subject_answers.csv`, isolate the feature matrix $X$, and extract the target vector $y$.

By the end of this lesson, you will be able to:
- Use `pd.read_csv()` with `pathlib.Path` objects.
- Distinguish between a 2D pandas `DataFrame` and a 1D pandas `Series`.
- Extract the feature matrix $X$ using a predefined list of column names (`FEATURES`).
- Verify the mathematical shapes and data types of $X$ and $y$ prior to machine learning model ingestion.

## Prerequisites
- Completion of Lessons 01, 02, and 03.
- Basic understanding of Python lists and pandas indexing.

## Concept Explanation
### Scikit-Learn's Input Shape Requirements
All standard supervised learning estimators in `scikit-learn` adhere to strict shape conventions:
1. **Feature Matrix ($X$)**: Must be a **2-Dimensional array-like structure** of shape:
   $$\text{Shape}(X) = (n\_samples, n\_features)$$
   In our project, $n\_samples = 90$ and $n\_features = 6$. Therefore, $X$ must have shape `(90, 6)`.
2. **Target Vector ($y$)**: Must be a **1-Dimensional array-like structure** of shape:
   $$\text{Shape}(y) = (n\_samples,)$$
   In our project, $y$ must have shape `(90,)`.

### Extracting $X$ as a 2D DataFrame
In pandas:
- Subsetting with a list of strings (`df[["col1", "col2"]]` or `df[FEATURES]`) returns a **2D DataFrame**.
- Subsetting with a single string (`df["col1"]`) returns a **1D Series**.

Because our project defines:
```python
FEATURES = [
    "likes_numbers",
    "likes_living_things",
    "likes_stories",
    "enjoys_experiments",
    "enjoys_debate",
    "likes_programming",
]
```
Passing `df[FEATURES]` guarantees that $X$ is returned as a 2D DataFrame with 6 columns.

### Extracting $y$ as a 1D Series
Passing `df["subject"]` extracts the target column as a 1D pandas `Series` with shape `(90,)`, perfectly matching scikit-learn's target expectations.

## Theoretical & Real-World Context
In real-world data science pipelines, passing incorrectly shaped data to scikit-learn triggers immediate errors:
- If you pass a 1D Series for $X$, scikit-learn raises: `ValueError: Expected 2D array, got 1D array instead: Reshape your data either using array.reshape(-1, 1) if your data has a single feature or array.reshape(1, -1) if it contains a single sample.`
- If you pass a 2D DataFrame for $y$, scikit-learn prints warnings: `DataConversionWarning: A column-vector y was passed when a 1d array was expected.`

Mastering the precise creation of 2D $X$ and 1D $y$ avoids these fundamental pitfalls.

## Relevant Code (from main.py)
In `main.py`, lines 30-37 and 64-67 define this exact extraction:
```python
# Lines 30-37 of main.py
FEATURES = [
    "likes_numbers",
    "likes_living_things",
    "likes_stories",
    "enjoys_experiments",
    "enjoys_debate",
    "likes_programming",
]

# Lines 64-67 of main.py
def main() -> None:
    df = pd.read_csv(DATA / "subject_answers.csv")
    X = df[FEATURES]
    y = df["subject"]
```

## Code Explanation & Line-by-Line Breakdown
- **Lines 30-37**: Defines the canonical list of feature column headers.
- **Line 64**: Ingests the full 7-column CSV into memory.
- **Line 65 (`X = df[FEATURES]`)**: Selects the 6 numeric columns. Shape becomes `(90, 6)`.
- **Line 66 (`y = df["subject"]`)**: Isolates the target labels. Shape becomes `(90,)`.

## Worked Example
Let us execute and inspect these objects in an interactive Python session:
```python
import pandas as pd
from pathlib import Path

df = pd.read_csv("data/subject_answers.csv")
FEATURES = [
    "likes_numbers", "likes_living_things", "likes_stories",
    "enjoys_experiments", "enjoys_debate", "likes_programming"
]

X = df[FEATURES]
y = df["subject"]

print("Type of X:", type(X))
print("Shape of X:", X.shape)
print("Type of y:", type(y))
print("Shape of y:", y.shape)
```
Output:
```
Type of X: <class 'pandas.core.frame.DataFrame'>
Shape of X: (90, 6)
Type of y: <class 'pandas.core.series.Series'>
Shape of y: (90,)
```
The dimensions match scikit-learn's requirements.

## Step-by-Step Student Instructions
1. Open your terminal in the project directory.
2. Launch Python: `python`.
3. Import pandas and load `data/subject_answers.csv`.
4. Inspect the first 3 rows of $X$:
   ```python
   print(X.head(3))
   ```
5. Inspect the first 3 elements of $y$:
   ```python
   print(y.head(3))
   ```

## Expected Output or Observable Behaviour
You will see:
```
   likes_numbers  likes_living_things  likes_stories  enjoys_experiments  enjoys_debate  likes_programming
0              1                    0              1                   0              1                  1
1              0                    0              0                   1              0                  0
2              0                    1              0                   0              1                  0
```
And for $y$:
```
0          Math
1       Biology
2    Literature
Name: subject, dtype: object
```

## Verification & Testing Methods
Verify that no data was dropped or altered:
```python
assert len(X) == len(y) == 90, "Mismatch in dataset row count!"
assert X.shape[1] == 6, "Feature count must be exactly 6!"
print("Verification passed: Shapes and row alignments are 100% correct.")
```

## Practical Exercises
- **Exercise 4.1**: What happens if you run `X = df["likes_numbers"]`? Check `X.shape` and explain why scikit-learn's `fit()` would fail.
- **Exercise 4.2**: Extract only the first two features (`likes_numbers` and `likes_living_things`) into a subset matrix $X_{sub}$. What is its shape?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Correction |
|---|---|---|
| Passing column names as strings rather than a list | Writing `df["likes_numbers", "likes_stories"]` | Always enclose multiple columns in list brackets: `df[["col1", "col2"]]` or `df[FEATURES]`. |
| Forgetting to exclude the target column from $X$ | Writing `X = df` | If the target is left inside $X$, the model achieves fake 100% accuracy through data leakage! Always isolate $X = df[FEATURES]$. |

## Best Practices and Security Considerations
- **Prevent Data Leakage**: Never include the target column (`subject`) in the feature matrix $X$.
- **Explicit Feature Lists**: Hardcoding explicit feature lists (`FEATURES`) guards against unexpected extra columns being introduced by raw CSV changes.

## Summary & Key Takeaways
- Scikit-learn requires $X$ to be a 2D matrix of shape `(n_samples, n_features)` and $y$ to be a 1D vector of shape `(n_samples,)`.
- `X = df[FEATURES]` extracts a $(90, 6)$ pandas `DataFrame`.
- `y = df["subject"]` extracts a $(90,)$ pandas `Series`.
- Verifying dimensions via `.shape` before model training prevents runtime `ValueError` crashes.

## Knowledge-check Questions and References
1. What is the shape of $X$ and $y$ in this project?
2. Why does `df[FEATURES]` return a DataFrame while `df["subject"]` returns a Series?
3. What runtime error occurs if you pass a 1D array as the feature matrix to `model.fit()`?

**References:**
- Scikit-learn documentation: *Common pitfalls and recommended practices.* https://scikit-learn.org/stable/common_pitfalls.html
- Pandas documentation: *Indexing and selecting data.* https://pandas.pydata.org/docs/user_guide/indexing.html
