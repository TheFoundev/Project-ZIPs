# Lesson 02: Binary Features and Survey Design: What the 6 Questions Measure

**Lesson ID:** lesson-02
**Module:** module-02
**Duration:** 20 minutes

## Purpose and Learning Objectives
This lesson analyzes the design of the survey questionnaire, examining how each of the 6 binary features captures psychological, academic, and behavioral preferences.

By the end of this lesson, you will be able to:
- Explain what binary feature encoding represents in survey analysis.
- Understand the domain intuition connecting specific questions to academic disciplines.
- Analyze feature correlations and identify potential overlaps between subjects.
- Evaluate the trade-offs between binary questions (Yes/No) and Likert-scale questions (1 to 5).

## Prerequisites
- Completion of Lesson 01.
- Basic understanding of survey design and binary representation.

## Concept Explanation
### The Power of Binary Encodings
In survey methodology, a **binary question** forces a respondent to make a discrete choice: either they identify with an attribute ($1$ = Yes / True) or they do not ($0$ = No / False).
While continuous variables (like temperature in degrees Celsius) measure magnitude, binary variables measure **presence or absence**.

In our chatbot, the 6 features capture affinities across three major academic domains:

| Feature Name | Conversational Question | Target Affinity Domain |
|---|---|---|
| `likes_numbers` | "Do you enjoy working with numbers?" | Quantitative / Mathematics |
| `likes_living_things` | "Do you like learning about living things?" | Natural Sciences / Biology |
| `likes_stories` | "Do you enjoy stories and writing?" | Humanities / Literature |
| `enjoys_experiments` | "Do you like running experiments?" | Empirical Sciences (Biology / Applied Math) |
| `enjoys_debate` | "Do you enjoy debating ideas?" | Humanities / Social Logic (Literature / Philosophy) |
| `likes_programming` | "Do you like programming?" | Computational Logic (Math / Computer Science) |

### Disentangling Subject Overlaps
Notice that students are rarely one-dimensional:
- A student who loves both `likes_numbers` and `likes_programming` strongly correlates with **Math**.
- A student who answers Yes to `likes_living_things` and `enjoys_experiments` strongly correlates with **Biology**.
- A student who answers Yes to `likes_stories` and `enjoys_debate` strongly correlates with **Literature**.

What happens when preferences cross traditional boundaries?
- What if a student likes living things *and* numbers? (Biostatistics / Computational Biology)
- What if a student likes programming *and* stories? (Interactive narrative / Computational linguistics)

This is precisely where the Decision Tree excels. Rather than relying on simplistic single-attribute stereotypes, the tree discovers multi-variable rules that differentiate nuanced combinations.

## Theoretical & Real-World Context
In industry user research, survey designers frequently debate between:
1. **Likert Scales (1 to 5 stars)**: Offer granular nuance but introduce subjective calibration bias (what is a "3" to one user might be a "4" to another).
2. **Forced-Choice Binary (Yes/No)**: Eliminates calibration bias, dramatically accelerates completion speed, and simplifies machine learning decision thresholds.

By choosing binary features, our chatbot minimizes cognitive burden on the student while enabling rapid, deterministic tree branching at $\le 0.50$.

## Relevant Code (from main.py)
In `main.py`, lines 30-45 maintain this parallel mapping:
```python
# Lines 30-45 of main.py
FEATURES = [
    "likes_numbers",
    "likes_living_things",
    "likes_stories",
    "enjoys_experiments",
    "enjoys_debate",
    "likes_programming",
]
QUESTIONS = [
    "Do you enjoy working with numbers?",
    "Do you like learning about living things?",
    "Do you enjoy stories and writing?",
    "Do you like running experiments?",
    "Do you enjoy debating ideas?",
    "Do you like programming?",
]
```

## Code Explanation & Line-by-Line Breakdown
- The `FEATURES` list defines the exact column headers expected by pandas and scikit-learn.
- The `QUESTIONS` list provides the user-facing natural language text displayed during interactive mode.
- Maintaining identical order ensures that when `ask_profile()` collects sequential answers, each answer corresponds to the intended feature.

## Worked Example
Let us compute the positive response rate (the percentage of students who answered "Yes") for each of the 6 questions across our 90 survey profiles:
```python
import pandas as pd
df = pd.read_csv("data/subject_answers.csv")
features = [
    "likes_numbers", "likes_living_things", "likes_stories",
    "enjoys_experiments", "enjoys_debate", "likes_programming"
]
rates = df[features].mean() * 100
for feat, rate in rates.items():
    print(f"{feat:22s}: {rate:5.1f}% answered Yes")
```
Output:
```
likes_numbers         :  55.6% answered Yes
likes_living_things   :  47.8% answered Yes
likes_stories         :  42.2% answered Yes
enjoys_experiments    :  51.1% answered Yes
enjoys_debate         :  44.4% answered Yes
likes_programming     :  48.9% answered Yes
```
Notice how balanced the dataset is! Every single question has between $42\%$ and $56\%$ positive answers. No feature is trivially all-zero or all-one, meaning every question carries valuable discriminatory information.

## Step-by-Step Student Instructions
1. Open a terminal and run Python.
2. Load the dataset into pandas:
   ```python
   import pandas as pd
   df = pd.read_csv("data/subject_answers.csv")
   ```
3. Group the dataset by `subject` and calculate the mean of each feature:
   ```python
   print(df.groupby("subject").mean().round(2))
   ```
4. Observe which subject has the highest affinity for each feature.

## Expected Output or Observable Behaviour
You will observe:
```
            likes_numbers  likes_living_things  likes_stories  enjoys_experiments  enjoys_debate  likes_programming
subject                                                                                                            
Biology              0.48                 0.79           0.17                0.86           0.28               0.24
Literature           0.27                 0.27           0.87                0.20           0.77               0.20
Math                 0.87                 0.37           0.23                0.47           0.30               1.00
```
Key observations:
- $100\%$ of Math students answered Yes to `likes_programming`!
- $87\%$ of Literature students answered Yes to `likes_stories`!
- $86\%$ of Biology students answered Yes to `enjoys_experiments`!

## Verification & Testing Methods
Verify that no student answered "No" to all 6 questions or "Yes" to all 6 questions simultaneously:
```python
row_sums = df.iloc[:, :6].sum(axis=1)
print("Minimum questions answered Yes:", row_sums.min())
print("Maximum questions answered Yes:", row_sums.max())
```
Output:
```
Minimum questions answered Yes: 1
Maximum questions answered Yes: 5
```
Every student has at least one interest and at most five interests, ensuring rich feature variance.

## Practical Exercises
- **Exercise 2.1**: Looking at the group means table above, identify which single feature is the strongest predictor of a student preferring Math.
- **Exercise 2.2**: If a user answers Yes to `likes_living_things` ($0.79$) and Yes to `enjoys_experiments` ($0.86$), which subject is the most probable?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Correction |
|---|---|---|
| Thinking a student can only like one subject's questions | Assuming human interests are mutually exclusive | Real students often have overlapping interests (e.g., loving both biology experiments and computer programming). |
| Confusing feature correlation with causation | Assuming liking numbers *causes* someone to like math | Correlation indicates statistical association; the decision tree exploits association for prediction without requiring causal mechanisms. |

## Best Practices and Security Considerations
- **Non-Biased Question Phrasing**: Questions should be phrased neutrally ("Do you enjoy...") rather than leading ("Don't you agree that numbers are exciting?").
- **Orthogonal Feature Design**: Survey questions should measure distinct facets of personality/aptitude rather than asking the same question in slightly different words.

## Summary & Key Takeaways
- The 6 survey features measure specific preferences across quantitative, scientific, and literary domains.
- Binary encodings ($0$ and $1$) simplify user input and align perfectly with decision tree splitting logic.
- Empirical group means confirm strong statistical associations: Math $\leftrightarrow$ Programming/Numbers; Biology $\leftrightarrow$ Living Things/Experiments; Literature $\leftrightarrow$ Stories/Debate.
- Features are balanced across the 90 profiles, with each feature active in approximately $42\%-56\%$ of instances.

## Knowledge-check Questions and References
1. What percentage of Math students in the dataset like programming?
2. Why is binary forced-choice questioning advantageous in automated diagnostic chatbots?
3. Which feature has the lowest positive response rate among Biology students?

**References:**
- Fowler, F. J. (2013). *Survey Research Methods (5th ed.).* SAGE Publications.
- Krosnick, J. A. (1999). *Survey research.* Annual Review of Psychology, 50(1), 537-567.
