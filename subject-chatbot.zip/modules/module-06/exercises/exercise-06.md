# Module 6 Exercises: Mode Comparison & Dataset Extension

## Exercise 6.1: Comparing Scripted vs. Interactive Workflows
**Objective:** Measure and contrast execution metrics between scripted and interactive modes.
**Problem Statement:** Write a script or terminal log that documents running `main.py` in default demo mode and `--interactive` mode.

**Requirements:**
1. Record wall-clock execution time for both modes using `time`.
2. Document the terminal output of both runs.
3. Write a 3-sentence summary explaining why batch demo mode is mandatory for automated test runners.

**Acceptance Criteria:**
- [ ] Confirms demo mode runs in <1 second.
- [ ] Documents complete interactive Q&A dialogue.
- [ ] Clearly articulates the architectural rationale.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes

---

## Exercise 6.2: Identifying and Debugging Misclassifications
**Objective:** Isolate and analyze the 5 misclassified test profiles.
**Problem Statement:** Write a Python script to isolate all test samples where `model.predict(X_test) != y_test`.

**Requirements:**
1. Train the model using the standard train/test split.
2. Filter `X_test` for rows where predictions do not match true labels.
3. Print each misclassified row's features, actual subject, and predicted subject.
4. Select one misclassified row and write a paragraph explaining why the model made that error.

**Acceptance Criteria:**
- [ ] Correctly identifies the 5 misclassified test instances.
- [ ] Displays features alongside actual and predicted labels.
- [ ] Written error explanation demonstrates understanding of feature ambiguity.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 20 minutes

---

## Exercise 6.3: Adding a Fourth Subject Category (History)
**Objective:** Expand `data/subject_answers.csv` with a new subject class and retrain the model.
**Problem Statement:** Create an expanded dataset containing 20 new student profiles whose favorite subject is "History".

**Requirements:**
1. Generate 20 synthetic rows labeled "History".
2. Ensure History students have high affinity for `likes_stories` and `enjoys_debate`, and low affinity for `likes_programming`.
3. Combine with original dataset to create `subject_answers_expanded.csv` (110 rows total).
4. Retrain `DecisionTreeClassifier(max_depth=4)` and verify that `History` appears in `model.classes_`.

**Acceptance Criteria:**
- [ ] Expanded dataset has exactly 110 rows.
- [ ] Model successfully trains on 4 classes.
- [ ] Prints updated accuracy and new classification report with History included.

**Difficulty:** Advanced  
**Estimated Completion Time:** 25 minutes

---

## Exercise 6.4: Designing a Hybrid Neuro-Symbolic Chatbot Proposal
**Objective:** Architect a modern hybrid conversational assistant.
**Problem Statement:** Write a 1-page architectural specification describing how an LLM and our Decision Tree can be integrated into a mobile college counseling app.

**Requirements:**
1. Diagram the data flow from user text to LLM entity extraction, decision tree evaluation, and final response generation.
2. Explain how this architecture prevents hallucinations.
3. Describe how `predict_proba()` confidence scores would be used to trigger human counselor handoffs.

**Acceptance Criteria:**
- [ ] Architecture diagram is clear and complete.
- [ ] Safety and anti-hallucination benefits are clearly articulated.
- [ ] Confidence thresholding logic is well-defined.

**Difficulty:** Advanced  
**Estimated Completion Time:** 20 minutes
