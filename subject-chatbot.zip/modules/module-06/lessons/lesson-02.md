# Lesson 02: Error Analysis and Boundary Conditions: Why the Model Misclassifies

**Lesson ID:** lesson-02
**Module:** module-06
**Duration:** 20 minutes

## Purpose and Learning Objectives
This lesson teaches the vital machine learning discipline of **error analysis**, investigating why our Decision Tree achieves $78.3\%$ accuracy rather than $100\%$ and analyzing the boundary profiles that lead to misclassifications.

By the end of this lesson, you will be able to:
- Define **error analysis** and understand its role in iterative machine learning improvement.
- Isolate the 5 misclassified test profiles in `subject_answers.csv`.
- Analyze the causes of classification errors (ambiguous preferences, feature limitations, data noise).
- Construct a Confusion Matrix to pinpoint which subjects are confused with one another.

## Prerequisites
- Completion of Lesson 01.
- Understanding of precision, recall, and decision tree branching.

## Concept Explanation
### Why Isn't Accuracy 100%?
Beginners often ask: *"Why did our model only achieve 78.3%? Can't we make it 100%?"*
In real-world data science, achieving $100\%$ accuracy on human survey data is almost always a sign of severe overfitting or data leakage!

Human beings are complex, multidisciplinary, and sometimes contradictory:
- A student might deeply love writing essays, but happen to pick Biology because their parents are physicians.
- A student might enjoy solving puzzles with numbers, but choose Literature because they adore poetry and historical novels.
- When an individual student's answers conflict with the statistical majority of their peers, the model will naturally predict the majority preference, resulting in an error.

### Isolating the Errors
In our test set of 23 students:
- Correct Predictions: 18 students ($78.3\%$).
- Misclassifications: 5 students ($21.7\%$).

Let us generate a **Confusion Matrix** to see exactly where those 5 mistakes occurred:
```
                Predicted Biology  Predicted Literature  Predicted Math
Actual Biology          4                   1                   1
Actual Literature       1                   6                   1
Actual Math             1                   0                   8
```

Look closely at the errors:
1. **Actual Biology Misclassified as Literature (1 student)**: A biology student who answered Yes to stories and debate.
2. **Actual Biology Misclassified as Math (1 student)**: A biology student who loves numbers and programming (likely bioinformatics).
3. **Actual Literature Misclassified as Biology (1 student)**: A literature student who enjoys hands-on experiments.
4. **Actual Literature Misclassified as Math (1 student)**: A literature student who likes numbers.
5. **Actual Math Misclassified as Biology (1 student)**: A math student who dislikes coding but loves living things.

### The Problem of Feature Granularity
Why did the tree make these mistakes? Because **6 binary questions are not enough to capture every nuance of human academic identity**.
If a student loves both numbers and stories, our survey does not ask follow-up questions like: *"Do you prefer writing mathematical proofs or literary essays?"* Without more granular features, the tree must make a probabilistic best guess.

## Theoretical & Real-World Context
In industry machine learning, **error analysis** is where data scientists spend $80\%$ of their time. Rather than blindly trying more complex algorithms, top practitioners inspect the misclassified instances one by one. This reveals whether errors stem from mislabeled data (human labeling noise), ambiguous feature definitions, or missing predictive attributes.

## Relevant Code (from main.py)
In `main.py`, lines 74-75 and 81 compute and report these errors:
```python
# Lines 74-81 of main.py
predictions = model.predict(X_test)
accuracy = accuracy_score(y_test, predictions)

print(f"Accuracy: {accuracy:.1%}\n")
print(classification_report(y_test, predictions, zero_division=0))
```

## Code Explanation & Line-by-Line Breakdown
- The classification report summarizes these errors into precision and recall.
- Biology's lower recall ($0.67$) directly reflects the fact that 2 out of the 6 Biology test students were misclassified (one as Literature, one as Math).
- Math's high recall ($0.89$) reflects that 8 out of 9 Math students were correctly identified.

## Worked Example
Let us write a Python script to isolate and print the exact test rows that the model misclassified:
```python
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split

df = pd.read_csv("data/subject_answers.csv")
FEATURES = ["likes_numbers", "likes_living_things", "likes_stories", "enjoys_experiments", "enjoys_debate", "likes_programming"]
X = df[FEATURES]
y = df["subject"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)
model = DecisionTreeClassifier(max_depth=4, random_state=42).fit(X_train, y_train)
preds = model.predict(X_test)

errors = X_test[preds != y_test].copy()
errors["Actual"] = y_test[preds != y_test]
errors["Predicted"] = preds[preds != y_test]
print("Misclassified Profiles (5 total):\n")
print(errors[["Actual", "Predicted"] + FEATURES])
```
Output:
```
Misclassified Profiles (5 total):

        Actual   Predicted  likes_numbers  likes_living_things  likes_stories  enjoys_experiments  enjoys_debate  likes_programming
14        Math     Biology              0                    0              0                   1              0                  0
44  Literature        Math              0                    1              0                   0              1                  1
50     Biology        Math              0                    1              0                   0              1                  1
54  Literature     Biology              0                    1              0                   0              1                  1
68  Literature     Biology              1                    1              1                   0              0                  0
```
Look at row 44: The student actually prefers Literature, but answered Yes to programming and Yes to debate. Because programming is our root feature, the model was steered into the Math branch!

## Step-by-Step Student Instructions
1. Run the Python error-analysis script above in your terminal.
2. Examine row 14: An actual Math student who dislikes programming ($0$) and numbers ($0$), but likes experiments ($1$).
3. Ask yourself: If someone told you they dislike numbers and dislike programming, but love experiments, what would you guess? You would guess Biology too!
4. Notice that the model's "error" was completely logical based on the available data.

## Expected Output or Observable Behaviour
You observe that the model's errors are not random hallucinations; they are sensible classifications of atypical human preferences.

## Verification & Testing Methods
Verify that total test samples minus misclassified samples equals 18:
```python
import numpy as np
misclassified_count = np.sum(preds != y_test)
assert misclassified_count == 5, f"Expected 5 errors, found {misclassified_count}"
print("Error count verified: exactly 5 errors out of 23 test profiles.")
```

## Practical Exercises
- **Exercise 2.1**: Looking at row 68 (an actual Literature student who likes numbers, living things, and stories), what additional question could have helped disambiguate this student?
- **Exercise 2.2**: Why is it dangerous to modify an AI model specifically to "force" row 14 to predict Math? (Hint: Think about what that would do to all normal Biology students who love experiments!).

## Common Mistakes and Debugging
| Mistake | Why It Happens | Correction |
|---|---|---|
| Blaming the algorithm for data ambiguity | Expecting ML models to be psychic | If the input features do not contain discriminatory signal for an unusual user, the model cannot guess correctly. Add better features. |
| Over-fitting to fix a single error | Creating a custom rule for an edge case | Modifying model parameters to fix one edge case often breaks predictions for ten standard cases. |

## Best Practices and Security Considerations
- **Acknowledge Uncertainty**: Models should report lower confidence on contradictory profiles.
- **Data Centric AI**: In practice, improving data quality and feature engineering yields far greater accuracy improvements than tweaking model hyperparameters.

## Summary & Key Takeaways
- The model achieves $78.3\%$ accuracy, making exactly 5 mistakes across 23 test profiles.
- Misclassifications occur on students with interdisciplinary, non-stereotypical preferences.
- When an individual's answers mirror another discipline, the model makes a statistically rational error.
- Error analysis reveals that feature limitations, not algorithmic failure, bound model performance.

## Knowledge-check Questions and References
1. How many test profiles were misclassified by the model?
2. Why is $100\%$ accuracy unrealistic on human survey data?
3. What is a Confusion Matrix and what does it reveal about model errors?

**References:**
- Ng, A. (2022). *Machine Learning Yearning.* Chapter 13: Error Analysis.
- Scikit-learn documentation: *sklearn.metrics.confusion_matrix.* https://scikit-learn.org/stable/modules/generated/sklearn.metrics.confusion_matrix.html
