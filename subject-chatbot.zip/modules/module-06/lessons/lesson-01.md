# Lesson 01: Execution Comparison: Scripted Automation vs. Conversational Interaction

**Lesson ID:** lesson-01
**Module:** module-06
**Duration:** 20 minutes

## Purpose and Learning Objectives
This lesson provides a comprehensive comparative analysis of running `main.py` in its two operational modes: **Scripted Batch Demo Mode** and **Live Interactive Mode**.

By the end of this lesson, you will be able to:
- Compare the execution workflows, latency, and input/output characteristics of both modes.
- Understand how automated batch modes facilitate continuous integration and model verification.
- Describe the conversational user journey during live CLI execution.
- Identify when to deploy batch evaluation versus conversational serving in industry.

## Prerequisites
- Completion of Modules 01 through 05.
- Experience executing `python main.py` and `python main.py --interactive`.

## Concept Explanation
### Side-by-Side Mode Comparison
Let us contrast the two execution paradigms implemented in `main.py`:

| Dimension | Scripted Demo Mode (`python main.py`) | Interactive Mode (`python main.py --interactive`) |
|---|---|---|
| **Trigger Mechanism** | Default (no command-line flags) | Explicit `--interactive` flag in `sys.argv` |
| **Input Source** | Hardcoded synthetic DataFrame (`demo_profiles`) | Live keyboard inputs via `input()` |
| **Blocking Behavior** | Non-blocking (runs in milliseconds) | Blocking (awaits human keystrokes) |
| **Evaluation Scope** | 3 archetypal student personas (Math, Bio, Lit) | 1 specific live human profile |
| **Output Artifacts** | `chatbot_tree.png`, `rules.txt`, console metrics | Console prediction + confidence percentage |
| **Primary Audience** | Automated test harnesses, CI/CD, instructors | End users, students, counselors |

### The Batch Workflow
In Scripted Demo Mode:
1. Loads historical CSV data.
2. Fits the decision tree.
3. Computes accuracy on test data.
4. Generates flowchart image and text rules.
5. Predicts subjects for Student 1, 2, and 3 simultaneously in a single vectorized pass.
6. Terminates cleanly with exit code 0.

### The Conversational Workflow
In Interactive Mode:
1. Completes steps 1-4 of the batch workflow (so the model is fully trained).
2. Pauses and prompts the user through the 6-question survey.
3. Validates each user response.
4. Dynamically builds a single-row DataFrame.
5. Invokes `model.predict()` and `model.predict_proba()`.
6. Prints the final guess with confidence percentage.

## Theoretical & Real-World Context
In enterprise AI architectures, this separation reflects the difference between **Model Training / Validation Pipelines** and **Inference Serving Endpoints**:
- **Batch / Offline Pipelines**: Train models overnight, evaluate regression test suites, export serialized model weights (`.joblib` or `.onnx`), and upload audit reports to cloud storage.
- **Online / Interactive Serving**: Load pre-trained weights and serve live predictions to human users via web chat interfaces, REST APIs, or mobile apps with low latency.

## Relevant Code (from main.py)
In `main.py`, lines 123-133 define this branching:
```python
# Lines 123-133 of main.py
if "--interactive" in sys.argv:
    print("\nAnswer six questions and the chatbot will guess your subject.\n")
    profile = ask_profile()
    prediction = model.predict(profile)[0]
    probabilities = model.predict_proba(profile)[0]
    confidence = probabilities.max()
    print(f"\nThe chatbot guesses: {prediction} ({confidence:.0%} confident)")
else:
    print("Run `python main.py --interactive` to chat with it yourself.")
    print("Try this: add a new subject and 20 example profiles.")
```

## Code Explanation & Line-by-Line Breakdown
- When executing without flags, the script trains the model, evaluates the three demo students, saves all artifacts, prints friendly advice, and exits immediately.
- When executing with `--interactive`, the script leverages the freshly trained model to provide an interactive dialogue session.

## Worked Example
Compare the execution times of both modes in Linux using the `time` utility:
```bash
$ time python main.py
...
real    0m0.428s
user    0m0.512s
sys     0m0.088s
```
Notice that demo mode completes in under half a second!
Now run interactive mode:
```bash
$ time python main.py --interactive
...
real    0m14.281s
user    0m0.530s
sys     0m0.092s
```
Notice that while the CPU time (`user` + `sys`) is identical (~0.6s), the `real` wall-clock time was 14 seconds because the script waited for a human to read and type answers.

## Step-by-Step Student Instructions
1. Open your terminal.
2. Execute `python main.py > demo_run.log`.
3. Check `demo_run.log` using `cat demo_run.log`. Notice how cleanly stdout was redirected because the script did not require keyboard interaction.
4. Now run `python main.py --interactive`.
5. Experience the Q&A loop firsthand.

## Expected Output or Observable Behaviour
You observe two distinct operational modalities from a single unified codebase.

## Verification & Testing Methods
Verify that both modes produce the exact same prediction for an identical profile:
- Run interactive mode and answer: `1, 0, 0, 1, 0, 1` (matching Student 1).
- Confirm that the chatbot outputs: `Math (100% confident)`.
- Confirm this matches Student 1's demo prediction (`Student 1: Math`).

## Practical Exercises
- **Exercise 1.1**: What happens if you redirect input from a text file into interactive mode: `python main.py --interactive < answers.txt`?
- **Exercise 1.2**: List two reasons why automated grading scripts require demo mode rather than interactive mode.

## Common Mistakes and Debugging
| Mistake | Why It Happens | Correction |
|---|---|---|
| Running `python main.py --interactive` in a non-interactive CI runner | The runner hangs indefinitely waiting for input and times out | Always execute `python main.py` without flags in automated CI scripts. |
| Expecting interactive mode to re-train the model | Believing interactive answers change the decision tree | Interactive mode runs **inference** only; it evaluates the existing trained model. |

## Best Practices and Security Considerations
- **Environment Awareness**: Scripts should detect whether `sys.stdin` is attached to an interactive TTY before entering interactive loops.
- **Deterministic Pipeline Execution**: Always ensure training and file generation happen deterministically before user prompts begin.

## Summary & Key Takeaways
- Scripted demo mode provides sub-second non-blocking execution for automated testing and grading.
- Interactive mode provides a personalized conversational experience using `ask_profile()`.
- Both modes share the exact same underlying decision tree model, ensuring behavioral consistency.
- Separating batch evaluation from interactive inference mirrors enterprise production ML standards.

## Knowledge-check Questions and References
1. How does the wall-clock execution time differ between scripted demo mode and interactive mode?
2. What are the three synthetic student personas designed to test?
3. Why does interactive mode not alter the decision tree weights?

**References:**
- Humble, J., & Farley, D. (2010). *Continuous Delivery: Reliable Software Releases through Build, Test, and Deployment Automation.* Addison-Wesley.
- Python documentation: *sys.stdin.isatty().* https://docs.python.org/3/library/io.html#io.IOBase.isatty
