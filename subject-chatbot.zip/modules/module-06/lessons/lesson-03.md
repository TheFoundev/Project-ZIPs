# Lesson 03: Extending the System: Adding New Subjects (History/Art) and Custom Questions

**Lesson ID:** lesson-03
**Module:** module-06
**Duration:** 20 minutes

## Purpose and Learning Objectives
This lesson guides you through extending the Subject Chatbot codebase to classify additional academic disciplines (such as History, Art, or Computer Science) and designing new discriminatory survey features.

By the end of this lesson, you will be able to:
- Design new survey questions that capture unique characteristics of a new academic field.
- Append new synthetic or empirical student profiles to `data/subject_answers.csv`.
- Update `FEATURES` and `QUESTIONS` in `main.py` while maintaining schema integrity.
- Retrain and evaluate the expanded decision tree on 4 or more subject classes.

## Prerequisites
- Completion of Lessons 01 and 02.
- Familiarity with CSV formatting and pandas DataFrame operations.

## Concept Explanation
### The Challenge in README.md
In the project `README.md`, line 38 presents an exciting open challenge:
```markdown
## Try this

Add a new subject and 20 example profiles. Does the tree still make sense?
```

Adding a new subject (e.g., **History** or **Art**) transforms our 3-class classification engine into a 4-class or 5-class engine.

### Designing Orthogonal Features
If we add **History**, what questions should we ask?
If we only use our existing 6 questions:
- A History student might answer: `likes_numbers=0, likes_living_things=0, likes_stories=1, enjoys_experiments=0, enjoys_debate=1, likes_programming=0`.
- Notice the problem: This is **identical** to the profile of a Literature student!
- If two different classes have identical feature vectors, no decision tree in the universe can distinguish them!

To successfully add History, we must introduce a **discriminatory feature**:
- New Feature: `likes_historical_events`
- New Question: *"Do you enjoy learning about the past and historical events?"*

Now:
- Literature Student: `likes_stories=1, likes_historical_events=0`
- History Student: `likes_stories=1, likes_historical_events=1`
The tree now has the discriminatory power to separate them!

### Steps to Extend the System
1. **Expand CSV Schema**: Add the new feature column header to `subject_answers.csv`.
2. **Add Training Profiles**: Create 20 new rows representing students who prefer the new subject.
3. **Update `FEATURES` and `QUESTIONS`**: Add the new feature name and question string in `main.py`.
4. **Retrain and Re-Evaluate**: Execute `python main.py` to observe the new tree flowchart and metrics.

## Theoretical & Real-World Context
In enterprise AI product development, this workflow is known as **taxonomy expansion**. When an e-commerce platform adds a new product category or a medical triage bot adds a new disease condition, engineers must evaluate whether existing attributes are sufficient or whether new intake questions must be designed.

## Relevant Code (from main.py)
In `main.py`, lines 30-45 require expansion:
```python
# Lines 30-45 of main.py
FEATURES = [
    "likes_numbers",
    "likes_living_things",
    "likes_stories",
    "enjoys_experiments",
    "enjoys_debate",
    "likes_programming",
    # Add: "likes_historical_events",
]
QUESTIONS = [
    "Do you enjoy working with numbers?",
    "Do you like learning about living things?",
    "Do you enjoy stories and writing?",
    "Do you like running experiments?",
    "Do you enjoy debating ideas?",
    "Do you like programming?",
    # Add: "Do you enjoy learning about the past?",
]
```

## Code Explanation & Line-by-Line Breakdown
- The order of `FEATURES` and `QUESTIONS` must remain strictly synchronized.
- Scikit-learn's `DecisionTreeClassifier` automatically detects the new class name in `df["subject"]` and expands its internal class list (`model.classes_`).
- The tree flowchart dynamically creates a new color hue for the added class.

## Worked Example
Let us write a small script that creates an expanded dataset `data/subject_answers_expanded.csv` with 20 new History students:
```python
import pandas as pd
import numpy as np

# Load original 90 rows
df = pd.read_csv("data/subject_answers.csv")

# Create 20 synthetic History students
np.random.seed(42)
history_rows = []
for _ in range(20):
    history_rows.append({
        "likes_numbers": np.random.choice([0, 1], p=[0.8, 0.2]),
        "likes_living_things": np.random.choice([0, 1], p=[0.8, 0.2]),
        "likes_stories": np.random.choice([0, 1], p=[0.2, 0.8]),       # 80% like stories
        "enjoys_experiments": np.random.choice([0, 1], p=[0.9, 0.1]),
        "enjoys_debate": np.random.choice([0, 1], p=[0.1, 0.9]),        # 90% like debate
        "likes_programming": np.random.choice([0, 1], p=[0.9, 0.1]),
        "subject": "History"
    })

expanded_df = pd.concat([df, pd.DataFrame(history_rows)], ignore_index=True)
print("Expanded shape:", expanded_df.shape)
print("Class counts:\n", expanded_df["subject"].value_counts())
```
Output:
```
Expanded shape: (110, 7)
Class counts:
 Math          35
Literature    29
Biology       26
History       20
Name: subject, dtype: int64
```
Now you have a 110-student dataset spanning four subjects!

## Step-by-Step Student Instructions
1. Open Python in your project folder.
2. Run the synthetic expansion script above to inspect how pandas appends new rows.
3. Fit a new `DecisionTreeClassifier(max_depth=4)` on the expanded data.
4. Print `model.classes_` and confirm that `'History'` appears in the fitted classes:
   `['Biology' 'History' 'Literature' 'Math']`.
5. Check accuracy and print the new question path with `export_text()`.

## Expected Output or Observable Behaviour
When retrained on 4 classes:
- The tree adapts its splits to separate History from Literature (primarily leveraging debate and stories).
- The baseline accuracy drops from $38.9\%$ to $35/110 \approx 31.8\%$ because guessing becomes harder with 4 choices.

## Verification & Testing Methods
Verify that the model successfully predicts History on a prototypical history student:
```python
from sklearn.tree import DecisionTreeClassifier
X = expanded_df[["likes_numbers", "likes_living_things", "likes_stories", "enjoys_experiments", "enjoys_debate", "likes_programming"]]
y = expanded_df["subject"]
model = DecisionTreeClassifier(max_depth=4, random_state=42).fit(X, y)

hist_student = pd.DataFrame([{"likes_numbers": 0, "likes_living_things": 0, "likes_stories": 1, "enjoys_experiments": 0, "enjoys_debate": 1, "likes_programming": 0}])
print("Prediction for history student:", model.predict(hist_student)[0])
```

## Practical Exercises
- **Exercise 3.1**: If you added "Art" as a fifth subject, what two survey questions would you add to reliably separate Art from Literature and Biology?
- **Exercise 3.2**: Why might `max_depth=4` need to be increased to `max_depth=5` when expanding from 3 subjects to 6 subjects?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Correction |
|---|---|---|
| Adding a new subject without adding discriminatory features | Assuming the model can distinguish categories with identical features | If two classes share identical feature values, classification accuracy collapses. Always ensure new classes have distinct feature signatures. |
| Forgetting to update `QUESTIONS` when updating `FEATURES` | Appending a feature column but forgetting the conversational prompt | Always update `FEATURES` and `QUESTIONS` in parallel pairs. |

## Best Practices and Security Considerations
- **Class Balance in Data Collection**: When expanding datasets, ensure new categories have sufficient sample sizes (at least 20-30 rows) so the tree can induce reliable branches.
- **Backwards Compatibility**: Ensure that existing student profiles remain valid when adding new columns by filling missing historical values with sensible defaults.

## Summary & Key Takeaways
- Adding new subjects transforms the chatbot from a 3-class to an $N$-class classification engine.
- New academic disciplines require orthogonal, discriminatory survey questions to prevent class confusion.
- Pandas and scikit-learn dynamically adapt to new class labels in `df["subject"]`.
- As classes increase, tree depth may need to be increased to maintain expressiveness.

## Knowledge-check Questions and References
1. Why can a decision tree not distinguish two subjects that have identical feature answers?
2. What happened to baseline guessing accuracy when we expanded from 3 subjects to 4 subjects?
3. What two Python lists in `main.py` must be updated when adding a new survey question?

**References:**
- Provost, F., & Fawcett, T. (2013). *Data Science for Business.* Chapter 3: Introduction to Predictive Modeling.
- Scikit-learn documentation: *Multiclass and multioutput algorithms.* https://scikit-learn.org/stable/modules/multiclass.html
