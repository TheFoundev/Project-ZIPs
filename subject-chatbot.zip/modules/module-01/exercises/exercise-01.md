# Module 1 Exercises: Chatbot Paradigms & Architecture

## Exercise 1.1: Rule-Based vs. Machine Learning Chatbot Comparison
**Objective:** Contrast deterministic handcoded dialogue graphs with data-driven decision tree induction.
**Problem Statement:** You are tasked with analyzing the architectural trade-offs of building a subject recommendation chatbot using nested `if/else` logic versus training a `DecisionTreeClassifier`.

**Requirements:**
1. Detail the steps required to build a 6-question quiz using manual conditional statements.
2. Calculate the theoretical maximum number of distinct leaf states for 6 binary questions ($2^6$).
3. Explain how `DecisionTreeClassifier.fit()` eliminates the need to manually code these combinations.
4. Provide a 4-5 sentence summary contrasting the maintenance overhead of both approaches.

**Acceptance Criteria:**
- [ ] Correctly identifies $2^6 = 64$ potential leaf paths.
- [ ] Explains that manual coding requires human specification of all branches.
- [ ] Explains that machine learning automatically calculates the optimal split sequence from data.
- [ ] Notes that adding new survey questions to a decision tree requires retraining on updated data, whereas manual trees require rewriting all conditional branches.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes

---

## Exercise 1.2: Environment Verification & Headless Backend Check
**Objective:** Verify that `17_subject_chatbot` runs smoothly and produces output artifacts in a headless environment.
**Problem Statement:** Verify your runtime dependencies and confirm that `main.py` executes without raising display server errors.

**Requirements:**
1. Navigate to `beginner-projects-main/AI-ML Beginners/projects/17_subject_chatbot`.
2. Execute `python main.py`.
3. Check the exit status code of the script.
4. Verify that `outputs/chatbot_tree.png` and `outputs/rules.txt` are populated on disk.

**Acceptance Criteria:**
- [ ] Script terminates with exit code 0.
- [ ] Terminal prints accuracy (~78.3%) and the learned question path.
- [ ] `outputs/chatbot_tree.png` exists and is non-empty (>50 KB).
- [ ] `outputs/rules.txt` exists and contains the accuracy score and demo predictions.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes

---

## Exercise 1.3: Mapping Chatbot Prompts to Tree Logic
**Objective:** Translate a branch from `outputs/rules.txt` into a human conversational exchange.
**Problem Statement:** Take the following excerpt from `outputs/rules.txt`:
```
|--- likes_programming <= 0.50
|   |--- likes_stories <= 0.50
|   |   |--- enjoys_experiments >  0.50
|   |   |   |--- class: Biology
```
Map each conditional test to its corresponding question in `QUESTIONS` and write the conversational exchange.

**Requirements:**
1. Identify the question asked at the root node.
2. Identify whether `<=` represents "Yes" or "No".
3. Write the 3-question dialogue between the chatbot and the student.
4. State the final prediction delivered by the chatbot.

**Acceptance Criteria:**
- [ ] Correctly identifies question 1: "Do you like programming?"
- [ ] Identifies `<=` as "No" (0).
- [ ] Produces a coherent 3-turn dialogue.
- [ ] Ends with the prediction: "Biology".

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 1.4: Exploring the Multiclass Classification Target
**Objective:** Analyze the target classes and explain why regression is unsuitable for this problem.
**Problem Statement:** Inspect the target column in `data/subject_answers.csv`. Write a short Python script to display the distribution of classes and explain the mathematical difference between regression and classification.

**Requirements:**
1. Load `data/subject_answers.csv` with pandas.
2. Print `df['subject'].value_counts()`.
3. Explain why encoding "Math" as 1, "Biology" as 2, and "Literature" as 3 in a Linear Regression model would introduce false numerical relationships.

**Acceptance Criteria:**
- [ ] Script successfully prints the counts of Math, Biology, and Literature.
- [ ] Explains that regression assumes order and distance (e.g., $1 + 2 = 3$ implies Math + Biology = Literature, which is nonsensical).
- [ ] Concludes that multiclass classification with distinct categorical probabilities is the appropriate approach.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes
