# Lesson 01: Chatbot Foundations: History, Rule-Based Systems vs. Machine Learning

**Lesson ID:** lesson-01
**Module:** module-01
**Duration:** 20 minutes

## Purpose and Learning Objectives
The primary purpose of this lesson is to ground your understanding of conversational interfaces in computer science history and explore how machine learning fundamentally transformed automated dialogue. 

By the end of this lesson, you will be able to:
- Trace the historical development of conversational agents from ELIZA (1966) to modern expert systems.
- Explain the key architectural differences between hardcoded rule-based chatbots and data-driven machine learning classifiers.
- Identify the limitations of manual if-else decision graphs when scaling to complex domains.
- Articulate why decision trees provide an ideal bridge between human-readable rules and automated machine learning.

## Prerequisites
- Familiarity with basic programming logic (conditional branching: `if`, `elif`, `else`).
- High-level awareness of what machine learning is (learning patterns from data rather than hardcoding instructions).

## Concept Explanation
### The Genesis of Chatbots: Pattern Matching and Scripted Rules
The concept of a computer simulating human conversation dates back to the mid-1960s with Joseph Weizenbaum's **ELIZA**. ELIZA operated through simple pattern matching and keyword substitution. When a user typed a sentence containing the word "father", ELIZA might respond with a canned prompt such as: *"Tell me more about your father."* While ELIZA gave an astonishing illusion of intelligence, it possessed zero semantic comprehension and zero capacity to adapt or learn from experience.

In subsequent decades, the artificial intelligence community developed **Expert Systems** (such as MYCIN in medical diagnosis and DENDRAL in chemical analysis). These systems replaced naive pattern matching with rigorous inference engines powered by vast human-curated knowledge bases consisting of thousands of explicit `IF-THEN` rules.

### The Problem with Handcoded Rule Bases
While expert systems were effective in narrow, highly formalized technical domains, they suffered from significant structural bottlenecks:
1. **The Knowledge Acquisition Bottleneck**: Every single branch, edge case, and contradiction had to be manually anticipated and coded by human domain experts.
2. **Brittle Logic**: If an end-user answered outside anticipated parameters or exhibited ambiguous preferences, hardcoded rule systems frequently stalled or collapsed.
3. **Exponential Branching**: For a questionnaire with $N$ binary questions, there are $2^N$ potential distinct response combinations. Handcrafting individual dialogue pathways for complex state graphs quickly becomes impossible.

### Enter Machine Learning: Automated Rule Induction
Rather than forcing a human software engineer to manually construct dozens of nested `if-else` blocks, **Machine Learning (ML)** inverts the programming paradigm:
- **Traditional Programming**: Input Data + Handcoded Rules $\longrightarrow$ Output Answers.
- **Machine Learning**: Input Data + Known Output Answers $\longrightarrow$ **Learned Rules & Models**.

In this project, instead of writing an intricate decision script guessing whether a student prefers Math, Biology, or Literature, we collect empirical student survey profiles. We feed these profiles into a **Decision Tree Classifier**, which automatically calculates the mathematical optimal sequence of questions needed to deduce a student's favorite subject.

## Theoretical & Real-World Context
In industry, conversational AI spans a spectrum from rigid deterministic flowcharts (frequently used in bank ATM menus, IVR telephone systems, and e-commerce checkout bots) to probabilistic natural language processing systems (such as modern Large Language Models like Gemini and ChatGPT).

However, high-stakes decision-making domains—such as medical symptom triage, mortgage eligibility qualification, and educational course placement—require **explainability**. Neural networks and deep learning models act as "black boxes" whose internal reasoning cannot easily be audited. A **Decision Tree**, in contrast, induces an expert system directly from empirical training data while remaining $100\%$ transparent and human-auditable.

## Relevant Code (from main.py)
In `main.py`, lines 7-9 introduce the core philosophy of our project:
```python
# Lines 7-9 of main.py
A tiny decision-tree chatbot.  The tree is trained on example answer
profiles and then converted into a readable flowchart.
```

Later, lines 72-73 demonstrate how a machine learning model replaces hundreds of lines of conditional code:
```python
# Lines 72-73 of main.py
model = DecisionTreeClassifier(max_depth=4, random_state=42)
model.fit(X_train, y_train)
```

## Code Explanation & Line-by-Line Breakdown
- **Line 7-9 (Docstring Concept)**: Sets the expectation that the chatbot does not use opaque deep learning or brittle keyword matching; it builds a true decision flowchart from data.
- **Line 72 (`DecisionTreeClassifier`)**: We instantiate an algorithm that learns an optimal hierarchy of binary questions directly from empirical observation.
- **Line 73 (`model.fit(X_train, y_train)`)**: With a single method call, the algorithm inspects 67 training survey profiles and automatically computes the optimal decision rules that would take a human engineer days to calibrate.

## Worked Example
Suppose we want to build a diagnostic chatbot to determine if someone prefers Literature over Math.

**The Rule-Based Approach:**
```python
def rule_based_quiz(likes_numbers, likes_stories):
    if likes_numbers == 1 and likes_stories == 0:
        return "Math"
    elif likes_numbers == 0 and likes_stories == 1:
        return "Literature"
    elif likes_numbers == 1 and likes_stories == 1:
        return "Undecided / Needs more questions!"
    else:
        return "Unknown"
```
Notice how with just two questions, we already face ambiguity (what if the student likes both numbers and stories?).

**The Machine Learning Approach:**
The Decision Tree evaluates our 90 training examples and observes that among students who like both numbers and stories, those who also like programming overwhelmingly choose Math ($89\%$), whereas those who enjoy debate choose Literature ($86\%$). The algorithm automatically prioritizes the question with the highest discriminatory power without manual intervention.

## Step-by-Step Student Instructions
1. Open your terminal and navigate to the project directory.
2. Inspect the project header in `main.py` using `head -n 15 main.py`.
3. Reflect on the difference between writing nested `if` statements and fitting a model with `model.fit()`.
4. Note down three real-world customer service chatbots you have interacted with. Identify which felt like brittle rule-based trees and which felt like flexible machine learning engines.

## Expected Output or Observable Behaviour
When executing `python main.py`, notice how instantly the script runs. Within milliseconds, `scikit-learn` ingests the historical dataset, evaluates all feature split combinations, and displays the learned question path:
```
============================================================
THE FAVORITE-SUBJECT CHATBOT
============================================================
Accuracy: 78.3%
...
Learned question path:

|--- likes_programming <= 0.50
|   |--- likes_stories <= 0.50
...
```
The tree structure output is an exact visual representation of the rules the model induced.

## Verification & Testing Methods
To verify your conceptual grasp of this lesson:
- Run `python -c "import sklearn; print(sklearn.__version__)"` to ensure your Python environment is ready.
- Verify that if you had 6 binary questions, a complete manual brute-force decision tree would require evaluating $2^6 = 64$ distinct leaf branches.

## Practical Exercises
- **Exercise 1.1**: Write a short Python function with 3 manual `if/else` checks simulating a basic quiz. Note how tedious it is to handle conflicting inputs.
- **Exercise 1.2**: Compare ELIZA's keyword matching with a Decision Tree's quantitative probability splits. List two advantages of each approach.

## Common Mistakes and Debugging
| Mistake | Why It Happens | Correction |
|---|---|---|
| Assuming all chatbots require Large Language Models (LLMs) | Modern media focuses exclusively on generative AI | Remember that diagnostic, deterministic, and triage bots are often best powered by Decision Trees due to zero hallucinations and 100% auditability. |
| Thinking a Decision Tree is just handcoded `if/else` statements | The output looks like nested `if` statements | The syntax is conditional, but the *structure and thresholds are learned automatically from data*, not written by hand. |
| Believing rule-based bots can learn from user answers | Confusing dialogue memory with model training | Rule-based bots reset each conversation; machine learning models update their parameters when retrained on new historical data. |

## Best Practices and Security Considerations
- **Determinism and Auditability**: In enterprise environments, decision trees ensure compliance with regulatory standards (e.g., GDPR's "Right to Explanation") because every classification decision can be traced back to explicit numerical branches.
- **Guarding Against Hallucination**: Generative AI chatbots can invent non-existent facts. A classification-tree chatbot will strictly predict one of the validated target categories (`Math`, `Biology`, `Literature`).

## Summary & Key Takeaways
- Chatbots originated with simple pattern-matching scripts (ELIZA) and evolved through expert systems (manual IF-THEN rule bases).
- Manual rule creation suffers from the knowledge acquisition bottleneck and fails to handle conflicting human survey preferences.
- Supervised machine learning algorithms (like Decision Trees) induce optimal decision rules directly from historical data.
- The Subject Chatbot combines the explainability of expert systems with the automated pattern recognition of modern machine learning.

## Knowledge-check Questions and References
1. Why does manual rule creation become intractable as the number of survey questions grows?
2. In what way does `model.fit()` invert traditional software programming?
3. What is the key advantage of a decision tree classifier over an opaque neural network in a diagnostic chatbot?

**References:**
- Weizenbaum, J. (1966). *ELIZA—a computer program for the study of natural language communication between man and machine.* Communications of the ACM, 9(1), 36-45.
- Russell, S., & Norvig, P. *Artificial Intelligence: A Modern Approach.* Chapter 18: Learning from Examples.
