# Lesson 03: Decision Trees as Chatbots: Translating Features and Splits into Dialogue

**Lesson ID:** lesson-03
**Module:** module-01
**Duration:** 20 minutes

## Purpose and Learning Objectives
This lesson bridges machine learning mathematics and conversational user experience (UX), showing how the nodes, branches, and leaves of a decision tree directly translate into questions, answers, and conclusions in a chatbot.

By the end of this lesson, you will be able to:
- Map the root node, internal decision nodes, branches, and leaf nodes of a decision tree to chatbot conversational elements.
- Understand how tree thresholds on binary data ($\le 0.50$ vs. $> 0.50$) evaluate "No" vs. "Yes" user answers.
- Explain how a decision tree dynamically short-circuits irrelevant questions compared to a static survey.
- Contrast the user experience of batch questionnaire forms with conversational interview trees.

## Prerequisites
- Completion of Lessons 01 and 02.
- Familiarity with the visual representation of tree diagrams (nodes and branches).

## Concept Explanation
### The Anatomy of a Decision Tree
A decision tree is a hierarchical model composed of three core components:
1. **Root Node**: The very first decision point at the top of the tree, applied to all incoming data.
2. **Internal Nodes**: Subsequent decision points that evaluate a condition on a specific feature.
3. **Leaf Nodes (Terminal Nodes)**: The end points of paths where no further splits occur, containing the final predicted class.

```
       [Root Node: Do you like programming?]
                  /              \
             No (<= 0.50)      Yes (> 0.50)
                /                  \
      [Internal Node]         [Internal Node]
    Do you like stories?     Do you like numbers?
        /          \             /          \
    No (<= 0.5)  Yes (> 0.5)  No (<= 0.5)  Yes (> 0.5)
      /              \           /              \
 [Leaf: Biology] [Leaf: Lit] [Leaf: Bio]   [Leaf: Math]
```

### The Conversational Equivalence
Every visual and mathematical component of a decision tree directly mirrors an element of human conversation:
- **Feature Evaluated at a Node** $\Longleftrightarrow$ **A Specific Question Asked by the Chatbot**.
- **The Inequality Test ($x_i \le 0.50$)** $\Longleftrightarrow$ **The User Replying "No" ($0$)**.
- **The Inequality Test ($x_i > 0.50$)** $\Longleftrightarrow$ **The User Replying "Yes" ($1$)**.
- **Traversing a Branch** $\Longleftrightarrow$ **Routing to the Next Conversational Step**.
- **Reaching a Leaf Node** $\Longleftrightarrow$ **The Chatbot Delivering its Final Diagnosis/Guess**.

### Why $\le 0.50$ is the Universal Split for Binary Features
Because our survey questions are encoded as binary numbers ($0$ for No, $1$ for Yes), any decision tree algorithm splitting these numbers will choose the midpoint threshold:
$$\text{Threshold} = \frac{0 + 1}{2} = 0.50$$
- If answer $\le 0.50$, the answer is mathematically $0$ ("No").
- If answer $> 0.50$, the answer is mathematically $1$ ("Yes").

Thus, whenever you inspect scikit-learn's exported tree rules and see:
`|--- likes_programming <= 0.50`
It directly means: *"If the user said No to programming..."*

## Theoretical & Real-World Context
In conventional web forms, every user must fill out all 20 or 50 questions regardless of their earlier answers. For example, a student who says they despise computers and mathematics is still forced to answer detailed questions about Python syntax and calculus!

In contrast, an adaptive conversational chatbot powered by a decision tree can **prune unnecessary questions**:
- If a user reveals strong scientific preferences and zero interest in literature, the tree can bypass poetry and essay questions entirely, focusing directly on laboratory and biology topics.
- This creates an efficient, engaging user experience, often cutting questionnaire fatigue in half.

## Relevant Code (from main.py)
In `main.py`, lines 30-45 explicitly define the pairing between the machine learning features and the conversational questions:
```python
# Lines 30-45 of main.py
FEATURES = [
    "likes_numbers",
    "likes_living_things",
    "likes_stories",
    "enjoys_experiments",
    "enjoys_debate",
    "likes_programming",
]
QUESTIONS = [
    "Do you enjoy working with numbers?",
    "Do you like learning about living things?",
    "Do you enjoy stories and writing?",
    "Do you like running experiments?",
    "Do you enjoy debating ideas?",
    "Do you like programming?",
]
```

Notice how index 0 of `FEATURES` (`"likes_numbers"`) corresponds directly to index 0 of `QUESTIONS` (`"Do you enjoy working with numbers?"`).

## Code Explanation & Line-by-Line Breakdown
- **Lines 30-37 (`FEATURES`)**: Defines the feature column names matching `data/subject_answers.csv`.
- **Lines 38-45 (`QUESTIONS`)**: Provides human-friendly natural language translations for each feature.
- **The 1-to-1 Mapping**: By preserving identical ordering, `dict(zip(FEATURES, answers))` allows the script to map user input directly to a valid DataFrame row.

## Worked Example
Look at this excerpt from `outputs/rules.txt` generated by `main.py`:
```
|--- likes_programming <= 0.50
|   |--- likes_stories >  0.50
|   |   |--- likes_living_things <= 0.50
|   |   |   |--- class: Literature
```

Let's translate this directly into conversational dialogue:
- **Chatbot**: "Do you like programming?"
- **User**: "No." (<= 0.50)
- **Chatbot**: "Do you enjoy stories and writing?"
- **User**: "Yes!" (> 0.50)
- **Chatbot**: "Do you like learning about living things?"
- **User**: "No." (<= 0.50)
- **Chatbot**: *"I guess your favorite subject is Literature!"*

The formal machine learning rule translates into natural human conversation.

## Step-by-Step Student Instructions
1. Inspect the exported decision tree rules in `outputs/rules.txt` (or run `python main.py` to generate it).
2. Choose one path from the root node to any leaf labeled `class: Biology`.
3. Transcribe that exact path into a 3-turn conversational script between a student and a guidance counselor.
4. Verify that every branch condition ($\le 0.50$ or $> 0.50$) matches your script's "No" or "Yes" responses.

## Expected Output or Observable Behaviour
When observing the tree visualization (`outputs/chatbot_tree.png`), you will see colored rectangular boxes. Each box displays:
- The question being tested (e.g., `likes_programming <= 0.5`)
- The Gini impurity of the node
- The total number of student samples reaching that node
- The distribution of classes (`values = [biology_count, lit_count, math_count]`)
- The predominant class label

## Verification & Testing Methods
To verify that feature mapping works correctly in Python, execute:
```python
features = ["likes_numbers", "likes_stories"]
answers = [1, 0]
profile_dict = dict(zip(features, answers))
print(profile_dict)
```
Expected output:
```
{'likes_numbers': 1, 'likes_stories': 0}
```

## Practical Exercises
- **Exercise 3.1**: Take the path leading to `class: Math` when `likes_programming > 0.50` and `likes_numbers > 0.50`. Write out the corresponding dialogue.
- **Exercise 3.2**: Why does scikit-learn use `0.50` as the split threshold rather than `0.0` or `1.0`?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Correction |
|---|---|---|
| Reversing the meaning of `<=` and `>` | Associating `<=` with "True" or "Yes" | In binary encoding, $0$ is False/No and $1$ is True/Yes. Since $0 \le 0.50$, the left branch (`<= 0.50`) is always **No**. |
| Assuming the chatbot asks every question in the exact list order | Believing the tree must follow the order of `QUESTIONS` | The decision tree asks questions in order of statistical importance (highest information gain first), not array index order. |
| Forgetting that leaf nodes don't ask questions | Expecting a final question at a leaf | Leaf nodes are answers, not questions. They contain the final class prediction. |

## Best Practices and Security Considerations
- **Transparent Decision Auditing**: Using a decision tree ensures that when a user asks "Why did you guess Literature?", the chatbot can answer with absolute fidelity: *"Because you answered No to programming, Yes to stories, and No to living things."*
- **Conversational Fairness**: Verify that the questions selected by the tree do not unfairly disadvantage users with interdisciplinary interests.

## Summary & Key Takeaways
- Decision tree nodes map directly to chatbot questions; branches map to user replies ("No" vs. "Yes"); leaves map to diagnoses.
- A numerical split at $\le 0.50$ neatly partitions binary $0$ ("No") and $1$ ("Yes") responses.
- Decision trees prioritize the most informative questions first, enabling efficient conversational short-circuiting.
- The tree structure provides an auditable, transparent conversational flow that eliminates AI hallucination.

## Knowledge-check Questions and References
1. If a decision tree node tests `enjoys_debate <= 0.50`, which user response leads to the right branch?
2. What conversational element does a leaf node represent?
3. How does a decision tree chatbot avoid asking redundant questions?

**References:**
- Quinlan, J. R. (1986). *Induction of decision trees.* Machine Learning, 1(1), 81-106.
- Hastie, T., Tibshirani, R., & Friedman, J. *The Elements of Statistical Learning.* Chapter 9: Additive Models, Trees, and Related Methods.
