# Lesson 02: Classification Engines: From Static Q&A to Data-Driven Decisions

**Lesson ID:** lesson-02
**Module:** module-01
**Duration:** 20 minutes

## Purpose and Learning Objectives
This lesson explains the mechanics of classification engines, transforming static question-and-answer interactions into a formal mathematical classification problem.

By the end of this lesson, you will be able to:
- Define what a classification engine is in the context of supervised learning.
- Distinguish multiclass classification from binary classification.
- Map conversational user responses to mathematical feature vectors ($X$).
- Describe how the model assigns a discrete categorical target ($y$) based on input features.

## Prerequisites
- Completion of Lesson 01.
- Understanding of independent variables (features) and dependent variables (targets).

## Concept Explanation
### What is a Classification Engine?
In machine learning, a **classification engine** is an algorithm that takes a set of input features describing an entity and assigns that entity to one of several predefined categories or classes.

While a regression engine predicts continuous numerical quantities (such as predicting house prices in dollars or cups of lemonade sold based on temperature), a classification engine predicts discrete group memberships:
- Is this email spam or not spam? (Binary classification)
- Is this handwritten digit a 0, 1, 2, ..., or 9? (Multiclass classification)
- Is this student's preferred subject Math, Biology, or Literature? (Multiclass classification)

### Translating Conversational Dialogue into Feature Vectors
When a human interacts with a chatbot, they communicate via natural language phrases, gestures, or button clicks. To process this interaction mathematically, the chatbot must convert user dialogue into a **feature vector**:
$$\mathbf{x} = [x_1, x_2, x_3, x_4, x_5, x_6]$$

In our Subject Chatbot, each question corresponds directly to an element of the feature vector:
1. "Do you enjoy working with numbers?" $\longrightarrow x_1 \in \{0, 1\}$
2. "Do you like learning about living things?" $\longrightarrow x_2 \in \{0, 1\}$
3. "Do you enjoy stories and writing?" $\longrightarrow x_3 \in \{0, 1\}$
4. "Do you like running experiments?" $\longrightarrow x_4 \in \{0, 1\}$
5. "Do you enjoy debating ideas?" $\longrightarrow x_5 \in \{0, 1\}$
6. "Do you like programming?" $\longrightarrow x_6 \in \{0, 1\}$

If a user answers "Yes" to numbers and programming, but "No" to the other four questions, their conversational profile is encoded as the mathematical vector:
$$\mathbf{x}_{user} = [1, 0, 0, 0, 0, 1]$$

### The Classification Mapping Function
The trained machine learning model acts as a mapping function $f$:
$$f: \mathcal{X} \longrightarrow \mathcal{Y}$$
where $\mathcal{X} = \{0, 1\}^6$ is the 6-dimensional binary feature space, and $\mathcal{Y} = \{\text{Math}, \text{Biology}, \text{Literature}\}$ is the target label set.

The classification engine computes $f(\mathbf{x}_{user})$ and outputs the predicted subject class label.

## Theoretical & Real-World Context
Classification engines drive modern recommender systems and interactive triage bots:
- **E-Commerce Recommendation**: "Quiz funnels" where customers answer 5 styling questions to receive personalized clothing suggestions.
- **Medical Triage**: Automated intake bots asking patients about symptoms (fever, cough, duration) to route them to urgent care, general practice, or home rest.
- **Streaming Media**: Profiling onboarding questionnaires (selecting favorite genres) to initialize recommendation algorithms.

In all these scenarios, conversation is simply the user-friendly interface layer sitting on top of an underlying classification engine.

## Relevant Code (from main.py)
In `main.py`, lines 65-67 illustrate the separation between the feature space ($X$) and the classification target ($y$):
```python
# Lines 65-67 of main.py
X = df[FEATURES]
y = df["subject"]
```

Later, lines 74-75 demonstrate how the classification engine makes predictions on unseen test feature vectors:
```python
# Lines 74-75 of main.py
predictions = model.predict(X_test)
accuracy = accuracy_score(y_test, predictions)
```

## Code Explanation & Line-by-Line Breakdown
- **Line 65 (`X = df[FEATURES]`)**: Extracts a 2D matrix of shape $(N, 6)$ where each row is a student's answer vector across the 6 survey questions.
- **Line 66 (`y = df["subject"]`)**: Isolates the 1D target vector of string categories (`Math`, `Biology`, `Literature`).
- **Line 74 (`predictions = model.predict(X_test)`)**: The classification engine processes the test feature vectors and outputs predicted subject labels.
- **Line 75 (`accuracy_score(y_test, predictions)`)**: Evaluates the engine by comparing predicted labels against the actual historical labels.

## Worked Example
Let us trace an incoming profile through our classification engine:
- Input Feature Vector: `likes_numbers=1, likes_living_things=0, likes_stories=0, enjoys_experiments=1, enjoys_debate=0, likes_programming=1`
- Vector Representation: `[1, 0, 0, 1, 0, 1]`

When we pass this vector to `model.predict()`:
1. The engine checks feature 5 (`likes_programming`): It is $1$ ($> 0.50$).
2. It checks feature 0 (`likes_numbers`): It is $1$ ($> 0.50$).
3. It checks feature 1 (`likes_living_things`): It is $0$ ($\le 0.50$).
4. It arrives at a terminal leaf node labeled **`Math`**.
The classification engine outputs `"Math"`.

## Step-by-Step Student Instructions
1. Open Python in interactive mode by typing `python` in your terminal.
2. Import pandas: `import pandas as pd`.
3. Create a mock single-student profile:
   ```python
   profile = pd.DataFrame([{"likes_numbers": 1, "likes_living_things": 0, "likes_stories": 0, "enjoys_experiments": 1, "enjoys_debate": 0, "likes_programming": 1}])
   print(profile.shape)
   ```
4. Confirm that the shape is `(1, 6)` — one sample with 6 input features.

## Expected Output or Observable Behaviour
When checking `profile.shape`, you will observe:
```python
(1, 6)
```
This confirms that the chatbot treats individual conversations as single rows within a standard machine learning feature matrix.

## Verification & Testing Methods
Run the following verification snippet to see all unique target classes in the dataset:
```python
import pandas as pd
df = pd.read_csv("data/subject_answers.csv")
print("Target classes:", df["subject"].unique())
print("Number of features:", len(df.columns) - 1)
```
Expected output:
```
Target classes: ['Math' 'Biology' 'Literature']
Number of features: 6
```

## Practical Exercises
- **Exercise 2.1**: Explain in writing why guessing a favorite subject is a multiclass classification task rather than a binary classification or regression task.
- **Exercise 2.2**: If we added a fourth subject category (e.g., "History"), how would the target set $\mathcal{Y}$ change? Does the input feature dimensionality necessarily have to change?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Correction |
|---|---|---|
| Treating the target as continuous numbers | Confusing classification with regression | Academic subjects are distinct qualitative categories. Use classification metrics, never Mean Squared Error. |
| Passing a 1D list directly to `model.predict()` | Forgetting scikit-learn's 2D input requirement | `model.predict()` requires a 2D array or DataFrame of shape `(n_samples, n_features)`. Wrap single samples in a list of lists or DataFrame. |
| Mismatching feature column names | Permuting the order of survey answers | Always bind features using the canonical `FEATURES` list so the column indices match the model's training matrix. |

## Best Practices and Security Considerations
- **Consistent Feature Ordering**: When extracting features from user input, always enforce explicit column headers matching the training data schema to prevent silent feature misalignment.
- **Handling Out-of-Vocabulary Responses**: Always sanitize user input so that only valid feature encodings ($0$ or $1$) reach the inference engine.

## Summary & Key Takeaways
- A classification engine maps multidimensional feature vectors ($X$) to discrete categorical labels ($y$).
- The Subject Chatbot treats a 6-question dialogue as an ingestion pipeline that populates a 6-element binary feature vector.
- The machine learning model acts as the reasoning core of the chatbot, replacing ad-hoc logic with mathematical optimization.
- Scikit-learn's `predict()` method evaluates user profiles against learned decision boundaries.

## Knowledge-check Questions and References
1. What defines a machine learning task as "multiclass classification"?
2. What are the dimensions of the feature matrix $X$ if 90 students answer 6 questions?
3. Why must conversational user responses be converted to numbers before reaching the classification engine?

**References:**
- Bishop, C. M. (2006). *Pattern Recognition and Machine Learning.* Chapter 4: Linear Models for Classification.
- Scikit-learn documentation: *Supervised learning - Classification.* https://scikit-learn.org/stable/supervised_learning.html
