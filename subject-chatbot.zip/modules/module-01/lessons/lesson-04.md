# Lesson 04: Project Architecture and Setup: Exploring 17_subject_chatbot and Environment

**Lesson ID:** lesson-04
**Module:** module-01
**Duration:** 20 minutes

## Purpose and Learning Objectives
This lesson guides you through the repository structure, code organization, and execution environment of the **Subject Chatbot** project (`17_subject_chatbot`).

By the end of this lesson, you will be able to:
- Navigate the filesystem layout of `17_subject_chatbot`.
- Understand the role of `matplotlib.use("Agg")` in headless terminal environments.
- Explain the role of `pathlib.Path` in creating portable, operating-system-independent file paths.
- Execute `main.py` in default demo mode and inspect generated output artifacts.

## Prerequisites
- Completion of Lessons 01, 02, and 03.
- Access to a Linux terminal with Python installed.

## Concept Explanation
### Project Directory Structure
The Subject Chatbot project is designed with a clean, decoupled architecture:
```
17_subject_chatbot/
├── data/
│   └── subject_answers.csv     # Historical survey profiles (90 samples)
├── outputs/                    # Output directory created at runtime
│   ├── chatbot_tree.png        # Graphical tree diagram (15x8 inches, 150 dpi)
│   └── rules.txt               # Plain-text rules, metrics, and demo predictions
├── main.py                     # Primary pipeline script containing all logic
└── README.md                   # Quickstart documentation
```

### Headless Rendering with Matplotlib Agg
In standard desktop Python scripts, calling `plt.show()` opens a GUI window displaying the plot. However, in server environments, remote SSH sessions, continuous integration pipelines, or headless containers, no graphical display server ($X11$ or Wayland) is running.

Attempting to open a GUI window in a headless environment raises a fatal error: `_tkinter.TclError: no display name and no $DISPLAY environment variable`.

To prevent this, `main.py` explicitly selects the **Agg** backend:
```python
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
```
The `Agg` (Anti-Grain Geometry) backend renders raster images directly to file buffers in memory without requiring any graphical screen.

### Robust Filepaths with pathlib.Path
Hardcoding paths as strings like `"data/subject_answers.csv"` or using backslashes (`"data\subject_answers.csv"`) makes code brittle across operating systems. Windows uses backslashes, while Linux and macOS use forward slashes. Furthermore, running the script from a different current working directory breaks relative string paths.

`main.py` solves this using Python's standard library `pathlib.Path`:
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)
```
- `__file__`: Points to the exact filesystem location of `main.py`.
- `.resolve().parent`: Obtains the canonical directory containing `main.py`.
- `/`: Overloaded operator that constructs valid platform-specific path objects.
- `exist_ok=True`: Creates `outputs/` if it does not already exist, preventing `FileExistsError`.

## Theoretical & Real-World Context
Production machine learning services operate almost exclusively in headless environments (e.g., Docker containers on AWS, Google Cloud Run, or Kubernetes clusters). Engineering scripts to execute reliably without graphical dependencies and with robust filesystem resolution is a vital software engineering competency.

## Relevant Code (from main.py)
In `main.py`, lines 16-28 establish this robust setup:
```python
# Lines 16-28 of main.py
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, export_text, plot_tree

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)
```

## Code Explanation & Line-by-Line Breakdown
- **Line 18 (`matplotlib.use("Agg")`)**: Must be executed **before** importing `plt` to lock in the headless raster engine.
- **Lines 20-23**: Imports standard data science tools (`pandas`, `scikit-learn` metrics, model selection, and tree functions).
- **Line 25 (`BASE = Path(__file__).resolve().parent`)**: Establishes the project root dynamically.
- **Line 26 (`DATA = BASE / "data"`)**: Points cleanly to the data folder.
- **Line 27 (`OUT = BASE / "outputs"`)**: Points cleanly to the output folder.
- **Line 28 (`OUT.mkdir(exist_ok=True)`)**: Safely provisions the destination directory.

## Worked Example
Suppose you run `main.py` from your home directory:
```bash
cd ~
python /home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML\ Beginners/projects/17_subject_chatbot/main.py
```
Because `BASE` uses `Path(__file__).resolve().parent`, the script correctly finds `DATA / "subject_answers.csv"` in the project folder, rather than looking for a non-existent `~/data/` folder in your home directory!

## Step-by-Step Student Instructions
1. Open your terminal.
2. Change directory into the project folder:
   ```bash
   cd beginner-projects-main/AI-ML\ Beginners/projects/17_subject_chatbot
   ```
3. Run `python main.py`.
4. Check that the `outputs/` directory was created:
   ```bash
   ls -la outputs/
   ```
5. Inspect `outputs/rules.txt` using `cat outputs/rules.txt | head -n 20`.

## Expected Output or Observable Behaviour
Running `ls -la outputs/` will show:
```
total 144
-rw-r--r-- 1 aziz aziz 140000 Oct 27 19:11 chatbot_tree.png
-rw-r--r-- 1 aziz aziz   1900 Oct 27 19:11 rules.txt
```
This confirms both the graphic flowchart and the serialized text rules were successfully written to disk.

## Verification & Testing Methods
Verify that the `outputs/rules.txt` file starts with the calculated accuracy:
```bash
python -c "with open('outputs/rules.txt') as f: print(f.readline())"
```
Output:
```
accuracy: 0.7826
```

## Practical Exercises
- **Exercise 4.1**: In an interactive Python session, print `Path(__file__).resolve().parent` and observe the exact absolute path of your script.
- **Exercise 4.2**: Modify `matplotlib.use("Agg")` temporarily to a comment, and observe what happens if you attempt to use graphical commands in a non-GUI terminal.

## Common Mistakes and Debugging
| Mistake | Why It Happens | Correction |
|---|---|---|
| Importing `matplotlib.pyplot` before calling `matplotlib.use("Agg")` | The backend is locked upon pyplot import | Always invoke `matplotlib.use("Agg")` immediately after `import matplotlib` and before `import matplotlib.pyplot as plt`. |
| Hardcoding string paths like `"outputs/rules.txt"` | Breaks when running the script from other working directories | Always construct paths using `OUT / "rules.txt"`. |
| Forgetting `exist_ok=True` on `mkdir()` | Calling `mkdir()` on an existing directory raises `FileExistsError` | Always pass `exist_ok=True` when provisioning output folders. |

## Best Practices and Security Considerations
- **Non-Interactive Backend**: Locking headless backends prevents GUI thread hangs on automated cloud build runners.
- **Path Sanitization**: `pathlib.Path` prevents path traversal vulnerabilities by resolving canonical filesystem locations.

## Summary & Key Takeaways
- `17_subject_chatbot` follows standard ML project layout: `data/`, `outputs/`, and `main.py`.
- `matplotlib.use("Agg")` enables error-free plot generation in headless server environments.
- `pathlib.Path` ensures robust, OS-agnostic path management.
- Executing `python main.py` automatically compiles the model, evaluates metrics, and generates visual and textual artifacts.

## Knowledge-check Questions and References
1. Why does calling `plt.show()` fail in a remote headless server?
2. What does `Path(__file__).resolve().parent` evaluate to?
3. What error does `exist_ok=True` prevent when calling `mkdir()`?

**References:**
- Matplotlib documentation: *What is a backend?* https://matplotlib.org/stable/users/explain/backends.html
- Python standard library: *pathlib — Object-oriented filesystem paths.* https://docs.python.org/3/library/pathlib.html
