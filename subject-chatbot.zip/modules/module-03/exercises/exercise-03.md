# Module 3 Exercises: Decision Tree Splitting & Rule Construction

## Exercise 3.1: Gini Impurity Manual Calculation
**Objective:** Calculate Gini impurity by hand for candidate node distributions.
**Problem Statement:** You are evaluating a node in a decision tree that classifies students into Math, Biology, and Literature. Compute the Gini impurity for the following three hypothetical student distributions.

**Requirements:**
1. Node A: 20 Math, 0 Biology, 0 Literature.
2. Node B: 10 Math, 10 Biology, 10 Literature.
3. Node C: 14 Biology, 6 Literature, 0 Math.
4. Show your step-by-step calculations for each node using $I_G = 1 - \sum p_i^2$.

**Acceptance Criteria:**
- [ ] Node A correctly calculated as $0.0$.
- [ ] Node B correctly calculated as $1 - 3(1/9) \approx 0.667$.
- [ ] Node C correctly calculated as $1 - [(14/20)^2 + (6/20)^2] = 1 - [0.49 + 0.09] = 0.420$.
- [ ] Explains which node is purest and why.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes

---

## Exercise 3.2: Interpreting Thresholds and Branch Rules
**Objective:** Decipher scikit-learn's exported text rules into plain English.
**Problem Statement:** Take the following snippet from `outputs/rules.txt`:
```
|--- likes_programming >  0.50
|   |--- likes_numbers <= 0.50
|   |   |--- enjoys_debate >  0.50
|   |   |   |--- class: Literature
```

**Requirements:**
1. State the three questions tested along this branch.
2. State the user's answers to each question (Yes or No).
3. Explain why the model might predict Literature for a student who likes programming but dislikes numbers and loves debate.

**Acceptance Criteria:**
- [ ] Identifies: `likes_programming` (Yes), `likes_numbers` (No), `enjoys_debate` (Yes).
- [ ] Notes that strong debate affinity points toward humanities despite coding interest.
- [ ] Written explanation is clear and logical.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes

---

## Exercise 3.3: Evaluating the Impact of max_depth
**Objective:** Experiment with different `max_depth` hyperparameter values and analyze the overfitting curve.
**Problem Statement:** Write a Python script to train a `DecisionTreeClassifier` on the project dataset using `max_depth` values of 1, 2, 3, 4, 5, 6, and `None`.

**Requirements:**
1. Load `data/subject_answers.csv` and split with `test_size=0.25, random_state=42, stratify=y`.
2. Iterate through `[1, 2, 3, 4, 5, 6, None]`.
3. Record both training accuracy and test accuracy for each depth.
4. Print the results in a formatted table.
5. Identify the exact depth where test accuracy begins to plateau or degrade (overfitting).

**Acceptance Criteria:**
- [ ] Script runs and outputs table of depths vs. train/test accuracies.
- [ ] Confirms `max_depth=4` achieves optimal test accuracy (~78.3%).
- [ ] Identifies that deeper trees achieve higher training accuracy but lower test accuracy.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 20 minutes

---

## Exercise 3.4: Designing a Synthetic Persona Verification Suite
**Objective:** Construct a custom testing suite of student personas.
**Problem Statement:** Expand the 3 demo profiles in `main.py` into a 6-persona comprehensive validation suite.

**Requirements:**
1. Create a DataFrame `custom_profiles` with 6 rows representing diverse student profiles.
2. Include at least one student who answers Yes to all 6 questions and one who answers No to all 6 questions.
3. Run `model.predict(custom_profiles)` and `model.predict_proba(custom_profiles)`.
4. Print each persona's predicted subject and prediction confidence percentage.

**Acceptance Criteria:**
- [ ] DataFrame has shape `(6, 6)` with valid column headers.
- [ ] Predictions and confidence scores are cleanly printed.
- [ ] Analyzes how the model handles contradictory or extreme answers.

**Difficulty:** Advanced  
**Estimated Completion Time:** 20 minutes
