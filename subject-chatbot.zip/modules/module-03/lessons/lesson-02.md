# Lesson 02: Splitting Criteria: Gini Impurity, Information Gain, and Thresholds (<= 0.50)

**Lesson ID:** lesson-02
**Module:** module-03
**Duration:** 20 minutes

## Purpose and Learning Objectives
This lesson explains the mathematical engine driving decision trees: **Gini Impurity** and **Information Gain**.

By the end of this lesson, you will be able to:
- State the mathematical formula for Gini Impurity.
- Calculate Gini Impurity for a pure node, an evenly split node, and real-world student clusters.
- Explain how the algorithm selects the optimal feature split by maximizing Information Gain.
- Understand why 0.50 is the optimal threshold for all binary splits in our survey.

## Prerequisites
- Completion of Lesson 01.
- Basic arithmetic (squaring fractions and subtracting from 1).

## Concept Explanation
### What is Node Purity?
Imagine you have a basket of 30 students:
- If all 30 students prefer Math, the basket is **100% pure**. A chatbot reaching this node needs to ask zero further questions—it can confidently declare "Math!"
- If the basket contains 10 Math, 10 Biology, and 10 Literature students, the basket is in **total disorder (maximum impurity)**. The chatbot has no idea which subject to guess.

A decision tree's entire goal during training is to transform impure parent nodes into pure child nodes.

### The Mathematical Formula for Gini Impurity
For a node containing samples across $K$ classes, the **Gini Impurity** $I_G$ is defined as:
$$I_G(p) = 1 - \sum_{i=1}^{K} p_i^2$$
where $p_i$ is the proportion (probability) of class $i$ present in the node.

Let us evaluate the two extreme cases for our 3-class problem ($K=3$):
1. **Case 1: Perfectly Pure Node** (e.g., all 20 students are Math):
   - $p_{\text{Math}} = 1.0, p_{\text{Bio}} = 0.0, p_{\text{Lit}} = 0.0$
   - $I_G = 1 - (1.0^2 + 0.0^2 + 0.0^2) = 1 - 1.0 = \mathbf{0.0}$
   - **A Gini score of 0.0 represents perfect purity!**
2. **Case 2: Perfectly Impure Node** (equal 1/3 split across all three classes):
   - $p_{\text{Math}} = \frac{1}{3}, p_{\text{Bio}} = \frac{1}{3}, p_{\text{Lit}} = \frac{1}{3}$
   - $I_G = 1 - \left(\left(\frac{1}{3}\right)^2 + \left(\frac{1}{3}\right)^2 + \left(\frac{1}{3}\right)^2\right) = 1 - \left(\frac{1}{9} + \frac{1}{9} + \frac{1}{9}\right) = 1 - \frac{3}{9} = 1 - 0.333 = \mathbf{0.667}$
   - **For a 3-class problem, the maximum possible Gini impurity is approximately 0.667.**

### Information Gain: Choosing the Winning Split
To choose which question to ask at any node, scikit-learn computes the **weighted impurity of the children** for each candidate question:
$$I_{G, \text{split}} = \frac{N_{\text{left}}}{N_{\text{parent}}} I_G(\text{left}) + \frac{N_{\text{right}}}{N_{\text{parent}}} I_G(\text{right})$$

The **Information Gain** (or impurity reduction) is:
$$\Delta I_G = I_G(\text{parent}) - I_{G, \text{split}}$$

The algorithm tests all 6 features and selects the feature that yields the **largest Information Gain** (the greatest drop in impurity).

## Theoretical & Real-World Context
Two primary impurity criteria dominate machine learning:
1. **Gini Impurity** (default in scikit-learn's CART implementation): Computes quickly because it only requires squaring numbers.
2. **Entropy / Information Gain** (used in ID3 and C4.5): Uses logarithmic functions ($- \sum p_i \log_2 p_i$), which is computationally slightly slower but produces nearly identical tree structures in practice.

Scikit-learn defaults to `criterion="gini"` because it executes with maximum computational efficiency.

## Relevant Code (from main.py)
In `main.py`, line 72 instantiates the decision tree:
```python
# Line 72 of main.py
model = DecisionTreeClassifier(max_depth=4, random_state=42)
```
Notice that we did not specify the `criterion` parameter. By default, scikit-learn sets `criterion="gini"`.

## Code Explanation & Line-by-Line Breakdown
- When `model.fit(X_train, y_train)` is called, scikit-learn calculates Gini impurity for all 6 features across all 67 training samples.
- The feature `likes_programming` provides the largest reduction in Gini impurity, earning it the honor of becoming the **Root Node** of our chatbot!

## Worked Example
Let us calculate the Gini impurity of the root node of our chatbot.
In the training partition (67 students total):
- Math: 26 students ($p_1 = \frac{26}{67} \approx 0.388$)
- Literature: 21 students ($p_2 = \frac{21}{67} \approx 0.313$)
- Biology: 20 students ($p_3 = \frac{20}{67} \approx 0.299$)

Let us calculate:
$$p_1^2 = (0.388)^2 \approx 0.1506$$
$$p_2^2 = (0.313)^2 \approx 0.0980$$
$$p_3^2 = (0.299)^2 \approx 0.0894$$
$$\sum p_i^2 = 0.1506 + 0.0980 + 0.0894 = 0.3380$$
$$I_G(\text{root}) = 1 - 0.3380 = \mathbf{0.662}$$

Now inspect `outputs/chatbot_tree.png`. At the very top box (the root node), you will see:
`gini = 0.662`! The mathematical formula matches the rendered diagram down to the third decimal place.

## Step-by-Step Student Instructions
1. Open `outputs/chatbot_tree.png` in an image viewer.
2. Look at the root box. Note the line `gini = 0.662`.
3. Look at any terminal leaf node at the bottom of the tree.
4. Verify that whenever all samples in a box belong to one class (e.g., `value = [0, 0, 7]`), the reported Gini is `gini = 0.0`.

## Expected Output or Observable Behaviour
In `outputs/chatbot_tree.png`:
- Every box displays its computed `gini` value.
- Boxes with high Gini are colored with pale, washed-out hues.
- Boxes with low Gini (high purity) are colored with deep, saturated colors (e.g., dark orange for pure Math, dark green for pure Literature, dark purple for pure Biology).

## Verification & Testing Methods
Verify Gini impurity calculation with a quick Python script:
```python
def gini(counts):
    total = sum(counts)
    if total == 0:
        return 0.0
    return 1.0 - sum((c / total) ** 2 for c in counts)

print("Pure node [10, 0, 0]:", round(gini([10, 0, 0]), 3))
print("Split node [10, 10, 10]:", round(gini([10, 10, 10]), 3))
print("Training root [20, 21, 26]:", round(gini([20, 21, 26]), 3))
```
Output:
```
Pure node [10, 0, 0]: 0.0
Split node [10, 10, 10]: 0.667
Training root [20, 21, 26]: 0.662
```

## Practical Exercises
- **Exercise 2.1**: Calculate the Gini impurity of a node containing 15 Biology students and 5 Literature students. Is it purer than the root node?
- **Exercise 2.2**: Why can a binary split on values 0 and 1 never use a threshold like 1.5 or -0.5?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Correction |
|---|---|---|
| Confusing low Gini with low quality | Thinking higher numbers are always better | In Gini impurity, **0.0 is the best possible score** (perfect purity). High Gini means chaos and uncertainty. |
| Forgetting that Gini depends on class count | Thinking 0.5 is always the maximum Gini | For 2 classes, max Gini is 0.5. For 3 classes, max Gini is 0.667. For $K$ classes, max Gini is $1 - 1/K$. |

## Best Practices and Security Considerations
- **Transparent Splitting**: Because Gini impurity is a purely deterministic mathematical formula, the decision tree's splitting decisions can be completely reproduced, audited, and explained.
- **Fairness Checking**: Ensure that splitting criteria do not disproportionately isolate minority classes into tiny, high-variance leaves.

## Summary & Key Takeaways
- Gini Impurity measures disorder within a node ($0.0$ = completely pure; $0.667$ = completely mixed across 3 classes).
- The CART algorithm chooses splits that maximize Information Gain (impurity reduction).
- The root node of our Subject Chatbot has a Gini score of $0.662$.
- Pure terminal leaf nodes achieve a Gini score of $0.0$.

## Knowledge-check Questions and References
1. What does a Gini impurity of 0.0 indicate about the samples in a node?
2. What is the maximum possible Gini impurity for a dataset with 3 equal classes?
3. How does scikit-learn use Gini impurity to select the root question of the chatbot?

**References:**
- Raileanu, L. E., & Stoffel, K. (2004). *Theoretical comparison between empirical sensitivity of Gini Index and Information Gain criteria.* Annals of Mathematics and Artificial Intelligence, 41(1), 77-93.
- Scikit-learn documentation: *Decision Tree Algorithms: CART.* https://scikit-learn.org/stable/modules/tree.html#tree-algorithms
