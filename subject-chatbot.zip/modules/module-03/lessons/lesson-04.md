# Lesson 04: Architectural Modes: Scripted Batch Execution vs. Live Interactive Q&A

**Lesson ID:** lesson-04
**Module:** module-03
**Duration:** 20 minutes

## Purpose and Learning Objectives
This lesson analyzes the architectural design pattern that allows `main.py` to seamlessly operate in two distinct modes: **Scripted Demo Mode** and **Live Interactive Mode**.

By the end of this lesson, you will be able to:
- Explain why production AI systems require headless automated test modes alongside interactive interfaces.
- Trace the code execution paths of scripted demo mode vs. interactive CLI mode in `main.py`.
- Understand how synthetic persona profiles are structured for automated batch regression testing.
- Evaluate the software engineering principles behind CLI flag branching.

## Prerequisites
- Completion of Lessons 01, 02, and 03.
- Familiarity with command-line arguments in Python.

## Concept Explanation
### Why Have Two Modes?
When developing conversational machine learning applications, developers face an immediate software engineering dilemma:
- **If the script always prompts for live human input**: You cannot run automated tests, benchmark scripts, continuous integration (CI) pipelines, or batch grading scripts! Every time someone runs `python main.py`, the program blocks and waits indefinitely for a human to type responses.
- **If the script only uses hardcoded profiles**: End users cannot experience the chatbot or test their own personal preferences.

The solution is a **dual-mode architecture**:
```
                           Execute: python main.py
                                      |
                     Is "--interactive" in sys.argv?
                                   /      \
                           NO     /        \    YES
                                 /          \
                                v            v
                    [SCRIPTED DEMO MODE]    [INTERACTIVE Q&A MODE]
                    - Evaluate 3 static      - Run ask_profile()
                      demo personas          - Collect live terminal input
                    - Print test metrics     - Compute live confidence
                    - Save tree & rules      - Deliver personalized guess
```

### The Scripted Demo Personas
In Scripted Demo Mode, `main.py` defines three archetypal student personas:
```python
demo_profiles = pd.DataFrame(
    [
        {"likes_numbers": 1, "likes_living_things": 0, "likes_stories": 0, "enjoys_experiments": 1, "enjoys_debate": 0, "likes_programming": 1},
        {"likes_living_things": 1, "likes_numbers": 0, "likes_stories": 0, "enjoys_experiments": 1, "enjoys_debate": 0, "likes_programming": 0},
        {"likes_stories": 1, "likes_numbers": 0, "likes_living_things": 0, "enjoys_experiments": 0, "enjoys_debate": 1, "likes_programming": 0},
    ]
)
```

Each persona is designed to test a distinct quadrant of the model:
- **Student 1 (The Quantitative Coder)**: Likes numbers, experiments, and programming $\implies$ Expected: **Math**.
- **Student 2 (The Natural Scientist)**: Likes living things and experiments $\implies$ Expected: **Biology**.
- **Student 3 (The Humanist)**: Likes stories and debate $\implies$ Expected: **Literature**.

Evaluating these three personas instantly verifies that all three subject branches of the decision tree are functioning properly!

## Theoretical & Real-World Context
In enterprise software engineering, this pattern is fundamental:
- **Smoke Testing / Regression Testing**: When code is updated or dependencies change, automated test suites execute `python main.py` in batch mode to ensure predictions across standard personas do not regress.
- **Interactive Serving**: When deployed as an API or user-facing CLI tool, the interactive subsystem is triggered.

Decoupling the interface layer from the core inference engine ensures that the exact same trained model serves both batch automation and real-time users.

## Relevant Code (from main.py)
In `main.py`, lines 85-96 execute the scripted demo:
```python
# Lines 85-96 of main.py
demo_profiles = pd.DataFrame(
    [
        {"likes_numbers": 1, "likes_living_things": 0, "likes_stories": 0, "enjoys_experiments": 1, "enjoys_debate": 0, "likes_programming": 1},
        {"likes_numbers": 0, "likes_living_things": 1, "likes_stories": 0, "enjoys_experiments": 1, "enjoys_debate": 0, "likes_programming": 0},
        {"likes_numbers": 0, "likes_living_things": 0, "likes_stories": 1, "enjoys_experiments": 0, "enjoys_debate": 1, "likes_programming": 0},
    ]
)
demo_predictions = model.predict(demo_profiles)
print("Demo profiles:")
for index, prediction in enumerate(demo_predictions, start=1):
    print(f"  Student {index}: {prediction}")
```

And lines 123-133 control the mode dispatch:
```python
# Lines 123-133 of main.py
if "--interactive" in sys.argv:
    print("\nAnswer six questions and the chatbot will guess your subject.\n")
    profile = ask_profile()
    prediction = model.predict(profile)[0]
    probabilities = model.predict_proba(profile)[0]
    confidence = probabilities.max()
    print(f"\nThe chatbot guesses: {prediction} ({confidence:.0%} confident)")
else:
    print("Run `python main.py --interactive` to chat with it yourself.")
    print("Try this: add a new subject and 20 example profiles.")
```

## Code Explanation & Line-by-Line Breakdown
- **Lines 85-91**: Constructs a 3-row DataFrame of synthetic test cases.
- **Line 92 (`model.predict(demo_profiles)`)**: Runs batch vector inference across all three rows simultaneously.
- **Lines 94-95**: Prints the results using `enumerate(..., start=1)`.
- **Line 123 (`if "--interactive" in sys.argv:`)**: Checks Python's runtime argument list. If the user passed `--interactive`, the program enters live dialogue mode; otherwise, it exits cleanly after displaying the demo.

## Worked Example
Compare running both commands in your terminal:
1. `python main.py`
   - Executes in ~0.2 seconds.
   - Evaluates Student 1, 2, and 3.
   - Displays: `Student 1: Math`, `Student 2: Biology`, `Student 3: Literature`.
   - Exits without blocking.
2. `python main.py --interactive`
   - Pauses execution and prompts: `Do you enjoy working with numbers? (y/n): `.
   - Awaits keyboard input for all 6 questions.
   - Outputs: `The chatbot guesses: Math (100% confident)`.

## Step-by-Step Student Instructions
1. Open your terminal in `17_subject_chatbot`.
2. Run `python main.py`. Note the speed and non-blocking execution.
3. Inspect lines 85-90 of `main.py` and modify Student 1's features so that `likes_stories: 1` and `likes_programming: 0`.
4. Re-run `python main.py` and observe how Student 1's prediction changes.
5. Revert your changes back to the original dictionary.

## Expected Output or Observable Behaviour
When executing in demo mode, the console displays:
```
Demo profiles:
  Student 1: Math
  Student 2: Biology
  Student 3: Literature

Saved: outputs/chatbot_tree.png, outputs/rules.txt
Run `python main.py --interactive` to chat with it yourself.
Try this: add a new subject and 20 example profiles.
```
All outputs are created automatically.

## Verification & Testing Methods
Verify that `demo_profiles` matches the feature columns expected by `model`:
```python
import pandas as pd
demo = pd.DataFrame([{"likes_numbers": 1, "likes_living_things": 0, "likes_stories": 0, "enjoys_experiments": 1, "enjoys_debate": 0, "likes_programming": 1}])
assert list(demo.columns) == ["likes_numbers", "likes_living_things", "likes_stories", "enjoys_experiments", "enjoys_debate", "likes_programming"]
print("Demo schema alignment verified.")
```

## Practical Exercises
- **Exercise 4.1**: Create a 4th student persona representing an undecided student who answered 0 to all questions. What does the model predict?
- **Exercise 4.2**: Why is batch prediction (`model.predict(demo_profiles)`) much faster than predicting one sample at a time in a loop?

## Common Mistakes and Debugging
| Mistake | Why It Happens | Correction |
|---|---|---|
| Putting `input()` before the model training logic | Forcing interactive input before the tree is even fit | Always train and validate the model first; interactive input should only occur at the inference phase. |
| Forgetting to test edge cases in demo profiles | Only testing personas that fit stereotypes | Include diverse personas in demo test suites to ensure edge branches don't fail silently. |

## Best Practices and Security Considerations
- **Non-Blocking Default Execution**: Command-line ML scripts should default to automated execution so automated harnesses and grading scripts don't hang.
- **Decoupled Architecture**: Separating the inference algorithm from the UI allows easy porting to web apps (Flask/FastAPI) or Slack/Discord bots without rewriting the ML code.

## Summary & Key Takeaways
- Dual-mode architecture decouples batch automated testing from live user interaction.
- Scripted demo mode uses 3 synthetic student personas to instantly verify that Math, Biology, and Literature predictions function properly.
- `sys.argv` inspection activates interactive mode only when explicitly requested.
- This pattern is standard practice in production machine learning systems.

## Knowledge-check Questions and References
1. What three student personas are tested in scripted demo mode?
2. Why is non-blocking execution essential for automated grading and CI/CD pipelines?
3. How does `main.py` detect whether the user requested interactive mode?

**References:**
- Fowler, M. (2018). *Refactoring: Improving the Design of Existing Code (2nd ed.).* Chapter 1: Refactoring a First Example.
- Python documentation: *sys.argv — Command line arguments.* https://docs.python.org/3/library/sys.html#sys.argv
