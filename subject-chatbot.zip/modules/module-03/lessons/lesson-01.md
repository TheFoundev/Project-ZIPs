# Lesson 01: Rule Induction: How Decision Trees Discover IF-THEN Rules from Survey Profiles

**Lesson ID:** lesson-01
**Module:** module-03
**Duration:** 20 minutes

## Purpose and Learning Objectives
The purpose of this lesson is to demystify how the Decision Tree algorithm automatically discovers logical IF-THEN rules from survey responses without human programming.

By the end of this lesson, you will be able to:
- Explain the concept of **rule induction** in machine learning.
- Contrast human heuristic rule authoring with algorithmic feature selection.
- Understand how recursive binary splitting builds a hierarchical rule set.
- Interpret the indented text rules exported by scikit-learn's `export_text()`.

## Prerequisites
- Completion of Modules 01 and 02.
- Understanding of basic boolean logic (AND, OR, NOT).

## Concept Explanation
### What is Rule Induction?
In computer science, **rule induction** is the automated extraction of formal IF-THEN rules from an empirical dataset.
Instead of a human domain expert sitting down and writing:
```python
if student_likes_programming and not student_likes_stories:
    recommend("Math")
```
The algorithm (specifically CART: Classification and Regression Trees) scans through all candidate features, tests every possible split, and identifies the exact questions that separate Math, Biology, and Literature students with the highest statistical certainty.

### Recursive Binary Splitting
The decision tree constructs rules through a greedy, top-down strategy known as **recursive binary splitting**:
1. **Find the Best Root Question**: The algorithm evaluates all 6 features across all 67 training students. It asks: *"Which single question, if asked first, does the best job separating the three subjects?"*
   - In our project, the algorithm discovers that `likes_programming` is the single most informative initial question.
2. **Partition the Data**: The training dataset is split into two child subsets:
   - Left Branch: Students who answered No (`likes_programming <= 0.50`).
   - Right Branch: Students who answered Yes (`likes_programming > 0.50`).
3. **Repeat Recursively**: For each child subset, the algorithm repeats Step 1 independently!
   - For students who do NOT like programming, the next best question is `likes_stories`.
   - For students who DO like programming, the next best question is `likes_numbers`.
4. **Stopping Condition**: Splitting stops when a node is pure, when all samples in a branch have the same label, or when a hyperparameter limit (like `max_depth=4`) is reached.

### Representing Rules as a Hierarchy
Each unique path from the root node to a leaf represents a single conjunction (AND condition) of rules:
$$\text{IF } (\text{likes\_programming} \le 0.50) \text{ AND } (\text{likes\_stories} > 0.50) \text{ AND } (\text{likes\_living\_things} \le 0.50) \implies \text{Literature}$$

## Theoretical & Real-World Context
In the 1980s, the field of Artificial Intelligence was dominated by expert systems. Companies spent millions hiring "knowledge engineers" to interview human experts and transcribe their intuition into rule engines.

Decision trees revolutionized this field by demonstrating that algorithms could **induce superior rule bases directly from historical transaction records** in a fraction of a second. Today, rule induction remains vital in credit scoring, medical triage protocols, and fraud detection where decisions must be fully explainable to auditors.

## Relevant Code (from main.py)
In `main.py`, lines 82-83 export and display these learned rules:
```python
# Lines 82-83 of main.py
print("Learned question path:\n")
print(export_text(model, feature_names=FEATURES))
```

And lines 113-116 save them to disk:
```python
# Lines 113-116 of main.py
with open(OUT / "rules.txt", "w", encoding="utf-8") as handle:
    handle.write(f"accuracy: {accuracy:.4f}\n\n")
    handle.write(export_text(model, feature_names=FEATURES))
```

## Code Explanation & Line-by-Line Breakdown
- **`export_text(model, feature_names=FEATURES)`**: Converts the binary tree data structure into a formatted string with visual indentation (`|---`).
- **`feature_names=FEATURES`**: Replaces generic feature labels (`feature_0`, `feature_1`) with human-readable column names (`likes_numbers`, `likes_programming`).
- **Indentation Depth**: Each level of indentation (`|   |---`) represents one additional question asked deeper in the conversation.

## Worked Example
Let us examine the right branch of the learned tree from `outputs/rules.txt`:
```
|--- likes_programming >  0.50
|   |--- likes_numbers >  0.50
|   |   |--- likes_living_things <= 0.50
|   |   |   |--- class: Math
```
Let us break down this rule logically:
1. Condition 1: `likes_programming > 0.50` (Student likes coding).
2. Condition 2: `likes_numbers > 0.50` (Student likes math/numbers).
3. Condition 3: `likes_living_things <= 0.50` (Student does not prefer biology).
4. **Conclusion**: Assign class **`Math`**.

Every student in the training data who satisfied these three conditions was indeed a Math student. The algorithm discovered a pure, high-confidence rule!

## Step-by-Step Student Instructions
1. Open your terminal in the project directory.
2. Run `python main.py`.
3. Open `outputs/rules.txt` in your text editor.
4. Count how many total leaf nodes (`|--- class: ...`) exist in the text rules.
5. Identify the shortest path from the root to a leaf. (Notice that some paths reach a conclusion in only 2 or 3 questions!).

## Expected Output or Observable Behaviour
In `outputs/rules.txt`, you will observe that all decision splits evaluate at `<= 0.50` or `> 0.50`:
```
|--- likes_programming <= 0.50
|   |--- likes_stories <= 0.50
|   |   |--- enjoys_experiments <= 0.50
|   |   |   |--- likes_living_things <= 0.50
|   |   |   |   |--- class: Math
|   |   |   |--- likes_living_things >  0.50
|   |   |   |   |--- class: Biology
|   |   |--- enjoys_experiments >  0.50
|   |   |   |--- class: Biology
```
Notice that if a student does not like programming and does not like stories, but enjoys experiments, the tree reaches `class: Biology` in only 3 questions without needing to ask about debate or numbers!

## Verification & Testing Methods
Verify that scikit-learn's exported rules match the underlying tree's node count:
```python
from sklearn.tree import DecisionTreeClassifier, export_text
import pandas as pd

df = pd.read_csv("data/subject_answers.csv")
FEATURES = ["likes_numbers", "likes_living_things", "likes_stories", "enjoys_experiments", "enjoys_debate", "likes_programming"]
model = DecisionTreeClassifier(max_depth=4, random_state=42).fit(df[FEATURES], df["subject"])
print("Total tree nodes:", model.tree_.node_count)
print("Total leaf nodes:", model.tree_.n_leaves)
```

## Practical Exercises
- **Exercise 1.1**: Find a path in `outputs/rules.txt` that leads to `class: Literature`. Write out the exact boolean expression.
- **Exercise 1.2**: Why does the tree test `likes_programming` at the root node instead of `enjoys_debate`? (Hint: Think about which question splits the 3 classes most cleanly).

## Common Mistakes and Debugging
| Mistake | Why It Happens | Correction |
|---|---|---|
| Thinking the tree evaluates all 6 questions for every user | Assuming decision trees are flat checklists | Decision trees traverse a single branch path; many questions are bypassed once a conclusive leaf is reached. |
| Forgetting to provide `feature_names` to `export_text` | Calling `export_text(model)` without parameters | Without `feature_names`, rules print as `feature_0 <= 0.50`, which is unreadable. Always pass `feature_names=FEATURES`. |

## Best Practices and Security Considerations
- **Human Auditability**: Exporting text rules allows human domain specialists (like teachers or counselors) to review the AI's internal logic before deploying the bot to students.
- **Eliminating Bias**: Reviewing text rules helps detect spurious correlations (e.g., if a chatbot accidentally used an irrelevant question to make high-stakes placement decisions).

## Summary & Key Takeaways
- Rule induction automatically extracts IF-THEN logic from training datasets.
- The CART algorithm uses recursive binary splitting to construct a hierarchical rule tree.
- Each branch in the tree represents an AND condition evaluated against user preferences.
- Scikit-learn's `export_text()` provides a transparent, human-readable view of the chatbot's decision brain.

## Knowledge-check Questions and References
1. What does the `|---` notation indicate in scikit-learn's `export_text()` output?
2. Why is recursive binary splitting referred to as a "greedy" algorithm?
3. What is the benefit of rule induction over manual rule programming?

**References:**
- Breiman, L., Friedman, J., Stone, C. J., & Olshen, R. A. (1984). *Classification and Regression Trees.* CRC Press.
- Scikit-learn documentation: *export_text.* https://scikit-learn.org/stable/modules/generated/sklearn.tree.export_text.html
