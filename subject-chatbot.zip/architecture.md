# Architecture: The Subject Chatbot

```
+---------------------------------------------------------------------------------+
|                               SYSTEM ARCHITECTURE                               |
+---------------------------------------------------------------------------------+

   +---------------------------+
   |   data/subject_answers    | (90 survey profile rows x 6 binary features)
   +---------------------------+
                 |
                 v
   +---------------------------+
   |    pandas Data Loading    | X = df[FEATURES], y = df["subject"]
   +---------------------------+
                 |
                 v
   +---------------------------+
   | Stratified Train/Test     | test_size=0.25, random_state=42, stratify=y
   | Split (67 train / 23 test)|
   +---------------------------+
                 |
                 v
   +---------------------------+
   |   DecisionTreeClassifier  | max_depth=4, random_state=42
   |         Fitting           |
   +---------------------------+
                 |
        +--------+--------+-----------------------+
        |                 |                       |
        v                 v                       v
 +-------------+   +--------------+     +-------------------+
 | Evaluation  |   | Visualization|     |  Inference Engine |
 |  Accuracy   |   | plot_tree()  |     +-------------------+
 | Class Report|   | export_text()|               |
 +-------------+   +--------------+               v
        |                 |             +-------------------+
        v                 v             | Execution Mode    |
  Console Print    outputs/             | Branching         |
                   - chatbot_tree.png   +-------------------+
                   - rules.txt            /               \
                                         /                 \
                      [No Flag: Scripted Demo]    [--interactive Flag]
                                 |                         |
                                 v                         v
                       demo_profiles DataFrame      ask_profile() Q&A Loop
                       (3 static synthetic rows)   (Live terminal input)
                                 |                         |
                                 v                         v
                       Batch predictions:          predict() & predict_proba()
                       Student 1: Math             "The chatbot guesses: Math"
                       Student 2: Biology          "(100% confident)"
                       Student 3: Literature
```

---

## Architectural Components

### 1. Data Subsystem
- **Source**: `data/subject_answers.csv` containing 90 labeled historical responses.
- **Feature Matrix ($X$)**: 6 binary numerical features ($0$ or $1$) representing preferences across math, science, humanities, and coding.
- **Target Vector ($y$)**: Categorical string labels representing academic subjects (`Math`, `Biology`, `Literature`).

### 2. Learning Pipeline
- **Partitioning**: `train_test_split` with `stratify=y` guarantees identical class representation across the 67-sample training set and 23-sample test set.
- **Classifier**: `DecisionTreeClassifier(max_depth=4, random_state=42)` recursively splits training data on the feature that maximizes information gain / minimizes Gini impurity.
- **Complexity Control**: `max_depth=4` bounds the depth of the tree to prevent memorization of noise while creating a dialogue tree of at most 4 consecutive questions.

### 3. Inspection & Serialization Subsystem
- **Flowchart Rendering**: `plot_tree()` generates a high-resolution graphical diagram with color-coded nodes reflecting majority classes.
- **Text Rule Induction**: `export_text()` prints indented conditional logic (`|--- feature <= 0.50`), mirroring an expert system knowledge base.
- **Disk Persistence**: Files written to `outputs/rules.txt` and `outputs/chatbot_tree.png`.

### 4. Dual-Mode Inference Engine
- **Mode Dispatcher**: Inspects `sys.argv` for the presence of the string `"--interactive"`.
- **Scripted Demo Mode (Default)**: Evaluates a predefined DataFrame of 3 prototypical student personas without waiting for user input.
- **Interactive Mode**: Executes `ask_profile()`, prompting the user through 6 sequential prompts with input validation, then reporting predicted subject and highest class probability (`confidence`).
