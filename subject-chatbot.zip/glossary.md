# Glossary

| Term | Definition |
|---|---|
| **Decision Tree** | A non-parametric supervised machine learning model that makes decisions by recursively partitioning feature space based on binary conditional tests. |
| **Expert System** | An early artificial intelligence paradigm that uses explicit rules and inference engines to emulate the decision-making ability of human specialists. |
| **Rule-Based Chatbot** | A conversational agent that relies on hardcoded decision graphs and scripted keyword matching rather than learned empirical patterns. |
| **Classification Engine** | A predictive algorithm that maps multidimensional input feature vectors to discrete categorical class labels. |
| **Binary Feature** | A numeric indicator variable restricted to two discrete values: $1$ (representing True, Yes, or Present) and $0$ (representing False, No, or Absent). |
| **Gini Impurity** | A metric used by decision tree algorithms to measure the probability of misclassifying a randomly chosen element from a node; ranges from $0.0$ (pure node) to $0.5$ (equally distributed binary classes). |
| **Information Gain** | The expected reduction in entropy or impurity achieved by partitioning a dataset on a given attribute. |
| **Root Node** | The topmost decision node in a tree hierarchy from which all subsequent branches originate. |
| **Internal Node** | A branching decision point in a tree that evaluates an inequality test on a feature (e.g., $likes\_programming \le 0.50$). |
| **Leaf Node (Terminal Node)** | An endpoint of a decision tree path that carries no further questions and assigns a final class label. |
| **Max Depth (`max_depth`)** | A regularization hyperparameter limiting the maximum length of any path from the root node to a leaf node to prevent overfitting. |
| **Stratified Sampling (`stratify=y`)** | A dataset splitting technique that ensures each train and test partition receives the exact same percentage of each target class as the original dataset. |
| **Accuracy** | The proportion of total test predictions that correctly matched the true target labels ($Accuracy = \frac{Correct}{Total}$). |
| **Precision** | The fraction of positive predictions for a given class that were actually correct ($Precision = \frac{TP}{TP + FP}$). |
| **Recall** | The fraction of actual members of a given class that the model successfully identified ($Recall = \frac{TP}{TP + FN}$). |
| **F1-Score** | The harmonic mean of precision and recall ($F_1 = 2 \cdot \frac{Precision \cdot Recall}{Precision + Recall}$). |
| **`predict_proba()`** | A method on scikit-learn classifiers that returns the estimated posterior class probability distribution for input samples. |
| **CLI Flag (`sys.argv`)** | An argument passed to a Python program via the terminal command line (e.g., `--interactive`) that alters program execution behavior. |
