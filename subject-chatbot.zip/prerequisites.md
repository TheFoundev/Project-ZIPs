# Prerequisites

## Required Technical Skills
- **Basic Python Syntax**: Variables, lists, dictionaries, conditionals (`if/else`), `for` and `while` loops, functions, and string methods (`strip()`, `lower()`).
- **Command-Line Navigation**: Running scripts from a terminal (`python main.py`), passing CLI arguments (`--interactive`), and inspecting file directory trees.
- **Introductory Pandas**: Loading CSV files with `pd.read_csv()`, selecting columns, creating small DataFrames from dictionaries.
- **Foundational Machine Learning**: Concept of features ($X$) vs. target ($y$), classification vs. regression, and train/test evaluation.

## Software & Environment Requirements
- **Python Version**: Python 3.8 or higher.
- **Package Manager**: `pip`.
- **Code Editor**: Visual Studio Code, PyCharm, or any modern terminal-based editor.

## Python Libraries Required
- `pandas`: Tabular data structures and CSV ingestion.
- `matplotlib`: Plotting engine for rendering the graphical decision tree flowchart.
- `scikit-learn`: Decision tree modeling, train-test splitting, and evaluation metrics.

## Key Theoretical Concepts to Review
- **Decision Trees**: Hierarchical structures that make predictions by answering a sequence of binary questions.
- **Rule-Based vs. ML Chatbots**: The difference between manually coded dialogue graphs and models induced directly from data.
- **Binary Features**: Categorical variables represented as numeric indicators ($1$ for Yes, $0$ for No).
- **Stratified Sampling**: Preserving class proportions across training and evaluation splits.
