# The Chatbot That Guesses Your Favorite Subject

Welcome to **The Chatbot That Guesses Your Favorite Subject** educational repository! This repository contains a complete, production-grade educational curriculum designed to teach beginner machine learning students how decision trees can function as expert-system classification engines and conversational chatbots.

---

## Curriculum Structure

This educational package is structured into six comprehensive modules:

- **Module 01: Project Overview & Chatbot Architecture**
  - History of conversational systems (ELIZA, expert systems, modern LLMs).
  - Rule-based vs. machine learning classification paradigms.
  - Decision trees as conversational inference engines.
  - Project environment setup and codebase exploration.

- **Module 02: Data & Profile Features**
  - Deep-dive analysis of `data/subject_answers.csv`.
  - Survey design and binary feature encoding ($1$ vs $0$).
  - Target class distribution and multiclass balance across Math, Biology, and Literature.
  - Data loading, feature matrix extraction ($X$), and target vector ($y$) isolation.

- **Module 03: Decision Tree as Expert System**
  - Rule induction: discovering IF-THEN rules from empirical data.
  - Splitting criteria: Gini impurity, information gain, and thresholding at $\le 0.50$.
  - Regularization with `max_depth=4` to constrain dialogue length and prevent overfitting.
  - Architecture of dual execution: scripted batch mode vs. interactive CLI.

- **Module 04: Training, Tree Flowchart & Demo Mode**
  - Model fitting with stratified train/test partitioning.
  - Evaluation metrics: accuracy, precision, recall, and classification reports.
  - Tree visualization using `plot_tree()` and rule export with `export_text()`.
  - Manual path tracing through the tree for three scripted demo student personas.

- **Module 05: Interactive Mode & CLI Engineering**
  - Command-line argument parsing via `sys.argv` and detecting `--interactive`.
  - User input sanitization using `while True` loops and string normalization.
  - Constructing runtime pandas DataFrames from user responses.
  - Calculating prediction confidence scores using `predict_proba()`.

- **Module 06: Running Both Modes & Extensions**
  - Execution comparison: batch scripted automation vs. live conversational Q&A.
  - Error analysis and boundary conditions in decision tree classification.
  - Extending the system: adding new academic subjects (e.g., History, Art) and survey questions.
  - Future directions: transitioning from static trees to dynamic, adaptive Q&A agents.

---

## Final Project & Assessments
- **Assessments**: Each module concludes with a 10-question multiple-choice assessment covering basic, intermediate, and advanced concepts.
- **Hands-on Exercises**: Practical exercises with explicit acceptance criteria and step-by-step guidance.
- **Final Project**: A capstone engineering assignment where students build and enhance the subject chatbot pipeline from scratch, backed by an evaluation rubric and mentor solution guide.

---

## Quick Start
```bash
# Clone the repository and navigate to the project directory
cd "beginner-projects-main/AI-ML Beginners/projects/17_subject_chatbot"

# Install dependencies
pip install pandas matplotlib scikit-learn

# Run the scripted demo mode
python main.py

# Run the live interactive conversational mode
python main.py --interactive
```
