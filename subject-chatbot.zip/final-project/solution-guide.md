# Mentor Solution Guide: The Subject Chatbot

## Overview
This guide provides mentors and instructors with the complete architectural reference implementation, line-by-line pedagogical breakdown, common student pitfalls, and grading verification points for **The Chatbot That Guesses Your Favorite Subject**.

---

## Reference Implementation Walkthrough

### 1. Imports and Backend Configuration (Lines 11-28)
```python
from __future__ import annotations
import sys
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, export_text, plot_tree

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)
```
**Mentor Verification Checklist:**
- `matplotlib.use("Agg")` must appear **before** `import matplotlib.pyplot as plt`. Failing to do so can trigger GUI backend crashes in headless Linux terminals or Docker environments.
- Paths are resolved relative to `__file__`, allowing script execution from any parent folder.
- `OUT.mkdir(exist_ok=True)` safely creates `outputs/` without raising an error if it already exists.

---

### 2. Feature and Question Definitions (Lines 30-45)
```python
FEATURES = [
    "likes_numbers",
    "likes_living_things",
    "likes_stories",
    "enjoys_experiments",
    "enjoys_debate",
    "likes_programming",
]
QUESTIONS = [
    "Do you enjoy working with numbers?",
    "Do you like learning about living things?",
    "Do you enjoy stories and writing?",
    "Do you like running experiments?",
    "Do you enjoy debating ideas?",
    "Do you like programming?",
]
```
**Mentor Verification Checklist:**
- The length of `FEATURES` and `QUESTIONS` must be identical (6 elements).
- Feature order must strictly match the column names in `data/subject_answers.csv`.

---

### 3. Interactive Input Sanitization Function (Lines 48-60)
```python
def ask_profile() -> pd.DataFrame:
    answers = []
    for question in QUESTIONS:
        while True:
            answer = input(f"{question} (y/n): ").strip().lower()
            if answer in ("y", "yes", "1"):
                answers.append(1)
                break
            if answer in ("n", "no", "0"):
                answers.append(0)
                break
            print("Please type y or n.")
    return pd.DataFrame([dict(zip(FEATURES, answers))])
```
**Common Student Mistakes:**
- Omitting `.strip()` or `.lower()`, which causes `' Y'` or `'Yes'` to be rejected as invalid.
- Using `input()` without a validation loop, causing index errors or non-binary strings to enter the feature matrix.
- Returning a raw dictionary or list instead of a 2D single-row `pd.DataFrame`. Scikit-learn's `predict()` requires 2D input with matching column feature names.

---

### 4. Data Splitting and Model Training (Lines 63-76)
```python
df = pd.read_csv(DATA / "subject_answers.csv")
X = df[FEATURES]
y = df["subject"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

model = DecisionTreeClassifier(max_depth=4, random_state=42)
model.fit(X_train, y_train)
```
**Mentor Verification Checklist:**
- `stratify=y` is crucial because the 90-sample dataset contains 3 classes. Without stratification, small test splits may suffer from severe class imbalance.
- `max_depth=4` restricts the depth of the tree to prevent overfitting and mimics an intuitive 4-question dialogue path.
- Verify that `model.fit()` is strictly passed `X_train` and `y_train`. Passing full `X` is data leakage.

---

### 5. Evaluation and Serialization (Lines 77-121)
```python
predictions = model.predict(X_test)
accuracy = accuracy_score(y_test, predictions)

# Draw and save the tree diagram
fig, ax = plt.subplots(figsize=(15, 8))
plot_tree(
    model,
    feature_names=FEATURES,
    class_names=list(model.classes_),
    filled=True,
    rounded=True,
    fontsize=8,
    ax=ax,
)
ax.set_title("The chatbot's decision tree")
fig.tight_layout()
fig.savefig(OUT / "chatbot_tree.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```
**Mentor Verification Checklist:**
- `class_names=list(model.classes_)` ensures nodes are correctly labeled with class names instead of raw numeric indices.
- `plt.close(fig)` must be executed to prevent matplotlib memory leaks.

---

### 6. Interactive Mode Branching (Lines 123-133)
```python
if "--interactive" in sys.argv:
    print("\nAnswer six questions and the chatbot will guess your subject.\n")
    profile = ask_profile()
    prediction = model.predict(profile)[0]
    probabilities = model.predict_proba(profile)[0]
    confidence = probabilities.max()
    print(f"\nThe chatbot guesses: {prediction} ({confidence:.0%} confident)")
```
**Mentor Verification Checklist:**
- Checking `"--interactive" in sys.argv` correctly decouples testing/grading from manual user input.
- `confidence = probabilities.max()` extracts the highest class probability, formatted as a percentage (`{confidence:.0%}`).

---

## Expected Output Reference
```
============================================================
THE FAVORITE-SUBJECT CHATBOT
============================================================
Accuracy: 78.3%

              precision    recall  f1-score   support

     Biology       0.67      0.67      0.67         6
  Literature       0.86      0.75      0.80         8
        Math       0.80      0.89      0.84         9

    accuracy                           0.78        23
   macro avg       0.77      0.77      0.77        23
weighted avg       0.79      0.78      0.78        23

Demo profiles:
  Student 1: Math
  Student 2: Biology
  Student 3: Literature
```
