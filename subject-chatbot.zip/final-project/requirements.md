# Final Project Requirements: The Subject Chatbot

## Project Objective
Develop, train, evaluate, and deploy an end-to-end intelligent conversational classifier: **The Chatbot That Guesses Your Favorite Subject**. Your implementation will ingest historical student preference surveys, train an interpretable Decision Tree classifier with controlled depth, visualize the learned decision tree as both a graphical flowchart and text rule set, evaluate demo student personas, and provide a live, fault-tolerant interactive Q&A command-line interface.

---

## Functional Requirements

### 1. Environment & Path Architecture
- Use `matplotlib.use("Agg")` prior to importing `matplotlib.pyplot` to enable headless rendering.
- Define filesystem paths using Python's object-oriented `pathlib.Path`.
- Ensure the destination directory `outputs/` is created automatically using `mkdir(exist_ok=True)`.

### 2. Dataset Ingestion & Feature Separation
- Ingest `data/subject_answers.csv` into a pandas DataFrame.
- Define a constant list `FEATURES` containing:
  - `"likes_numbers"`
  - `"likes_living_things"`
  - `"likes_stories"`
  - `"enjoys_experiments"`
  - `"enjoys_debate"`
  - `"likes_programming"`
- Separate feature matrix $X$ using `df[FEATURES]` and target vector $y$ using `df["subject"]`.
- Verify $X$ has shape `(90, 6)` and $y$ has shape `(90,)`.

### 3. Stratified Partitioning
- Partition data into training and test splits using `train_test_split`.
- Parameter requirements: `test_size=0.25`, `random_state=42`, `stratify=y`.
- Verify training set contains 67 samples and test set contains 23 samples.

### 4. Model Training & Complexity Regulation
- Instantiate `DecisionTreeClassifier` from `sklearn.tree`.
- Enforce regularization via `max_depth=4` and fix reproducibility via `random_state=42`.
- Fit the classifier exclusively on `X_train` and `y_train`.

### 5. Evaluation & Performance Reporting
- Generate test set predictions using `model.predict(X_test)`.
- Compute overall accuracy using `accuracy_score(y_test, predictions)` and verify it achieves approximately $78.3\%$.
- Generate a multiclass classification report using `classification_report(y_test, predictions, zero_division=0)`.

### 6. Rule Export & Graphic Flowchart Rendering
- Convert the tree logic into text rules using `export_text(model, feature_names=FEATURES)`.
- Render the tree architecture using `plot_tree(model, feature_names=FEATURES, class_names=list(model.classes_), filled=True, rounded=True, fontsize=8)`.
- Save the plot to `outputs/chatbot_tree.png` with `dpi=150` and `bbox_inches="tight"`.
- Write `outputs/rules.txt` containing model accuracy, text rules, demo predictions, and full classification report.
- Properly release system graphics memory using `plt.close(fig)`.

### 7. Scripted Demo Evaluation
- Construct a synthetic DataFrame `demo_profiles` representing three student personas:
  - Student 1: `likes_numbers=1, enjoys_experiments=1, likes_programming=1` (others 0)
  - Student 2: `likes_living_things=1, enjoys_experiments=1` (others 0)
  - Student 3: `likes_stories=1, enjoys_debate=1` (others 0)
- Predict their subjects using `model.predict(demo_profiles)` and print predictions to the console.

### 8. Interactive CLI Q&A Subsystem
- Inspect command-line arguments using `sys.argv`.
- If `"--interactive"` is present:
  - Implement `ask_profile()` prompting 6 user questions.
  - Implement a `while True` loop validating inputs against affirmative (`'y'`, `'yes'`, `'1'`) and negative (`'n'`, `'no'`, `'0'`) tokens.
  - Reprompt upon invalid input without crashing.
  - Construct a single-row DataFrame with the 6 feature columns.
  - Predict the subject using `model.predict(profile)[0]`.
  - Calculate prediction confidence using `model.predict_proba(profile)[0].max()`.
  - Format output: `"The chatbot guesses: <subject> (<confidence>% confident)"`.
- If `"--interactive"` is absent, display informative instructions on how to launch interactive mode.

---

## Non-Functional Requirements
- **Deterministic Reproducibility**: Using `random_state=42` ensures identical splits and tree topologies across runs.
- **Robust Exception Handling**: Interactive input must gracefully handle uppercase input, whitespace, and invalid characters.
- **Code Standards**: Conform to PEP 8 naming conventions and clean modular code design.
- **Path Independence**: Use `Path(__file__).resolve().parent` to ensure the script executes reliably from any working directory.
