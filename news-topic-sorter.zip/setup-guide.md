# Setup Guide: The News Topic Sorter

Follow these instructions to set up your environment, inspect the project files, and run the classifier.

## Step 1: Navigate to the Project Root
Open your terminal and navigate to the project directory:
```bash
cd "/home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/19_news_topic_sorter"
```

## Step 2: Set Up Python Virtual Environment (Recommended)
Create and activate an isolated virtual environment:
```bash
python3 -m venv venv
source venv/bin/activate
```

## Step 3: Install Required Dependencies
Install the required scientific Python libraries:
```bash
pip install pandas numpy matplotlib scikit-learn
```

Verify the installation:
```bash
python3 -c "import pandas, numpy, matplotlib, sklearn; print('Dependencies successfully verified!')"
```

## Step 4: Inspect the Dataset
Examine the first 10 rows of the news headlines dataset:
```bash
head -n 11 data/headlines.csv
```
You should observe two comma-separated columns: `headline` and `topic`.

## Step 5: Execute the Main Script
Run the complete classification pipeline:
```bash
python3 main.py
```

## Step 6: Verify Generated Outputs
Confirm that the script printed the evaluation metrics to the console and generated artifacts in `outputs/`:
```bash
ls -la outputs/
cat outputs/predictions.txt
```
You will find:
1. `outputs/confusion_matrix.png` — Visual confusion matrix across food, sports, and technology.
2. `outputs/predictions.txt` — Summary report containing overall accuracy, classification metrics, and new headline inference results.
