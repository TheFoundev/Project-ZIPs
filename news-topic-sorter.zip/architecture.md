# Architecture: The News Topic Sorter

## End-to-End Pipeline
The project implements a modular, reproducible NLP pipeline structured in `main.py`:

1. **Environment & Backend Configuration**:
   - `matplotlib.use("Agg")` ensures reliable server-side rendering without display hardware.
   - `pathlib.Path(__file__).resolve().parent` establishes absolute reference paths for input data and generated outputs.
2. **Data Ingestion**:
   - Ingests `data/headlines.csv` using pandas.
   - Validates schema: text column `headline` and categorical label column `topic`.
3. **Stratified Splitting**:
   - `train_test_split(..., test_size=0.25, random_state=42, stratify=df["topic"])` preserves class balance across partitions.
4. **Scikit-Learn Pipeline Assembly**:
   - **Step 1: CountVectorizer**:
     - Strips English stop words (`stop_words="english"`).
     - Extracts both individual words and bigram pairs (`ngram_range=(1, 2)`).
     - Generates a vocabulary of 282 n-gram tokens.
   - **Step 2: MultinomialNB**:
     - Fits conditional log-likelihood distributions $P(w_i | c)$.
     - Incorporates additive Laplace smoothing ($lpha = 1.0$) to prevent zero-probability errors on rare tokens.
5. **Inference & Metric Computation**:
   - Computes overall accuracy score.
   - Generates comprehensive precision, recall, and F1-score report.
6. **Interpretability & Feature Extraction**:
   - Retrieves top 8 feature log-probabilities for each class using `np.argsort()`.
7. **Unseen Headline Scoring**:
   - Executes `predict` and `predict_proba` over 5 test cases to demonstrate confidence calibration.
8. **Artifact Generation**:
   - Saves confusion matrix figure `outputs/confusion_matrix.png` at 150 DPI.
   - Serializes classification results to `outputs/predictions.txt`.

## Data Flow Diagram
```
headlines.csv ──> pandas DataFrame ──> train_test_split (stratified)
                                            │
               ┌────────────────────────────┴───────────────────────────┐
               ▼                                                        ▼
         X_train, y_train                                         X_test, y_test
               │                                                        │
               ▼                                                        │
  Pipeline.fit()                                                        │
    ├── CountVectorizer (fit_transform)                                 │
    └── MultinomialNB (fit)                                             │
               │                                                        ▼
               └──────────────────────────────────────────────> Pipeline.predict()
                                                                        │
                                                                        ▼
                                                         Accuracy, Report & CM Plot
```
