# Final Project Requirements: The News Topic Sorter

## Project Objective
Implement the complete News Topic Sorter from scratch using Python and scikit-learn, adhering strictly to the architecture and operational requirements of `main.py`. Your implementation will load the headline dataset, execute stratified data splitting, configure an NLP pipeline combining Bag-of-Words n-gram vectorization with Multinomial Naive Bayes, evaluate the model's multi-class performance, inspect distinctive lexical keywords, predict topics for unseen headlines, and save evaluation artifacts.

## Detailed Requirements

### 1. Environment & Setup
- Configure matplotlib with the non-interactive `"Agg"` backend prior to importing `matplotlib.pyplot`.
- Use `pathlib.Path(__file__).resolve().parent` to dynamically establish paths for `BASE`, `DATA = BASE / "data"`, and `OUT = BASE / "outputs"`.
- Ensure `OUT.mkdir(exist_ok=True)` is called before writing any files.

### 2. Data Loading & Partitioning
- Ingest `data/headlines.csv` using `pd.read_csv()`.
- Extract the feature sequence $X$ from `df["headline"]` and target labels $y$ from `df["topic"]`.
- Execute a stratified split using `train_test_split(..., test_size=0.25, random_state=42, stratify=df["topic"])`.
- Verify that the resulting partitions contain 67 training instances and 23 testing instances.

### 3. Pipeline Construction & Vectorization
- Assemble a `sklearn.pipeline.Pipeline` with two named stages:
  1. `"vectorizer"`: `CountVectorizer(stop_words="english", ngram_range=(1, 2))`
  2. `"classifier"`: `MultinomialNB()`
- Train the pipeline strictly on `X_train` and `y_train` using `model.fit()`.

### 4. Model Evaluation & Reporting
- Generate test set predictions using `model.predict(X_test)`.
- Compute overall accuracy using `accuracy_score(y_test, predictions)`.
- Print a formatted console header and display accuracy as a percentage (`{accuracy:.1%}`).
- Print `classification_report(y_test, predictions, zero_division=0)`.

### 5. Vocabulary Feature Importance Extraction
- Retrieve the fitted vectorizer and classifier from `model.named_steps`.
- Extract feature names via `vectorizer.get_feature_names_out()`.
- Retrieve target classes via `list(classifier.classes_)`.
- For each topic class, find the indices of the 8 highest log-probabilities using `np.argsort(classifier.feature_log_prob_[index])[-8:][::-1]`.
- Print the top 8 terms for each topic.

### 6. Inference on Unseen Test Headlines
- Evaluate the following 5 headlines:
  1. `"Team wins the final after a dramatic last-minute goal"`
  2. `"New open-source tool makes Python debugging easier"`
  3. `"Five quick recipes for a healthy student lunch"`
  4. `"The city opens a new food market this weekend"`
  5. `"A smartphone that folds into a tablet"`
- Obtain class predictions using `model.predict(new_headlines)`.
- Obtain predicted probability distributions using `model.predict_proba(new_headlines)`.
- Format and display each prediction with its confidence percentage.

### 7. Confusion Matrix Visualization & Output File Creation
- Compute `confusion_matrix(y_test, predictions, labels=labels)`.
- Render the matrix using `ConfusionMatrixDisplay(cm, display_labels=labels).plot(ax=ax, cmap="Blues", colorbar=False)`.
- Save the plot to `outputs/confusion_matrix.png` at 150 DPI with `bbox_inches="tight"`.
- Close the figure using `plt.close(fig)` to release memory.
- Serialize the evaluation summary, classification report, and unseen headline predictions to `outputs/predictions.txt`.
