# Mentor Solution Guide: The News Topic Sorter

## Overview
This mentor solution guide outlines the technical reference implementation for the News Topic Sorter final project. Mentors should use this guide to evaluate student submissions, troubleshoot common implementation pitfalls, and verify numerical results.

## Reference Code Walkthrough & Checkpoints

### Checkpoint 1: Headless Configuration & Imports
```python
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
```
**Mentor Verification Checklist**:
- `matplotlib.use("Agg")` must appear before `import matplotlib.pyplot as plt` to prevent graphical display crashes in headless environments.
- All classes must be imported from their official scikit-learn modules.

### Checkpoint 2: Data Splitting & Stratification
```python
df = pd.read_csv(DATA / "headlines.csv")
X_train, X_test, y_train, y_test = train_test_split(
    df["headline"], df["topic"], test_size=0.25, random_state=42, stratify=df["topic"]
)
```
**Mentor Verification Checklist**:
- Verify that `stratify=df["topic"]` is present. Without stratification, small datasets can suffer from class imbalance between splits.
- Verify shapes: `len(X_train) == 67` and `len(X_test) == 23`.
- Verify class distribution in test set: 8 technology, 8 sports, 7 food.

### Checkpoint 3: Pipeline & Vectorizer Configuration
```python
model = Pipeline(
    [
        ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
        ("classifier", MultinomialNB()),
    ]
)
model.fit(X_train, y_train)
```
**Mentor Verification Checklist**:
- Ensure `stop_words="english"` is set.
- Ensure `ngram_range=(1, 2)` is specified. This allows the model to learn unigrams ("recipe") as well as bigrams ("street food").
- Ensure the pipeline is fitted ONLY on `X_train, y_train` to avoid data leakage.

### Checkpoint 4: Keyword Log-Probability Extraction
```python
vectorizer = model.named_steps["vectorizer"]
classifier = model.named_steps["classifier"]
names = vectorizer.get_feature_names_out()
classes = list(classifier.classes_)

for index, topic in enumerate(classes):
    top = np.argsort(classifier.feature_log_prob_[index])[-8:][::-1]
    print(f"  {topic:10s}: {', '.join(names[top])}")
```
**Mentor Verification Checklist**:
- Verify that `classifier.feature_log_prob_` is accessed.
- Verify that `np.argsort` indices are sliced with `[-8:][::-1]` to sort in descending order of probability.

### Checkpoint 5: Unseen Headline Inference & Confidence
```python
new_predictions = model.predict(new_headlines)
new_probabilities = model.predict_proba(new_headlines)
for headline, prediction, probability in zip(new_headlines, new_predictions, new_probabilities):
    confidence = probability[classes.index(prediction)]
    print(f"  {prediction:10s} ({confidence:.0%}) -> {headline}")
```
**Expected Inferences**:
- `"Team wins the final after a dramatic last-minute goal"` -> `sports` (~90%)
- `"New open-source tool makes Python debugging easier"` -> `technology` (~100%)
- `"Five quick recipes for a healthy student lunch"` -> `food` (~34%)
- `"The city opens a new food market this weekend"` -> `food` (~97%)
- `"A smartphone that folds into a tablet"` -> `technology` (~70%)

*Note for mentors*: Discuss with students why the student lunch headline has a lower confidence of ~34% (minimal domain-specific n-grams in the vocabulary, making the probability distribution flatter across classes).
