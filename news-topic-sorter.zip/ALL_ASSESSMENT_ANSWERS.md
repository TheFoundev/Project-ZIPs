# All Assessment Answers: The News Topic Sorter
**Project:** The News Topic Sorter (Multi-Class Naive Bayes Text Classification)
**Total Modules:** 6 | **Total Questions:** 60 (10 per module: 3 basic, 5 intermediate, 2 advanced)
---

## Module 01
**q1-01.** What are the three news topics classified in this project?
   **Correct Answer:** b. sports, technology, food
   *Explanation:* The News Topic Sorter specifically classifies headlines into sports, technology, and food as defined in main.py lines 6-7.
   *Concept Tested:* Project topic taxonomy (Lesson: lesson-01)

**q1-02.** Why is news topic sorting considered a multi-class classification task?
   **Correct Answer:** b. Because it assigns each headline to one of three or more mutually exclusive categories
   *Explanation:* Multi-class classification involves predicting one label among three or more mutually exclusive categorical targets. Here we have 3 classes (sports, tech, food).
   *Concept Tested:* Definition of multi-class classification (Lesson: lesson-02)

**q1-03.** Which scikit-learn class is used to chain the text vectorizer and the classifier together?
   **Correct Answer:** b. Pipeline
   *Explanation:* Scikit-learn's Pipeline encapsulates sequential data transformations (like CountVectorizer) and a terminal estimator (like MultinomialNB) into a unified object.
   *Concept Tested:* Scikit-learn Pipeline architecture (Lesson: lesson-03)

**q1-04.** What is the primary operational advantage of using automated topic categorization over manual editorial tagging?
   **Correct Answer:** b. Automated models process incoming wire feeds in milliseconds at massive scale without fatigue
   *Explanation:* Automated classification models can evaluate and route incoming articles in milliseconds at scale, overcoming human editorial latency and fatigue.
   *Concept Tested:* Operational value of automated news categorization (Lesson: lesson-01)

**q1-05.** For any given headline, what must the sum of its predicted probabilities across all 3 classes equal?
   **Correct Answer:** b. 1.0 (or 100%)
   *Explanation:* In a valid probability distribution over mutually exclusive outcomes, the probabilities across all candidate classes must sum to exactly 1.0 (or 100%).
   *Concept Tested:* Probability distribution normalization (Lesson: lesson-02)

**q1-06.** How does scikit-learn order categorical target labels when populating `classifier.classes_`?
   **Correct Answer:** b. In standard alphabetical order ('food', 'sports', 'technology')
   *Explanation:* Scikit-learn sorts unique string labels alphabetically when creating the classes_ array, yielding ['food', 'sports', 'technology'].
   *Concept Tested:* Label ordering in scikit-learn (Lesson: lesson-02)

**q1-07.** Why does wrapping text vectorization and classification inside a `Pipeline` prevent data leakage?
   **Correct Answer:** b. It ensures the vocabulary is learned strictly from training data, never from test data
   *Explanation:* By encapsulating the vectorizer inside a Pipeline, the vocabulary is fitted strictly on X_train during fit(). During predict(), test data is only transformed using the training vocabulary, preventing data leakage.
   *Concept Tested:* Data leakage prevention via Pipeline (Lesson: lesson-03)

**q1-08.** In `main.py`, what is the purpose of `OUT.mkdir(exist_ok=True)`?
   **Correct Answer:** b. It ensures the output folder exists without raising an error if it is already present
   *Explanation:* Calling mkdir(exist_ok=True) ensures that the target directory is created if it does not exist, but does not raise an error if it already exists.
   *Concept Tested:* Safe directory creation with pathlib (Lesson: lesson-04)

**q1-09.** Suppose a model produces probabilities: food=0.34, sports=0.33, tech=0.33 for a headline. What is true about this prediction?
   **Correct Answer:** b. Food is predicted as the winning class, but with very low confidence/margin
   *Explanation:* The argmax of [0.34, 0.33, 0.33] selects 'food' as the winning prediction, but because the margin over the other classes is only 1%, the model has very low confidence.
   *Concept Tested:* Interpreting probability distributions and confidence (Lesson: lesson-02)

**q1-10.** Why is `Path(__file__).resolve().parent` superior to using hardcoded relative paths like `'data/headlines.csv'`?
   **Correct Answer:** b. It makes file resolution independent of the terminal's current working directory
   *Explanation:* Resolving paths relative to Path(__file__).resolve().parent guarantees that files are found relative to the script's location, regardless of which folder the user is in when executing the command.
   *Concept Tested:* Robust path resolution in Python (Lesson: lesson-04)

## Module 02
**q2-01.** How many total headline rows exist in `data/headlines.csv`?
   **Correct Answer:** b. 90
   *Explanation:* The headlines.csv dataset contains exactly 90 data rows (excluding the header line), representing 30 headlines per topic.
   *Concept Tested:* Dataset row count (Lesson: lesson-01)

**q2-02.** What is the distribution of topics in the full dataset?
   **Correct Answer:** b. 30 sports, 30 technology, 30 food
   *Explanation:* The dataset is perfectly balanced across the three topics, with exactly 30 samples each for sports, technology, and food.
   *Concept Tested:* Dataset class balance (Lesson: lesson-02)

**q2-03.** Which column in `headlines.csv` is used as the target label ($y$)?
   **Correct Answer:** c. topic
   *Explanation:* The 'topic' column holds the target category labels ('sports', 'technology', 'food') that the model learns to predict.
   *Concept Tested:* Target column identification (Lesson: lesson-01)

**q2-04.** Why is `stratify=df['topic']` specified in `train_test_split`?
   **Correct Answer:** b. To ensure both training and testing splits maintain identical class proportions
   *Explanation:* Stratified sampling ensures that both the training and testing sets have the same proportion of each target class as the original dataset.
   *Concept Tested:* Purpose of stratified splitting (Lesson: lesson-02)

**q2-05.** With `test_size=0.25` on 90 rows, how many samples are assigned to the training and test sets respectively?
   **Correct Answer:** b. 67 train, 23 test
   *Explanation:* With 90 samples and test_size=0.25, 25% of 90 is 22.5 (rounded to 23 test samples), leaving 67 training samples.
   *Concept Tested:* Train/test partition sizes (Lesson: lesson-02)

**q2-06.** Which of the following words has high discriminative power for the `food` topic?
   **Correct Answer:** b. recipe
   *Explanation:* 'recipe' is strongly specific to culinary content and virtually never appears in sports or technology headlines, giving it high discriminative power.
   *Concept Tested:* Discriminative lexical features (Lesson: lesson-03)

**q2-07.** Why do sports and technology articles exhibit more potential vocabulary confusion than food articles?
   **Correct Answer:** b. Because sports and tech frequently share shared performance vocabulary like 'faster', 'tests', and 'announces'
   *Explanation:* Sports and technology journalism often share common vocabularies about speed, competitive performance, announcements, and equipment ('faster', 'tests', 'season'), whereas food has a distinct physical/culinary vocabulary.
   *Concept Tested:* Semantic overlap between domains (Lesson: lesson-04)

**q2-08.** What is the composition of the 23 test samples across topics in `main.py`?
   **Correct Answer:** b. 8 technology, 8 sports, 7 food
   *Explanation:* Stratified splitting of 23 samples across 3 balanced classes produces 8 technology, 8 sports, and 7 food samples in the test partition.
   *Concept Tested:* Stratified partition composition (Lesson: lesson-02)

**q2-09.** Why did the test headline `'Five quick recipes for a healthy student lunch'` receive a relatively low confidence score of 34%?
   **Correct Answer:** b. Because several words ('student', 'lunch') were unrepresented or sparse in the training vocabulary, diluting the signal
   *Explanation:* The headline contains words like 'student' and 'lunch' that have little or no representation in the training vocabulary, so the only recognized signal is 'recipe', resulting in a low confidence advantage (34%).
   *Concept Tested:* Causes of low prediction confidence (Lesson: lesson-04)

**q2-10.** In the context of multi-class news sorting, what is 'polysemy'?
   **Correct Answer:** b. A linguistic phenomenon where a single word form has multiple distinct meanings across different domains (e.g., 'chip' or 'apple')
   *Explanation:* Polysemy refers to words having multiple distinct meanings across contexts (e.g., 'chip' as potato snack vs computer microprocessor), which can mislead word-frequency classifiers.
   *Concept Tested:* Linguistic polysemy in text classification (Lesson: lesson-04)

## Module 03
**q3-01.** What does the Bag-of-Words model use to represent a text document?
   **Correct Answer:** b. An unordered collection of word frequencies
   *Explanation:* The Bag-of-Words model represents documents as an unordered frequency histogram of their words, ignoring grammar and word order.
   *Concept Tested:* Bag-of-Words model definition (Lesson: lesson-01)

**q3-02.** What is the purpose of setting `stop_words='english'` in CountVectorizer?
   **Correct Answer:** b. To filter out ubiquitous function words like 'the', 'is', and 'at'
   *Explanation:* Setting stop_words='english' removes standard high-frequency English function words like 'the', 'is', and 'at' that provide no topical distinction.
   *Concept Tested:* Stop words filtering function (Lesson: lesson-02)

**q3-03.** What does `ngram_range=(1, 2)` extract from a document?
   **Correct Answer:** b. Both single words (unigrams) and two-word phrases (bigrams)
   *Explanation:* ngram_range=(min_n, max_n) extracts all n-gram sizes between min_n and max_n inclusive. Here (1, 2) extracts both unigrams (1) and bigrams (2).
   *Concept Tested:* N-gram range configuration (Lesson: lesson-03)

**q3-04.** Why are Document-Term Matrices stored as sparse matrices in scikit-learn?
   **Correct Answer:** a. Because most words in the vocabulary do not appear in any single short headline, making most entries zero
   *Explanation:* Short documents only contain a tiny subset of the global vocabulary, resulting in matrices where >95% of entries are zeros. Storing them sparsely saves huge amounts of memory.
   *Concept Tested:* Matrix sparsity in text vectorization (Lesson: lesson-01)

**q3-05.** How many total vocabulary features (unigrams and bigrams) are learned by the vectorizer on the training split in `main.py`?
   **Correct Answer:** b. 282
   *Explanation:* When fitted on the 67 training headlines with stop_words='english' and ngram_range=(1, 2), the vectorizer extracts exactly 282 features.
   *Concept Tested:* Fitted vocabulary size in main.py (Lesson: lesson-03)

**q3-06.** Which attribute of a fitted `Pipeline` allows direct access to its internal stages by name?
   **Correct Answer:** b. model.named_steps
   *Explanation:* The named_steps attribute provides dictionary-style access to the pipeline's individual transformer and estimator objects using their assigned string names.
   *Concept Tested:* Pipeline step inspection (Lesson: lesson-04)

**q3-07.** Why is the bigram `'street food'` more informative for classification than the unigram `'street'` alone?
   **Correct Answer:** b. Because 'street' could refer to city infrastructure or news, but 'street food' specifically refers to culinary culture
   *Explanation:* Individual words like 'street' appear in diverse contexts (traffic, municipal news), whereas the bigram 'street food' strongly and specifically denotes culinary journalism.
   *Concept Tested:* Semantic value of bigrams (Lesson: lesson-03)

**q3-08.** Which method on `CountVectorizer` returns the array of learned feature names?
   **Correct Answer:** b. get_feature_names_out()
   *Explanation:* get_feature_names_out() is the modern scikit-learn API method that retrieves the array of feature names from a fitted transformer.
   *Concept Tested:* Feature names retrieval API (Lesson: lesson-04)

**q3-09.** What happens if a new headline contains a word that was never present in the training set when passed to `pipeline.predict()`?
   **Correct Answer:** b. The vectorizer silently ignores the unseen word and vectorizes the remaining known words
   *Explanation:* During vectorizer.transform(), any tokens not present in the learned training vocabulary dictionary are simply ignored without throwing an error.
   *Concept Tested:* Out-of-vocabulary handling during inference (Lesson: lesson-04)

**q3-10.** Why should you avoid using an excessively high upper bound for n-grams, such as `ngram_range=(1, 6)`?
   **Correct Answer:** b. Because it causes a combinatorial explosion of rare features, vastly increasing matrix size and risking overfitting
   *Explanation:* Higher-order n-grams generate millions of combinations, most of which appear only once. This causes a massive, sparse feature space that leads to severe memory usage and overfitting.
   *Concept Tested:* N-gram dimension trade-offs (Lesson: lesson-03)

## Module 04
**q4-01.** What does Bayes' Theorem calculate in text classification?
   **Correct Answer:** a. The posterior probability of a topic given the observed words in a headline
   *Explanation:* Bayes' Theorem calculates the posterior probability of each topic category given the observed word tokens in the text: P(Topic|Words).
   *Concept Tested:* Bayes' Theorem purpose in NLP (Lesson: lesson-01)

**q4-02.** Why is the Naive Bayes algorithm called 'naive'?
   **Correct Answer:** b. Because it naively assumes all word features are conditionally independent given the class
   *Explanation:* The algorithm is termed 'naive' because it assumes that all word features are completely independent of one another given the class label, ignoring grammar and natural word correlations.
   *Concept Tested:* Definition of 'naive' assumption (Lesson: lesson-01)

**q4-03.** Which Naive Bayes variant is specifically designed for discrete word frequency count data?
   **Correct Answer:** b. MultinomialNB
   *Explanation:* MultinomialNB is tailored specifically for multinomially distributed data, which describes discrete word frequency counts in text documents.
   *Concept Tested:* MultinomialNB specialization (Lesson: lesson-02)

**q4-04.** What fatal problem occurs in Naive Bayes if an unseen word has a probability of zero and no smoothing is applied?
   **Correct Answer:** b. Multiplying by zero zeroes out the entire class probability, ignoring all other positive word evidence
   *Explanation:* Because Naive Bayes multiplies all word likelihoods together, a single probability of zero causes the entire product to become zero, completely overriding all other positive word evidence.
   *Concept Tested:* Zero-frequency multiplication problem (Lesson: lesson-02)

**q4-05.** How does Laplace smoothing with $\alpha=1.0$ solve the zero-frequency problem?
   **Correct Answer:** b. It adds a pseudo-count of 1 to every word's frequency, guaranteeing all probabilities remain strictly positive
   *Explanation:* Laplace smoothing adds a pseudo-count of 1 to every word's count in the numerator (and |V| to the denominator), ensuring that every word likelihood remains strictly positive.
   *Concept Tested:* Laplace smoothing mechanics (Lesson: lesson-02)

**q4-06.** What is stored in `classifier.feature_log_prob_` after fitting `MultinomialNB`?
   **Correct Answer:** b. The natural log of conditional probabilities $\log P(w|c)$ for every vocabulary feature given each class
   *Explanation:* feature_log_prob_ stores the natural logarithm of the smoothed conditional probability log P(w|c) for every vocabulary feature across each topic class, with shape (3, 282).
   *Concept Tested:* feature_log_prob_ attribute (Lesson: lesson-03)

**q4-07.** What does `model.predict_proba()` return?
   **Correct Answer:** b. A 2D array of estimated class probabilities for each sample, summing to 1.0 across columns
   *Explanation:* predict_proba() outputs a 2D array of probability estimates for each sample across all classes. Each row sums to 1.0.
   *Concept Tested:* predict_proba return structure (Lesson: lesson-04)

**q4-08.** Why must inputs to `model.predict()` be passed as a list of strings (e.g., `['Headline text']`) rather than a single string?
   **Correct Answer:** a. Because scikit-learn expects an iterable collection of documents, and a raw string would be iterated character-by-character
   *Explanation:* Scikit-learn transformers expect a collection/list of documents. Passing a single string causes Python to treat the string as an iterable of individual characters, resulting in character-level tokenization errors.
   *Concept Tested:* Input document formatting for inference (Lesson: lesson-04)

**q4-09.** In `main.py`, what confidence percentage was assigned to `'New open-source tool makes Python debugging easier'`?
   **Correct Answer:** d. 100%
   *Explanation:* In main.py, the Python debugging headline contains multiple strong technology terms, resulting in a predicted confidence of 100% for technology.
   *Concept Tested:* Headline prediction confidence values in main.py (Lesson: lesson-04)

**q4-10.** Why do production text classification systems rely on `predict_proba` confidence scores rather than just raw `predict` labels?
   **Correct Answer:** b. To enable safety thresholds: high-confidence predictions can be automated while low-confidence predictions are routed to human editors
   *Explanation:* Probability confidence scores provide an uncertainty metric: articles with high confidence (e.g., >80%) can be published automatically, while borderline or ambiguous cases (<60%) can be flagged for human verification.
   *Concept Tested:* Operational importance of confidence calibration (Lesson: lesson-04)

## Module 05
**q5-01.** What test set accuracy was achieved by the model in `main.py`?
   **Correct Answer:** c. 100.0%
   *Explanation:* The script prints 'Accuracy: 100.0%' because all 23 test headlines were correctly classified on this synthetic benchmark.
   *Concept Tested:* Model accuracy in main.py (Lesson: lesson-01)

**q5-02.** In a confusion matrix, where do correctly classified instances appear?
   **Correct Answer:** b. Along the main diagonal from top-left to bottom-right
   *Explanation:* Correct classifications occur where True Class equals Predicted Class, which falls along the main diagonal from top-left to bottom-right.
   *Concept Tested:* Confusion matrix diagonal interpretation (Lesson: lesson-02)

**q5-03.** Which scikit-learn class is used to render a visual confusion matrix plot in matplotlib?
   **Correct Answer:** a. ConfusionMatrixDisplay
   *Explanation:* ConfusionMatrixDisplay is scikit-learn's visualization class for plotting confusion matrices using matplotlib.
   *Concept Tested:* ConfusionMatrixDisplay utility (Lesson: lesson-02)

**q5-04.** What does the 'support' column in a scikit-learn `classification_report` represent?
   **Correct Answer:** b. The number of true instances of each class in the test dataset
   *Explanation:* Support indicates the true ground-truth sample count for each class in the evaluated test dataset (e.g., 7 food, 8 sports, 8 tech).
   *Concept Tested:* Support column definition in classification report (Lesson: lesson-01)

**q5-05.** What is the difference between macro average and weighted average F1-scores?
   **Correct Answer:** a. Macro average weights classes equally; weighted average weights classes by their sample support count
   *Explanation:* Macro average calculates an unweighted arithmetic mean across all classes equally, while weighted average weights each class's score by its proportion of test samples (support).
   *Concept Tested:* Macro vs weighted average metrics (Lesson: lesson-01)

**q5-06.** What does an entry in row `sports` and column `technology` of a confusion matrix represent?
   **Correct Answer:** b. A sports headline mistakenly predicted as technology
   *Explanation:* The row indicates the True (Actual) class (sports), and the column indicates the Predicted class (technology), meaning a sports article was misclassified as technology.
   *Concept Tested:* Reading confusion matrix cells (Lesson: lesson-02)

**q5-07.** Why do sports and technology headlines exhibit greater potential for classification confusion than food headlines?
   **Correct Answer:** a. Because food journalism uses distinct culinary nouns and ingredients, while sports and tech share performance, speed, and organizational vocabulary
   *Explanation:* Food reporting features unique culinary terms (ingredients, recipes), whereas sports and tech share overlapping lexicons centered on performance, speed, tests, metrics, and competition.
   *Concept Tested:* Cross-domain semantic overlap causes (Lesson: lesson-03)

**q5-08.** In `main.py`, which NumPy expression is used to extract the indices of the 8 highest log-probabilities in descending order?
   **Correct Answer:** b. np.argsort(probs)[-8:][::-1]
   *Explanation:* np.argsort sorts ascending; slicing [-8:] takes the 8 largest values, and [::-1] reverses them to produce descending order from largest to smallest.
   *Concept Tested:* NumPy indexing for feature importance (Lesson: lesson-04)

**q5-09.** Which of the following phrases was identified as one of the strongest features for `sports` in `main.py`?
   **Correct Answer:** b. comeback victory
   *Explanation:* 'comeback victory' was identified as one of the top 8 strongest learned features for the sports category.
   *Concept Tested:* Specific top keywords per topic in main.py (Lesson: lesson-04)

**q5-10.** Why are feature log-probabilities in `classifier.feature_log_prob_` always negative numbers?
   **Correct Answer:** b. Because probabilities are numbers between 0 and 1, and the natural logarithm of any number strictly between 0 and 1 is negative
   *Explanation:* Probabilities p satisfy 0 < p <= 1. The natural logarithm of any number strictly between 0 and 1 is negative (e.g., ln(0.5) = -0.693, ln(1.0) = 0).
   *Concept Tested:* Mathematical properties of log-probabilities (Lesson: lesson-04)

## Module 06
**q6-01.** Where does `main.py` save its generated confusion matrix plot?
   **Correct Answer:** b. outputs/confusion_matrix.png
   *Explanation:* main.py lines 26, 82 explicitly save the figure to OUT / 'confusion_matrix.png', which resolves to outputs/confusion_matrix.png.
   *Concept Tested:* Output file path for confusion matrix (Lesson: lesson-01)

**q6-02.** What information is recorded in `outputs/predictions.txt`?
   **Correct Answer:** a. Overall accuracy, classification report, and predictions with confidence for new headlines
   *Explanation:* outputs/predictions.txt serializes the overall accuracy score, the formatted classification_report, and each new test headline with its predicted class and confidence percentage.
   *Concept Tested:* Contents of outputs/predictions.txt (Lesson: lesson-01)

**q6-03.** What does TF-IDF stand for?
   **Correct Answer:** b. Term Frequency - Inverse Document Frequency
   *Explanation:* TF-IDF stands for Term Frequency - Inverse Document Frequency, a weighting technique that balances term occurrence within a document against its frequency across the corpus.
   *Concept Tested:* TF-IDF acronym definition (Lesson: lesson-04)

**q6-04.** Why is `encoding='utf-8'` explicitly specified when writing `outputs/predictions.txt`?
   **Correct Answer:** b. To ensure consistent text serialization across operating systems, preventing encoding crashes on non-ASCII characters
   *Explanation:* Explicitly specifying encoding='utf-8' ensures that text files are serialized identically across Linux, macOS, and Windows, avoiding platform-dependent character corruption.
   *Concept Tested:* File encoding best practices (Lesson: lesson-01)

**q6-05.** What prediction and confidence did `'A smartphone that folds into a tablet'` receive in `main.py`?
   **Correct Answer:** b. technology (70%)
   *Explanation:* In main.py line 73 output, 'A smartphone that folds into a tablet' is classified as technology with 70% confidence.
   *Concept Tested:* Headline prediction confidence values in main.py (Lesson: lesson-02)

**q6-06.** If a 4th topic (`politics`) is added with 30 headlines, what does the confusion matrix shape become?
   **Correct Answer:** b. 4x4
   *Explanation:* A confusion matrix has dimensions K x K where K is the number of target classes. For 4 classes, the matrix is a 4x4 square grid.
   *Concept Tested:* Confusion matrix scaling with classes (Lesson: lesson-03)

**q6-07.** How does TF-IDF improve upon raw word counts in `CountVectorizer`?
   **Correct Answer:** b. It down-weights words that appear across almost all documents and amplifies rare, domain-specific keywords
   *Explanation:* TF-IDF multiplies term frequency by inverse document frequency, penalizing words that appear across many documents (like 'new' or 'report') and boosting unique domain keywords.
   *Concept Tested:* TF-IDF weighting advantages (Lesson: lesson-04)

**q6-08.** What code change is required in the pipeline to switch from `CountVectorizer` to `TfidfVectorizer`?
   **Correct Answer:** a. Replace CountVectorizer with TfidfVectorizer as the first tuple in the Pipeline list
   *Explanation:* Because both classes implement the scikit-learn transformer API (fit/transform), switching to TF-IDF requires only replacing CountVectorizer with TfidfVectorizer in the Pipeline tuple.
   *Concept Tested:* Pipeline modularity and vectorizer swapping (Lesson: lesson-04)

**q6-09.** Why is class balance critical when expanding a taxonomy to include a 4th category?
   **Correct Answer:** b. Because adding a class with very few samples gives it an artificially low prior probability, making it difficult for the model to ever predict it
   *Explanation:* In Naive Bayes, class prior probabilities are calculated directly from sample proportions. A class with very few samples receives a tiny prior, requiring massive evidence to overcome the disadvantage.
   *Concept Tested:* Class balance importance in taxonomy expansion (Lesson: lesson-03)

**q6-10.** What fundamental limitation of Bag-of-Words and TF-IDF representations do modern Transformer models (like BERT) overcome?
   **Correct Answer:** b. Transformers capture contextual word meanings and sequential grammar, distinguishing polysemous words based on their full sentence context
   *Explanation:* Transformer models utilize self-attention mechanisms to evaluate words in their full contextual sentence structure, easily resolving polysemous words (e.g., 'apple' as fruit vs company) based on surrounding text.
   *Concept Tested:* Modern Transformer advancements over BoW (Lesson: lesson-04)
