# Project Summary: The News Topic Sorter

## Executive Summary
The News Topic Sorter demonstrates how classical probabilistic machine learning—specifically **Multinomial Naive Bayes** paired with **Bag-of-Words** n-gram vectorization—can achieve exceptional speed, interpretability, and accuracy for text classification tasks. By categorizing short news headlines into **sports**, **technology**, and **food**, the project illustrates foundational NLP techniques applied to media routing and content management.

## Core Problem Statement
High-volume digital content platforms receive incoming news feeds at velocities that surpass human editorial capacity. Without automated classification, content indexing suffers delays, misfiled articles frustrate readers, and automated recommendation engines degrade. The goal is to build an automated classifier that accurately assigns multi-class category labels to raw headline strings with high statistical confidence.

## Pipeline Architecture
```
[Raw News Headline]
        │
        ▼
[CountVectorizer]
  - Tokenization & Lowercasing
  - English Stop Word Removal
  - N-gram Range (1, 2)
  - Vocabulary Mapping (282 features)
        │
        ▼
[Sparse Term-Frequency Matrix]
        │
        ▼
[Multinomial Naive Bayes]
  - Laplace Smoothing (alpha=1.0)
  - Prior Probabilities P(C)
  - Feature Log Probabilities log P(w|C)
        │
  ┌─────┴────────────────┐
  ▼                      ▼
[Topic Predictions]    [Prediction Probabilities]
  (sports/tech/food)     (Calibrated Confidence %)
```

## Key Findings & Benchmark Metrics
- **Dataset**: 90 headlines (balanced 1:1:1 ratio across sports, tech, food).
- **Split**: 75% train (67 samples), 25% test (23 samples: 8 tech, 8 sports, 7 food).
- **Test Set Accuracy**: 100.0% on the synthetic benchmark dataset.
- **Top Discriminatory Keywords**:
  - *Food*: `food`, `street`, `street food`, `recipe`, `farmers market`, `farmers`
  - *Sports*: `announces`, `comeback victory`, `twice comeback`, `twice`, `cricket`
  - *Technology*: `new`, `ai`, `train`, `unveil faster`, `unveil`, `faster`, `faster way`
- **Ambiguity Insights**: Multi-class text classifiers rely heavily on distinct vocabulary tokens. Headlines containing domain crossover or fewer topic-specific n-grams (e.g., student lunches) yield lower prediction confidence (~34%) compared to unambiguous domain headlines (90-100%).
