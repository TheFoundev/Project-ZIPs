# Module 4 Exercises: Naive Bayes Probability & Inference

## Exercise 4.1: Manual Laplace Smoothing Calculation (15 min)
**Objective:** Calculate smoothed conditional likelihoods and posterior probabilities by hand.
**Problem Statement:** Given a vocabulary size $|V| = 100$ and two classes: `sports` ($N_{	ext{sports}} = 200$) and `tech` ($N_{	ext{tech}} = 200$). Both have equal priors $P(C) = 0.5$.
Word `"battery"` appears 0 times in sports and 20 times in tech.
Word `"match"` appears 15 times in sports and 0 times in tech.

**Requirements:**
1. Calculate $P(	ext{battery}|	ext{sports})$ and $P(	ext{battery}|	ext{tech})$ with $lpha = 1.0$.
2. Calculate $P(	ext{match}|	ext{sports})$ and $P(	ext{match}|	ext{tech})$ with $lpha = 1.0$.
3. For a new headline: `"battery match"`, compute the unnormalized posterior for both classes.
4. Normalize the posteriors and state the winning class and confidence.

**Acceptance Criteria:**
- [ ] Correctly applies formula $rac{count + 1}{N_c + |V|}$.
- [ ] Accurately computes denominator $200 + 100 = 300$.
- [ ] Correctly multiplies probabilities and normalizes to 1.0.

---

## Exercise 4.2: Confidence Threshold Routing (15 min)
**Objective:** Implement a confidence threshold routing function in Python.
**Problem Statement:** Build an automated routing script that classifies headlines but flags uncertain predictions for human review.

**Requirements:**
1. Train the pipeline on `headlines.csv`.
2. Define a function `route_headline(headline_str, min_confidence=0.60)`.
3. If confidence $\ge$ 0.60, return `"AUTOMATED_ROUTING: <topic> (<confidence>%)"`.
4. If confidence < 0.60, return `"MANUAL_REVIEW_FLAGGED: <topic> (<confidence>%)"`.
5. Test the function on the 5 headlines from `main.py` and confirm that `"Five quick recipes for a healthy student lunch"` is flagged for manual review.

**Acceptance Criteria:**
- [ ] Correctly extracts prediction and confidence using `predict` and `predict_proba`.
- [ ] Correctly routes headlines based on threshold comparison.
- [ ] Accurately flags the student recipe headline for manual review.
