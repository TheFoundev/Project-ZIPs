# Lesson 04: Topic Prediction & Probability Confidence

**Lesson ID:** lesson-04  
**Module:** module-04  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Generate discrete class predictions using `model.predict()`.
- Extract posterior probability distributions using `model.predict_proba()`.
- Calculate prediction confidence percentages for winning classes.
- Interpret high-confidence vs. low-confidence classifications on unseen headlines.

## Prerequisites
- Lesson 03: Model Training & Fitting the Pipeline.
- Basic list comprehension and string formatting in Python.

## Industry and Real-World Motivation
In production decision systems, knowing **what** a model predicted is only half the story; knowing **how confident** the model is represents critical operational intelligence. 

Consider an automated news engine: if an article is classified as `sports` with 98% confidence, it can be published to the mobile sports alert feed immediately without human oversight. However, if a headline receives a prediction with only 34% confidence (barely edging out competing categories), routing it automatically risks publishing embarrassing mistakes. Production systems use confidence scores to automate safe decisions while routing uncertain items to human editors.

## Concept Explanation
### `model.predict()` vs. `model.predict_proba()`
A fitted scikit-learn pipeline provides two primary inference methods:

1. **`model.predict(X)`**:
   - Returns a 1D NumPy array of discrete category strings.
   - For each input document, it identifies the class with the maximum posterior probability:
     $$\hat{y} = \arg\max_{c} P(y=c|x)$$

2. **`model.predict_proba(X)`**:
   - Returns a 2D NumPy array of shape `(n_samples, n_classes)`.
   - Each row corresponds to an input sample, and each column corresponds to a class in `classifier.classes_` (`['food', 'sports', 'technology']`).
   - Every value represents the calibrated probability $P(y=c|x)$, and each row sums to exactly 1.0.

### Calculating Winning Confidence
To extract the confidence percentage for the winning prediction:
1. Obtain the predicted class string: `prediction = model.predict(headline)[0]`.
2. Locate its column index: `class_idx = classes.index(prediction)`.
3. Extract the probability value: `confidence = probability[class_idx]`.
4. Format as a percentage: `f"{confidence:.0%}"`.

## Architectural and Pipeline Context
During inference, raw text strings bypass manual vectorization:
```
New Headline String ──> model.predict() ──> 'technology'
                    └──> model.predict_proba() ──> [0.05, 0.05, 0.90] (90% tech)
```

## Relevant Code
From `main.py` (lines 43, 68-74):
```python
    predictions = model.predict(X_test)
...
    new_headlines = [
        "Team wins the final after a dramatic last-minute goal",
        "New open-source tool makes Python debugging easier",
        "Five quick recipes for a healthy student lunch",
        "The city opens a new food market this weekend",
        "A smartphone that folds into a tablet",
    ]
    new_predictions = model.predict(new_headlines)
    new_probabilities = model.predict_proba(new_headlines)
    print("\nNew headline predictions:")
    for headline, prediction, probability in zip(new_headlines, new_predictions, new_probabilities):
        confidence = probability[classes.index(prediction)]
        print(f"  {prediction:10s} ({confidence:.0%}) -> {headline}")
```

## Line-by-Line Code Breakdown
- Line 43: Calls `model.predict(X_test)` to generate predictions on the 23 test samples.
- Lines 61-67: Defines a list of 5 unseen real-world headlines for inference testing.
- Line 68: Generates topic predictions for all 5 new headlines.
- Line 69: Computes full probability distributions across all 3 classes for each headline.
- Lines 71-73: Iterates through predictions, extracts the winning class probability, and prints the formatted confidence score alongside the headline.

## Worked Example
Let's trace what `main.py` prints for the 5 unseen headlines:
```
New headline predictions:
  sports     (90%) -> Team wins the final after a dramatic last-minute goal
  technology (100%) -> New open-source tool makes Python debugging easier
  food       (34%) -> Five quick recipes for a healthy student lunch
  food       (97%) -> The city opens a new food market this weekend
  technology (70%) -> A smartphone that folds into a tablet
```

Analysis:
- `"New open-source tool makes Python debugging easier"`: 100% confidence. Features like `new`, `python`, `open source`, and `debugging` provide overwhelming evidence for technology.
- `"Five quick recipes for a healthy student lunch"`: 34% confidence. Only `recipe` matched the vocabulary, while `student` and `lunch` were out-of-vocabulary, resulting in an uncertain 34% vs. 33% vs. 33% split.
- `"A smartphone that folds into a tablet"`: 70% confidence. `smartphone` strongly signals tech, but `folds` and `tablet` were less frequent, leading to solid but not absolute confidence.

## Step-by-Step Student Instructions
1. Run `python3 main.py` and inspect the "New headline predictions" section.
2. Verify the 5 headlines and their respective confidence scores.
3. Test your own custom headline using Python:
   ```python
   test_headline = ["World cup final match tickets sell out"]
   pred = model.predict(test_headline)
   probs = model.predict_proba(test_headline)
   print(pred[0], probs)
   ```
4. Confirm which category wins and inspect the probability spread.

## Expected Output or Observable Behaviour
- Output cleanly displays the predicted topic name, the confidence percentage in parentheses, and the headline text.
- Probabilities across the three categories sum to 1.0.

## Practical Exercises
- **Exercise 4.1**: What are the probabilities for sports and technology when the food headline receives 34% confidence?
- **Exercise 4.2**: Write a Python function `predict_with_threshold(headline, threshold=0.70)` that returns the prediction if confidence $\ge$ threshold, or returns `"NEEDS_HUMAN_REVIEW"` if confidence is below threshold.

## Common Mistakes and Debugging
| Mistake | Consequence | Proper Approach |
|---|---|---|
| Passing a single string instead of a list: `model.predict("Team wins")` | Treats the string as an iterable of characters, vectorizing single letters | Pass a list of strings: `model.predict(["Team wins"])` |
| Assuming the first probability is always the winning class | Probabilities follow alphabetical order of classes, not sorted by value | Use `probability[classes.index(prediction)]` or `np.max(probability)` |
| Confusing `predict` with `predict_proba` | `predict` returns strings; `predict_proba` returns numerical floating-point arrays | Use `predict` for labels and `predict_proba` for confidence scores |

## Best Practices and Operational Considerations
- Always feed inputs as lists of strings (`[headline]`), even when evaluating a single sample.
- Use `predict_proba` in production to implement confidence-based routing and safety thresholds.

## Summary and Key Takeaways
- `model.predict()` returns discrete class labels, while `model.predict_proba()` outputs calibrated probability distributions.
- Classes are mapped to probability columns in alphabetical order: `food` (col 0), `sports` (col 1), `technology` (col 2).
- Confidence scores expose clear vs. ambiguous headlines, enabling risk-managed automated decision making.

## Knowledge-Check Questions and References
1. What is the return type and shape of `model.predict_proba()` on 5 samples across 3 classes?
2. In what column order are the probabilities arranged in `predict_proba()`?
3. Why did the "student lunch" headline have a confidence score of only 34%?
4. Why must inputs to `model.predict()` be passed inside a list?

*References*:
- Scikit-learn User Guide: *Probability calibration* (https://scikit-learn.org/stable/modules/calibration.html).
