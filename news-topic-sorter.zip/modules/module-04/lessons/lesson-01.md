# Lesson 01: Probability Foundations & Bayes' Theorem in NLP

**Lesson ID:** lesson-01  
**Module:** module-04  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- State **Bayes' Theorem** in the context of text document classification.
- Define **prior probability** $P(C)$, **likelihood** $P(D|C)$, and **posterior probability** $P(C|D)$.
- Explain the "naive" conditional independence assumption in Naive Bayes.
- Explain why the evidence denominator $P(D)$ is constant across all candidate classes during inference.

## Prerequisites
- Module 03: CountVectorizer for News.
- Basic understanding of probabilities (values between 0 and 1).

## Industry and Real-World Motivation
When diagnosing a patient based on symptoms or categorizing an article based on headline words, humans and machines reason backwards: given the observed evidence (words), what is the most probable underlying cause (topic)?

Bayes' Theorem provides the exact mathematical framework for inverting conditional probabilities. In high-speed production environments—such as spam filtering, sentiment monitoring, and real-time news routing—Bayesian text classifiers remain widely deployed because they require minimal training data, compute lightning-fast predictions, and provide mathematically grounded confidence scores.

## Concept Explanation
### Bayes' Theorem Formulation
For a news headline document $D$ composed of word features $w_1, w_2, \dots, w_n$ and a candidate topic category $C \in \{\text{food}, \text{sports}, \text{technology}\}$:

$$P(C|D) = \frac{P(D|C) \cdot P(C)}{P(D)}$$

Where:
1. **Posterior Probability $P(C|D)$**: The probability that the headline belongs to topic $C$ given that we observed document words $D$. This is what we want to calculate!
2. **Prior Probability $P(C)$**: The baseline probability of observing topic $C$ before reading any words. In our balanced dataset of 30 headlines per topic, $P(C) = \frac{30}{90} = \frac{1}{3} \approx 0.333$ for each topic.
3. **Likelihood $P(D|C)$**: The probability that a writer composing an article about topic $C$ would use the specific words in document $D$.
4. **Evidence $P(D)$**: The total probability of observing document $D$ across all possible topics:
   $$P(D) = \sum_{k} P(D|C_k) \cdot P(C_k)$$

### The "Naive" Assumption
Calculating the true joint likelihood $P(w_1, w_2, \dots, w_n | C)$ is computationally impossible for large vocabularies because words appear in endless permutations.

The Naive Bayes model makes a radically simplifying assumption: **all words are conditionally independent given the topic category**:
$$P(w_1, w_2, \dots, w_n | C) \approx \prod_{i=1}^{n} P(w_i | C)$$

Even though this assumption is linguistically false (words like "comeback" and "victory" are clearly correlated in sports), in practice it works astonishingly well for classification because the ranking of the highest-probability class remains largely unaffected.

### Decision Rule
Since $P(D)$ is identical for all candidate classes $C$, we drop the denominator and find the class that maximizes the numerator:
$$\hat{C} = \arg\max_{C} \left[ P(C) \prod_{i=1}^{n} P(w_i | C) \right]$$

## Architectural and Pipeline Context
Multinomial Naive Bayes implements this Bayesian decision rule directly on the Document-Term Matrix produced by `CountVectorizer`.

## Relevant Code
From `main.py` (lines 21, 39):
```python
from sklearn.naive_bayes import MultinomialNB
...
model = Pipeline(
    [
        ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
        ("classifier", MultinomialNB()),
    ]
)
```

## Line-by-Line Code Breakdown
- Line 21: Imports `MultinomialNB` from `sklearn.naive_bayes`.
- Line 39: Instantiates `MultinomialNB()` as the classification stage of the pipeline.

## Worked Example
Suppose we have a 1-word headline: `"recipe"`.
Assume training statistics:
- Priors: $P(\text{food}) = 0.33$, $P(\text{sports}) = 0.33$, $P(\text{tech}) = 0.33$.
- Likelihoods:
  - $P(\text{recipe}|\text{food}) = 0.08$
  - $P(\text{recipe}|\text{sports}) = 0.001$
  - $P(\text{recipe}|\text{tech}) = 0.001$

Calculate unnormalized posteriors ($P(C) \times P(\text{recipe}|C)$):
- Food: $0.33 \times 0.08 = 0.0264$
- Sports: $0.33 \times 0.001 = 0.00033$
- Tech: $0.33 \times 0.001 = 0.00033$

Total evidence: $0.0264 + 0.00033 + 0.00033 = 0.02706$

Normalized Probabilities:
- $P(\text{food}|\text{recipe}) = 0.0264 / 0.02706 \approx 97.6\%$
- $P(\text{sports}|\text{recipe}) \approx 1.2\%$
- $P(\text{tech}|\text{recipe}) \approx 1.2\%$

Decision: Confidently classify as `food`!

## Step-by-Step Student Instructions
1. Review Bayes' Theorem formula.
2. Identify the three components: Prior, Likelihood, Posterior.
3. Observe why equal priors ($1/3$ each) mean the decision depends entirely on word likelihoods.
4. Note that scikit-learn performs these multiplications in log space to prevent underflow.

## Expected Output or Observable Behaviour
- Bayesian models compute rapid probability distributions across classes.
- Words with high topic-specific likelihood dominate the product.

## Practical Exercises
- **Exercise 1.1**: If a dataset has 80 tech headlines and 20 sports headlines, what are the prior probabilities for tech and sports?
- **Exercise 1.2**: Why is the independence assumption in Naive Bayes referred to as "naive"?

## Common Mistakes and Debugging
| Misconception | Correction |
|---|---|
| Assuming Naive Bayes understands sentence syntax | Naive Bayes treats words as independent draws from a category bag |
| Thinking the denominator $P(D)$ changes between classes | $P(D)$ is the same constant normalization factor for all classes in a given document |
| Believing Naive Bayes cannot handle multi-class problems | Naive Bayes natively handles any number of discrete classes $K \ge 2$ |

## Best Practices and Operational Considerations
- Keep class proportions balanced when collecting data so priors don't unfairly bias predictions toward the majority class.
- Compute probabilities using logarithms ($\log P(C) + \sum \log P(w|C)$) to prevent floating-point arithmetic underflow.

## Summary and Key Takeaways
- Bayes' Theorem calculates posterior probability $P(C|D)$ from prior $P(C)$ and word likelihoods $P(D|C)$.
- The naive independence assumption treats all words as conditionally independent given the topic.
- The highest unnormalized numerator determines the predicted class.

## Knowledge-Check Questions and References
1. What are the four mathematical terms in Bayes' Theorem?
2. What is the prior probability $P(C)$ in a balanced 3-class dataset?
3. What is the "naive" assumption made by Naive Bayes?
4. Why can we ignore the denominator $P(D)$ when determining the winning class?

*References*:
- Russell, S., & Norvig, P. (2020). *Artificial Intelligence: A Modern Approach (4th ed.)*, Chapter 12: Quantifying Uncertainty.
