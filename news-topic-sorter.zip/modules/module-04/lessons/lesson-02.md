# Lesson 02: The Multinomial Naive Bayes Algorithm & Laplace Smoothing

**Lesson ID:** lesson-02  
**Module:** module-04  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain the difference between Gaussian, Bernoulli, and Multinomial Naive Bayes.
- Calculate conditional word probabilities using token count frequencies.
- Explain the **zero-frequency problem** when an unseen word is encountered.
- Apply **additive Laplace smoothing ($\alpha = 1.0$)** to eliminate zero probabilities.

## Prerequisites
- Lesson 01: Probability Foundations & Bayes' Theorem in NLP.
- Basic algebraic fractions and counting.

## Industry and Real-World Motivation
Imagine a news classifier that has learned thousands of words across sports and technology. Suddenly, a new sports headline contains the word `"badminton"`, which happened not to appear in the training split. 

Without smoothing, the probability $P(\text{badminton}|\text{sports})$ would be exactly $0$. Because Naive Bayes multiplies all word probabilities together, that single zero would multiply the entire expression to zero:
$$P(\text{sports}) \times P(\text{player}|\text{sports}) \times 0 \times P(\text{championship}|\text{sports}) = 0$$
The model would conclude that there is a 0% chance the headline is about sports, completely wiping out all other overwhelming evidence! Additive **Laplace smoothing** is the industry-standard safeguard that prevents this catastrophic failure mode.

## Concept Explanation
### Multinomial Naive Bayes
Scikit-learn provides multiple Naive Bayes variants:
- **GaussianNB**: Assumes continuous features following a normal (Gaussian) distribution (e.g., sensor readings).
- **BernoulliNB**: Designed for binary boolean features (word presence/absence: 0 or 1).
- **MultinomialNB**: Specifically designed for discrete frequency counts (word counts in Bag-of-Words).

In Multinomial Naive Bayes, a document is modeled as a sequence of draws from a multinomial distribution over vocabulary words.

### Word Likelihood Without Smoothing
The basic maximum likelihood estimate of word $w$ in class $c$ is:
$$P(w|c) = \frac{N_{c, w}}{N_c}$$
Where $N_{c, w}$ is the count of word $w$ in class $c$, and $N_c$ is the total count of all words in class $c$.

### The Zero-Frequency Problem & Laplace Smoothing
If word $w$ never appeared in class $c$ during training, $N_{c, w} = 0$, leading to $P(w|c) = 0$.

To solve this, **Laplace smoothing** adds a pseudo-count $\alpha > 0$ (default $\alpha = 1.0$) to every word's count, and adds $\alpha \times |V|$ to the denominator:
$$P(w|c) = \frac{N_{c, w} + \alpha}{N_c + \alpha |V|}$$
Where:
- $N_{c, w}$ = Number of times word $w$ appears in class $c$ in the training data.
- $N_c$ = Total word count across all documents belonging to class $c$.
- $|V|$ = Total size of the vocabulary (282 features in our project).
- $\alpha$ = Smoothing parameter (default $\alpha = 1.0$, known as Laplace smoothing).

With Laplace smoothing:
- Even if $N_{c, w} = 0$, the numerator becomes $0 + 1 = 1$.
- The probability is small but strictly positive ($\frac{1}{N_c + |V|} > 0$), preventing any single word from destroying the entire probability product.

## Architectural and Pipeline Context
Scikit-learn's `MultinomialNB()` applies Laplace smoothing with $\alpha=1.0$ by default:
```python
MultinomialNB(alpha=1.0)
```
The smoothed probabilities are converted into natural logarithms (`feature_log_prob_`) to ensure numerical stability.

## Relevant Code
From `main.py` (lines 39, 58):
```python
model = Pipeline(
    [
        ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
        ("classifier", MultinomialNB()), # Default alpha=1.0
    ]
)
...
top = np.argsort(classifier.feature_log_prob_[index])[-8:][::-1]
```

## Line-by-Line Code Breakdown
- Line 39: Instantiates `MultinomialNB()` with default parameter `alpha=1.0`.
- Line 58: Accesses `classifier.feature_log_prob_`, which stores the smoothed $\log P(w|c)$ values for each class and vocabulary feature.

## Worked Example
Suppose class `sports` has a total word count $N_{\text{sports}} = 500$ across all training articles, and the vocabulary size $|V| = 282$.
Let $\alpha = 1.0$.

Case 1: Word `"goal"` appeared 25 times in sports training data:
$$P(\text{goal}|\text{sports}) = \frac{25 + 1}{500 + 1 \times 282} = \frac{26}{782} \approx 0.0332$$

Case 2: Word `"pasta"` appeared 0 times in sports training data:
$$P(\text{pasta}|\text{sports}) = \frac{0 + 1}{500 + 1 \times 282} = \frac{1}{782} \approx 0.00128$$

Notice that `"pasta"` receives a small probability ($0.00128$) rather than zero. When a headline about a sports match mentions pasta, the model won't crash or zero out sports entirely!

## Step-by-Step Student Instructions
1. Open a Python shell.
2. Import `MultinomialNB` from `sklearn.naive_bayes`.
3. Check the default parameters using `MultinomialNB().get_params()`.
4. Verify that `'alpha': 1.0` and `'fit_prior': True` are the default settings.

## Expected Output or Observable Behaviour
- Instantiating `MultinomialNB()` creates a classifier ready to handle sparse non-negative integer count matrices.
- The default $\alpha = 1.0$ guarantees that no feature probability will ever equal zero.

## Practical Exercises
- **Exercise 2.1**: What would happen if you set `MultinomialNB(alpha=0.0)` and encountered an unseen word during testing?
- **Exercise 2.2**: If $|V| = 100$, $N_c = 400$, and a word appears 10 times, calculate the Laplace smoothed probability with $\alpha = 1.0$.

## Common Mistakes and Debugging
| Mistake | Consequence | Proper Approach |
|---|---|---|
| Using `GaussianNB` on Bag-of-Words count data | Assumes bell-curve continuous data, performing poorly on sparse discrete word counts | Use `MultinomialNB` for text count data |
| Setting `alpha=0` | Causes zero-division or zero-multiplication errors on out-of-vocabulary words | Always retain positive smoothing ($\alpha \ge 0.1$, default 1.0) |
| Using `MultinomialNB` on negative values | Multinomial distributions require non-negative counts; negative values raise `ValueError` | Ensure inputs are raw counts or TF-IDF values ($\ge 0$) |

## Best Practices and Operational Considerations
- Leave $\alpha = 1.0$ as the baseline; for very large datasets, tuning $\alpha$ via grid search (e.g., between 0.1 and 1.0) can provide minor performance optimizations.
- Use log-probabilities for all calculations to prevent mathematical floating-point underflow.

## Summary and Key Takeaways
- Multinomial Naive Bayes is designed specifically for discrete count data like text word frequencies.
- Without smoothing, unobserved words cause zero probabilities that wipe out the entire probability product.
- Laplace smoothing ($\alpha = 1.0$) adds 1 to all word counts, ensuring all conditional probabilities remain positive.

## Knowledge-Check Questions and References
1. Why is `MultinomialNB` preferred over `GaussianNB` for text classification?
2. What is the "zero-frequency problem" in Naive Bayes?
3. How does Laplace smoothing modify the numerator and denominator of the word likelihood formula?
4. What is the default value of the smoothing parameter $\alpha$ in scikit-learn?

*References*:
- Scikit-learn User Guide: *Naive Bayes — Multinomial Naive Bayes* (https://scikit-learn.org/stable/modules/naive_bayes.html#multinomial-naive-bayes).
