# Lesson 03: Model Training & Fitting the Pipeline

**Lesson ID:** lesson-03  
**Module:** module-04  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Execute `model.fit(X_train, y_train)` to train the classification pipeline.
- Explain what happens internally during the `.fit()` call for both vectorizer and classifier.
- Inspect the learned class log-priors (`class_log_prior_`) and feature log-probabilities (`feature_log_prob_`).
- Verify training completion without data leakage.

## Prerequisites
- Lesson 02: The Multinomial Naive Bayes Algorithm & Laplace Smoothing.
- Understanding of training vs. testing data splits.

## Industry and Real-World Motivation
Training a machine learning model is the process of estimating mathematical parameters from historical data. In deep neural networks, fitting requires hours or days of intensive backpropagation across GPU clusters. 

In contrast, fitting a Multinomial Naive Bayes model requires only a single rapid pass through the training data to tally word counts. This makes Naive Bayes training virtually instantaneous—taking less than 50 milliseconds on our dataset. This speed allows rapid iteration, frequent retraining on live data streams, and low-cost deployment.

## Concept Explanation
### What Happens When You Call `model.fit(X_train, y_train)`?
Because `model` is a scikit-learn `Pipeline`, calling `.fit()` initiates a coordinated sequence:

1. **Step 1: Vectorizer Fitting**:
   - `CountVectorizer` reads the 67 headlines in `X_train`.
   - It strips stop words, extracts unigrams and bigrams, and builds the vocabulary of 282 features.
   - It computes the sparse count matrix for the 67 training documents.
2. **Step 2: Classifier Fitting**:
   - `MultinomialNB` receives the count matrix and the class labels in `y_train`.
   - It computes the prior probability for each class $P(C)$ based on class counts:
     - `food`: 23 / 67
     - `sports`: 22 / 67
     - `technology`: 22 / 67
   - It aggregates the word counts for each class and applies Laplace smoothing ($\alpha = 1.0$).
   - It calculates the log feature probabilities:
     $$\log P(w_j | C_k)$$
     storing the resulting $(3, 282)$ matrix in `classifier.feature_log_prob_`.

### Inspecting Learned Parameters
After fitting, the classifier contains:
- `classifier.classes_`: `array(['food', 'sports', 'technology'])`
- `classifier.class_count_`: `array([23., 22., 22.])`
- `classifier.class_log_prior_`: Natural log of class priors:
  $$\log(23/67) \approx -1.069, \quad \log(22/67) \approx -1.114$$
- `classifier.feature_log_prob_`: Shape $(3, 282)$, containing the log likelihood of every word given each topic.

## Architectural and Pipeline Context
The pipeline structure guarantees that only training data touches the fitting process:
```
X_train (67 strings) ──> vectorizer.fit_transform() ──> Count Matrix (67 x 282)
                                                                │
y_train (67 labels)  ───────────────────────────────────────────┴──> classifier.fit()
```

## Relevant Code
From `main.py` (lines 42, 52-55):
```python
    model.fit(X_train, y_train)
...
    vectorizer = model.named_steps["vectorizer"]
    classifier = model.named_steps["classifier"]
    names = vectorizer.get_feature_names_out()
    classes = list(classifier.classes_)
```

## Line-by-Line Code Breakdown
- Line 42: `model.fit(X_train, y_train)` fits both the vectorizer and classifier in a single atomic call.
- Lines 52-53: Extracts the trained component instances for introspection.
- Line 54: Extracts the 282 vocabulary feature names.
- Line 55: Converts the array of learned class labels into a standard Python list.

## Worked Example
Let's verify the shape of the learned parameter matrices in Python:
```python
import numpy as np
# After fitting:
classifier = model.named_steps["classifier"]
print("Classes:", classifier.classes_)
# ['food' 'sports' 'technology']
print("Class counts:", classifier.class_count_)
# [23. 22. 22.]
print("Feature log prob shape:", classifier.feature_log_prob_.shape)
# (3, 282)
```
The shape `(3, 282)` reflects:
- 3 rows: one row per topic category.
- 282 columns: one column per vocabulary feature.
- Each entry $(i, j)$ is the natural log probability $\log P(\text{word}_j | \text{topic}_i)$.

## Step-by-Step Student Instructions
1. Open a Python terminal and execute lines 1-42 of `main.py`.
2. Inspect `classifier = model.named_steps["classifier"]`.
3. Check `classifier.class_count_` and confirm it sums to 67.
4. Check `classifier.feature_log_prob_.shape` and confirm it is `(3, 282)`.

## Expected Output or Observable Behaviour
- The fitting operation completes silently in a fraction of a second.
- The pipeline transitions from an unfitted configuration to a fully parameterized model capable of making predictions.

## Practical Exercises
- **Exercise 3.1**: Why are feature probabilities stored as log-probabilities (`feature_log_prob_`) rather than standard probabilities?
- **Exercise 3.2**: Write code to convert `classifier.class_log_prior_` back into standard percentages using `np.exp()`.

## Common Mistakes and Debugging
| Mistake | Error | Correction |
|---|---|---|
| Passing test data to `fit`: `model.fit(X_test, y_test)` | Severe data leakage and testing invalidation | Always fit exclusively on `X_train, y_train` |
| Calling `.fit()` multiple times on different subsets | Overwrites previously learned parameters | Fit once on the full training set |
| Passing non-string inputs to text pipeline | `AttributeError: 'float' object has no attribute 'lower'` | Ensure all entries in text series are clean string objects |

## Best Practices and Operational Considerations
- Always verify training set size and class counts after fitting to ensure no rows were accidentally dropped.
- Keep training code modular so new datasets can be passed without modifying pipeline architecture.

## Summary and Key Takeaways
- `model.fit(X_train, y_train)` fits both the vectorizer (vocabulary creation) and classifier (probability estimation).
- Training fits 67 headlines across 3 topics with 282 vocabulary features.
- Learned parameters include class priors and a $(3, 282)$ matrix of feature log-probabilities.

## Knowledge-Check Questions and References
1. What two major steps occur when `model.fit()` is called on this pipeline?
2. How many samples are in `X_train` during model fitting?
3. What is the shape of `classifier.feature_log_prob_`?
4. What mathematical function reverses log-probabilities back to standard probabilities?

*References*:
- Scikit-learn Pipeline documentation: https://scikit-learn.org/stable/modules/generated/sklearn.pipeline.Pipeline.html#sklearn.pipeline.Pipeline.fit
