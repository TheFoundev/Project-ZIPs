# Module 2 Exercises: Data Exploration & Lexical Analysis

## Exercise 2.1: Dataset Balance & Split Audit (15 min)
**Objective:** Calculate class distributions and verify stratified splitting mathematically.
**Problem Statement:** Audit the dataset at `data/headlines.csv` to confirm class balance, then compute the exact sample counts resulting from a 75/25 stratified split.

**Requirements:**
1. Load `data/headlines.csv` using pandas.
2. Print the value counts of the `topic` column. Confirm the count for each of the 3 classes.
3. Apply `train_test_split(df["headline"], df["topic"], test_size=0.25, random_state=42, stratify=df["topic"])`.
4. Verify the exact length of `X_train` and `X_test`.
5. Verify the class counts in `y_test`.

**Acceptance Criteria:**
- [ ] Confirms exactly 30 samples per topic in full dataset (90 total).
- [ ] Confirms `len(X_train) == 67` and `len(X_test) == 23`.
- [ ] Confirms `y_test` distribution: 8 technology, 8 sports, 7 food.

---

## Exercise 2.2: Cross-Domain Boundary Analysis (15 min)
**Objective:** Formulate and evaluate cross-domain headlines that induce semantic ambiguity.
**Problem Statement:** Create 3 hybrid headlines combining topics and analyze how a word-frequency classifier evaluates them.

**Requirements:**
1. Write one headline combining `sports` + `technology` (e.g., GPS tracking in soccer).
2. Write one headline combining `food` + `technology` (e.g., automated restaurant ordering kiosks).
3. Write one headline combining `sports` + `food` (e.g., Olympic marathon runner nutrition).
4. Identify which specific words in each headline pull toward each topic.

**Acceptance Criteria:**
- [ ] Three hybrid headlines created with clear cross-domain vocabulary.
- [ ] Explicit identification of competing keywords for each topic.
- [ ] Thoughtful explanation of why boundary cases produce lower probability confidence.
