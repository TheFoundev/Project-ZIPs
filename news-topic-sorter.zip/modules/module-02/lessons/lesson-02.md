# Lesson 02: Class Distribution & Stratified Splitting

**Lesson ID:** lesson-02  
**Module:** module-02  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Calculate class frequencies using pandas `value_counts()`.
- Define balanced vs. imbalanced datasets and explain their impact on classification.
- Explain the purpose and mechanics of **stratified sampling** (`stratify=df['topic']`).
- Verify the exact sample counts in the training set (67) and testing set (23).

## Prerequisites
- Lesson 01: Loading & Inspecting News Headlines.
- Basic understanding of train/test splitting.

## Industry and Real-World Motivation
In real-world data science, class imbalance is a pervasive challenge. For instance, in fraud detection, 99.9% of transactions are legitimate and only 0.1% are fraudulent. A naive model that always predicts "legitimate" would achieve 99.9% accuracy while being completely useless.

Even when a source dataset is balanced, a random train/test split might accidentally place 80% of one category into the test set and only 20% into the training set—especially when working with small datasets. **Stratified sampling** guarantees that both training and testing sets retain the exact proportion of each class, ensuring equitable training and fair evaluation.

## Concept Explanation
### Class Distribution Analysis
When we inspect `df["topic"].value_counts()` on `headlines.csv`:
- `technology`: 30 samples (33.33%)
- `sports`: 30 samples (33.33%)
- `food`: 30 samples (33.33%)
- Total: 90 samples (100.0%)

This represents an **ideally balanced multi-class dataset**. Every class has identical representation, meaning no single category possesses an unfair prior probability advantage during training.

### Stratified Train/Test Split
In `main.py`, the data is partitioned with:
```python
X_train, X_test, y_train, y_test = train_test_split(
    df["headline"], df["topic"], test_size=0.25, random_state=42, stratify=df["topic"]
)
```
- `test_size=0.25`: Allocates 25% of the data to the test set ($90 	imes 0.25 = 22.5 ightarrow 23$ samples) and 75% to the training set ($67$ samples).
- `random_state=42`: Seeds the pseudorandom number generator, ensuring identical splits across all student machines.
- `stratify=df["topic"]`: Enforces proportional sampling within each topic subgroup.

### Resulting Partition Distribution:
- **Training Set (67 total)**:
  - `food`: 23 samples
  - `sports`: 22 samples
  - `technology`: 22 samples
- **Testing Set (23 total)**:
  - `technology`: 8 samples
  - `sports`: 8 samples
  - `food`: 7 samples

Notice that each class accounts for approximately one-third of both subsets.

## Architectural and Pipeline Context
The split separates the data before any vectorization or model fitting occurs:
```
All Headlines (90) ──[ Stratified Split ]──┬──> X_train (67) ──> model.fit()
                                           └──> X_test  (23) ──> model.predict()
```

## Relevant Code
From `main.py` (lines 32-34):
```python
    X_train, X_test, y_train, y_test = train_test_split(
        df["headline"], df["topic"], test_size=0.25, random_state=42, stratify=df["topic"]
    )
```

## Line-by-Line Code Breakdown
- Line 32: Unpacks the four partition subsets returned by `train_test_split`.
- Line 33: Passes features `df["headline"]` and targets `df["topic"]`. Specifies `test_size=0.25` (25% holdout).
- Line 34: Sets `random_state=42` for reproducibility and passes `stratify=df["topic"]` to mandate balanced class proportions across both splits.

## Worked Example
What happens if we omit `stratify=df["topic"]` on small datasets?
Suppose a random split selected 15 food headlines for testing out of 23 test slots:
- Food in test: 15 / 30 = 50% of all food data removed from training!
- Training set now only has 15 food headlines, while having 26 tech and 26 sports headlines.
- The model would become biased toward predicting tech and sports, and underpredict food.
With `stratify=df["topic"]`, scikit-learn performs sampling independently within each class group, guaranteeing 7 or 8 samples per class in the test set.

## Step-by-Step Student Instructions
1. Run a Python shell and load the headlines dataset.
2. Execute `df["topic"].value_counts()` and observe that each class has exactly 30 samples.
3. Import `train_test_split` from `sklearn.model_selection`.
4. Perform the stratified split using the exact parameters from `main.py`.
5. Run `y_test.value_counts()` to verify that the test set contains 8 tech, 8 sports, and 7 food samples.

## Expected Output or Observable Behaviour
```python
>>> y_test.value_counts()
topic
technology    8
sports        8
food          7
Name: count, dtype: int64
```
Total test count equals 23, with balanced representation across all three topics.

## Practical Exercises
- **Exercise 2.1**: What would the test set size be if `test_size=0.20` was used instead of `0.25`?
- **Exercise 2.2**: Why is setting `random_state` essential when publishing research benchmarks or comparing models?

## Common Mistakes and Debugging
| Mistake | Consequence | Correction |
|---|---|---|
| Omitting `stratify=df["topic"]` | Risk of unbalanced partitions where some classes are underrepresented in training | Always include `stratify=y` in classification splitting |
| Passing feature matrix $X$ as a 2D DataFrame with column list `df[["headline"]]` | Works, but `CountVectorizer` prefers a 1D Series or list of strings | Pass 1D series: `df["headline"]` |
| Swapping the order of unpacked variables | `X_train, y_train, X_test, y_test` creates mismatched feature/target assignments | Follow standard order: `X_train, X_test, y_train, y_test` |

## Best Practices and Operational Considerations
- Always verify class distributions before and after splitting using `.value_counts()`.
- Use stratified splitting for all classification problems, especially when sample counts are limited.

## Summary and Key Takeaways
- The dataset is perfectly balanced with 30 headlines per topic (90 total).
- `test_size=0.25` yields 67 training headlines and 23 testing headlines.
- `stratify=df["topic"]` guarantees that each category is proportionally represented in both training and testing sets.

## Knowledge-Check Questions and References
1. How many headlines belong to each topic in `data/headlines.csv`?
2. What is the size of the test partition when splitting 90 rows with `test_size=0.25`?
3. What problem does stratified sampling prevent?
4. How many food headlines are in the test set after stratified splitting?

*References*:
- Scikit-learn User Guide: *Cross-validation: evaluating estimator performance* (https://scikit-learn.org/stable/modules/cross_validation.html#stratification).
