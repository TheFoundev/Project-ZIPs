# Lesson 03: Vocabulary Patterns & Distinctive Lexicons

**Lesson ID:** lesson-03  
**Module:** module-02  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain what constitutes a distinctive topic vocabulary or domain lexicon.
- Identify characteristic terminology for sports, technology, and food headlines.
- Understand how word co-occurrence creates topic identity.
- Explain why common conversational words lack discriminative power.

## Prerequisites
- Lesson 02: Class Distribution & Stratified Splitting.
- Intuitive understanding of word frequencies in natural language.

## Industry and Real-World Motivation
Search engines, spam filters, and news topic sorters all rely on a core linguistic principle: **domain-specific lexical concentration**. When people write about cooking, they naturally use culinary nouns and verbs (bake, simmer, garlic, chef). When writing about athletic competitions, they use competitive vocabulary (tournament, score, stadium, trophy). 

Recognizing these domain lexicons allows machine learning algorithms to map documents to topic concepts without needing to understand deep sentence semantics or world knowledge.

## Concept Explanation
A topic's **distinctive lexicon** consists of words and phrases that appear with high frequency inside that topic's articles but are virtually absent from other topics.

### Lexical Breakdown Across the 3 Categories:

1. **Food Lexicon**:
   - Nouns: `recipe`, `noodles`, `pasta`, `vegetables`, `market`, `cafe`, `vendors`, `chef`
   - Adjectives: `spicy`, `delicious`, `healthy`, `colorful`, `local`
   - Bigrams: `street food`, `farmers market`, `quick recipes`

2. **Sports Lexicon**:
   - Nouns: `cricket`, `league`, `stadium`, `championship`, `match`, `captain`, `team`
   - Verbs: `scores`, `wins`, `announces`, `return`
   - Bigrams: `comeback victory`, `summer schedule`, `sold out`

3. **Technology Lexicon**:
   - Nouns: `cybersecurity`, `ai`, `python`, `battery`, `smartphone`, `phishing`, `gadgets`
   - Verbs: `warn`, `unveil`, `train`, `folds`, `debugging`
   - Bigrams: `faster way`, `open source`, `battery life`

### High vs. Low Discriminative Words
- **High Discriminative Power**: Words like `pasta` or `cybersecurity`. If the word `pasta` appears in a headline, the probability that the topic is `food` is near 100%.
- **Low Discriminative Power**: Words like `new`, `city`, `week`, `announces`. A tech company can announce a new phone, a team can announce a new schedule, or a restaurant can announce a new menu.

## Architectural and Pipeline Context
The classifier's effectiveness hinges on having enough discriminative words in each headline. If a headline consists solely of generic words, the classifier struggles to differentiate between classes.

## Relevant Code
From `main.py` (lines 56-60):
```python
    print("Strongest words per topic:")
    for index, topic in enumerate(classes):
        top = np.argsort(classifier.feature_log_prob_[index])[-8:][::-1]
        print(f"  {topic:10s}: {', '.join(names[top])}")
```

## Line-by-Line Code Breakdown
- Line 56: Prints console header announcing strongest words.
- Line 57: Loops over each topic class in alphabetical order (`food`, `sports`, `technology`).
- Lines 58-59: Sorts the learned feature log-probabilities to extract and print the 8 most distinctive words and n-grams for that specific topic.

## Worked Example
When `main.py` completes execution, it outputs the actual top learned words:
- **Food**: `food`, `street`, `street food`, `recipe`, `expands weekend`, `farmers market`, `farmers`, `expands`
- **Sports**: `announces`, `comeback victory`, `twice comeback`, `twice`, `cricket`, `cricket league`, `league announces`, `comeback`
- **Technology**: `new`, `ai`, `train`, `unveil faster`, `unveil`, `faster`, `faster way`, `train small`

Notice how each category's top words reflect distinct conceptual domains. Even multi-word bigrams like `farmers market` or `comeback victory` emerge as powerful topic anchors.

## Step-by-Step Student Instructions
1. Inspect `data/headlines.csv` manually.
2. Select 5 random headlines from each topic.
3. Circle the words that are unique to that topic.
4. Verify whether words like `new` or `opens` appear across multiple topics.

## Expected Output or Observable Behaviour
Students observe that topics have clearly distinguishable vocabulary clusters, but also share a pool of generic verbs (`announces`, `opens`, `reveals`) and modifiers (`new`, `top`, `faster`).

## Practical Exercises
- **Exercise 3.1**: List 3 words that would be almost exclusively found in technology headlines, 3 in food, and 3 in sports.
- **Exercise 3.2**: Explain why the word `new` appears in the top words for technology even though it is not exclusively technical.

## Common Mistakes and Debugging
| Misconception | Reality |
|---|---|
| Thinking every word in a headline must be domain-specific | Real headlines combine common grammatical scaffolding with 1-3 domain-specific anchor words |
| Assuming short headlines don't contain enough signal | Even 6-word headlines typically contain 2-3 highly diagnostic keywords |
| Relying only on single words (unigrams) | Phrases like "street food" or "comeback victory" provide much stronger topic signals than "street" or "comeback" alone |

## Best Practices and Operational Considerations
- Use n-grams (bigrams and trigrams) to capture compound domain concepts (`machine learning`, `ice cream`, `world cup`).
- Filter out domain-agnostic stop words so common terms don't drown out informative signals.

## Summary and Key Takeaways
- Each news category is defined by a distinctive lexicon of domain-specific nouns, verbs, and phrases.
- High-discriminative words provide unambiguous classification evidence, while generic words offer little differentiation.
- Capturing both single words and compound phrases (n-grams) strengthens topic separation.

## Knowledge-Check Questions and References
1. Name two distinctive keywords for the food category in the project.
2. Why is the word `recipe` more discriminative than the word `announced`?
3. How do bigrams like `comeback victory` help identify topics?
4. What happens when a headline contains only non-discriminative words?

*References*:
- Bird, S., Klein, E., & Loper, E. (2009). *Natural Language Processing with Python*, Chapter 2: Accessing Text Corpora and Lexical Resources.
