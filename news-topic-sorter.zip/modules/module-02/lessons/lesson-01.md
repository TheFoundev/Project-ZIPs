# Lesson 01: Loading & Inspecting News Headlines

**Lesson ID:** lesson-01  
**Module:** module-02  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Load `data/headlines.csv` into a pandas DataFrame using `pd.read_csv()`.
- Inspect the schema, column names, data types, and total observation count.
- Verify data hygiene (absence of null values, unexpected data types, or missing columns).
- Separate the input feature vector ($X$) from the target label vector ($y$).

## Prerequisites
- Module 01: Project Overview & News Categorization at Scale.
- Basic understanding of tabular CSV structures and pandas.

## Industry and Real-World Motivation
Data quality is the foremost determinant of machine learning success ("garbage in, garbage out"). In industrial text processing, incoming text files often contain formatting defects: corrupted encodings (e.g., UTF-8 vs Latin-1), unescaped quotation marks, blank lines, or mismatched column delimiters. 

Before passing any raw text into tokenizers or vectorizers, machine learning engineers must inspect the DataFrame shape, confirm that headers match expected schemas, and verify that text rows are non-empty strings.

## Concept Explanation
The News Topic Sorter uses a curated dataset stored at `data/headlines.csv`. 

### Dataset Schema
The CSV contains exactly two columns:
1. `headline`: The textual news headline (string). This serves as the predictive feature ($X$).
2. `topic`: The editorial topic label (string: `sports`, `technology`, or `food`). This serves as the ground-truth target ($y$).

When loaded via pandas:
```python
df = pd.read_csv(DATA / "headlines.csv")
```
Pandas reads the first line as column headers and infers the object (string) data type for both columns. The dataset contains 90 rows of headlines.

Unlike numeric datasets where features occupy multiple columns (e.g., temperature, humidity, wind speed), raw NLP classification datasets frequently have a single feature column containing arbitrary-length text strings.

## Architectural and Pipeline Context
Loading the data cleanly is the entry point of the pipeline in `main.py`:
```
data/headlines.csv ──> pd.read_csv() ──> DataFrame (90, 2) ──> Feature/Target Separation
```
The feature sequence `df["headline"]` represents a 1D pandas Series of text documents, while `df["topic"]` represents a 1D pandas Series of categorical labels.

## Relevant Code
From `main.py` (lines 31-33):
```python
def main() -> None:
    df = pd.read_csv(DATA / "headlines.csv")
    X_train, X_test, y_train, y_test = train_test_split(
        df["headline"], df["topic"], test_size=0.25, random_state=42, stratify=df["topic"]
    )
```

## Line-by-Line Code Breakdown
- Line 31: `df = pd.read_csv(DATA / "headlines.csv")` opens and reads the CSV file from the `data` directory into a pandas `DataFrame`.
- Line 32-33: Accesses `df["headline"]` as the input features ($X$) and `df["topic"]` as the target labels ($y$) directly within the arguments of `train_test_split`.

## Worked Example
Let's inspect the first 5 rows of `data/headlines.csv`:
```
headline,topic
Cybersecurity experts warn about a new phishing scam,technology
Cricket league announces its summer schedule,sports
Tech conference highlights affordable health gadgets,technology
Chef shares a five-minute recipe for spicy noodles,food
Star player scores twice in comeback victory,sports
```
In Python:
```python
import pandas as pd
df = pd.read_csv("data/headlines.csv")
print(df.shape)       # Output: (90, 2)
print(df.columns)     # Output: Index(['headline', 'topic'], dtype='object')
print(df.isnull().sum())
# headline    0
# topic       0
# dtype: int64
```
Both columns have zero missing values across all 90 rows.

## Step-by-Step Student Instructions
1. Open a Python terminal or scratch script.
2. Import pandas and load `data/headlines.csv`.
3. Check the shape using `df.shape`. Confirm that it reports 90 rows and 2 columns.
4. Print the first 5 rows using `df.head()`.
5. Check for null values using `df.isna().sum()`.

## Expected Output or Observable Behaviour
- `df.shape` returns `(90, 2)`.
- `df.dtypes` shows `object` for both `headline` and `topic`.
- Headings display clean string text without NaN or null entries.

## Practical Exercises
- **Exercise 1.1**: Write a single line of pandas code to print the average character length of headlines in `df`.
- **Exercise 1.2**: What happens if a CSV file contains a blank line at the end? How does pandas handle it by default?

## Common Mistakes and Debugging
| Common Mistake | Symptom / Error | Resolution |
|---|---|---|
| Misspelling the column name as `df['headlines']` or `df['text']` | `KeyError: 'headlines'` | Check `df.columns` to verify exact column names (`'headline'` and `'topic'`) |
| Passing entire DataFrame `df` instead of `df["headline"]` to vectorizer | Vectorizer fails expecting 1D iterable of strings | Extract single column Series: `df["headline"]` |
| File path not found | `FileNotFoundError: [Errno 2] No such file or directory` | Use absolute or dynamically resolved path `DATA / "headlines.csv"` |

## Best Practices and Operational Considerations
- Always inspect `df.info()` or `df.isnull().sum()` immediately after reading any CSV.
- Confirm string encoding: When dealing with international news text containing accents or emojis, ensure `encoding="utf-8"` is specified.

## Summary and Key Takeaways
- `data/headlines.csv` consists of 90 rows and 2 columns: `headline` (features) and `topic` (target).
- Both columns contain complete, non-null textual data.
- In NLP, features are typically represented as a 1D sequence of document strings.

## Knowledge-Check Questions and References
1. How many total headlines are present in `data/headlines.csv`?
2. What are the exact names of the two columns in the dataset?
3. Which column is used as the feature ($X$) and which as the target ($y$)?
4. What data type does pandas assign to text columns by default?

*References*:
- McKinney, W. (2022). *Python for Data Analysis (3rd ed.)*, Chapter 6: Data Loading, Storage, and File Formats.
