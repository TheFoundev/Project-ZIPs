# Module 1 Exercises: News Topic Sorter Architecture & Setup

## Exercise 1.1: Multi-Class Problem Framing (15 min)
**Objective:** Define the supervised multi-class problem formulation for news topic classification.
**Problem Statement:** You are designing an automated content routing engine for an online publication that covers sports, technology, and food. You must establish the formal machine learning definition of this task.

**Requirements:**
1. State the input space ($X$) and target label space ($Y$).
2. Explain why this problem is multi-class classification and NOT binary classification or regression.
3. Define the mathematical constraint on the predicted class probabilities for any given headline.

**Acceptance Criteria:**
- [ ] Correctly identifies $X$ as headline text strings and $Y = \{\text{sports}, \text{technology}, \text{food}\}$.
- [ ] Accurately defines multi-class classification ($K=3$ mutually exclusive classes).
- [ ] Explains that probabilities must satisfy $0 \le P(y=c|x) \le 1$ and $\sum P(y=c|x) = 1.0$.

---

## Exercise 1.2: Directory & Environment Verification (15 min)
**Objective:** Verify the project directory structure, dependencies, and dynamic path resolution.
**Problem Statement:** Inspect the filesystem and confirm that the Python environment contains all required scientific libraries.

**Requirements:**
1. Navigate to the project root directory.
2. Confirm the presence of `main.py` and `data/headlines.csv`.
3. Test that `pandas`, `numpy`, `matplotlib`, and `sklearn` can be imported without errors.
4. Execute `python3 main.py` and confirm that `outputs/confusion_matrix.png` and `outputs/predictions.txt` are created.

**Acceptance Criteria:**
- [ ] All four Python dependencies verified in environment.
- [ ] Script executes to completion without errors.
- [ ] Both output files verified in `outputs/`.
