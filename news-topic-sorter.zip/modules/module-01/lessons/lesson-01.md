# Lesson 01: The News Sorting Problem & Digital Newsrooms

**Lesson ID:** lesson-01  
**Module:** module-01  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Formulate the business and technical problem that the News Topic Sorter solves.
- Explain why modern digital news portals (Google News, Apple News, RSS feeds) require automated text classification.
- Contrast automated algorithmic sorting with manual editorial tagging in terms of latency, scalability, and operational cost.
- Identify the three news categories used in this project: sports, technology, and food.

## Prerequisites
- Familiarity with basic computer science terminology (inputs, outputs, automation).
- General awareness of news feeds and digital media publishing workflows.

## Industry and Real-World Motivation
Every single minute, global news publishers, wire services (like Reuters and Associated Press), and independent blogs produce tens of thousands of articles. Leading aggregators like Google News, Yahoo News, and Feedly ingest these incoming data streams in real time. 

If human editors had to manually review, tag, and assign each incoming article to specific section pages (e.g., Tech, Sports, Lifestyle), massive bottlenecks would form. A breaking news headline about a championship match or a major software vulnerability would sit in an editorial backlog for hours instead of reaching readers in milliseconds. Automated multi-class topic categorization enables real-time content delivery, dynamic push notifications, and personalized user feeds.

## Concept Explanation
The News Topic Sorter addresses a classic Natural Language Processing (NLP) task: **supervised multi-class document routing**.

In our scenario, each incoming article headline is represented as a raw text string. The machine learning model must evaluate the words within the headline and assign it to one of three predefined editorial buckets:
1. **Sports**: Athletic events, matches, scores, championships, player injuries.
2. **Technology**: Software developments, hardware releases, artificial intelligence, cybersecurity.
3. **Food**: Recipes, culinary trends, restaurant openings, food festivals, nutrition.

Because the set of target classes contains three distinct categories, this problem cannot be solved using a standard binary classifier (which only handles two categories, such as spam vs. ham). Instead, the model calculates probability distributions across all three classes simultaneously and selects the category with the highest likelihood.

## Architectural and Pipeline Context
The News Topic Sorter operates as a sequential decision system:
1. Ingestion: Raw headline strings enter the pipeline from `data/headlines.csv`.
2. Representation: Words are transformed into numerical frequencies using Bag-of-Words vectorization.
3. Decision Engine: A Multinomial Naive Bayes model estimates topic likelihoods.
4. Output Routing: The system assigns the dominant topic label and records diagnostic confidence scores.

This modular structure allows the same underlying engine to scale from 3 topics to 50 topics in production environments.

## Relevant Code
From `main.py` (lines 1-8):
```python
"""Project 19: The News Topic Sorter (Naive Bayes).

Run:
    python main.py

Multi-class text classification with three topics: sports, technology, and
food.  The confusion matrix shows which topics are easiest to confuse.
"""
```

## Line-by-Line Code Breakdown
- Lines 1-2: Module docstring introducing Project 19: The News Topic Sorter, specifying the underlying algorithm (Naive Bayes).
- Lines 3-4: Direct execution instructions for learners running the script from terminal.
- Lines 6-7: Core problem definition highlighting multi-class classification across three discrete topics: sports, technology, and food.
- Lines 7-8: Analytical objective explaining that the generated confusion matrix reveals which categories exhibit lexical overlap and are most susceptible to misclassification.

## Worked Example
Consider an incoming RSS wire feed emitting the following headline:
`"Star player scores twice in comeback victory"`

A human editor immediately spots athletic terminology: "player", "scores", "victory". An automated topic classifier performs a similar evaluation mathematically:
1. It analyzes the presence of tokens: `['player', 'scores', 'twice', 'comeback', 'victory']`.
2. It looks up historical word frequencies across sports, technology, and food articles.
3. It determines that tokens like `comeback victory` and `scores` possess an overwhelming statistical correlation with `sports`.
4. The system automatically tags the story as `sports` and routes it to the sports feed without human intervention.

## Step-by-Step Student Instructions
1. Open your terminal and examine the project files in `19_news_topic_sorter`.
2. Read the top docstring in `main.py` to identify the three target classes.
3. Identify three real-world news websites (e.g., BBC, Reuters, NYT) and observe their topical navigation sections.
4. Note down two examples of headlines that clearly belong to technology and two that belong to food.
5. Consider how an automated system handles ambiguous headlines that might belong to multiple categories.

## Expected Output or Observable Behaviour
When observing news platforms or executing classification pipelines:
- Unambiguous headlines receive high-confidence classification scores (e.g., >90%).
- Headlines are processed within a few milliseconds, far exceeding human reading speed.
- The output label is strictly one of the configured categories: `sports`, `technology`, or `food`.

## Practical Exercises
- **Exercise 1.1**: Write down 3 sample headlines—one for sports, one for tech, and one for food. Underline the specific keywords in each that give away the topic.
- **Exercise 1.2**: Imagine a headline: `"New AI tracking system helps football athletes improve sprint speeds."` Which two topics does this span? Explain why edge cases occur in real-world newsrooms.

## Common Mistakes and Debugging
| Common Misconception | Why It Is Incorrect | Proper Understanding |
|---|---|---|
| Assuming text classification requires understanding grammar | Bag-of-Words and Naive Bayes ignore grammar and syntax | Models rely on word frequency statistics, not grammatical comprehension |
| Confusing multi-class with multi-label classification | Multi-label allows an article to have multiple tags at once | Multi-class assigns exactly one mutually exclusive category per headline |
| Believing manual sorting is more reliable at scale | Humans suffer from fatigue, inconsistency, and latency | Automated models process millions of headlines consistently in milliseconds |

## Best Practices and Operational Considerations
- Define clear taxonomy boundaries: Ensure that categories in your news taxonomy are sufficiently distinct to minimize ambiguity.
- Measure classification latency: In high-frequency ingestion systems, model inference speed is just as critical as accuracy.
- Maintain human-in-the-loop review: For low-confidence predictions (e.g., confidence < 50%), route the headline to human editors for verification.

## Summary and Key Takeaways
- Digital news platforms ingest massive volumes of content requiring real-time automated routing.
- The News Topic Sorter implements multi-class text classification across sports, technology, and food.
- Algorithmic classification provides instant, scalable, and repeatable content categorization compared to slow, expensive manual editorial workflows.

## Knowledge-Check Questions and References
1. What three categories does the News Topic Sorter classify headlines into?
2. Why is automated text classification essential for digital news aggregators?
3. How does multi-class classification differ from binary classification?
4. What role does topic confidence play in automated editorial routing?

*References*:
- Jurafsky, D., & Martin, J. H. (2023). *Speech and Language Processing (3rd ed.)*, Chapter 4: Naive Bayes Classification and Sentiment.
- Manning, C. D., Raghavan, P., & Schütze, H. (2008). *Introduction to Information Retrieval*, Chapter 13: Text classification and Naive Bayes.
