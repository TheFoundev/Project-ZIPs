# Lesson 03: The End-to-End NLP Pipeline Architecture

**Lesson ID:** lesson-03  
**Module:** module-01  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why natural language text cannot be fed directly into mathematical learning algorithms.
- Diagram the two-stage scikit-learn `Pipeline` combining `CountVectorizer` and `MultinomialNB`.
- Explain how `Pipeline` prevents data leakage between training and testing data splits.
- Contrast separate manual transformations with unified pipeline execution.

## Prerequisites
- Lesson 02: Multi-Class vs Binary Classification.
- Basic understanding of Python lists and tuples.

## Industry and Real-World Motivation
In production machine learning systems, data processing is rarely a single step. Before a machine learning algorithm can process raw human language, the text must undergo cleaning, tokenization, stop-word removal, n-gram generation, and vector formatting. 

Executing these steps manually using separate scripts or disconnected objects frequently leads to **data leakage**—a catastrophic flaw where information from the test dataset accidentally leaks into the training pipeline. Scikit-learn's `Pipeline` object encapsulates all transformation stages and estimators into a single cohesive artifact, ensuring reproducible, leak-free training and deployment.

## Concept Explanation
Computers cannot directly multiply words like "football" or "algorithm" by mathematical weights. Text must first be converted into numerical vectors.

The News Topic Sorter accomplishes this using a two-stage sequential architecture:
1. **Stage 1: Feature Extraction (`CountVectorizer`)**:
   - Converts raw strings into a sparse matrix of token counts.
   - Applies text lowercasing, tokenization, stop-word filtering, and n-gram extraction.
2. **Stage 2: Probabilistic Classifier (`MultinomialNB`)**:
   - Learns the statistical association between token frequencies and topic classes.
   - Predicts topic labels and outputs probability estimates.

```
Raw Text String ──> [ CountVectorizer ] ──> Numerical Term-Count Matrix ──> [ MultinomialNB ] ──> Class Label
```

When you call `model.fit(X_train, y_train)` on a Pipeline:
- The vectorizer executes `fit_transform(X_train)`, creating the vocabulary and transforming training text into a count matrix.
- The classifier executes `fit()` on the resulting matrix and `y_train`.

When you call `model.predict(X_test)`:
- The vectorizer executes only `transform(X_test)` using the fixed vocabulary learned during training.
- The classifier executes `predict()` on the test count matrix.

## Architectural and Pipeline Context
The pipeline pattern ensures complete encapsulation. New headlines fed to `model.predict()` automatically undergo identical preprocessing without requiring duplicate code or manual tokenization routines.

## Relevant Code
From `main.py` (lines 36-42):
```python
    model = Pipeline(
        [
            ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
            ("classifier", MultinomialNB()),
        ]
    )
    model.fit(X_train, y_train)
```

## Line-by-Line Code Breakdown
- Lines 36-37: Instantiates a `Pipeline` object by passing a list of `(name, transform_object)` tuples.
- Line 38: Defines the first stage named `"vectorizer"`, configuring `CountVectorizer` with English stop-word removal and unigram + bigram combinations `(1, 2)`.
- Line 39: Defines the second stage named `"classifier"`, utilizing `MultinomialNB()` with default Laplace smoothing ($lpha = 1.0$).
- Line 42: `model.fit(X_train, y_train)` triggers the end-to-end training process in a single unified method call.

## Worked Example
Suppose we have training headlines:
1. `"Cricket match schedule"`
2. `"New Python tool"`

Step 1 (`CountVectorizer.fit_transform`):
- Vocabulary learned: `['cricket', 'cricket match', 'match', 'match schedule', 'new', 'new python', 'python', 'python tool', 'schedule', 'tool']`.
- Matrix shape: `(2, 10)`.

Step 2 (`MultinomialNB.fit`):
- Calculates conditional probabilities of each n-gram given the category.

Step 3 Inference (`model.predict(["Python tool release"])`):
- `CountVectorizer.transform` converts the new headline using the existing vocabulary. The word "release" was not in training, so it is ignored. The words "python" and "tool" are counted.
- `MultinomialNB.predict` computes class probabilities and predicts `technology`.

## Step-by-Step Student Instructions
1. Inspect lines 36-41 in `main.py`.
2. Notice the syntax: `Pipeline([ (step_1_name, step_1_obj), (step_2_name, step_2_obj) ])`.
3. Check the named stages: `"vectorizer"` and `"classifier"`.
4. Observe how calling `model.fit()` trains both components simultaneously.

## Expected Output or Observable Behaviour
- A single trained `Pipeline` object that can accept raw text strings directly in `.predict()` or `.predict_proba()` without prior manual vectorization.
- Clean code architecture free from scattered intermediate matrices.

## Practical Exercises
- **Exercise 3.1**: Why would it be an error to call `fit_transform` on the test data (`X_test`)?
- **Exercise 3.2**: Write down the tuple structure required to add an extra scaling or preprocessing stage to a scikit-learn Pipeline.

## Common Mistakes and Debugging
| Common Mistake | Why It Breaks the Workflow | Correct Approach |
|---|---|---|
| Vectorizing before splitting data into train/test | Causes data leakage: test vocabulary leaks into the training feature set | Split raw strings first with `train_test_split`, then fit vectorizer only on train data |
| Manually vectorizing test strings before calling `pipeline.predict()` | Pipeline expects raw strings because `vectorizer` is the first pipeline step | Pass raw string lists directly to `pipeline.predict()` |
| Misspelling step names in `model.named_steps` | Raises `KeyError` when accessing components for inspection | Use exact names specified in the pipeline constructor (`"vectorizer"`, `"classifier"`) |

## Best Practices and Operational Considerations
- Always bundle transformers and estimators into a `Pipeline` for production NLP tasks.
- Keep pipeline components modular so individual steps (e.g., swapping `CountVectorizer` for `TfidfVectorizer`) can be tested without rewriting downstream logic.

## Summary and Key Takeaways
- Raw natural language text requires numerical encoding before classification algorithms can process it.
- Scikit-learn `Pipeline` chains `CountVectorizer` and `MultinomialNB` into a single leak-free object.
- Calling `.fit()` trains both stages; calling `.predict()` automatically transforms new text and computes class predictions.

## Knowledge-Check Questions and References
1. What are the two stages in the News Topic Sorter pipeline?
2. What does `CountVectorizer` convert raw text into?
3. How does using a `Pipeline` prevent data leakage?
4. What happens if an unseen word appears in a new headline during `pipeline.predict()`?

*References*:
- Scikit-learn Pipeline documentation: https://scikit-learn.org/stable/modules/compose.html
- Buitinck et al. (2013). *API design for machine learning software: experiences from the scikit-learn project*.
