# Lesson 02: Multi-Class vs Binary Classification

**Lesson ID:** lesson-02  
**Module:** module-01  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Distinguish between binary classification, multi-class classification, and continuous regression.
- Define the target label space ($Y$) for the News Topic Sorter.
- Explain why probability distributions across multiple classes must sum to 1.0 (100%).
- Identify why accuracy alone may not be sufficient for evaluating multi-class systems.

## Prerequisites
- Lesson 01: The News Sorting Problem & Digital Newsrooms.
- Basic understanding of target variables in supervised learning.

## Industry and Real-World Motivation
In real-world data science, classification tasks are rarely binary. While fraud detection (fraud vs. not fraud) or spam filtering (spam vs. ham) are binary, most organizational workflows require choosing among many options:
- Customer support ticket routing (Billing, Technical Support, Returns, Sales, Account Security).
- Legal document sorting (Patent, Litigation, Compliance, Mergers, Employment).
- Medical diagnosis (Multiple potential disease classifications).

Understanding how multi-class classifiers evaluate candidate categories simultaneously is a foundational requirement for any machine learning engineer.

## Concept Explanation
In supervised machine learning, predictive tasks are categorized by the nature of their target variable $y$:

1. **Regression**: Predicts a continuous numerical value (e.g., predicting temperature, house prices, or lemonade cups sold).
2. **Binary Classification**: Predicts one of two possible outcomes, typically represented as $\{0, 1\}$ or negative vs. positive.
3. **Multi-Class Classification**: Predicts exactly one class from a set of $K$ mutually exclusive categories, where $K > 2$.

In the News Topic Sorter, the label space consists of $K=3$ discrete categories:
$$Y = \{\text{food}, \text{sports}, \text{technology}\}$$

When presented with a headline $x$, a multi-class probabilistic model does not merely output a single label. It estimates a probability vector:
$$\mathbf{p} = [P(y=\text{food}|x), P(y=\text{sports}|x), P(y=\text{technology}|x)]$$
subject to the constraints that:
$$0 \le P(y=c|x) \le 1 \quad \text{and} \quad \sum_{c \in Y} P(y=c|x) = 1.0$$

The final predicted class is the argument that maximizes this probability:
$$\hat{y} = \arg\max_{c \in Y} P(y=c|x)$$

## Architectural and Pipeline Context
Multi-class models in scikit-learn handle the expansion from binary to multi-class natively. While algorithms like Logistic Regression often require "One-vs-Rest" (OvR) or "One-vs-One" (OvO) strategies, Naive Bayes naturally models multinomial distributions across arbitrary numbers of classes without requiring separate binary meta-estimators.

## Relevant Code
From `main.py` (lines 6-7, 55):
```python
# Multi-class text classification with three topics: sports, technology, and food.
...
classes = list(classifier.classes_)
# classes evaluated: ['food', 'sports', 'technology']
```

## Line-by-Line Code Breakdown
- Lines 6-7: Comments explicitly establish that this is a multi-class problem with three specific targets.
- Line 55: `classes = list(classifier.classes_)` extracts the learned class labels from the fitted classifier. Scikit-learn automatically sorts categorical strings alphabetically, resulting in `['food', 'sports', 'technology']`.

## Worked Example
Suppose our model evaluates the headline:
`"Simple one-pot pasta recipe wins over busy students"`

The model evaluates token evidence and computes the posterior probability distribution:
- $P(y=\text{food}|x) = 0.94$ (94%)
- $P(y=\text{sports}|x) = 0.02$ (2%)
- $P(y=\text{technology}|x) = 0.04$ (4%)

Sum of probabilities:
$$0.94 + 0.02 + 0.04 = 1.00 \quad (100\%)$$

Decision:
$$\hat{y} = \arg\max(0.94, 0.02, 0.04) = \text{food}$$
The headline is confidently classified as `food`.

## Step-by-Step Student Instructions
1. Inspect the target labels in `data/headlines.csv`.
2. Verify that every single row belongs to exactly one topic: `sports`, `technology`, or `food`.
3. Check the number of classes ($K=3$).
4. Note that unlike binary classification where predicting the probability of class 1 automatically gives class 0 ($1 - P$), in multi-class we must track all $K$ probabilities.

## Expected Output or Observable Behaviour
When predicting across multiple classes:
- `model.predict()` returns an array of string labels (`'food'`, `'sports'`, or `'technology'`).
- `model.predict_proba()` returns a 2D array of shape `(n_samples, 3)` where each row sums to $1.0$.

## Practical Exercises
- **Exercise 2.1**: If a classifier outputs probabilities of 0.45 for sports and 0.35 for technology on a headline, what must its probability for food be?
- **Exercise 2.2**: Why is predicting the topic of a news headline a classification task rather than a regression task?

## Common Mistakes and Debugging
| Common Mistake | Why It Causes Errors | Proper Technique |
|---|---|---|
| Treating multi-class as numbers like 1, 2, 3 in regression | Regression implies order and distance (2 is closer to 1 than 3 is) | Use discrete categorical strings or one-hot/label encoding without numeric distance |
| Forgetting alphabetical sorting in `classes_` | Assuming classes follow dataset appearance order leads to incorrect probability mapping | Always retrieve class order directly from `classifier.classes_` |
| Ignoring low-confidence winners | A prediction with 34% probability might win if others are 33% and 33%, but confidence is very low | Inspect probability distributions, not just predicted class names |

## Best Practices and Operational Considerations
- Always verify label balance: Having vastly unequal sample counts across classes can bias multi-class predictions toward the majority class.
- Always check `classifier.classes_`: Never hardcode probability index mappings; always query the classifier's internal label array.

## Summary and Key Takeaways
- Multi-class classification predicts one label among $K > 2$ discrete categories.
- Probabilities across all $K$ classes sum to 1.0.
- Scikit-learn natively supports multi-class classification and sorts string labels alphabetically.

## Knowledge-Check Questions and References
1. What defines a machine learning task as "multi-class"?
2. What are the three classes in the News Topic Sorter label space?
3. If an input receives probabilities of 0.70 for tech and 0.20 for food, what is the probability for sports?
4. In what order does scikit-learn arrange class names in `classifier.classes_`?

*References*:
- Scikit-learn User Guide: *Multiclass and multioutput algorithms* (https://scikit-learn.org/stable/modules/multiclass.html).
- Hastie, T., Tibshirani, R., & Friedman, J. (2009). *The Elements of Statistical Learning*, Chapter 4.
