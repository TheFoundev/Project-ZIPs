# Lesson 04: Project Directory Structure & Running main.py

**Lesson ID:** lesson-04  
**Module:** module-01  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Navigate the project directory structure and identify essential source files and folders.
- Explain the role of `Path(__file__).resolve().parent` in building robust file paths.
- Execute `main.py` from the command line and interpret the immediate console outputs.
- Locate the output directory and verify generated artifact files.

## Prerequisites
- Lesson 03: The End-to-End NLP Pipeline Architecture.
- Basic terminal and command-line familiarity.

## Industry and Real-World Motivation
Professional machine learning codebases must be reproducible, portable, and cleanly organized. Hardcoded paths like `C:\Users\alice\Documents\data.csv` break when shared with teammates, run inside Docker containers, or deployed to cloud training clusters. 

Using standard directory hierarchies (`data/`, `outputs/`, `src/`) and resolving paths dynamically relative to the script's location ensures that projects run reliably across Linux, macOS, and Windows environments without manual path adjustments.

## Concept Explanation
The News Topic Sorter follows standard data science project structuring conventions:

```
19_news_topic_sorter/
├── main.py              # Self-contained execution pipeline
├── README.md            # Project documentation and instructions
├── data/                # Immutable input datasets
│   └── headlines.csv    # 90 synthetic news headlines with topic labels
└── outputs/             # Generated execution artifacts
    ├── confusion_matrix.png # High-resolution evaluation plot
    └── predictions.txt      # Text summary of metrics and test outputs
```

### Dynamic Path Resolution
In `main.py`, file paths are managed using Python's modern `pathlib` module:
- `BASE = Path(__file__).resolve().parent`: Resolves the absolute directory containing `main.py`.
- `DATA = BASE / "data"`: Resolves the dataset directory regardless of the current working directory.
- `OUT = BASE / "outputs"`: Resolves the output directory.
- `OUT.mkdir(exist_ok=True)`: Creates the output folder automatically if it does not already exist, preventing runtime `FileNotFoundError` exceptions.

## Architectural and Pipeline Context
The main execution routine is wrapped in a `main()` function protected by the standard Python idiom:
```python
if __name__ == "__main__":
    main()
```
This design allows `main.py` to be executed directly as a standalone script or imported into testing harnesses without automatically triggering training.

## Relevant Code
From `main.py` (lines 10, 24-28, 96-97):
```python
from pathlib import Path
...
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)
...
if __name__ == "__main__":
    main()
```

## Line-by-Line Code Breakdown
- Line 10: Imports `Path` from standard library `pathlib` for object-oriented filesystem path manipulation.
- Line 24: Resolves `BASE` to the script's parent folder by taking `__file__`, resolving symbolic links, and extracting `.parent`.
- Line 25: Defines `DATA` path using the clean `/` operator provided by `Path`.
- Line 26: Defines `OUT` path pointing to the `outputs` directory.
- Line 27: Calls `OUT.mkdir(exist_ok=True)` to ensure the directory exists before saving plots or text summaries.
- Lines 96-97: Standard entry point execution check calling `main()` when run from CLI.

## Worked Example
Let's see what happens during execution:
1. Student runs:
   ```bash
   cd "/home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/19_news_topic_sorter"
   python3 main.py
   ```
2. The script resolves paths, reads `data/headlines.csv`, splits 90 samples into 67 train and 23 test, builds and trains the pipeline.
3. The script prints:
   ```
   ============================================================
   THE NEWS TOPIC SORTER
   ============================================================
   Accuracy: 100.0%
   ...
   ```
4. The script creates `outputs/confusion_matrix.png` and `outputs/predictions.txt`.

## Step-by-Step Student Instructions
1. Open terminal and navigate to the project directory.
2. Check that `data/headlines.csv` exists using `ls -la data/`.
3. Run `python3 main.py`.
4. Inspect the printed accuracy and classification report in the terminal.
5. Check the contents of `outputs/` using `ls -lh outputs/`.

## Expected Output or Observable Behaviour
Console output displays:
```
============================================================
THE NEWS TOPIC SORTER
============================================================
Accuracy: 100.0%

              precision    recall  f1-score   support

        food       1.00      1.00      1.00         7
      sports       1.00      1.00      1.00         8
  technology       1.00      1.00      1.00         8

    accuracy                           1.00        23
   macro avg       1.00      1.00      1.00        23
weighted avg       1.00      1.00      1.00        23
```
Files created in `outputs/`:
- `confusion_matrix.png` (~25 KB image file)
- `predictions.txt` (Text evaluation summary)

## Practical Exercises
- **Exercise 4.1**: Delete the `outputs/` directory using `rm -rf outputs` and re-run `python3 main.py`. Does the script recreate the folder without throwing an error? Explain why.
- **Exercise 4.2**: Open `outputs/predictions.txt` and verify that the metrics recorded match the values displayed in the terminal.

## Common Mistakes and Debugging
| Issue / Error | Cause | Solution |
|---|---|---|
| `FileNotFoundError: data/headlines.csv` | Running script using relative path from different directory without resolving `BASE` | Always use `DATA = BASE / "data"` with `Path(__file__).resolve().parent` |
| `ModuleNotFoundError: No module named 'sklearn'` | Virtual environment not activated or scikit-learn not installed | Run `pip install scikit-learn pandas matplotlib numpy` |
| `PermissionError` on writing outputs | Output folder created with root permissions or read-only directory | Ensure user write permissions on project root |

## Best Practices and Operational Considerations
- Never hardcode relative string paths like `"data/headlines.csv"`; always anchor with `Path(__file__).resolve().parent`.
- Always specify `exist_ok=True` when creating directories to make scripts idempotent.
- Guard script execution with `if __name__ == "__main__":` to support modular imports.

## Summary and Key Takeaways
- The project is cleanly organized into source script `main.py`, immutable input `data/`, and generated `outputs/`.
- `pathlib.Path` provides platform-independent path resolution anchored to the script location.
- Running `python3 main.py` fits the model, displays console diagnostics, and saves evaluation artifacts to disk.

## Knowledge-Check Questions and References
1. Why is `Path(__file__).resolve().parent` preferred over hardcoded string paths?
2. What parameter prevents `mkdir` from crashing if the folder already exists?
3. Where are the generated plot and text report saved?
4. What guard prevents code execution when a Python file is imported as a module?

*References*:
- Python official documentation: `pathlib` — Object-oriented filesystem paths (https://docs.python.org/3/library/pathlib.html).
