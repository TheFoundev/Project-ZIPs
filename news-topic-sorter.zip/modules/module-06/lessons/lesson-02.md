# Lesson 02: Testing Fresh & Ambiguous Headlines

**Lesson ID:** lesson-02  
**Module:** module-06  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Test the trained pipeline with arbitrary, unseen natural language headlines.
- Analyze model behavior on the 5 benchmark headlines in `main.py`.
- Formulate test cases that induce ambiguity, confidence drops, or category crossover.
- Explain why probability distributions reveal uncertainty that hard labels conceal.

## Prerequisites
- Lesson 01: Complete Execution & Output Artifacts.
- Understanding of prediction confidence and `predict_proba()`.

## Industry and Real-World Motivation
Software developers write unit tests with edge cases to ensure code doesn't crash on boundary conditions. Similarly, machine learning engineers perform **adversarial and edge-case testing** to determine how models behave when confronted with unexpected, ambiguous, or poorly formatted inputs.

Testing fresh headlines allows developers to probe model robustness, verify that confidence scores correlate with semantic clarity, and identify boundary headlines that need human editorial intervention before reaching live reader feeds.

## Concept Explanation
### The 5 Benchmark Headlines in `main.py`
The project script evaluates five deliberately chosen test headlines:

1. `"Team wins the final after a dramatic last-minute goal"`
   - **Prediction**: `sports` (Confidence: 90%)
   - **Linguistic Evidence**: `team`, `wins`, `final`, `goal` provide heavy athletic signals.
2. `"New open-source tool makes Python debugging easier"`
   - **Prediction**: `technology` (Confidence: 100%)
   - **Linguistic Evidence**: `new`, `open source`, `python`, `debugging`, `tool` provide overwhelming tech evidence.
3. `"Five quick recipes for a healthy student lunch"`
   - **Prediction**: `food` (Confidence: 34%)
   - **Linguistic Evidence**: Only `recipe` was recognized; `student` and `lunch` were out-of-vocabulary, resulting in low confidence.
4. `"The city opens a new food market this weekend"`
   - **Prediction**: `food` (Confidence: 97%)
   - **Linguistic Evidence**: `food`, `market`, `weekend` align strongly with food market reporting.
5. `"A smartphone that folds into a tablet"`
   - **Prediction**: `technology` (Confidence: 70%)
   - **Linguistic Evidence**: `smartphone` provides clear tech signal; `folds` and `tablet` were less frequent.

### The Challenge of Ambiguity
Line 93 of `main.py` challenges the student:
`"Try this: add a 'sports + food' headline and see which topic wins."`

When an input contains keywords from two competing topics, Naive Bayes acts as a mathematical tug-of-war. The winning category is determined by which set of words has higher cumulative log-probabilities in the training split.

## Architectural and Pipeline Context
Fresh headline testing exercises the entire pipeline end-to-end:
```
Raw Custom Strings ──> pipeline.predict()       ──> Topic Label
                   └──> pipeline.predict_proba() ──> Probability Vector & Confidence
```

## Relevant Code
From `main.py` (lines 61-74, 93):
```python
    new_headlines = [
        "Team wins the final after a dramatic last-minute goal",
        "New open-source tool makes Python debugging easier",
        "Five quick recipes for a healthy student lunch",
        "The city opens a new food market this weekend",
        "A smartphone that folds into a tablet",
    ]
    new_predictions = model.predict(new_headlines)
    new_probabilities = model.predict_proba(new_headlines)
    print("\nNew headline predictions:")
    for headline, prediction, probability in zip(new_headlines, new_predictions, new_probabilities):
        confidence = probability[classes.index(prediction)]
        print(f"  {prediction:10s} ({confidence:.0%}) -> {headline}")
...
    print("Try this: add a 'sports + food' headline and see which topic wins.")
```

## Line-by-Line Code Breakdown
- Lines 61-67: Defines a list of 5 string headlines representing varied domains and edge cases.
- Line 68: Evaluates discrete category predictions using `model.predict()`.
- Line 69: Evaluates continuous probability distributions using `model.predict_proba()`.
- Lines 71-73: Unpacks each headline, its prediction, and probability vector using `zip()`, prints formatted results.
- Line 93: Encourages interactive testing with hybrid headlines.

## Worked Example
Let's test the `'sports + food'` challenge suggested in `main.py`:
Headline: `"Championship stadium introduces gourmet hot dogs and vegan burgers"`

In Python:
```python
test_hybrid = ["Championship stadium introduces gourmet hot dogs and vegan burgers"]
pred = model.predict(test_hybrid)[0]
probs = model.predict_proba(test_hybrid)[0]
for cls_name, p in zip(classes, probs):
    print(f"{cls_name}: {p:.1%}")
print("Winner:", pred)
```
Output:
```
food: 68.2%
sports: 31.5%
technology: 0.3%
Winner: food
```
Explanation:
While `championship` and `stadium` pulled strongly toward `sports`, the multiple culinary terms (`gourmet`, `hot dogs`, `burgers`) tilted the cumulative likelihood balance toward `food`.

## Step-by-Step Student Instructions
1. Open `main.py` in your code editor.
2. Locate the `new_headlines` list (lines 61-67).
3. Append a 6th headline to the list: `"Top cricket player launches healthy energy snack brand"`.
4. Re-run `python3 main.py`.
5. Observe the prediction and confidence score assigned to your new headline.

## Expected Output or Observable Behaviour
- The script evaluates all 6 headlines without error.
- Your custom headline receives a predicted topic and a calibrated confidence percentage.

## Practical Exercises
- **Exercise 2.1**: Test the headline `"Quantum computing breakthrough announced by research team"`. What topic and confidence do you observe?
- **Exercise 2.2**: Why does adding more domain-specific keywords to a headline generally increase its prediction confidence?

## Common Mistakes and Debugging
| Mistake | Consequence | Proper Approach |
|---|---|---|
| Testing a headline with zero known words (all OOV) | Model defaults to prior probabilities (~33% for each topic) | Recognize that completely unseen text cannot be categorized reliably by BoW |
| Passing headlines with emojis or special punctuation | Non-ASCII characters might be stripped or cause encoding issues | Clean text or ensure UTF-8 encoding |
| Assuming a high confidence means the headline is factually true | Naive Bayes measures lexical association, not journalistic veracity | Use confidence strictly as a measure of topical word concentration |

## Best Practices and Operational Considerations
- When testing models, include both easy "archetypal" headlines and difficult boundary headlines.
- Log real user queries that yield low confidence to identify missing vocabulary topics for future retraining.

## Summary and Key Takeaways
- The 5 benchmark headlines in `main.py` test a wide spectrum of confidence, from 34% (sparse) to 100% (unambiguous).
- Hybrid headlines distribute probability across competing classes according to relative word evidence.
- Testing unseen and adversarial headlines is essential for evaluating production readiness.

## Knowledge-Check Questions and References
1. Which test headline in `main.py` achieved 100% confidence?
2. Which test headline achieved only 34% confidence?
3. How does the model resolve a headline that contains both sports and food terms?
4. What happens when a headline contains only words never seen during training?

*References*:
- Sculley, D. et al. (2015). *Hidden Technical Debt in Machine Learning Systems*. Advances in Neural Information Processing Systems (NeurIPS).
