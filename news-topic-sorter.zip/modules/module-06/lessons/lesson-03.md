# Lesson 03: Expanding the Taxonomy: Adding a 4th News Topic

**Lesson ID:** lesson-03  
**Module:** module-06  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Design a taxonomy expansion adding a 4th news category (e.g., `politics` or `business`).
- Describe the dataset collection and balancing requirements for adding a new class.
- Explain how the confusion matrix, vocabulary, and probability distributions scale from 3 to 4 classes.
- Identify the potential for new cross-domain confusions when adding categories.

## Prerequisites
- Lesson 02: Testing Fresh & Ambiguous Headlines.
- Understanding of multi-class classification and stratified splitting.

## Industry and Real-World Motivation
Real-world digital publications rarely restrict their taxonomy to three categories. A mainstream news portal covers politics, finance, health, entertainment, science, education, and world events.

As an organization grows, data science teams are routinely asked: *"Can we add a new section for Politics or Entertainment?"* Scaling an NLP classifier requires more than just changing a line of code; it demands disciplined taxonomy design, balanced data curation, audit of lexical overlap, and confusion matrix re-baselining.

## Concept Explanation
### Designing the 4th Topic: `politics`
Suppose we expand our taxonomy from 3 classes to $K=4$ classes:
$$Y = \{\text{food}, \text{politics}, \text{sports}, \text{technology}\}$$

### 1. Data Collection & Balance
To maintain class balance, we must collect 30 high-quality headlines for `politics` to match the 30 existing headlines for food, sports, and tech:
- Examples of political headlines:
  - `"Parliament debates new environmental legislation this afternoon"`
  - `"Prime minister meets foreign leaders for bilateral economic summit"`
  - `"Voters head to polls in highly contested municipal election"`
- Total dataset size expands from 90 to **120 headlines**.

### 2. Stratified Split Changes
Using `test_size=0.25`:
- Total Test Set: $120 \times 0.25 = \mathbf{30\text{ samples}}$ (vs. 23 previously).
- Training Set: $120 \times 0.75 = \mathbf{90\text{ samples}}$ (vs. 67 previously).
- Test class breakdown: Exactly 7 or 8 samples for each of the 4 classes.

### 3. Architectural Scaling
Because `CountVectorizer` and `MultinomialNB` are fully dynamic:
- **Zero architecture code changes required**: `Pipeline([("vectorizer", ...), ("classifier", ...)])` automatically handles $K=4$ classes!
- `classifier.classes_`: Expands to `['food', 'politics', 'sports', 'technology']`.
- `classifier.feature_log_prob_`: Expands to shape $(4, V)$.
- `confusion_matrix`: Expands from a $3 \times 3$ grid to a **$4 \times 4$ grid**.
- `predict_proba`: Outputs a 4-element probability vector that sums to 1.0.

### 4. New Confusion Dynamics
Adding `politics` introduces new semantic overlaps:
- Politics & Technology: Cyber-espionage, tech regulation, AI ethics legislation.
- Politics & Food: Agricultural subsidies, food inflation, school lunch policies.
- Politics & Sports: Stadium tax funding, national Olympic boycotts.

## Architectural and Pipeline Context
Scaling from 3 to 4 classes expands the output dimensionality:
```
Input Headline ──> Pipeline ──> Probabilities: [P(food), P(politics), P(sports), P(tech)]
                                Matrix: 4x4 Confusion Matrix
```

## Relevant Code
Hypothetical dataset addition in `data/headlines.csv`:
```csv
headline,topic
Parliament debates new environmental legislation this afternoon,politics
Prime minister meets foreign leaders for bilateral summit,politics
Voters head to polls in municipal election,politics
```
In `main.py`:
```python
# No code modification needed in pipeline construction!
# pipeline.fit(X_train, y_train) automatically adapts to 4 classes.
labels = sorted(df["topic"].unique()) # Evaluates to 4 labels!
```

## Line-by-Line Code Breakdown
- When `df["topic"].unique()` discovers 4 unique strings, scikit-learn fits 4 class distributions.
- `ConfusionMatrixDisplay` dynamically renders a $4 \times 4$ grid without manual dimension configuration.

## Worked Example
Suppose we train the 4-class model and evaluate:
`"Government passes new cybersecurity legislation for tech firms"`

Competing topics:
- `politics`: signaled by `'government'`, `'passes'`, `'legislation'`
- `technology`: signaled by `'cybersecurity'`, `'tech firms'`

Predicted probability distribution:
- $P(\text{food}) = 0.01$ (1%)
- $P(\text{sports}) = 0.01$ (1%)
- $P(\text{politics}) = 0.52$ (52%)
- $P(\text{technology}) = 0.46$ (46%)

Winning class: `politics` (52% confidence).
The confusion matrix might show off-diagonal counts between politics and technology, highlighting the need for specialized bigrams like `'cybersecurity legislation'`.

## Step-by-Step Student Instructions
1. Inspect `data/headlines.csv`.
2. Draft 5 sample headlines for a new `politics` category.
3. List the top 3 domain keywords you expect `politics` to learn (e.g., `election`, `parliament`, `minister`).
4. Predict which existing category `politics` is most likely to blur into.

## Expected Output or Observable Behaviour
- Scikit-learn seamlessly expands from 3 to 4 classes without code changes.
- The confusion matrix becomes a $4 \times 4$ grid.
- Probabilities divide across 4 categories (baseline uniform prior = 25% each).

## Practical Exercises
- **Exercise 3.1**: If you added 30 headlines for `politics` and 30 for `business`, what would the total dataset size and the shape of `classifier.feature_log_prob_` be?
- **Exercise 3.2**: Why would adding `politics` with only 5 headlines while the other categories have 30 be problematic?

## Common Mistakes and Debugging
| Mistake | Consequence | Proper Approach |
|---|---|---|
| Adding a 4th class with severe class imbalance (e.g., 5 rows vs 30) | Classifier learns tiny prior probability for the new class, virtually never predicting it | Balance sample counts across all classes during dataset expansion |
| Choosing overlapping taxonomy categories (e.g., `tech` and `computers`) | Severe mutual confusion and degraded accuracy | Ensure distinct, well-separated editorial definitions |
| Hardcoding matrix display labels or figure sizes | $4 \times 4$ text labels may overlap if plot size isn't slightly expanded | Adjust `figsize=(6.5, 5.5)` when scaling matrix dimensions |

## Best Practices and Operational Considerations
- Audit taxonomy boundaries with editorial stakeholders before collecting data.
- Collect at least 30-50 samples per category to provide sufficient lexical coverage for n-grams.

## Summary and Key Takeaways
- The scikit-learn Pipeline architecture dynamically scales to any number of classes $K$.
- Expanding to a 4th topic requires balanced data collection and re-baselining of the confusion matrix.
- Adding topics increases opportunities for cross-domain lexical confusion.

## Knowledge-Check Questions and References
1. What changes must be made to `model = Pipeline(...)` when adding a 4th topic?
2. What would the dimensions of the confusion matrix be for 4 classes?
3. What is the baseline prior probability for each class in a balanced 4-class dataset?
4. Name one area where `politics` and `technology` headlines naturally overlap.

*References*:
- Manning, C. D., Raghavan, P., & Schütze, H. (2008). *Introduction to Information Retrieval*, Chapter 14: Vector space classification.
