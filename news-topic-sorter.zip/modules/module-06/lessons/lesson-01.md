# Lesson 01: Complete Execution & Output Artifacts

**Lesson ID:** lesson-01  
**Module:** module-06  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Execute `main.py` from start to finish and monitor execution milestones.
- Locate and inspect the saved visual artifact: `outputs/confusion_matrix.png`.
- Parse and interpret the serialized evaluation report: `outputs/predictions.txt`.
- Verify file I/O safety practices including `encoding="utf-8"` and headless plotting cleanup.

## Prerequisites
- Module 05: Evaluation & Topic Confusion.
- Basic command-line file inspection (`cat`, `ls`, `head`).

## Industry and Real-World Motivation
In production Machine Learning Operations (MLOps), training runs do not merely print ephemeral text to a developer terminal. Production training jobs run unattended inside automated CI/CD pipelines, containerized microservices, or scheduled cron workflows.

Every run must produce persistent, auditable artifacts: high-resolution diagnostic charts for model governance dashboards, structured prediction logs for auditability, and serialized metrics for tracking experiments over time. Mastering artifact generation ensures your machine learning workflows are production-grade.

## Concept Explanation
### Execution Workflow of `main.py`
When `python3 main.py` is invoked:
1. **Directory Verification**: `OUT.mkdir(exist_ok=True)` creates `outputs/` if missing.
2. **Data Ingestion**: Reads `data/headlines.csv` (90 rows).
3. **Partitioning**: Splits into 67 train and 23 test rows via stratified sampling.
4. **Pipeline Fit**: Trains `CountVectorizer` (282 features) and `MultinomialNB`.
5. **Evaluation**: Computes test accuracy and classification report.
6. **Feature Introspection**: Extracts and prints top 8 keywords per topic.
7. **Unseen Testing**: Evaluates 5 fresh headlines using `predict` and `predict_proba`.
8. **Artifact Serialization**:
   - Saves `outputs/confusion_matrix.png` (150 DPI matplotlib render).
   - Writes `outputs/predictions.txt` (UTF-8 encoded text summary).
   - Closes matplotlib figure to free memory.

### Structure of `outputs/predictions.txt`
The output file contains three structured sections:
1. Overall test accuracy: `accuracy: 1.0000`
2. Full per-class classification report (precision, recall, F1-score, support).
3. New headline predictions formatted with class name, exact confidence percentage, and headline string:
   ```
   sports (90.31%) -> Team wins the final after a dramatic last-minute goal
   technology (99.82%) -> New open-source tool makes Python debugging easier
   food (33.85%) -> Five quick recipes for a healthy student lunch
   food (96.53%) -> The city opens a new food market this weekend
   technology (70.12%) -> A smartphone that folds into a tablet
   ```

## Architectural and Pipeline Context
Artifact generation forms the final operational stage in `main.py`:
```
Model Pipeline ──┬──> ConfusionMatrixDisplay ──> outputs/confusion_matrix.png
                 └──> open(..., "w")         ──> outputs/predictions.txt
```

## Relevant Code
From `main.py` (lines 85-92):
```python
    with open(OUT / "predictions.txt", "w", encoding="utf-8") as handle:
        handle.write(f"accuracy: {accuracy:.4f}\n\n")
        handle.write(classification_report(y_test, predictions, zero_division=0))
        handle.write("\nNew headlines:\n")
        for headline, prediction, probability in zip(new_headlines, new_predictions, new_probabilities):
            handle.write(f"{prediction} ({probability[classes.index(prediction)]:.2%}) -> {headline}\n")

    print("\nSaved: outputs/confusion_matrix.png, outputs/predictions.txt")
```

## Line-by-Line Code Breakdown
- Line 85: Opens `OUT / "predictions.txt"` in write mode using a context manager (`with open(...)`) and explicitly enforces `encoding="utf-8"`.
- Line 86: Writes formatted overall accuracy with 4 decimal places.
- Line 87: Writes the complete monospace classification report.
- Lines 88-90: Iterates through each fresh headline, writing the predicted category, calibrated confidence to 2 decimal places (`:.2%`), and headline string.
- Line 92: Prints terminal confirmation notifying the user of saved files.

## Worked Example
Let's verify the files generated after execution:
```bash
$ ls -lh outputs/
total 32K
-rw-r--r-- 1 aziz aziz  28K Oct 27 19:06 confusion_matrix.png
-rw-r--r-- 1 aziz aziz 1.1K Oct 27 19:06 predictions.txt

$ head -n 5 outputs/predictions.txt
accuracy: 1.0000

              precision    recall  f1-score   support

        food       1.00      1.00      1.00         7
```
Both files are intact, non-empty, and contain the complete evaluation record.

## Step-by-Step Student Instructions
1. Open terminal and run `python3 main.py`.
2. Verify that the terminal ends with `"Saved: outputs/confusion_matrix.png, outputs/predictions.txt"`.
3. Use `cat outputs/predictions.txt` to read the serialized summary file.
4. Verify that the confidence percentages match the values discussed in class.

## Expected Output or Observable Behaviour
- Script terminates cleanly with return code 0.
- `outputs/confusion_matrix.png` exists and can be viewed as an image.
- `outputs/predictions.txt` contains accuracy, classification metrics, and 5 new headline inferences.

## Practical Exercises
- **Exercise 1.1**: Why is using `with open(...)` as a context manager safer than manually calling `handle = open(...)` and `handle.close()`?
- **Exercise 1.2**: Why is `encoding="utf-8"` explicitly specified in line 85? What bugs could occur on Windows systems without it?

## Common Mistakes and Debugging
| Mistake | Consequence | Proper Approach |
|---|---|---|
| Forgetting `encoding="utf-8"` | Default platform encodings (e.g., Windows CP-1252) crash when headlines contain emojis or foreign characters | Always specify `encoding="utf-8"` on all file handles |
| Writing to a directory before `mkdir` | `FileNotFoundError: [Errno 2] No such file or directory: 'outputs/predictions.txt'` | Always call `OUT.mkdir(exist_ok=True)` before file writes |
| Leaving figure open without `plt.close(fig)` | Progressive memory consumption across recurring runs | Always call `plt.close(fig)` after saving figures |

## Best Practices and Operational Considerations
- Keep output artifacts structured and versioned for reproducibility.
- Never write temporary outputs directly to the project root; keep all generated files contained inside `outputs/`.

## Summary and Key Takeaways
- `main.py` executes an end-to-end NLP workflow and saves both visual and textual artifacts.
- `outputs/confusion_matrix.png` provides an intuitive visual diagnostic of class separation.
- `outputs/predictions.txt` records accuracy, per-class metrics, and calibrated inference results for future audits.

## Knowledge-Check Questions and References
1. What two files are saved in the `outputs/` folder?
2. What format is used to format confidence in `outputs/predictions.txt`?
3. Why is `encoding="utf-8"` specified when opening text files?
4. What happens if `plt.close(fig)` is omitted in a loop running hundreds of models?

*References*:
- Python documentation: *Reading and Writing Files* (https://docs.python.org/3/tutorial/inputoutput.html#reading-and-writing-files).
