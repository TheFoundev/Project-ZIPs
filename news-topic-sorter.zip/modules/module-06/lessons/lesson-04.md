# Lesson 04: Beyond Bag-of-Words: TF-IDF & Modern NLP

**Lesson ID:** lesson-04  
**Module:** module-06  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain the limitations of raw term frequency in `CountVectorizer`.
- Define **TF-IDF (Term Frequency-Inverse Document Frequency)** and its mathematical components.
- Explain how swapping `TfidfVectorizer` into the pipeline penalizes generic words while elevating domain terms.
- Survey modern NLP advancements: subword tokenization, word embeddings (Word2Vec), and transformer models (BERT).

## Prerequisites
- Lesson 03: Expanding the Taxonomy: Adding a 4th News Topic.
- Basic understanding of logarithms and fractions.

## Industry and Real-World Motivation
While Bag-of-Words with raw counts is simple and fast, it has an inherent limitation: it treats all words that survive stop-word removal with equal baseline importance. If the word `"new"` or `"announces"` appears 10 times in tech articles and 10 times in sports articles, raw counts treat it with the same magnitude as highly specific words like `"microprocessor"` or `"quarterback"`.

In industrial information retrieval and large-scale document classification, **TF-IDF** is the standard mathematical refinement over raw counts. Beyond TF-IDF, modern AI systems use dense contextual embeddings (like BERT and RoBERTa) to capture deep semantic relationships. Understanding the evolutionary trajectory from BoW to TF-IDF to Transformers prepares you for advanced AI/ML.

## Concept Explanation
### The TF-IDF Formulation
**TF-IDF** stands for **Term Frequency-Inverse Document Frequency**. It evaluates how important a word is to a document within a larger collection of documents.

$$\text{TF-IDF}(t, d, D) = \text{TF}(t, d) \times \text{IDF}(t, D)$$

1. **Term Frequency $\text{TF}(t, d)$**: How frequently term $t$ appears in document $d$.
2. **Inverse Document Frequency $\text{IDF}(t, D)$**: Measures how common or rare term $t$ is across the entire corpus $D$:
   $$\text{IDF}(t, D) = \log\left( \frac{1 + |D|}{1 + \text{DF}(t)} \right) + 1$$
   Where $|D|$ is the total number of documents and $\text{DF}(t)$ is the number of documents containing term $t$.

### How TF-IDF Elevates Informative Words:
- **Case 1: Common Across All Topics** (e.g., `"new"`, `"announces"`):
  Appears in almost every document $\rightarrow \text{DF}(t)$ is large $\rightarrow \text{IDF}$ is close to zero $\rightarrow$ **Low TF-IDF weight**.
- **Case 2: Specific to One Topic** (e.g., `"phishing"`, `"recipe"`):
  Appears only in a few documents $\rightarrow \text{DF}(t)$ is small $\rightarrow \text{IDF}$ is large $\rightarrow$ **High TF-IDF weight**.

### The Modern NLP Landscape
```
1. Bag-of-Words (CountVectorizer)  ──> Raw frequency counts (ignores syntax & rarity)
              │
              ▼
2. TF-IDF (TfidfVectorizer)        ──> Re-weights words by inverse document rarity
              │
              ▼
3. Word Embeddings (Word2Vec/GloVe) ──> Dense vector spaces (captures synonyms: 'king - man + woman = queen')
              │
              ▼
4. Transformers (BERT / LLMs)      ──> Full bidirectional contextual attention ('apple' tech vs fruit)
```

## Architectural and Pipeline Context
Upgrading `main.py` from `CountVectorizer` to `TfidfVectorizer` requires changing only a single line in the pipeline:
```python
from sklearn.feature_extraction.text import TfidfVectorizer

model = Pipeline(
    [
        ("vectorizer", TfidfVectorizer(stop_words="english", ngram_range=(1, 2))),
        ("classifier", MultinomialNB()),
    ]
)
```
Because both vectorizers share the identical scikit-learn transformer interface, the downstream classifier, evaluation metrics, and inference logic remain completely unchanged!

## Relevant Code
Comparing the two vectorizers:
```python
# Baseline in main.py:
CountVectorizer(stop_words="english", ngram_range=(1, 2))

# Advanced TF-IDF Alternative:
from sklearn.feature_extraction.text import TfidfVectorizer
TfidfVectorizer(stop_words="english", ngram_range=(1, 2), sublinear_tf=True)
```

## Line-by-Line Code Breakdown
- `TfidfVectorizer` automatically executes tokenization, stop-word removal, n-gram extraction, TF-IDF calculation, and L2 vector normalization.
- `sublinear_tf=True` replaces raw term count $tf$ with $1 + \log(tf)$, dampening the effect of repeated words.

## Worked Example
Suppose we have 90 headlines:
- The word `"new"` appears in 45 headlines across sports, tech, and food.
  $$\text{IDF}(\text{"new"}) = \log\left(\frac{91}{46}\right) + 1 = \log(1.978) + 1 \approx 0.68 + 1 = 1.68$$
- The word `"phishing"` appears in only 3 tech headlines.
  $$\text{IDF}(\text{"phishing"}) = \log\left(\frac{91}{4}\right) + 1 = \log(22.75) + 1 \approx 3.12 + 1 = 4.12$$

Notice that `"phishing"` receives an IDF weight of **4.12**, which is nearly $2.5\times$ higher than the generic word `"new"` ($1.68$).
When vectorizing a cybersecurity headline, the diagnostic term `"phishing"` dominates the feature vector, sharpening category separation!

## Step-by-Step Student Instructions
1. Open a Python terminal.
2. Import `TfidfVectorizer` from `sklearn.feature_extraction.text`.
3. Fit a small corpus:
   ```python
   corpus = ["new python tool", "new cricket match", "new spicy recipe"]
   tfidf = TfidfVectorizer()
   X = tfidf.fit_transform(corpus)
   ```
4. Print feature names and inspect the TF-IDF weights:
   ```python
   for word, idf in zip(tfidf.get_feature_names_out(), tfidf.idf_):
       print(f"{word:10s}: {idf:.2f}")
   ```
5. Confirm that `"new"` receives the lowest IDF score because it appears in all three documents.

## Expected Output or Observable Behaviour
- Common words across all documents receive low IDF values (~1.0).
- Rare words specific to single documents receive high IDF values (>1.5).

## Practical Exercises
- **Exercise 4.1**: If a word appears in every single document in a corpus of 1,000 documents, what will its IDF score be?
- **Exercise 4.2**: What is the primary limitation of both BoW and TF-IDF that transformer models (like BERT) successfully resolve? (Hint: word order and context-dependent meanings).

## Common Mistakes and Debugging
| Mistake | Consequence | Proper Approach |
|---|---|---|
| Thinking `MultinomialNB` cannot accept TF-IDF weights | Fractional weights work seamlessly with MultinomialNB in scikit-learn | MultinomialNB supports non-negative float inputs like TF-IDF directly |
| Using TF-IDF on tiny 5-document datasets | IDF calculations need diverse documents to accurately estimate rarity | Use CountVectorizer for tiny toy datasets, TF-IDF for larger corpora |
| Assuming TF-IDF solves word order | TF-IDF still discards word order and grammar | Incorporate bigrams or upgrade to Transformer architectures |

## Best Practices and Operational Considerations
- Use `TfidfVectorizer` as the default baseline feature extractor for real-world text classification tasks.
- For modern enterprise search or intent classification with nuanced context, consider fine-tuning pre-trained transformer embeddings (e.g., `sentence-transformers` or `distilbert`).

## Summary and Key Takeaways
- Raw counts in `CountVectorizer` allow ubiquitous non-stop words to exert excessive influence.
- `TfidfVectorizer` dampens common words and amplifies rare, domain-specific terminology.
- The scikit-learn Pipeline architecture allows seamless replacement of `CountVectorizer` with `TfidfVectorizer`.
- Modern NLP extends from BoW and TF-IDF to dense vector embeddings and contextual Transformer models.

## Knowledge-Check Questions and References
1. What does the acronym TF-IDF stand for?
2. How does IDF penalize words that appear in nearly all documents?
3. What parameter in a Pipeline must change to switch from CountVectorizer to TfidfVectorizer?
4. How do Transformer models improve upon Bag-of-Words representations?

*References*:
- Salton, G., & Buckley, C. (1988). *Term-weighting approaches in automatic text retrieval*. Information Processing & Management.
- Vaswani et al. (2017). *Attention Is All You Need*. Advances in Neural Information Processing Systems (NeurIPS).
