# Module 6 Exercises: Extensions & TF-IDF Upgrade

## Exercise 6.1: Custom Adversarial Headline Testing (15 min)
**Objective:** Evaluate custom hybrid and ambiguous headlines using the trained model pipeline.
**Problem Statement:** Design 4 challenging headlines to test the boundaries of the news classifier.

**Requirements:**
1. Write 1 headline that attempts to fool the model into predicting `sports` for a food story.
2. Write 1 headline that attempts to fool the model into predicting `technology` for a sports story.
3. Write 1 headline that uses tech terminology in a culinary context (e.g., 3D food printing).
4. Run all 4 headlines through `model.predict()` and `model.predict_proba()`.
5. Record the predicted class and confidence percentages.

**Acceptance Criteria:**
- [ ] 4 distinct adversarial headlines crafted.
- [ ] Model predictions and calibrated confidence extracted.
- [ ] Explanation of which specific tokens drove the winning decision for each headline.

---

## Exercise 6.2: TF-IDF Pipeline Benchmarking (15 min)
**Objective:** Swap `CountVectorizer` for `TfidfVectorizer` and compare classification metrics.
**Problem Statement:** Upgrade the pipeline in `main.py` to use `TfidfVectorizer(stop_words="english", ngram_range=(1, 2))` and compare performance.

**Requirements:**
1. Import `TfidfVectorizer` from `sklearn.feature_extraction.text`.
2. Construct a pipeline using `TfidfVectorizer` and `MultinomialNB`.
3. Fit on `X_train, y_train` and evaluate on `X_test, y_test`.
4. Compare accuracy and classification report with the CountVectorizer baseline.
5. Evaluate the 5 test headlines and compare confidence scores between CountVectorizer and TF-IDF.

**Acceptance Criteria:**
- [ ] TF-IDF pipeline successfully constructed and trained.
- [ ] Full evaluation report generated.
- [ ] Clear analysis comparing confidence calibration between raw counts and TF-IDF.
