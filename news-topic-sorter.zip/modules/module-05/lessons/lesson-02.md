# Lesson 02: The Multi-Class Confusion Matrix

**Lesson ID:** lesson-02  
**Module:** module-05  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Construct and interpret a multi-class **confusion matrix**.
- Identify **true labels** along the rows and **predicted labels** along the columns.
- Distinguish between **diagonal elements** (correct classifications) and **off-diagonal elements** (errors).
- Use `ConfusionMatrixDisplay` in matplotlib to render and save a visual matrix plot.

## Prerequisites
- Lesson 01: Multi-Class Evaluation Metrics.
- Basic understanding of 2D grid coordinates and matplotlib plotting.

## Industry and Real-World Motivation
Summary metrics like 92% accuracy tell you that an algorithm makes mistakes, but they cannot tell you **which** mistakes it is making. Is the model mistaking sports for tech, or food for sports? 

A confusion matrix is the supreme diagnostic tool for classification systems. By mapping every single prediction against its actual ground truth, the confusion matrix reveals asymmetric error patterns, exposes systematic class confusions, and directly guides data collection and feature engineering efforts.

## Concept Explanation
### Confusion Matrix Structure
A multi-class confusion matrix $C$ is a $K \times K$ square grid where $K$ is the number of classes (here $K=3$):
- **Rows** represent the **True (Actual) Classes**.
- **Columns** represent the **Predicted Classes**.

$$\begin{array}{c|ccc}
& \text{Pred: Food} & \text{Pred: Sports} & \text{Pred: Tech} \\
\hline
\text{True: Food} & C_{0, 0} & C_{0, 1} & C_{0, 2} \\
\text{True: Sports} & C_{1, 0} & C_{1, 1} & C_{1, 2} \\
\text{True: Tech} & C_{2, 0} & C_{2, 1} & C_{2, 2}
\end{array}$$

### Reading the Matrix:
- **Main Diagonal ($C_{i, i}$)**: Cells where True Class == Predicted Class. These represent correct classifications. The darker the blue along the diagonal, the better the model!
- **Off-Diagonal Cells ($C_{i, j}$ where $i \neq j$)**: Misclassifications.
  - Row `Sports`, Column `Tech`: A sports article that was mistakenly predicted as technology.
  - Row `Tech`, Column `Sports`: A technology article that was mistakenly predicted as sports.

### Rendering with Matplotlib
In `main.py`, the confusion matrix is plotted using `ConfusionMatrixDisplay`:
- `cmap="Blues"`: Applies a clean monochromatic color gradient where higher sample counts appear as deeper blue shades.
- `colorbar=False`: Suppresses the side colorbar for a compact layout.
- `fig.savefig(OUT / "confusion_matrix.png", dpi=150, bbox_inches="tight")`: Saves a sharp 150 DPI image.

## Architectural and Pipeline Context
The confusion matrix is generated after computing evaluation metrics:
```
y_test & predictions ──> confusion_matrix() ──> ConfusionMatrixDisplay() ──> outputs/confusion_matrix.png
```

## Relevant Code
From `main.py` (lines 76-84):
```python
    # ---- Confusion matrix ---------------------------------------------
    labels = sorted(df["topic"].unique())
    cm = confusion_matrix(y_test, predictions, labels=labels)
    fig, ax = plt.subplots(figsize=(5.5, 4.5))
    ConfusionMatrixDisplay(cm, display_labels=labels).plot(ax=ax, cmap="Blues", colorbar=False)
    ax.set_title("News topic classification")
    fig.tight_layout()
    fig.savefig(OUT / "confusion_matrix.png", dpi=150, bbox_inches="tight")
    plt.close(fig)
```

## Line-by-Line Code Breakdown
- Line 76: `labels = sorted(df["topic"].unique())` extracts the sorted category list `['food', 'sports', 'technology']` to ensure consistent row/column alignment.
- Line 77: `confusion_matrix(y_test, predictions, labels=labels)` computes the raw $3 \times 3$ NumPy array.
- Line 78: Creates a matplotlib figure with compact dimensions `figsize=(5.5, 4.5)`.
- Line 79: Instantiates `ConfusionMatrixDisplay` with the matrix and label names, plotting onto axis `ax` with the `"Blues"` colormap.
- Line 80: Sets plot title to `"News topic classification"`.
- Lines 81-82: Adjusts layout padding and saves the figure to `outputs/confusion_matrix.png` at 150 DPI.
- Line 83: `plt.close(fig)` releases GUI memory.

## Worked Example
In `main.py`, on the 23 test samples:
```python
cm = confusion_matrix(y_test, predictions, labels=['food', 'sports', 'technology'])
# Array output:
# [[7, 0, 0],
#  [0, 8, 0],
#  [0, 0, 8]]
```
Visual interpretation:
- Row 0 (True Food): 7 samples classified as Food, 0 as Sports, 0 as Tech.
- Row 1 (True Sports): 0 classified as Food, 8 classified as Sports, 0 as Tech.
- Row 2 (True Tech): 0 classified as Food, 0 as Sports, 8 classified as Tech.

Every single off-diagonal cell is zero, visually demonstrating 100% test accuracy.

## Step-by-Step Student Instructions
1. Run `python3 main.py`.
2. Open the file `outputs/confusion_matrix.png` using an image viewer.
3. Observe the three labeled axes: "Predicted label" on the x-axis, "True label" on the y-axis.
4. Verify the numbers inside each cell: 7 in the top-left, 8 in the center, 8 in the bottom-right.
5. Confirm that all other squares are light white with zero.

## Expected Output or Observable Behaviour
- An image file `outputs/confusion_matrix.png` is generated (~25 KB).
- The plot shows a clear 3x3 grid with category labels `food`, `sports`, `technology` on both axes.

## Practical Exercises
- **Exercise 2.1**: If cell $(1, 2)$ contained the number 3, what specific type of real-world error would that indicate?
- **Exercise 2.2**: Why is it critical to explicitly pass `labels=labels` to both `confusion_matrix` and `ConfusionMatrixDisplay`?

## Common Mistakes and Debugging
| Mistake | Consequence | Correction |
|---|---|---|
| Omitting `labels=labels` | If a test split happens to lack one class, the matrix shrinks to $2 \times 2$, misaligning axes | Always pass explicit sorted label list |
| Omitting `plt.close(fig)` | Memory leaks in automated testing loops or server processes | Always call `plt.close(fig)` after saving plots |
| Forgetting `matplotlib.use("Agg")` | Crashes with display errors on headless Linux servers | Set headless Agg backend before importing pyplot |

## Best Practices and Operational Considerations
- Always normalize confusion matrices (`normalize='true'`) when evaluating datasets with significant class imbalance to view percentages rather than raw counts.
- Keep confusion matrix plots uncluttered: omit colorbars if sample numbers are directly readable inside cells.

## Summary and Key Takeaways
- The confusion matrix maps true classes (rows) against predicted classes (columns).
- Diagonal elements represent correct classifications; off-diagonal elements expose specific misclassification errors.
- `ConfusionMatrixDisplay` provides an elegant, publication-ready visualization in matplotlib.

## Knowledge-Check Questions and References
1. What do the rows and columns represent in a standard scikit-learn confusion matrix?
2. Where do correct predictions appear in a confusion matrix?
3. What values appear along the diagonal in `main.py`'s confusion matrix?
4. What parameter sets the colormap to shades of blue in `ConfusionMatrixDisplay`?

*References*:
- Scikit-learn API: `sklearn.metrics.ConfusionMatrixDisplay` (https://scikit-learn.org/stable/modules/generated/sklearn.metrics.ConfusionMatrixDisplay.html).
