# Lesson 01: Multi-Class Evaluation Metrics: Accuracy, Precision, Recall & F1-Score

**Lesson ID:** lesson-01  
**Module:** module-05  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Calculate overall classification **accuracy** on test predictions.
- Define **precision**, **recall**, and **F1-score** in a multi-class setting.
- Interpret the scikit-learn `classification_report` output.
- Distinguish between **macro average** and **weighted average** metrics.

## Prerequisites
- Module 04: MultinomialNB for Topic Classification.
- Basic fractions and percentage calculations.

## Industry and Real-World Motivation
In commercial news aggregation, raw accuracy can mask critical blind spots. Imagine an aggregator where 90% of all articles are general news and only 10% are breaking cybersecurity alerts. A naive classifier that never predicts cybersecurity achieves 90% accuracy, yet catastrophic security breaches go undetected.

To assess whether a model serves readers across all sections equally, data scientists rely on a multi-metric diagnostic suite: accuracy for overall health, precision to measure false alarm rates, recall to measure coverage, and F1-score to capture balanced performance per class.

## Concept Explanation
### The Evaluation Metrics
For each topic class $c \in \{\text{food}, \text{sports}, \text{technology}\}$:
- **True Positives ($TP_c$)**: Articles correctly predicted as topic $c$.
- **False Positives ($FP_c$)**: Articles from other topics mistakenly predicted as topic $c$.
- **False Negatives ($FN_c$)**: Articles belonging to topic $c$ that were mistakenly predicted as another topic.

1. **Accuracy**:
   $$\text{Accuracy} = \frac{\sum TP_c}{\text{Total Test Samples}} = \frac{7 + 8 + 8}{23} = \frac{23}{23} = 100.0\%$$
   Measures the fraction of all test predictions that were correct.

2. **Precision**:
   $$\text{Precision}_c = \frac{TP_c}{TP_c + FP_c}$$
   Answers: *"When the model predicts this topic, how often is it actually right?"* High precision means low false alarms.

3. **Recall**:
   $$\text{Recall}_c = \frac{TP_c}{TP_c + FN_c}$$
   Answers: *"Of all real articles belonging to this topic, what percentage did the model catch?"* High recall means minimal missed stories.

4. **F1-Score**:
   $$\text{F1} = 2 \times \frac{\text{Precision} \times \text{Recall}}{\text{Precision} + \text{Recall}}$$
   The harmonic mean of precision and recall. Punishes extreme imbalances between precision and recall.

### Macro vs. Weighted Average
- **Macro Average**: Computes metrics independently for each class and calculates the unweighted arithmetic mean:
  $$\text{Macro F1} = \frac{\text{F1}_{\text{food}} + \text{F1}_{\text{sports}} + \text{F1}_{\text{tech}}}{3}$$
  Treats all classes as equally important, regardless of sample count.
- **Weighted Average**: Weights each class metric by its test sample count (**support**):
  $$\text{Weighted F1} = \sum_{c} \left( \frac{\text{Support}_c}{N_{\text{test}}} \times \text{F1}_c \right)$$

## Architectural and Pipeline Context
Metrics are computed immediately after test set inference in `main.py`:
```
X_test ──> model.predict() ──> predictions ──┬──> accuracy_score(y_test, predictions)
                                             └──> classification_report(y_test, predictions)
```

## Relevant Code
From `main.py` (lines 19, 43-50):
```python
from sklearn.metrics import accuracy_score, classification_report
...
    predictions = model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)

    print("=" * 60)
    print("THE NEWS TOPIC SORTER")
    print("=" * 60)
    print(f"Accuracy: {accuracy:.1%}\n")
    print(classification_report(y_test, predictions, zero_division=0))
```

## Line-by-Line Code Breakdown
- Line 19: Imports metric evaluation utilities from `sklearn.metrics`.
- Line 43: Generates test set predictions using `model.predict(X_test)`.
- Line 44: Computes overall accuracy by comparing `y_test` ground-truth to `predictions`.
- Line 49: Displays accuracy formatted as a percentage: `Accuracy: 100.0%`.
- Line 50: Prints `classification_report(..., zero_division=0)`. The `zero_division=0` parameter prevents runtime warnings if a class has zero predicted samples.

## Worked Example
In `main.py`, the test set contains 23 samples (7 food, 8 sports, 8 technology).
Because every single test sample is correctly classified:
```
              precision    recall  f1-score   support

        food       1.00      1.00      1.00         7
      sports       1.00      1.00      1.00         8
  technology       1.00      1.00      1.00         8

    accuracy                           1.00        23
   macro avg       1.00      1.00      1.00        23
weighted avg       1.00      1.00      1.00        23
```
- For food: $TP=7, FP=0, FN=0 \rightarrow \text{Precision}=7/7=1.00, \text{Recall}=7/7=1.00$.
- For sports: $TP=8, FP=0, FN=0 \rightarrow \text{Precision}=8/8=1.00, \text{Recall}=8/8=1.00$.
- For technology: $TP=8, FP=0, FN=0 \rightarrow \text{Precision}=8/8=1.00, \text{Recall}=8/8=1.00$.
- Total Support: $7 + 8 + 8 = 23$ test samples.

## Step-by-Step Student Instructions
1. Run `python3 main.py` and inspect the printed classification report.
2. Locate the "support" column. Verify that it shows the exact sample count for each class.
3. Compare the "macro avg" and "weighted avg" values.
4. Note how `zero_division=0` ensures graceful handling when no positive predictions occur.

## Expected Output or Observable Behaviour
- Accuracy displays `100.0%`.
- The classification report outputs a clean monospace table with 4 columns: precision, recall, f1-score, and support.

## Practical Exercises
- **Exercise 1.1**: Suppose in an updated test set of 20 tech articles, the model correctly found 18, but also mistakenly labeled 2 sports articles as tech. Calculate the precision and recall for technology.
- **Exercise 1.2**: Why is the macro average more sensitive to poor performance on minority classes than the weighted average?

## Common Mistakes and Debugging
| Mistake | Consequence | Proper Approach |
|---|---|---|
| Inverting the argument order: `accuracy_score(predictions, y_test)` | Some sklearn metrics are asymmetric and fail or give misleading errors | Always pass ground truth first: `metric(y_true, y_pred)` |
| Omitting `zero_division=0` | Prints ugly runtime warning `UndefinedMetricWarning` if any class has 0 predictions | Always set `zero_division=0` in production reporting |
| Relying solely on accuracy in imbalanced datasets | High accuracy can conceal 0% recall on critical minority classes | Inspect precision, recall, and F1-score across all categories |

## Best Practices and Operational Considerations
- Always evaluate precision and recall independently per class.
- Use macro average F1-score as the primary optimization objective when all classes are equally critical to users.

## Summary and Key Takeaways
- Accuracy measures total correct predictions over total samples (100.0% in `main.py`).
- Precision measures prediction purity ($TP / (TP + FP)$); recall measures coverage ($TP / (TP + FN)$).
- F1-score provides a balanced harmonic mean of precision and recall.
- `classification_report` produces a complete per-class diagnostic breakdown.

## Knowledge-Check Questions and References
1. What is the formula for classification accuracy?
2. How does precision differ from recall?
3. What does the "support" column indicate in `classification_report`?
4. What is the purpose of setting `zero_division=0`?

*References*:
- Scikit-learn User Guide: *Model evaluation: quantifying the quality of predictions* (https://scikit-learn.org/stable/modules/model_evaluation.html#classification-metrics).
