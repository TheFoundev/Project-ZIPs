# Lesson 04: Extracting Feature Importance & Strongest Words per Topic

**Lesson ID:** lesson-04  
**Module:** module-05  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Access the learned conditional feature log-probabilities in `MultinomialNB`.
- Use `np.argsort()` to rank vocabulary features by topic association.
- Extract and display the top 8 strongest words for sports, technology, and food.
- Explain the role of model interpretability in building trust with editorial stakeholders.

## Prerequisites
- Lesson 03: Error Analysis: Why Topics Get Confused.
- Basic understanding of NumPy array indexing and slicing (`[-8:][::-1]`).

## Industry and Real-World Motivation
In high-stakes enterprise applications, "black box" models that cannot explain their decisions face severe resistance from domain experts. If an automated news router misfiles a sensitive article, editorial leadership needs to know **why** the decision was made.

One of the greatest operational strengths of Naive Bayes is complete **transparency and interpretability**. By inspecting feature log-probabilities, engineers can extract the exact words and phrases that exert the strongest pull toward each topic, audit the model for bias or spurious correlations, and demonstrate accountability to editorial stakeholders.

## Concept Explanation
### Feature Log-Probabilities in MultinomialNB
During training, `MultinomialNB` learns the smoothed log-probability of every vocabulary word $w$ given each class $c$:
$$\text{feature\_log\_prob\_}[c, j] = \log P(w_j | c)$$
- Values are negative numbers (since probabilities are $\le 1.0$, $\log(p) \le 0$).
- Higher (less negative) values indicate that a word appears with higher relative frequency in that class.
  - E.g., $\log(0.05) \approx -2.99$ (strong association).
  - E.g., $\log(0.001) \approx -6.91$ (very weak association).

### Ranking Words with NumPy `np.argsort()`
To find the most influential words for topic $c$:
1. Retrieve the row of log-probabilities: `log_probs = classifier.feature_log_prob_[index]`.
2. Apply `np.argsort(log_probs)`: Returns the feature indices sorted from lowest to highest log-probability.
3. Slice the last 8 indices: `[-8:]` extracts the 8 highest values.
4. Reverse the order: `[::-1]` arranges them in descending order (strongest first).
5. Map indices to words using `names[top]`.

## Architectural and Pipeline Context
Feature extraction connects the classifier's internal parameter arrays to the human-readable vocabulary:
```
classifier.feature_log_prob_ ──> np.argsort()[-8:][::-1] ──> names[top] ──> Top Words per Topic
```

## Relevant Code
From `main.py` (lines 52-60):
```python
    vectorizer = model.named_steps["vectorizer"]
    classifier = model.named_steps["classifier"]
    names = vectorizer.get_feature_names_out()
    classes = list(classifier.classes_)
    print("Strongest words per topic:")
    for index, topic in enumerate(classes):
        top = np.argsort(classifier.feature_log_prob_[index])[-8:][::-1]
        print(f"  {topic:10s}: {', '.join(names[top])}")
```

## Line-by-Line Code Breakdown
- Lines 52-53: Unpacks the vectorizer and classifier from `model.named_steps`.
- Line 54: Retrieves the 282 feature names from the vectorizer.
- Line 55: Obtains the list of target class names in alphabetical order (`food`, `sports`, `technology`).
- Line 57: Loops through each topic index and name.
- Line 58: Sorts the log-probabilities for class `index` and extracts the top 8 feature indices in descending order.
- Line 59: Prints the topic name padded to 10 characters followed by the comma-separated top 8 feature names.

## Worked Example
When `main.py` executes, it prints the following strongest words:
```
Strongest words per topic:
  food      : food, street, street food, recipe, expands weekend, farmers market, farmers, expands
  sports    : announces, comeback victory, twice comeback, twice, cricket, cricket league, league announces, comeback
  technology: new, ai, train, unveil faster, unveil, faster, faster way, train small
```

Key Insights:
- **Food**: Strong culinary keywords (`food`, `recipe`) combined with market bigrams (`street food`, `farmers market`).
- **Sports**: Highly athletic vocabulary (`comeback victory`, `cricket league`, `twice`). Notice how bigrams capture the exact phrasing of competitive match reporting.
- **Technology**: Innovation verbs and technical terminology (`ai`, `unveil faster`, `faster way`, `train small`).

## Step-by-Step Student Instructions
1. Run `python3 main.py` and inspect the "Strongest words per topic" output.
2. In a Python terminal, extract the top 3 words for `food` manually:
   ```python
   top3 = np.argsort(classifier.feature_log_prob_[0])[-3:][::-1]
   print(names[top3])
   ```
3. Check the actual numerical log-probabilities:
   ```python
   print(classifier.feature_log_prob_[0, top3])
   ```
4. Verify that the log-probability values are negative and in descending numerical order.

## Expected Output or Observable Behaviour
- Top words display clear, intuitive domain associations for each topic.
- Multi-word bigrams appear alongside single unigrams, proving that `ngram_range=(1, 2)` effectively extracted phrase features.

## Practical Exercises
- **Exercise 4.1**: How would you modify the slice `[-8:][::-1]` to display the top 15 words instead of the top 8?
- **Exercise 4.2**: Why does `np.argsort` sort in ascending order by default, and why is `[::-1]` needed?

## Common Mistakes and Debugging
| Mistake | Consequence | Proper Approach |
|---|---|---|
| Omitting `[::-1]` | Prints the 8 weakest (lowest probability) words instead of the strongest | Use `[-8:][::-1]` to reverse array into descending order |
| Accessing `classes_` from vectorizer | `AttributeError`: vectorizers have no `classes_` | Access `classes_` from `classifier` |
| Indexing log-probs with string topic name | `IndexError`: matrix rows are indexed by integer `index`, not string `'food'` | Use `classes.index(topic)` or `enumerate(classes)` |

## Best Practices and Operational Considerations
- Always audit top features before deploying a text model to ensure it hasn't latched onto spurious keywords (e.g., journalist bylines or website URLs).
- Share top keyword lists with editorial stakeholders to build confidence in automated routing systems.

## Summary and Key Takeaways
- `classifier.feature_log_prob_` holds the smoothed conditional log-probabilities $\log P(w|c)$.
- `np.argsort()` enables fast extraction and ranking of the most influential words per topic.
- Extracting top keywords provides complete model interpretability and transparency.

## Knowledge-Check Questions and References
1. What attribute of `MultinomialNB` stores feature log-probabilities?
2. What does `np.argsort()` return?
3. Why are feature log-probabilities negative numbers?
4. What are two top phrases learned for the `sports` topic in `main.py`?

*References*:
- NumPy documentation: `numpy.argsort` (https://numpy.org/doc/stable/reference/generated/numpy.argsort.html).
- Ribeiro, M. T., Singh, S., & Guestrin, C. (2016). *"Why Should I Trust You?": Explaining the Predictions of Any Classifier*. ACM SIGKDD.
