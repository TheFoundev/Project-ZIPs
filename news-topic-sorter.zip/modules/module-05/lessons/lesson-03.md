# Lesson 03: Error Analysis: Why Topics Get Confused

**Lesson ID:** lesson-03  
**Module:** module-05  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Conduct structured **error analysis** on text classification outputs.
- Explain why sports and technology share higher semantic overlap than food.
- Analyze how shared non-stop words (e.g., "team", "tests", "new") can mislead Bag-of-Words models.
- Formulate data augmentation strategies to resolve category confusion.

## Prerequisites
- Lesson 02: The Multi-Class Confusion Matrix.
- Understanding of vocabulary overlap and polysemy.

## Industry and Real-World Motivation
When deploying machine learning models in production, achieving 100% test accuracy on a small synthetic benchmark is never the finish line. In the wild, real-world data drifts, new vocabulary emerges, and ambiguous headlines challenge classification boundaries.

Conducting rigorous error analysis—inspecting false positives and false negatives—is where the real data science happens. Rather than blindly trying more complex algorithms, top practitioners inspect misclassified samples to understand what misleading words confused the model, and then refine taxonomies, expand training data, or add specialized features.

## Concept Explanation
### Asymmetric Domain Distances
News topics do not occupy equidistant positions in semantic space. 

```
               [ FOOD ]
              /        \
   (Culinary /          \ (Physical
  Ingredients)          Food Tech)
            /            \
       [ SPORTS ] ────── [ TECHNOLOGY ]
             (Performance / Tools /
              Competitions / Speed)
```

1. **Food vs. Sports / Tech**: The vocabulary of food is grounded in culinary ingredients, recipes, flavors, and dining establishments (`noodles`, `pasta`, `spicy`, `cafe`, `vegetables`). These words almost never appear in athletic fixtures or software documentation. Thus, food is easily separated with virtually zero confusion.
2. **Sports vs. Technology**: Both domains revolve around competition, performance optimization, metrics, tools, speed, and organizational announcements:
   - Sports: `"Team tests new equipment ahead of championship match"`
   - Technology: `"Team tests new algorithm ahead of developer conference"`
   Notice that 5 out of 8 words (`team`, `tests`, `new`, `ahead`, `of`) are identical! If a headline lacks explicit anchor words like `stadium` or `software`, a Bag-of-Words model can easily mistake sports for tech or vice versa.

### Error Analysis Checklist
When investigating a misclassified headline:
1. **Identify the Out-of-Vocabulary (OOV) Words**: Were the key domain terms missing from the training dictionary?
2. **Inspect the Polysemous Words**: Did words like "apple", "pitch", or "lead" trigger probability weight for the wrong category?
3. **Examine Probability Margins**: Was the error a high-confidence mistake (overconfident model) or a borderline tie (34% vs 33%)?

## Architectural and Pipeline Context
Error analysis leverages the model's learned log-probabilities to explain misclassifications:
```
Misclassified Headline ──> Token Inspection ──> feature_log_prob_ Lookup ──> Root Cause Identified
```

## Relevant Code
From `main.py` (lines 7-8, 93):
```python
# Multi-class text classification with three topics: sports, technology, and
# food. The confusion matrix shows which topics are easiest to confuse.
...
# Try this: add a 'sports + food' headline and see which topic wins.
```

## Line-by-Line Code Breakdown
- Lines 7-8: Establishes that analyzing topic confusion is a core learning objective of the project.
- Line 93: Suggests experimenting with hybrid headlines (`'sports + food'`) to observe the competitive resolution of ambiguous inputs.

## Worked Example
Suppose an adversarial headline is fed to the classifier:
`"Football team opens new automated smoothie bar at training stadium"`

Analysis of token evidence:
- Sports tokens: `'football'` (sports), `'team'` (sports/tech), `'stadium'` (sports), `'training'` (sports).
- Food tokens: `'smoothie'` (food), `'bar'` (food).
- Technology tokens: `'automated'` (tech), `'new'` (tech).

Model posterior probability calculation:
- $P(\text{sports}|x) = 0.58$ (58%)
- $P(\text{food}|x) = 0.32$ (32%)
- $P(\text{technology}|x) = 0.10$ (10%)

Result: Sports wins because athletic terms outnumber and outweigh the culinary terms in the headline. However, food captures 32% of the probability mass, clearly signalling domain crossover!

## Step-by-Step Student Instructions
1. Review the docstring in `main.py` lines 6-8.
2. In a Python scratchpad, create an ambiguous headline:
   `ambiguous = ["New wearable fitness tracker monitors athletes during marathon"]`
3. Predict its topic and probabilities using `model.predict(ambiguous)` and `model.predict_proba(ambiguous)`.
4. Observe whether the model classifies it as technology or sports, and note the probability spread.

## Expected Output or Observable Behaviour
- Ambiguous or cross-domain headlines distribute probability mass across multiple classes.
- Sports and technology frequently split probability (e.g., 55% sports vs 45% technology), whereas food receives <5%.

## Practical Exercises
- **Exercise 3.1**: Write a headline that intentionally causes the model to confuse `technology` with `food` (e.g., food delivery app algorithms).
- **Exercise 3.2**: If error analysis reveals that sports and technology headlines are repeatedly confused due to the word `"team"`, how could feature engineering address this? (Hint: consider bigrams or stop-word tuning).

## Common Mistakes and Debugging
| Mistake | Consequence | Proper Approach |
|---|---|---|
| Assuming 100% test accuracy guarantees zero errors in production | Synthetic test splits don't reflect live data noise | Test with diverse, messy, real-world headlines |
| Blaming the algorithm rather than the data | Changing from Naive Bayes to deep learning won't solve ambiguous text with identical words | Augment training data with targeted boundary examples |
| Treating low-confidence correct predictions as complete successes | A correct prediction with 34% confidence is fragile and easily flipped by slight noise | Treat low-confidence predictions as borderline risks requiring review |

## Best Practices and Operational Considerations
- Maintain a dedicated "hard test set" containing known ambiguous and boundary cases to evaluate model robustness.
- Regularly review confusion matrices on live production logs to identify new vocabulary drift.

## Summary and Key Takeaways
- Error analysis reveals the root linguistic causes of classification mistakes.
- Sports and technology exhibit greater vocabulary overlap (performance, speed, tools) than food, making them harder to separate.
- Hybrid headlines produce split probability distributions that can be caught using confidence thresholds.

## Knowledge-Check Questions and References
1. Why is food less susceptible to topic confusion than sports or technology?
2. What words are frequently shared between sports and technology articles?
3. What is an out-of-vocabulary (OOV) word?
4. How do hybrid headlines reflect topic ambiguity in `predict_proba`?

*References*:
- Ng, A. (2022). *Machine Learning Yearning*, Chapter 13: Error Analysis.
