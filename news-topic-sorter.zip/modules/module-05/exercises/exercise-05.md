# Module 5 Exercises: Evaluation, Confusion & Keyword Extraction

## Exercise 5.1: Multi-Class Confusion Matrix & Metric Calculation (15 min)
**Objective:** Calculate accuracy, precision, recall, and F1-score by hand from a given confusion matrix.
**Problem Statement:** An evaluation run on an expanded test set produces the following confusion matrix:
```
               Pred Food   Pred Sports   Pred Tech
Actual Food        10           1            1
Actual Sports       0          12            2
Actual Tech         1           1           12
```

**Requirements:**
1. Calculate the total number of test samples.
2. Calculate overall accuracy.
3. Calculate Precision, Recall, and F1-score for `sports`.
4. Identify which class had the highest number of false positives.

**Acceptance Criteria:**
- [ ] Correct total sample count calculated ($12 + 14 + 14 = 40$).
- [ ] Correct accuracy computed ($34 / 40 = 85.0\%$).
- [ ] Sports Precision ($12 / 14 = 85.7\%$) and Recall ($12 / 14 = 85.7\%$) computed.
- [ ] Correctly identifies the class with the most false positives (`tech` with 3 FP).

---

## Exercise 5.2: Programmatic Top Keyword Extraction (15 min)
**Objective:** Write a Python function to extract the top $N$ keywords for any class.
**Problem Statement:** Create an interpretability utility that allows journalists to inspect the top keywords for any topic.

**Requirements:**
1. Train the pipeline on `headlines.csv`.
2. Write a function `get_top_keywords(model, topic_name, n=5)`.
3. The function must look up the topic index in `classifier.classes_`.
4. Use `np.argsort` to extract the top $n$ feature names.
5. Return the list of top words and their corresponding probability percentages.

**Acceptance Criteria:**
- [ ] Function correctly retrieves class index and log-probabilities.
- [ ] Accurately extracts top $n$ features.
- [ ] Successfully outputs top keywords for `'technology'`.
