# Lesson 04: Scikit-Learn Pipeline Integration

**Lesson ID:** lesson-04  
**Module:** module-03  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Construct a scikit-learn `Pipeline` chaining a text vectorizer and a classifier.
- Explain the role of `named_steps` in accessing internal pipeline components.
- Inspect the learned vocabulary using `get_feature_names_out()`.
- Explain how pipelines prevent data leakage during cross-validation and production inference.

## Prerequisites
- Lesson 03: N-Grams and Phrase Capture.
- Familiarity with Python dictionary syntax and object properties.

## Industry and Real-World Motivation
In enterprise machine learning engineering, loose scripts with disconnected preprocessing functions are considered severe technical debt. If a preprocessing step changes (e.g., adding a new stop word or altering n-gram ranges), any separate inference script or deployment endpoint that isn't updated in lockstep will silently produce corrupted predictions.

Scikit-learn's `Pipeline` pattern bundles feature extraction and estimation into a single serialized object. When a model is exported to production, the vectorizer and classifier travel together as one atomic unit, guaranteeing that test data is transformed with the exact parameters and vocabulary used during training.

## Concept Explanation
### Pipeline Construction Syntax
A scikit-learn `Pipeline` is instantiated with a list of `(name_string, estimator_or_transformer_object)` tuples:
```python
model = Pipeline(
    [
        ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
        ("classifier", MultinomialNB()),
    ]
)
```
- Every step except the last must be a **transformer** implementing `.fit()` and `.transform()`.
- The final step must be an **estimator** implementing `.fit()` (and optionally `.predict()`, `.predict_proba()`).

### Accessing Internal Pipeline Stages via `named_steps`
Once fitted, internal components of the pipeline are accessible via the `named_steps` dictionary attribute:
```python
vectorizer = model.named_steps["vectorizer"]
classifier = model.named_steps["classifier"]
```
This allows developers to inspect learned vocabulary parameters, retrieve feature names, or query model weights without disassembling the pipeline.

### Vocabulary Inspection
The vectorizer's vocabulary mapping can be inspected using:
```python
names = vectorizer.get_feature_names_out()
```
This returns a 1D NumPy array of length 282 containing every unigram and bigram learned from the training split.

## Architectural and Pipeline Context
The pipeline architecture abstracts away intermediate matrices:
```
Raw Text Series ──> [ Pipeline.fit() ] ──> Trained End-to-End Model Object
                         │
        ┌────────────────┴────────────────┐
        ▼                                 ▼
model.named_steps["vectorizer"]    model.named_steps["classifier"]
(CountVectorizer instance)         (MultinomialNB instance)
```

## Relevant Code
From `main.py` (lines 36-42, 52-55):
```python
    model = Pipeline(
        [
            ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
            ("classifier", MultinomialNB()),
        ]
    )
    model.fit(X_train, y_train)
...
    vectorizer = model.named_steps["vectorizer"]
    classifier = model.named_steps["classifier"]
    names = vectorizer.get_feature_names_out()
    classes = list(classifier.classes_)
```

## Line-by-Line Code Breakdown
- Lines 36-41: Assembles the pipeline with named stages `"vectorizer"` and `"classifier"`.
- Line 42: Trains the combined pipeline on `X_train` and `y_train`.
- Line 52: Extracts the fitted `CountVectorizer` instance from `named_steps`.
- Line 53: Extracts the fitted `MultinomialNB` instance from `named_steps`.
- Line 54: Retrieves the 282 vocabulary feature names.
- Line 55: Retrieves the target classes `['food', 'sports', 'technology']`.

## Worked Example
Suppose you want to know if the phrase `"farmers market"` is present in the pipeline's vocabulary and what its index is:
```python
# Access the vectorizer from the fitted pipeline
vectorizer = model.named_steps["vectorizer"]
vocab = vectorizer.vocabulary_

if "farmers market" in vocab:
    index = vocab["farmers market"]
    print(f"'farmers market' is feature index: {index}")
```
In `main.py`, `"farmers market"` is indeed in the vocabulary and is one of the top 8 strongest words learned for `food`.

## Step-by-Step Student Instructions
1. Run `python3 main.py`.
2. In a Python shell, recreate the pipeline fitting code on `headlines.csv`.
3. Access `model.named_steps["vectorizer"]`.
4. Run `len(model.named_steps["vectorizer"].get_feature_names_out())`. Confirm the count is 282.
5. Inspect the first 10 vocabulary terms: `names[:10]`.

## Expected Output or Observable Behaviour
```python
>>> len(model.named_steps["vectorizer"].get_feature_names_out())
282
>>> model.named_steps["vectorizer"].get_feature_names_out()[:5]
array(['affordable', 'affordable breakfast', 'affordable health', 'ai',
       'ai models'], dtype=object)
```
Features appear in sorted alphabetical order, seamlessly blending unigrams and bigrams.

## Practical Exercises
- **Exercise 4.1**: What happens if you try to access `model.named_steps["clf"]` when the stage was named `"classifier"`?
- **Exercise 4.2**: Why does calling `model.predict(["A new sports car"])` work directly without needing to call `vectorizer.transform()` first?

## Common Mistakes and Debugging
| Mistake | Error / Symptom | Solution |
|---|---|---|
| Trying to access `model.classes_` directly | `AttributeError: 'Pipeline' object has no attribute 'classes_'` | Access via classifier: `model.named_steps["classifier"].classes_` |
| Calling `fit_transform()` on a Pipeline during inference | Mutates the pipeline and wipes out learned training weights | Use `model.predict()` or `model.predict_proba()` for inference |
| Forgetting to fit the pipeline before inspecting `named_steps` | `NotFittedError` when accessing `get_feature_names_out()` | Ensure `model.fit(X_train, y_train)` is executed first |

## Best Practices and Operational Considerations
- Always assign intuitive, descriptive names to pipeline steps (`"vectorizer"`, `"classifier"`).
- Serialize the entire fitted `Pipeline` using `joblib.dump(model, "pipeline.joblib")` for production deployment.

## Summary and Key Takeaways
- Scikit-learn `Pipeline` encapsulates feature extraction and classification into a unified, leak-free object.
- `model.named_steps` enables transparent inspection of internal pipeline transformers and estimators.
- `vectorizer.get_feature_names_out()` returns the complete array of 282 learned vocabulary terms.

## Knowledge-Check Questions and References
1. How do you access an individual step inside a fitted scikit-learn Pipeline?
2. What method on `CountVectorizer` returns the list of vocabulary features?
3. What is the benefit of passing a raw text list directly to `pipeline.predict()`?
4. What error occurs if you try to inspect feature names before calling `.fit()`?

*References*:
- Scikit-learn User Guide: *Pipeline: chaining estimators* (https://scikit-learn.org/stable/modules/compose.html#pipeline).
