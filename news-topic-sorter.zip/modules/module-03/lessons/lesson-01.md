# Lesson 01: Bag-of-Words Representation & Tokenization

**Lesson ID:** lesson-01  
**Module:** module-03  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain how the **Bag-of-Words (BoW)** model transforms text into numerical vectors.
- Define **tokenization**, lowercasing, and punctuation stripping in text processing.
- Describe the structure and sparsity of a **document-term matrix (DTM)**.
- Understand how word order is discarded in pure frequency-based representations.

## Prerequisites
- Module 02: Data & Article Analysis.
- Basic understanding of 2D matrices and row/column indexing.

## Industry and Real-World Motivation
Machine learning algorithms operate on mathematical arrays, not character strings. In applications ranging from search engine indexing to automated email sorting, raw documents must be translated into structured numeric matrices. 

The Bag-of-Words model is the foundational workhorse of text representation. Despite its structural simplicity, BoW representations power large-scale content filtering, document indexing, and baseline classification across internet-scale search engines and news organizations.

## Concept Explanation
The **Bag-of-Words (BoW)** model treats each document as an unordered collection ("bag") of its constituent words, keeping track only of token frequencies while disregarding word order, grammar, and sentence structure.

### How Text Becomes Numbers
1. **Corpus Ingestion**: The system takes in all training headlines.
2. **Tokenization**: Each headline string is split into individual tokens (words) separated by whitespace and punctuation.
3. **Normalization**: Tokens are lowercased so that "Cricket", "cricket", and "CRICKET" map to the identical token.
4. **Vocabulary Construction**: A global dictionary of all unique words across the training corpus is constructed. Each word is assigned a unique column index.
5. **Vectorization**: Each headline is represented as a row vector whose values correspond to the count of times each vocabulary word appears in that headline.

### The Document-Term Matrix (DTM)
If the training set contains $N$ headlines and the vocabulary contains $V$ unique words, the resulting document-term matrix has shape $(N, V)$:
- Rows correspond to individual headlines ($i = 1, \dots, N$).
- Columns correspond to vocabulary terms ($j = 1, \dots, V$).
- Cell $M_{i, j}$ contains the integer count of word $j$ in headline $i$.

Because any single short headline of 8 words contains only a tiny fraction of the global vocabulary ($V = 282$), the vast majority of entries in this matrix are zeroes. Scikit-learn stores this as a **sparse matrix**, consuming minimal memory.

## Architectural and Pipeline Context
`CountVectorizer` serves as the initial transformer in the classification pipeline:
```
Raw Headline String ──> CountVectorizer.fit_transform() ──> Sparse Matrix (67 x 282) ──> Classifier
```

## Relevant Code
From `main.py` (lines 18, 38):
```python
from sklearn.feature_extraction.text import CountVectorizer
...
model = Pipeline(
    [
        ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
        ("classifier", MultinomialNB()),
    ]
)
```

## Line-by-Line Code Breakdown
- Line 18: Imports `CountVectorizer` from `sklearn.feature_extraction.text`.
- Line 38: Instantiates `CountVectorizer` as the first pipeline step named `"vectorizer"`.

## Worked Example
Suppose we have three toy headlines:
- Headline 1: `"Chef shares spicy noodles"`
- Headline 2: `"Chef shares spicy pasta recipe"`
- Headline 3: `"Cricket player scores twice"`

Vocabulary created ($V=8$ words):
`['chef', 'cricket', 'noodles', 'pasta', 'player', 'recipe', 'scores', 'shares', 'spicy', 'twice']`

Document-Term Matrix:
```
           chef  cricket  noodles  pasta  player  recipe  scores  shares  spicy  twice
Headline 1:  1      0        1       0       0       0       0       1      1      0
Headline 2:  1      0        0       1       0       1       0       1      1      0
Headline 3:  0      1        0       0       1       0       1       0      0      1
```
Notice how each row is a simple frequency histogram. Headline 1 and 2 share "chef", "shares", and "spicy", placing them close together in vector space.

## Step-by-Step Student Instructions
1. In a Python environment, import `CountVectorizer` from `sklearn.feature_extraction.text`.
2. Create a small list of 3 strings: `["sports match", "tech computer", "food recipe"]`.
3. Call `vec = CountVectorizer()`.
4. Run `X = vec.fit_transform(strings)`.
5. Check `vec.get_feature_names_out()` and `X.toarray()`. Observe the binary and integer counts.

## Expected Output or Observable Behaviour
- `vec.get_feature_names_out()` outputs an alphabetically sorted array of token strings.
- `X.toarray()` displays a 2D NumPy array containing word frequencies per document.

## Practical Exercises
- **Exercise 1.1**: If two sentences have the exact same words in reverse order ("dog bites man" vs. "man bites dog"), how will their Bag-of-Words vectors compare?
- **Exercise 1.2**: Why does `CountVectorizer` return a sparse matrix (e.g., `scipy.sparse.csr_matrix`) rather than a standard NumPy array?

## Common Mistakes and Debugging
| Common Mistake | Consequence | Proper Approach |
|---|---|---|
| Calling `.toarray()` on massive datasets | Converts sparse matrix to dense array, potentially exhausting RAM | Keep matrices sparse; scikit-learn estimators handle sparse inputs natively |
| Expecting grammar or word order preservation | BoW models lose syntax ("not good" vs "good") | Acknowledge BoW limitations or introduce n-grams to capture local word pairs |
| Manual string splitting with `.split()` | Fails to strip punctuation and handle contractions properly | Use `CountVectorizer`'s built-in regular expression tokenizer |

## Best Practices and Operational Considerations
- Keep data in sparse format throughout training and inference.
- Verify vocabulary size: Extremely large vocabularies can cause overfitting; adjust parameters like `min_df` or `max_features` when scaling up.

## Summary and Key Takeaways
- Bag-of-Words converts arbitrary text into numerical word-frequency vectors.
- A Document-Term Matrix represents documents as rows and vocabulary words as columns.
- The resulting matrices are sparse and stored efficiently by scikit-learn.

## Knowledge-Check Questions and References
1. What does Bag-of-Words discard when representing a sentence?
2. What do the rows and columns represent in a Document-Term Matrix?
3. Why are most entries in a text count matrix equal to zero?
4. How does `CountVectorizer` normalize text by default?

*References*:
- Scikit-learn User Guide: *Feature extraction — Text feature extraction* (https://scikit-learn.org/stable/modules/feature_extraction.html#text-feature-extraction).
