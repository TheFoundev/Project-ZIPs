# Lesson 03: N-Grams and Phrase Capture

**Lesson ID:** lesson-03  
**Module:** module-03  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define **unigrams**, **bigrams**, and generalized **n-grams**.
- Explain how n-grams capture phrase context and multi-word semantic units.
- Configure `ngram_range=(1, 2)` in `CountVectorizer`.
- Analyze how n-grams expand the vocabulary size from individual words to 282 features.

## Prerequisites
- Lesson 02: Stop Words Filtering in News Headlines.
- Basic understanding of word combinations and sequences.

## Industry and Real-World Motivation
Individual words often lose their decisive meaning when detached from adjacent words. 
Consider the phrase:
`"street food"`

If analyzed strictly as isolated unigrams:
- `"street"`: A generic urban geographic noun (could be traffic, construction, real estate).
- `"food"`: A broad culinary concept.

When paired together as the bigram `"street food"`, the phrase forms an unambiguous cultural and culinary concept. Similarly, `"comeback victory"` carries vastly more athletic meaning than either `"comeback"` or `"victory"` alone. Incorporating n-grams allows models to learn phrase-level context without requiring complex neural syntactic parsers.

## Concept Explanation
An **n-gram** is a contiguous sequence of $n$ items (words) extracted from a text document:
- **Unigram ($n=1$)**: Single words (`['cricket', 'league', 'announces']`).
- **Bigram ($n=2$)**: Two-word pairs (`['cricket league', 'league announces']`).
- **Trigram ($n=3$)**: Three-word phrases (`['cricket league announces']`).

### The `ngram_range` Parameter
In scikit-learn, the `ngram_range` parameter accepts a tuple `(min_n, max_n)`:
- `ngram_range=(1, 1)`: Unigrams only (standard Bag-of-Words).
- `ngram_range=(1, 2)`: Both unigrams and bigrams.
- `ngram_range=(2, 2)`: Bigrams only.

In `main.py`, we configure:
```python
CountVectorizer(stop_words="english", ngram_range=(1, 2))
```
This extracts all single informative words AND all two-word phrases formed by adjacent non-stop words.

### Vocabulary Expansion
Adding bigrams significantly enriches the feature set, expanding the training vocabulary on `headlines.csv` to **282 total features**. 
Among these 282 features are key phrases such as:
- `street food`
- `farmers market`
- `comeback victory`
- `cricket league`
- `faster way`
- `train small`

## Architectural and Pipeline Context
The n-gram extraction happens automatically inside `CountVectorizer`:
```
"Street food festival returns" ──[ Stop Words & (1, 2) N-Grams ]──>
  Unigrams: ['street', 'food', 'festival', 'returns']
  Bigrams:  ['street food', 'food festival', 'festival returns']
```
All 7 features are inserted into the Document-Term Matrix simultaneously.

## Relevant Code
From `main.py` (lines 38, 52-54):
```python
model = Pipeline(
    [
        ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
        ("classifier", MultinomialNB()),
    ]
)
...
vectorizer = model.named_steps["vectorizer"]
names = vectorizer.get_feature_names_out()
# len(names) == 282
```

## Line-by-Line Code Breakdown
- Line 38: Sets `ngram_range=(1, 2)` inside `CountVectorizer`.
- Line 52: Accesses the fitted vectorizer step using `model.named_steps["vectorizer"]`.
- Line 54: Calls `names = vectorizer.get_feature_names_out()`, which returns an array of all 282 learned unigrams and bigrams.

## Worked Example
Let's see what features are generated for the headline:
`"Campus cafe adds affordable breakfast options"`

Step 1 (Stop word removal: `'adds'` is not a stop word, but if `'a'` was there it would be removed).
Step 2 (Unigram extraction):
`'campus'`, `'cafe'`, `'adds'`, `'affordable'`, `'breakfast'`, `'options'`

Step 3 (Bigram extraction):
`'campus cafe'`, `'cafe adds'`, `'adds affordable'`, `'affordable breakfast'`, `'breakfast options'`

Total features generated for this single headline: 6 unigrams + 5 bigrams = 11 features.
Notice how `'campus cafe'` and `'affordable breakfast'` strongly signal the `food` topic.

## Step-by-Step Student Instructions
1. Run Python and import `CountVectorizer`.
2. Test n-gram extraction:
   ```python
   vec = CountVectorizer(ngram_range=(1, 2))
   res = vec.fit_transform(["Open source Python debugging"])
   print(vec.get_feature_names_out())
   ```
3. Observe how each adjacent pair of words is joined with a space.
4. Verify that single words are also retained.

## Expected Output or Observable Behaviour
Output features:
```python
['debugging', 'open', 'open source', 'python', 'python debugging', 'source', 'source python']
```
Notice both unigrams (`'open'`, `'source'`) and bigrams (`'open source'`) are present.

## Practical Exercises
- **Exercise 3.1**: What would `ngram_range=(2, 3)` extract from the sentence `"fast local food market"`?
- **Exercise 3.2**: If a document has 5 words, how many unigrams and bigrams can it generate assuming no stop words?

## Common Mistakes and Debugging
| Mistake | Consequence | Proper Approach |
|---|---|---|
| Setting `ngram_range=(1, 5)` on large corpora | Combinatorial explosion: millions of rare n-grams causing memory crashes and severe overfitting | Restrict `ngram_range` to `(1, 2)` or `(1, 3)` for most NLP applications |
| Using `ngram_range=(2, 2)` alone | Loses all single-word features; if a headline contains strong unigrams without bigram matches, it receives zero signal | Use `(1, 2)` so the model benefits from both unigram coverage and bigram context |
| Looking for bigrams that crossed over removed stop words | Stop words are removed first; adjacent remaining words form the bigrams | Be aware that "championship in final" produces the bigram "championship final" when "in" is filtered |

## Best Practices and Operational Considerations
- Use `ngram_range=(1, 2)` as the standard default for short text and headline classification.
- Always monitor vocabulary growth: If bigrams introduce too many rare features, use `min_df=2` to discard n-grams that appear only once in the corpus.

## Summary and Key Takeaways
- Unigrams capture single words; bigrams capture adjacent two-word phrases.
- Setting `ngram_range=(1, 2)` captures both individual keywords and phrase-level semantics like "street food" or "comeback victory".
- On our dataset, `ngram_range=(1, 2)` creates a rich vocabulary of 282 features.

## Knowledge-Check Questions and References
1. What is the difference between a unigram and a bigram?
2. What does `ngram_range=(1, 2)` instruct `CountVectorizer` to do?
3. How many total features are in the fitted vocabulary in `main.py`?
4. Why is `"street food"` more informative than `"street"` alone?

*References*:
- Jurafsky, D., & Martin, J. H. (2023). *Speech and Language Processing (3rd ed.)*, Chapter 3: N-gram Language Models.
