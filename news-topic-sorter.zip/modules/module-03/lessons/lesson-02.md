# Lesson 02: Stop Words Filtering in News Headlines

**Lesson ID:** lesson-02  
**Module:** module-03  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define **stop words** and explain their prevalence in natural language.
- Explain why stop words dilute classification signals and waste matrix dimensions.
- Configure `CountVectorizer(stop_words="english")` in scikit-learn.
- Evaluate the trade-offs of stop-word filtering in short text headlines.

## Prerequisites
- Lesson 01: Bag-of-Words Representation & Tokenization.
- Familiarity with common English function words (articles, prepositions, conjunctions).

## Industry and Real-World Motivation
According to Zipf's Law, a tiny handful of grammatical function words account for a massive percentage of all words in any natural language corpus. In English, words like *the, a, is, at, which, and, on* appear in virtually every paragraph written.

In a news classification system, these ubiquitous words appear with equal frequency across sports stories, technology analyses, and culinary reviews. If retained, they consume valuable vocabulary space, increase matrix dimensions, and dilute the statistical signals of topic-defining keywords. Filtering stop words sharpens topic separation.

## Concept Explanation
### What Are Stop Words?
**Stop words** are high-frequency words that serve grammatical or syntactic functions rather than carrying domain-specific semantic meaning.

Examples of English stop words:
- Articles: *a, an, the*
- Prepositions: *in, on, at, by, for, with, about*
- Pronouns: *it, its, he, she, they, their*
- Auxiliary Verbs: *is, was, are, were, been, have, has*
- Conjunctions: *and, but, or, so*

### Stop Words Filtering in CountVectorizer
When `stop_words="english"` is passed to `CountVectorizer`:
1. Scikit-learn utilizes an internal English stop word dictionary containing 318 common terms.
2. During tokenization, any token matching an entry in the stop word list is immediately discarded.
3. Only content-bearing words remain in the vocabulary.

### Impact on a Headline
Original Headline:
`"Cybersecurity experts warn about a new phishing scam"`

Without stop-word filtering:
Tokens: `['about', 'a', 'cybersecurity', 'experts', 'new', 'phishing', 'scam', 'warn']` (8 tokens)

With `stop_words="english"`:
Tokens: `['cybersecurity', 'experts', 'new', 'phishing', 'scam', 'warn']` (6 tokens)
*Notice*: `'about'` and `'a'` are eliminated because they provide zero diagnostic information about technology.

## Architectural and Pipeline Context
Stop-word filtering is configured directly within the vectorizer definition in `main.py`:
```python
("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2)))
```
This ensures that stop words are stripped consistently from both training headlines and new test headlines.

## Relevant Code
From `main.py` (line 38):
```python
model = Pipeline(
    [
        ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
        ("classifier", MultinomialNB()),
    ]
)
```

## Line-by-Line Code Breakdown
- Line 38: Sets `stop_words="english"`. This instructs `CountVectorizer` to discard standard English stop words before building the vocabulary.

## Worked Example
Consider this headline from `headlines.csv`:
`"Injury update: captain expected to return next week"`

Stop words identified:
- `to` (preposition)
- `next` (temporal stop word)

Tokens retained:
`['injury', 'update', 'captain', 'expected', 'return', 'week']`

By removing `to`, the model focuses its statistical weight on `injury`, `captain`, and `return`—all of which correlate strongly with `sports`.

## Step-by-Step Student Instructions
1. Open a Python shell.
2. Instantiate two vectorizers:
   ```python
   from sklearn.feature_extraction.text import CountVectorizer
   v_raw = CountVectorizer()
   v_clean = CountVectorizer(stop_words="english")
   ```
3. Vectorize the sentence: `["The team won with a dramatic goal in the final"]`.
4. Print `v_raw.get_feature_names_out()` and `v_clean.get_feature_names_out()`.
5. Compare the length and content of both vocabularies.

## Expected Output or Observable Behaviour
- `v_raw` vocabulary contains: `['dramatic', 'final', 'goal', 'in', 'team', 'the', 'with', 'won']` (8 words).
- `v_clean` vocabulary contains: `['dramatic', 'final', 'goal', 'team', 'won']` (5 words).
- Notice that `'in'`, `'the'`, and `'with'` were successfully removed.

## Practical Exercises
- **Exercise 2.1**: Can removing stop words ever cause issues? Consider the title: *"To Be or Not to Be"*. What would happen if stop words were removed from that title?
- **Exercise 2.2**: How many stop words are included in scikit-learn's built-in `'english'` list? (Hint: inspect `from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS; len(ENGLISH_STOP_WORDS)`).

## Common Mistakes and Debugging
| Mistake | Consequence | Proper Approach |
|---|---|---|
| Passing `stop_words=True` | `TypeError: 'bool' object is not iterable` | Pass the string `"english"` or a custom list of words |
| Removing domain keywords accidentally | If a custom stop list contains words like "system" or "game", crucial domain signals are lost | Review custom stop lists carefully before applying them |
| Applying stop words in sentiment analysis where negation matters | Removing words like "not" or "no" turns "not good" into "good" | For sentiment tasks, customize stop lists to preserve negations |

## Best Practices and Operational Considerations
- Use `stop_words="english"` for topic classification because topical signals reside in nouns and domain verbs.
- For specialized domains (e.g., medical or legal), construct domain-specific stop word lists that remove recurring clinical or boilerplate legal phrases.

## Summary and Key Takeaways
- Stop words are ubiquitous grammatical terms that carry minimal topical signal.
- Setting `stop_words="english"` strips non-informative words like "the", "a", and "for".
- Filtering stop words reduces matrix sparsity and focuses classifier probability mass on topic-defining keywords.

## Knowledge-Check Questions and References
1. What is the definition of a stop word in NLP?
2. Name three common English stop words removed by scikit-learn.
3. What parameter in `CountVectorizer` enables English stop word filtering?
4. How does removing stop words benefit a Naive Bayes classifier?

*References*:
- Manning, C. D., Raghavan, P., & Schütze, H. (2008). *Introduction to Information Retrieval*, Section 2.2.2: Drop common words: stop sequences.
