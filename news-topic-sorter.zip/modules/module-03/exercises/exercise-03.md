# Module 3 Exercises: Feature Extraction & Pipeline Construction

## Exercise 3.1: Manual Document-Term Matrix Computation (15 min)
**Objective:** Calculate token frequencies, stop-word filtering, and n-grams by hand for a small corpus.
**Problem Statement:** You are given 2 headlines:
1. `"Star player wins victory"`
2. `"Chef wins cooking victory"`

**Requirements:**
1. Lowercase both headlines.
2. Remove standard English stop words (none are present here, or identify any function words).
3. Extract all unigrams and bigrams (`ngram_range=(1, 2)`).
4. Construct the complete alphabetically sorted vocabulary list.
5. Write the resulting Document-Term Matrix as a table of counts.

**Acceptance Criteria:**
- [ ] Correctly identifies all unigrams and bigrams.
- [ ] Alphabetically orders vocabulary features.
- [ ] Accurately constructs the (2, V) count matrix.

---

## Exercise 3.2: Pipeline Inspection Script (15 min)
**Objective:** Programmatically inspect the fitted vectorizer inside `main.py`'s pipeline.
**Problem Statement:** Write a Python script that loads `headlines.csv`, builds and fits the pipeline, and answers key feature questions.

**Requirements:**
1. Replicate the pipeline definition from `main.py`.
2. Fit the pipeline on `X_train, y_train`.
3. Extract `vectorizer` via `model.named_steps["vectorizer"]`.
4. Print the total vocabulary size (must equal 282).
5. Print all bigrams in the vocabulary that start with the word `"cricket"`.

**Acceptance Criteria:**
- [ ] Successfully accesses `named_steps["vectorizer"]`.
- [ ] Verifies total vocabulary count equals 282.
- [ ] Identifies bigrams such as `"cricket league"`.
