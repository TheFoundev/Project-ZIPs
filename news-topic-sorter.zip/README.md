# The News Topic Sorter

## Overview
The **News Topic Sorter** is a practical natural language processing (NLP) project that uses **Multinomial Naive Bayes** to classify news headlines into three distinct topical categories: **sports**, **technology**, and **food**. Built on top of the runnable codebase at `beginner-projects-main/AI-ML Beginners/projects/19_news_topic_sorter/`, this curriculum guides learners through the end-to-end pipeline of text vectorization, model training, evaluation with confusion matrices, and inference confidence scoring.

## Real-World Use Case
Digital news portals (such as Google News, Apple News, and RSS aggregators) process millions of breaking stories daily. Automatic topic classification allows news engines to instantly index articles, populate topic feeds, recommend content to targeted reader segments, and alert specialized editorial teams without human intervention.

## Features Implemented
- **Data Ingestion**: Loads a balanced dataset of news headlines (`data/headlines.csv`) across sports, technology, and food.
- **Stratified Splitting**: Splits text data into training (75%) and testing (25%) partitions while strictly preserving category proportions.
- **Text Feature Extraction**: Uses `CountVectorizer` with English stop-word filtering and unigram + bigram ranges (`ngram_range=(1, 2)`).
- **Scikit-Learn Pipeline**: Combines text tokenization and `MultinomialNB` into an integrated, leakage-free processing pipeline.
- **Performance Evaluation**: Computes classification accuracy, precision, recall, and per-class F1-scores.
- **Lexical Inspection**: Analyzes feature log-probabilities (`feature_log_prob_`) to extract the 8 most influential keywords per topic.
- **Confidence Scoring**: Evaluates unseen real-world headlines using `predict_proba` to show model confidence percentages.
- **Visual Diagnostics**: Generates and saves a high-resolution confusion matrix plot (`outputs/confusion_matrix.png`).
- **Audit Persistence**: Writes accuracy, classification reports, and test predictions to `outputs/predictions.txt`.

## Technology Stack
- **Python 3.8+**
- **pandas** (Data manipulation and CSV ingestion)
- **numpy** (Array sorting and mathematical operations)
- **matplotlib** (Agg headless plotting backend for confusion matrix rendering)
- **scikit-learn** (CountVectorizer, MultinomialNB, Pipeline, metrics, train_test_split)

## Project Structure
```
19_news_topic_sorter/
├── main.py              # Full runnable classification script
├── README.md            # Quickstart guide
├── data/
│   └── headlines.csv    # 90 labeled news headlines (30 sports, 30 tech, 30 food)
└── outputs/
    ├── confusion_matrix.png # Confusion matrix plot
    └── predictions.txt      # Text summary of metrics and test predictions
```

## How It Works
1. Reads `data/headlines.csv` containing columns `headline` (raw text) and `topic` (target class).
2. Performs stratified train/test split: 67 training headlines, 23 testing headlines.
3. Assembles a two-stage `Pipeline`:
   - `vectorizer`: `CountVectorizer(stop_words="english", ngram_range=(1, 2))`
   - `classifier`: `MultinomialNB()`
4. Trains the pipeline on the training set using `model.fit(X_train, y_train)`.
5. Predicts test categories and calculates classification accuracy and comprehensive classification metrics.
6. Inspects vocabulary log-probabilities to reveal top discriminatory phrases.
7. Evaluates 5 fresh headlines representing diverse topics and edge cases.
8. Plots and saves a confusion matrix visualization and summary text file.
