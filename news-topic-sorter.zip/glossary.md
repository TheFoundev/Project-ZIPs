# Glossary: The News Topic Sorter

| Term | Definition |
|---|---|
| **Multi-Class Classification** | A supervised machine learning task where an instance must be classified into one of three or more mutually exclusive categories. |
| **Naive Bayes** | A probabilistic classifier based on Bayes' Theorem that assumes strong (naive) conditional independence between features given the class label. |
| **Multinomial Naive Bayes** | A Naive Bayes variant tailored for discrete count data, particularly word frequencies in text documents. |
| **Bag-of-Words (BoW)** | A text representation technique that simplifies documents into an unordered multiset of word counts, disregarding grammar and word order. |
| **CountVectorizer** | A scikit-learn utility that converts a collection of text documents into a matrix of token counts. |
| **Tokenization** | The process of segmenting a sequence of characters into meaningful syntactic units called tokens (words, subwords, symbols). |
| **Stop Words** | Commonly used words (such as 'the', 'is', 'at') that carry minimal domain-specific semantic signal and are routinely filtered out of text features. |
| **N-gram** | A contiguous sequence of $n$ items from a given text sample; unigrams ($n=1$) are single words, while bigrams ($n=2$) are word pairs (e.g., 'farmers market'). |
| **Stratified Sampling** | A data partitioning method ensuring that each split (train and test) maintains the exact same proportion of class labels as the complete dataset. |
| **Laplace Smoothing** | An additive smoothing technique ($lpha=1.0$) applied to categorical data distributions to prevent zero-probability assignments for unseen tokens. |
| **Feature Log Probability** | The natural logarithm of the probability of observing a given word feature within a specific class; higher (less negative) values indicate stronger association. |
| **Confusion Matrix** | A specific table layout that visualizes algorithm performance, displaying counts of true positives, false positives, true negatives, and false negatives across all classes. |
| **Precision** | The fraction of predicted positive instances that are actually correct: $\text{TP} / (\text{TP} + \text{FP})$. |
| **Recall** | The fraction of actual positive instances that were successfully identified: $\text{TP} / (\text{TP} + \text{FN})$. |
| **F1-Score** | The harmonic mean of precision and recall: $2 \times (\text{Precision} \times \text{Recall}) / (\text{Precision} + \text{Recall})$. |
| **Pipeline** | A scikit-learn construct that chains multiple data transformers and a final estimator into a unified object, preventing data leakage during cross-validation. |
| **predict_proba** | A method that outputs the estimated class probabilities for input samples, summing to 1.0 across all target classes. |
