# Prerequisites: The News Topic Sorter

## Technical Skills Required
- **Python Fundamentals**: Understanding of functions, lists, dictionaries, imports, and string handling.
- **Data Manipulation with pandas**: Basic familiarity with `DataFrame`, column selection (`df["col"]`), and reading CSV files (`pd.read_csv`).
- **Command-Line Operations**: Navigating directories, executing Python scripts from terminal (`python main.py`), and inspecting generated files.
- **Introductory Machine Learning Concepts**: Understanding supervised learning (training on labeled examples), features ($X$) vs target labels ($y$), and train/test evaluation.
- **Introductory Math/Probability**: Basic intuition about probabilities (values between 0 and 1, percentages, and word counts).

## Software & Environment Requirements
- **Python**: Version 3.8 or higher.
- **Package Manager**: `pip` (Python package installer).
- **Core Dependencies**:
  - `pandas` (>= 1.3.0)
  - `numpy` (>= 1.20.0)
  - `matplotlib` (>= 3.4.0)
  - `scikit-learn` (>= 1.0.0)

## Recommended Reading Before Starting
- What is supervised text classification?
- How does Bag-of-Words represent a sentence as numbers?
- Why do we split data into training and testing sets?
