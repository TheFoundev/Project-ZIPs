# The Penguin Detective

An end-to-end educational machine learning project demonstrating multi-class classification, instance-based learning with **K-Nearest Neighbours (KNN)**, feature standardization pipelines, hyperparameter comparison, and probability confidence estimation using the renowned Palmer Penguins morphometrics dataset.

## Project Summary
- **Title**: The Penguin Detective
- **Algorithm**: K-Nearest Neighbours (`KNeighborsClassifier`)
- **Dataset**: `data/penguins.csv` (150 Antarctic penguin specimens: 50 Adelie, 50 Chinstrap, 50 Gentoo)
- **Features (4D)**: `bill_length_mm`, `bill_depth_mm`, `flipper_length_mm`, `body_mass_g`
- **Target Label**: `species` (3 classes: Adelie, Chinstrap, Gentoo)
- **Architecture**: `Pipeline` (`StandardScaler` → `KNeighborsClassifier`)
- **Split Configuration**: `test_size=0.25`, `random_state=42`, `stratify=y`
- **Hyperparameter Tuning**: Compares $k=3$ vs $k=5$ and selects the best performer
- **Inference**: Classifies a mystery penguin (`[39.0, 18.0, 190.0, 3700.0]`) and extracts prediction confidence using `predict_proba()`
- **Visual Artifacts**: Bill vs Flipper scatter plot with class clusters (`outputs/penguin_scatter.png`), confusion matrix heatmap (`outputs/confusion_matrix.png`), and metric logs (`outputs/metrics.txt`).

## Quick Start
```bash
# 1. Install dependencies
pip install pandas numpy matplotlib scikit-learn

# 2. Run the pipeline
python3 main.py
```

## Repository Structure
```text
penguin-detective/
├── project.json              # Project metadata & machine-readable specifications
├── README.md                 # Project introduction, quick start, and directory guide
├── PROJECT_SUMMARY.md        # Comprehensive technical summary and results
├── architecture.md           # Pipeline data flow and system diagrams
├── glossary.md               # Key machine learning and biological terms
├── prerequisites.md          # Learner prerequisites, packages, and skills
├── setup-guide.md            # Environment setup and execution instructions
├── references.json           # Links to official scikit-learn docs & Palmer LTER research
├── ALL_ASSESSMENT_ANSWERS.md # Complete question directory and solutions
├── manifest.json             # Content library manifest and file integrity index
├── modules/                  # 6 comprehensive instructional modules
│   ├── module-01/            # Project Overview & Ecological Classification
│   ├── module-02/            # Data Exploration, Morphometrics & Stratified Splitting
│   ├── module-03/            # The KNN Algorithm & Hyperparameter Optimization
│   ├── module-04/            # Preprocessing Pipelines & Confidence Estimation
│   ├── module-05/            # Multi-Class Evaluation & Cluster Visualizations
│   └── module-06/            # Execution, Feature Ablation & Model Extensions
└── final-project/            # Final capstone project materials
    ├── requirements.md       # Capstone specifications and deliverables
    ├── evaluation-rubric.json# Objective 100-point grading criteria
    └── solution-guide.md     # Reference implementation walkthrough & code
```

## Curriculum Overview
1. **Module 01: Project Overview**: Biological context of Antarctic penguins, classification vs. regression, and why morphometrics identify species.
2. **Module 02: Data & Penguin Features**: Loading `penguins.csv`, exploring the 4 features, verifying class balance, and stratified splitting.
3. **Module 03: KNN Algorithm & Hyperparameter Tuning**: Multi-dimensional Euclidean distance, voting mechanics, and comparing $k=3$ vs $k=5$.
4. **Module 04: Pipeline Training & Confidence Scores**: Feature standardization with `StandardScaler`, `Pipeline` construction, and `predict_proba()` confidence scoring.
5. **Module 05: Evaluation & Visualization**: Interpreting accuracy (94.7%), classification reports, confusion matrix diagnostics, and 2D cluster plotting.
6. **Module 06: Running, Species Prediction & Extensions**: Full pipeline execution, mystery penguin inference, feature ablation (removing `body_mass_g`), and multi-class extensions.
