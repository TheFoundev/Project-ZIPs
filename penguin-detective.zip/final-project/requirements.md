# Final Project Requirements: The Penguin Detective

## Objective
Implement, evaluate, and expand **The Penguin Detective** classification system from scratch. Your implementation must load field observations, construct a standardized scikit-learn pipeline, optimize the number of neighbours $k$, infer the species of an unknown specimen with probability confidence scoring, produce diagnostic visual charts, and investigate feature importance via ablation experiments.

## Functional Requirements

### 1. Data Loading & Feature Preparation
- Load `data/penguins.csv` into a pandas DataFrame.
- Define `FEATURES = ["bill_length_mm", "bill_depth_mm", "flipper_length_mm", "body_mass_g"]`.
- Extract feature matrix $X$ with shape `(150, 4)` and target vector $y = \text{df}['\text{species}']$ with length 150.
- Confirm dataset class balance: exactly 50 Adelie, 50 Chinstrap, and 50 Gentoo.

### 2. Stratified Partitioning
- Split data using `train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)`.
- Verify the resulting shapes:
  - `X_train`: `(112, 4)`, `y_train`: `(112,)`
  - `X_test`: `(38, 4)`, `y_test`: `(38,)`
- Verify test set class distribution: 12 Adelie, 13 Chinstrap, 13 Gentoo.

### 3. Pipeline Construction & Hyperparameter Evaluation
- For each $k \in (3, 5)$:
  - Construct an `sklearn.pipeline.Pipeline` with steps `[("scale", StandardScaler()), ("knn", KNeighborsClassifier(n_neighbors=k))]`.
  - Fit the pipeline on `(X_train, y_train)`.
  - Predict class labels on `X_test`.
  - Calculate test set accuracy using `accuracy_score(y_test, predictions)`.
- Identify `best_k` using `max()` over recorded accuracies.

### 4. Classification Metrics & Reporting
- Print model accuracy for both $k=3$ and $k=5$ formatted as a percentage (`{accuracy:.1%}`).
- Print the scikit-learn `classification_report(y_test, best_predictions, zero_division=0)`.
- Confirm overall test accuracy is **94.7%** (36 of 38 correct).

### 5. Mystery Penguin Inference & Confidence
- Create a test specimen DataFrame:
  ```python
  new_penguin = pd.DataFrame([{
      "bill_length_mm": 39.0,
      "bill_depth_mm": 18.0,
      "flipper_length_mm": 190.0,
      "body_mass_g": 3700.0,
  }])
  ```
- Predict species using `best_model.predict(new_penguin)[0]`.
- Extract maximum class probability using `best_model.predict_proba(new_penguin).max()`.
- Confirm output: `New penguin -> Adelie (100% confident)`.

### 6. Visual Artifacts
- **Cluster Scatter Plot (`outputs/penguin_scatter.png`)**:
  - Figure size `(7.5, 5.5)`.
  - Scatter plot of `bill_length_mm` (x-axis) vs `flipper_length_mm` (y-axis).
  - Use `COLOURS = {"Adelie": "#2471a3", "Gentoo": "#c0392b", "Chinstrap": "#16a085"}`.
  - Overlay the mystery specimen as a black star marker (`marker='*'`, `s=280`, `color='#111111'`).
  - Configure titles, axis labels, legend, and grid with alpha 0.25.
  - Save to `outputs/penguin_scatter.png` with `dpi=150` and `bbox_inches="tight"`.
- **Confusion Matrix (`outputs/confusion_matrix.png`)**:
  - Compute `confusion_matrix(y_test, best_predictions, labels=labels)`.
  - Render with `ConfusionMatrixDisplay` using colormap `'Blues'`.
  - Save to `outputs/confusion_matrix.png`.
- **Text Summary (`outputs/metrics.txt`)**:
  - Write accuracy for each $k$, `best_k`, mystery specimen prediction and confidence, and full classification report.

### 7. Feature Ablation Investigation
- Train a separate model omitting `body_mass_g` (`FEATURES = ["bill_length_mm", "bill_depth_mm", "flipper_length_mm"]`).
- Re-run evaluation and verify that test accuracy increases to **97.4%** for $k=3$.
- Provide a written analysis explaining why dropping body mass reduced misclassification between Adelie and Chinstrap.
