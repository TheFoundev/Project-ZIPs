# Setup Guide

Follow these step-by-step instructions to set up the development environment for **The Penguin Detective**.

## 1. Verify Python Installation
Open your terminal and confirm that Python 3 is installed:
```bash
python3 --version
```
Ensure the version is 3.8 or higher.

## 2. Navigate to the Project Directory
Change directory to the Penguin Detective source directory:
```bash
cd /home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML\ Beginners/projects/13_penguin_detective
```

## 3. Create a Virtual Environment (Recommended)
Isolate project dependencies by creating a dedicated virtual environment:
```bash
python3 -m venv .venv
source .venv/bin/activate
```
*(On Windows: `.venv\Scripts\activate`)*

## 4. Install Dependencies
Install all required libraries using `pip`:
```bash
pip install pandas numpy matplotlib scikit-learn
```

## 5. Verify Dataset and Directory Structure
Confirm that the dataset exists at `data/penguins.csv`:
```bash
ls -la data/
head -n 5 data/penguins.csv
```
The first line should be the CSV header:
`species,bill_length_mm,bill_depth_mm,flipper_length_mm,body_mass_g`

## 6. Run the Project
Execute `main.py` to confirm the environment is operational:
```bash
python3 main.py
```
Expected terminal summary:
- Comparison of accuracy for `k=3` (94.7%) and `k=5` (94.7%).
- Classification report showing precision, recall, and F1-score across Adelie, Chinstrap, and Gentoo.
- Prediction for the mystery penguin: **Adelie (100% confident)**.
- Generated output files in the `outputs/` folder.
