# Project Summary: The Penguin Detective

## Executive Overview
**The Penguin Detective** demonstrates how data-driven machine learning models automate ecological species classification. Using real-world field observations collected by Dr. Kristen Gorman and the Palmer Station Long Term Ecological Research (LTER) team in Antarctica, the system trains a **K-Nearest Neighbours (KNN)** classifier to distinguish between three sympatric penguin species: **Adelie** (*Pygoscelis adeliae*), **Chinstrap** (*Pygoscelis antarcticus*), and **Gentoo** (*Pygoscelis papua*).

## The Ecological Problem
In Antarctic field biology, identifying penguin species from visual observation alone can be challenging during harsh weather, moulting periods, or when observing juveniles. However, anatomical body measurements (culmen bill length, bill depth, flipper length, and body mass) reflect distinct evolutionary adaptations to specialized diets and foraging depths. This project creates an automated, deterministic classification pipeline that maps four continuous physical measurements to the correct biological species.

## Key Technical Specifications
| Specification | Implementation |
|---|---|
| **Task Type** | Supervised Multi-Class Classification (3 classes) |
| **Algorithm** | K-Nearest Neighbours (`KNeighborsClassifier`) |
| **Pipeline** | `sklearn.pipeline.Pipeline` with `StandardScaler` + `KNeighborsClassifier` |
| **Dataset** | `data/penguins.csv` (150 specimens: 50 Adelie, 50 Chinstrap, 50 Gentoo) |
| **Features** | `bill_length_mm`, `bill_depth_mm`, `flipper_length_mm`, `body_mass_g` |
| **Target Variable** | `species` |
| **Data Split** | 75% Train (112 samples), 25% Test (38 samples), `stratify=y`, `random_state=42` |
| **Hyperparameter Grid** | $k \in \{3, 5\}$ |
| **Optimal Hyperparameter** | $k=3$ (accuracy: 94.74%, 36/38 correct test samples) |
| **Confidence Scoring** | `predict_proba()` neighbor proportion calculation |
| **Inference Case** | Specimen `[39.0mm, 18.0mm, 190.0mm, 3700g]` $\rightarrow$ **Adelie** (100% confidence) |
| **Visual Outputs** | `penguin_scatter.png` (bill vs flipper), `confusion_matrix.png` |
| **Report Artifacts** | `metrics.txt` containing hyperparameter scores & full classification report |

## Key Findings & Diagnostic Insights
1. **Feature Scaling is Essential**: Because `body_mass_g` spans thousands of units (2959g to 6026g) while `bill_depth_mm` spans only single digits (13.6mm to 21.0mm), unscaled Euclidean distance would be completely overwhelmed by mass. `StandardScaler` standardizes each feature to zero mean and unit variance.
2. **Species Cluster Separation**:
   - **Gentoo** penguins are completely separated in morphometric space: they have substantially larger body mass (~5028g) and longer flippers (~216mm), leading to **100% precision and recall**.
   - **Adelie** and **Chinstrap** penguins share similar body mass (~3700g) and bill depth (~18.4mm), leading to a minor mutual misclassification (1 Adelie misclassified as Chinstrap, and 1 Chinstrap misclassified as Adelie).
3. **Feature Ablation Impact**: When `body_mass_g` is removed from the feature set, model accuracy for $k=3$ paradoxically **increases from 94.7% to 97.4%** (37/38 correct), demonstrating that noisy or overlapping features can introduce variance into instance-based distance metrics.
