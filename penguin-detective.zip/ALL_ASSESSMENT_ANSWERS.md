# All Correct Answers for Assessments
Project: Penguin Detective: Multi-Class Morphological Classification with K-Nearest Neighbors
---

## Module 01: Project Overview: The Antarctic Mystery & Penguin Classification

**q1-01.** What are the three Antarctic penguin species classified in The Penguin Detective project?
   **Correct Answer:** B. Adelie, Chinstrap, and Gentoo
   *Explanation:* The Palmer Penguins dataset and Project 13 focus on the three sympatric Pygoscelis species native to the Palmer Archipelago: Adelie (Pygoscelis adeliae), Chinstrap (Pygoscelis antarcticus), and Gentoo (Pygoscelis papua).

**q1-02.** What type of machine learning task is implemented in The Penguin Detective?
   **Correct Answer:** C. Supervised multi-class classification
   *Explanation:* The project uses labeled training data to map four continuous physical measurements to one of three discrete categorical species labels, which is the definition of supervised multi-class classification.

**q1-03.** Which four physical body measurements are used as predictive features in the project?
   **Correct Answer:** A. bill_length_mm, bill_depth_mm, flipper_length_mm, body_mass_g
   *Explanation:* The four features defined in main.py are bill_length_mm, bill_depth_mm, flipper_length_mm, and body_mass_g, reflecting culmen length, culmen depth, wing flipper length, and overall mass.

**q1-04.** Why is predicting penguin species framed as classification rather than regression?
   **Correct Answer:** B. Because the target variable represents discrete categorical labels rather than a continuous numerical quantity
   *Explanation:* Classification is appropriate because the target consists of mutually exclusive categorical classes (Adelie, Chinstrap, Gentoo) rather than continuous numbers on a numerical scale.

**q1-05.** In the context of the Palmer LTER research study, why is automated species classification valuable?
   **Correct Answer:** B. It provides consistent identification during blizzards or moulting when plumage is obscured, aiding climate monitoring
   *Explanation:* Automated morphometric identification allows field scientists and automated sensor systems to classify penguins reliably even when plumage markings are obscured by blizzards, mud, or annual moulting.

**q1-06.** According to the dataset's morphometric distributions, what anatomical trait most cleanly distinguishes Gentoo penguins from Adelie and Chinstrap?
   **Correct Answer:** B. Substantially larger body mass (>5,000g) and longer flippers (>215mm), along with shallower bill depth
   *Explanation:* Gentoo penguins are substantially heavier (averaging >5,000g vs ~3,700g for Adelie/Chinstrap), possess longer flippers (>215mm), and have a shallower bill depth (~15.1mm), creating clear separation.

**q1-07.** Which measurement is most critical for separating Adelie penguins from Chinstrap penguins, given their similar body masses?
   **Correct Answer:** B. Bill length, which averages ~38.7mm for Adelie versus ~48.2mm for Chinstrap
   *Explanation:* Adelie and Chinstrap penguins have almost identical body mass (~3,700g) and bill depth (~18.4mm), but Chinstrap bills average ~48.2mm compared to Adelie's ~38.7mm, providing a clean ~10mm separation.

**q1-08.** Why does main.py configure an scikit-learn Pipeline with StandardScaler and KNeighborsClassifier?
   **Correct Answer:** A. To prevent body mass in grams from numerically dominating distance calculations over millimeter measurements and to avoid data leakage
   *Explanation:* Because body mass is measured in thousands of grams while bill depth is around 15 millimeters, unscaled Euclidean distance would be dominated by mass. StandardScaler normalizes all features to unit variance, and Pipeline prevents test data leakage.

**q1-09.** What would happen if a machine learning practitioner mapped Adelie=1, Chinstrap=2, and Gentoo=3 and trained an ordinary Linear Regression model?
   **Correct Answer:** B. The model would falsely assume an artificial mathematical order and distance between species, predicting nonsensical fractional values like 1.73
   *Explanation:* Arbitrary integer encoding of unordered categorical classes imposes an artificial metric topology, causing linear regression to assume Chinstrap is midway between Adelie and Gentoo and producing biologically meaningless fractional predictions.

**q1-10.** Which set of artifacts is generated and saved into the outputs/ directory by main.py?
   **Correct Answer:** B. penguin_scatter.png, confusion_matrix.png, and metrics.txt
   *Explanation:* main.py saves three distinct persistent artifacts: penguin_scatter.png (cluster visualization), confusion_matrix.png (diagnostic error matrix), and metrics.txt (quantitative performance log).


## Module 02: Data & Penguin Features: Loading, Morphometrics & Splitting

**q2-01.** What is the total number of rows and columns in data/penguins.csv?
   **Correct Answer:** B. 150 rows and 5 columns
   *Explanation:* The dataset data/penguins.csv contains exactly 150 observation rows and 5 columns (species, bill_length_mm, bill_depth_mm, flipper_length_mm, body_mass_g).

**q2-02.** How many samples of each penguin species are present in penguins.csv?
   **Correct Answer:** A. 50 Adelie, 50 Chinstrap, and 50 Gentoo
   *Explanation:* The dataset is perfectly balanced with exactly 50 samples of Adelie, 50 samples of Chinstrap, and 50 samples of Gentoo penguins.

**q2-03.** What are the dimensions (shape) of the feature matrix X and target vector y in main.py?
   **Correct Answer:** B. X is (150, 4) and y is (150,)
   *Explanation:* X is a 2D pandas DataFrame of shape (150, 4) containing the 4 feature columns, while y is a 1D pandas Series of shape (150,) containing the species string labels.

**q2-04.** Comparing the four morphometric features, which feature exhibits the largest numerical values and variance?
   **Correct Answer:** D. body_mass_g
   *Explanation:* body_mass_g has values spanning from 2959g to 6026g (mean 4153.2g, std 722.1g), which is orders of magnitude larger than millimeter measurements that range between 13mm and 232mm.

**q2-05.** What is the primary danger of training a distance-based algorithm like KNN on unscaled features when body_mass_g is in thousands of grams and bill_depth_mm is around 15 millimeters?
   **Correct Answer:** B. Body mass will overwhelmingly dominate distance calculations, rendering bill depth and flipper length virtually irrelevant
   *Explanation:* In unscaled Euclidean distance, squared mass differences (e.g. (5000-3700)^2 = 1,690,000) dwarf millimeter differences (e.g. (18-18)^2 = 0 or (48-40)^2 = 64), effectively causing the classifier to ignore beak dimensions.

**q2-06.** What baseline classification accuracy would be achieved on this dataset by a naive model that always predicts 'Adelie' without examining features?
   **Correct Answer:** B. 33.33%
   *Explanation:* Because each of the three species accounts for exactly 50 out of 150 samples (1/3 or 33.33%), guessing any single class blindly results in 33.33% accuracy.

**q2-07.** When train_test_split is called with test_size=0.25 on the 150-sample dataset, how many samples are placed in X_train and X_test respectively?
   **Correct Answer:** B. 112 in X_train and 38 in X_test
   *Explanation:* With test_size=0.25, 25% of 150 is 37.5, which rounds to 38 test samples in X_test, leaving 150 - 38 = 112 samples in X_train.

**q2-08.** What is the specific function of the stratify=y argument in train_test_split?
   **Correct Answer:** C. It guarantees that the proportion of each species in the train and test subsets mirrors the original dataset distribution
   *Explanation:* The stratify=y parameter enforces stratified sampling, ensuring that training and test splits retain the exact same percentage of each class as the original dataset.

**q2-09.** In main.py, what is the exact species breakdown in the 38-sample test set under stratified splitting?
   **Correct Answer:** A. 12 Adelie, 13 Chinstrap, and 13 Gentoo
   *Explanation:* Dividing 38 test samples across 3 balanced classes with random_state=42 yields 12 Adelie, 13 Chinstrap, and 13 Gentoo (12 + 13 + 13 = 38).

**q2-10.** Why must feature scaling parameters (mean and variance) be computed solely on X_train rather than the entire dataset before splitting?
   **Correct Answer:** B. Computing scaling on the whole dataset introduces data leakage, giving the model knowledge of test set distributions during training
   *Explanation:* Fitting StandardScaler on the full dataset before splitting leaks the test set's mean and standard deviation into the training pipeline, violating the strict out-of-sample assumption of machine learning.


## Module 03: KNN Algorithm & Hyperparameter Tuning: 4D Geometry & Model Selection

**q3-01.** What does the 'K' in K-Nearest Neighbours represent?
   **Correct Answer:** B. The number of closest training examples used to vote on the class of a query point
   *Explanation:* In K-Nearest Neighbours, 'k' specifies the integer count of closest training instances in feature space whose class labels are polled to determine the predicted class of a query point.

**q3-02.** Why is K-Nearest Neighbours referred to as a 'lazy learner'?
   **Correct Answer:** B. Because it does not learn explicit parameters during training, deferring distance calculations until prediction time
   *Explanation:* KNN is called a lazy learner because it performs no eager generalization or parameter estimation during training; it simply indexes training instances and defers all computation until prediction time.

**q3-03.** What is the default distance metric used by scikit-learn's KNeighborsClassifier?
   **Correct Answer:** B. Minkowski metric with p=2 (Euclidean distance)
   *Explanation:* KNeighborsClassifier defaults to metric='minkowski' with p=2, which is mathematically identical to standard Euclidean (L2) distance.

**q3-04.** What is the Euclidean distance between points p = [1, 1, 1, 1] and q = [3, 3, 3, 3] in 4-dimensional feature space?
   **Correct Answer:** B. 4.0
   *Explanation:* d = sqrt((3-1)^2 + (3-1)^2 + (3-1)^2 + (3-1)^2) = sqrt(2^2 + 2^2 + 2^2 + 2^2) = sqrt(4 + 4 + 4 + 4) = sqrt(16) = 4.0.

**q3-05.** In main.py, what test accuracies are obtained for k=3 and k=5?
   **Correct Answer:** B. k=3 achieves 94.7% and k=5 achieves 94.7%
   *Explanation:* Executing main.py evaluates both k=3 and k=5, each achieving exactly 94.7% test accuracy (36 out of 38 correct predictions).

**q3-06.** When both k=3 and k=5 achieve the exact same test accuracy (94.7%), which value does main.py select as best_k and why?
   **Correct Answer:** B. k=3, because Python's max() function returns the first key encountered when values tie
   *Explanation:* Python's built-in max() function selects the first key encountered in iteration order when values tie; because results was populated with (3, 5), k=3 is selected.

**q3-07.** What is the primary risk of setting k=1 in K-Nearest Neighbours?
   **Correct Answer:** B. High variance (overfitting), making the model excessively sensitive to noise and outliers
   *Explanation:* Setting k=1 creates a model with zero bias on the training set but very high variance, causing the decision boundary to form erratic islands around noisy or mislabeled individual points.

**q3-08.** What happens to the decision boundary of a KNN classifier as k approaches the total number of training samples (k = N_train)?
   **Correct Answer:** B. The decision boundary becomes overly simplified and smoothed, eventually predicting the majority class everywhere
   *Explanation:* When k approaches the total dataset size, every query point samples the entire dataset, smoothing away all local decision boundaries and predicting whichever class has the most training examples.

**q3-09.** Why is evaluating k=1 on the training set (X_train) fundamentally flawed when tuning hyperparameters?
   **Correct Answer:** B. Because every training sample is its own nearest neighbor (distance = 0), yielding trivial 100% training accuracy regardless of actual generalization
   *Explanation:* When evaluating a k=1 model on its own training set, each point's closest neighbor is itself (distance 0.0), guaranteeing a false 100% accuracy score that conceals overfitting.

**q3-10.** Suppose a query penguin has 3 nearest neighbours: 2 Adelie and 1 Chinstrap. How does KNN assign the predicted class and posterior probability for Adelie?
   **Correct Answer:** B. Predicts Adelie by plurality vote with 66.7% (2/3) probability
   *Explanation:* With 2 Adelie votes out of 3 total neighbors, Adelie wins the plurality vote, and the posterior probability is the neighbor voting fraction: 2/3 = 66.7%.


## Module 04: Pipeline Training & Confidence Scores: Scaling, Workflows & Inference

**q4-01.** What mathematical transformation does StandardScaler perform on each feature?
   **Correct Answer:** B. Subtracts the feature mean and divides by standard deviation: z = (x - mean) / std
   *Explanation:* StandardScaler standardizes features by removing the empirical mean and dividing by standard deviation (z = (x - mean) / std), resulting in zero mean and unit variance.

**q4-02.** In scikit-learn, what is the role of an scikit-learn Pipeline?
   **Correct Answer:** B. To chain data transformers and a final estimator into a single unified object
   *Explanation:* An scikit-learn Pipeline chains sequential preprocessing transformers (like StandardScaler) with a final estimator (like KNeighborsClassifier) into a unified object.

**q4-03.** What does best_model.predict(new_penguin)[0] return for the project's mystery penguin?
   **Correct Answer:** C. 'Adelie'
   *Explanation:* The mystery penguin [39.0, 18.0, 190.0, 3700.0] has physical dimensions characteristic of an Adelie penguin, and best_model.predict() outputs 'Adelie'.

**q4-04.** What confidence score is output by main.py for the mystery penguin prediction?
   **Correct Answer:** D. 100% confident
   *Explanation:* main.py outputs 'New penguin -> Adelie (100% confident)' because all 3 closest neighbors in standardized 4D feature space are Adelie penguins.

**q4-05.** How does KNeighborsClassifier compute class probabilities in predict_proba()?
   **Correct Answer:** B. By calculating the proportion of the k nearest neighbours belonging to each class
   *Explanation:* In KNeighborsClassifier, class probability is calculated as the voting fraction: the number of neighbors belonging to class C divided by k.

**q4-06.** What is the expected order of classes in the 2D probability array returned by predict_proba()?
   **Correct Answer:** C. Alphabetical order matching model.classes_ (Adelie, Chinstrap, Gentoo)
   *Explanation:* Scikit-learn orders columns in predict_proba() strictly according to the alphabetical order stored in model.classes_: index 0 is Adelie, index 1 is Chinstrap, index 2 is Gentoo.

**q4-07.** When best_model.predict(new_penguin) is executed, how does the Pipeline handle feature scaling?
   **Correct Answer:** B. It automatically applies StandardScaler.transform() using the mean and standard deviation learned from X_train
   *Explanation:* When predict() is called on a Pipeline, intermediate transformers automatically execute transform() using the scaling parameters (mean and std) learned during the earlier fit() on X_train.

**q4-08.** Why does a 100% confidence rating occur for the mystery penguin [39.0mm, 18.0mm, 190mm, 3700g] under k=3?
   **Correct Answer:** A. Because all 3 closest neighbors in standardized 4D feature space belong to the Adelie species (3/3 = 100%)
   *Explanation:* With k=3, a 100% confidence rating means that 3 out of 3 closest training neighbors are Adelie penguins, producing a unanimous voting fraction of 3/3 = 1.0.

**q4-09.** If you evaluate a model using k=3, what are the only possible probability values that predict_proba() can produce for any given class?
   **Correct Answer:** B. 0.0, 0.333, 0.667, and 1.0
   *Explanation:* Because probability is the fraction of k neighbors, when k=3 the possible vote counts for any class are 0, 1, 2, or 3, yielding probabilities 0/3=0.0, 1/3=0.333, 2/3=0.667, and 3/3=1.0.

**q4-10.** Why is chaining StandardScaler inside a Pipeline superior to standardizing features manually prior to train_test_split?
   **Correct Answer:** B. Standardizing before splitting computes statistics across the whole dataset, causing data leakage and overly optimistic evaluation scores
   *Explanation:* Standardizing before splitting leaks information about the test set's mean and variance into the training process (data leakage), artificially inflating evaluation metrics.


## Module 05: Model Evaluation & Morphological Visualization

**q5-01.** In scikit-learn, what does the score returned by knn.score(X_test, y_test) represent for a multi-class classification task?
   **Correct Answer:** B. The proportion of test samples correctly classified (overall accuracy)
   *Explanation:* In scikit-learn, calling score(X, y) on a classifier computes subset accuracy, representing the exact proportion of correctly classified instances (sum of correct predictions divided by total instances).

**q5-02.** How does increasing the number of nearest neighbors k from 1 to a larger number typically affect a KNN classifier's decision boundary?
   **Correct Answer:** A. It makes the decision boundary smoother, increasing bias and reducing variance
   *Explanation:* Increasing k incorporates more neighboring data points into each voting decision, smoothing out local boundaries. This increases model bias (making simpler assumptions) while decreasing variance (reducing sensitivity to individual noisy points).

**q5-03.** Why are odd values of k (such as 3 or 5) conventionally preferred when configuring K-Nearest Neighbors classifiers?
   **Correct Answer:** B. Odd values reduce the likelihood of symmetric tie votes between candidate classes
   *Explanation:* Odd values of k prevent 50/50 binary ties and substantially reduce ambiguous voting deadlocks in multi-class problems, ensuring a decisive majority winner in neighborhood polling.

**q5-04.** In our 38-sample test set, the classifier correctly predicted 11 Adelie penguins but falsely predicted 1 Chinstrap as an Adelie. What is the precision for Adelie?
   **Correct Answer:** A. 0.92 (11 / 12)
   *Explanation:* Precision is defined as TP / (TP + FP). For Adelie, the model correctly predicted 11 Adelies (TP = 11) and mistakenly predicted 1 Chinstrap as Adelie (FP = 1). Thus, Precision = 11 / (11 + 1) = 11 / 12 = 0.9167, which rounds to 0.92.

**q5-05.** There are 13 actual Chinstrap penguins in the test set. The model correctly identifies 12 of them and mistakenly predicts 1 as an Adelie. What is the recall for Chinstrap?
   **Correct Answer:** B. 0.92 (12 / 13)
   *Explanation:* Recall is defined as TP / (TP + FN). For Chinstrap, there are 13 actual specimens. The model correctly identified 12 (TP = 12) while missing 1 by classifying it as Adelie (FN = 1). Thus, Recall = 12 / (12 + 1) = 12 / 13 = 0.9231, which rounds to 0.92.

**q5-06.** In scikit-learn's convention for confusion_matrix(y_true, y_pred), what do the rows and columns represent?
   **Correct Answer:** B. Rows represent true ground-truth classes, while columns represent predicted classes
   *Explanation:* In scikit-learn's confusion_matrix, rows strictly represent the ground-truth actual classes, while columns represent the model's predicted classes. Diagonal cells represent True Positives.

**q5-07.** Why does the Gentoo penguin class achieve a perfect 1.00 precision, recall, and F1-score in the Palmer Penguins test set?
   **Correct Answer:** B. Gentoo penguins possess significantly longer flippers and greater body mass, forming an isolated cluster in morphospace
   *Explanation:* Gentoo penguins are biologically distinct: their flippers average ~217 mm and body mass ~5075 g, placing them in an isolated region of 4D feature space far from Adelie and Chinstrap, resulting in zero false positives and zero false negatives.

**q5-08.** What is the primary difference between macro avg and weighted avg in a scikit-learn classification report?
   **Correct Answer:** B. Macro average computes an unweighted arithmetic mean across classes, whereas weighted average weights metrics by class support
   *Explanation:* Macro average treats every class equally by calculating the simple arithmetic mean of the metric across all classes. Weighted average multiplies each class metric by its support (number of actual instances) before summing, accounting for class imbalance.

**q5-09.** In the observed confusion matrix, exactly 1 Adelie is predicted as Chinstrap and 1 Chinstrap is predicted as Adelie. What morphological factor primarily accounts for this mutual confusion?
   **Correct Answer:** A. Adelie and Chinstrap have overlapping body masses and flipper lengths, so tail specimens with atypical bill lengths cross the decision threshold
   *Explanation:* Adelie and Chinstrap penguins have heavily overlapping body masses (~3700 g) and flipper lengths (~190-196 mm). Their primary distinguishing trait is bill length (Adelie ~38.8 mm, Chinstrap ~48.8 mm). Outlier specimens at the tails of these distributions can cross the decision boundary.

**q5-10.** When plotting penguin_scatter.png, why does the pairing of Bill Length (x-axis) and Flipper Length (y-axis) provide superior visual separability compared to other 2D pairs?
   **Correct Answer:** A. Flipper length cleanly separates Gentoo vertically, while bill length cleanly separates Adelie and Chinstrap horizontally
   *Explanation:* In 2D space, flipper length provides vertical separation (isolating Gentoo's long flippers at the top), while bill length provides horizontal separation (isolating Adelie's short bills on the left from Chinstrap's long bills on the right), yielding three distinct non-overlapping clusters.


## Module 06: Inference, Feature Ablation & Model Productionization

**q6-01.** When preparing a novel mystery specimen for inference using a pre-trained pipeline, why must you call scaler.transform() instead of scaler.fit_transform()?
   **Correct Answer:** A. Calling fit_transform() would recalculate the mean and variance on the single query instance, zeroing out features
   *Explanation:* Calling scaler.fit_transform() on a novel sample recalculates the mean and variance on that sample alone. Because a single sample has identical values to its own mean, the centered difference becomes zero, producing an invalid vector of zeros. Inference data must strictly use scaler.transform() using parameters learned from training.

**q6-02.** What input shape does scikit-learn's model.predict() expect when evaluating a single query sample with 4 features?
   **Correct Answer:** B. A 2-dimensional array of shape (1, 4)
   *Explanation:* Scikit-learn design specifications strictly require input matrices to be 2D, structured as (n_samples, n_features). For a single query instance with 4 features, the expected shape is (1, 4).

**q6-03.** In empirical machine learning research, what is the core purpose of a feature ablation study?
   **Correct Answer:** A. To systematically remove individual features or components to quantify their marginal impact on model performance
   *Explanation:* Feature ablation is a systematic scientific protocol where specific features or components are withheld from the model pipeline to observe performance changes and measure each feature's marginal utility or potential noise contribution.

**q6-04.** When querying a KNN classifier with k=3, the method model.predict_proba() returns [1.0, 0.0, 0.0]. What does this output indicate?
   **Correct Answer:** B. All 3 nearest neighbors in the training set belong exclusively to class 0
   *Explanation:* For KNN, predict_proba() calculates the fraction of the k nearest neighbors belonging to each class. When k=3, a probability of 1.0 for class 0 indicates that all 3 neighbors belong to class 0 (3/3 = 1.0).

**q6-05.** Why does omitting body_mass_g from the feature set improve KNN (k=3) test accuracy from 94.7% to 97.4% on the Palmer Penguins dataset?
   **Correct Answer:** A. Body mass has large seasonal fluctuations and overlaps heavily between Adelie and Chinstrap, adding distance noise that pulls boundary specimens into the wrong cluster
   *Explanation:* Body mass fluctuates wildly in wild penguins due to feeding and fasting cycles and overlaps heavily between Adelie (~3700 g) and Chinstrap (~3730 g). In 4D space, this volatility acts as noise in the Euclidean distance calculation, dragging borderline specimens into incorrect neighborhoods. Dropping body mass relies strictly on stable skeletal dimensions, boosting accuracy to 97.4%.

**q6-06.** What is the primary architectural advantage of using sklearn.pipeline.Pipeline over managing StandardScaler and KNeighborsClassifier as separate variables?
   **Correct Answer:** A. It encapsulates scaling and modeling into a single atomic object, preventing data leakage and guaranteeing transforms are applied identically during inference
   *Explanation:* Scikit-learn's Pipeline bundles transformers and estimators into a cohesive unit. It automatically applies the training-derived scaling transformations during inference, preventing data leakage and eliminating manual preprocessing steps.

**q6-07.** Which Python library and function pair is recommended by scikit-learn for serializing trained pipelines to disk for production deployment?
   **Correct Answer:** A. joblib.dump() and joblib.load()
   *Explanation:* joblib.dump() and joblib.load() are the standard, optimized tools for serializing and deserializing scikit-learn estimators and pipelines containing large NumPy arrays.

**q6-08.** What is the computational time complexity of querying a brute-force K-Nearest Neighbors classifier at inference time, given N training specimens and D features?
   **Correct Answer:** B. O(N * D) linear in the number of training samples and features
   *Explanation:* Brute-force KNN computes the Euclidean distance between the query vector and every one of the N stored training vectors across all D dimensions, resulting in O(N * D) computational complexity per query.

**q6-09.** How does K-Nearest Neighbors' non-parametric nature make it uniquely adaptable to adding a 4th penguin species (e.g., King Penguin) compared to parametric neural networks?
   **Correct Answer:** A. KNN requires no architectural re-weighting or retraining; it merely indexes the new labeled feature vectors into its reference set
   *Explanation:* Because KNN is a lazy, instance-based learner, it maintains no fixed weight matrices. Adding a new class merely requires appending the new specimens with label y=3 to the training corpus. Parametric models (like neural networks) require modifying output layer dimensions and retraining weights.

**q6-10.** When scaling a nearest-neighbor classifier to deploy across an enterprise dataset with 10 million specimens, which technique is used to overcome the O(N * D) inference latency bottleneck?
   **Correct Answer:** A. Approximate Nearest Neighbor (ANN) indexing structures such as Hierarchical Navigable Small World (HNSW) graphs or KD-Trees
   *Explanation:* Approximate Nearest Neighbor (ANN) indexers (such as HNSW graphs, KD-Trees, BallTrees, and inverted file indexes in FAISS) partition space to retrieve nearest neighbors in sub-linear O(log N) time, making retrieval scalable to tens of millions of vectors.
