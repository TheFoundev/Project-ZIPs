# Lesson 03: Feature Ablation Experiments: Omitting Body Mass for Higher Accuracy

## Purpose and Learning Objectives
The primary objective of this lesson is to master feature ablation as an empirical method for evaluating feature importance and optimizing machine learning models. In data science, more data features do not automatically produce better predictions. When features carry high intra-class variance or fail to differentiate target classes, they act as noisy distractors in multi-dimensional space. By systematically removing `body_mass_g` from the feature set and observing test accuracy increase from $94.7\%$ to $97.4\%$, students will uncover the counter-intuitive mechanics of feature selection and the curse of dimensionality in distance-based algorithms.

By the end of this lesson, you will be able to:
- Define feature ablation and its role in diagnostic machine learning workflows.
- Explain how noisy, uninformative features degrade Euclidean distance calculations in K-Nearest Neighbors.
- Implement an ablation experiment comparing 4-feature models against 3-feature models in scikit-learn.
- Analyze the biological reasons why body mass fluctuates independent of species identity.
- Verify that removing `body_mass_g` eliminates the Adelie misclassification, elevating test accuracy to $97.4\%$ ($37/38$ correct).

## Prerequisites
Before starting this lesson, you should be familiar with:
- The baseline 4-feature model achieving $94.7\%$ accuracy from Module 05 and Lesson 01.
- Euclidean distance geometry in normalized coordinate spaces from Module 04.
- Biological morphometrics and species differences from Module 01 and Module 02.

## Biological and Real-World Context
In animal physiology, certain physical traits are highly conserved and stable, while others fluctuate dramatically based on seasonal and environmental factors.
- **Skeletal traits** (bill length, bill depth, and flipper length) are determined by bone structure and cartilage. Once an adult penguin reaches maturity, these dimensions remain essentially fixed throughout its lifetime.
- **Soft-tissue mass** (`body_mass_g`), on the other hand, is highly volatile. An adult Adelie penguin arriving on the breeding grounds after months of oceanic feeding can weigh over $4500\text{ g}$. After weeks of incubating an egg without food, that same individual can drop below $3000\text{ g}$—a loss of more than $30\%$ of its total mass.

Furthermore, Adelie and Chinstrap penguins possess nearly identical average body masses in nature:
- Adelie Mean Body Mass: $\approx 3700\text{ g}$
- Chinstrap Mean Body Mass: $\approx 3730\text{ g}$

Because their distributions overlap almost completely, body mass provides virtually zero discriminative signal for separating Adelie from Chinstrap. Instead, seasonal weight changes introduce random noise into the distance metric, occasionally pulling a healthy Adelie closer to the Chinstrap cluster.

## Concept Explanation
### The Mechanics of Feature Ablation
Feature ablation is the controlled removal of individual input features (or groups of features) to measure their marginal contribution to overall model performance.
1. Train and evaluate the baseline model with all $D$ features: $\text{Score}_{\text{baseline}}$.
2. Remove feature $j$, producing a reduced feature matrix of dimension $D - 1$.
3. Re-train and evaluate the estimator on the identical train/test partition: $\text{Score}_{\text{ablated}}$.
4. Calculate the ablation impact:
   $$\Delta = \text{Score}_{\text{ablated}} - \text{Score}_{\text{baseline}}$$
   - If $\Delta < 0$, feature $j$ provided essential predictive signal; removing it harms the model.
   - If $\Delta = 0$, feature $j$ was redundant.
   - If $\Delta > 0$, feature $j$ was actively acting as a distractor or noise contributor; removing it improves generalization.

### How Noisy Features Corrupt Nearest Neighbors
Recall the 4-dimensional standardized Euclidean distance:

$$d(\mathbf{p}, \mathbf{q}) = \sqrt{(z_{p,1} - z_{q,1})^2 + (z_{p,2} - z_{q,2})^2 + (z_{p,3} - z_{q,3})^2 + (z_{p,4} - z_{q,4})^2}$$

Where coordinate 4 corresponds to standardized body mass ($z_4$).
- Suppose specimen $P$ (an Adelie) and specimen $Q$ (another Adelie) have nearly identical bill and flipper dimensions: $\sum_{j=1}^3 (z_{p,j} - z_{q,j})^2 = 0.05$.
- However, specimen $P$ has just finished feeding ($z_{p,4} = +1.2$) while specimen $Q$ has been fasting ($z_{q,4} = -1.1$).
- The squared distance along dimension 4 is $(1.2 - (-1.1))^2 = 2.3^2 = 5.29$.
- The total distance balloons from $\sqrt{0.05} \approx 0.22$ to $\sqrt{0.05 + 5.29} \approx 2.31$.
- Meanwhile, an adjacent Chinstrap specimen that happens to share a similar weight state may sit at distance $1.80$. The classifier chooses the Chinstrap as the nearest neighbor simply because their body masses aligned, resulting in a misclassification!

By dropping the volatile mass dimension, distance calculations rely strictly on stable skeletal proportions: Bill Length, Bill Depth, and Flipper Length.

## Relevant Code (from main.py)
In `main.py`, all 4 features are used by default:
```python
features = ["bill_length_mm", "bill_depth_mm", "flipper_length_mm", "body_mass_g"]
```

To execute the ablation experiment, we construct an alternate feature matrix excluding `body_mass_g`:
```python
# Feature ablation: omit body_mass_g
features_ablated = ["bill_length_mm", "bill_depth_mm", "flipper_length_mm"]
X_ablated = df[features_ablated].values

X_tr_ab, X_te_ab, y_tr, y_te = train_test_split(
    X_ablated, y, test_size=0.25, random_state=42, stratify=y
)

scaler_ab = StandardScaler()
X_tr_scaled = scaler_ab.fit_transform(X_tr_ab)
X_te_scaled = scaler_ab.transform(X_te_ab)

knn_ab = KNeighborsClassifier(n_neighbors=3)
knn_ab.fit(X_tr_scaled, y_tr)
acc_ab = knn_ab.score(X_te_scaled, y_te)
print(f"3-Feature Accuracy (without body_mass_g): {acc_ab*100:.1f}%")
```

## Code Explanation
Let us inspect the implementation mechanics:
1. `features_ablated = ["bill_length_mm", "bill_depth_mm", "flipper_length_mm"]`: Selects only the 3 skeletal dimensions, dropping the soft-tissue weight metric.
2. `train_test_split(..., random_state=42, stratify=y)`: Reuses the exact same random state and stratification target. In ablation studies, keeping the train/test partition identical is critical to ensure that any change in accuracy stems purely from the feature modification rather than random sample re-shuffling.
3. `scaler_ab.fit_transform(X_tr_ab)`: Fits a new 3-dimensional scaler. Notice that `StandardScaler` must be re-fitted on the reduced 3-column matrix; using the old 4-column scaler would cause a dimension mismatch error.
4. `knn_ab.score(X_te_scaled, y_te)`: Evaluates the 3-feature classifier against the 38 test specimens.
5. The output demonstrates an increase from $94.7\%$ to $97.4\%$.

## Worked Example
Let us trace the confusion matrices before and after the ablation:
- **Baseline 4-Feature Model ($k=3$)**:
  ```text
                    Adelie   Chinstrap      Gentoo
  Adelie                11           1           0
  Chinstrap              1          12           0
  Gentoo                 0           0          13
  Accuracy: 36 / 38 = 94.7%
  ```
- **Ablated 3-Feature Model (Omitting `body_mass_g`, $k=3$)**:
  ```text
                    Adelie   Chinstrap      Gentoo
  Adelie                12           0           0
  Chinstrap              1          12           0
  Gentoo                 0           0          13
  Accuracy: 37 / 38 = 97.4%
  ```

### What Happened to the Adelie Misclassification?
- In the 4-feature baseline, 1 Adelie specimen (index #1 in our Exercise 05 analysis: bill $44.1\text{ mm}$, flipper $210\text{ mm}$, mass $4000\text{ g}$) was misclassified as Chinstrap.
- Why was it misclassified previously? Because its body mass was $4000\text{ g}$—unusually heavy for an Adelie, falling closer to the upper Chinstrap range. In 4D space, that mass deviation added significant distance from the Adelie centroid.
- When `body_mass_g` is removed, the distance calculation focuses strictly on its bill depth ($18.0\text{ mm}$) and bill length ($44.1\text{ mm}$). Because Chinstrap bill depths average only $18.4\text{ mm}$ for much longer bills, the skeletal proportions anchor the specimen firmly to Adelie training points.
- As a result, Adelie recall jumps from $91.7\%$ to $100.0\%$! Only 1 Chinstrap remains misclassified as Adelie.

## Step-by-Step Student Instructions
1. Open a new script in your workspace named `ablation_study.py`.
2. Copy the ablation code snippet from the "Relevant Code" section.
3. Run the script: `python ablation_study.py`.
4. Inspect the printed accuracy: verify that it displays `97.4%`.
5. Compute the raw count of correct test samples: $38 \times 0.97368... = 37$.
6. Print the updated confusion matrix using `confusion_matrix(y_te, knn_ab.predict(X_te_scaled))`.
7. Confirm that the top row now reads `[12, 0, 0]`, demonstrating zero Adelie errors.

## Expected Output or Observable Behaviour
When executing `ablation_study.py`, the following output appears in your console:
```text
3-Feature Accuracy (without body_mass_g): 97.4%
Updated Confusion Matrix:
[[12  0  0]
 [ 1 12  0]
 [ 0  0 13]]
```
Key observations:
- Test accuracy improves by $+2.7\%$ (from $94.7\%$ to $97.4\%$).
- Adelie classification achieves $100\%$ precision and $100\%$ recall.
- Exactly 1 error remains across the entire 38-specimen test set (a single Chinstrap with unusually short bill misclassified as Adelie).

## Practical Exercises
### Exercise 1: Single-Feature Ablation Sweep
Conduct a full leave-one-out feature ablation study across all 4 features. Create a loop that removes one feature at a time, trains a KNN ($k=3$), and prints the delta:
```python
baseline_acc = 0.947
for feat in features:
    sub_feats = [f for f in features if f != feat]
    X_sub = df[sub_feats].values
    X_tr, X_te, y_tr, y_te = train_test_split(X_sub, y, test_size=0.25, random_state=42, stratify=y)
    scaler = StandardScaler()
    X_tr = scaler.fit_transform(X_tr)
    X_te = scaler.transform(X_te)
    clf = KNeighborsClassifier(n_neighbors=3)
    clf.fit(X_tr, y_tr)
    acc = clf.score(X_te, y_te)
    print(f"Omitted {feat:18} -> Acc: {acc*100:.1f}% (Δ: {(acc - baseline_acc)*100:+.1f}%)")
```
Determine which single feature causes the largest drop in accuracy when removed.

### Exercise 2: Minimalist 2-Feature Classifier
Train a classifier using only the two most visually distinct features: `bill_length_mm` and `flipper_length_mm`. What accuracy does this minimalist 2-feature model achieve on the test set?

## Common Mistakes and Debugging
- **Evaluating on Different Splits**: If you fail to use `random_state=42` and `stratify=y` when creating the ablated feature dataset, changes in accuracy will reflect random partitioning noise rather than the genuine effect of removing the feature.
- **Reusing the 4-Feature Scaler**: Attempting to call `scaler.transform(X_te_ab)` using the 4-feature fitted scaler will trigger `ValueError: X has 3 features, but StandardScaler is expecting 4 features as input`. Always fit a dedicated scaler for each feature subset.
- **Overinterpreting Small Dataset Deltas**: On a 38-sample test set, a single sample represents $1/38 \approx 2.63\%$. While the $97.4\%$ result is statistically sound and biologically explainable, real-world data science requires validating such improvements with k-fold cross-validation.

## Best Practices and Security Considerations
- **Occam's Razor (Principle of Parsimony)**: All other things being equal, prefer the simpler model with fewer input features. Models with fewer features are cheaper to collect data for, faster to compute, and less vulnerable to sensor drift.
- **Domain-Driven Feature Selection**: Do not rely purely on brute-force search. Pair empirical metrics with biological or physical understanding of why a trait behaves as signal or noise.
- **Documenting Feature Dropping**: When pruning features in production systems, document the biological and statistical justification in technical model cards.

## Summary and Key Takeaways
- Feature ablation isolates the empirical value of individual input variables by measuring performance changes when features are removed.
- Soft-tissue mass (`body_mass_g`) fluctuates substantially within individual penguins due to feeding and fasting cycles, introducing noise into distance calculations.
- Because Adelie and Chinstrap share nearly identical average body masses, body mass fails to provide discriminative signal between them.
- Omitting `body_mass_g` boosts KNN ($k=3$) accuracy from $94.7\%$ to $97.4\%$, eliminating the Adelie false positive error.

## Knowledge-check Questions
1. Why does an increase in accuracy after removing a feature indicate that the feature was acting as noise?
2. Biologically, why is skeletal bill length a more reliable species indicator than body mass in wild penguins?
3. How many test specimens are correctly classified by the 3-feature model out of 38?
4. Why must `StandardScaler` be re-fitted when changing the number of features from 4 to 3?

## References
- Guyon, I., & Elisseeff, A. (2003). An introduction to variable and feature selection. *Journal of Machine Learning Research*, 3(Mar), 1157-1182.
- Blum, A. L., & Langley, P. (1997). Selection of relevant features and examples in machine learning. *Artificial Intelligence*, 97(1-2), 245-271.
- Gorman, K. B., Williams, T. D., & Fraser, W. R. (2014). Ecological Sexual Dimorphism and Environmental Variability within a Community of Antarctic Penguins (Genus Pygoscelis). *PLoS ONE*, 9(3), e90081.
