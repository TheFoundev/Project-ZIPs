# Lesson 04: Architectural Scaling: Adding New Species and Productionizing KNN

## Purpose and Learning Objectives
The primary objective of this lesson is to examine how to transition an educational prototype model into a scalable, maintainable, and extensible production machine learning system. In research and industrial practice, machine learning models face evolving requirements: biological taxonomies expand to include new species, query volume increases from single field tests to millions of automated sensor readings, and standalone Python scripts must be deployed as containerized web microservices. By exploring how K-Nearest Neighbors handles architectural extensions—such as introducing a 4th penguin species, implementing approximate nearest neighbor indexing, and serializing models with scikit-learn pipelines—students will acquire professional ML engineering skills.

By the end of this lesson, you will be able to:
- Explain how non-parametric lazy learners like KNN accommodate new classes without structural model retraining.
- Analyze the asymptotic time and space complexity of brute-force KNN during training and query phases.
- Identify when and how to transition from exact Euclidean search to Approximate Nearest Neighbor (ANN) indexers (e.g., FAISS, HNSW).
- Serialize and deserialize complete preprocessing and model pipelines using `joblib`.
- Encapsulate preprocessing transformations and estimators into unified `sklearn.pipeline.Pipeline` architectures.

## Prerequisites
Before starting this lesson, you should be familiar with:
- The full end-to-end pipeline execution from Lesson 01.
- Feature ablation and standardization mechanics from Lesson 03.
- Object serialization concepts and Python virtual environment package management.

## Biological and Real-World Context
In global wildlife conservation and ornithological surveillance, regional field stations often need to adapt local algorithms to broader geographical territories. The Palmer Penguins dataset focuses on three brush-tailed species (*Pygoscelis*) inhabiting the Antarctic Peninsula. 

However, an environmental agency expanding monitoring operations to the sub-Antarctic Prince Edward Islands or South Georgia encounters additional penguin species:
- **King Penguin** (*Aptenodytes patagonicus*): A massive penguin with bill lengths exceeding $120\text{ mm}$, flipper lengths over $300\text{ mm}$, and body mass averaging $13\text{--}16\text{ kg}$.
- **Macaroni Penguin** (*Eudyptes chrysolophus*): A crested penguin species with heavy, bulbous orange-red beaks and intermediate flipper lengths.

If our classifier were a rigid parametric model (such as a multi-layer perceptron neural network with a fixed 3-unit output layer), incorporating a fourth species would require completely redesigning the network architecture and retraining all internal weights from scratch. In contrast, K-Nearest Neighbors offers remarkable structural flexibility: expanding to a 4th or 5th species merely requires adding reference morphological vectors to the training database.

## Concept Explanation
### Non-Parametric Class Extensibility
In parametric models (e.g., Logistic Regression, Multi-Layer Perceptrons):
- The model architecture fixes the number of target classes $C$ in advance (e.g., $W \in \mathbb{R}^{D \times C}$).
- Adding a new class requires changing the weight matrix shape, reinitializing parameters, and performing iterative gradient descent optimization over the entire dataset.

In non-parametric instance-based models (KNN):
- The model parameters are the training data vectors themselves: $\mathcal{D} = \{(\mathbf{x}_i, y_i)\}_{i=1}^N$.
- Adding a 4th species (e.g., `King`) requires appending new observations to $\mathcal{D}$ with label $y = 3$.
- The prediction rule remains identical: find the $k$ nearest points in the augmented space and take the majority vote. No matrix re-dimensioning or iterative re-optimization is required.

### Asymptotic Complexity and the Scaling Bottleneck
While KNN is uniquely flexible during class expansion, it incurs steep computational costs as dataset size $N$ grows:

| Operation | Brute-Force KNN Complexity | Logistic Regression Complexity |
| :--- | :--- | :--- |
| **Training Time** | $\mathcal{O}(1)$ (Instantaneous storage) | $\mathcal{O}(N \cdot D \cdot \text{iterations})$ |
| **Storage (RAM)** | $\mathcal{O}(N \cdot D)$ (Stores all points) | $\mathcal{O}(D \cdot C)$ (Stores weights only) |
| **Inference Time** | $\mathcal{O}(N \cdot D + N \log k)$ | $\mathcal{O}(D \cdot C)$ (Single dot product) |

For our Palmer dataset ($N = 112$ training samples, $D = 4$ features), computing Euclidean distance takes less than $10$ microseconds. However, if deployed in a global marine bio-logger system processing $N = 10,000,000$ historical sensor records:
- Storing $10$ million records requires gigabytes of active memory.
- Calculating exact Euclidean distances against all $10$ million vectors for every new query creates unacceptable inference latency.

### Transitioning to Approximate Nearest Neighbor (ANN) Indexing
To scale nearest-neighbor retrieval to millions of high-dimensional vectors, modern production architectures replace brute-force Euclidean scanning with **Approximate Nearest Neighbor (ANN)** indexing structures:
1. **Tree-Based Methods (KD-Tree, BallTree)**: Scikit-learn supports `algorithm='kd_tree'` or `algorithm='ball_tree'`, which recursively partition feature space into hierarchical bounding boxes, reducing query complexity to $\mathcal{O}(D \log N)$ for low dimensions ($D < 20$).
2. **Graph-Based Methods (HNSW - Hierarchical Navigable Small World)**: Libraries such as FAISS (Facebook AI Similarity Search) and Hnswlib construct multi-layer skip-graphs where nodes represent vectors. Queries navigate rapidly through coarse long-range links before settling into fine local neighborhoods, delivering millisecond queries across hundreds of millions of vectors.
3. **Quantization (Product Quantization - PQ)**: Compresses floating-point feature vectors into compact binary codes, reducing memory consumption by up to $95\%$.

### Pipeline Encapsulation and Serialization
In production software engineering, preprocessing transformers and estimators should never be managed as separate, detached objects. Scikit-learn provides `Pipeline` to chain preprocessing and model fitting into a single deployable object:

```python
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
import joblib

# Bundle preprocessing and model into a unified pipeline
penguin_pipeline = Pipeline([
    ("scaler", StandardScaler()),
    ("knn", KNeighborsClassifier(n_neighbors=3))
])

# Fit pipeline end-to-end
penguin_pipeline.fit(X_train, y_train)

# Export complete pipeline artifact
joblib.dump(penguin_pipeline, "penguin_pipeline.joblib")
```

When loaded in a production web API, calling `loaded_pipeline.predict(raw_mystery)` automatically executes `StandardScaler.transform` before querying `KNeighborsClassifier.predict`, eliminating data leakage, manual transformation errors, and feature order mismatches.

## Relevant Code (from main.py)
In `main.py`, the model and scaler are instantiated separately:
```python
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

best_k = 3
model = KNeighborsClassifier(n_neighbors=best_k)
model.fit(X_train, y_train)
```

In an industrial production architecture, this is refactored into an encapsulated, serializable pipeline:
```python
from sklearn.pipeline import Pipeline
import joblib

# Production pipeline construction
pipeline = Pipeline([
    ("scaler", StandardScaler()),
    ("classifier", KNeighborsClassifier(n_neighbors=3))
])

# End-to-end training
pipeline.fit(X_train_raw, y_train)

# Model serialization
joblib.dump(pipeline, "penguin_model_v1.joblib")
print("Exported production pipeline to penguin_model_v1.joblib")

# Production inference loading
deployed_model = joblib.load("penguin_model_v1.joblib")
pred = deployed_model.predict(mystery)
print(f"Production Inference: {species_names[pred[0]]}")
```

## Code Explanation
Let us analyze how this production pattern transforms our codebase:
1. `Pipeline([('scaler', StandardScaler()), ('classifier', KNeighborsClassifier(n_neighbors=3))])`:
   - Constructs an immutable directed processing chain.
   - The first step (`scaler`) must be a transformer implementing `fit` and `transform`.
   - The final step (`classifier`) is an estimator implementing `fit` and `predict`.
2. `pipeline.fit(X_train_raw, y_train)`:
   - Takes raw, unscaled millimeter and gram measurements.
   - Automatically computes training means and variances on `X_train_raw`.
   - Transforms `X_train_raw` into scaled z-scores.
   - Fits the `KNeighborsClassifier` on the resulting scaled data.
   - Prevents accidental data leakage between preprocessing and estimation.
3. `joblib.dump(pipeline, "penguin_model_v1.joblib")`:
   - Serializes the entire pipeline—including learned scaling parameters ($oldsymbol{\mu}, oldsymbol{\sigma}$), all 112 reference training vectors, and hyperparameter settings ($k=3$)—into a compact, portable binary file.
4. `deployed_model = joblib.load(...)`:
   - Reconstructs the complete trained pipeline in memory in less than 2 milliseconds.
5. `deployed_model.predict(mystery)`:
   - Ingests raw physical measurements directly without manual pre-scaling, applying the saved scaling transform automatically.

## Worked Example
Let us simulate what happens when expanding our dataset to include a 4th species: **King Penguin** (*Aptenodytes patagonicus*).
Suppose we add 10 King Penguin observations to our dataset:
- Bill length: $110\text{--}130\text{ mm}$ (vs. Adelie $38\text{ mm}$, Gentoo $47\text{ mm}$)
- Bill depth: $15\text{--}18\text{ mm}$
- Flipper length: $300\text{--}340\text{ mm}$ (vs. Gentoo $217\text{ mm}$)
- Body mass: $12000\text{--}15000\text{ g}$ (vs. Gentoo $5000\text{ g}$)

Let us trace how the pipeline accommodates this new species:
```python
import numpy as np

# Synthetic King Penguin records
king_penguins = np.array([
    [120.0, 16.5, 315.0, 13500.0],
    [125.0, 17.0, 320.0, 14200.0],
    [118.0, 15.8, 310.0, 13000.0]
])
king_labels = np.array([3, 3, 3])

# Augmented training set
X_augmented = np.vstack([X_train_raw, king_penguins])
y_augmented = np.concatenate([y_train, king_labels])
species_names_ext = ["Adelie", "Chinstrap", "Gentoo", "King"]

# Re-fit production pipeline
pipeline.fit(X_augmented, y_augmented)

# Predict an unknown mega-penguin specimen
giant_specimen = np.array([[122.0, 16.2, 318.0, 13800.0]])
giant_pred = pipeline.predict(giant_specimen)
print(f"Species: {species_names_ext[giant_pred[0]]}")
# Emits: Species: King
```

Because King penguins are biologically distinct in size, their standardized coordinates sit at $z > +5.0$ along flipper and mass axes. The KNN classifier classifies them with $100\%$ precision, completely separated from the three *Pygoscelis* species without requiring architectural re-engineering.

## Step-by-Step Student Instructions
1. Open your terminal and activate your virtual environment.
2. Verify that `joblib` is installed: `python -c "import joblib; print(joblib.__version__)"`.
3. Create a script named `production_pipeline.py`.
4. Copy the scikit-learn `Pipeline` and `joblib` serialization code.
5. Execute the script: `python production_pipeline.py`.
6. Verify that `penguin_model_v1.joblib` is generated on disk: `ls -lh penguin_model_v1.joblib`.
7. Inspect the file size. Notice that the entire pipeline model artifact is small (typically under $25\text{ KB}$).
8. Execute a test inference query loading the saved `.joblib` file and confirm that it outputs `Adelie`.

## Expected Output or Observable Behaviour
When executing the production pipeline script:
```text
Exported production pipeline to penguin_model_v1.joblib
Production Inference: Adelie
```
On disk:
- A new serialized binary file `penguin_model_v1.joblib` is created.
- Loading the file in a separate Python process restores the identical model state and returns identical predictions without requiring access to `data/penguins.csv`.

## Practical Exercises
### Exercise 1: Building a Minimal FastAPI Microservice
Write a lightweight REST API script using `fastapi` and `uvicorn` that serves real-time penguin predictions:
```python
# app.py
from fastapi import FastAPI
from pydantic import BaseModel
import joblib

app = FastAPI(title="Penguin Detective API")
pipeline = joblib.load("penguin_model_v1.joblib")
species_names = ["Adelie", "Chinstrap", "Gentoo"]

class PenguinFeatures(BaseModel):
    bill_length_mm: float
    bill_depth_mm: float
    flipper_length_mm: float
    body_mass_g: float

@app.post("/predict")
def predict_species(item: PenguinFeatures):
    data = [[item.bill_length_mm, item.bill_depth_mm, item.flipper_length_mm, item.body_mass_g]]
    pred = pipeline.predict(data)[0]
    proba = pipeline.predict_proba(data)[0]
    return {
        "species": species_names[pred],
        "confidence": float(proba[pred])
    }
```
Discuss how packaging the model in a pipeline makes API endpoint handlers clean and robust.

### Exercise 2: Benchmarking Inference Latency Across k
Write a benchmarking loop that queries the serialized model 10,000 times with random noise inputs. Calculate the mean latency per inference request in microseconds.

## Common Mistakes and Debugging
- **Pickling Incompatible Environments**: Serializing a model using Python 3.12 and attempting to load it in Python 3.9 can trigger `ModuleNotFoundError` or `AttributeError` due to internal bytecode differences. Always record library versions in `requirements.txt`.
- **Forgetting Scaler in Production**: A frequent rookie mistake is serializing only the `KNeighborsClassifier` while discarding the `StandardScaler`. Passing raw inputs directly to the unscaled classifier causes catastrophic misclassification. Always encapsulate both in a `Pipeline`.
- **Security Vulnerabilities in Deserialization**: Never load untrusted `.joblib` or `.pkl` files downloaded from public forums or unauthenticated networks, as Python object unpickling can execute arbitrary system commands. Use cryptographic signature checks (e.g., SHA-256) on model artifacts.

## Best Practices and Security Considerations
- **Model Versioning and Registry**: Maintain an explicit version naming convention (e.g., `penguin_knn_v1.0.0.joblib`) accompanied by metadata documenting training date, Git commit hash, dataset checksum, and test accuracy.
- **Health Checks and Drift Monitoring**: Monitor prediction distributions in production. If the model suddenly stops predicting Adelie penguins or begins emitting low-confidence probabilities, alert engineers to potential sensor drift or distribution shift.
- **Deterministic Pipeline Construction**: Always set fixed seeds in random sampling transformers and enforce type-checked interfaces for production inputs.

## Summary and Key Takeaways
- K-Nearest Neighbors readily accommodates new classes without architectural redesign; adding a 4th species merely requires indexing new labeled vectors.
- Brute-force KNN inference complexity scales linearly with dataset size ($\mathcal{O}(N \cdot D)$), requiring Approximate Nearest Neighbor (ANN) indexers (like KD-Trees, BallTrees, or HNSW) for large datasets.
- Scikit-learn's `Pipeline` encapsulates preprocessing transformers and estimators into a single atomic artifact.
- Model serialization via `joblib` allows instantaneous deployment of pre-trained pipelines to edge field devices and cloud microservices.

## Knowledge-check Questions
1. Why does K-Nearest Neighbors not require weight re-initialization or structural changes when a 4th class is added to the training set?
2. What is the time complexity of querying a brute-force KNN classifier with $N$ reference points and $D$ dimensions?
3. What is the primary operational advantage of wrapping `StandardScaler` and `KNeighborsClassifier` inside a scikit-learn `Pipeline`?
4. Why is unpickling a `.joblib` file from an untrusted source considered a major security risk?

## References
- Pedregosa, F., et al. (2011). Scikit-learn: Machine Learning in Python. *Journal of Machine Learning Research*, 12, 2825-2830.
- Malkov, Y. A., & Yashunin, D. A. (2020). Efficient and robust approximate nearest neighbor search using Hierarchical Navigable Small World graphs. *IEEE Transactions on Pattern Analysis and Machine Intelligence*, 42(4), 824-836.
- Scikit-Learn Pipeline Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.pipeline.Pipeline.html
