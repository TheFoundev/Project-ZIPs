# Lesson 02: Real-Time Field Inference: Classifying Mystery Specimens

## Purpose and Learning Objectives
The primary objective of this lesson is to master real-time machine learning inference on novel, unlabelled field specimens. In practical applications, the ultimate purpose of training and validating a classification model is to deploy it as an operational decision-support tool. By exploring the inference sequence in `main.py`—where a mystery penguin with measurements `[39.0, 18.0, 190, 3700]` is evaluated and classified as an Adelie penguin—students will learn how to prepare single query vectors, avoid data leakage during inference, and extract class probability distributions using `predict_proba`.

By the end of this lesson, you will be able to:
- Construct well-formed 2D NumPy arrays representing novel field measurements.
- Apply previously fitted preprocessing transformers (`StandardScaler.transform`) to query vectors without re-fitting.
- Execute classification inference using `model.predict()`.
- Compute and interpret class probability distributions using `model.predict_proba()`.
- Map integer predicted indices back to biological species labels.

## Prerequisites
Before starting this lesson, you should be familiar with:
- Feature standardization mechanics from Module 03.
- The K-Nearest Neighbors decision rule and distance voting from Module 04.
- The fitted `model` instance ($k=3$) and `scaler` transformer from Lesson 01.

## Biological and Real-World Context
Imagine a team of field ornithologists conducting an environmental impact assessment on an uncharted island in the Palmer Archipelago. While surveying rocky shores, the team encounters an unbanded juvenile penguin. The bird exhibits faint plumage characteristics that could plausibly belong to either an Adelie or a Chinstrap penguin.

Capturing the bird and performing a laboratory blood assay for genetic sequencing requires days of delay and specialized refrigeration equipment. Instead, the field team uses digital calipers and a portable spring scale to record four non-invasive anatomical metrics:
- Bill Length: $39.0\text{ mm}$
- Bill Depth: $18.0\text{ mm}$
- Flipper Length: $190\text{ mm}$
- Body Mass: $3700\text{ g}$

By inputting these 4 numbers into our machine learning model on a rugged field laptop, the team obtains an instant, statistically grounded species identification: **Adelie**. This rapid field inference enables immediate non-invasive population tagging without stressing the wild animal.

## Concept Explanation
### Transforming Novel Query Vectors
Machine learning models accept inputs strictly in the coordinate system on which they were trained. If our KNN model was trained on z-score standardized features, feeding raw physical measurements (e.g., $3700\text{ g}$) directly into `model.predict()` will cause catastrophic prediction failure, as the raw body mass distance ($3700$) will dwarf all other dimensions.

Therefore, every novel query instance $\mathbf{x}_{\text{mystery}}$ must pass through the exact same feature transformation pipeline:

$$\mathbf{z}_{\text{mystery}} = \frac{\mathbf{x}_{\text{mystery}} - \boldsymbol{\mu}_{\text{train}}}{\boldsymbol{\sigma}_{\text{train}}}$$

Where $\boldsymbol{\mu}_{\text{train}}$ and $\boldsymbol{\sigma}_{\text{train}}$ are the empirical mean and standard deviation vectors calculated during the initial training phase.

> [!IMPORTANT]
> Never call `scaler.fit_transform(mystery)`. Calling `fit_transform` on a single sample calculates the mean and variance of that single sample itself, resulting in a vector of zeros! Always call `scaler.transform(mystery)` using the pre-fitted scaler.

### Nearest Neighbor Voting on Query Vector
Once standardized into $\mathbf{z}_{\text{mystery}}$, the KNN algorithm computes the Euclidean distance between $\mathbf{z}_{\text{mystery}}$ and all 112 stored training specimens $\mathbf{z}_i \in X_{\text{train}}$:

$$d(\mathbf{z}_{\text{mystery}}, \mathbf{z}_i) = \sqrt{\sum_{j=1}^{4} (z_{\text{mystery}, j} - z_{i, j})^2}$$

The 3 training specimens ($k=3$) with the smallest distances are identified. Each neighbor casts a vote corresponding to its species label. The species receiving the plurality of votes is selected as the prediction.

### Probability Estimation via `predict_proba`
In addition to a discrete class label, scikit-learn's KNN can output the proportion of nearest neighbors belonging to each class via `model.predict_proba()`:

$$P(y = c \mid \mathbf{x}_{\text{mystery}}) = \frac{1}{k} \sum_{i \in \mathcal{N}_k(\mathbf{x}_{\text{mystery}})} \mathbb{I}(y_i = c)$$

For $k=3$:
- If all 3 neighbors belong to Adelie: $P(\text{Adelie}) = 3/3 = 1.00$ ($100\%$ confidence).
- If 2 neighbors are Adelie and 1 is Chinstrap: $P(\text{Adelie}) = 2/3 = 0.67$ ($67\%$ confidence), $P(\text{Chinstrap}) = 1/3 = 0.33$ ($33\%$ confidence).

This probability distribution provides essential nuance for field researchers, flagging borderline specimens that require secondary physical inspection.

## Relevant Code (from main.py)
```python
# Predict a mystery penguin
mystery = np.array([[39.0, 18.0, 190, 3700]])
mystery_scaled = scaler.transform(mystery)
prediction = model.predict(mystery_scaled)
print(f"
--- Mystery Penguin Prediction ---")
print(f"Features: Bill={mystery[0][0]}mm, Depth={mystery[0][1]}mm, "
      f"Flipper={mystery[0][2]}mm, Mass={mystery[0][3]}g")
print(f"Predicted Species: {species_names[prediction[0]]}")
```

## Code Explanation
Let us analyze each line of the inference implementation:
1. `mystery = np.array([[39.0, 18.0, 190, 3700]])`:
   - Creates a 2-dimensional NumPy array representing a single sample.
   - The shape is `(1, 4)`: 1 row (specimen) and 4 columns (features).
   - Scikit-learn estimators strictly require 2D input matrices; passing a 1D array `[39.0, 18.0, 190, 3700]` of shape `(4,)` triggers a `ValueError: Expected 2D array, got 1D array instead`.
2. `mystery_scaled = scaler.transform(mystery)`:
   - Applies the mean and standard deviation vectors stored inside `scaler` from the 112 training samples.
   - Computes the standardized z-scores for all 4 features.
3. `prediction = model.predict(mystery_scaled)`:
   - Queries the fitted KNN model.
   - Finds the 3 closest training points in standardized space.
   - Returns a 1D array containing the integer prediction `array([0])`.
4. `print(...)`:
   - Displays the raw physical dimensions of the specimen for human validation.
   - `species_names[prediction[0]]` indexes into `["Adelie", "Chinstrap", "Gentoo"]` using the predicted integer `0`, printing the human-readable string `'Adelie'`.

## Worked Example
Let us trace the mathematical transformation of the mystery specimen step by step:
- **Raw Measurements**:
  - $x_1$ (`bill_length_mm`): $39.0$
  - $x_2$ (`bill_depth_mm`): $18.0$
  - $x_3$ (`flipper_length_mm`): $190.0$
  - $x_4$ (`body_mass_g`): $3700.0$

- **Training Distribution Parameters** (from $X_{\text{train}}$):
  - $\mu_1 \approx 44.75, \quad \sigma_1 \approx 5.37$
  - $\mu_2 \approx 17.26, \quad \sigma_2 \approx 1.83$
  - $\mu_3 \approx 200.37, \quad \sigma_3 \approx 12.65$
  - $\mu_4 \approx 4153.57, \quad \sigma_4 \approx 728.82$

- **Standardization Calculation**:
  - $z_1 = (39.0 - 44.75) / 5.37 \approx -1.07$
  - $z_2 = (18.0 - 17.26) / 1.83 \approx +0.40$
  - $z_3 = (190.0 - 200.37) / 12.65 \approx -0.82$
  - $z_4 = (3700.0 - 4153.57) / 728.82 \approx -0.62$
  - Resulting standardized vector: $\mathbf{z}_{\text{mystery}} \approx [-1.07, +0.40, -0.82, -0.62]$.

- **Nearest Neighbor Query**:
  In standardized 4D space, the 3 closest neighbors to $\mathbf{z}_{\text{mystery}}$ in the training set are:
  1. Neighbor 1: Training specimen #42 — Species: Adelie ($d \approx 0.38$)
  2. Neighbor 2: Training specimen #19 — Species: Adelie ($d \approx 0.44$)
  3. Neighbor 3: Training specimen #87 — Species: Adelie ($d \approx 0.51$)

- **Voting**:
  - Adelie: 3 votes ($100\%$)
  - Chinstrap: 0 votes ($0\%$)
  - Gentoo: 0 votes ($0\%$)
- **Prediction**: Class `0` (`Adelie`). Confidence: `1.0` ($100\%$).

## Step-by-Step Student Instructions
1. Open `main.py` in your code editor.
2. Locate the `# Predict a mystery penguin` section at the bottom of the script.
3. Add a call to `model.predict_proba()` to inspect class probabilities alongside the discrete prediction:
   ```python
   probabilities = model.predict_proba(mystery_scaled)[0]
   for sp, prob in zip(species_names, probabilities):
       print(f"  Confidence {sp:10}: {prob*100:.1f}%")
   ```
4. Save `main.py` and run it in your terminal: `python main.py`.
5. Verify the console output:
   - Features printed: Bill=39.0mm, Depth=18.0mm, Flipper=190.0mm, Mass=3700.0g.
   - Predicted Species: Adelie.
   - Adelie confidence: 100.0%.

## Expected Output or Observable Behaviour
When the mystery penguin inference code executes, the following block appears at the end of the console run:
```text
--- Mystery Penguin Prediction ---
Features: Bill=39.0mm, Depth=18.0mm, Flipper=190.0mm, Mass=3700.0g
Predicted Species: Adelie
```
If you added the probability reporting exercise, it expands to:
```text
--- Mystery Penguin Prediction ---
Features: Bill=39.0mm, Depth=18.0mm, Flipper=190.0mm, Mass=3700.0g
Predicted Species: Adelie
  Confidence Adelie    : 100.0%
  Confidence Chinstrap : 0.0%
  Confidence Gentoo    : 0.0%
```
Key observations:
- All 3 nearest neighbors are Adelie penguins, giving unambiguous 100% classification confidence.
- The morphological profile (short bill, moderate depth, short flipper, moderate mass) is quintessential Adelie anatomy.

## Practical Exercises
### Exercise 1: Classifying a Borderline Mystery Specimen
Create a second mystery specimen with morphological characteristics situated directly on the boundary between Adelie and Chinstrap:
```python
boundary_mystery = np.array([[44.0, 17.5, 192.0, 3650.0]])
boundary_scaled = scaler.transform(boundary_mystery)
pred_b = model.predict(boundary_scaled)
proba_b = model.predict_proba(boundary_scaled)[0]

print("
--- Borderline Specimen Prediction ---")
print(f"Predicted Species: {species_names[pred_b[0]]}")
for sp, p in zip(species_names, proba_b):
    print(f"  {sp:10}: {p*100:.1f}%")
```
Observe whether the nearest neighbors are unanimous or split between Adelie and Chinstrap.

### Exercise 2: Classifying a Large Gentoo Specimen
Define a mystery specimen with Gentoo dimensions:
```python
gentoo_mystery = np.array([[50.0, 15.0, 220.0, 5200.0]])
gentoo_scaled = scaler.transform(gentoo_mystery)
print(f"Predicted Gentoo Specimen: {species_names[model.predict(gentoo_scaled)[0]]}")
```
Verify that the model identifies it as Gentoo with 100% confidence.

## Common Mistakes and Debugging
- **Passing a 1D List or Array**: Calling `scaler.transform([39.0, 18.0, 190, 3700])` causes `ValueError: Expected 2D array, got 1D array instead. Reshape your data either using array.reshape(-1, 1) or array.reshape(1, -1)`. Always wrap single instances in double brackets `np.array([[...]])`.
- **Calling `fit_transform` on Inference Data**: Calling `scaler.fit_transform(mystery)` recalculates scaling parameters on the single query instance, zeroing out the features and causing invalid classifications. Always call `scaler.transform(mystery)`.
- **Feature Order Mismatch**: The input array must supply features in the exact column order used during training: `["bill_length_mm", "bill_depth_mm", "flipper_length_mm", "body_mass_g"]`. Swapping flipper length and bill length will result in nonsensical predictions.

## Best Practices and Security Considerations
- **Input Validation**: In production APIs, validate that incoming numeric values fall within biologically plausible ranges (e.g., $20 < \text{bill\_length} < 70$, $1000 < \text{body\_mass} < 10000$) before passing them to the model, rejecting corrupted or malicious payloads.
- **Reporting Uncertainty**: Never present deterministic predictions without confidence metrics when making high-stakes decisions. Always provide class probabilities via `predict_proba()`.
- **Pipeline Bundling**: In enterprise applications, bundle the fitted `StandardScaler` and `KNeighborsClassifier` together using `sklearn.pipeline.Pipeline` to guarantee that transformations cannot be inadvertently bypassed during deployment.

## Summary and Key Takeaways
- Real-time field inference applies a trained model to previously unseen query specimens.
- Query vectors must be standardized using the training set's mean and variance (`scaler.transform()`).
- The mystery penguin `[39.0, 18.0, 190, 3700]` is classified as an Adelie penguin with 100% neighbor consensus.
- Scikit-learn's `predict_proba()` calculates neighbor vote proportions, providing essential confidence quantification for field biologists.

## Knowledge-check Questions
1. Why does passing a 1D NumPy array of shape `(4,)` to `scaler.transform` cause an error in scikit-learn?
2. What would happen to the feature values if you erroneously called `scaler.fit_transform()` on a single mystery specimen?
3. If $k=5$ and a query vector has 3 Adelie neighbors and 2 Chinstrap neighbors, what probabilities does `model.predict_proba()` output?
4. In what order must the 4 morphological measurements be arranged when constructing the query vector?

## References
- Scikit-Learn Inference API Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.KNeighborsClassifier.html#sklearn.neighbors.KNeighborsClassifier.predict
- Gorman, K. B., Williams, T. D., & Fraser, W. R. (2014). Ecological Sexual Dimorphism and Environmental Variability within a Community of Antarctic Penguins (Genus Pygoscelis). *PLoS ONE*, 9(3), e90081.
- Goodfellow, I., Bengio, Y., & Courville, A. (2016). *Deep Learning*. MIT Press. Chapter 5: Machine Learning Basics.
