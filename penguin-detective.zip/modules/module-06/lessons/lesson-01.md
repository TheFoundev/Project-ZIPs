# Lesson 01: Executing the Complete Pipeline and Interpreting Console Telemetry

## Purpose and Learning Objectives
The primary objective of this lesson is to synthesize all preceding components into a unified, end-to-end machine learning pipeline. In real-world data science, models do not exist as isolated mathematical equations; they operate within sequential software pipelines that ingest raw tabular files, perform automated data transformations, fit estimators, output diagnostic metrics, export visualizations, and emit actionable real-time inferences. By executing `main.py` from top to bottom and tracing every phase of its terminal telemetry, students will master the structural flow of production-grade machine learning workflows.

By the end of this lesson, you will be able to:
- Trace the lifecycle of data from CSV ingestion through feature extraction, standardization, model fitting, and export.
- Execute the complete `main.py` script and interpret each section of its structured console output.
- Validate data integrity checkpoints (dataset shape, species distribution, train/test counts) via console telemetry.
- Connect intermediate pipeline logs directly to their underlying code blocks.
- Debug pipeline execution failures using informative console error messages.

## Prerequisites
Before starting this lesson, you should be familiar with:
- The data ingestion and exploratory data analysis established in Module 02.
- The feature-target separation and standardization pipeline from Module 03.
- The K-Nearest Neighbors classifier mechanics from Module 04.
- The multi-metric diagnostic evaluation from Module 05.

## Biological and Real-World Context
In scientific expeditions to remote regions such as Antarctica, field computational systems must be robust, transparent, and completely self-contained. Researchers operating at Palmer Station or aboard research vessels often deploy automated monitoring scripts on lightweight laptops or embedded edge devices.

When a field researcher runs a script, verbose and structured console telemetry provides immediate confirmation that data was loaded correctly, preprocessing transforms were fitted without bias, model accuracy meets rigorous scientific thresholds, and the target output artifacts were successfully committed to non-volatile storage. If an unexpected anomaly occurs—such as a corrupted sensor data row or a missing library dependency—well-structured pipeline telemetry allows researchers to pinpoint the failure point instantly without opening an interactive debugger in harsh field conditions.

## Concept Explanation
### Pipeline Architectural Flow
A production machine learning pipeline operates as a directed acyclic graph (DAG) of processing stages:
```
[Raw CSV File] 
       │
       ▼
[Data Ingestion & Integrity Check] ──> logs: Dataset shape, Species distribution
       │
       ▼
[Train/Test Stratified Split] ─────> logs: Training set size, Test set size
       │
       ▼
[StandardScaler Normalization] ───> transforms features into zero-mean, unit-variance
       │
       ▼
[Hyperparameter Evaluation Loop] ─> logs: k=3 Accuracy: 94.7%, k=5 Accuracy: 94.7%
       │
       ▼
[Optimal Model Selection & Fit] ──> fits production KNN (k=3)
       │
       ▼
[Diagnostic Reporting] ───────────> logs: Classification Report, Confusion Matrix
       │
       ▼
[Visualization Rendering] ────────> saves: penguin_scatter.png
       │
       ▼
[Real-Time Field Inference] ──────> logs: Mystery Penguin Prediction
```

### Structured Console Telemetry
Console telemetry is the real-time stream of text emitted by a program during execution. Effective telemetry follows three core principles:
1. **Section Headers**: Use clean visual delimiters (such as `--- Model Evaluation (KNN) ---` or `=== Palmer Penguins Classification ===`) to partition distinct logical pipeline stages.
2. **Quantitative Checkpoints**: Always print counts, percentages, and shapes (e.g., `Dataset: 150 penguins, 3 species`, `Training set: 112, Test set: 38`) to allow immediate visual auditing of data completeness.
3. **Artifact Confirmations**: Explicitly log the creation and storage path of external files (e.g., `Scatter plot saved as penguin_scatter.png`), confirming that disk write operations succeeded.

## Relevant Code (from main.py)
Below is the overarching structure of `main.py` executing the end-to-end sequence:

```python
# Palmer Penguins Classification with K-Nearest Neighbors (KNN)
# Dataset: Palmer Archipelago (Antarctica) penguin measurements
# Classes: Adelie, Chinstrap, Gentoo

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report, confusion_matrix

# 1. Load the dataset
df = pd.read_csv("data/penguins.csv")
print("=== Palmer Penguins Classification ===")
print(f"Dataset: {len(df)} penguins, {df['species'].nunique()} species")
print(f"Species: {', '.join(df['species'].unique())}")
print(f"
Feature Summary:")
print(df.describe().round(1))

# 2. Prepare features and target
features = ["bill_length_mm", "bill_depth_mm", "flipper_length_mm", "body_mass_g"]
X = df[features].values
species_names = ["Adelie", "Chinstrap", "Gentoo"]
species_map = {name: i for i, name in enumerate(species_names)}
y = df["species"].map(species_map).values

# 3. Train/test split (stratified)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)
print(f"
Training set: {len(X_train)}, Test set: {len(X_test)}")

# 4. Feature scaling
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# 5. Evaluate KNN model across multiple k values
print("
--- Model Evaluation (KNN) ---")
for k in [3, 5]:
    knn = KNeighborsClassifier(n_neighbors=k)
    knn.fit(X_train, y_train)
    acc = knn.score(X_test, y_test)
    print(f"k={k} Accuracy: {acc*100:.1f}%")

# 6. Train best model
best_k = 3
model = KNeighborsClassifier(n_neighbors=best_k)
model.fit(X_train, y_train)

# 7. Diagnostic Reporting
y_pred = model.predict(X_test)
print(f"
Classification Report (k={best_k}):")
print(classification_report(y_test, y_pred, target_names=species_names))

cm = confusion_matrix(y_test, y_pred)
print("Confusion Matrix:")
print(f"{'':12}" + "".join(f"{name:>12}" for name in species_names))
for i, row in enumerate(cm):
    print(f"{species_names[i]:12}" + "".join(f"{val:>12}" for val in row))

# 8. Visualization Export
plt.figure(figsize=(8, 5))
colors = {"Adelie": "#FF6B6B", "Chinstrap": "#4ECDC4", "Gentoo": "#45B7D1"}
for species in species_names:
    subset = df[df["species"] == species]
    plt.scatter(
        subset["bill_length_mm"],
        subset["flipper_length_mm"],
        label=species,
        color=colors[species],
        alpha=0.7,
    )
plt.xlabel("Bill Length (mm)")
plt.ylabel("Flipper Length (mm)")
plt.title("Palmer Penguins: Bill Length vs Flipper Length")
plt.legend()
plt.tight_layout()
plt.savefig("penguin_scatter.png")
print("
Scatter plot saved as penguin_scatter.png")

# 9. Real-Time Field Inference
mystery = np.array([[39.0, 18.0, 190, 3700]])
mystery_scaled = scaler.transform(mystery)
prediction = model.predict(mystery_scaled)
print(f"
--- Mystery Penguin Prediction ---")
print(f"Features: Bill={mystery[0][0]}mm, Depth={mystery[0][1]}mm, "
      f"Flipper={mystery[0][2]}mm, Mass={mystery[0][3]}g")
print(f"Predicted Species: {species_names[prediction[0]]}")
```

## Code Explanation
Let us examine how this unified script executes synchronously:
1. **Imports (Lines 8-13)**: Loads standard numerical, scientific, and visualization libraries. Because Python executes linearly, any missing package immediately triggers an `ImportError` before any computation occurs.
2. **Ingestion & Summary (Lines 16-21)**: Loads `data/penguins.csv`, computes row counts, isolates unique species names, and formats the five-number statistical summary table rounded to one decimal place.
3. **Pre-processing & Splitting (Lines 24-37)**: Extracts NumPy arrays, maps text labels to contiguous integers `0, 1, 2`, partitions the dataset into stratified 75/25 splits, and scales the feature matrices. Notice that `StandardScaler` calculates mean and variance strictly on `X_train` and applies those identical parameters to `X_test`.
4. **Hyperparameter Tuning & Training (Lines 40-51)**: Iterates over $k \in [3, 5]$, prints validation accuracy for each, establishes $k=3$ as the definitive hyperparameter, and fits the final production classifier instance `model`.
5. **Diagnostics (Lines 54-63)**: Evaluates the production model against the test set, printing the precision/recall table and formatted confusion matrix.
6. **Artifact Generation (Lines 66-86)**: Generates the bivariate scatter plot using raw millimeters for intuitive interpretation and writes `penguin_scatter.png` to disk.
7. **Field Inference (Lines 89-95)**: Standardizes a mystery field vector using the fitted scaler, evaluates its nearest neighbors, and outputs the predicted biological identity.

## Worked Example
Let us execute the entire script and analyze the resulting output step by step. When invoked in bash via `python main.py`, the terminal generates the following complete log:

```text
=== Palmer Penguins Classification ===
Dataset: 150 penguins, 3 species
Species: Adelie, Chinstrap, Gentoo

Feature Summary:
       bill_length_mm  bill_depth_mm  flipper_length_mm  body_mass_g
count           150.0          150.0              150.0        150.0
mean             44.8           17.3              200.5       4153.2
std               5.3            1.8               12.5        722.1
min              33.5           13.6              179.0       2959.0
25%              40.6           15.9              190.0       3550.0
50%              44.5           17.3              197.0       4050.0
75%              49.1           18.7              212.0       4750.0
max              57.4           21.0              232.0       6026.0

Training set: 112, Test set: 38

--- Model Evaluation (KNN) ---
k=3 Accuracy: 94.7%
k=5 Accuracy: 94.7%

Classification Report (k=3):
              precision    recall  f1-score   support

      Adelie       0.92      0.92      0.92        12
   Chinstrap       0.92      0.92      0.92        13
      Gentoo       1.00      1.00      1.00        13

    accuracy                           0.95        38
   macro avg       0.95      0.95      0.95        38
weighted avg       0.95      0.95      0.95        38

Confusion Matrix:
                  Adelie   Chinstrap      Gentoo
Adelie                11           1           0
Chinstrap              1          12           0
Gentoo                 0           0          13

Scatter plot saved as penguin_scatter.png

--- Mystery Penguin Prediction ---
Features: Bill=39.0mm, Depth=18.0mm, Flipper=190.0mm, Mass=3700.0g
Predicted Species: Adelie
```

Tracing the logical validation checkpoints:
- Total rows processed: $150$ ($112$ training + $38$ test = $150$).
- Target support sums: $12 + 13 + 13 = 38$ test specimens.
- Accuracy matches confusion matrix: $(11 + 12 + 13) / 38 = 36 / 38 = 94.7\%$.
- Export confirmed: `penguin_scatter.png` created.
- Field inference emitted: `Adelie`.

## Step-by-Step Student Instructions
1. Open your terminal and navigate to your `penguin-detective` repository.
2. Verify that your virtual environment is active: `source venv/bin/activate`.
3. Check that the dataset exists at `data/penguins.csv` or in the root directory.
4. Execute the pipeline: `python main.py`.
5. Follow the execution flow in your terminal:
   - Verify the initial greeting and feature summary table.
   - Confirm that the train/test split reports 112 training and 38 test samples.
   - Confirm that both $k=3$ and $k=5$ yield $94.7\%$.
   - Inspect the classification report and confusion matrix.
   - Confirm the confirmation message `Scatter plot saved as penguin_scatter.png`.
   - Confirm the mystery penguin prediction outputs `Adelie`.
6. Verify file generation: `ls -lh penguin_scatter.png`.

## Expected Output or Observable Behaviour
When `main.py` is executed:
- The entire process terminates cleanly in under 1 second with exit code 0.
- All 9 pipeline stages print their respective telemetry headers in clear chronological order.
- A PNG file titled `penguin_scatter.png` appears in the working directory.
- No warnings or deprecation notices are emitted when running modern scikit-learn and pandas versions.

## Practical Exercises
### Exercise 1: Pipeline Execution Profiling
Add execution timing telemetry to monitor elapsed time across stages using Python's `time` standard library:
```python
import time

start_time = time.perf_counter()
# ... [pipeline steps] ...
end_time = time.perf_counter()
print(f"
Pipeline finished in {(end_time - start_time)*1000:.2f} milliseconds.")
```
Record the total runtime. Notice that over 90% of the elapsed runtime is spent on Matplotlib rendering and file I/O rather than algorithmic model training.

### Exercise 2: Adding a Verbose Flag
Wrap detailed diagnostics in a command-line argument or boolean flag `VERBOSE = True`:
- If `VERBOSE = True`, print the full statistical summary and confusion matrix.
- If `VERBOSE = False`, print only the final prediction and test accuracy, creating a lightweight execution mode suitable for automated batch processing.

## Common Mistakes and Debugging
- **Executing from the Wrong Working Directory**: Running `python projects/13_penguin_detective/main.py` while inside the repository root can trigger `FileNotFoundError: [Errno 2] No such file or directory: 'data/penguins.csv'`. Always ensure your working directory matches the relative path used by `pd.read_csv`.
- **Display Backend Errors on Headless Servers**: On headless cloud instances without GUI subsystems, Matplotlib may fail if configured to use an interactive backend. To prevent this, add `import matplotlib; matplotlib.use('Agg')` before importing `pyplot`.
- **Unsaved Modifications**: Editing code in your editor but forgetting to save before running `python main.py` leads to confusion when terminal output does not reflect your changes.

## Best Practices and Security Considerations
- **Exit Codes**: In production pipelines, return non-zero exit codes (`sys.exit(1)`) if input data fails validation checks (e.g., unexpected missing columns or zero rows).
- **Structured Logging vs. Print**: While `print()` is suitable for educational scripts, enterprise ML workflows utilize Python's `logging` module to direct timestamped logs to centralized monitoring infrastructure (such as CloudWatch, Datadog, or Grafana).
- **Idempotency**: Ensure running the pipeline multiple times produces identical, deterministic results without appending duplicate records or leaving unclosed file handles.

## Summary and Key Takeaways
- An end-to-end ML pipeline coordinates data ingestion, exploratory summaries, stratified splitting, scaling, hyperparameter tuning, model training, evaluation, visualization, and inference.
- Structured console telemetry provides an auditable, real-time window into pipeline execution.
- Executing `main.py` validates the entire mathematical and architectural workflow developed across Modules 01 through 05.
- KNN training and prediction execute virtually instantaneously on small-to-medium biological datasets, with the majority of runtime allocated to plotting and I/O.

## Knowledge-check Questions
1. Why is it beneficial to log data shapes (e.g., `len(X_train)`, `len(X_test)`) immediately after executing `train_test_split`?
2. Which stage of the `main.py` script consumes the highest proportion of total execution time?
3. What is the operational risk of running a data science pipeline without explicit console or file telemetry?
4. How does the concept of idempotency apply to the execution of `main.py`?

## References
- Fowler, M. (2018). *Refactoring: Improving the Design of Existing Code* (2nd ed.). Addison-Wesley Professional.
- Breck, E., et al. (2017). What's your ML Test Score? A rubric for ML production systems. *NIPS Workshop on Reliable Machine Learning in the Wild*.
- Scikit-Learn Pipeline Architecture: https://scikit-learn.org/stable/modules/compose.html
