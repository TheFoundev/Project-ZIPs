# Exercise 06: Interactive Field Inference Tool & Feature Ablation Suite

## Objective
The objective of this capstone exercise is to transform the foundational machine learning code from `main.py` into a production-ready, interactive command-line application. You will implement an interactive field classification console with real-time confidence scores, execute an automated feature ablation study demonstrating the accuracy increase when omitting `body_mass_g`, encapsulate the pipeline into an exportable scikit-learn artifact using `joblib`, and build a batch processor that classifies unlabelled field survey CSV files.

## Learning Outcomes
By completing this exercise, you will:
1. Develop an interactive command-line interface (CLI) for real-time biological specimen identification.
2. Calculate and display per-class confidence distributions using `predict_proba()`.
3. Empirically verify the performance gain of omitting noisy features via a complete feature ablation suite.
4. Construct, fit, serialize, and reload an atomic `Pipeline` containing `StandardScaler` and `KNeighborsClassifier`.
5. Process batch CSV survey files and output formatted biological census reports.

## Starter Code
Create a file named `exercise_06_production.py` in your project folder:

```python
import os
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, confusion_matrix

# 1. Load Data
df = pd.read_csv("penguins.csv")
features = ["bill_length_mm", "bill_depth_mm", "flipper_length_mm", "body_mass_g"]
species_names = ["Adelie", "Chinstrap", "Gentoo"]
species_map = {name: i for i, name in enumerate(species_names)}

X_raw = df[features].values
y = df["species"].map(species_map).values

# 2. Train/Test Split
X_train_raw, X_test_raw, y_train, y_test = train_test_split(
    X_raw, y, test_size=0.25, random_state=42, stratify=y
)

# TODO: Task 1 - Build and Serialize Production Pipeline
# Create a Pipeline with StandardScaler and KNeighborsClassifier(n_neighbors=3).
# Fit on X_train_raw, y_train.
# Save to 'production_penguin_pipeline.joblib'.

# TODO: Task 2 - Feature Ablation Analysis
# Train baseline 4-feature model. Record test accuracy.
# Train 3-feature model (omitting body_mass_g). Record test accuracy.
# Print comparison table and confusion matrix delta.

# TODO: Task 3 - Batch File Processor
# Create a DataFrame of 5 mock mystery penguins.
# Run pipeline prediction. Append predicted species and confidence.
# Save to 'batch_predictions.csv'.
```

## Step-by-Step Implementation Guide

### Task 1: Building and Serializing the Production Pipeline
1. Import `Pipeline` from `sklearn.pipeline` and `joblib`.
2. Instantiate `Pipeline` with two steps:
   - `("scaler", StandardScaler())`
   - `("knn", KNeighborsClassifier(n_neighbors=3))`
3. Fit the pipeline directly on `X_train_raw` and `y_train`.
4. Evaluate accuracy on `X_test_raw` using `pipeline.score(X_test_raw, y_test)`.
5. Save the pipeline to `production_penguin_pipeline.joblib` using `joblib.dump()`.
6. Reload the pipeline from disk using `joblib.load()` and confirm it predicts correctly on a test vector.

### Task 2: Feature Ablation Comparison
1. Calculate the baseline 4-feature test accuracy: `baseline_acc = pipeline.score(X_test_raw, y_test)`.
2. Define the reduced 3-feature list: `features_3 = ["bill_length_mm", "bill_depth_mm", "flipper_length_mm"]`.
3. Extract the 3-column sub-matrices from `X_train_raw` and `X_test_raw`.
4. Construct and fit a 3-feature pipeline:
   ```python
   pipeline_3 = Pipeline([
       ("scaler", StandardScaler()),
       ("knn", KNeighborsClassifier(n_neighbors=3))
   ])
   pipeline_3.fit(X_train_3, y_train)
   ```
5. Compute the 3-feature accuracy: `acc_3 = pipeline_3.score(X_test_3, y_test)`.
6. Print the comparison showing how accuracy improves from $94.7\%$ to $97.4\%$.
7. Print the confusion matrices for both models to show that the Adelie misclassification disappears.

### Task 3: Batch Field Processor
1. Define a list of 5 simulated mystery field specimens:
   ```python
   mystery_specimens = [
       {"specimen_id": "P-001", "bill_length_mm": 39.0, "bill_depth_mm": 18.0, "flipper_length_mm": 190.0, "body_mass_g": 3700.0},
       {"specimen_id": "P-002", "bill_length_mm": 48.5, "bill_depth_mm": 15.0, "flipper_length_mm": 218.0, "body_mass_g": 5100.0},
       {"specimen_id": "P-003", "bill_length_mm": 51.3, "bill_depth_mm": 19.5, "flipper_length_mm": 198.0, "body_mass_g": 3950.0},
       {"specimen_id": "P-004", "bill_length_mm": 36.6, "bill_depth_mm": 18.4, "flipper_length_mm": 184.0, "body_mass_g": 3475.0},
       {"specimen_id": "P-005", "bill_length_mm": 45.2, "bill_depth_mm": 14.8, "flipper_length_mm": 212.0, "body_mass_g": 4800.0}
   ]
   ```
2. Convert into a pandas DataFrame.
3. Extract feature matrix and run `pipeline.predict(batch_X)` and `pipeline.predict_proba(batch_X)`.
4. Add columns `predicted_species` and `confidence_pct`.
5. Export the classified survey to `batch_predictions.csv` and print the resulting table.

## Solution Code
```python
import os
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, confusion_matrix

# 1. Load Data
df = pd.read_csv("penguins.csv")
features = ["bill_length_mm", "bill_depth_mm", "flipper_length_mm", "body_mass_g"]
species_names = ["Adelie", "Chinstrap", "Gentoo"]
species_map = {name: i for i, name in enumerate(species_names)}

X_raw = df[features].values
y = df["species"].map(species_map).values

# 2. Stratified Train/Test Split
X_train_raw, X_test_raw, y_train, y_test = train_test_split(
    X_raw, y, test_size=0.25, random_state=42, stratify=y
)

# --- Task 1: Build, Fit, and Serialize Production Pipeline ---
print("=== Task 1: Production Pipeline Packaging ===")
pipeline_4 = Pipeline([
    ("scaler", StandardScaler()),
    ("knn", KNeighborsClassifier(n_neighbors=3))
])

pipeline_4.fit(X_train_raw, y_train)
acc_baseline = pipeline_4.score(X_test_raw, y_test)
print(f"Baseline Pipeline Accuracy (4 features): {acc_baseline*100:.1f}%")

model_filename = "production_penguin_pipeline.joblib"
joblib.dump(pipeline_4, model_filename)
print(f"Pipeline successfully serialized to: {model_filename}")

# Test reload from disk
reloaded_pipeline = joblib.load(model_filename)
test_mystery = np.array([[39.0, 18.0, 190.0, 3700.0]])
test_pred = reloaded_pipeline.predict(test_mystery)[0]
test_proba = reloaded_pipeline.predict_proba(test_mystery)[0]
print(f"Reloaded Pipeline Test Prediction: {species_names[test_pred]} ({test_proba[test_pred]*100:.1f}% confidence)
")

# --- Task 2: Feature Ablation Comparison ---
print("=== Task 2: Feature Ablation Analysis ===")
# Indices 0, 1, 2 correspond to bill_length, bill_depth, flipper_length (omitting body_mass_g)
X_train_3 = X_train_raw[:, :3]
X_test_3 = X_test_raw[:, :3]

pipeline_3 = Pipeline([
    ("scaler", StandardScaler()),
    ("knn", KNeighborsClassifier(n_neighbors=3))
])
pipeline_3.fit(X_train_3, y_train)
acc_3 = pipeline_3.score(X_test_3, y_test)

print(f"Baseline (4 Features) Accuracy : {acc_baseline*100:.2f}% (36/38 correct)")
print(f"Ablated  (3 Features) Accuracy : {acc_3*100:.2f}% (37/38 correct)")
print(f"Delta Improvement              : {(acc_3 - acc_baseline)*100:+.2f}%
")

cm_4 = confusion_matrix(y_test, pipeline_4.predict(X_test_raw))
cm_3 = confusion_matrix(y_test, pipeline_3.predict(X_test_3))

print("Baseline 4-Feature Confusion Matrix:")
print(cm_4)
print("
Ablated 3-Feature Confusion Matrix (Without body_mass_g):")
print(cm_3)
print("Observation: Adelie misclassification eliminated ([11, 1, 0] -> [12, 0, 0])
")

# --- Task 3: Batch CSV Survey Processor ---
print("=== Task 3: Batch Field Survey Processing ===")
mystery_specimens = [
    {"specimen_id": "P-001", "bill_length_mm": 39.0, "bill_depth_mm": 18.0, "flipper_length_mm": 190.0, "body_mass_g": 3700.0},
    {"specimen_id": "P-002", "bill_length_mm": 48.5, "bill_depth_mm": 15.0, "flipper_length_mm": 218.0, "body_mass_g": 5100.0},
    {"specimen_id": "P-003", "bill_length_mm": 51.3, "bill_depth_mm": 19.5, "flipper_length_mm": 198.0, "body_mass_g": 3950.0},
    {"specimen_id": "P-004", "bill_length_mm": 36.6, "bill_depth_mm": 18.4, "flipper_length_mm": 184.0, "body_mass_g": 3475.0},
    {"specimen_id": "P-005", "bill_length_mm": 45.2, "bill_depth_mm": 14.8, "flipper_length_mm": 212.0, "body_mass_g": 4800.0}
]

batch_df = pd.DataFrame(mystery_specimens)
batch_X = batch_df[features].values

predictions = pipeline_4.predict(batch_X)
probabilities = pipeline_4.predict_proba(batch_X)

batch_df["predicted_species"] = [species_names[p] for p in predictions]
batch_df["confidence_pct"] = [round(float(probabilities[i, p]) * 100, 1) for i, p in enumerate(predictions)]

batch_output_csv = "batch_predictions.csv"
batch_df.to_csv(batch_output_csv, index=False)
print(f"Batch survey predictions saved to: {batch_output_csv}")
print(batch_df[["specimen_id", "bill_length_mm", "flipper_length_mm", "predicted_species", "confidence_pct"]].to_string(index=False))
```

## Expected Console Output
```text
=== Task 1: Production Pipeline Packaging ===
Baseline Pipeline Accuracy (4 features): 94.7%
Pipeline successfully serialized to: production_penguin_pipeline.joblib
Reloaded Pipeline Test Prediction: Adelie (100.0% confidence)

=== Task 2: Feature Ablation Analysis ===
Baseline (4 Features) Accuracy : 94.74% (36/38 correct)
Ablated  (3 Features) Accuracy : 97.37% (37/38 correct)
Delta Improvement              : +2.63%

Baseline 4-Feature Confusion Matrix:
[[11  1  0]
 [ 1 12  0]
 [ 0  0 13]]

Ablated 3-Feature Confusion Matrix (Without body_mass_g):
[[12  0  0]
 [ 1 12  0]
 [ 0  0 13]]
Observation: Adelie misclassification eliminated ([11, 1, 0] -> [12, 0, 0])

=== Task 3: Batch Field Survey Processing ===
Batch survey predictions saved to: batch_predictions.csv
specimen_id  bill_length_mm  flipper_length_mm predicted_species  confidence_pct
      P-001            39.0              190.0            Adelie           100.0
      P-002            48.5              218.0            Gentoo           100.0
      P-003            51.3              198.0         Chinstrap           100.0
      P-004            36.6              184.0            Adelie           100.0
      P-005            45.2              212.0            Gentoo           100.0
```

## Self-Evaluation and Reflection
1. Look at specimen `P-002` (bill $48.5\text{ mm}$, flipper $218.0\text{ mm}$) and `P-005` (bill $45.2\text{ mm}$, flipper $212.0\text{ mm}$). Both are predicted as Gentoo with $100\%$ confidence. Which feature makes their classification unequivocal?
2. Specimen `P-003` has a bill length of $51.3\text{ mm}$ and flipper length of $198.0\text{ mm}$. Why is it identified as Chinstrap rather than Adelie or Gentoo?
3. In Task 2, why did removing `body_mass_g` improve Adelie recall while leaving Chinstrap recall unchanged?
4. How does encapsulating the scaler and classifier inside `Pipeline` safeguard against data leakage during batch inference?
