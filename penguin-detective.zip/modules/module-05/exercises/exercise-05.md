# Exercise 05: Comprehensive Model Evaluation & Visualization Suite

## Objective
The objective of this hands-on exercise is to expand upon the diagnostic evaluation framework developed in Module 05. You will implement an automated hyperparameter validation curve across an extended range of $k$ values, extract and inspect the exact individual specimens misclassified by the $k=3$ model, construct a multi-panel bivariate visualization dashboard, and assess model stability under simulated measurement noise.

## Learning Outcomes
By completing this exercise, you will:
1. Construct and plot a hyperparameter validation curve comparing training accuracy vs. test accuracy across $k \in [1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21]$.
2. Isolate and print the exact misclassified penguin specimens from the 38-specimen test set with their raw physiological measurements.
3. Build a side-by-side 2-panel scatter visualization comparing (a) Bill Length vs. Flipper Length and (b) Bill Depth vs. Body Mass.
4. Synthesize diagnostic findings into an actionable ecological assessment report.

## Starter Code
Create a file named `exercise_05_eval.py` in your project directory:

```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report, confusion_matrix

# 1. Load Data
df = pd.read_csv("penguins.csv")
features = ["bill_length_mm", "bill_depth_mm", "flipper_length_mm", "body_mass_g"]
species_names = ["Adelie", "Chinstrap", "Gentoo"]
species_map = {name: i for i, name in enumerate(species_names)}

X_raw = df[features].values
y = df["species"].map(species_map).values

# 2. Stratified Train/Test Split
X_train_raw, X_test_raw, y_train, y_test = train_test_split(
    X_raw, y, test_size=0.25, random_state=42, stratify=y
)

# 3. Standardization
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train_raw)
X_test = scaler.transform(X_test_raw)

# TODO: Task 1 - Hyperparameter Validation Curve
# Evaluate k in range(1, 23, 2). Track train_acc and test_acc.
# Save plot to 'validation_curve.png'.

# TODO: Task 2 - Identify Misclassified Specimens
# Train model with k=3. Predict on X_test.
# Find indices where y_pred != y_test.
# Print the raw measurements and true vs predicted labels for these specimens.

# TODO: Task 3 - Dual-Panel Bivariate Visualization
# Create a figure with 2 subplots (1 row, 2 cols).
# Panel 1: Bill Length vs Flipper Length.
# Panel 2: Bill Depth vs Body Mass.
# Save figure to 'morphology_dashboard.png'.
```

## Step-by-Step Implementation Guide

### Task 1: Hyperparameter Validation Curve
1. Define a list of candidate $k$ values: `k_values = list(range(1, 23, 2))`.
2. Initialize two empty lists: `train_accuracies = []` and `test_accuracies = []`.
3. Loop through `k_values`, fitting a `KNeighborsClassifier(n_neighbors=k)` on `X_train`.
4. Append `knn.score(X_train, y_train)` to `train_accuracies` and `knn.score(X_test, y_test)` to `test_accuracies`.
5. Plot both curves against `k_values` using `plt.plot()`.
6. Add labels, title, grid, legend, and export to `validation_curve.png`.

### Task 2: Granular Misclassification Extraction
1. Instantiate `KNeighborsClassifier(n_neighbors=3)` and fit on `X_train`.
2. Compute `y_pred = knn.predict(X_test)`.
3. Locate error indices using boolean masking: `error_indices = np.where(y_pred != y_test)[0]`.
4. For each index in `error_indices`:
   - Retrieve the true species name: `species_names[y_test[idx]]`.
   - Retrieve the predicted species name: `species_names[y_pred[idx]]`.
   - Retrieve the original unscaled feature values from `X_test_raw[idx]`.
   - Print a formatted summary detailing why this specimen sits near the morphological boundary.

### Task 3: Dual-Panel Bivariate Dashboard
1. Initialize a figure canvas with dimensions `figsize=(14, 5)`.
2. Create two subplots side-by-side using `plt.subplot(1, 2, 1)` and `plt.subplot(1, 2, 2)`.
3. In Subplot 1, plot `bill_length_mm` vs. `flipper_length_mm` colored by species.
4. In Subplot 2, plot `bill_depth_mm` vs. `body_mass_g` colored by species.
5. In Subplot 2, note how Adelie and Chinstrap overlap heavily in both bill depth and body mass, illustrating why bill length is essential for discriminating between them.
6. Save the dashboard to `morphology_dashboard.png`.

## Solution Code
```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report, confusion_matrix

# 1. Load Data
df = pd.read_csv("penguins.csv")
features = ["bill_length_mm", "bill_depth_mm", "flipper_length_mm", "body_mass_g"]
species_names = ["Adelie", "Chinstrap", "Gentoo"]
species_map = {name: i for i, name in enumerate(species_names)}

X_raw = df[features].values
y = df["species"].map(species_map).values

# 2. Stratified Train/Test Split
X_train_raw, X_test_raw, y_train, y_test = train_test_split(
    X_raw, y, test_size=0.25, random_state=42, stratify=y
)

# 3. Standardization
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train_raw)
X_test = scaler.transform(X_test_raw)

# Task 1: Validation Curve
k_values = list(range(1, 23, 2))
train_scores = []
test_scores = []

for k in k_values:
    clf = KNeighborsClassifier(n_neighbors=k)
    clf.fit(X_train, y_train)
    train_scores.append(clf.score(X_train, y_train))
    test_scores.append(clf.score(X_test, y_test))

plt.figure(figsize=(8, 5))
plt.plot(k_values, train_scores, marker='o', label='Training Accuracy', color='#FF6B6B')
plt.plot(k_values, test_scores, marker='s', label='Test Accuracy', color='#4ECDC4')
plt.xlabel("k (Number of Neighbors)")
plt.ylabel("Accuracy")
plt.title("KNN Validation Curve: Bias-Variance Tradeoff")
plt.xticks(k_values)
plt.grid(True, linestyle='--', alpha=0.6)
plt.legend()
plt.tight_layout()
plt.savefig("validation_curve.png")
plt.close()
print("Saved validation_curve.png")

# Task 2: Granular Misclassifications
best_k = 3
model = KNeighborsClassifier(n_neighbors=best_k)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

error_mask = (y_pred != y_test)
error_indices = np.where(error_mask)[0]

print(f"
--- Misclassified Specimens (k={best_k}) ---")
print(f"Total Test Specimens: {len(y_test)}")
print(f"Total Misclassified: {len(error_indices)}
")

for rank, idx in enumerate(error_indices, 1):
    true_label = species_names[y_test[idx]]
    pred_label = species_names[y_pred[idx]]
    meas = dict(zip(features, X_test_raw[idx]))
    print(f"Error #{rank}:")
    print(f"  True Species     : {true_label}")
    print(f"  Predicted Species: {pred_label}")
    print(f"  Measurements     :")
    for feat, val in meas.items():
        print(f"    - {feat:18}: {val}")
    print()

# Task 3: Dual-Panel Morphology Dashboard
colors = {"Adelie": "#FF6B6B", "Chinstrap": "#4ECDC4", "Gentoo": "#45B7D1"}
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

for sp in species_names:
    sub = df[df["species"] == sp]
    ax1.scatter(sub["bill_length_mm"], sub["flipper_length_mm"], label=sp, color=colors[sp], alpha=0.7)
    ax2.scatter(sub["bill_depth_mm"], sub["body_mass_g"], label=sp, color=colors[sp], alpha=0.7)

ax1.set_xlabel("Bill Length (mm)")
ax1.set_ylabel("Flipper Length (mm)")
ax1.set_title("Morphology: Bill Length vs Flipper Length")
ax1.legend()
ax1.grid(True, linestyle=":", alpha=0.5)

ax2.set_xlabel("Bill Depth (mm)")
ax2.set_ylabel("Body Mass (g)")
ax2.set_title("Morphology: Bill Depth vs Body Mass")
ax2.legend()
ax2.grid(True, linestyle=":", alpha=0.5)

plt.tight_layout()
plt.savefig("morphology_dashboard.png")
plt.close()
print("Saved morphology_dashboard.png")
```

## Expected Console Output
```text
Saved validation_curve.png

--- Misclassified Specimens (k=3) ---
Total Test Specimens: 38
Total Misclassified: 2

Error #1:
  True Species     : Adelie
  Predicted Species: Chinstrap
  Measurements     :
    - bill_length_mm    : 44.1
    - bill_depth_mm     : 18.0
    - flipper_length_mm : 210.0
    - body_mass_g       : 4000.0

Error #2:
  True Species     : Chinstrap
  Predicted Species: Adelie
  Measurements     :
    - bill_length_mm    : 40.9
    - bill_depth_mm     : 16.6
    - flipper_length_mm : 187.0
    - body_mass_g       : 3200.0

Saved morphology_dashboard.png
```

## Self-Evaluation and Reflection
1. Look at Error #1 (True Adelie predicted as Chinstrap). Its bill length is $44.1\text{ mm}$ (substantially above the Adelie average of $38.8\text{ mm}$) and its flipper length is $210.0\text{ mm}$ (well above typical Adelie flippers). Why did the classifier mistake it for a Chinstrap?
2. Look at Error #2 (True Chinstrap predicted as Adelie). Its bill length is $40.9\text{ mm}$ (well below the Chinstrap average of $48.8\text{ mm}$). How does this biological outlier demonstrate the limitations of purely morphometric classification without genetic markers?
3. Inspect `validation_curve.png`. At what value of $k$ does test accuracy begin to noticeably drop? Why does training accuracy start at $100\%$ for $k=1$ and steadily decline?
