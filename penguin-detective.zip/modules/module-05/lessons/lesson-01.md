# Lesson 01: Evaluating Multi-Class KNN with Accuracy Across Multiple k Values

## Purpose and Learning Objectives
The primary objective of this lesson is to examine how to systematically evaluate a multi-class K-Nearest Neighbors classifier across different hyperparameter values. Hyperparameter selection directly governs the bias-variance tradeoff in non-parametric models. By comparing $k=3$ and $k=5$ on the 38-specimen held-out Palmer Archipelago test set, students will master the calculation and interpretation of overall classification accuracy, understand why identical accuracy figures can emerge from distinct underlying neighbor neighborhoods, and learn how to select an optimal model configuration for production deployment.

By the end of this lesson, you will be able to:
- Define multi-class classification accuracy mathematically and programmatically using scikit-learn.
- Explain the role of the neighborhood size hyperparameter $k$ in balancing model bias and variance.
- Execute an iterative evaluation loop evaluating $k \in [3, 5]$ against stratified test data.
- Analyze why both $k=3$ and $k=5$ achieve $94.7\%$ test accuracy ($36/38$ correct) in the Palmer Penguins dataset.
- Implement automated model selection logic to identify the best hyperparameter configuration.

## Prerequisites
Before starting this lesson, you should be familiar with:
- The Palmer Penguins dataset features and target labels (`species`) established in Module 01 and Module 02.
- Feature standardization using `StandardScaler` from Module 03.
- The core mechanics of Euclidean distance, majority voting, and tie-breaking from Module 04.
- Basic Python loops and formatting strings (`f"{acc*100:.1f}%"`).

## Biological and Real-World Context
In field ornithology and ecological conservation, predictive models are used to monitor penguin population dynamics without requiring invasive genetic assays. However, deploying a model requires rigorous empirical validation. If field researchers deploy a model that performs poorly on unseen specimens, entire sub-populations might be miscounted, skewing habitat protection policies.

When evaluating models on wild biological populations, researchers must account for natural morphological variance within and between species. Hyperparameter $k$ dictates how many neighboring specimens in 4-dimensional morphospace vote on an unknown bird's species. Setting $k$ too low ($k=1$) risks memorizing anomalous individuals (e.g., an unusually stunted Gentoo or a malnourished Adelie), leading to overfitting. Setting $k$ too high risks diluting rare species or blurring distinct cluster boundaries, leading to underfitting. Evaluating candidate values on an independent validation set ensures the chosen classifier generalizes faithfully to newly encountered wild specimens.

## Concept Explanation
### Multi-Class Classification Accuracy
Classification accuracy is the ratio of correctly predicted instances to the total number of evaluated instances:

$$\text{Accuracy} = \frac{\sum_{i=1}^{N} \mathbb{I}(\hat{y}_i = y_i)}{N} = \frac{\text{Number of Correct Predictions}}{\text{Total Number of Test Specimens}}$$

Where:
- $N$ is the total count of test samples (in our held-out test split, $N = 38$).
- $y_i$ is the true ground-truth biological species label for sample $i$.
- $\hat{y}_i$ is the predicted species label emitted by the KNN model.
- $\mathbb{I}(\cdot)$ is the indicator function, returning $1$ when the condition is met and $0$ otherwise.

In scikit-learn, calling `knn.score(X_test, y_test)` internally executes `knn.predict(X_test)` and computes `accuracy_score(y_test, y_pred)`.

### The Hyperparameter $k$ and the Bias-Variance Tradeoff
The parameter $k$ represents the number of nearest neighbors included in the consensus voting pool:
1. **Low $k$ ($k=1, 3$): Low Bias, High Variance**:
   - The decision boundary wraps tightly around individual training data points.
   - Highly sensitive to local variations, noise, and measurement errors in bill or flipper dimensions.
   - Captures fine, intricate decision boundaries between overlapping species clusters.
2. **High $k$ ($k=5, 15, 31$): High Bias, Low Variance**:
   - The decision boundary becomes smoother and more generalized across the feature space.
   - Resistant to individual noisy outliers or mislabeled specimens.
   - Can overpower minority or tightly clustered classes if the neighborhood spans across natural cluster boundaries.

### Why Odd Values of $k$?
In binary classification, odd values of $k$ ($3, 5, 7$) prevent binary 50/50 ties. In our 3-class problem (Adelie, Chinstrap, Gentoo), a 3-way tie (1-1-1) could theoretically occur if $k=3$, or a 2-way tie (2-2-1) if $k=5$. Scikit-learn breaks multi-class voting ties by selecting the class with the smallest sum of neighbor distances or the first encountered class in alphabetical order. Keeping $k$ relatively small and odd minimizes ambiguous voting scenarios while maintaining adequate statistical support for each prediction.

## Relevant Code (from main.py)
```python
# Evaluate KNN model
print("
--- Model Evaluation (KNN) ---")
for k in [3, 5]:
    knn = KNeighborsClassifier(n_neighbors=k)
    knn.fit(X_train, y_train)
    acc = knn.score(X_test, y_test)
    print(f"k={k} Accuracy: {acc*100:.1f}%")

# Train best model
best_k = 3
model = KNeighborsClassifier(n_neighbors=best_k)
model.fit(X_train, y_train)
```

## Code Explanation
Let us inspect each component of this evaluation sequence:
1. `for k in [3, 5]:`: An iterative loop testing discrete candidate values for the neighborhood size. In real-world data pipelines, this can be expanded into a systematic grid search (e.g., `range(1, 21, 2)`).
2. `knn = KNeighborsClassifier(n_neighbors=k)`: Instantiates a fresh `KNeighborsClassifier` instance configured with the current candidate neighborhood size. Notice that default distance metrics (Euclidean, $p=2$) and uniform neighbor weighting are inherited.
3. `knn.fit(X_train, y_train)`: Fits the model by storing the standardized 112 training feature vectors and their corresponding integer class labels (`0: Adelie, 1: Chinstrap, 2: Gentoo`).
4. `acc = knn.score(X_test, y_test)`: Feeds the 38 standardized test specimens into the classifier, generates predictions, compares them against ground-truth test labels, and returns the proportion of correct classifications as a floating-point scalar between $0.0$ and $1.0$.
5. `print(f"k={k} Accuracy: {acc*100:.1f}%")`: Formats the scalar proportion into a readable percentage rounded to one decimal place.
6. `best_k = 3`: Finalizes the chosen operational hyperparameter. Although both $k=3$ and $k=5$ yield $94.7\%$, $k=3$ provides sharper resolution between the closely related Adelie and Chinstrap clusters without suffering from boundary oversmoothing.
7. `model = KNeighborsClassifier(n_neighbors=best_k)` and `model.fit(X_train, y_train)`: Instantiates and trains the definitive model artifact used for subsequent diagnostic reporting and field inference.

## Worked Example
Let us compute the exact number of correct and incorrect specimens evaluated during this test run:
- Test set size: $N = 38$ specimens.
- Observed test accuracy: $94.7\%$.
- Number of correct predictions:
  $$\text{Correct} = 38 \times 0.947368... = 36$$
- Number of errors:
  $$\text{Errors} = 38 - 36 = 2$$

Both the $k=3$ and $k=5$ models correctly identify 36 out of 38 penguins, misidentifying exactly 2 specimens. In Lesson 03, we will investigate the confusion matrix to see precisely which species these 2 errors belong to.

Here is a complete standalone Python script demonstrating how to calculate and verify this programmatically:
```python
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier

# Load and prepare data
df = pd.read_csv("penguins.csv")
features = ["bill_length_mm", "bill_depth_mm", "flipper_length_mm", "body_mass_g"]
X = df[features].values
species_map = {"Adelie": 0, "Chinstrap": 1, "Gentoo": 2}
y = df["species"].map(species_map).values

# Stratified split and scaling
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Compare k values
for k in [1, 3, 5, 7, 9]:
    clf = KNeighborsClassifier(n_neighbors=k)
    clf.fit(X_train_scaled, y_train)
    accuracy = clf.score(X_test_scaled, y_test)
    correct_count = int(round(accuracy * len(y_test)))
    print(f"k={k:2d} -> Accuracy: {accuracy*100:.2f}% ({correct_count}/{len(y_test)} correct)")
```

## Step-by-Step Student Instructions
1. Open your terminal and activate your virtual environment: `source venv/bin/activate`.
2. Open `main.py` and locate the evaluation section starting with `# Evaluate KNN model`.
3. Add a temporary print statement inside the evaluation loop to display the raw count of correct classifications alongside the percentage:
   ```python
   correct = int(round(acc * len(y_test)))
   print(f"k={k} Accuracy: {acc*100:.1f}% ({correct}/{len(y_test)} correct)")
   ```
4. Run `python main.py` and inspect the terminal output.
5. Notice that both `k=3` and `k=5` yield identical accuracy ($94.7\%$), representing 36 correct and 2 incorrect classifications out of 38 test specimens.
6. Verify that `best_k = 3` successfully instantiates the production classifier.

## Expected Output or Observable Behaviour
When executing the evaluation block in `main.py`, the following output appears in your terminal:
```text
--- Model Evaluation (KNN) ---
k=3 Accuracy: 94.7%
k=5 Accuracy: 94.7%
```
Key observations:
- Both $k=3$ and $k=5$ achieve $94.7\%$ accuracy.
- Exactly 2 out of 38 test specimens are misclassified by both models.
- The computation executes instantaneously because training KNN consists merely of indexing the 112 reference points in memory, and querying 38 test vectors takes less than 5 milliseconds.

## Practical Exercises
### Exercise 1: Expanding the Hyperparameter Sweep
Modify the loop in `main.py` to evaluate all odd values of $k$ from 1 to 15:
```python
k_values = range(1, 16, 2)
for k in k_values:
    knn = KNeighborsClassifier(n_neighbors=k)
    knn.fit(X_train, y_train)
    acc = knn.score(X_test, y_test)
    print(f"k={k:2d}: {acc*100:.1f}%")
```
Observe how accuracy changes as $k$ increases. At what point does accuracy begin to degrade due to over-smoothing?

### Exercise 2: Comparing Unscaled vs Scaled Accuracy Across $k$
Evaluate $k=3$ and $k=5$ using unscaled raw features (`X_train` and `X_test` without `StandardScaler`). Record the accuracy drop caused by `body_mass_g` dominating distance metrics.

## Common Mistakes and Debugging
- **Evaluating on Training Data**: A common pitfall is calling `knn.score(X_train, y_train)` instead of `knn.score(X_test, y_test)`. For $k=1$, training accuracy is always $100\%$ because each sample is its own nearest neighbor, giving an illusory impression of perfection.
- **Data Leakage in Scaling**: Passing the entire dataset `scaler.fit(X)` before splitting leaks test distribution parameters into the evaluation, artificially inflating reported accuracy. Always call `scaler.fit(X_train)` and `scaler.transform(X_test)`.
- **Selecting Even $k$ Values**: Using even $k$ values ($k=2, 4$) can lead to frequent 50/50 ties, forcing scikit-learn into deterministic fallback tie-breaking that may obscure genuine model capability.

## Best Practices and Security Considerations
- **Stratified Evaluation**: Always ensure test evaluation sets are stratified across classes (`stratify=y`) so that class proportions match the real-world population and accuracy is not skewed by class imbalance.
- **Reporting Metrics Beyond Accuracy**: In multi-class problems, aggregate accuracy can hide poor performance on a specific difficult class. Always pair accuracy with a confusion matrix and class-level precision and recall.
- **Deterministic Random State**: Always set `random_state` during dataset splitting to guarantee that accuracy metrics are fully reproducible across team members and CI/CD pipelines.

## Summary and Key Takeaways
- Accuracy measures the overall proportion of correct classifications: $\text{Accuracy} = \text{Correct} / \text{Total}$.
- Testing multiple values of $k$ enables practitioners to select a neighborhood size that balances local sensitivity and noise tolerance.
- In our Palmer Penguins test set ($N=38$), both $k=3$ and $k=5$ attain $94.7\%$ accuracy ($36/38$ correct).
- $k=3$ is selected as `best_k` because it provides sharp discrimination between adjacent morphometric clusters while offering robustness against isolated point anomalies.

## Knowledge-check Questions
1. Why is evaluating accuracy on `X_train` insufficient for selecting the best $k$ hyperparameter?
2. If a test set has 38 samples and a model achieves $94.7\%$ accuracy, how many samples were misclassified?
3. Why are odd numbers conventionally chosen for the neighborhood size $k$?
4. What happens to the KNN decision boundary when $k$ is increased to a very large number relative to the dataset size?

## References
- Scikit-Learn Documentation on `KNeighborsClassifier.score`: https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.KNeighborsClassifier.html
- Hastie, T., Tibshirani, R., & Friedman, J. (2009). *The Elements of Statistical Learning: Data Mining, Inference, and Prediction*. Springer. Chapter 13: Prototype Methods and Nearest-Neighbors.
- Gorman, K. B., Williams, T. D., & Fraser, W. R. (2014). Ecological Sexual Dimorphism and Environmental Variability within a Community of Antarctic Penguins (Genus Pygoscelis). *PLoS ONE*, 9(3), e90081.
