# Lesson 04: Visualizing Morphological Decision Boundaries and Cluster Separation

## Purpose and Learning Objectives
The primary objective of this lesson is to master exploratory data visualization using Matplotlib to interpret multi-dimensional machine learning representations. High-dimensional models operating in 4D space can feel abstract; projecting biological features onto a 2D Cartesian plane allows human practitioners to intuitively inspect cluster compactness, boundary margins, and outlier overlap. By generating and analyzing `penguin_scatter.png`—a scatter plot of Bill Length versus Flipper Length colored by species—students will visually validate why the K-Nearest Neighbors classifier achieves near-perfect separation.

By the end of this lesson, you will be able to:
- Use Matplotlib's object-oriented and functional plotting APIs to render multi-class scatter plots.
- Map categorical class labels to distinct hex color palettes for high-contrast presentation.
- Configure plot aesthetics including figure dimensions, marker alpha transparency, axis labels, legends, and tight layouts.
- Interpret the 2D morphological clustering of Adelie, Chinstrap, and Gentoo penguins.
- Explain why the pairing of Bill Length and Flipper Length provides maximum visual discriminative power among morphological dimensions.

## Prerequisites
Before starting this lesson, you should be familiar with:
- The Palmer Penguins dataset loaded into a pandas DataFrame from Module 02.
- The confusion matrix and classification report results from Lessons 02 and 03.
- Basic Matplotlib concepts (figures, axes, scatter plots, and file exports).
- Working in headless or script-based execution environments where plots are saved to disk.

## Biological and Real-World Context
In evolutionary ecomorphology, animals evolve physical structures that correspond directly to their foraging habits and environmental niches. Bill morphology reflects diet:
- Adelie penguins feed primarily on Antarctic krill (*Euphausia superba*), requiring short, stout beaks to crush crustacean shells.
- Chinstrap penguins also eat krill but supplement their diet with small fish, possessing longer bills to snatch slippery prey.
- Gentoo penguins are dietary generalists, feeding heavily on fish, squid, and krill, possessing both long, deep bills and extensive flipper surface areas for sustained deep diving.

Flipper length correlates directly with swimming efficiency and hydrodynamic power. Gentoos dive up to 200 meters, requiring powerful, elongated flippers. Adelies and Chinstraps are shallow-to-medium divers, maintaining shorter flippers. 

When researchers plot Bill Length against Flipper Length, these divergent evolutionary adaptations crystallize into distinct geometric clusters. Machine learning practitioners leverage these morphological visualizations to explain algorithmic predictions to wildlife biologists, policymakers, and public stakeholders.

## Concept Explanation
### Multi-Class 2D Projection
Our full KNN classifier evaluates penguins across 4 dimensions ($D = 4$). However, humans cannot directly perceive 4-dimensional hyperplanes. Dimensionality reduction or bivariate projection allows us to visualize high-dimensional relationships. By selecting the two most discriminative features—`bill_length_mm` ($x$-axis) and `flipper_length_mm` ($y$-axis)—we can project the 150 biological specimens onto a 2D Cartesian plane:

$$\mathbf{p}_i = \big(x_i = \text{bill\_length\_mm}_i, \; y_i = \text{flipper\_length\_mm}_i\big)$$

### Morphological Cluster Separation
When rendered in 2D space, the three species form three well-defined regions:
1. **Adelie (Bottom Left Cluster)**:
   - Short bill ($32\text{--}44\text{ mm}$) and short flipper ($175\text{--}205\text{ mm}$).
   - Compact grouping in the lower-left quadrant.
2. **Chinstrap (Bottom Right Cluster)**:
   - Long bill ($45\text{--}58\text{ mm}$) and short flipper ($185\text{--}210\text{ mm}$).
   - Shares similar flipper lengths with Adelie, but is distinctly shifted to the right due to greater bill length.
3. **Gentoo (Top Right / Upper Cluster)**:
   - Moderate-to-long bill ($42\text{--}55\text{ mm}$) and exceptionally long flipper ($205\text{--}235\text{ mm}$).
   - Completely separated along the vertical $y$-axis, creating a large margin of separation from both Adelie and Chinstrap.

### Visualizing Nearest Neighbor Decision Regions
In KNN, the classification of any arbitrary query point $\mathbf{x}^*$ is determined by the majority label of its closest training points. In this 2D projection, the spatial distance between points closely approximates the multi-dimensional Euclidean distance. Points deep within the Gentoo cluster will have 100% Gentoo neighbors. Points lying on the narrow boundary between the Adelie and Chinstrap clusters may have mixed neighborhoods, visually explaining the single misclassification observed in the confusion matrix.

## Relevant Code (from main.py)
```python
# Visualization
plt.figure(figsize=(8, 5))
colors = {"Adelie": "#FF6B6B", "Chinstrap": "#4ECDC4", "Gentoo": "#45B7D1"}
for species in species_names:
    subset = df[df["species"] == species]
    plt.scatter(
        subset["bill_length_mm"],
        subset["flipper_length_mm"],
        label=species,
        color=colors[species],
        alpha=0.7,
    )
plt.xlabel("Bill Length (mm)")
plt.ylabel("Flipper Length (mm)")
plt.title("Palmer Penguins: Bill Length vs Flipper Length")
plt.legend()
plt.tight_layout()
plt.savefig("penguin_scatter.png")
print("
Scatter plot saved as penguin_scatter.png")
```

## Code Explanation
Let us examine the plotting pipeline step by step:
1. `plt.figure(figsize=(8, 5))`: Initializes a new Matplotlib figure canvas with a width of 8 inches and a height of 5 inches, providing a balanced aspect ratio for presentation slides and technical reports.
2. `colors = {"Adelie": "#FF6B6B", "Chinstrap": "#4ECDC4", "Gentoo": "#45B7D1"}`:
   - Defines a custom dictionary mapping each species name to a distinct, colorblind-friendly hexadecimal color code.
   - `#FF6B6B` (Coral Red) for Adelie.
   - `#4ECDC4` (Turquoise Green) for Chinstrap.
   - `#45B7D1` (Sky Blue) for Gentoo.
3. `for species in species_names:`: Iterates through each unique species label (`["Adelie", "Chinstrap", "Gentoo"]`).
4. `subset = df[df["species"] == species]`: Filters the original unscaled DataFrame to isolate rows corresponding to the current species.
5. `plt.scatter(...)`:
   - Plots the coordinates `subset["bill_length_mm"]` against `subset["flipper_length_mm"]`.
   - `label=species`: Assigns the text label for the plot legend.
   - `color=colors[species]`: Applies the designated hex color.
   - `alpha=0.7`: Sets 70% opacity, allowing overlapping data points to appear darker and denser rather than completely occluding each other.
6. `plt.xlabel("Bill Length (mm)")` and `plt.ylabel("Flipper Length (mm)")`: Adds informative, unit-bearing axis labels.
7. `plt.title("Palmer Penguins: Bill Length vs Flipper Length")`: Adds an overarching title describing the visualization.
8. `plt.legend()`: Renders the legend box using the labels and colors defined during the scatter calls.
9. `plt.tight_layout()`: Automatically adjusts subplot padding to prevent labels and titles from clipping against canvas margins.
10. `plt.savefig("penguin_scatter.png")`: Renders and exports the vector canvas to a high-resolution raster PNG image on disk.
11. `print("
Scatter plot saved as penguin_scatter.png")`: Notifies the user via console telemetry that the file export succeeded.

## Worked Example
Let us trace what happens when `plt.scatter` is executed for each species:
- **Iteration 1 (`species = 'Adelie'`)**:
  - `subset` contains 50 rows.
  - Mean bill length: $38.8\text{ mm}$, Mean flipper length: $190.0\text{ mm}$.
  - 50 coral red circles are plotted in the lower-left region ($x \in [33.5, 46.0], y \in [179, 208]$).
- **Iteration 2 (`species = 'Chinstrap'`)**:
  - `subset` contains 50 rows.
  - Mean bill length: $48.8\text{ mm}$, Mean flipper length: $195.8\text{ mm}$.
  - 50 turquoise circles are plotted in the lower-right region ($x \in [40.9, 57.4], y \in [180, 212]$).
- **Iteration 3 (`species = 'Gentoo'`)**:
  - `subset` contains 50 rows.
  - Mean bill length: $47.5\text{ mm}$, Mean flipper length: $217.2\text{ mm}$.
  - 50 sky blue circles are plotted in the upper region ($x \in [40.9, 55.9], y \in [200, 232]$).

### Examining the Overlap Zone
Notice the boundary between Adelie and Chinstrap:
- Adelie bill lengths extend up to $46.0\text{ mm}$.
- Chinstrap bill lengths extend down to $40.9\text{ mm}$.
- Because both species have similar flipper lengths ($180\text{--}205\text{ mm}$), points in the $x \in [41, 46]$ interval sit immediately adjacent to each other. An Adelie at $x=44.1, y=195$ will have nearest neighbors that include both Adelie and Chinstrap specimens, directly explaining why 1 test specimen from each species cross-classified in our confusion matrix.
- Conversely, Gentoo flippers start at $200\text{ mm}$ with most specimens well above $210\text{ mm}$, creating an unmistakable vertical gap above the Adelie cluster.

## Step-by-Step Student Instructions
1. Open your terminal in the `penguin-detective` repository.
2. Verify that `matplotlib` is installed: `python -c "import matplotlib; print(matplotlib.__version__)"`.
3. Locate the `# Visualization` block in `main.py`.
4. Run `python main.py`.
5. Check your directory listing to verify the generation of `penguin_scatter.png`: `ls -lh penguin_scatter.png`.
6. Open `penguin_scatter.png` using an image viewer or VS Code preview.
7. Locate the three colored clusters and confirm:
   - Coral red points (Adelie) cluster at the bottom left.
   - Turquoise points (Chinstrap) cluster at the bottom right.
   - Sky blue points (Gentoo) form an isolated band across the top.
8. Locate the legend in the upper-left quadrant and verify all three species are clearly labeled.

## Expected Output or Observable Behaviour
When executed, `main.py` logs the following console output:
```text
Scatter plot saved as penguin_scatter.png
```
On disk, a new file `penguin_scatter.png` is generated:
- File dimensions: approximately $800 \times 500$ pixels (or $1600 \times 1000$ at $200\text{ DPI}$).
- Three distinct color-coded point clusters clearly visible against a white background.
- Crisp axis titles: "Bill Length (mm)" and "Flipper Length (mm)".
- Clear legend with species names and matching color swatches.

## Practical Exercises
### Exercise 1: Overlaying Mystery Penguin on Scatter Plot
Modify the plotting script to plot the mystery field specimen (`[39.0, 18.0, 190, 3700]`) as an eye-catching black star on top of the dataset clusters:
```python
plt.scatter(
    [39.0], [190],
    color="black", marker="*", s=250,
    edgecolors="yellow", linewidths=1.5,
    label="Mystery Specimen", zorder=5
)
plt.legend()
plt.savefig("penguin_scatter_with_mystery.png")
```
Open `penguin_scatter_with_mystery.png` and confirm visually that the mystery specimen falls directly in the center of the Adelie cluster.

### Exercise 2: Alternate Bivariate Projection (Bill Length vs Body Mass)
Create a second scatter plot plotting `bill_length_mm` against `body_mass_g`:
```python
plt.figure(figsize=(8, 5))
for species in species_names:
    sub = df[df["species"] == species]
    plt.scatter(sub["bill_length_mm"], sub["body_mass_g"], label=species, alpha=0.7)
plt.xlabel("Bill Length (mm)")
plt.ylabel("Body Mass (g)")
plt.title("Palmer Penguins: Bill Length vs Body Mass")
plt.legend()
plt.tight_layout()
plt.savefig("penguin_mass_scatter.png")
```
Compare this plot to the flipper length plot. Does Gentoo remain well-separated? Does the Adelie-Chinstrap separation improve or worsen?

## Common Mistakes and Debugging
- **Calling `plt.show()` in Headless Environments**: In automated scripts, remote servers, or Docker containers without an active X11 display, calling `plt.show()` can block execution or throw a `TclError`. In production pipelines, always prefer `plt.savefig()` with a non-interactive backend (e.g., `matplotlib.use('Agg')`).
- **Missing `plt.legend()`**: If you supply `label=species` to `plt.scatter` but forget to invoke `plt.legend()`, no legend will be rendered on the figure, leaving viewers unable to identify which color represents which species.
- **Plotting Scaled Data Without Updating Axis Labels**: If you accidentally plot `X_train_scaled[:, 0]` instead of `df["bill_length_mm"]`, the axis coordinates will range from $-2.5$ to $+2.5$ instead of $30\text{--}60\text{ mm}$. Ensure axis labels accurately match the plotted scale.

## Best Practices and Security Considerations
- **Colorblind-Accessible Palettes**: Never rely solely on pure red and pure green markers, as approximately 8% of men have red-green color vision deficiency. Use distinguishable hues (like coral, turquoise, and sky blue) or pair colors with distinct marker shapes (`marker='o'`, `marker='s'`, `marker='^'`).
- **Resolution Control**: In technical publications and web interfaces, specify explicit resolution using `dpi=300` in `plt.savefig()` to guarantee vector-sharp rasterization.
- **Resource Cleanup**: Always call `plt.close()` after `plt.savefig()` in long-running applications or automated loops to prevent memory leaks from accumulated figure canvases.

## Summary and Key Takeaways
- Bivariate scatter plots project multi-dimensional feature spaces onto intuitive 2D planes for visual validation.
- Plotting `bill_length_mm` against `flipper_length_mm` reveals three distinct morphological clusters corresponding to the three penguin species.
- Gentoo penguins form a distinct upper cluster due to long flippers ($>205\text{ mm}$).
- Adelie and Chinstrap penguins share similar flipper lengths ($180\text{--}205\text{ mm}$) but are separated horizontally by bill length.
- The slight proximity between the upper tail of Adelie bills and the lower tail of Chinstrap bills visually explains the rare confusion between these two species.

## Knowledge-check Questions
1. Why is setting `alpha=0.7` in `plt.scatter` beneficial when plotting overlapping biological datasets?
2. Looking at `penguin_scatter.png`, which feature primarily separates Gentoo penguins from Adelie penguins?
3. Which feature primarily separates Adelie penguins from Chinstrap penguins?
4. Why is `plt.tight_layout()` recommended before saving figures with Matplotlib?

## References
- Matplotlib Documentation: https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.scatter.html
- Wickham, H. (2010). A Layered Grammar of Graphics. *Journal of Computational and Graphical Statistics*, 19(1), 3-28.
- Gorman, K. B., Williams, T. D., & Fraser, W. R. (2014). Ecological Sexual Dimorphism and Environmental Variability within a Community of Antarctic Penguins (Genus Pygoscelis). *PLoS ONE*, 9(3), e90081.
