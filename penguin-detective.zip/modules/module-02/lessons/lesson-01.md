# Lesson 01: Anatomy of `penguins.csv` & Data Exploration

**Lesson ID:** lesson-01
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Load `data/penguins.csv` into a pandas DataFrame using `pathlib.Path`
- Verify the structural dimensions of the dataset (150 rows by 5 columns)
- Inspect column data types, memory footprint, and absence of missing values
- Separate tabular data into independent predictor features ($X$) and dependent target labels ($y$)

## Prerequisites
- Module 01: Project Overview
- Basic pandas knowledge (`read_csv`, `head`, `info`, `shape`)

## Biological and Real-World Context
In scientific ecological studies, raw field data is often recorded across multiple notebooks or raw CSV exports containing environmental noise, sensor glitches, or missing records. The dataset provided in `data/penguins.csv` represents a clean, curated subset of the Palmer Station Long Term Ecological Research (LTER) collection.

Before applying machine learning algorithms to any ecological data, data scientists must perform exploratory data analysis (EDA). Verifying the data dimensions, column names, value types, and summary distributions ensures that the modeling pipeline receives high-integrity numerical inputs.

## Concept Explanation
The file `data/penguins.csv` is structured in standard Comma-Separated Values (CSV) format. A quick inspection reveals 1 header row followed by 150 data rows, each corresponding to an individual penguin captured and measured by field biologists.

The five columns are:
1. `species`: The biological species name (text string: Adelie, Chinstrap, or Gentoo) $\rightarrow$ **Target variable ($y$)**.
2. `bill_length_mm`: Float measurement in millimeters $\rightarrow$ **Predictor feature ($X$)**.
3. `bill_depth_mm`: Float measurement in millimeters $\rightarrow$ **Predictor feature ($X$)**.
4. `flipper_length_mm`: Integer/float measurement in millimeters $\rightarrow$ **Predictor feature ($X$)**.
5. `body_mass_g`: Integer/float measurement in grams $\rightarrow$ **Predictor feature ($X$)**.

In supervised machine learning, we divide this single tabular structure into two complementary entities:
- **Feature matrix ($X$)**: A 2-dimensional tabular array of shape `(150, 4)` containing solely numerical measurements.
- **Target vector ($y$)**: A 1-dimensional series of shape `(150,)` containing the ground truth category for each row.

## Relevant Code (from main.py)
```python
# Lines 23-28, 33-35 of main.py
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"

FEATURES = ["bill_length_mm", "bill_depth_mm", "flipper_length_mm", "body_mass_g"]

def main() -> None:
    df = pd.read_csv(DATA / "penguins.csv")
    X = df[FEATURES]
    y = df["species"]
```

## Code Explanation
- `DATA = BASE / "data"` builds an immutable path object pointing to the data subfolder.
- `pd.read_csv(DATA / "penguins.csv")` parses the CSV file into a pandas DataFrame object `df`.
- `X = df[FEATURES]` uses Python list indexing to slice out exactly the four columns specified in `FEATURES`, returning a 2D DataFrame of shape `(150, 4)`.
- `y = df["species"]` extracts the target column as a 1D pandas Series of shape `(150,)`.
- Notice that `X` is 2-dimensional (rows $\times$ features) as required by scikit-learn estimators, while `y` is 1-dimensional.

## Worked Example
Let us trace what pandas outputs when we run exploratory commands on `df`:

```python
import pandas as pd
df = pd.read_csv("data/penguins.csv")

print("Shape:", df.shape)
# Output: Shape: (150, 5)

print("Columns:", list(df.columns))
# Output: Columns: ['species', 'bill_length_mm', 'bill_depth_mm', 'flipper_length_mm', 'body_mass_g']

print("Data Types:
", df.dtypes)
# Output:
# species               object
# bill_length_mm       float64
# bill_depth_mm        float64
# flipper_length_mm      int64
# body_mass_g            int64
```
All features are numeric (`float64` or `int64`), and the target is text (`object`). There are no missing (`NaN`) values in this curated dataset, meaning no imputation step is required prior to scaling.

## Step-by-Step Student Instructions
1. Open a terminal and navigate to the project directory.
2. Launch a Python interactive session (`python3`).
3. Import `pandas` and load `data/penguins.csv`.
4. Inspect `df.head(5)` to see the first 5 rows.
5. Print `df.shape` and confirm that it yields `(150, 5)`.
6. Extract `X = df[["bill_length_mm", "bill_depth_mm", "flipper_length_mm", "body_mass_g"]]` and verify `X.shape` is `(150, 4)`.
7. Extract `y = df["species"]` and verify `y.shape` is `(150,)`.

## Expected Output or Observable Behaviour
```text
>>> df.head(3)
     species  bill_length_mm  bill_depth_mm  flipper_length_mm  body_mass_g
0     Gentoo            48.9           15.3                216         5153
1     Adelie            40.8           16.5                188         3942
2  Chinstrap            48.0           19.3                188         3593
```
Each row exhibits clean, non-null values for all four measurements alongside the species classification.

## Practical Exercises
- **Exercise 1.1**: Write a Python snippet that checks whether any null values exist in `df` using `df.isnull().sum()`.
- **Exercise 1.2**: Explain why `X` must be a 2D DataFrame rather than a 1D Series when passed to scikit-learn's `fit()` method.
- **Exercise 1.3**: What would happen if the CSV file had an extra column, such as `island` or `sex`? How does `X = df[FEATURES]` protect the pipeline from unselected columns?

## Common Mistakes and Debugging
- **Passing the target inside $X$**: Writing `X = df` instead of `X = df[FEATURES]`. If the target column `species` remains in $X$, the model would "cheat" by using the answer as an input feature, or throw a `ValueError` during mathematical scaling.
- **Mismatched column spelling**: A typo like `"bill_lengths_mm"` raises a `KeyError: "['bill_lengths_mm'] not in index"`.
- **Using relative paths without `Path`**: Calling `pd.read_csv("data/penguins.csv")` works only if the current working directory matches the project root. Using `pathlib.Path(__file__).resolve().parent` avoids this issue.

## Best Practices and Security Considerations
- **Explicit Feature Lists**: Always define features as an explicit list (`FEATURES = [...]`) rather than dropping columns. This ensures that only authorized columns enter the model.
- **Read-Only Dataset Access**: Never modify the original raw CSV file during data processing. Treat raw data as immutable.
- **Type Verification**: Explicitly verify that numeric columns have numeric dtypes (`float64`, `int64`) to prevent string-formatted numbers from causing downstream scaling crashes.

## Summary and Key Takeaways
- `data/penguins.csv` contains 150 records across 5 columns: 4 numerical features and 1 categorical target.
- `FEATURES` explicitly specifies the 4 predictor columns: bill length, bill depth, flipper length, and body mass.
- Slicing `df[FEATURES]` generates the 2D feature matrix $X$ of shape `(150, 4)`.
- Extracting `df["species"]` generates the 1D target vector $y$ of shape `(150,)`.

## Knowledge-check Questions
1. How many total rows and columns are contained in `penguins.csv`?
2. What are the names of the four predictor features?
3. What is the difference in shape between $X$ and $y$?
4. What data type is the `species` column in pandas?
5. Why is defining an explicit `FEATURES` list safer than dropping columns?

## References
- pandas `read_csv` Documentation: https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html
- Python `pathlib` Tutorial: https://docs.python.org/3/library/pathlib.html
- Palmer Penguins Data Dictionary: https://allisonhorst.github.io/palmerpenguins/articles/intro.html
