# Lesson 04: Stratified Train-Test Splitting with `train_test_split`

**Lesson ID:** lesson-04
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why datasets must be partitioned into independent training and testing sets
- Define the role and mechanics of the `stratify=y` parameter in `train_test_split`
- Calculate exact sample allocations for a 75/25 split on 150 rows (112 train, 38 test)
- Understand the purpose of setting `random_state=42` for experimental reproducibility

## Prerequisites
- Lesson 01: Anatomy of `penguins.csv` & Data Exploration
- Lesson 03: Species Distribution & Class Balance in the Dataset
- Understanding of independent vs dependent variables

## Biological and Real-World Context
Imagine training an automated wildlife scanner on 150 captured penguins. If you evaluate the scanner by asking it to classify those exact same 150 birds, it might score 100% simply by memorizing individual birds. But when deployed in the field next season, it might fail completely on new birds.

In machine learning, this pitfall is called **overfitting** or **training on the test set**. To obtain an honest, unbiased assessment of how well a model generalizes to unobserved penguins, we must hold out a fraction of the data during training and use it exclusively for final evaluation.

## Concept Explanation
The function `train_test_split` from `sklearn.model_selection` partitions arrays or DataFrames into random train and test subsets. In `main.py`, three key parameters control this partition:

```python
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)
```

### 1. `test_size=0.25`
- Allocates $25\%$ of the total samples to the test set and the remaining $75\%$ to the training set.
- Total samples: $150$.
- Test size: $\text{round}(150 \times 0.25) = 38\text{ samples}$.
- Train size: $150 - 38 = 112\text{ samples}$.

### 2. `random_state=42`
- Sets the pseudo-random number generator seed.
- Guarantees that every execution produces the **exact same partition**, ensuring deterministic, reproducible evaluation results across different computers.

### 3. `stratify=y`
- Enforces **stratified sampling**, ensuring that the proportion of each class in the test set matches the proportion in the full dataset.
- Without stratification, pure random sampling might allocate 18 Gentoos, 12 Adelies, and only 8 Chinstraps to the test set by random fluctuation.
- With `stratify=y`, the 38 test samples are divided as evenly as possible: **12 Adelie, 13 Chinstrap, and 13 Gentoo** ($12 + 13 + 13 = 38$).
- Similarly, the 112 training samples consist of **38 Adelie, 37 Chinstrap, and 37 Gentoo** ($38 + 37 + 37 = 112$).

## Relevant Code (from main.py)
```python
# Lines 37-39 of main.py
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)
```

## Code Explanation
- `X`: The `(150, 4)` DataFrame of morphometric features.
- `y`: The `(150,)` Series of species class strings.
- The function unpacks four distinct subsets:
  - `X_train`: Feature matrix used to teach the model (`shape: (112, 4)`).
  - `y_train`: Ground-truth labels used to teach the model (`shape: (112,)`).
  - `X_test`: Held-out feature matrix used to generate predictions (`shape: (38, 4)`).
  - `y_test`: Ground-truth labels used to score model predictions (`shape: (38,)`).

## Worked Example
Let us verify the exact class distribution resulting from this split:

```python
from collections import Counter
print("y_train distribution:", Counter(y_train))
# Output: Counter({'Adelie': 38, 'Chinstrap': 37, 'Gentoo': 37})

print("y_test distribution:", Counter(y_test))
# Output: Counter({'Chinstrap': 13, 'Gentoo': 13, 'Adelie': 12})
```

Total counts:
- Adelie: $38\text{ train} + 12\text{ test} = 50\text{ total}$.
- Chinstrap: $37\text{ train} + 13\text{ test} = 50\text{ total}$.
- Gentoo: $37\text{ train} + 13\text{ test} = 50\text{ total}$.

Every single penguin in the original dataset is accounted for, and both partitions reflect the balanced composition of the original data.

## Step-by-Step Student Instructions
1. Import `train_test_split` from `sklearn.model_selection`.
2. Load `penguins.csv` and define $X$ and $y$.
3. Execute `train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)`.
4. Check `X_train.shape` and confirm it equals `(112, 4)`.
5. Check `X_test.shape` and confirm it equals `(38, 4)`.
6. Run `y_test.value_counts()` and confirm the counts are 13 Chinstrap, 13 Gentoo, and 12 Adelie.

## Expected Output or Observable Behaviour
```text
>>> X_train.shape, X_test.shape
((112, 4), (38, 4))
>>> y_test.value_counts()
species
Chinstrap    13
Gentoo       13
Adelie       12
Name: count, dtype: int64
```
The sample shapes and species counts match the theoretical partition perfectly.

## Practical Exercises
- **Exercise 4.1**: What would happen to the split sizes if `test_size=0.20` were used instead of `0.25` on 150 rows?
- **Exercise 4.2**: What happens if `random_state` is omitted? Try running the split three times without `random_state` and inspect the indices.
- **Exercise 4.3**: Why is stratified splitting especially crucial when working with small datasets or imbalanced datasets?

## Common Mistakes and Debugging
- **Data Leakage during Scaling**: Standardizing all 150 rows *before* splitting data into train and test sets. Doing so leaks test set mean and variance into the training process. Preprocessing parameters must be learned exclusively from `X_train`.
- **Mismatched Unpacking Order**: Accidentally writing `X_train, y_train, X_test, y_test = train_test_split(...)`. Scikit-learn returns `X_train, X_test, y_train, y_test`. Reversing the middle two variables results in silent shape and label errors.
- **Omitting `stratify=y`**: In small datasets, unstratified splitting can leave one class severely underrepresented in the test set, leading to high variance in accuracy estimates.

## Best Practices and Security Considerations
- **Fixed Random State for Verification**: Always fix `random_state` during development and peer review to ensure reproducible results.
- **Never Touch the Test Set During Training**: Keep `X_test` and `y_test` strictly sequestered until final evaluation.
- **Stratify by Default on Categorical Targets**: Unless dealing with time-series or grouped hierarchical data, default to stratified sampling for classification tasks.

## Summary and Key Takeaways
- Train-test splitting prevents overfitting by evaluating models on unseen data.
- `test_size=0.25` partitions 150 rows into 112 training samples and 38 test samples.
- `stratify=y` guarantees proportional representation of each class across both partitions (12 Adelie, 13 Chinstrap, 13 Gentoo in test).
- `random_state=42` ensures deterministic reproducibility across runs and environments.

## Knowledge-check Questions
1. How many total rows are assigned to `X_train` and `X_test` respectively when `test_size=0.25` on 150 rows?
2. What does the `stratify=y` parameter guarantee?
3. How many Adelie, Chinstrap, and Gentoo samples are present in the test set?
4. What is the danger of evaluating a machine learning model on the exact data used for training?
5. Why is `random_state=42` specified in `main.py`?

## References
- scikit-learn `train_test_split` Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html
- Kohavi R (1995) A Study of Cross-Validation and Bootstrap for Accuracy Estimation and Model Selection. *IJCAI*.
- Data Leakage in Machine Learning (Kaufman et al.): https://www.cs.umb.edu/~ding/history/470_670_fall_2011/papers/cs670_leakage.pdf
