# Lesson 02: The Four Morphometric Features: Bill Length, Bill Depth, Flipper Length, and Body Mass

**Lesson ID:** lesson-02
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Compute and interpret descriptive summary statistics for each of the four features
- Analyze the numerical range, spread, and standard deviation across features
- Recognize the vast difference in scale between millimeter features and gram features
- Explain the biological significance of culmen dimensions and flipper length

## Prerequisites
- Lesson 01: Anatomy of `penguins.csv` & Data Exploration
- Basic statistics (mean, minimum, maximum, quartiles, standard deviation)

## Biological and Real-World Context
In avian biology, a bird's bill is its primary tool for feeding, grooming, and defense. Dr. Kristen Gorman and the Palmer LTER scientists specifically recorded the **culmen** dimensions:
- The **culmen length** is the dorsal ridge length of the upper mandible, extending from where feathers start at the base of the skull to the extreme tip of the beak.
- The **culmen depth** is the vertical height of the bill base.

Penguin wings have evolved into stiff, blade-like flippers covered with scale-like feathers. Unlike flying birds whose wings generate aerodynamic lift, penguin flippers act as hydrofoils, generating powerful aquatic thrust against dense polar waters. Flipper length directly correlates with swimming velocity and diving depth. Body mass reflects overall structural bulk and subcutaneous blubber thickness needed for thermal regulation in Antarctic seas.

## Concept Explanation
Let us inspect the parametric distribution of the four features across the entire 150-sample dataset using pandas' `.describe()` method:

| Metric | `bill_length_mm` | `bill_depth_mm` | `flipper_length_mm` | `body_mass_g` |
|---|---|---|---|---|
| **Mean** | 44.82 mm | 17.28 mm | 200.45 mm | 4,153.23 g |
| **Std Dev** | 5.28 mm | 1.81 mm | 12.48 mm | 722.08 g |
| **Minimum** | 33.50 mm | 13.60 mm | 179.00 mm | 2,959.00 g |
| **25% (Q1)** | 40.53 mm | 15.70 mm | 191.00 mm | 3,584.50 g |
| **50% (Median)**| 45.95 mm | 17.70 mm | 196.00 mm | 3,957.50 g |
| **75% (Q3)** | 48.60 mm | 18.50 mm | 212.00 mm | 4,797.50 g |
| **Maximum** | 57.40 mm | 21.00 mm | 232.00 mm | 6,026.00 g |

Notice the critical observation that defines this project:
- `bill_depth_mm` spans a narrow range of just $7.4\text{ mm}$ ($13.6$ to $21.0$).
- `bill_length_mm` spans $23.9\text{ mm}$ ($33.5$ to $57.4$).
- `flipper_length_mm` spans $53.0\text{ mm}$ ($179.0$ to $232.0$).
- `body_mass_g` spans $3,067.0\text{ g}$ ($2,959$ to $6,026$).

The scale of `body_mass_g` is roughly **400 times larger** than `bill_depth_mm`. Without feature scaling, any mathematical distance metric would be overwhelmingly dominated by mass.

## Relevant Code (from main.py)
```python
# Lines 28, 34 of main.py
FEATURES = ["bill_length_mm", "bill_depth_mm", "flipper_length_mm", "body_mass_g"]

df = pd.read_csv(DATA / "penguins.csv")
X = df[FEATURES]
```

## Code Explanation
- The `FEATURES` list bundles features with fundamentally different units ($mm$ vs $g$) and widely differing orders of magnitude.
- Python and pandas preserve the original floating-point and integer numbers during extraction.
- Because these features are continuous numeric values, they define a 4-dimensional geometric coordinate space where each penguin is represented as a point $(x_1, x_2, x_3, x_4)$.

## Worked Example
Let us calculate the unscaled squared distance between two penguins across their features:
- Penguin A: `[bill_length=40.0, bill_depth=18.0, flipper=190.0, body_mass=3700.0]`
- Penguin B: `[bill_length=48.0, bill_depth=18.0, flipper=195.0, body_mass=5000.0]`

Compute squared coordinate differences:
- $\Delta \text{bill\_length}^2 = (48 - 40)^2 = 8^2 = 64$
- $\Delta \text{bill\_depth}^2 = (18 - 18)^2 = 0^2 = 0$
- $\Delta \text{flipper}^2 = (195 - 190)^2 = 5^2 = 25$
- $\Delta \text{body\_mass}^2 = (5000 - 3700)^2 = 1300^2 = 1,690,000$

Total unscaled sum: $64 + 0 + 25 + 1,690,000 = 1,690,089$.
Notice that `body_mass_g` accounts for $\frac{1,690,000}{1,690,089} = 99.995\%$ of the total distance calculation! Bill length and flipper length contribute virtually nothing. This proves mathematically why standardizing feature scales is essential.

## Step-by-Step Student Instructions
1. Load `penguins.csv` into a DataFrame in Python.
2. Call `df[FEATURES].describe()` to display the statistical summary table.
3. Compare the maximum value of `body_mass_g` (6026) to `bill_depth_mm` (21.0).
4. Compute the standard deviation of each feature using `df[FEATURES].std()`.
5. Observe how `body_mass_g` has a standard deviation of 722.08, whereas `bill_depth_mm` has a standard deviation of only 1.81.

## Expected Output or Observable Behaviour
```text
>>> df[FEATURES].agg(['min', 'mean', 'max', 'std'])
      bill_length_mm  bill_depth_mm  flipper_length_mm  body_mass_g
min        33.500000      13.600000         179.000000  2959.000000
mean       44.815333      17.276667         200.453333  4153.226667
max        57.400000      21.000000         232.000000  6026.000000
std         5.277656       1.812722          12.482786   722.076388
```
The printout highlights the dramatic spread difference across variables.

## Practical Exercises
- **Exercise 2.1**: Find the penguin in the dataset with the maximum flipper length using `df.loc[df['flipper_length_mm'].idxmax()]`. What species is it?
- **Exercise 2.2**: Find the penguin with the shortest bill length using `df.loc[df['bill_length_mm'].idxmin()]`. What species is it?
- **Exercise 2.3**: Calculate the ratio between the standard deviation of `body_mass_g` and `bill_depth_mm`.

## Common Mistakes and Debugging
- **Assuming all features have equal influence without scaling**: Forgetting that distance algorithms measure numerical differences; a difference of 100g is numerically larger than 10mm, even though 10mm is a huge biological difference for a penguin beak.
- **Treating integer and float columns inconsistently**: pandas loads `flipper_length_mm` as `int64` and `bill_length_mm` as `float64`. `StandardScaler` handles both seamlessly, converting all inputs to float64.
- **Confusing bill depth with bill length**: Culmen length is the horizontal ridge; culmen depth is the vertical base thickness.

## Best Practices and Security Considerations
- **Descriptive Statistics Verification**: Always inspect minimums, medians, and maximums to detect data entry errors (e.g., negative weights or zero lengths).
- **Domain Sanity Checks**: Confirm that maximum and minimum values align with established biological literature for polar seabirds.
- **Awareness of Units**: Explicitly document measurement units in variable names (e.g., `_mm` and `_g`) to prevent interpretation errors.

## Summary and Key Takeaways
- The four features measure culmen length (mm), culmen depth (mm), flipper length (mm), and body mass (g).
- Feature ranges differ dramatically: bill depth ranges from 13.6 to 21.0 mm, while body mass ranges from 2959 to 6026 g.
- Because `body_mass_g` has a magnitude in the thousands, unscaled Euclidean distance would be dominated by weight, ignoring delicate beak differences.
- Descriptive statistical inspection is a necessary prerequisite to designing an effective machine learning preprocessing pipeline.

## Knowledge-check Questions
1. What is the mean body mass across all penguins in the dataset?
2. What is the minimum and maximum bill depth recorded in the dataset?
3. Which feature has the largest standard deviation in absolute terms?
4. Why does an unscaled distance metric fail when features have vastly different orders of magnitude?
5. What anatomical structure does culmen depth measure?

## References
- Gorman KB, et al. (2014) *PLoS ONE* 9(3): e90081.
- scikit-learn Feature Scaling: https://scikit-learn.org/stable/modules/preprocessing.html#standardization-or-mean-removal-and-variance-scaling
- pandas Descriptive Statistics: https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.describe.html
