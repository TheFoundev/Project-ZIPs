# Lesson 03: Species Distribution & Class Balance in the Dataset

**Lesson ID:** lesson-03
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Quantify the frequency distribution of classes in the target variable `species`
- Identify that the dataset is perfectly balanced across all three penguin species
- Explain the advantages of class balance in training and evaluating classification models
- Contrast balanced datasets with real-world imbalanced ecological datasets

## Prerequisites
- Lesson 01: Anatomy of `penguins.csv` & Data Exploration
- Lesson 02: The Four Morphometric Features
- Basic understanding of frequencies, counts, and percentages

## Biological and Real-World Context
In nature, species abundances are rarely equal. An Antarctic island might host 50,000 breeding pairs of Adelie penguins but only 200 pairs of Gentoos. If field biologists surveyed birds purely at random, raw observational counts would be heavily skewed towards the dominant species.

When training machine learning classifiers, severe **class imbalance** poses serious challenges: models can achieve deceptively high accuracy by simply predicting the majority class for every sample, while completely failing to identify the rare class. In this curated dataset, however, researchers selected an equal quota of 50 specimens per species to create a clean, balanced benchmark for comparative pattern recognition.

## Concept Explanation
Let us inspect the class distribution of `species` in `data/penguins.csv` using pandas' `.value_counts()` method:

```python
>>> df["species"].value_counts()
species
Gentoo       50
Adelie       50
Chinstrap    50
Name: count, dtype: int64
```

Observations:
- Total samples: $150$
- Number of classes: $3$
- Adelie count: $50$ ($33.33\%$)
- Chinstrap count: $50$ ($33.33\%$)
- Gentoo count: $50$ ($33.33\%$)

This is a **perfectly balanced multi-class dataset**.
Why does this matter?
1. **Unbiased Baseline**: A trivial "dummy classifier" that always guesses the same species will achieve exactly $\frac{1}{3} = 33.33\%$ accuracy. Any trained model achieving $>90\%$ accuracy is demonstrating genuine learned pattern discrimination.
2. **Equal Representation in Geometry**: In instance-based algorithms like KNN, class priors do not distort neighbor voting. If classes were imbalanced (e.g., 90 Adelies and 5 Gentoos), majority voting would consistently favor Adelie merely due to density of neighbors rather than geometric proximity.
3. **Symmetric Error Costs**: We can evaluate the model using standard accuracy without immediately needing specialized cost-sensitive resampling techniques (like SMOTE).

## Relevant Code (from main.py)
```python
# Lines 35, 37-39 of main.py
y = df["species"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)
```

## Code Explanation
- `y = df["species"]` stores the class labels for all 150 instances.
- The parameter `stratify=y` explicitly instructs scikit-learn to preserve this exact equal balance when dividing the dataset into training and testing partitions.
- Without stratification, random sampling might pull disproportionately more of one species into the test set by chance.

## Worked Example
Suppose an imbalanced dataset contains 95 Adelie penguins and 5 Gentoo penguins (100 total):
- A lazy model that always outputs `"Adelie"` without looking at measurements achieves **95% accuracy**!
- However, its recall for Gentoo is **0%**—it fails completely at identifying the rare species.
- In our balanced dataset (50 Adelie, 50 Chinstrap, 50 Gentoo), that same lazy model would achieve only **33.3% accuracy**.
- Therefore, our model's actual test accuracy of **94.7%** reflects genuine, high-fidelity classification across all three species.

## Step-by-Step Student Instructions
1. Load `data/penguins.csv` in Python.
2. Run `df['species'].value_counts()` to verify the exact counts for each species.
3. Calculate the proportion of each class using `df['species'].value_counts(normalize=True)`.
4. Confirm that each species accounts for exactly one-third ($0.3333$) of the dataset.
5. Reflect on how class balance simplifies evaluation and prevents majority-class bias in KNN voting.

## Expected Output or Observable Behaviour
```text
>>> df['species'].value_counts(normalize=True)
species
Gentoo       0.333333
Adelie       0.333333
Chinstrap    0.333333
Name: proportion, dtype: float64
```
The normalized proportions show an exact $1:1:1$ distribution across all three species.

## Practical Exercises
- **Exercise 3.1**: Compute the baseline random-guessing accuracy for a balanced 3-class dataset.
- **Exercise 3.2**: If a new dataset had 120 Adelie, 20 Chinstrap, and 10 Gentoo, what would the dummy majority-class accuracy be?
- **Exercise 3.3**: Why is instance-based KNN particularly sensitive to severe class imbalance?

## Common Mistakes and Debugging
- **Assuming accuracy alone is sufficient for imbalanced datasets**: When working with imbalanced data, high accuracy is often misleading; always examine precision, recall, and confusion matrices.
- **Ignoring class balance when splitting data**: Forgetting to check class distribution before splitting can result in test sets with zero representatives of a rare class.
- **Treating balanced sample quotas as natural population counts**: Remember that equal sample counts in research datasets often reflect deliberate sampling quotas, not actual ecological population ratios in the wild.

## Best Practices and Security Considerations
- **Always Check Target Value Counts**: Run `value_counts()` as the very first exploratory step on any categorical target.
- **Document Sampling Strategies**: Note whether dataset balance was achieved through stratified field collection, downsampling, or natural population parity.
- **Stratified Partitioning**: Always pair balanced or imbalanced categorical targets with stratified splitting during validation.

## Summary and Key Takeaways
- `penguins.csv` contains exactly 50 samples of each species: Adelie, Chinstrap, and Gentoo.
- Perfect class balance sets the random-guessing baseline accuracy at $33.33\%$.
- Balanced classes prevent KNN majority voting from developing an artificial bias towards overrepresented classes.
- Stratified sampling ensures that this balanced distribution is preserved across both training and test partitions.

## Knowledge-check Questions
1. How many total instances of each penguin species are present in `penguins.csv`?
2. What percentage of the overall dataset does each species represent?
3. What accuracy would a baseline model achieve by always guessing "Adelie"?
4. Why is KNN particularly vulnerable to skewed class distributions?
5. What scikit-learn parameter preserves class balance during data splitting?

## References
- He H, Garcia EA (2009) Learning from Imbalanced Data. *IEEE Transactions on Knowledge and Data Engineering* 21(9): 1263-1284.
- scikit-learn Model Evaluation Guide: https://scikit-learn.org/stable/modules/model_evaluation.html
- Palmer Station Penguin Ecology Research: https://pallter.marine.rutgers.edu/
