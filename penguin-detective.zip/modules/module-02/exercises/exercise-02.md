# Module 2 Exercises: Data Exploration, Features & Splitting

## Exercise 2.1: Dataset Inspection and Feature Slicing (15 min)
**Objective:** Load `penguins.csv`, verify dimensions, and slice $X$ and $y$.
**Problem Statement:** Load the Palmer Penguins dataset and confirm that the feature matrix $X$ contains only the 4 specified numerical columns and has the expected 2D shape.

**Requirements:**
1. Load `data/penguins.csv` using pandas.
2. Verify total shape is `(150, 5)`.
3. Slicing with `FEATURES = ["bill_length_mm", "bill_depth_mm", "flipper_length_mm", "body_mass_g"]`, extract $X$.
4. Extract $y$ from `df["species"]`.
5. Print `X.shape` and `y.shape`.

**Acceptance Criteria:**
- [ ] DataFrame successfully loaded.
- [ ] $X$ shape verified as `(150, 4)`.
- [ ] $y$ shape verified as `(150,)`.
- [ ] No null values identified in any column.

---

## Exercise 2.2: Feature Scale and Variance Disparity (15 min)
**Objective:** Calculate summary statistics to prove why feature standardization is required.
**Problem Statement:** Compute the mean, minimum, maximum, and standard deviation for `bill_depth_mm` and `body_mass_g`. Calculate the ratio of their standard deviations.

**Requirements:**
1. Compute `.describe()` for `bill_depth_mm` and `body_mass_g`.
2. Compute the range (max - min) for both features.
3. Calculate the ratio $\frac{\sigma_{\text{mass}}}{\sigma_{\text{depth}}}$.
4. Write a brief statement explaining the implications for Euclidean distance.

**Acceptance Criteria:**
- [ ] Range of `bill_depth_mm` calculated as $7.4\text{ mm}$ ($21.0 - 13.6$).
- [ ] Range of `body_mass_g` calculated as $3,067\text{ g}$ ($6,026 - 2,959$).
- [ ] Standard deviation ratio calculated as approximately $\frac{722.08}{1.81} \approx 398.9$.
- [ ] Clear explanation that unscaled distance would be 99.9% dominated by body mass.

---

## Exercise 2.3: Stratified Partition Verification (15 min)
**Objective:** Execute `train_test_split` and verify stratified class distributions.
**Problem Statement:** Split the dataset using `test_size=0.25`, `random_state=42`, and `stratify=y`. Verify sample counts for both partitions.

**Requirements:**
1. Perform the split using scikit-learn.
2. Confirm `X_train` has 112 rows and `X_test` has 38 rows.
3. Count class occurrences in `y_test`.
4. Verify counts: 13 Chinstrap, 13 Gentoo, 12 Adelie.

**Acceptance Criteria:**
- [ ] Split executed with exact parameters.
- [ ] Sample sizes 112 and 38 verified.
- [ ] Class counts in test set verified as 12 Adelie, 13 Chinstrap, 13 Gentoo.
