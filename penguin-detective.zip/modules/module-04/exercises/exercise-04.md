# Module 4 Exercises: Pipelines, Confidence & Inference

## Exercise 4.1: Manual Z-Score Calculation (15 min)
**Objective:** Calculate $z$-scores manually and verify matching output with `StandardScaler`.
**Problem Statement:** Given a training feature with mean $\mu = 44.82$ and standard deviation $\sigma = 5.28$, compute the standardized value $z$ for raw values $x_1 = 39.0$, $x_2 = 44.82$, and $x_3 = 50.10$.

**Requirements:**
1. Compute $z_1 = \frac{39.0 - 44.82}{5.28}$.
2. Compute $z_2 = \frac{44.82 - 44.82}{5.28}$.
3. Compute $z_3 = \frac{50.10 - 44.82}{5.28}$.
4. State the biological interpretation of each $z$-score.

**Acceptance Criteria:**
- [ ] $z_1$ computed as approximately $-1.10$ (1.10 standard deviations below mean).
- [ ] $z_2$ computed as exactly $0.00$ (exactly average).
- [ ] $z_3$ computed as approximately $+1.00$ (1.00 standard deviation above mean).

---

## Exercise 4.2: Building an End-to-End Pipeline (15 min)
**Objective:** Construct, fit, and query an scikit-learn Pipeline.
**Problem Statement:** Write a Python script that builds a Pipeline combining `StandardScaler` and `KNeighborsClassifier(n_neighbors=3)`. Fit the pipeline on `X_train` and `y_train`, and inspect the fitted steps.

**Requirements:**
1. Import `Pipeline`, `StandardScaler`, and `KNeighborsClassifier`.
2. Construct the pipeline with step names `"scale"` and `"knn"`.
3. Fit on training data.
4. Print `model.named_steps["scale"].mean_` and `model.named_steps["knn"].classes_`.

**Acceptance Criteria:**
- [ ] Pipeline constructed correctly.
- [ ] `mean_` array printed with 4 values.
- [ ] `classes_` printed as `['Adelie', 'Chinstrap', 'Gentoo']`.

---

## Exercise 4.3: Classifying Novel Penguin Specimens (15 min)
**Objective:** Create multiple query specimens and analyze class predictions and confidence scores.
**Problem Statement:** Construct query DataFrames for two distinct hypothetical penguins and report their predicted species and confidence percentages:
- Specimen A: `[bill_length=50.0, bill_depth=15.0, flipper=220, body_mass=5200]`
- Specimen B: `[bill_length=49.0, bill_depth=19.0, flipper=195, body_mass=3700]`

**Requirements:**
1. Define each specimen as a 1-row pandas DataFrame.
2. Call `best_model.predict()` and `best_model.predict_proba()`.
3. Format outputs as `{species} ({confidence:.0%} confident)`.

**Acceptance Criteria:**
- [ ] Specimen A classified as Gentoo (100% confident).
- [ ] Specimen B classified as Chinstrap (100% confident).
- [ ] Biological rationale provided for both classifications.
