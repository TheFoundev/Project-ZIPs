# Lesson 02: Building and Fitting an `sklearn.pipeline.Pipeline`

**Lesson ID:** lesson-02
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Construct composite machine learning workflows using `sklearn.pipeline.Pipeline`
- Explain the role of sequential transformers and final estimators in a pipeline
- Describe how pipelines prevent data leakage during training, cross-validation, and inference
- Execute `.fit()` and `.predict()` through unified pipeline objects

## Prerequisites
- Lesson 01: Feature Scaling & `StandardScaler` in Distance-Based Models
- Understanding of Python lists of tuples and object-oriented interfaces

## Biological and Real-World Context
In automated polar environmental monitoring, data pipelines are deployed on embedded edge devices at weather stations or autonomous observation drones. If an algorithm requires manual multi-step processing—first running a script to scale data, saving temporary files, and then loading those files into another classification script—the process is brittle and prone to catastrophic crashes in remote environments.

An scikit-learn `Pipeline` packages the entire data transformation and classification lifecycle into a single, cohesive, self-contained software object. Feeding raw measurements into the pipeline produces an immediate species prediction with zero intermediate manual steps.

## Concept Explanation
An scikit-learn `Pipeline` chains together multiple data processing steps sequentially. Each intermediate step must be a **transformer** (an object implementing `.fit()` and `.transform()`), and the final step must be an **estimator** or **classifier** (an object implementing `.fit()` and `.predict()`).

### Anatomy of a Pipeline
In `main.py`, the pipeline is constructed as follows:

```python
model = Pipeline(
    [
        ("scale", StandardScaler()),
        ("knn", KNeighborsClassifier(n_neighbors=k)),
    ]
)
```

The pipeline constructor accepts a list of `(name, object)` 2-tuples:
1. `("scale", StandardScaler())`: The preprocessing stage. Named `"scale"` for convenient reference.
2. `("knn", KNeighborsClassifier(n_neighbors=k))`: The classification stage. Named `"knn"`.

### The Lifecycle of `Pipeline.fit()`
When `model.fit(X_train, y_train)` is called:
1. The pipeline passes `X_train` to `StandardScaler.fit_transform(X_train)`.
2. The scaler computes $\mu$ and $\sigma$ for each feature and returns the standardized array `X_train_scaled`.
3. The pipeline passes `X_train_scaled` along with `y_train` to `KNeighborsClassifier.fit(X_train_scaled, y_train)`.
4. The KNN estimator stores the scaled training coordinates and labels in memory.

### The Lifecycle of `Pipeline.predict()`
When `model.predict(X_test)` or `model.predict(new_penguin)` is called:
1. The pipeline automatically calls `StandardScaler.transform(X_test)` using the previously learned $\mu$ and $\sigma$.
2. It forwards the resulting scaled coordinates to `KNeighborsClassifier.predict()`.
3. The KNN classifier outputs the predicted species strings.

## Relevant Code (from main.py)
```python
# Lines 20, 43-49 of main.py
from sklearn.pipeline import Pipeline

model = Pipeline(
    [
        ("scale", StandardScaler()),
        ("knn", KNeighborsClassifier(n_neighbors=k)),
    ]
)
model.fit(X_train, y_train)
predictions = model.predict(X_test)
```

## Code Explanation
- `from sklearn.pipeline import Pipeline` imports the pipeline factory class.
- The pipeline encapsulates both scaling and classification behind standard scikit-learn estimator methods: `.fit()`, `.predict()`, and `.predict_proba()`.
- Raw, unscaled data (`X_train`, `X_test`, `new_penguin`) is passed directly to the pipeline. The pipeline handles internal scaling transformations transparently.
- This design completely eliminates manual scaling code and ensures that test data cannot leak into the training process.

## Worked Example
Let us trace what occurs under the hood when a single query row is passed to the fitted pipeline:

```python
new_penguin = pd.DataFrame([{
    "bill_length_mm": 39.0,
    "bill_depth_mm": 18.0,
    "flipper_length_mm": 190.0,
    "body_mass_g": 3700.0,
}])

species = model.predict(new_penguin)
```

Step 1: The pipeline intercepts `new_penguin` and invokes `model.named_steps['scale'].transform(new_penguin)`.
- It subtracts training means: `[44.82, 17.28, 200.45, 4153.23]`.
- It divides by training standard deviations: `[5.28, 1.81, 12.48, 722.08]`.
- Output scaled vector: `[-1.10, +0.40, -0.84, -0.63]`.

Step 2: The pipeline passes this scaled vector to `model.named_steps['knn'].predict()`.
- The classifier searches its 112 stored points and identifies the 3 closest points.
- Output: `array(['Adelie'], dtype=object)`.

The developer never has to manually touch or compute $z$-scores; the pipeline manages the end-to-end transformation flawlessly.

## Step-by-Step Student Instructions
1. Import `Pipeline` from `sklearn.pipeline`.
2. Construct a pipeline chaining `StandardScaler` and `KNeighborsClassifier(n_neighbors=3)`.
3. Train the pipeline using `model.fit(X_train, y_train)`.
4. Inspect the individual steps using `model.named_steps`.
5. Access the fitted scaler parameters using `model.named_steps['scale'].mean_`.
6. Call `model.predict(X_test)` and verify that predictions are returned as an array of species names.

## Expected Output or Observable Behaviour
```python
>>> model.named_steps
{'scale': StandardScaler(), 'knn': KNeighborsClassifier(n_neighbors=3)}
>>> model.named_steps['knn'].classes_
array(['Adelie', 'Chinstrap', 'Gentoo'], dtype=object)
```
The pipeline confirms its internal composition and shows that the classifier has indexed the three target classes.

## Practical Exercises
- **Exercise 2.1**: Access the internal KNN model inside the pipeline and print the number of features it was fitted on using `.n_features_in_`.
- **Exercise 2.2**: What happens if you pass a DataFrame with columns in a different order to `model.predict()`? Verify whether scikit-learn matches columns by name or position.
- **Exercise 2.3**: Why is using a Pipeline particularly critical when performing cross-validation (e.g., `cross_val_score`)?

## Common Mistakes and Debugging
- **Passing estimators as intermediate steps**: Trying to place a classifier in the first step of a pipeline. All steps except the final one must implement both `fit` and `transform`.
- **Formatting step tuples incorrectly**: Supplying a dictionary instead of a list of `(name, object)` tuples. A dictionary does not preserve execution order in older Python versions and raises a `TypeError` in scikit-learn.
- **Scaling data outside the pipeline**: Manually scaling `X` before passing it to the pipeline, causing the pipeline's internal scaler to scale already-scaled data a second time.

## Best Practices and Security Considerations
- **Name Steps Descriptively**: Use concise, intuitive names for steps (e.g., `"scale"` and `"knn"`) to allow clean parameter referencing in hyperparameter grid searches (e.g., `"knn__n_neighbors"`).
- **Encapsulate Preprocessing**: Keep all data transformation steps inside the pipeline to ensure identical preprocessing logic is applied during training and deployment.
- **Model Serialization**: When saving a trained model to disk using `joblib` or `pickle`, serialize the entire `Pipeline` object so that the scaler and classifier remain bound together.

## Summary and Key Takeaways
- Scikit-learn's `Pipeline` bundles sequential preprocessing transformers and a final estimator into a single unified object.
- The pipeline executes `fit_transform` on intermediate steps during training, and `transform` during inference.
- Using pipelines prevents data leakage and ensures clean, reproducible, production-ready code.
- In `main.py`, the pipeline encapsulates `StandardScaler` and `KNeighborsClassifier`, allowing raw DataFrames to be passed directly to `fit()` and `predict()`.

## Knowledge-check Questions
1. What methods must an intermediate step in a Pipeline implement?
2. What structure is used to define steps when creating a Pipeline?
3. How does a Pipeline prevent data leakage during model training?
4. How can you access an individual step inside a fitted pipeline object?
5. What happens automatically to a raw test sample when `pipeline.predict()` is called?

## References
- scikit-learn Pipeline User Guide: https://scikit-learn.org/stable/modules/compose.html#pipeline
- Buitinck L, et al. (2013) API design for machine learning software: experiences from the scikit-learn project. *ECML PKDD*.
- Joblib Model Persistence: https://scikit-learn.org/stable/modules/model_persistence.html
