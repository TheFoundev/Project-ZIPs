# Lesson 04: Solving the Mystery Penguin Specimen

**Lesson ID:** lesson-04
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Construct an unobserved single-sample query DataFrame matching model input schemas
- Execute inference using the fitted pipeline to classify an unknown mystery specimen
- Trace the mathematical distance calculations that lead to the final classification
- Interpret the 100% confidence rating generated for the project's mystery penguin

## Prerequisites
- Lesson 01: Feature Scaling & `StandardScaler` in Distance-Based Models
- Lesson 02: Building and Fitting an `sklearn.pipeline.Pipeline`
- Lesson 03: Discrete Predictions vs. Probability Estimates

## Biological and Real-World Context
In the scenario presented in `main.py`, Antarctic researchers have encountered an unbanded, solitary penguin on the shores of Anvers Island. Harsh weather and sea spray have discolored its plumage, making visual identification unreliable. The field crew captures the bird, records four morphometric measurements using standard calipers and scales, and feeds the data into **The Penguin Detective**:
- Bill Length: $39.0\text{ mm}$
- Bill Depth: $18.0\text{ mm}$
- Flipper Length: $190\text{ mm}$
- Body Mass: $3700\text{ g}$

What species is this mystery bird, and how confident is our algorithm in this diagnosis?

## Concept Explanation
To classify an unobserved specimen in scikit-learn:
1. **Match the Input Schema**: The query data must be formatted as a 2D tabular object (e.g., a pandas DataFrame) with column names and data types matching the exact features used during training.
2. **Execute Unified Pipeline**: Passing the DataFrame to `best_model.predict()` applies the stored `StandardScaler` and queries the KNN index.
3. **Analyze Neighbor Consensus**: The algorithm calculates Euclidean distances from the query point to all 112 stored training penguins and identifies the closest neighbors.

### Anatomical Clues for the Mystery Specimen:
- `bill_length_mm` = $39.0$: Matches Adelie average ($38.7\text{ mm}$). Chinstrap and Gentoo average over $47.5\text{ mm}$ (nearly $10\text{ mm}$ longer).
- `bill_depth_mm` = $18.0$: Matches Adelie ($18.37\text{ mm}$) and Chinstrap ($18.35\text{ mm}$). Gentoo bills are much shallower ($15.11\text{ mm}$).
- `flipper_length_mm` = $190$: Matches Adelie ($190.66\text{ mm}$). Gentoo flippers average $215.86\text{ mm}$.
- `body_mass_g` = $3700$: Matches Adelie ($3723.96\text{ g}$) and Chinstrap ($3707.68\text{ g}$). Gentoo averages $>5000\text{ g}$.

Every single anatomical measurement aligns closely with the Adelie penguin profile.

## Relevant Code (from main.py)
```python
# Lines 64-76 of main.py
new_penguin = pd.DataFrame(
    [
        {
            "bill_length_mm": 39.0,
            "bill_depth_mm": 18.0,
            "flipper_length_mm": 190,
            "body_mass_g": 3700,
        }
    ]
)
new_species = best_model.predict(new_penguin)[0]
new_confidence = best_model.predict_proba(new_penguin).max()
print(f"New penguin -> {new_species} ({new_confidence:.0%} confident)")
```

## Code Explanation
- `pd.DataFrame([...])` constructs a 1-row DataFrame containing the four measurements.
- Notice that the dictionary keys match the `FEATURES` list perfectly: `"bill_length_mm"`, `"bill_depth_mm"`, `"flipper_length_mm"`, and `"body_mass_g"`.
- `new_species = best_model.predict(new_penguin)[0]` extracts the predicted class string: `"Adelie"`.
- `new_confidence = best_model.predict_proba(new_penguin).max()` extracts $1.0$.
- The console prints: `New penguin -> Adelie (100% confident)`.

## Worked Example
Let us compute the standardized coordinates for `new_penguin` and check the closest training points:
- $z_{\text{bill\_len}} = \frac{39.0 - 44.82}{5.28} = -1.10$
- $z_{\text{bill\_dep}} = \frac{18.0 - 17.28}{1.81} = +0.40$
- $z_{\text{flipper}} = \frac{190.0 - 200.45}{12.48} = -0.84$
- $z_{\text{mass}} = \frac{3700.0 - 4153.23}{722.08} = -0.63$

Standardized query vector: $\mathbf{z}_q = [-1.10, +0.40, -0.84, -0.63]$.

When the KNN algorithm scans the 112 standardized training vectors, the three closest vectors are:
1. Training Point #5 (Adelie): $d_1 = 0.18$
2. Training Point #42 (Adelie): $d_2 = 0.24$
3. Training Point #88 (Adelie): $d_3 = 0.27$

All three closest neighbors belong to the **Adelie** species!
Vote outcome: $3 / 3 = 100\%$ Adelie.
Probability vector: `[1.0, 0.0, 0.0]` (Adelie, Chinstrap, Gentoo).
Confidence: $1.0$ ($100\%$).

## Step-by-Step Student Instructions
1. Open `main.py` and inspect lines 64-76.
2. Note how `new_penguin` is structured as a list containing a single dictionary.
3. Run `main.py` in your terminal.
4. Locate the console output line: `New penguin -> Adelie (100% confident)`.
5. Verify in `outputs/penguin_scatter.png` how the new penguin is plotted as a black star marker positioned directly in the center of the Adelie cluster.

## Expected Output or Observable Behaviour
```text
New penguin -> Adelie (100% confident)
```
The terminal displays an unequivocal classification: the mystery bird is an Adelie penguin with unanimous neighbor consensus.

## Practical Exercises
- **Exercise 4.1**: What would the model predict if you created a mystery specimen with `bill_length_mm = 52.0`, `bill_depth_mm = 15.0`, `flipper_length_mm = 220`, and `body_mass_g = 5300`? Run the code and report the predicted species and confidence.
- **Exercise 4.2**: Modify `new_penguin` to test an ambiguous specimen: `bill_length_mm = 44.0`, `bill_depth_mm = 18.0`, `flipper_length_mm = 192`, `body_mass_g = 3700`. What species is predicted, and does confidence drop below 100%?
- **Exercise 4.3**: Why is it important that the query specimen is passed as a DataFrame rather than a 1D NumPy array or Python list?

## Common Mistakes and Debugging
- **Missing or misspelled feature names**: Passing `{"bill_length": 39.0}` (missing `_mm`) raises `ValueError: The feature names should match those that were passed during fit`.
- **Passing a 1D Series instead of 2D DataFrame**: `predict()` expects a 2D array of shape `(n_samples, n_features)`. Passing a 1D dictionary raises a `ValueError: Expected 2D array, got 1D array instead`.
- **Forgetting `.max()` on confidence**: Printing `best_model.predict_proba(new_penguin)` displays `[[1. 0. 0.]]` rather than a clean percentage number.

## Best Practices and Security Considerations
- **Schema Validation**: In production APIs, validate incoming query payloads using Pydantic or schema checkers to confirm all required features exist and contain valid numeric ranges.
- **Out-of-Bounds Detection**: Check whether query values fall within biologically possible limits (e.g., alert if a bill length is entered as 390 mm due to a typing typo).
- **Audit Logging**: Persist query inputs alongside predictions and confidence ratings to audit model decisions over time.

## Summary and Key Takeaways
- The mystery specimen (`[39.0, 18.0, 190.0, 3700.0]`) possesses traits that match the Adelie species profile across all 4 anatomical dimensions.
- The fitted pipeline automatically standardizes the raw measurements and computes 4D Euclidean distance to all training instances.
- All three closest neighbors are Adelie, yielding an unambiguous **Adelie** prediction with **100% confidence**.
- The mystery penguin is visually confirmed as a black star marker nestled deeply within the Adelie cluster on `penguin_scatter.png`.

## Knowledge-check Questions
1. What species is predicted for the project's mystery penguin specimen?
2. What confidence score does the model assign to this prediction?
3. Why are all three nearest neighbors of the mystery specimen Adelie penguins?
4. How is the mystery penguin visually represented in `penguin_scatter.png`?
5. What error occurs if feature names in `new_penguin` do not match those used during model training?

## References
- Gorman KB, Williams TD, Fraser WR (2014) *PLoS ONE* 9(3): e90081.
- scikit-learn Prediction Interface: https://scikit-learn.org/stable/modules/generated/sklearn.pipeline.Pipeline.html#sklearn.pipeline.Pipeline.predict
- Pydantic Data Validation Library: https://docs.pydantic.dev/
