# Lesson 01: Feature Scaling & `StandardScaler` in Distance-Based Models

**Lesson ID:** lesson-01
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why distance-based algorithms like KNN require feature scaling
- Calculate $z$-scores manually using the standardization formula $z = \frac{x - \mu}{\sigma}$
- Explain how `StandardScaler` transforms features to have zero mean ($\mu = 0$) and unit variance ($\sigma = 1$)
- Identify the consequences of training KNN on unstandardized data with heterogeneous units

## Prerequisites
- Module 03: KNN Algorithm & Hyperparameter Tuning
- Basic algebra: sample mean ($\mu$) and standard deviation ($\sigma$)

## Biological and Real-World Context
In field biology, animals are measured using whatever physical units make human sense: a bird's beak is measured in millimeters using handheld calipers, while its overall body weight is measured in grams or kilograms using a hanging spring scale.

However, a mathematical algorithm like K-Nearest Neighbours possesses no biological intuition about units. It does not know that $1\text{ mm}$ of beak length represents a substantial evolutionary difference, while $1\text{ g}$ of body weight is an imperceptible fluctuation (less than the weight of a single Antarctic snowflake). Without scaling, an algorithm blindly equates $1\text{ mm}$ of bill length with $1\text{ g}$ of weight, distorting the biology completely.

## Concept Explanation
**Standardization** (or $z$-score normalization) rescales the distribution of each feature independently so that its mean becomes $0$ and its standard deviation becomes $1$.

### The Mathematical Formula
For any feature value $x$:

$$z = \frac{x - \mu}{\sigma}$$

Where:
- $x$ is the raw measurement value.
- $\mu$ is the mean of that feature across the training set: $\mu = \frac{1}{N} \sum_{i=1}^N x_i$.
- $\sigma$ is the standard deviation across the training set: $\sigma = \sqrt{\frac{1}{N} \sum_{i=1}^N (x_i - \mu)^2}$.

### Why Standardization Solves Scale Distortion
When every feature is transformed into a $z$-score:
1. A value of $z = 0$ represents an organism that is exactly average for that trait.
2. A value of $z = +1.5$ means the measurement is $1.5$ standard deviations above the population mean.
3. A value of $z = -2.0$ means the measurement is $2.0$ standard deviations below the population mean.

Because all four dimensions are expressed in dimensionless standard deviation units, a $1$-unit shift in bill depth carries identical geometric weight to a $1$-unit shift in body mass.

## Relevant Code (from main.py)
```python
# Lines 21, 45 of main.py
from sklearn.preprocessing import StandardScaler

model = Pipeline(
    [
        ("scale", StandardScaler()),
        ("knn", KNeighborsClassifier(n_neighbors=k)),
    ]
)
```

## Code Explanation
- `StandardScaler` is imported from `sklearn.preprocessing`.
- When `model.fit(X_train, y_train)` is executed, the pipeline calls `StandardScaler.fit_transform(X_train)`:
  - It computes and stores the mean `mean_` and standard deviation `scale_` for all 4 features on `X_train`.
  - It subtracts the mean and divides by standard deviation, replacing the raw data matrix with standardized $z$-scores.
- When new data is evaluated (`model.predict(X_test)`), the pipeline automatically applies `StandardScaler.transform(X_test)` using the stored parameters from the training set.

## Worked Example
Let us compute the $z$-score for a penguin whose raw measurements are:
- `bill_length_mm` = $39.0\text{ mm}$
- `body_mass_g` = $3700.0\text{ g}$

Given the training dataset population statistics:
- $\mu_{\text{bill}} = 44.82\text{ mm}$, $\sigma_{\text{bill}} = 5.28\text{ mm}$
- $\mu_{\text{mass}} = 4153.23\text{ g}$, $\sigma_{\text{mass}} = 722.08\text{ g}$

Calculate $z$-scores:
1. $z_{\text{bill}} = \frac{39.0 - 44.82}{5.28} = \frac{-5.82}{5.28} \approx \mathbf{-1.10}$ (The bill is $1.10$ standard deviations shorter than average).
2. $z_{\text{mass}} = \frac{3700.0 - 4153.23}{722.08} = \frac{-453.23}{722.08} \approx \mathbf{-0.63}$ (The mass is $0.63$ standard deviations below average).

Both numbers are now directly comparable on the same mathematical scale between $-3$ and $+3$. In Euclidean distance calculations, neither feature dwarfs the other.

## Step-by-Step Student Instructions
1. Import `StandardScaler` from `sklearn.preprocessing`.
2. Instantiate `scaler = StandardScaler()`.
3. Fit the scaler on `X_train`: `scaler.fit(X_train)`.
4. Inspect `scaler.mean_` and confirm it contains 4 values matching the training column means.
5. Inspect `scaler.scale_` (the standard deviations).
6. Transform `X_train` into `X_scaled = scaler.transform(X_train)`.
7. Verify that `X_scaled[:, 0].mean()` is approximately $0.0$ and `X_scaled[:, 0].std()` is approximately $1.0$.

## Expected Output or Observable Behaviour
```python
>>> scaler.mean_
array([  44.81533333,   17.27666667,  200.45333333, 4153.22666667])
>>> X_scaled.mean(axis=0)
array([ 0.,  0.,  0.,  0.])  # within floating-point epsilon (1e-16)
>>> X_scaled.std(axis=0)
array([1., 1., 1., 1.])
```
All four features now share identical zero-centered, unit-variance distributions.

## Practical Exercises
- **Exercise 1.1**: If a Gentoo penguin has a body mass of $5500\text{ g}$, calculate its standardized $z$-score given $\mu = 4153.23$ and $\sigma = 722.08$.
- **Exercise 1.2**: Contrast `StandardScaler` ($z$-score) with `MinMaxScaler` (bounding between 0 and 1). Which method is more resilient to extreme outliers?
- **Exercise 1.3**: Explain what happens if you apply `fit_transform` on the test set instead of `transform`.

## Common Mistakes and Debugging
- **Calling `fit` on test data**: Running `scaler.fit_transform(X_test)` recomputes the mean and variance on the test set, creating inconsistent coordinates relative to the training set. Always use `scaler.transform(X_test)`.
- **Forgetting that scaling is required for KNN**: Assuming that scaling is only for neural networks. KNN is arguably the most scale-sensitive algorithm in machine learning because its entire logic depends on geometric Euclidean distance.
- **Scaling the target variable $y$**: Attempting to pass `y` to `StandardScaler`. Categorical string labels cannot and must not be standardized.

## Best Practices and Security Considerations
- **Use Pipelines to Automate Transformation**: Enclosing `StandardScaler` inside an scikit-learn `Pipeline` automatically handles `fit` vs `transform` calls, eliminating human error.
- **Check for Zero Variance**: If a feature has zero variance (all values identical), division by $\sigma = 0$ results in `NaN`. Scikit-learn handles zero variance by setting scale to 1.0, but constant features should be eliminated during EDA.
- **Never Invert Scales for Interpretability Without Preserving Model State**: Keep raw DataFrames intact for human reporting and use scaled arrays strictly for model computation.

## Summary and Key Takeaways
- Distance-based algorithms like KNN are highly sensitive to differing feature scales and measurement units.
- `StandardScaler` rescales features to zero mean and unit variance using the formula $z = (x - \mu) / \sigma$.
- In `penguins.csv`, scaling prevents `body_mass_g` (thousands of grams) from numerically dominating `bill_depth_mm` (tens of millimeters).
- Scaling parameters must be learned exclusively on training data and subsequently applied to test and inference specimens.

## Knowledge-check Questions
1. What is the mathematical formula for computing a $z$-score?
2. What are the mean and standard deviation of a feature after applying `StandardScaler`?
3. Why does unscaled body mass in grams distort KNN distance calculations?
4. What is the difference between `scaler.fit()` and `scaler.transform()`?
5. Why must `scaler.fit()` never be executed on test data?

## References
- scikit-learn Preprocessing Guide: https://scikit-learn.org/stable/modules/preprocessing.html#standardization-or-mean-removal-and-variance-scaling
- Aksoy S, Haralick RM (2001) Feature normalization and likelihood-based similarity measures for image retrieval. *Pattern Recognition Letters* 22(5): 563-582.
- Data Leakage in Machine Learning (Kaufman et al., 2012).
