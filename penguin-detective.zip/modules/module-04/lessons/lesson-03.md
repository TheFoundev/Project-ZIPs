# Lesson 03: Discrete Predictions vs. Probability Estimates (`predict()` vs. `predict_proba()`)

**Lesson ID:** lesson-03
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Contrast discrete categorical predictions (`predict()`) with continuous class probability estimates (`predict_proba()`)
- Explain how KNN calculates class posterior probabilities from neighbor voting fractions
- Identify how scikit-learn maps probability arrays to the alphabetical order of `classes_`
- Compute model prediction confidence using `.max()` on predicted probability arrays

## Prerequisites
- Lesson 01: Feature Scaling & `StandardScaler` in Distance-Based Models
- Lesson 02: Building and Fitting an `sklearn.pipeline.Pipeline`
- Basic understanding of fractions and percentages

## Biological and Real-World Context
In ecological conservation, an automated tool that only provides a single binary answer can be dangerous if taken at face value.
Consider two different field scenarios:
1. Scenario A: The classifier encounters an unambiguous penguin whose 3 nearest neighbors are all Gentoo. The model predicts **Gentoo** with **100% confidence**.
2. Scenario B: The classifier encounters an atypical penguin on the boundary between species; 2 neighbors are Adelie and 1 neighbor is Chinstrap. The model predicts **Adelie**, but with only **66.7% confidence**.

If a wildlife agency is deciding whether to relocate a rare bird, knowing that the model is only 66.7% confident alerts biologists to conduct physical DNA testing rather than blindly trusting the top prediction. Providing probability confidence estimates transforms machine learning from a black box into a transparent decision-support tool.

## Concept Explanation
Scikit-learn classifiers provide two primary methods for generating predictions:

### 1. `predict(X)`
- Returns a 1D array of **discrete class labels**.
- For each sample, it identifies the class that received the highest vote count (plurality voting).
- Output format: `array(['Adelie', 'Gentoo', ...])`.

### 2. `predict_proba(X)`
- Returns a 2D array of shape `(n_samples, n_classes)` containing **posterior class probabilities**.
- Each row represents a sample; each column represents the probability of belonging to a specific class.
- The columns correspond exactly to the sorted alphabetical order stored in `model.classes_`:
  - Column 0: Probability of **Adelie**
  - Column 1: Probability of **Chinstrap**
  - Column 2: Probability of **Gentoo**
- For KNN, the probability of class $C$ is simply the fraction of the $k$ nearest neighbors that belong to class $C$:

$$P(y = C \mid x) = \frac{1}{k} \sum_{i \in N_k(x)} \mathbb{I}(y_i = C)$$

Where $\mathbb{I}(\cdot)$ is the indicator function ($1$ if true, $0$ if false).
For $k=3$, the only possible probability values are $0.0$ ($0/3$), $0.333$ ($1/3$), $0.667$ ($2/3$), and $1.0$ ($3/3$).
For $k=5$, the possible probabilities are $0.0$, $0.20$, $0.40$, $0.60$, $0.80$, and $1.00$.

## Relevant Code (from main.py)
```python
# Lines 74-76 of main.py
new_species = best_model.predict(new_penguin)[0]
new_confidence = best_model.predict_proba(new_penguin).max()
print(f"New penguin -> {new_species} ({new_confidence:.0%} confident)")
```

## Code Explanation
- `best_model.predict(new_penguin)` outputs a 1-element array: `['Adelie']`.
- Indexing `[0]` extracts the string label `"Adelie"`.
- `best_model.predict_proba(new_penguin)` returns a 2D array of shape `(1, 3)`: `[[1.0, 0.0, 0.0]]`.
- `.max()` extracts the highest probability value in the row ($1.0$).
- `{new_confidence:.0%}` formats the float $1.0$ as a human-readable percentage: `100%`.

## Worked Example
Let us examine the output of `predict_proba` for three different test penguins under $k=3$:

| Penguin Case | Nearest Neighbors | `predict_proba()` Array | Winning Class (`predict()`) | Confidence (`.max()`) |
|---|---|---|---|---|
| **Specimen 1** | 3 Adelie | `[[1.0, 0.0, 0.0]]` | Adelie | **100%** |
| **Specimen 2** | 2 Chinstrap, 1 Adelie | `[[0.333, 0.667, 0.0]]` | Chinstrap | **67%** |
| **Specimen 3** | 3 Gentoo | `[[0.0, 0.0, 1.0]]` | Gentoo | **100%** |

Notice that the sum across all columns in any row is always strictly equal to $1.0$ ($100\%$):
$0.333 + 0.667 + 0.0 = 1.0$.

## Step-by-Step Student Instructions
1. In an interactive session with the fitted pipeline `best_model`, inspect `best_model.classes_`.
2. Verify that the classes are alphabetically ordered: `['Adelie', 'Chinstrap', 'Gentoo']`.
3. Create a query DataFrame with raw measurements.
4. Call `best_model.predict_proba(query_df)`.
5. Observe the 3-column output and verify that each entry represents the fraction of neighbors from that class.
6. Extract the maximum probability using `.max()`.

## Expected Output or Observable Behaviour
```python
>>> best_model.classes_
array(['Adelie', 'Chinstrap', 'Gentoo'], dtype=object)
>>> best_model.predict_proba(new_penguin)
array([[1., 0., 0.]])
>>> best_model.predict_proba(new_penguin).max()
1.0
```
The output confirms that all 3 nearest neighbors of `new_penguin` belong to the Adelie class, resulting in 100% confidence.

## Practical Exercises
- **Exercise 3.1**: If $k=5$ and a query penguin has 3 Gentoo neighbors and 2 Chinstrap neighbors, what will `predict_proba()` return?
- **Exercise 3.2**: Write a Python function that accepts a probability vector and returns both the predicted class name and its formatted confidence string.
- **Exercise 3.3**: Why can a KNN model with $k=3$ never output a confidence score of $75\%$?

## Common Mistakes and Debugging
- **Confusing column order in `predict_proba`**: Assuming column 0 is Gentoo because Gentoo was first in the CSV file. Scikit-learn always orders columns according to `model.classes_` (alphabetical order: Adelie, Chinstrap, Gentoo).
- **Forgetting that `predict_proba` returns a 2D array**: Writing `prob = model.predict_proba(x)[0]` returns the 1D probability vector across all classes; to get the maximum confidence, call `.max()` or extract the specific winning index.
- **Interpreting KNN probabilities as calibrated Bayesian probabilities**: KNN probabilities represent neighbor voting fractions, which can be overconfident or poorly calibrated in sparse regions of feature space.

## Best Practices and Security Considerations
- **Set Decision Thresholds**: For safety-critical classification, establish a confidence threshold (e.g., flag specimens with confidence $< 70\%$ for manual expert review).
- **Verify Sum to One**: Ensure that predicted probability arrays sum to $1.0$ across classes (`np.allclose(probs.sum(axis=1), 1.0)`).
- **Expose Confidence in User Interfaces**: Always present the confidence percentage alongside the discrete class label in user-facing reports.

## Summary and Key Takeaways
- `predict()` returns discrete winning class labels, while `predict_proba()` returns continuous probability distributions across all classes.
- For KNN, class probabilities equal the fraction of the $k$ nearest neighbors belonging to each class.
- Probability columns correspond to the alphabetical order in `model.classes_` (Adelie, Chinstrap, Gentoo).
- Calling `.max()` on the probability row yields the winning confidence score, which is formatted as `{new_confidence:.0%}` in `main.py`.

## Knowledge-check Questions
1. What does the output shape `(N, 3)` of `predict_proba` represent in a 3-class problem?
2. In what order are class probabilities arranged in scikit-learn's `predict_proba` array?
3. What are the possible probability values returned by a KNN classifier when $k=5$?
4. How is the confidence score calculated in `main.py` line 75?
5. Why is a confidence score of 67% more informative to an ecologist than simply outputting the class name "Adelie"?

## References
- scikit-learn Probability Calibration: https://scikit-learn.org/stable/modules/calibration.html
- Niculescu-Mizil A, Caruana R (2005) Predicting good probabilities with supervised learning. *ICML*.
- scikit-learn Classifier Interface: https://scikit-learn.org/stable/glossary.html#term-predict_proba
