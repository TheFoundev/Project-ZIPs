# Lesson 03: Morphometric Identification: Why Body Measurements Differentiate Species

**Lesson ID:** lesson-03
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain what morphometrics is and why it serves as the foundational data for organism classification
- Identify the four specific anatomical measurements utilized in the Palmer Penguins dataset
- Understand the biological adaptations reflected in bill length, bill depth, flipper length, and body mass
- Explain how natural selection creates distinct clusters in multi-dimensional feature space

## Prerequisites
- Lesson 01: The Antarctic Mystery & The Three Penguin Species
- Lesson 02: Classification vs. Regression in Ecological Machine Learning

## Biological and Real-World Context
In evolutionary biology, closely related species that inhabit the same geographical ecosystem (sympatric species) must minimize competition for limited food resources to coexist. This evolutionary pressure is known as **niche partitioning**.

Over millions of years, the three brush-tailed penguin species evolved distinct foraging strategies:
- **Adelies** specialize in catching surface-level Antarctic krill (*Euphausia superba*), requiring short, sturdy, high-depth bills to grasp small crustaceans.
- **Chinstraps** also hunt krill and squid, but feed at slightly different offshore zones and depths, reflected in significantly longer, sharp bills.
- **Gentoos** hunt both krill and benthic fish in deep coastal waters. To dive deeper and swim faster, Gentoos evolved substantially larger pectoral flippers and significantly heavier body mass, while maintaining a slender, streamlined bill depth to reduce underwater hydrodynamic drag.

Because these morphological traits are genetically inherited and conserved, physical body measurements serve as reliable biometric signatures.

## Concept Explanation
**Morphometrics** refers to the quantitative measurement of organismal size and shape. In **The Penguin Detective**, four continuous anatomical features capture the morphological variation among penguins:

| Feature | Unit | Anatomical Description | Biological Relevance |
|---|---|---|---|
| `bill_length_mm` | Millimeters | Length of the culmen (dorsal ridge of the upper mandible) | Reflects prey size, reach, and handling mechanism |
| `bill_depth_mm` | Millimeters | Vertical height of the bill base | Reflects crushing power and hydrodynamic drag |
| `flipper_length_mm` | Millimeters | Length from the wing joint to the tip of the longest feather | Determines propulsion power and deep-water diving capability |
| `body_mass_g` | Grams | Overall mass of the penguin | Reflects thermal insulation, energy reserves, and overall size |

When plotted in a multi-dimensional coordinate system where each measurement represents an axis, penguins of the same species cluster tightly together, while different species occupy distinct regions of the feature space.

## Relevant Code (from main.py)
```python
# Line 28 of main.py
FEATURES = ["bill_length_mm", "bill_depth_mm", "flipper_length_mm", "body_mass_g"]
```

## Code Explanation
- `FEATURES` is a Python list storing the four column names corresponding to the morphometric variables.
- Each feature is measured on a continuous numerical scale.
- Note the differing physical scales and units: three features are in millimeters (spanning tens to hundreds), while `body_mass_g` is in grams (spanning thousands).
- This list definition ensures modularity, making it easy to include, exclude, or reorder features across the pipeline.

## Worked Example
Let us compare the empirical mean values for each feature across the three species in the dataset:

| Species | Mean Bill Length (mm) | Mean Bill Depth (mm) | Mean Flipper Length (mm) | Mean Body Mass (g) |
|---|---|---|---|---|
| **Adelie** | 38.65 | 18.37 | 190.66 | 3,723.96 |
| **Chinstrap** | 48.22 | 18.35 | 194.84 | 3,707.68 |
| **Gentoo** | 47.57 | 15.11 | 215.86 | 5,028.04 |

Observations:
1. **Gentoo vs Others**: Gentoos have much larger flippers (215.86 mm vs ~191-195 mm), much higher mass (5,028 g vs ~3,710 g), and shallower bills (15.11 mm vs ~18.36 mm). They are immediately distinguishable.
2. **Adelie vs Chinstrap**: Adelies and Chinstraps have nearly identical body mass (~3,715 g) and bill depth (~18.36 mm). However, Chinstraps have dramatically longer bills (48.22 mm vs 38.65 mm)—a clean ~10 mm separation.

Together, these four measurements provide sufficient distinct information to separate all three species cleanly.

## Step-by-Step Student Instructions
1. Inspect `main.py` line 28 to identify the four feature names.
2. Check the units of measurement for each feature.
3. Compare the mean bill length of Adelie (38.7 mm) to Chinstrap (48.2 mm).
4. Notice that Gentoo penguins have both the longest flippers and the largest mass, but the shallowest bill depth.
5. Explain how combining multiple physical dimensions eliminates ambiguities that might exist when looking at just one dimension alone.

## Expected Output or Observable Behaviour
When grouping the dataset by species in pandas:
```python
>>> df.groupby("species")[FEATURES].mean()
           bill_length_mm  bill_depth_mm  flipper_length_mm  body_mass_g
species                                                                 
Adelie             38.654         18.368             190.66      3723.96
Chinstrap          48.220         18.348             194.84      3707.68
Gentoo             47.572         15.114             215.86      5028.04
```
The output confirms clear mathematical separation across the biological groups.

## Practical Exercises
- **Exercise 3.1**: If you only measured `body_mass_g`, could you reliably tell an Adelie penguin apart from a Chinstrap penguin? Explain why or why not using the empirical averages.
- **Exercise 3.2**: Which single measurement provides the clearest separation between Adelie and Chinstrap penguins?
- **Exercise 3.3**: Why is it beneficial to measure four features rather than relying on a single anatomical trait?

## Common Mistakes and Debugging
- **Overlooking differing units**: Forgetting that `body_mass_g` is in thousands of grams while `bill_depth_mm` is around ~15 mm. If unscaled, distance algorithms would be 99.9% dominated by body mass.
- **Assuming one feature solves everything**: Looking only at bill length would confuse Chinstrap (48.2 mm) and Gentoo (47.6 mm). Multiple dimensions are required to disambiguate all species.
- **Confusing culmen length with total head size**: Bill length specifically measures the culmen ridge of the upper mandible, not the full head.

## Best Practices and Security Considerations
- **Consistent Measurement Protocols**: In field biology, standard calipers must be used for culmen measurements, and standard rulers for flipper measurements, to avoid instrument bias.
- **Feature Redundancy Check**: Ensure features provide complementary biological information rather than being redundant duplicates.
- **Data Integrity**: Validate that all measurement values fall within biologically plausible ranges (e.g., no negative lengths or zero weights).

## Summary and Key Takeaways
- Morphometrics provides an objective, quantitative basis for biological species classification.
- The four features measured are bill length, bill depth, flipper length, and body mass.
- Niche partitioning drives morphological divergence: Gentoos are heavy, deep divers; Chinstraps have long bills for offshore feeding; Adelies have short, deep bills for krill.
- Combining all four measurements into a multi-dimensional feature space enables machine learning models to identify species with high accuracy.

## Knowledge-check Questions
1. What does the term "culmen length" refer to on a penguin's anatomy?
2. What are the four features included in the `FEATURES` list in `main.py`?
3. Which species has the highest average body mass and longest flippers?
4. Why is bill length particularly crucial for distinguishing Adelie from Chinstrap penguins?
5. What units are used for flipper length and body mass respectively?

## References
- Gorman KB, et al. (2014) *PLoS ONE* 9(3): e90081.
- Palmer Penguins R package documentation by Allison Horst: https://allisonhorst.github.io/palmerpenguins/
- scikit-learn Feature Preprocessing Guide: https://scikit-learn.org/stable/modules/preprocessing.html
