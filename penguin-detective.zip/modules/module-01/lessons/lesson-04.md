# Lesson 04: Project Architecture & The Penguin Detective Pipeline

**Lesson ID:** lesson-04
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Trace the complete end-to-end data pipeline implemented in `main.py`
- Identify the seven primary execution phases of the script
- Explain why preprocessing and model estimation are chained into an scikit-learn `Pipeline`
- Describe the artifacts generated and saved into the `outputs/` directory

## Prerequisites
- Lesson 01: The Antarctic Mystery & The Three Penguin Species
- Lesson 02: Classification vs. Regression in Ecological Machine Learning
- Lesson 03: Morphometric Identification: Why Body Measurements Differentiate Species

## Biological and Real-World Context
In production data science, an algorithm cannot exist as an isolated mathematical formula. To be useful to polar scientists, wildlife agencies, and automated research stations, code must follow a structured, reproducible software pipeline:
1. Ingest raw observational data from permanent storage.
2. Partition data to guarantee honest out-of-sample evaluation.
3. Standardize diverse physical units automatically.
4. Fit and compare predictive models systematically.
5. Provide probabilistic confidence scores for unknown specimens.
6. Export visual diagnostics and machine-readable performance metrics.

The Penguin Detective establishes this exact production architecture in a clean, self-contained Python script.

## Concept Explanation
The script `main.py` implements a disciplined **seven-stage execution architecture**:

```text
[1. Ingestion]           Load penguins.csv into DataFrame
         │
[2. Partitioning]        Stratified train_test_split (75% train, 25% test)
         │
[3. Pipeline & Tuning]   For k in (3, 5): Pipeline(StandardScaler -> KNN(k)).fit()
         │
[4. Model Selection]     Identify best_k based on held-out test accuracy
         │
[5. Inference]           predict() and predict_proba() on mystery specimen
         │
[6. Visualization]       Generate penguin_scatter.png & confusion_matrix.png
         │
[7. Artifact Logging]    Write quantitative results to metrics.txt
```

By encapsulating `StandardScaler` and `KNeighborsClassifier` inside a `Pipeline`, scikit-learn guarantees that scaling transformations applied to test data or new query specimens utilize the exact mean and variance learned from the training split, completely eliminating **data leakage**.

## Relevant Code (from main.py)
```python
# Lines 20-26, 32-40 of main.py
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)

def main() -> None:
    df = pd.read_csv(DATA / "penguins.csv")
    X = df[FEATURES]
    y = df["species"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
```

## Code Explanation
- `BASE = Path(__file__).resolve().parent` establishes absolute path resolution relative to the script's physical location on disk.
- `DATA` and `OUT` create standardized paths for input data and output artifacts.
- `OUT.mkdir(exist_ok=True)` ensures that the destination directory exists before saving figures or text logs.
- `train_test_split(..., test_size=0.25, random_state=42, stratify=y)` splits the 150 rows into 112 training samples and 38 testing samples while maintaining exact class proportions.
- The pipeline architecture ensures that no raw data is ever exposed to the model without standardizing feature scales first.

## Worked Example
Let us trace the lifecycle of a single measurement through this architecture:
1. **Raw Ingestion**: Specimen arrives with `body_mass_g = 3700.0` and `bill_length_mm = 39.0`.
2. **Pipeline Preprocessing**: `StandardScaler` subtracts the training mean ($\mu_{	ext{mass}} pprox 4153$) and divides by standard deviation ($\sigma_{	ext{mass}} pprox 722$), converting $3700	ext{g} ightarrow z pprox -0.63$.
3. **Distance Calculation**: The KNN estimator calculates Euclidean distance in normalized 4D space to find the $k$ closest neighbors.
4. **Voting & Confidence**: If all 3 closest neighbors are Adelie, the voting fraction is $3/3 = 1.0$ (100% confidence).
5. **Output**: The result is logged to `metrics.txt` and highlighted on `penguin_scatter.png`.

## Step-by-Step Student Instructions
1. Open `main.py` and locate the `BASE`, `DATA`, and `OUT` path definitions.
2. Note how `Path.resolve().parent` ensures the script runs consistently regardless of the terminal's working directory.
3. Trace the flow from `pd.read_csv()` to `train_test_split()`.
4. Locate the loop where $k=3$ and $k=5$ pipelines are evaluated.
5. Identify the three output files created in the `outputs/` directory.

## Expected Output or Observable Behaviour
When `main.py` is executed, the terminal outputs the evaluation trace:
```text
============================================================
THE PENGUIN DETECTIVE
============================================================
k=3: accuracy 94.7%
k=5: accuracy 94.7%

Best k: 3

              precision    recall  f1-score   support

      Adelie       0.92      0.92      0.92        12
   Chinstrap       0.92      0.92      0.92        13
      Gentoo       1.00      1.00      1.00        13

    accuracy                           0.95        38
   macro avg       0.95      0.95      0.95        38
weighted avg       0.95      0.95      0.95        38

New penguin -> Adelie (100% confident)

Saved: outputs/penguin_scatter.png, outputs/confusion_matrix.png, outputs/metrics.txt
```
The specified files are reliably created in `outputs/`.

## Practical Exercises
- **Exercise 4.1**: What is the purpose of setting `matplotlib.use("Agg")` at the beginning of `main.py`?
- **Exercise 4.2**: Why does `main.py` store `results` in a dictionary indexed by $k$?
- **Exercise 4.3**: List the three output files saved to `outputs/` and describe the purpose of each.

## Common Mistakes and Debugging
- **Hardcoding relative file paths**: Using `"data/penguins.csv"` directly instead of `DATA / "penguins.csv"` causes `FileNotFoundError` if the script is executed from a parent or child directory.
- **Forgetting `exist_ok=True` on `mkdir`**: If the `outputs` directory already exists, omitting `exist_ok=True` raises a `FileExistsError`.
- **Calling GUI plot functions on headless servers**: Omitting `matplotlib.use("Agg")` causes crashes when running on remote servers or automated containers without display servers ($DISPLAY unset).

## Best Practices and Security Considerations
- **Non-Interactive Matplotlib Backend**: Always specify `matplotlib.use("Agg")` for automated batch scripts and headless servers.
- **Explicit Output Directories**: Organize generated plots and metric files in a dedicated `outputs/` folder, keeping raw data directories read-only.
- **Explicit Resource Cleanup**: Call `plt.close(fig)` after saving figures to avoid memory leaks during long-running tasks or batch processing.

## Summary and Key Takeaways
- `main.py` implements a disciplined 7-stage production architecture: ingestion, stratified split, pipeline fitting, hyperparameter tuning, mystery inference, plot rendering, and metric logging.
- `pathlib.Path` ensures robust, platform-independent path resolution across Windows, macOS, and Linux.
- An scikit-learn `Pipeline` encapsulates feature standardization alongside KNN estimation, preventing data leakage.
- Three persistent artifacts are generated: `penguin_scatter.png`, `confusion_matrix.png`, and `metrics.txt`.

## Knowledge-check Questions
1. Why does `main.py` use `pathlib.Path(__file__).resolve().parent`?
2. What role does `StandardScaler` play inside the scikit-learn `Pipeline`?
3. How many samples from the 150-row dataset are assigned to the test set when `test_size=0.25`?
4. What three output files are created when `main.py` completes execution?
5. Why is `plt.close(fig)` called after saving each plot?

## References
- scikit-learn Pipeline Guide: https://scikit-learn.org/stable/modules/compose.html
- Python `pathlib` Documentation: https://docs.python.org/3/library/pathlib.html
- Matplotlib Headless Guide: https://matplotlib.org/stable/users/explain/backends.html
