# Lesson 01: The Antarctic Mystery & The Three Penguin Species

**Lesson ID:** lesson-01
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Trace the biological background of the Palmer Station Long Term Ecological Research (LTER) study in Antarctica
- Identify the three sympatric penguin species: Adelie (*Pygoscelis adeliae*), Chinstrap (*Pygoscelis antarcticus*), and Gentoo (*Pygoscelis papua*)
- Explain why automated species identification is critical for ecological conservation and climate monitoring
- Recognize how automated pattern recognition assists field researchers in challenging polar environments

## Prerequisites
- Basic familiarity with biological species concepts
- General understanding that living organisms exhibit measurable physical characteristics

## Biological and Real-World Context
In the freezing expanse of the Palmer Archipelago in Western Antarctica, scientists at Palmer Station monitor penguin populations as indicator species for ecological change. The Palmer Archipelago is home to three related brush-tailed penguin species of the genus *Pygoscelis*:
1. **Adelie Penguin (*Pygoscelis adeliae*)**: Compact and resilient, with a distinctive white ring around its eye. Adelies are ice-dependent penguins that feed primarily on Antarctic krill.
2. **Chinstrap Penguin (*Pygoscelis antarcticus*)**: Recognized by a narrow black band running under its chin, looking like a black helmet strap. They nest on rocky, ice-free slopes.
3. **Gentoo Penguin (*Pygoscelis papua*)**: The largest of the three brush-tailed species, distinguished by a bright orange-red bill and a prominent white patch atop its head. Gentoos dive deeper than Adelies and Chinstraps to hunt fish and squids.

Because climate change is rapidly altering sea ice extent along the Western Antarctic Peninsula, tracking how each species' population expands or contracts provides vital signals about polar ecosystem health.

## Concept Explanation
Field biologists capture, measure, band, and release penguins to monitor their colonies. However, manual species logging in the polar field is fraught with practical challenges:
- Weather conditions (blizzards, extreme sub-zero temperatures, dense fog) severely degrade visual visibility.
- Young penguins (chicks and fledglings) and moulting adults lose the distinct plumage patterns that human observers typically rely upon.
- Manual species identification in vast automated sensor networks (such as camera traps or automated weigh-stations) requires algorithmic intelligence.

To solve this problem, ecologists turned to **morphometrics**—the quantitative measurement of physical body dimensions. By taking four simple physical measurements (bill length, bill depth, flipper length, and body mass), biologists can determine a penguin's species with mathematical certainty. In machine learning, this translates into a **supervised multi-class classification** problem: using known physical dimensions to predict a categorical label.

## Relevant Code (from main.py)
```python
# Lines 1-8 of main.py
"""Project 13: The Penguin Detective (K-Nearest Neighbours).

Run:
    python main.py

Classify a penguin's species from four body measurements.  The script
compares k=3 and k=5 so you can see that a hyperparameter changes the answer.
"""
```

## Code Explanation
- The module docstring immediately frames the core engineering goal: classifying a penguin's biological species using four numerical body measurements.
- The project is named **The Penguin Detective** because the machine learning algorithm investigates subtle anatomical clues (measurements) to deduce the subject's true identity (species).
- The docstring establishes that this is a classification problem and introduces the algorithm used: **K-Nearest Neighbours (KNN)**.
- It highlights that the script compares two hyperparameter settings ($k=3$ vs $k=5$) to show how model tuning impacts diagnostic accuracy.

## Worked Example
Consider an Antarctic field station that registers a newly weighed and measured bird with:
- Bill Length: 49.0 mm
- Bill Depth: 15.0 mm
- Flipper Length: 218 mm
- Body Mass: 5200 g

How does an ecologist—or our algorithm—reason about this bird?
1. The flipper length (218 mm) and body mass (5200 g) are far above the maximum ranges typical for Adelie and Chinstrap penguins (which rarely exceed 200 mm flippers or 4000 g mass).
2. The bill depth is relatively slender (15.0 mm), which matches the streamlined beak profile of a deep-diving fish hunter.
3. Both clues strongly point towards *Pygoscelis papua* (Gentoo).
A trained classifier performs this reasoning systematically and instantaneously across multiple dimensions without human fatigue.

## Step-by-Step Student Instructions
1. Open the project root folder in your terminal.
2. Read the docstring at the top of `main.py`.
3. Note the four physical body measurements mentioned in the docstring.
4. Verify the three biological species studied in the Palmer LTER dataset: Adelie, Chinstrap, and Gentoo.
5. Reflect on why automated classification provides objective consistency compared to subjective manual visual tags.

## Expected Output or Observable Behaviour
When reading `main.py` lines 1-8, you observe a clear project declaration:
```text
Project 13: The Penguin Detective (K-Nearest Neighbours).
Classify a penguin's species from four body measurements.
```
No errors or ambiguity should exist regarding the project's ecological purpose or machine learning task type.

## Practical Exercises
- **Exercise 1.1**: Name the three penguin species native to the Palmer Archipelago included in this project.
- **Exercise 1.2**: If a field biologist encounters a penguin during a heavy blizzard where feather coloration cannot be distinguished, explain why physical body measurements remain reliable identifiers.
- **Exercise 1.3**: Research which of the three species is the heaviest on average, and explain how body mass relates to diving capability.

## Common Mistakes and Debugging
- **Confusing penguins with Arctic birds**: Penguins are exclusively native to the Southern Hemisphere (Antarctica and sub-polar regions); polar bears live in the Arctic.
- **Assuming visual plumage is always available**: Assuming that feather coloration is sufficient ignores fledglings, moulting adults, and automated sensor logging where color photographs are unavailable.
- **Thinking all three species are identical in size**: Believing all three brush-tailed species have identical body structures ignores millions of years of ecological niche partitioning.

## Best Practices and Security Considerations
- **Ecological Data Ethics**: The Palmer Station LTER dataset was collected under strict scientific animal-handling permits. Real-world ecological data should always be collected with minimal disruption to wildlife.
- **Reproducibility**: Always document the geographic location, date, and environmental conditions under which observational measurements were captured.
- **Domain Collaboration**: Machine learning engineers should work closely with domain biologists to ensure that model features make biological sense and are not statistical artifacts.

## Summary and Key Takeaways
- The Palmer Penguins dataset documents three brush-tailed Antarctic species: Adelie, Chinstrap, and Gentoo.
- Climate researchers monitor these populations as vital bio-indicators of Antarctic ecosystem stability.
- Automated species classification solves visual identification challenges caused by harsh polar weather and plumage moulting.
- The Penguin Detective applies machine learning to translate 4 continuous physical measurements into accurate, automated species predictions.

## Knowledge-check Questions
1. What are the common and scientific names of the three penguin species analyzed in this project?
2. Where was the empirical field data collected?
3. Why are penguins considered valuable bio-indicators for environmental monitoring?
4. What four physical body measurements serve as the inputs to our model?
5. What machine learning algorithm does the project employ?

## References
- Gorman KB, Williams TD, Fraser WR (2014) Ecological Sexual Dimorphism and Environmental Variability within a Community of Antarctic Penguins (Genus Pygoscelis). PLoS ONE 9(3): e90081.
- Palmer Station Long Term Ecological Research: https://pallter.marine.rutgers.edu/
- scikit-learn User Guide (Nearest Neighbors): https://scikit-learn.org/stable/modules/neighbors.html
