# Lesson 02: Classification vs. Regression in Ecological Machine Learning

**Lesson ID:** lesson-02
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define the fundamental differences between classification and regression in supervised learning
- Identify why predicting penguin species is a multi-class classification problem
- Contrast continuous numerical prediction targets with discrete categorical targets
- Explain why regression algorithms (like Linear Regression) are inappropriate for discrete species labels

## Prerequisites
- Lesson 01: The Antarctic Mystery & The Three Penguin Species
- Understanding of variables, data types (numbers vs strings), and basic logic

## Biological and Real-World Context
In ecological data science, questions frequently arise in two distinct mathematical forms:
1. **Continuous estimation**: "How many grams does this chick weigh?" or "What will the colony population count be next winter?"
2. **Categorical identification**: "Is this organism healthy, stressed, or infected?" or "Does this specimen belong to species A, B, or C?"

Choosing the wrong mathematical formulation leads to nonsensical biological conclusions. For example, if an algorithm treated species as arbitrary numbers (Adelie = 1, Chinstrap = 2, Gentoo = 3), an ordinary linear regression model might output $1.73$. What biological creature is a $1.73$ penguin? It does not exist in nature. Hence, proper task framing is critical.

## Concept Explanation
Supervised machine learning divides into two primary paradigms based on the mathematical nature of the **target variable ($y$)**:

### 1. Regression
- The target $y$ is a **continuous numeric value** on an interval or ratio scale ($y \in \mathbb{R}$).
- Examples: Predicting lemonade cups sold (e.g., 44.6 cups), predicting used-car price (e.g., $18,450), or predicting penguin body mass in grams.
- Loss functions measure distance between continuous numbers (e.g., Mean Absolute Error, Mean Squared Error).

### 2. Classification
- The target $y$ is a **discrete categorical label** belonging to a finite set of classes ($y \in \{C_1, C_2, \dots, C_K\}$).
- If $K=2$, it is **binary classification** (e.g., survived vs died, spam vs ham).
- If $K > 2$, it is **multi-class classification** (e.g., Adelie vs Chinstrap vs Gentoo).
- Algorithms output class assignments or posterior probability distributions across classes.

Because penguin species is a discrete categorical variable with three mutually exclusive biological identities, **The Penguin Detective** is strictly a **multi-class classification** task.

## Relevant Code (from main.py)
```python
# Lines 34-35 of main.py
X = df[FEATURES]
y = df["species"]
```

## Code Explanation
- `X = df[FEATURES]` selects the 4 continuous predictor columns: `bill_length_mm`, `bill_depth_mm`, `flipper_length_mm`, and `body_mass_g`.
- `y = df["species"]` extracts the target column.
- The values inside `y` are strings: `"Adelie"`, `"Chinstrap"`, and `"Gentoo"`.
- Scikit-learn's classification algorithms natively handle string class labels, converting them internally into discrete integer indices while preserving human-readable outputs.

## Worked Example
Let us trace what happens when we examine target values across different projects:
- In Project 02 (Lemonade Stand): $y \in [12.0, 48.0]$ cups $\rightarrow$ Continuous $\rightarrow$ **Regression**.
- In Project 03 (Titanic Survival): $y \in \{0, 1\}$ $\rightarrow$ 2 discrete classes $\rightarrow$ **Binary Classification**.
- In Project 13 (Penguin Detective): $y \in \{\text{Adelie}, \text{Chinstrap}, \text{Gentoo}\}$ $\rightarrow$ 3 discrete classes $\rightarrow$ **Multi-Class Classification**.

Notice that in classification, there is no inherent mathematical ordering between classes: Gentoo is not "greater than" Adelie, nor is Chinstrap the "average" of Adelie and Gentoo.

## Step-by-Step Student Instructions
1. Inspect the target column `species` in `data/penguins.csv`.
2. Count the unique values present in the column using `df['species'].unique()`.
3. Confirm that there are exactly 3 unique values: Adelie, Gentoo, and Chinstrap.
4. Write down whether the target represents a measured quantity or a discrete identity.
5. Conclude why multi-class classification is the appropriate learning task.

## Expected Output or Observable Behaviour
In an interactive Python environment:
```python
>>> df["species"].unique()
array(['Gentoo', 'Adelie', 'Chinstrap'], dtype=object)
>>> df["species"].dtype
dtype('O')  # Object / String
```
The target consists of unordered textual categories, confirming a multi-class classification problem.

## Practical Exercises
- **Exercise 2.1**: Explain why predicting penguin `body_mass_g` from bill measurements would be a regression problem, whereas predicting `species` is a classification problem.
- **Exercise 2.2**: If someone encoded Adelie as 1, Chinstrap as 2, and Gentoo as 3, and applied Linear Regression, what logical error would occur if the model predicted 2.5?
- **Exercise 2.3**: What is the difference between binary classification and multi-class classification?

## Common Mistakes and Debugging
- **Applying regression metrics to classification**: Trying to compute Mean Absolute Error (MAE) or $R^2$ score on string class labels causes immediate `TypeError` or `ValueError` in scikit-learn. Classification requires metrics like Accuracy, Precision, Recall, and Confusion Matrices.
- **Assuming numeric targets imply classification**: A numeric value like body mass or temperature is continuous, not categorical.
- **Imposing an artificial order on categories**: Labeling categories with numbers (1, 2, 3) must not be interpreted as quantitative magnitude.

## Best Practices and Security Considerations
- **Verify Target Data Type**: Always inspect the distribution and unique categories of `y` before selecting machine learning algorithms.
- **Ensure Mutual Exclusivity**: Confirm that each sample belongs to exactly one class. (Multi-label classification, where a sample can belong to multiple classes simultaneously, requires different algorithms).
- **Check for Class Imbalance**: Always check whether classes have roughly equal counts or if one dominant class will skew accuracy.

## Summary and Key Takeaways
- Supervised learning splits into regression (continuous numeric outputs) and classification (discrete categorical outputs).
- The Penguin Detective is a multi-class classification problem with 3 distinct target species: Adelie, Chinstrap, and Gentoo.
- Treating discrete biological species as continuous numbers leads to invalid biological assumptions.
- Scikit-learn classifiers evaluate performance using accuracy, precision, recall, and confusion matrices rather than regression residuals.

## Knowledge-check Questions
1. What mathematical characteristic distinguishes a classification target from a regression target?
2. How many distinct classes exist in the Palmer Penguins species target?
3. Why can linear regression not be directly used to predict Adelie, Chinstrap, or Gentoo?
4. What error would occur if you computed Mean Squared Error on string class labels?
5. What type of machine learning task would it be if we predicted penguin flipper length from body mass?

## References
- scikit-learn Classification vs Regression Guide: https://scikit-learn.org/stable/supervised_learning.html
- Bishop CM (2006) *Pattern Recognition and Machine Learning*. Springer, Chapter 4: Linear Models for Classification.
- Python Data Science Handbook (Jake VanderPlas): https://jakevdp.github.io/PythonDataScienceHandbook/
