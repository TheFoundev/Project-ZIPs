# Module 1 Exercises: Project Overview & Problem Formulation

## Exercise 1.1: Ecological Problem Formulation (15 min)
**Objective:** Formulate an ecological species identification challenge into a supervised multi-class classification problem.
**Problem Statement:** Wildlife researchers at Palmer Station monitor three penguin species (*Adelie*, *Chinstrap*, and *Gentoo*). When bad weather impairs visual sightings, researchers must identify captured penguins using physical measurements. You must define this problem in formal machine learning terms.

**Requirements:**
1. Identify the input features $X$ and state their physical units.
2. Identify the target variable $y$ and list all possible output values.
3. Classify this task as either regression, binary classification, or multi-class classification, and justify why.
4. Explain why treating the species as numerical codes (1, 2, 3) with linear regression would be an invalid approach.

**Acceptance Criteria:**
- [ ] Features are identified as `bill_length_mm`, `bill_depth_mm`, `flipper_length_mm`, and `body_mass_g`.
- [ ] Target is identified as `species` with classes: Adelie, Chinstrap, Gentoo.
- [ ] Task is correctly categorized as multi-class classification.
- [ ] Clear mathematical reasoning explains why continuous regression cannot predict discrete, unordered biological categories.

---

## Exercise 1.2: Exploring Morphometric Separation (15 min)
**Objective:** Analyze empirical species averages to understand feature separability.
**Problem Statement:** Using the dataset summary values, explain which measurements best separate Gentoo penguins from the other two species, and which measurement differentiates Adelie from Chinstrap.

**Requirements:**
1. Compare Gentoo flipper length (~216 mm) and body mass (~5028 g) to Adelie and Chinstrap averages.
2. Compare Adelie bill length (~38.7 mm) to Chinstrap bill length (~48.2 mm).
3. Explain why measuring both bill depth and bill length is more informative than measuring bill length alone.

**Acceptance Criteria:**
- [ ] Gentoo is identified as separable by flipper length, body mass, and shallower bill depth.
- [ ] Adelie and Chinstrap are identified as separable primarily by bill length (~10 mm difference).
- [ ] Analysis explains that multi-dimensional measurements resolve ambiguities present in single-feature views.

---

## Exercise 1.3: Tracing the Script Architecture (15 min)
**Objective:** Map out the execution lifecycle of `main.py` and inspect artifact generation.
**Problem Statement:** Review `main.py` and diagram the 7 architectural stages from data loading to artifact persistence.

**Requirements:**
1. List the 7 execution phases in order.
2. Identify the role of `StandardScaler` inside the pipeline.
3. Identify the three output files generated in `outputs/`.

**Acceptance Criteria:**
- [ ] 7 stages correctly listed: Ingestion, Splitting, Pipeline Training, Model Selection, Inference, Visualization, Artifact Logging.
- [ ] `StandardScaler` explained as normalizing feature distributions to zero mean and unit variance.
- [ ] Outputs identified: `penguin_scatter.png`, `confusion_matrix.png`, `metrics.txt`.
