# Lesson 01: Foundations of K-Nearest Neighbours

**Lesson ID:** lesson-01
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain the core operational logic of the K-Nearest Neighbours (KNN) algorithm
- Distinguish instance-based (lazy) learning from parametric eager learning algorithms
- Describe how plurality (majority) voting assigns a categorical class to a new observation
- Explain why KNN requires no explicit training phase other than indexing the training dataset

## Prerequisites
- Module 02: Data & Penguin Features
- Basic intuition of coordinate systems and geometric proximity

## Biological and Real-World Context
When a human field detective arrives at a crime scene with a single piece of evidence (e.g., a mystery footprint), how do they deduce the culprit? They do not invent a complex mathematical equation from scratch. Instead, they look through their database of known records, find the physical records that most closely resemble the evidence, and deduce the identity based on the closest matches.

In machine learning, this intuitive strategy is called **instance-based learning** or **case-based reasoning**. For polar researchers encountering an unidentified penguin on an Antarctic ice shelf, the most natural question is: *"Which known penguins in our database have almost the exact same bill, flipper, and mass measurements as this bird?"* If the 3 birds closest in physical measurements are all Adelies, it is overwhelming evidence that the new bird is an Adelie. This is the exact philosophy of K-Nearest Neighbours.

## Concept Explanation
**K-Nearest Neighbours (KNN)** is a non-parametric, supervised machine learning algorithm used for both classification and regression. Unlike algorithms that learn explicit mathematical parameters (such as the slope and intercept in linear regression, or split thresholds in decision trees), KNN makes decisions by referencing raw training examples directly.

### Key Characteristics of KNN:
1. **Lazy Learner**: KNN does not learn a discriminative function during `.fit()`. Training consists simply of storing and indexing the training data points in memory. All computational work happens during `.predict()`, when distances between the new query point and all stored training points must be computed.
2. **Non-Parametric**: KNN makes no prior assumptions about the underlying statistical distribution of the data (e.g., it does not assume Gaussian distributions or linear boundaries). It can learn arbitrary, highly irregular decision boundaries.
3. **Plurality Voting**: When a new query point $x_q$ arrives:
   - The algorithm computes the distance between $x_q$ and every point in the training set.
   - It identifies the $k$ training points that have the shortest distances to $x_q$.
   - Each of the $k$ neighbours casts a vote for its true class label.
   - The class receiving the highest number of votes is declared the predicted class.

## Relevant Code (from main.py)
```python
# Lines 19, 42-51 of main.py
from sklearn.neighbors import KNeighborsClassifier

results = {}
for k in (3, 5):
    model = Pipeline(
        [
            ("scale", StandardScaler()),
            ("knn", KNeighborsClassifier(n_neighbors=k)),
        ]
    )
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    results[k] = (model, predictions, accuracy_score(y_test, predictions))
```

## Code Explanation
- `KNeighborsClassifier(n_neighbors=k)` instantiates scikit-learn's KNN classifier with the neighbor count specified by `k`.
- Inside the pipeline, `model.fit(X_train, y_train)` fits the scaler and stores the standardized coordinates of the 112 training penguins.
- `model.predict(X_test)` evaluates each of the 38 test penguins by finding their $k$ nearest training neighbors and tallying their votes.
- The loop evaluates both $k=3$ and $k=5$ configurations to observe the effect of the neighbor hyperparameter.

## Worked Example
Suppose we have a mystery penguin and want to classify it using $k=3$ nearest neighbours.
The algorithm calculates distances to all 112 training birds and identifies the 3 closest birds:
- Neighbour 1: Distance = $0.21$, Class = **Adelie**
- Neighbour 2: Distance = $0.29$, Class = **Adelie**
- Neighbour 3: Distance = $0.34$, Class = **Adelie**

Vote tally:
- Adelie: 3 votes
- Chinstrap: 0 votes
- Gentoo: 0 votes

Winning class: **Adelie** (unanimous vote, $3/3 = 100\%$ confidence).
Now suppose Neighbour 3 had been Chinstrap:
- Adelie: 2 votes
- Chinstrap: 1 vote
- Gentoo: 0 votes
Winning class: **Adelie** (plurality vote, $2/3 = 66.7\%$ confidence).

## Step-by-Step Student Instructions
1. Import `KNeighborsClassifier` from `sklearn.neighbors`.
2. Instantiate a classifier with `knn = KNeighborsClassifier(n_neighbors=3)`.
3. Understand that calling `knn.fit(X, y)` simply indexes $X$ and $y$ into internal search trees (like KD-Tree or BallTree).
4. Recognize that the computational cost of KNN scales with the number of training samples during inference time.
5. Consider what happens when $k$ is an even number versus an odd number in binary or multi-class problems.

## Expected Output or Observable Behaviour
```text
KNeighborsClassifier(n_neighbors=3)
```
When inspected in Python, the classifier confirms its default parameters: Euclidean metric (`metric='minkowski'`, `p=2`), uniform weights (`weights='uniform'`), and auto algorithm selection (`algorithm='auto'`).

## Practical Exercises
- **Exercise 1.1**: Why is KNN referred to as a "lazy learner"? Contrast this with an "eager learner" like Linear Regression.
- **Exercise 1.2**: In a 3-class problem with $k=3$, what happens if the 3 nearest neighbors are 1 Adelie, 1 Chinstrap, and 1 Gentoo (a three-way tie)? How does scikit-learn resolve ties?
- **Exercise 1.3**: Why is choosing an odd number for $k$ (e.g., $k=3, 5, 7$) often preferred over even numbers?

## Common Mistakes and Debugging
- **Expecting a learned equation**: Asking "Where are the weights or coefficients of the KNN model?" KNN has no learned weights or equation; the dataset itself IS the model.
- **Slow inference on massive datasets**: Because KNN must calculate distances to all stored points, querying a dataset with millions of rows can be slow without spatial indexing trees (KD-Trees).
- **Ignoring unscaled features**: Running KNN on raw features where one feature has large numbers causes all other features to be ignored.

## Best Practices and Security Considerations
- **Memory Management**: Since KNN retains the full training set in memory, monitor memory consumption when scaling to large datasets.
- **Odd Values of $k$**: Use odd numbers for $k$ in binary classification to prevent 50/50 vote ties.
- **Tie-Breaking Awareness**: In multi-class problems where ties can occur (e.g., 1 vote each for 3 classes), scikit-learn breaks ties by selecting the class with the closest single neighbor or lowest index.

## Summary and Key Takeaways
- K-Nearest Neighbours is an instance-based, non-parametric supervised learning algorithm.
- KNN stores the training data and classifies query points using plurality voting among their $k$ nearest neighbors.
- As a "lazy learner," training is instantaneous, but prediction requires computing distances across training instances.
- KNN relies entirely on geometric proximity in feature space, making proper feature scaling mandatory.

## Knowledge-check Questions
1. Why is KNN called an instance-based algorithm?
2. What happens during the `.fit()` call of a KNeighborsClassifier?
3. How does KNN determine the class of a new data point?
4. What is the difference between an eager learner and a lazy learner?
5. Why is $k$ typically chosen as an odd number?

## References
- Cover T, Hart P (1967) Nearest neighbor pattern classification. *IEEE Transactions on Information Theory* 13(1): 21-27.
- scikit-learn KNeighborsClassifier: https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.KNeighborsClassifier.html
- The Elements of Statistical Learning (Hastie, Tibshirani, Friedman), Chapter 13: Prototype Methods and Nearest-Neighbors.
