# Lesson 02: Calculating Euclidean Distance in 4D Feature Space

**Lesson ID:** lesson-02
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- State the mathematical formula for Euclidean distance in arbitrary $N$-dimensional space
- Calculate the straight-line geometric distance between two penguins across 4 standardized features
- Understand how scikit-learn generalizes the Pythagorean theorem to 4D hyperspace
- Explain the role of the Minkowski metric with parameter $p=2$

## Prerequisites
- Lesson 01: Foundations of K-Nearest Neighbours
- Basic algebra: square roots, exponents, and summation notation ($\sum$)

## Biological and Real-World Context
In everyday life, we experience distance in 2 dimensions (a map) or 3 dimensions (physical space). When we measure the distance between two landmarks on a map, we use the Pythagorean theorem: $d = \sqrt{\Delta x^2 + \Delta y^2}$.

In ecological biology, an organism is not defined by physical spatial coordinates $(x, y, z)$, but by its **phenotypic trait coordinates**. A penguin is a single point in an abstract 4-dimensional biological space defined by:
1. Dimension 1: Culmen Bill Length
2. Dimension 2: Culmen Bill Depth
3. Dimension 3: Flipper Length
4. Dimension 4: Body Mass

Two penguins that are biologically similar will be situated extremely close to each other in this 4D space, while penguins belonging to different species will be separated by large geometric voids.

## Concept Explanation
The straight-line geometric distance between any two points in $N$-dimensional space is given by the **Euclidean Distance** formula:

$$d(\mathbf{p}, \mathbf{q}) = \sqrt{\sum_{i=1}^N (p_i - q_i)^2} = \sqrt{(p_1 - q_1)^2 + (p_2 - q_2)^2 + \dots + (p_N - q_N)^2}$$

For our 4-dimensional penguin feature space ($N=4$):

$$d(\text{penguin}_A, \text{penguin}_B) = \sqrt{(\Delta\text{bill\_length})^2 + (\Delta\text{bill\_depth})^2 + (\Delta\text{flipper})^2 + (\Delta\text{body\_mass})^2}$$

### The Minkowski Metric
In scikit-learn's `KNeighborsClassifier`, the default distance metric is the **Minkowski metric**:

$$D(x, y) = \left( \sum_{i=1}^N |x_i - y_i|^p \right)^{\frac{1}{p}}$$

When $p=1$, this formula yields the **Manhattan (City Block) Distance** ($L_1$ norm).
When $p=2$, this formula simplifies to the standard **Euclidean Distance** ($L_2$ norm).
By default, scikit-learn sets `metric='minkowski'` and `p=2`, which is mathematically identical to Euclidean distance.

## Relevant Code (from main.py)
```python
# KNeighborsClassifier default configuration in main.py line 46:
model = Pipeline(
    [
        ("scale", StandardScaler()),
        ("knn", KNeighborsClassifier(n_neighbors=k)),
    ]
)
```

## Code Explanation
- By omitting the `metric` and `p` parameters, `KNeighborsClassifier(n_neighbors=k)` defaults to `metric='minkowski'` with `p=2`.
- When passed standardized feature vectors where each dimension has zero mean and unit variance, the classifier computes genuine 4D Euclidean distance without distortion.

## Worked Example
Let us compute the 4D Euclidean distance between two penguins whose features have been standardized into $z$-scores:
- Penguin A (Standardized): $z_A = [ -1.10, +0.60, -0.80, -0.62 ]$
- Penguin B (Standardized): $z_B = [ -1.00, +0.70, -0.75, -0.58 ]$
- Penguin C (Standardized): $z_C = [ +0.80, -1.20, +1.20, +1.30 ]$

Let us compute the distance from Penguin A to Penguin B:
1. $\Delta_1^2 = (-1.00 - (-1.10))^2 = (0.10)^2 = 0.0100$
2. $\Delta_2^2 = (0.70 - 0.60)^2 = (0.10)^2 = 0.0100$
3. $\Delta_3^2 = (-0.75 - (-0.80))^2 = (0.05)^2 = 0.0025$
4. $\Delta_4^2 = (-0.58 - (-0.62))^2 = (0.04)^2 = 0.0016$
Sum of squared differences: $0.0100 + 0.0100 + 0.0025 + 0.0016 = 0.0241$.
Distance: $d(A, B) = \sqrt{0.0241} \approx \mathbf{0.155}$.

Now let us compute the distance from Penguin A to Penguin C:
1. $\Delta_1^2 = (0.80 - (-1.10))^2 = (1.90)^2 = 3.61$
2. $\Delta_2^2 = (-1.20 - 0.60)^2 = (-1.80)^2 = 3.24$
3. $\Delta_3^2 = (1.20 - (-0.80))^2 = (2.00)^2 = 4.00$
4. $\Delta_4^2 = (1.30 - (-0.62))^2 = (1.92)^2 = 3.6864$
Sum: $3.61 + 3.24 + 4.00 + 3.6864 = 14.5364$.
Distance: $d(A, C) = \sqrt{14.5364} \approx \mathbf{3.813}$.

Conclusion: Penguin B is situated at distance $0.155$ from A (they are both Adelies!), whereas Penguin C is at distance $3.813$ (C is a Gentoo!). Penguin B is naturally selected as a nearest neighbor, while Penguin C is excluded.

## Step-by-Step Student Instructions
1. Write down the 4D Euclidean distance formula.
2. Select two arbitrary points $p = (1, 2, 3, 4)$ and $q = (4, 3, 2, 1)$.
3. Compute differences for each coordinate: $(4-1)=3$, $(3-2)=1$, $(2-3)=-1$, $(1-4)=-3$.
4. Square each difference: $9 + 1 + 1 + 9 = 20$.
5. Take the square root: $\sqrt{20} \approx 4.472$.
6. Verify this result using `scipy.spatial.distance.euclidean([1,2,3,4], [4,3,2,1])`.

## Expected Output or Observable Behaviour
```python
from scipy.spatial.distance import euclidean
>>> euclidean([1, 2, 3, 4], [4, 3, 2, 1])
4.47213595499958
```
The manual calculation matches the scientific computation library down to machine precision.

## Practical Exercises
- **Exercise 2.1**: Calculate the Euclidean distance between point $u = [0, 0, 0, 0]$ and point $v = [1, 1, 1, 1]$ in 4D space.
- **Exercise 2.2**: If the distance between two penguins across three bill and flipper features is $0.5$, but their body mass difference in standardized units is $2.0$, calculate the total 4D distance.
- **Exercise 2.3**: What is the difference between Manhattan distance ($p=1$) and Euclidean distance ($p=2$)?

## Common Mistakes and Debugging
- **Forgetting the square root**: Calculating the sum of squared differences $\sum (p_i - q_i)^2$ without taking $\sqrt{\cdot}$. (While squared Euclidean distance preserves relative ordering, actual distance values require the root).
- **Subtracting negative coordinates incorrectly**: When subtracting a negative coordinate (e.g., $1.0 - (-1.5)$), the signs yield addition ($1.0 + 1.5 = 2.5$).
- **Assuming humans can visualize 4D space**: Trying to mentally "picture" a 4-dimensional physical room. In mathematics and machine learning, $N$-dimensional space simply means a vector with $N$ independent numerical elements.

## Best Practices and Security Considerations
- **Vectorized Array Operations**: Use NumPy's vectorized operations (`np.linalg.norm(a - b)`) rather than Python `for` loops when computing distances across thousands of rows.
- **Standardization Before Distance**: Never apply Euclidean distance to multi-dimensional data without standardizing features first.
- **Curse of Dimensionality**: Be mindful that as the number of features $N$ grows very large (e.g., thousands of features), Euclidean distance loses discriminative power as all points tend to become equidistant. For 4 features, Euclidean distance works exceptionally well.

## Summary and Key Takeaways
- Euclidean distance generalizes the Pythagorean theorem to any arbitrary number of dimensions.
- In 4D feature space, distance is computed as the square root of the sum of squared differences across all 4 measurements.
- Scikit-learn implements Euclidean distance via the Minkowski metric with parameter $p=2$.
- Feature standardization ensures that each of the 4 dimensions contributes proportionately to the total geometric distance.

## Knowledge-check Questions
1. What is the mathematical formula for Euclidean distance in 4 dimensions?
2. What value of the Minkowski parameter $p$ corresponds to Euclidean distance?
3. What is the distance between $[0, 0, 0, 0]$ and $[2, 2, 2, 2]$?
4. What happens to relative distances between points if you omit the square root step?
5. Why is Euclidean distance appropriate for the 4 morphometric features in this project?

## References
- scikit-learn Distance Metrics: https://scikit-learn.org/stable/modules/generated/sklearn.metrics.DistanceMetric.html
- Deza MM, Deza E (2009) *Encyclopedia of Distances*. Springer.
- SciPy Spatial Distance Documentation: https://docs.scipy.org/doc/scipy/reference/spatial.distance.html
