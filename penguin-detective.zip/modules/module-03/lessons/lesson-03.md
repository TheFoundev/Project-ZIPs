# Lesson 03: Comparing Hyperparameters: k=3 vs. k=5

**Lesson ID:** lesson-03
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define what a hyperparameter is and how it differs from learned model parameters
- Implement a comparative evaluation loop testing $k=3$ and $k=5$
- Analyze the test accuracy results obtained for both hyperparameter settings
- Explain how Python's `max()` function selects the winning hyperparameter configuration

## Prerequisites
- Lesson 01: Foundations of K-Nearest Neighbours
- Lesson 02: Calculating Euclidean Distance in 4D Feature Space
- Python loops, dictionaries, and tuple unpacking

## Biological and Real-World Context
In field ecology and medicine, diagnostic systems often require tuning a decision threshold. If a medical test considers too few symptoms ($k$ too small), it might overreact to temporary anomalies. If it requires too many symptoms ($k$ too large), it might fail to catch an emerging illness.

In **The Penguin Detective**, the number of neighbours $k$ is the central control dial. Should the algorithm consult the **3 closest penguins** or the **5 closest penguins** when identifying a mystery specimen? By systematically training and testing models under both configurations, data scientists replace subjective guesswork with empirical performance data.

## Concept Explanation
In machine learning, we distinguish between two classes of parameters:
1. **Model Parameters**: Values learned automatically by the algorithm from data during training (e.g., slopes in linear regression, split thresholds in decision trees).
2. **Hyperparameters**: External configuration settings chosen by the engineer *before* training begins that govern how the algorithm learns (e.g., the number of neighbours $k$ in KNN, regularization strength $\alpha$, or tree depth).

Because KNN is non-parametric and has no learned internal weights, the choice of $k$ is its most critical hyperparameter.

### Comparing $k=3$ vs $k=5$
In `main.py`, the code iterates over a tuple of candidate values: `(3, 5)`.
For each $k$:
1. A fresh `Pipeline` containing `StandardScaler` and `KNeighborsClassifier(n_neighbors=k)` is initialized.
2. The pipeline is fitted on `(X_train, y_train)` (112 samples).
3. Predictions are generated on `X_test` (38 samples).
4. The test accuracy is computed: $\text{accuracy} = \frac{\text{Number of correct test predictions}}{38}$.
5. The pipeline object, prediction array, and accuracy score are stored in a dictionary.

## Relevant Code (from main.py)
```python
# Lines 41-51, 56-60 of main.py
results = {}
for k in (3, 5):
    model = Pipeline(
        [
            ("scale", StandardScaler()),
            ("knn", KNeighborsClassifier(n_neighbors=k)),
        ]
    )
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    results[k] = (model, predictions, accuracy_score(y_test, predictions))

for k, (_, _, accuracy) in results.items():
    print(f"k={k}: accuracy {accuracy:.1%}")

best_k = max(results, key=lambda k: results[k][2])
best_model, best_predictions, best_accuracy = results[best_k]
```

## Code Explanation
- `for k in (3, 5):` iterates through the candidate hyperparameter values.
- `results[k] = (model, predictions, accuracy_score(y_test, predictions))` stores a 3-element tuple for each $k$.
- `max(results, key=lambda k: results[k][2])` evaluates the accuracy (element index 2 of the tuple) for each dictionary key.
- It returns the key $k$ that achieved the highest test accuracy.
- If both configurations achieve identical accuracy, Python's `max()` deterministically returns the first key encountered ($k=3$).

## Worked Example
Let us examine the exact empirical output produced when `main.py` executes:

```text
============================================================
THE PENGUIN DETECTIVE
============================================================
k=3: accuracy 94.7%
k=5: accuracy 94.7%

Best k: 3
```

Detailed calculation:
- For $k=3$: 36 of 38 test samples are correctly classified. Accuracy $= 36 / 38 = 0.947368... \rightarrow \mathbf{94.7\%}$.
- For $k=5$: 36 of 38 test samples are correctly classified. Accuracy $= 36 / 38 = 0.947368... \rightarrow \mathbf{94.7\%}$.

Both models achieve identical accuracy on this test set.
Because $k=3$ appeared first in the iteration tuple `(3, 5)`, `max(..., key=...)` selects `best_k = 3`.
In addition, $k=3$ provides sharper, more localized decision boundaries for small clusters than $k=5$.

## Step-by-Step Student Instructions
1. Review the loop in `main.py` lines 41-51.
2. Note how `results` maps each integer $k$ to `(model, predictions, accuracy)`.
3. Understand the lambda function `lambda k: results[k][2]`: it tells `max()` to compare models using the accuracy score at index 2.
4. Run `main.py` and verify that the terminal outputs `k=3: accuracy 94.7%` and `k=5: accuracy 94.7%`.
5. Confirm that `best_k` evaluates to 3.

## Expected Output or Observable Behaviour
```text
k=3: accuracy 94.7%
k=5: accuracy 94.7%

Best k: 3
```
Both models exhibit high predictive fidelity, demonstrating that KNN is robust to minor shifts in neighbor count on this dataset.

## Practical Exercises
- **Exercise 3.1**: What would happen if you extended the loop to `for k in (1, 3, 5, 7, 9):`?
- **Exercise 3.2**: Why would $k=1$ be risky in the presence of measurement noise or data entry errors?
- **Exercise 3.3**: Write a Python function that accepts a range of $k$ values and plots test accuracy against $k$.

## Common Mistakes and Debugging
- **Evaluating on training data instead of test data**: Computing `accuracy_score(y_train, model.predict(X_train))`. For $k=1$, training accuracy is always 100% because every point is its own nearest neighbor! Always evaluate hyperparameters on held-out test data.
- **Overwriting models in a loop**: Using a single variable `model` without saving it to a collection, making it impossible to retrieve the best model after the loop concludes.
- **Tuple index confusion**: In `results[k][2]`, indexing `[1]` instead of `[2]` would cause `max()` to compare arrays of string predictions instead of float accuracy scores, causing unpredictable behavior.

## Best Practices and Security Considerations
- **Systematic Search**: When tuning multiple hyperparameters, use scikit-learn's `GridSearchCV` or `RandomizedSearchCV` with cross-validation.
- **Documenting Selection Criteria**: When two models tie in accuracy, document the tie-breaking policy (e.g., favoring smaller $k$ for lower latency or larger $k$ for smoother boundaries).
- **Independent Validation Split**: In large projects, tune hyperparameters on a dedicated validation split and evaluate the final selected model on a pristine test set.

## Summary and Key Takeaways
- Hyperparameters are configuration settings chosen before model training; $k$ is the central hyperparameter of KNN.
- `main.py` evaluates $k=3$ vs $k=5$ by fitting pipelines on `X_train` and scoring on `X_test`.
- Both $k=3$ and $k=5$ achieve $94.7\%$ accuracy (36/38 correct test samples).
- Python's `max()` selects $k=3$ as the optimal configuration.

## Knowledge-check Questions
1. What is the fundamental difference between a model parameter and a hyperparameter?
2. What accuracy score is achieved by both $k=3$ and $k=5$ in `main.py`?
3. How many test samples out of 38 are correctly classified by both models?
4. How does `max(results, key=lambda k: results[k][2])` select the best model?
5. Why is training accuracy misleading when evaluating $k=1$?

## References
- scikit-learn Hyperparameter Tuning Guide: https://scikit-learn.org/stable/modules/grid_search.html
- Bergstra J, Bengio Y (2012) Random Search for Hyper-Parameter Optimization. *JMLR* 13: 281-305.
- Kuhn M, Johnson K (2013) *Applied Predictive Modeling*. Springer, Chapter 4: Over-Fitting and Model Tuning.
