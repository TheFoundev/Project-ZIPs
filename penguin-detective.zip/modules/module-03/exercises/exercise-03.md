# Module 3 Exercises: KNN Mechanics & Hyperparameter Optimization

## Exercise 3.1: Manual 4D Euclidean Distance Calculation (15 min)
**Objective:** Calculate Euclidean distance between two standardized vectors manually.
**Problem Statement:** Given a standardized query point and two candidate training points, compute the 4D Euclidean distance to determine which candidate is the nearest neighbor.

**Given Data:**
- Query specimen $q = [0.0, 1.0, -0.5, -0.5]$
- Candidate 1 (Adelie): $c_1 = [-0.2, 0.8, -0.6, -0.4]$
- Candidate 2 (Chinstrap): $c_2 = [0.8, 0.9, -0.4, -0.5]$

**Requirements:**
1. Compute the squared coordinate differences for $q$ vs $c_1$.
2. Compute the squared coordinate differences for $q$ vs $c_2$.
3. Sum the squared differences and take the square root.
4. Identify which candidate is closer to $q$.

**Acceptance Criteria:**
- [ ] Distance $d(q, c_1)$ calculated as $\sqrt{(-0.2)^2 + (-0.2)^2 + (-0.1)^2 + (0.1)^2} = \sqrt{0.04 + 0.04 + 0.01 + 0.01} = \sqrt{0.10} \approx 0.316$.
- [ ] Distance $d(q, c_2)$ calculated as $\sqrt{(0.8)^2 + (-0.1)^2 + (0.1)^2 + (0.0)^2} = \sqrt{0.64 + 0.01 + 0.01 + 0.00} = \sqrt{0.66} \approx 0.812$.
- [ ] Candidate 1 (Adelie) correctly identified as the nearest neighbor ($0.316 < 0.812$).

---

## Exercise 3.2: Hyperparameter Tuning Loop Implementation (15 min)
**Objective:** Implement a loop evaluating KNN performance across multiple values of $k$.
**Problem Statement:** Write a Python script that evaluates `KNeighborsClassifier` for $k \in (1, 3, 5, 7, 9)$ on the standardized penguin dataset and prints a formatted summary table.

**Requirements:**
1. Construct pipelines with `StandardScaler` and `KNeighborsClassifier(n_neighbors=k)`.
2. Train on `X_train` and predict on `X_test`.
3. Record `accuracy_score` for each $k$.
4. Print each $k$ and its formatted accuracy percentage.

**Acceptance Criteria:**
- [ ] Loop correctly iterates over $k \in (1, 3, 5, 7, 9)$.
- [ ] Accuracies recorded for both train and test splits.
- [ ] Formatted output matches `k=X: accuracy XX.X%`.

---

## Exercise 3.3: Bias-Variance Tradeoff Analysis (15 min)
**Objective:** Explain how changing $k$ shifts a model between overfitting and underfitting.
**Problem Statement:** Contrast the decision boundaries and error characteristics of $k=1$ and $k=112$ on the penguin dataset.

**Requirements:**
1. Describe the boundary geometry for $k=1$.
2. Describe the boundary geometry for $k=112$.
3. Explain which model suffers from high variance and which suffers from high bias.
4. Justify why $k=3$ is an appropriate operating point.

**Acceptance Criteria:**
- [ ] $k=1$ identified as high variance, low bias, jagged decision boundaries.
- [ ] $k=112$ identified as high bias, zero variance, predicting only the majority class.
- [ ] $k=3$ justified as balancing noise tolerance with localized sensitivity.
