# Prerequisites

Before starting **The Penguin Detective**, ensure you meet the following baseline requirements:

## Skills Required
- **Python Fundamentals**: Variables, dictionaries, lists, loops, functions, and import statements.
- **Tabular Data Concepts**: Basic understanding of rows, columns, features (independent variables), and target labels (dependent variable).
- **Basic Mathematics**: Euclidean distance between two points ($d = \sqrt{(x_2-x_1)^2 + (y_2-y_1)^2}$), mean, and percentage calculations.
- **Command-Line Basics**: Navigating directories, executing Python scripts, and installing packages with `pip`.

## Tools Required
- **Python**: Version 3.8 or newer (tested on Python 3.10+).
- **Package Manager**: `pip` (standard Python package installer).
- **Code Editor**: VS Code, PyCharm, or any text editor with syntax highlighting.
- **Terminal / Shell**: Bash, Zsh, or Windows Command Prompt / PowerShell.

## Required Python Libraries
- `pandas`: For CSV loading and DataFrame manipulation.
- `numpy`: For numerical computations and array operations.
- `matplotlib`: For rendering cluster scatter plots and confusion matrix figures.
- `scikit-learn`: For data splitting, feature scaling, KNN classification, and evaluation metrics.

## Concepts to Review
- The difference between **Supervised Learning** (learning with labels) and **Unsupervised Learning** (pattern discovery without labels).
- The difference between **Classification** (discrete class outputs) and **Regression** (continuous numerical outputs).
- Why units of measurement (e.g., grams vs millimeters) impact geometric distance calculations.
