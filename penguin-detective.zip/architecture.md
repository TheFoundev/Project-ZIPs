# Architecture: The Penguin Detective

This document details the system design, data flow, and pipeline architecture implemented in `main.py`.

## Pipeline Architecture Diagram

```text
[ data/penguins.csv ]
         │
         ▼
[ pd.read_csv() ] ──> DataFrame (150 rows × 5 columns)
         │
         ├──> X: Features (bill_length_mm, bill_depth_mm, flipper_length_mm, body_mass_g) [150, 4]
         └──> y: Target (species: Adelie, Chinstrap, Gentoo) [150,]
         │
         ▼
[ train_test_split() ] ── (test_size=0.25, random_state=42, stratify=y)
         ├──> Train Set: X_train (112, 4), y_train (112,)
         └──> Test Set:  X_test (38, 4),   y_test (38,)
         │
         ▼
[ Pipeline Model Training & Evaluation Loop for k in (3, 5) ]
         │
         ├── Step 1: StandardScaler().fit_transform(X_train)
         └── Step 2: KNeighborsClassifier(n_neighbors=k).fit(scaled_X_train, y_train)
         │
         ▼
[ Model Selection: Choose best k by test accuracy ] ──> k=3 selected (94.7%)
         │
         ├──> Classification Report & Confusion Matrix
         ├──> Mystery Penguin Inference: predict() & predict_proba() ──> Adelie (100%)
         └──> Matplotlib Visualizations (penguin_scatter.png & confusion_matrix.png)
         │
         ▼
[ Artifact Generation: outputs/metrics.txt, penguin_scatter.png, confusion_matrix.png ]
```

## Key Components

1. **Data Ingestion Module**
   - Source: `data/penguins.csv` (150 rows: 50 Adelie, 50 Chinstrap, 50 Gentoo).
   - Separation of 4 continuous numeric predictor features from the multi-class categorical target label.

2. **Stratified Partitioning**
   - Uses `test_size=0.25` (38 test samples, 112 train samples).
   - `stratify=y` guarantees equal proportional representation of each species across both splits (12 Adelie, 13 Chinstrap, 13 Gentoo in test).

3. **Composite Scikit-Learn Pipeline**
   - **Transformer**: `StandardScaler` calculates mean $\mu$ and standard deviation $\sigma$ solely on `X_train`, standardizing all 4 dimensions to zero mean and unit variance ($z = \frac{x - \mu}{\sigma}$).
   - **Estimator**: `KNeighborsClassifier(n_neighbors=k)` performs instance-based classification using Euclidean distance in 4D standardized space.

4. **Hyperparameter Selection Engine**
   - Compares candidate values `k=3` and `k=5`.
   - Records accuracy metrics on the held-out test partition.
   - Selects the top-performing configuration (`best_k = 3`).

5. **Inference & Confidence Engine**
   - Takes a new specimen DataFrame: `[39.0mm, 18.0mm, 190mm, 3700g]`.
   - Executes `predict()` to assign the winning class label.
   - Executes `predict_proba()` to compute posterior neighbor consensus confidence.

6. **Evaluation & Diagnostic Exporter**
   - Creates a 2D cluster scatter plot (`penguin_scatter.png`) contrasting bill length against flipper length, color-coded with `COLOURS`, overlaying the new specimen as a black star marker.
   - Produces a normalized or counts confusion matrix display (`confusion_matrix.png`).
   - Exports quantitative evaluation tables into `metrics.txt`.
