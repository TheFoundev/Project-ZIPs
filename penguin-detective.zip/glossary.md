# Glossary

| Term | Definition |
|---|---|
| **K-Nearest Neighbours (KNN)** | An instance-based supervised learning algorithm that classifies a new sample based on the plurality vote of its $k$ closest neighbors in feature space. |
| **Morphometrics** | Quantitative analysis of the size, shape, and physical proportions of organisms or biological structures (e.g., bill length, flipper length). |
| **Feature (Predictor)** | An individual measurable property or characteristic of a phenomenon being observed (e.g., `bill_depth_mm`). |
| **Target Label (Class)** | The discrete categorical outcome or identity that a supervised classification algorithm attempts to predict (e.g., `species`). |
| **Multi-Class Classification** | A classification task where instances are categorized into one of three or more distinct discrete classes. |
| **StandardScaler** | A preprocessing transformer that standardizes features by removing the mean and scaling to unit variance ($z = (x - \mu) / \sigma$). |
| **Pipeline** | A scikit-learn utility that chains data transformers and a final estimator into a single unified object, preventing data leakage during training and validation. |
| **Hyperparameter** | A configuration parameter whose value is set before the learning process begins (e.g., $k$, the number of neighbors in KNN), rather than learned from data. |
| **Hyperparameter Tuning** | The empirical process of testing multiple hyperparameter configurations to select the one that optimizes validation performance. |
| **Stratified Split** | A data splitting technique that partitions datasets while maintaining identical class proportions across both training and test subsets. |
| **Euclidean Distance** | The straight-line geometric distance between two points in Euclidean space, calculated as $d(p, q) = \sqrt{\sum_{i=1}^n (p_i - q_i)^2}$. |
| **predict_proba()** | A scikit-learn method returning the fraction of nearest neighbors belonging to each target class, interpreted as posterior prediction confidence. |
| **Confusion Matrix** | A diagnostic grid layout where rows represent true class instances and columns represent predicted class instances, exposing specific classification errors. |
| **Precision** | The fraction of positive predictions that were correct: $\frac{TP}{TP + FP}$. |
| **Recall** | The fraction of actual positive instances that were correctly retrieved: $\frac{TP}{TP + FN}$. |
| **F1-Score** | The harmonic mean of precision and recall: $2 \times \frac{\text{Precision} \times \text{Recall}}{\text{Precision} + \text{Recall}}$. |
| **Support** | The actual number of true instances belonging to a specific class within the evaluation dataset. |
| **Feature Ablation** | An investigative experiment in which one or more features are intentionally omitted to quantify their direct contribution to model accuracy. |
