# Prerequisites: The Used Car Price Whisperer

## Skills Required
- Basic Python syntax (functions, variables, dictionaries, f-strings)
- Working with CSV files and tabular data in pandas
- Understanding of 2D arrays vs. 1D vectors
- Basic Cartesian geometry and algebra (linear equations: $y = mx + b$)
- Familiarity with the terminal / command line

## Tools Required
- Python 3.8+
- `pip` package manager
- Code editor or IDE (VS Code, PyCharm, or text editor)
- Operating system terminal (bash, zsh, or PowerShell)

## Packages
- `pandas` (>= 1.3.0)
- `scikit-learn` (>= 1.0.0)
- `matplotlib` (>= 3.4.0)

## Knowledge to Review
- **Features vs. Target:** Independent variables (clues) vs. the dependent variable to predict.
- **Multiple Regression:** How multiple input features combine linearly into a single output prediction.
- **Train/Test Splitting:** Why models must be evaluated on unseen holdout data to test generalization.
- **Depreciation:** The economic concept that vehicles lose value over time and cumulative distance.
