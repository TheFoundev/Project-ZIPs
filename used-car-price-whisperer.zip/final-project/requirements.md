# Final Project Requirements: The Used Car Price Whisperer

## Project Objective

Independently recreate and verify the complete **Used Car Price Whisperer** machine learning pipeline from scratch, mirroring the implementation in [`main.py`](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML%20Beginners/projects/07_car_price/main.py). Your pipeline will ingest historical sales records, separate features from the target, perform a reproducible train/test split, train a multiple linear regression model using scikit-learn, extract and interpret the learned depreciation weights, evaluate performance using MAE and $R^2$, predict the fair market value of a benchmark vehicle (5 years old, 60,000 km), generate an actual-vs-predicted diagnostic plot, and export machine-readable metrics to disk.

---

## Functional Requirements

### 1. Imports, Backend & Environment Setup
- Configure matplotlib to use the non-interactive `"Agg"` backend **before** importing `matplotlib.pyplot`.
- Import `Path` from `pathlib`, `pandas`, `LinearRegression` from `sklearn.linear_model`, `mean_absolute_error` and `r2_score` from `sklearn.metrics`, and `train_test_split` from `sklearn.model_selection`.
- Dynamically resolve directory paths using `Path(__file__).resolve().parent` to ensure portability.
- Ensure the `outputs/` directory is automatically created using `mkdir(exist_ok=True)`.

### 2. Data Ingestion & Validation
- Ingest `data/used_cars.csv` into a pandas DataFrame using `pd.read_csv()`.
- Verify the dataset contains exactly 45 rows and 3 columns (`age_years`, `kilometers`, `price_usd`).
- Verify there are zero null or missing values across all columns.

### 3. Feature Matrix & Target Vector Construction
- Construct the 2D feature matrix `X = df[["age_years", "kilometers"]]` using double-bracket DataFrame indexing (shape: `(45, 2)`).
- Construct the 1D target vector `y = df["price_usd"]` using single-bracket Series indexing (shape: `(45,)`).
- Ensure no target data leaks into the feature matrix.

### 4. Reproducible Train/Test Partitioning
- Partition the dataset using `train_test_split(X, y, test_size=0.25, random_state=42)`.
- Verify that the resulting subsets have exactly:
  - `X_train`: 33 rows, 2 columns
  - `y_train`: 33 samples
  - `X_test`: 12 rows, 2 columns
  - `y_test`: 12 samples

### 5. Model Instantiation & Training
- Instantiate `LinearRegression()` from scikit-learn.
- Train the model using `.fit(X_train, y_train)` strictly on the training partition.

### 6. Coefficient Extraction & Equation Deconstruction
- Unpack the learned coefficient array `model.coef_` into `age_weight` and `km_weight`.
- Extract the baseline intercept from `model.intercept_`.
- Formulate the pricing equation:
  $$\text{price} = \text{intercept} + (\text{age\_weight} \times \text{age}) + (\text{km\_weight} \times \text{km})$$
- Formulate plain-English translations:
  - Depreciation per additional year ($\approx -\$1,242$)
  - Depreciation per additional 10,000 km ($\approx -\$922$)

### 7. Evaluation & Metrics Calculation
- Generate predictions for all test instances: `predictions = model.predict(X_test)`.
- Compute Mean Absolute Error (MAE) using `mean_absolute_error(y_test, predictions)` ($\approx \$905.97$, displayed as `~$906`).
- Compute $R^2$ score using `r2_score(y_test, predictions)` ($\approx 0.9280$, displayed as `~0.93`).

### 8. Benchmark Vehicle Valuation
- Create a single-row DataFrame representing the benchmark test car:
  ```python
  example = pd.DataFrame([{"age_years": 5, "kilometers": 60_000}])
  ```
- Generate and extract the float prediction: `example_price = float(model.predict(example)[0])` ($\approx \$15,076.97$, displayed as `~$15,077`).

### 9. Terminal Summary Report
- Output a formatted console banner and report matching `main.py` formatting:
  ```text
  ============================================================
  THE USED CAR PRICE WHISPERER
  ============================================================
  Equation: price = 26,818 + (-1,242 x age) + (-0.09 x km)
  Each extra year is associated with about $1,242 less value.
  Each extra 10,000 km is associated with about $922 less value.
  Mean absolute error: $906
  R-squared: 0.93
  Prediction for a 5-year-old car with 60,000 km: $15,077
  ```

### 10. Actual-vs-Predicted Diagnostic Visualization
- Create a square figure canvas with `fig, ax = plt.subplots(figsize=(6, 6))`.
- Render the test observations using `ax.scatter(y_test, predictions, color="#2471a3", s=65, alpha=0.85)`.
- Dynamically determine plot limits from actuals and predictions (`low = min(...)`, `high = max(...)`).
- Draw the 45-degree dashed red reference line from `[low, high]` to `[low, high]` (`color="#c0392b", linestyle="--", label="perfect prediction"`).
- Set axis labels ("Actual price ($)", "Predicted price ($)"), title, legend, and subtle grid (`alpha=0.25`).
- Export to `outputs/actual_vs_predicted.png` with `dpi=150` and `bbox_inches="tight"`.
- Call `plt.close(fig)` to release memory resources.

### 11. Artifact Persistence & Cleanup
- Open `outputs/metrics.txt` using a context manager (`with open(...) as handle:`) with `encoding="utf-8"`.
- Write the six required metrics with exact formatting:
  ```text
  intercept: 26817.96
  age coefficient: -1241.53
  km coefficient: -0.092223
  MAE: 905.97
  R2: 0.9280
  example prediction: 15076.97
  ```
- Print confirmation statement and the categorical extension suggestion.
- Protect entry point with `if __name__ == "__main__": main()`.

---

## Technical Constraints & Submission Deliverables

1. **Language & Libraries:** Python 3.8+, pandas, scikit-learn, matplotlib.
2. **Code File:** Submit a clean, executable `main.py` script.
3. **Generated Artifacts:**
   - `outputs/actual_vs_predicted.png`
   - `outputs/metrics.txt`
4. **Analysis Memo:** A brief 1-page written technical reflection covering:
   - Parameter interpretation in economic terms
   - Evaluation of MAE ($906) and $R^2$ (0.93)
   - Discussion of linear model boundary limitations and unmeasured features
