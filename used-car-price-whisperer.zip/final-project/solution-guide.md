# Mentor Solution Guide: The Used Car Price Whisperer

## Overview

This guide provides instructors and mentors with the reference implementation, review checkpoints, expected numerical outputs, and grading guidelines for the final project of **The Used Car Price Whisperer**. Mentors should verify that the student's submission follows the architecture and numerical precision established in [`main.py`](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML%20Beginners/projects/07_car_price/main.py).

---

## Complete Reference Solution

```python
"""Project 07: The Used Car Price Whisperer (multiple linear regression).

Run:
    python main.py

Two clues (age and kilometres) are combined into one price estimate.  The
script prints the model's weights so you can see which clue matters more.
"""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)


def main() -> None:
    df = pd.read_csv(DATA / "used_cars.csv")
    X = df[["age_years", "kilometers"]]
    y = df["price_usd"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42
    )

    model = LinearRegression()
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    mae = mean_absolute_error(y_test, predictions)
    r2 = r2_score(y_test, predictions)
    age_weight, km_weight = model.coef_
    intercept = model.intercept_

    example = pd.DataFrame([{"age_years": 5, "kilometers": 60_000}])
    example_price = float(model.predict(example)[0])

    print("=" * 60)
    print("THE USED CAR PRICE WHISPERER")
    print("=" * 60)
    print(f"Equation: price = {intercept:,.0f} + ({age_weight:,.0f} x age) + ({km_weight:.2f} x km)")
    print(f"Each extra year is associated with about ${abs(age_weight):,.0f} less value.")
    print(f"Each extra 10,000 km is associated with about ${abs(km_weight) * 10_000:,.0f} less value.")
    print(f"Mean absolute error: ${mae:,.0f}")
    print(f"R-squared: {r2:.2f}")
    print(f"Prediction for a 5-year-old car with 60,000 km: ${example_price:,.0f}")

    fig, ax = plt.subplots(figsize=(6, 6))
    ax.scatter(y_test, predictions, color="#2471a3", s=65, alpha=0.85)
    low = min(y_test.min(), predictions.min())
    high = max(y_test.max(), predictions.max())
    ax.plot([low, high], [low, high], color="#c0392b", linestyle="--", label="perfect prediction")
    ax.set_xlabel("Actual price ($)")
    ax.set_ylabel("Predicted price ($)")
    ax.set_title("Actual vs. predicted used-car prices")
    ax.legend()
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(OUT / "actual_vs_predicted.png", dpi=150, bbox_inches="tight")
    plt.close(fig)

    with open(OUT / "metrics.txt", "w", encoding="utf-8") as handle:
        handle.write(f"intercept: {intercept:.2f}\n")
        handle.write(f"age coefficient: {age_weight:.2f}\n")
        handle.write(f"km coefficient: {km_weight:.6f}\n")
        handle.write(f"MAE: {mae:.2f}\n")
        handle.write(f"R2: {r2:.4f}\n")
        handle.write(f"example prediction: {example_price:.2f}\n")

    print("\nSaved: outputs/actual_vs_predicted.png, outputs/metrics.txt")
    print("Try this: add a 'fuel_type' column (petrol/diesel) and think about encoding it.")


if __name__ == "__main__":
    main()
```

---

## Checkpoint-by-Checkpoint Mentor Review

### Checkpoint 1: Backend & Path Resolution (lines 12–25)
- **Verification:**
  - `matplotlib.use("Agg")` must execute **prior** to `import matplotlib.pyplot as plt`.
  - `BASE = Path(__file__).resolve().parent` establishes dynamic root resolution.
  - `OUT.mkdir(exist_ok=True)` executes before any file write operations.
- **Common Mistakes:**
  - Hardcoding absolute paths like `/home/user/...` which fail on grading machines.
  - Omission of `exist_ok=True`, crashing if `outputs/` already exists.

### Checkpoint 2: Data Ingestion & Shape (lines 28–30)
- **Verification:**
  - Reads `data/used_cars.csv` with pandas.
  - `X = df[["age_years", "kilometers"]]` uses double brackets to produce a 2D DataFrame (shape: `(45, 2)`).
  - `y = df["price_usd"]` uses single brackets to produce a 1D Series (shape: `(45,)`).
- **Common Mistakes:**
  - Passing single brackets for `X`, creating a 1D Series that scikit-learn rejects.
  - Inadvertently including `price_usd` inside `X`, resulting in 100% data leakage ($R^2 = 1.0$).

### Checkpoint 3: Splitting & Reproducibility (lines 32–34)
- **Verification:**
  - Uses `test_size=0.25` and `random_state=42`.
  - Resulting training set contains exactly 33 rows; testing set contains exactly 12 rows.
- **Common Mistakes:**
  - Changing or omitting `random_state`, which causes coefficients and metrics to deviate from the reference values.

### Checkpoint 4: Training & Parameter Extraction (lines 36–44)
- **Verification:**
  - Fits model strictly on `(X_train, y_train)`.
  - Extracts `model.coef_` into two scalar floats: `age_weight` and `km_weight`.
  - Extracts `model.intercept_` as scalar float.
- **Expected Values:**
  - Intercept: $26,817.96
  - Age Weight: -$1,241.53 per year
  - KM Weight: -$0.092223 per kilometer

### Checkpoint 5: Test Evaluation & Metrics (lines 40–41)
- **Verification:**
  - Predictions generated via `model.predict(X_test)`.
  - MAE computed using `mean_absolute_error(y_test, predictions)` ($\approx \$905.97$).
  - $R^2$ computed using `r2_score(y_test, predictions)` ($\approx 0.9280$).
- **Common Mistakes:**
  - Evaluating metrics on `y_train` instead of `y_test`, yielding overly optimistic numbers.
  - Reversing arguments in `r2_score(predictions, y_test)`.

### Checkpoint 6: Inference on Benchmark Vehicle (lines 45–46)
- **Verification:**
  - Passes a DataFrame with matching column names: `pd.DataFrame([{"age_years": 5, "kilometers": 60_000}])`.
  - Evaluates prediction as float: `float(model.predict(example)[0])`.
- **Expected Value:**
  - Prediction: $\$15,076.97$ (displayed as `$15,077`).

### Checkpoint 7: Diagnostic Scatter Plot (lines 58–70)
- **Verification:**
  - Square aspect ratio `figsize=(6, 6)`.
  - Test dots plotted with actuals on X, predictions on Y (`color="#2471a3"`).
  - Red dashed line (`#c0392b`) drawn from `low` to `high`.
  - Labels, title, legend, and subtle grid (`alpha=0.25`).
  - Calls `plt.close(fig)` after `fig.savefig()`.

### Checkpoint 8: Metric Persistence (lines 72–80)
- **Verification:**
  - Uses context manager `with open(...) as handle:`.
  - Sets `encoding="utf-8"`.
  - Formats `km coefficient` with `:.6f` and `R2` with `:.4f`.
  - Verifies `outputs/metrics.txt` matches expected schema.

---

## Benchmark Audit Reference Table

| Metric / Parameter | Exact Value | Terminal Display | `metrics.txt` Entry |
|---|---|---|---|
| **Intercept ($\beta_0$)** | 26817.958... | `price = 26,818 + ...` | `intercept: 26817.96` |
| **Age Coefficient ($\beta_1$)** | -1241.528... | `-$1,242 less value` | `age coefficient: -1241.53` |
| **KM Coefficient ($\beta_2$)** | -0.092223... | `-$922 less value` | `km coefficient: -0.092223` |
| **MAE** | 905.972... | `$906` | `MAE: 905.97` |
| **$R^2$** | 0.92804... | `0.93` | `R2: 0.9280` |
| **5 yr / 60k km Car** | 15076.969... | `$15,077` | `example prediction: 15076.97` |
