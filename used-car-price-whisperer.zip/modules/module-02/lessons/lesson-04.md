# Lesson 04: Correlation Analysis and Feature Independence

**Lesson ID:** lesson-04  
**Module:** module-02  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Define the Pearson correlation coefficient ($r$) and interpret its scale from $-1.0$ to $+1.0$.
- Generate and interpret a correlation matrix using `df.corr()`.
- Analyze the strong negative correlation between `age_years` and `price_usd` ($r \approx -0.749$).
- Analyze the strong negative correlation between `kilometers` and `price_usd` ($r \approx -0.618$).
- Discover and explain the critical near-zero correlation between `age_years` and `kilometers` ($r \approx +0.0035$), and explain why this independence makes multiple regression particularly effective.

## Prerequisites

Completion of [Lesson 01](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-02/lessons/lesson-01.md), [Lesson 02](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-02/lessons/lesson-02.md), and [Lesson 03](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-02/lessons/lesson-03.md). Basic understanding of linear trends.

## Concept Explanation

### What is Pearson Correlation?
In statistics, the **Pearson correlation coefficient** ($r$) measures the strength and direction of the linear relationship between two continuous variables. The mathematical formula for sample correlation between $x$ and $y$ is:
$$r = \frac{\sum (x_i - \bar{x})(y_i - \bar{y})}{\sqrt{\sum (x_i - \bar{x})^2 \sum (y_i - \bar{y})^2}}$$

The correlation coefficient always produces a value bounded strictly between $-1.0$ and $+1.0$:
- **$r = +1.0$:** Perfect positive linear relationship (as $x$ increases, $y$ increases proportionally).
- **$r = 0.0$:** Zero linear correlation (knowing $x$ gives no linear predictive information about $y$).
- **$r = -1.0$:** Perfect negative linear relationship (as $x$ increases, $y$ decreases proportionally).

### Computing the Correlation Matrix in Pandas
In pandas, computing all pairwise correlations requires a single method call:
```python
df.corr()
```

When executed on `used_cars.csv`, pandas produces the following correlation matrix:

| Variable | `age_years` | `kilometers` | `price_usd` |
|---|---|---|---|
| **`age_years`** | **1.000000** | 0.003550 | **-0.748999** |
| **`kilometers`** | 0.003550 | **1.000000** | **-0.618142** |
| **`price_usd`** | **-0.748999** | **-0.618142** | **1.000000** |

### Analyzing the Findings

#### 1. Feature-to-Target Correlations (Strong Negative Relationships)
- **`corr(age_years, price_usd) = -0.749`:** There is a strong negative linear association between a car's age and its transaction price. As a car gets older, its market value drops markedly. An $r$ value of $-0.75$ indicates that chronological age alone explains a substantial portion of price variance.
- **`corr(kilometers, price_usd) = -0.618`:** There is also a substantial negative linear association between odometer mileage and price. As a vehicle logs more kilometers on the road, its market value declines noticeably.

Both features demonstrate clear, economically sound relationships with the target variable, confirming that both features contain valuable predictive signals for our model.

#### 2. Feature-to-Feature Correlation (The "Holy Grail" of Multiple Regression)
Now examine the intersection of the two input features:
$$\text{corr}(\text{age\_years}, \text{kilometers}) = +0.003550 \approx 0.0035$$

This is an extraordinary finding. A correlation of $+0.0035$ is virtually **zero** ($r \approx 0$).

What does this mean in plain language?
It means that in this dataset, **a car's age tells you virtually nothing about how many kilometers it has been driven**, and **its odometer mileage tells you virtually nothing about its calendar age**!
- You have some 2-year-old cars with high mileage (e.g., Row 10: 2 years old, 142,600 km).
- You have some 8-year-old cars with ultra-low mileage (e.g., Row 7: 8 years old, 8,400 km).
- You have 12-year-old cars with low mileage (Row 15: 12 years old, 31,900 km).
- You have 7-year-old cars with high mileage (Row 23: 7 years old, 127,200 km).

### Why Feature Independence is Ideal for Multiple Regression
When two features are highly correlated with each other (a condition known as **multicollinearity**), they fight over the same predictive variance, making model coefficients unstable and difficult to interpret.

However, when two features are completely independent of each other ($r \approx 0$) yet **both strongly correlated with the target** ($r = -0.75$ and $r = -0.62$), they provide **orthogonal (complementary) information**.
- `age_years` provides one independent clue about value loss due to calendar aging.
- `kilometers` provides a completely distinct, independent clue about value loss due to physical road wear.

Combining both independent signals allows the multiple linear regression model to explain far more variance ($R^2 \approx 0.93$) than either feature could ever explain alone!

## Relevant Code (from main.py, lines 29-37)

```python
    df = pd.read_csv(DATA / "used_cars.csv")
    X = df[["age_years", "kilometers"]]
    y = df["price_usd"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42
    )

    model = LinearRegression()
    model.fit(X_train, y_train)
```

### Code explanation
- Because `df[["age_years", "kilometers"]]` contains two complementary features with near-zero mutual correlation, `LinearRegression()` can cleanly assign separate, stable regression coefficients to each feature during `.fit()`.

## Worked Example

**Problem:**  
Explain why combining two independent features ($r \approx 0$) each correlated with the target yields a higher predictive score than combining two redundant features ($r \approx 0.95$).

**Scenario Comparison:**
- **Scenario A (Redundant Features):** Suppose we predict price using `kilometers` and `miles`. Since $1 \text{ mile} = 1.609 \text{ km}$, their mutual correlation is $r = +1.0$. Knowing both gives you zero extra information over knowing just one. The second feature adds nothing new.
- **Scenario B (Independent Features - Our Project):** We predict price using `age_years` and `kilometers`. Mutual correlation is $r = +0.0035$. A car can be old with low miles, or young with high miles. Knowing the age gives you information that mileage cannot reveal, and knowing the mileage gives you information that age cannot reveal.

**Empirical Result in our Project:**
- Model using Age alone: $R^2 \approx 0.48$ (explains only 48% of variance).
- Model using Kilometers alone: $R^2 \approx -0.46$ on test set (unstable on test data).
- **Multiple Regression combining both:** $R^2 = 0.93$ (explains **93% of variance**)!

The synergy between independent features boosts explained variance from 48% to 93%!

## Step-by-Step Student Instructions

1. **Open Python:** Launch an interactive Python session in your terminal.
2. **Compute Correlation Matrix:**
   ```python
   import pandas as pd
   df = pd.read_csv("data/used_cars.csv")
   matrix = df.corr()
   print(matrix)
   ```
3. **Verify Target Relationships:** Look at the `price_usd` column. Confirm that `age_years` is $-0.748999$ and `kilometers` is $-0.618142$.
4. **Verify Mutual Independence:** Look at the intersection between `age_years` and `kilometers`. Confirm that the value is approximately $+0.003550$.
5. **Draw the Conclusion:** Note that both features are strong negative predictors of price, but completely uncorrelated with each other.

## Expected Output or Observable Behaviour

Executing `df.corr()` prints the 3×3 symmetric matrix with 1.0 along the main diagonal, negative values along the price row/column, and ~0.0035 at the age/kilometers intersection.

## Practical Exercises

- **Exercise 4.1:** If an analyst claims that "older cars always have higher mileage," what empirical evidence from our correlation matrix directly refutes this claim?
- **Exercise 4.2:** Explain why correlation between a variable and itself (the main diagonal of the matrix) is always exactly $1.000000$.
- **Exercise 4.3:** If you discovered a third feature, `previous_owners`, that had a correlation of $+0.98$ with `age_years`, would you expect it to add significant new predictive power over `age_years`? Why or why not?

## Common Mistakes and Debugging

| Mistake | Why it happens | How to avoid or fix |
|---|---|---|
| Interpreting negative correlation as "no correlation" | Confusing the sign (direction) with the magnitude (strength). | A correlation of $-0.75$ is very strong! Near zero ($0.0$) means no correlation; $-1.0$ is a perfect negative relationship. |
| Confusing correlation with causation | Assuming that high mileage literally causes time to pass, or vice versa. | Correlation measures linear association, not mechanistic causality. |
| Calculating correlation on non-numeric data | Passing raw text columns to `df.corr()`. | Ensure columns are numeric; pandas will raise a warning or omit non-numeric columns. |

## Best Practices and Security Considerations

- **Always Inspect Feature Correlations:** Always generate a correlation matrix before modeling to screen for multicollinearity between predictors.
- **Check Directions of Association:** Verify that the signs of correlations align with domain expectations (e.g., vehicle age and mileage should negatively correlate with resale value).
- **Beware of Non-Linear Relationships:** Remember that Pearson correlation measures *linear* relationships. A non-linear relationship (e.g., U-shaped) might have $r \approx 0$ despite having a strong mathematical pattern.

## Summary

In Lesson 04, we performed correlation analysis on `used_cars.csv`. We discovered that both `age_years` ($r \approx -0.75$) and `kilometers` ($r \approx -0.62$) exhibit strong negative linear relationships with `price_usd`. Crucially, the correlation between age and kilometers is virtually zero ($r \approx +0.0035$), demonstrating that the two features are mutually independent. This independence provides orthogonal predictive information, making multiple linear regression exceptionally well-suited for this dataset.

## Knowledge-check Questions

1. What is the allowable numerical range for the Pearson correlation coefficient?
2. What are the specific correlation values of `age_years` and `kilometers` with `price_usd` in our dataset?
3. What is the correlation between `age_years` and `kilometers`?
4. Why is a near-zero correlation between two predictive features beneficial in multiple linear regression?
5. Does a negative correlation coefficient mean a weak relationship? Explain why or why not.

## References

- [used_cars.csv](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price/data/used_cars.csv)
- [Pandas DataFrame corr Documentation](https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.corr.html)
- [Pearson Correlation Coefficient (Wikipedia)](https://en.wikipedia.org/wiki/Pearson_correlation_coefficient)
