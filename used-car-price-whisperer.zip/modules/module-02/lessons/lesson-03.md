# Lesson 03: Feature and Target Distributions

**Lesson ID:** lesson-03  
**Module:** module-02  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Use `df.describe()` to extract comprehensive five-number summaries and standard deviations for all columns.
- Analyze the distribution of `age_years`, noting the minimum (0), mean (~6.96), median (8), and maximum (12).
- Analyze the distribution of `kilometers`, noting the minimum (8,400), mean (~85,264), median (93,200), and maximum (148,300).
- Analyze the distribution of `price_usd`, noting the minimum ($1,500), mean (~$10,418), median ($10,063), and maximum ($22,865).
- Identify the presence or absence of extreme outliers and assess data plausibility for linear regression.

## Prerequisites

Completion of [Lesson 01](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-02/lessons/lesson-01.md) and [Lesson 02](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-02/lessons/lesson-02.md). Basic understanding of mean, median, standard deviation, and quartiles.

## Concept Explanation

### The Importance of Exploratory Distribution Analysis
Before training an algorithm, data scientists examine each variable's distribution to answer crucial sanity-check questions:
- Are there negative numbers where only positive numbers make physical sense (e.g., negative car age or negative mileage)?
- Are there absurd typographical errors (e.g., a car with an age of 2,000 years or an odometer reading of 10,000,000 km)?
- Are the variables symmetrically distributed, or are they heavily skewed?
- What is the typical scale and variability of each feature?

In pandas, the single most powerful summary command is `df.describe()`.

### The Five-Number Summary and Statistics
Executing `df.describe()` on `used_cars.csv` yields the following exact table:

| Statistic | `age_years` | `kilometers` | `price_usd` |
|---|---|---|---|
| **Count** | 45.0 | 45.0 | 45.0 |
| **Mean** | 6.955556 (~6.96 yrs) | 85,264.44 km | $10,418.22 |
| **Standard Deviation (`std`)** | 3.717010 (~3.72 yrs) | 43,451.79 km | $6,293.84 |
| **Minimum (`min`)** | 0.0 yrs | 8,400.00 km | $1,500.00 |
| **25% (First Quartile, $Q_1$)** | 3.0 yrs | 44,500.00 km | $5,347.00 |
| **50% (Median, $Q_2$)** | 8.0 yrs | 93,200.00 km | $10,063.00 |
| **75% (Third Quartile, $Q_3$)** | 9.0 yrs | 123,000.00 km | $14,012.00 |
| **Maximum (`max`)** | 12.0 yrs | 148,300.00 km | $22,865.00 |

### Deep-Dive into Variable Characteristics

#### 1. Vehicle Age (`age_years`)
- The age ranges from 0 to 12 years.
- The minimum of 0 represents a car in its initial registration year (less than 12 months old).
- The median age is 8.0 years, while the mean is ~6.96 years. The mean is slightly lower than the median because several young cars (ages 0, 1, 2) pull the arithmetic mean down.
- The interquartile range ($IQR = Q_3 - Q_1$) is $9.0 - 3.0 = 6.0$ years. Over 50% of the vehicles in the sample are between 3 and 9 years old.

#### 2. Cumulative Distance (`kilometers`)
- Distances range from 8,400 km to 148,300 km.
- The standard deviation is large: ~43,452 km. This wide variability provides ample variance for the regression model to detect the relationship between distance driven and price erosion.
- The median is 93,200 km, and the 75th percentile is 123,000 km, indicating a healthy mix of moderately driven cars and high-mileage road vehicles.

#### 3. Selling Price (`price_usd`)
- The prices range from $1,500 to $22,865.
- Notice the remarkable alignment between the mean ($10,418.22) and the median ($10,063.00). In statistics, when the mean and median are closely aligned, the distribution is relatively balanced and symmetrical without massive distortion from extreme outliers!
- The standard deviation of $6,293.84 reflects a wide pricing spread, which aligns realistically with vehicles ranging from almost new to heavily worn.

### Assessing Outliers
In linear regression, extreme outliers (e.g., an exotic antique car worth $1,000,000 or a salvage vehicle sold for $1) can act as high-leverage points that distort the fitted regression line. In `used_cars.csv`, all data points fall comfortably within standard passenger car norms. There are no negative numbers, no typographical errors, and no hyper-exotic luxury vehicles.

## Relevant Code (from main.py, lines 28-30)

```python
def main() -> None:
    df = pd.read_csv(DATA / "used_cars.csv")
    X = df[["age_years", "kilometers"]]
    y = df["price_usd"]
```

### Code explanation
- Before slicing `X` and `y`, inspecting `df.describe()` allows the developer to confirm that the distribution ranges align with physical reality.
- `df["price_usd"]` spans a range of ~$1,500 to ~$22,865, establishing the scale of predictions our model will produce.

## Worked Example

**Problem:**  
Using the summary statistics table above, calculate the Interquartile Range (IQR) for `price_usd` and determine the standard 1.5×IQR boundaries for outlier detection. Are there any price outliers in the dataset?

**Step-by-step Calculation:**
1. Identify $Q_1$ and $Q_3$:
   - $Q_1 = \$5,347$
   - $Q_3 = \$14,012$
2. Calculate IQR:
   $$\text{IQR} = Q_3 - Q_1 = 14,012 - 5,347 = \$8,665$$
3. Calculate lower outlier threshold:
   $$\text{Lower Bound} = Q_1 - (1.5 \times \text{IQR}) = 5,347 - (1.5 \times 8,665) = 5,347 - 12,997.5 = -\$7,650.50$$
   *(Since prices cannot be negative, effectively $0).*
4. Calculate upper outlier threshold:
   $$\text{Upper Bound} = Q_3 + (1.5 \times \text{IQR}) = 14,012 + (1.5 \times 8,665) = 14,012 + 12,997.5 = \$27,009.50$$
5. Evaluate actual min and max against thresholds:
   - Minimum price: $1,500 > $0 (Not an outlier).
   - Maximum price: $22,865 < $27,009.50 (Not an outlier).

**Conclusion:**  
Every single price point in the dataset falls within the standard 1.5×IQR boundary! The dataset is remarkably clean, well-behaved, and free of extreme price anomalies.

## Step-by-Step Student Instructions

1. **Launch Python Shell:** Open terminal and start python.
2. **Load Dataset:**
   ```python
   import pandas as pd
   df = pd.read_csv("data/used_cars.csv")
   ```
3. **Generate Summary Table:**
   ```python
   print(df.describe())
   ```
4. **Compare Mean vs Median:** Check `df["price_usd"].mean()` vs `df["price_usd"].median()`. Note how close both values are (~$10,418 vs ~$10,063).
5. **Check Bounds:** Verify `df["age_years"].min() == 0` and `df["age_years"].max() == 12`.

## Expected Output or Observable Behaviour

The terminal prints a clean 8-row statistical summary table matching the figures presented above. All statistics confirm positive, realistic values.

## Practical Exercises

- **Exercise 3.1:** What is the ratio between the maximum kilometers (148,300) and minimum kilometers (8,400)? What does this tell us about the usage diversity of vehicles in this dataset?
- **Exercise 3.2:** Write a line of pandas code to find the row index of the vehicle that has the maximum price ($22,865). (Hint: use `df["price_usd"].idxmax()`).
- **Exercise 3.3:** How many cars in the dataset have an age of 0 years? Use `(df["age_years"] == 0).sum()` to find out.

## Common Mistakes and Debugging

| Mistake | Why it happens | How to avoid or fix |
|---|---|---|
| Assuming `mean` always equals `median` | Assuming all real-world distributions are perfectly Gaussian (bell curves). | Recognize that skewness pulls the mean away from the median. Comparing both reveals skewness. |
| Overlooking feature scale differences | `kilometers` is measured in tens of thousands, while `age_years` is measured in single digits. | Recognize that feature scales differ naturally; scikit-learn's linear regression accommodates different units by adjusting coefficients accordingly. |
| Deleting data points prematurely | Assuming a 0-year-old car or 148,300 km car is a "bad outlier" and deleting it. | Verify whether extreme points represent realistic market observations before pruning data. |

## Best Practices and Security Considerations

- **Distribution Profiling First:** Always run descriptive statistics before building predictive models to understand data bounds.
- **Physical Plausibility Checks:** Ensure features do not violate real-world constraints (e.g., negative distance or prices).
- **Scale Awareness:** When interpreting regression coefficients later, always remember that kilometers are measured in units of 1 km (or 10,000 km), while age is measured in units of 1 year.

## Summary

In Lesson 03, we explored the distributional properties of `used_cars.csv` using `df.describe()`. We discovered that `age_years` spans 0 to 12 years (mean ~6.96), `kilometers` spans 8,400 to 148,300 km (mean ~85,264), and `price_usd` spans $1,500 to $22,865 (mean ~$10,418). The close match between the mean and median price confirms a balanced, outlier-free distribution that is exceptionally well-suited for linear modeling.

## Knowledge-check Questions

1. What pandas method computes count, mean, standard deviation, and quartiles in a single table?
2. What are the minimum and maximum values of `age_years` in the dataset?
3. What is the median price (`50%` percentile) of cars in `used_cars.csv`?
4. What does the close alignment between the mean price ($10,418) and median price ($10,063) suggest about the price distribution?
5. Did our 1.5×IQR outlier analysis identify any extreme price outliers in this dataset?

## References

- [used_cars.csv](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price/data/used_cars.csv)
- [Pandas describe Documentation](https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.describe.html)
- [Exploratory Data Analysis (NIST/SEMATECH e-Handbook)](https://www.itl.nist.gov/div898/handbook/eda/eda.htm)
