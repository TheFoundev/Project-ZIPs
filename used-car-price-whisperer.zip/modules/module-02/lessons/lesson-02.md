# Lesson 02: Loading Data with Pandas

**Lesson ID:** lesson-02  
**Module:** module-02  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Use `pandas.read_csv()` to ingest tabular data into a memory-efficient DataFrame.
- Combine `pathlib.Path` objects directly with pandas I/O functions.
- Inspect newly ingested data using essential exploration methods: `.head()`, `.tail()`, `.info()`, and `.shape`.
- Verify dataset dimensions, confirming the presence of 45 rows and 3 columns.
- Audit data types and confirm the absence of missing or corrupted values.

## Prerequisites

Completion of [Lesson 01](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-02/lessons/lesson-01.md). Familiarity with basic Python imports and tabular spreadsheets.

## Concept Explanation

### Ingesting Tabular Data with Pandas
The pandas library is the gold standard for data manipulation and analysis in Python. Its primary data structure is the **DataFrame**—a two-dimensional, labeled, size-mutable tabular data structure with columns of potentially different types (analogous to an in-memory SQL table or spreadsheet).

In `main.py`, line 28 loads the dataset:
```python
df = pd.read_csv(DATA / "used_cars.csv")
```
Notice how smoothly `pd.read_csv()` accepts the `pathlib.Path` object `DATA / "used_cars.csv"`. You do not need to convert the path to a string (`str(DATA / ...)`), because modern pandas natively supports `os.PathLike` objects.

### Essential DataFrame Inspection Methods
Once data is loaded into memory, a responsible machine learning practitioner immediately inspects its geometry, types, and contents using four core tools:

#### 1. `.shape` Attribute
```python
print(df.shape)  # Output: (45, 3)
```
The `.shape` attribute returns a Python tuple `(n_rows, n_columns)`. For `used_cars.csv`, it returns `(45, 3)`, confirming 45 observations and 3 variables.

#### 2. `.head(n)` and `.tail(n)` Methods
```python
print(df.head(5))
```
Returns the first $n$ rows (default is 5). This allows you to visually verify that headers parsed correctly and data values align with their respective column names:
```text
   age_years  kilometers  price_usd
0          5      105100      10063
1          4       27800      22783
2          9      136600       2784
3         10       78200       4871
4          6      106600      10202
```
Similarly, `.tail(5)` shows the final 5 rows to ensure the file was read completely and did not truncate prematurely.

#### 3. `.info()` Method
```python
df.info()
```
The `.info()` method displays a comprehensive structural summary:
- RangeIndex: 45 entries (index 0 to 44)
- Total columns: 3
- Column names, non-null counts, and data types (`Dtype`)
- Memory usage footprint

For our dataset:
```text
<class 'pandas.core.frame.DataFrame'>
RangeIndex: 45 entries, 0 to 44
Data columns (total 3 columns):
 #   Column      Non-Null Count  Dtype
---  ------      --------------  -----
 0   age_years   45 non-null     int64
 1   kilometers  45 non-null     int64
 2   price_usd   45 non-null     int64
dtypes: int64(3)
memory usage: 1.2 KB
```

### Auditing for Cleanliness and Missing Values
Before proceeding to modeling, we check for missing or null entries using:
```python
missing_counts = df.isnull().sum()
```
In `used_cars.csv`, all columns report exactly 0 missing values. Furthermore, all columns are formatted as `int64` (64-bit integers), meaning no currency formatting strings, commas, or corrupted characters entered the raw data.

## Relevant Code (from main.py, line 28)

```python
def main() -> None:
    df = pd.read_csv(DATA / "used_cars.csv")
    X = df[["age_years", "kilometers"]]
    y = df["price_usd"]
```

### Code explanation
- `pd.read_csv(DATA / "used_cars.csv")`: Reads the raw CSV file using the anchored `DATA` path object.
- The resulting `df` variable stores the complete 45-row by 3-column table ready for slicing and partitioning.

## Worked Example

**Problem:**  
Write a standalone Python script to load `data/used_cars.csv`, verify that exactly 45 rows and 3 columns are loaded, and verify that no column contains null values. If any assertion fails, the script should alert the developer.

**Solution Script:**
```python
from pathlib import Path
import pandas as pd

DATA_DIR = Path(__file__).resolve().parent / "data"
csv_path = DATA_DIR / "used_cars.csv"

# Load dataset
df = pd.read_csv(csv_path)

# Verify shape
expected_shape = (45, 3)
assert df.shape == expected_shape, f"Expected shape {expected_shape}, got {df.shape}"

# Verify columns
expected_cols = ["age_years", "kilometers", "price_usd"]
assert list(df.columns) == expected_cols, f"Column mismatch: {df.columns}"

# Verify zero null values
null_total = df.isnull().sum().sum()
assert null_total == 0, f"Found {null_total} missing values!"

print(f"Dataset successfully verified: {df.shape[0]} rows, {df.shape[1]} columns, 0 nulls.")
```

**Output:**
```text
Dataset successfully verified: 45 rows, 3 columns, 0 nulls.
```

## Step-by-Step Student Instructions

1. **Launch Python:** Open a terminal in the project directory and launch `python3`.
2. **Execute Ingestion:**
   ```python
   import pandas as pd
   df = pd.read_csv("data/used_cars.csv")
   ```
3. **Inspect the Shape:**
   ```python
   print(df.shape)
   ```
   Confirm that the output tuple is `(45, 3)`.
4. **View First and Last Rows:**
   ```python
   print(df.head(3))
   print(df.tail(3))
   ```
5. **Inspect Column Types:**
   ```python
   print(df.dtypes)
   ```
   Confirm that `age_years`, `kilometers`, and `price_usd` are all integer types (`int64`).

## Expected Output or Observable Behaviour

Executing inspection commands on `df` reveals a clean, complete 45×3 integer matrix with zero missing values, ready for slicing into feature and target subsets.

## Practical Exercises

- **Exercise 2.1:** How would you modify `pd.read_csv()` if the CSV file used semicolons `;` as separators instead of commas? (Hint: check the `sep` parameter).
- **Exercise 2.2:** Run `df.sample(5, random_state=10)` in your interactive shell. What does this command do, and why is sampling rows useful when inspecting large datasets?
- **Exercise 2.3:** Write a single line of pandas code to calculate the total number of individual data cells in `df` (Hint: check `df.size`).

## Common Mistakes and Debugging

| Mistake | Why it happens | How to avoid or fix |
|---|---|---|
| Calling `df.shape()` with parentheses | `shape` is a tuple attribute of the DataFrame, not a callable function. | Call `df.shape` without parentheses. |
| Forgetting to assign the return value of `read_csv` | Writing `pd.read_csv(...)` without `df = ...`. | Always assign the output of `pd.read_csv()` to a variable. |
| Looking for file in current directory instead of `DATA` path | Passing `"used_cars.csv"` without `DATA /` prefix. | Use the defined `DATA / "used_cars.csv"` path anchor. |

## Best Practices and Security Considerations

- **Never Trust External Data Unconditionally:** Always verify shapes, column names, and missing values immediately after loading external files.
- **Memory Management:** For large datasets (millions of rows), specify explicit data types with `dtype={...}` to optimize memory consumption.
- **Untrusted CSV Files:** In enterprise applications, beware of "CSV Injection" attacks if the CSV contains formula strings starting with `=`, `@`, or `+`. Our dataset is purely numeric and completely safe.

## Summary

In Lesson 02, we mastered tabular data ingestion using `pandas.read_csv()`. We utilized `.shape`, `.head()`, `.tail()`, and `.info()` to inspect the loaded DataFrame, verifying that `used_cars.csv` contains 45 complete rows, 3 clean integer columns, and zero missing values. This establishes a verified, trustworthy foundation for our regression modeling pipeline.

## Knowledge-check Questions

1. What pandas function is used to read a CSV file into a DataFrame?
2. What does `df.shape` return for `used_cars.csv`?
3. What information does `df.info()` provide that `df.head()` does not?
4. How many missing (null) values exist in `used_cars.csv`?
5. Why is it advantageous that `pd.read_csv()` accepts `pathlib.Path` objects directly?

## References

- [used_cars.csv](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price/data/used_cars.csv)
- [main.py line 28](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price/main.py#L28)
- [Pandas read_csv Documentation](https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html)
