# Lesson 01: Environment Setup, Pathlib, and Project Structure

**Lesson ID:** lesson-01  
**Module:** module-02  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain why robust file path resolution using Python's standard `pathlib` module is essential for portable code.
- Deconstruct the expression `BASE = Path(__file__).resolve().parent` and trace how subdirectories are constructed with the `/` operator.
- Explain the role of `matplotlib.use("Agg")` and why headless graphics rendering is vital for automated scripts and servers.
- Identify the project directory structure, including source code, input datasets (`data/`), and generated artifacts (`outputs/`).
- Safely initialize output directories using `mkdir(exist_ok=True)`.

## Prerequisites

Completion of [Module 01](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-01/module.json). Basic familiarity with terminal commands and running Python files.

## Concept Explanation

### The Problem with Hardcoded Paths
Beginner Python programmers frequently write file paths like `"data/used_cars.csv"` or `"C:\\Users\\Bob\\projects\\data\\used_cars.csv"`. This creates fragile scripts:
- If a user runs the script from any directory other than the project folder (for example, running `python projects/07_car_price/main.py` from their home directory), relative paths break with `FileNotFoundError`.
- If an absolute path is hardcoded, the code only runs on the original author's computer and fails on another operating system or teammate's environment.

Python 3 introduced the `pathlib` module, which offers an object-oriented, cross-platform approach to filesystem paths.

### Anchor Paths with `Path(__file__)`
The proper idiomatic solution is to anchor all paths relative to the script file itself:
```python
BASE = Path(__file__).resolve().parent
```

Let's dissect this statement:
1. `__file__`: A built-in Python variable containing the path of the currently executing script file (`main.py`).
2. `Path(__file__)`: Wraps the raw file string into a rich `pathlib.Path` object.
3. `.resolve()`: Normalizes the path into a complete, canonical absolute path, resolving all symbolic links and relative references.
4. `.parent`: Traverses up one level to retrieve the directory containing `main.py` (the project root directory).

Once `BASE` is defined, subdirectories and files are constructed using Python's intuitive division operator `/`:
```python
DATA = BASE / "data"
OUT = BASE / "outputs"
```
Under the hood, `pathlib` uses forward slashes on Linux/macOS and backslashes on Windows automatically, ensuring complete platform independence!

### Directory Creation: `mkdir(exist_ok=True)`
Before a script writes visual plots or text files, the target directory must exist on the disk. Attempting to write a file into a non-existent folder causes an `IOError` or `FileNotFoundError`.
```python
OUT.mkdir(exist_ok=True)
```
The parameter `exist_ok=True` instructs the operating system: "If the directory does not exist, create it. If it already exists, do nothing and do not raise an error." This ensures idempotent execution.

### Headless Plotting: `matplotlib.use("Agg")`
In interactive GUI environments (such as a local laptop with desktop windows), matplotlib pops up graphical windows when plots are generated. However, in production servers, cloud containers (Docker), automated CI/CD pipelines, or headless remote servers (via SSH), no graphical display window exists. In such environments, attempting to launch an interactive GUI window causes a severe crash: `TclError: no display name and no $DISPLAY environment variable`.

To prevent this, `main.py` explicitly selects the `"Agg"` backend:
```python
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
```
The Anti-Grain Geometry (`Agg`) engine is a high-performance, non-interactive rasterizer that writes directly to image files (such as PNG) without requiring an active desktop display. Calling `matplotlib.use("Agg")` before importing `pyplot` guarantees your script runs flawlessly anywhere.

## Relevant Code (from main.py, lines 10-25)

```python
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)
```

### Code explanation
- Lines 10–19 import standard libraries and set up the `"Agg"` plotting engine prior to importing `pyplot`.
- Lines 21–23 define `BASE`, `DATA`, and `OUT` as robust, anchored `Path` objects.
- Line 24 creates the `outputs` directory if it does not already exist, guaranteeing safe file writes later in the script.

## Worked Example

**Problem:**  
A developer runs `main.py` on a remote Linux server where no monitor is attached and no GUI display server (X11 or Wayland) is installed. Compare what happens if the script uses `matplotlib.use("Agg")` versus what happens if this line is omitted and `plt.show()` is called.

**Comparison:**

| Scenario | Code Executed | Result on Remote Server |
|---|---|---|
| **Without Agg backend** | `import matplotlib.pyplot as plt` followed by default backend | Server attempts to connect to `$DISPLAY`. The process crashes immediately with `UserWarning: Matplotlib is currently using agg, which is a non-GUI backend` or raises a fatal crash if GUI backend is configured. |
| **With Agg backend (main.py)** | `matplotlib.use("Agg")` before importing `plt` | Matplotlib renders pixels purely in memory. When `fig.savefig(OUT / "actual_vs_predicted.png")` is called, the file is cleanly written to disk with zero display errors. |

This demonstrates why setting `"Agg"` is mandatory for automated machine learning batch scripts.

## Step-by-Step Student Instructions

1. **Open the Project Folder:** Navigate to `/home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price/`.
2. **Review the File Tree:** Observe that the folder contains:
   - `main.py` (the primary application script)
   - `data/` (containing `used_cars.csv`)
   - `outputs/` (initially created when `main.py` runs)
3. **Verify Imports in Python:** Start an interactive Python shell and execute:
   ```python
   from pathlib import Path
   import matplotlib
   matplotlib.use("Agg")
   import matplotlib.pyplot as plt
   print("Setup successful!")
   ```
4. **Test Path Resolution:** In the Python shell, print `Path(".").resolve()` to see your current working directory.

## Expected Output or Observable Behaviour

When `main.py` is executed, the directory `outputs/` is automatically created on disk if it was not already present, and no graphical pop-up window appears on the screen. The terminal displays progress smoothly.

## Practical Exercises

- **Exercise 1.1:** Write a 3-line Python snippet using `pathlib.Path` that checks whether `data/used_cars.csv` exists, and prints its file size in bytes using `.stat().st_size`.
- **Exercise 1.2:** What happens if `matplotlib.use("Agg")` is called *after* `import matplotlib.pyplot as plt`? Test this in a scratch script and note any warnings or errors.
- **Exercise 1.3:** Explain why `exist_ok=True` is safer in a shared production script than writing `if not OUT.exists(): OUT.mkdir()`. (Hint: consider race conditions in multi-process execution).

## Common Mistakes and Debugging

| Mistake | Why it happens | How to avoid or fix |
|---|---|---|
| Calling `matplotlib.use("Agg")` after `pyplot` import | Python loads the default backend when `pyplot` is imported. | Always call `matplotlib.use("Agg")` immediately after `import matplotlib` and before `import matplotlib.pyplot as plt`. |
| Using string concatenation for paths (`BASE + "/data"`) | Adding strings to `Path` objects causes a `TypeError`. | Use the `/` operator between `Path` objects and subdirectories (`BASE / "data"`). |
| Forgetting `exist_ok=True` | Calling `OUT.mkdir()` when `outputs/` already exists raises `FileExistsError`. | Always include `exist_ok=True` inside `mkdir()` for repeatable script runs. |

## Best Practices and Security Considerations

- **Never Use Hardcoded Absolute Paths:** Never hardcode paths like `/home/aziz/...` or `C:\Users\...` in production scripts. Anchor paths relative to `__file__`.
- **Backend Hygiene:** Always declare headless backends explicitly when generating automated visualization reports.
- **Path Sanitization:** When accepting file path inputs from external users, always use `.resolve()` and verify the target path remains within the permitted project root to avoid path traversal vulnerabilities.

## Summary

In Lesson 01, we examined professional environment setup and project structuring. Using `pathlib.Path(__file__).resolve().parent`, we create an absolute anchor for all project directories, allowing reliable relative references via the `/` operator. We also explored why setting the non-interactive `matplotlib.use("Agg")` backend ensures headless, crash-free execution in production environments and how `OUT.mkdir(exist_ok=True)` provides safe directory creation.

## Knowledge-check Questions

1. What is the advantage of using `pathlib.Path` over plain string path operations?
2. What does `Path(__file__).resolve().parent` evaluate to?
3. Why is `matplotlib.use("Agg")` called before `import matplotlib.pyplot as plt`?
4. What error occurs if `OUT.mkdir()` is called without `exist_ok=True` when the folder already exists?
5. Which operator does `pathlib` overload to join directory paths together cleanly?

## References

- [main.py lines 10-25](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price/main.py#L10-L25)
- [Python pathlib official documentation](https://docs.python.org/3/library/pathlib.html)
- [Matplotlib Backends User Guide](https://matplotlib.org/stable/users/explain/backends.html)
