# Module 2 Exercises: Data Loading & Exploratory Analysis

## Exercise 2.1: Pathlib and Headless Matplotlib Setup (15 min)
**Objective:** Construct a modular, platform-independent project skeleton with safe directory handling and non-interactive plotting.  
**Problem Statement:** You must set up a Python script that reliably discovers project directories regardless of where the script is executed from, sets up headless rendering for server environments, and guarantees that an `outputs/` folder is safely created.

**Requirements:**
1. Import `Path` from `pathlib` and configure `BASE = Path(__file__).resolve().parent`.
2. Construct path anchors `DATA = BASE / "data"` and `OUT = BASE / "outputs"`.
3. Call `OUT.mkdir(exist_ok=True)` and explain the purpose of `exist_ok=True`.
4. Configure matplotlib to use the non-interactive `"Agg"` backend prior to importing `pyplot`.
5. Write an assertion verifying that `DATA / "used_cars.csv"` exists on the filesystem.

**Constraints:** Write clean Python code without hardcoding any absolute filesystem strings.

**Expected Behaviour:** The script runs cleanly from any current working directory, creates `outputs/` if absent, and verifies dataset presence without errors.

**Acceptance Criteria:**
- [ ] Uses `Path(__file__).resolve().parent` correctly.
- [ ] Uses `/` operator for path composition.
- [ ] Employs `exist_ok=True` when making directory.
- [ ] Declares `matplotlib.use("Agg")` before importing `pyplot`.
- [ ] Confirms the file exists using `(DATA / "used_cars.csv").is_file()`.

**Hints:**
- Run the script from outside the project directory (e.g., from your home folder) to test portability.
- Remember that importing `pyplot` before setting `"Agg"` can lock in the default interactive backend.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 2.2: DataFrame Ingestion & Structural Inspection (15 min)
**Objective:** Ingest `used_cars.csv` with pandas and systematically verify tabular properties.  
**Problem Statement:** Before performing statistical analysis, an engineer must audit the structural integrity of the raw data.

**Requirements:**
1. Load `data/used_cars.csv` into a pandas DataFrame named `df`.
2. Print the exact shape of `df` and assert that it matches `(45, 3)`.
3. Print the first 5 rows using `.head()` and last 5 rows using `.tail()`.
4. Inspect data types using `.dtypes` and confirm that all 3 columns are 64-bit integers.
5. Compute and print the total number of missing or null entries across all cells.

**Constraints:** Use pandas methods exclusively.

**Expected Behaviour:** Terminal prints shape `(45, 3)`, column names, head and tail listings, and reports 0 missing values.

**Acceptance Criteria:**
- [ ] Dataset loaded via `pd.read_csv()`.
- [ ] Shape verified as `(45, 3)`.
- [ ] First and last 5 rows printed.
- [ ] Confirms `dtypes` are integer types.
- [ ] `df.isnull().sum()` verified to equal 0 across all columns.

**Hints:**
- Use `assert df.shape == (45, 3)` to build automated checks.
- `df.isnull().values.any()` is a quick boolean check for any missing values.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 2.3: Distribution Analysis and Outlier Detection (20 min)
**Objective:** Compute descriptive statistics and determine if anomalous values exist.  
**Problem Statement:** Perform a comprehensive distribution analysis on `age_years`, `kilometers`, and `price_usd` using summary statistics.

**Requirements:**
1. Generate the 8-statistic summary table for `df` using `df.describe()`.
2. Extract the mean, median (50%), minimum, and maximum for each column.
3. Compute the Interquartile Range ($IQR = Q_3 - Q_1$) for `price_usd`.
4. Compute the lower outlier threshold ($Q_1 - 1.5 \times IQR$) and upper outlier threshold ($Q_3 + 1.5 \times IQR$) for `price_usd`.
5. Check whether any vehicles fall outside these thresholds and interpret the result.

**Constraints:** Perform calculations using pandas and standard Python arithmetic.

**Expected Behaviour:** Code displays the full summary table, calculates IQR and outlier thresholds, and reports whether any outliers exist.

**Acceptance Criteria:**
- [ ] `df.describe()` output generated and displayed.
- [ ] Mean and median values reported accurately for all 3 columns.
- [ ] Price IQR calculated as approximately $8,665.
- [ ] Price outlier boundaries calculated (effective lower: $0, upper: ~$27,010).
- [ ] Concludes that all 45 observations fall safely within normal bounds.

**Hints:**
- $Q_1$ is `df["price_usd"].quantile(0.25)` and $Q_3$ is `df["price_usd"].quantile(0.75)`.
- Remember to compare `df["price_usd"].min()` and `df["price_usd"].max()` to the calculated thresholds.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 20 minutes  

---

## Exercise 2.4: Correlation Matrix Calculation and Interpretation (15 min)
**Objective:** Calculate Pearson correlation coefficients and explain feature independence.  
**Problem Statement:** You need to quantify the relationships between all variables in the dataset and evaluate whether the two features are suitable for multiple regression.

**Requirements:**
1. Compute the pairwise Pearson correlation matrix for `df` using `df.corr()`.
2. Identify the correlation between `age_years` and `price_usd`.
3. Identify the correlation between `kilometers` and `price_usd`.
4. Identify the correlation between `age_years` and `kilometers`.
5. Write a short technical memo explaining:
   - Why both features are strong individual negative predictors of price.
   - Why the near-zero correlation between age and kilometers is considered ideal for multiple regression.

**Constraints:** Base all numerical values on the actual output of `df.corr()`.

**Expected Behaviour:** Python prints the 3×3 matrix, and the student provides a written analysis of the findings.

**Acceptance Criteria:**
- [ ] Correlation matrix printed with values matching project metrics ($r \approx -0.749$, $r \approx -0.618$, $r \approx 0.0035$).
- [ ] Strong negative relationships with price are correctly interpreted as asset depreciation.
- [ ] Near-zero feature-to-feature correlation is correctly recognized as absence of multicollinearity.
- [ ] Written memo explains why independent features provide complementary predictive power.

**Hints:**
- High correlation between features causes multicollinearity, which inflates variance.
- Near-zero correlation means each feature brings fresh, non-overlapping information.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  
