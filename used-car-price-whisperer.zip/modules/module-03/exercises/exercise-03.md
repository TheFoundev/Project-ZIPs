# Module 3 Exercises: Multiple Linear Regression & Multicollinearity

## Exercise 3.1: Line vs. Plane Geometric Formulation (15 min)
**Objective:** Compare simple and multiple linear regression mathematically and geometrically.  
**Problem Statement:** You must present a visual and mathematical comparison demonstrating why simple linear regression fails to capture car pricing dynamics compared to multiple linear regression.

**Requirements:**
1. Write down the algebraic equation for simple linear regression predicting price from age alone ($y = \beta_0 + \beta_1 x_1$).
2. Write down the algebraic equation for multiple linear regression predicting price from age and kilometers ($y = \beta_0 + \beta_1 x_1 + \beta_2 x_2$).
3. Describe the geometric dimensionality of the feature space and the prediction surface for both models.
4. Contrast the empirical performance: explain why the test $R^2$ jumps from ~0.48 (simple regression on age) to ~0.93 (multiple regression on age and kilometers).

**Constraints:** Ground all mathematical formulas and performance figures in the project data.

**Expected Behaviour:** A written technical comparison clearly explaining the transition from a 2D line to a 3D regression plane and justifying the dramatic performance increase.

**Acceptance Criteria:**
- [ ] Both mathematical formulas correctly written.
- [ ] Simple regression described as 1D line in 2D space.
- [ ] Multiple regression described as 2D plane in 3D space.
- [ ] Clear explanation of why omitting kilometers caps explained variance at ~48%.
- [ ] Correctly notes that multiple regression combines both dimensions to reach ~93% explained variance.

**Hints:**
- Consider a car that is 5 years old with 10,000 km vs. 5 years old with 150,000 km. Can a 1D line on age distinguish them?

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 3.2: Equation Deconstruction & Manual Evaluation (15 min)
**Objective:** Deconstruct the learned regression equation and compute manual valuations.  
**Problem Statement:** A car dealership needs to audit the automated model equation:
$$\text{price} = 26,818 - 1,241.53 \times \text{age} - 0.092223 \times \text{km}$$

**Requirements:**
1. State the economic interpretation of the intercept ($26,818).
2. State the economic interpretation of the age weight (-$1,241.53/year).
3. State the economic interpretation of the mileage weight (-$0.092223/km), and calculate the depreciation per 10,000 km.
4. Manually calculate the estimated price for:
   - Car A: 2 years old, 30,000 km
   - Car B: 6 years old, 75,000 km
   - Car C: 10 years old, 120,000 km
5. Verify whether any of the calculated prices fall below zero.

**Constraints:** Perform arithmetic accurately to the nearest dollar.

**Expected Behaviour:** Documented step-by-step arithmetic showing each deduction and the final price for all three vehicles.

**Acceptance Criteria:**
- [ ] Intercept identified as the baseline new car price ($0 \text{ yrs}, 0 \text{ km}$).
- [ ] Age coefficient interpreted as annual loss of ~$1,242.
- [ ] Mileage coefficient scaled to ~$922 per 10,000 km.
- [ ] Car A price computed as ~$21,568.
- [ ] Car B price computed as ~$12,452.
- [ ] Car C price computed as ~$3,336.
- [ ] Confirms all three valuations remain positive.

**Hints:**
- For Car A: $26,818 - (1,241.53 \times 2) - (0.092223 \times 30,000) = 26,818 - 2,483.06 - 2,766.69 = \$21,568.25$.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 3.3: Slicing 2D Feature Matrices & Diagnosing Shape Errors (15 min)
**Objective:** Master pandas bracket syntax and debug scikit-learn dimensionality exceptions.  
**Problem Statement:** An apprentice developer wrote the following code snippet and encountered a crash:
```python
import pandas as pd
from sklearn.linear_model import LinearRegression

df = pd.read_csv("data/used_cars.csv")
X = df["age_years"]
y = df["price_usd"]
model = LinearRegression().fit(X, y)
```

**Requirements:**
1. Identify the exact error message raised by scikit-learn.
2. Explain the difference between `df["age_years"]` and `df[["age_years"]]` in terms of pandas types and array shapes.
3. Rewrite the code using double brackets to correctly create a 2D feature matrix containing both `age_years` and `kilometers`.
4. Add assertions to the script checking that `X.shape == (45, 2)` and `y.shape == (45,)`.
5. Execute the corrected script and verify that `.fit()` executes without error.

**Constraints:** Write clean Python code that imports required libraries and runs cleanly.

**Expected Behaviour:** The script corrects the indexing syntax, passes shape assertions, and fits the model without error.

**Acceptance Criteria:**
- [ ] Correctly identifies the `ValueError: Expected 2D array, got 1D array instead`.
- [ ] Explains single bracket (Series, 1D) vs. double bracket (DataFrame, 2D).
- [ ] Rewrites code to `X = df[["age_years", "kilometers"]]`.
- [ ] Includes assertions for `X.shape == (45, 2)` and `y.shape == (45,)`.
- [ ] Code runs successfully.

**Hints:**
- Scikit-learn estimators always require features to have shape `(n_samples, n_features)`.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 3.4: Multicollinearity Diagnosis and VIF Calculation (20 min)
**Objective:** Calculate correlation and Variance Inflation Factors to diagnose feature collinearity.  
**Problem Statement:** Prove mathematically and empirically that `age_years` and `kilometers` do not suffer from multicollinearity in `used_cars.csv`.

**Requirements:**
1. Compute the Pearson correlation $r$ between `age_years` and `kilometers` using pandas.
2. Compute the coefficient of determination $R^2 = r^2$ between the two features.
3. Compute the Variance Inflation Factor: $\text{VIF} = \frac{1}{1 - R^2}$.
4. Create a synthetic collinear column: `df["mileage_miles"] = df["kilometers"] * 0.621371`.
5. Fit a model on `["kilometers", "mileage_miles"]` and observe the distorted coefficients.
6. Write a concluding assessment explaining why low VIF (~1.000) ensures stable, trustworthy depreciation coefficients in our project.

**Constraints:** Use Python and pandas to perform all numerical calculations.

**Expected Behaviour:** Code outputs correlation (~0.00355), $R^2$ (~0.000013), VIF (~1.000013), demonstrates coefficient instability under synthetic collinearity, and summarizes findings.

**Acceptance Criteria:**
- [ ] Correlation between age and kilometers calculated as ~0.00355.
- [ ] VIF calculated as approximately 1.000.
- [ ] Synthetic collinear model demonstrates coefficient splitting or distortion.
- [ ] Clear written explanation of why feature independence protects coefficient stability.

**Hints:**
- High VIF (> 5 or 10) indicates severe multicollinearity. A VIF near 1.0 is ideal.

**Difficulty:** Advanced  
**Estimated Completion Time:** 20 minutes  
