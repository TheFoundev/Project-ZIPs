# Lesson 04: Multicollinearity Basics

**Lesson ID:** lesson-04  
**Module:** module-03  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Define multicollinearity in multiple regression and understand how it arises.
- Explain why high correlation between two input features distorts regression coefficients.
- Understand how multicollinearity inflates coefficient variance without necessarily reducing overall prediction accuracy.
- Calculate and interpret the empirical correlation between `age_years` and `kilometers` ($r \approx +0.0035$).
- Explain why our car pricing dataset possesses near-ideal feature independence.

## Prerequisites

Completion of [Lesson 01](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-03/lessons/lesson-01.md), [Lesson 02](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-03/lessons/lesson-02.md), and [Lesson 03](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-03/lessons/lesson-03.md). Basic understanding of linear correlation and systems of equations.

## Concept Explanation

### What is Multicollinearity?
In multiple linear regression, we assume each feature $x_j$ provides independent information that helps predict target $y$. **Multicollinearity** occurs when two or more input features are highly linearly correlated with each other. In other words, one feature can be linearly predicted from the other feature with high accuracy.

#### An Extreme Example: Perfect Collinearity
Imagine an analyst who includes both `kilometers` and `miles` in the feature matrix $X$:
$$\text{kilometers} = 1.60934 \times \text{miles}$$
Because miles and kilometers are exact mathematical transformations of each other, the correlation is $r = 1.0$.

When the ordinary least squares (OLS) algorithm attempts to solve the normal equation $(X^T X)^{-1} X^T y$, the matrix $(X^T X)$ becomes singular (non-invertible). The algorithm cannot determine whether the depreciation should be attributed to the `kilometers` column, the `miles` column, or an infinite combination of both! One coefficient might end up as $+10,000$ and the other as $-16,093$, producing wild mathematical instability.

### High Multicollinearity in Practice
Even when correlation is not an exact 1.0 (e.g., $r = 0.92$), high collinearity creates severe problems:
1. **Unstable Coefficients:** Small changes in the training data cause drastic swings in the magnitude and even the positive/negative signs of the learned coefficients.
2. **Loss of Interpretability:** In multiple regression, a coefficient is supposed to represent the marginal change in $y$ while *holding all other features constant*. But if Feature A and Feature B always move in lockstep, it is physically impossible to hold one constant while changing the other!
3. **Inflated Standard Errors:** The confidence intervals for the coefficients become very wide, making it difficult to determine whether a feature is statistically significant.

### The Variance Inflation Factor (VIF)
Statisticians quantify multicollinearity using the **Variance Inflation Factor (VIF)** for each feature:
$$\text{VIF}_j = \frac{1}{1 - R_j^2}$$
where $R_j^2$ is the $R^2$ obtained by regressing feature $x_j$ against all other remaining features.
- $\text{VIF} = 1$: Complete independence (zero collinearity).
- $1 < \text{VIF} < 5$: Moderate, acceptable collinearity.
- $\text{VIF} > 5$ or $10$: Severe multicollinearity; corrective action is necessary.

### Evaluating Multicollinearity in Our Dataset
Let us check our car price dataset:
```python
df[["age_years", "kilometers"]].corr()
```
The correlation between `age_years` and `kilometers` is:
$$r = 0.003550$$
Let us compute the $R^2$ between them:
$$R^2 = r^2 = (0.003550)^2 = 0.0000126$$
Now let us compute the VIF:
$$\text{VIF} = \frac{1}{1 - 0.0000126} = \frac{1}{0.9999874} \approx 1.000013$$

A VIF of **1.000013** is essentially a textbook-perfect score of 1.0! 

There is virtually **zero multicollinearity** in `used_cars.csv`. Vehicle age and odometer mileage operate as two orthogonal, independent information channels. This guarantees:
- The age coefficient (-$1,241.53/year) is stable and reliable.
- The mileage coefficient (-$0.0922/km) is stable and reliable.
- Each weight directly and cleanly reflects the true isolated depreciation rate of that feature.

## Relevant Code (from main.py, lines 28-30)

```python
def main() -> None:
    df = pd.read_csv(DATA / "used_cars.csv")
    X = df[["age_years", "kilometers"]]
    y = df["price_usd"]
```

### Code explanation
- Slicing `X = df[["age_years", "kilometers"]]` yields two independent predictors with near-zero collinearity, ensuring well-conditioned matrix inversion in scikit-learn's underlying solver.

## Worked Example

**Problem:**  
Suppose a student adds a redundant column `age_months = df["age_years"] * 12` to `used_cars.csv` and trains a multiple linear regression model with three features: `age_years`, `age_months`, and `kilometers`. What happens to the coefficients?

**Experimental Code & Results:**
```python
import pandas as pd
from sklearn.linear_model import LinearRegression

df = pd.read_csv("data/used_cars.csv")
df["age_months"] = df["age_years"] * 12

X_redundant = df[["age_years", "age_months", "kilometers"]]
y = df["price_usd"]

model = LinearRegression().fit(X_redundant, y)
print("Coefficients:", model.coef_)
```

**Output:**
```text
Coefficients: [ -85.76022831  -96.31394598   -0.09222253]
```

**Analysis:**  
Notice what happened:
- In the original model, `age_years` had a clean weight of **-$1,241.53**.
- In the redundant model, the age depreciation was arbitrarily split between `age_years` (-$85.76) and `age_months` (-$96.31).
- Notice that: $-85.76 + (12 \times -96.31) = -85.76 - 1,155.77 = -\$1,241.53$!
The total depreciation remains the same, but the individual coefficients have become scrambled and uninterpretable because `age_years` and `age_months` are perfectly collinear ($r = 1.0$).

This proves why eliminating redundant features and maintaining feature independence is essential for clear model interpretation.

## Step-by-Step Student Instructions

1. **Calculate the Correlation:** In Python, run:
   ```python
   import pandas as pd
   df = pd.read_csv("data/used_cars.csv")
   print(df["age_years"].corr(df["kilometers"]))
   ```
   Observe that the correlation is approximately `0.00355`.
2. **Compute VIF:** Confirm that $R^2 = (0.00355)^2 \approx 0$, meaning $\text{VIF} \approx 1.0$.
3. **Contrast with Domain Assumptions:** In real life, older cars often have higher mileage. Why might our dataset have low correlation? Because used car dealers source many different types of cars: some were commercial fleet cars (high mileage, young age), while others were elderly owners' weekend cars (low mileage, high age).
4. **Appreciate the Clean Signal:** Recognize that this diversity in vehicle usage patterns is precisely what allows our model to decouple age depreciation from mileage depreciation!

## Expected Output or Observable Behaviour

Executing correlation and VIF checks demonstrates that `age_years` and `kilometers` have near-zero collinearity, ensuring that the model's coefficients represent pure, unpolluted marginal effects.

## Practical Exercises

- **Exercise 4.1:** What is the Variance Inflation Factor (VIF), and what does a VIF value of 1.0 signify?
- **Exercise 4.2:** If two features in a dataset have a correlation of $r = 0.99$, what is their approximate VIF? Would you recommend keeping both in a linear regression model?
- **Exercise 4.3:** How does near-zero correlation between features help an automotive appraiser explain a car's price to a customer?

## Common Mistakes and Debugging

| Mistake | Why it happens | How to avoid or fix |
|---|---|---|
| Confusing feature-target correlation with feature-feature correlation | Thinking features must have low correlation with the target. | Features should have **high** correlation with the target ($y$), but **low** correlation with each other ($X_j, X_k$). |
| Ignoring multicollinearity because $R^2$ is high | Believing high $R^2$ means all features are well-behaved. | Severe multicollinearity can exist alongside high $R^2$; always inspect correlation matrices or VIF scores. |
| Dropping independent features unnecessarily | Assuming low correlation between features means one of them is useless. | Low inter-feature correlation is ideal; each feature provides unique, non-overlapping information. |

## Best Practices and Security Considerations

- **Pre-Model Screening:** Always compute the correlation matrix of feature matrix $X$ before training linear models.
- **VIF Thresholds:** Apply standard statistical thresholds ($\text{VIF} < 5$) to detect and eliminate redundant collinear features.
- **Dimensionality Reduction:** If high multicollinearity exists (e.g., dozens of highly correlated sensor signals), consider regularization (Ridge/Lasso) or Principal Component Analysis (PCA).

## Summary

In Lesson 04, we examined multicollinearity—the phenomenon where input features are highly correlated with each other. Multicollinearity inflates coefficient variance, scrambles weights, and impairs interpretability. By computing the correlation between `age_years` and `kilometers` ($r \approx +0.0035$, $\text{VIF} \approx 1.000$), we demonstrated that our dataset features near-perfect orthogonality, allowing clean, stable, and independent estimation of age and mileage depreciation.

## Knowledge-check Questions

1. What is multicollinearity in a multiple linear regression model?
2. What problems does multicollinearity cause for regression coefficients?
3. What is the Pearson correlation between `age_years` and `kilometers` in `used_cars.csv`?
4. What is the approximate Variance Inflation Factor (VIF) for the features in our dataset?
5. Why is it desirable for features to have high correlation with the target, but low correlation with each other?

## References

- [main.py lines 28-30](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price/main.py#L28-L30)
- [Variance Inflation Factor (Wikipedia)](https://en.wikipedia.org/wiki/Variance_inflation_factor)
- [Multicollinearity in Regression Analysis (Statistics By Jim)](https://statisticsbyjim.com/regression/multicollinearity-in-regression-analysis/)
