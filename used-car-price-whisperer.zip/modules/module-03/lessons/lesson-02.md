# Lesson 02: The Multiple Regression Equation

**Lesson ID:** lesson-02  
**Module:** module-03  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Deconstruct every component of the multiple regression equation: $\text{price} = \beta_0 + (\beta_1 \times \text{age}) + (\beta_2 \times \text{km})$.
- Define the intercept ($\beta_0$) and explain its physical and economic interpretation.
- Define partial regression weights ($\beta_1, \beta_2$) and explain why they are termed "marginal effects."
- Interpret units of measurement for coefficients (dollars per year and dollars per kilometer).
- Compute manual price predictions by plugging arbitrary vehicle specifications into the equation.

## Prerequisites

Completion of [Lesson 01](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-03/lessons/lesson-01.md). Basic understanding of linear equations and algebraic substitution.

## Concept Explanation

### The Learned Equation
In "The Used Car Price Whisperer", fitting the `LinearRegression` model discovers three fundamental parameters:
1. Intercept ($\beta_0 \approx 26,817.96$, or ~$26,818)
2. Age weight ($\beta_1 \approx -1,241.53$, or ~-$1,242)
3. Mileage weight ($\beta_2 \approx -0.092223$, or ~-$0.09)

Substituting these values into the multiple linear regression formula gives:
$$\text{price\_usd} = 26,818 + (-1,242 \times \text{age\_years}) + (-0.0922 \times \text{kilometers})$$

Let us analyze each term in detail.

### 1. The Intercept ($\beta_0 = \$26,818$)
In coordinate geometry, the intercept is the point where the regression plane penetrates the vertical $Y$-axis. Mathematically, it represents the predicted price when all input features equal zero:
$$\text{age\_years} = 0 \quad \text{and} \quad \text{kilometers} = 0$$

**Economic Interpretation:**
What is a car with 0 years of age and 0 kilometers driven? It is a **brand-new vehicle sitting on the dealer's showroom floor**!
The model has discovered, purely from used car sales data, that the baseline price of an unused vehicle of this type is approximately **$26,818**.

Notice how intuitive this is: used car prices start at an initial new-car baseline, and then each year and each kilometer driven chips away at that starting value!

### 2. The Age Coefficient ($\beta_1 = -\$1,242 \text{ per year}$)
The coefficient $\beta_1$ represents the **marginal effect** of vehicle age on price, *holding kilometers constant*.
- For every additional year a car ages, its expected market value decreases by approximately **$1,242**.
- If two cars have identical odometer readings (e.g., both have 50,000 km), but Car A was manufactured in 2020 (4 years old) and Car B was manufactured in 2018 (6 years old), Car B will be priced approximately $2 \times \$1,242 = \$2,484$ lower than Car A.

### 3. The Mileage Coefficient ($\beta_2 = -\$0.0922 \text{ per kilometer}$)
The coefficient $\beta_2$ represents the marginal effect of cumulative distance driven, *holding age constant*.
- For every additional kilometer driven, the car's expected value decreases by approximately **$0.0922** (about 9.2 cents).
- Because a single kilometer is a tiny unit of distance for a car, we often scale this coefficient to more human-meaningful increments:
  $$\text{Depreciation per 10,000 km} = 10,000 \times \$0.092223 \approx \$922$$
- For every 10,000 km recorded on the dashboard odometer, the car's market value declines by approximately **$922**.

## Relevant Code (from main.py, lines 42-53)

```python
    age_weight, km_weight = model.coef_
    intercept = model.intercept_

    example = pd.DataFrame([{"age_years": 5, "kilometers": 60_000}])
    example_price = float(model.predict(example)[0])

    print("=" * 60)
    print("THE USED CAR PRICE WHISPERER")
    print("=" * 60)
    print(f"Equation: price = {intercept:,.0f} + ({age_weight:,.0f} x age) + ({km_weight:.2f} x km)")
    print(f"Each extra year is associated with about ${abs(age_weight):,.0f} less value.")
    print(f"Each extra 10,000 km is associated with about ${abs(km_weight) * 10_000:,.0f} less value.")
```

### Code explanation
- `age_weight, km_weight = model.coef_`: The `model.coef_` attribute is a 1D NumPy array containing two floats. We unpack them directly into two descriptive variable names.
- `model.intercept_`: Returns the scalar floating-point value of the baseline intercept.
- `abs(age_weight)` and `abs(km_weight) * 10_000`: We use `abs()` to convert the negative weights into readable positive dollar amounts when printing sentences like "associated with $1,242 less value."

## Worked Example

**Problem:**  
A used car buyer is comparing two vehicles on a dealer lot:
- Car X: 3 years old, 45,000 km
- Car Y: 7 years old, 20,000 km

Using the project equation ($\text{price} = 26,818 - 1,241.53 \times \text{age} - 0.092223 \times \text{km}$), calculate the estimated market price for both cars and determine which car is expected to be more expensive.

**Calculation for Car X:**
1. Age deduction: $3 \times \$1,241.53 = \$3,724.59$
2. Mileage deduction: $45,000 \times \$0.092223 = \$4,150.04$
3. Net price:
   $$\text{Price}_X = 26,817.96 - 3,724.59 - 4,150.04 = \$18,943.33 \approx \$18,943$$

**Calculation for Car Y:**
1. Age deduction: $7 \times \$1,241.53 = \$8,690.71$
2. Mileage deduction: $20,000 \times \$0.092223 = \$1,844.46$
3. Net price:
   $$\text{Price}_Y = 26,817.96 - 8,690.71 - 1,844.46 = \$16,282.79 \approx \$16,283$$

**Comparison:**  
Car X ($18,943) is valued at **$2,660 more** than Car Y ($16,283). Even though Car Y has driven 25,000 fewer kilometers, its 4 additional years of age result in $4,966 of additional age depreciation, which outweighs its mileage advantage.

## Step-by-Step Student Instructions

1. **Memorize the Structure:** Write the general template: $\text{Target} = \text{Intercept} + (\text{Weight}_1 \times \text{Feature}_1) + (\text{Weight}_2 \times \text{Feature}_2)$.
2. **Review Formatting Strings:** Look at line 51 of `main.py`: `f"Equation: price = {intercept:,.0f} + ({age_weight:,.0f} x age) + ({km_weight:.2f} x km)"`. Notice how `{age_weight:,.0f}` rounds to the nearest dollar with commas, while `{km_weight:.2f}` preserves two decimals.
3. **Practice Mental Math:** If a car is 10 years old with 100,000 km:
   - Baseline: ~$26,800
   - Age loss: ~$12,400
   - Mileage loss: ~$9,200
   - Expected price: $26,800 - $12,400 - $9,200 = ~$5,200.
4. **Inspect Coefficients in Python:** In your Python shell, inspect `model.coef_` and verify that it contains exactly two negative numbers.

## Expected Output or Observable Behaviour

Executing lines 48-53 of `main.py` prints:
```text
============================================================
THE USED CAR PRICE WHISPERER
============================================================
Equation: price = 26,818 + (-1,242 x age) + (-0.09 x km)
Each extra year is associated with about $1,242 less value.
Each extra 10,000 km is associated with about $922 less value.
```

## Practical Exercises

- **Exercise 2.1:** What is the predicted price of a car with age = 0 and kilometers = 100,000? How does this compare to the baseline intercept?
- **Exercise 2.2:** Why is `km_weight` printed as `-0.09` with two decimal places in the equation line, but multiplied by 10,000 in the explanation line? Why is that better for human readers?
- **Exercise 2.3:** At what age would a car with 0 km reach an estimated price of $0 according to this linear equation? Is this an example of linear extrapolation?

## Common Mistakes and Debugging

| Mistake | Why it happens | How to avoid or fix |
|---|---|---|
| Adding negative weights instead of subtracting | Forgetting that the weights already contain a negative sign: $+ (-1,242 \times \text{age})$. | Recognize that adding a negative number is equivalent to subtraction: $26,818 - 1,242 \times \text{age}$. |
| Misinterpreting coefficient scale | Thinking -$0.09 is tiny and therefore mileage does not matter. | Remember that mileage is measured in tens of thousands of kilometers; 100,000 km results in a massive $9,222 deduction! |
| Unpacking `model.coef_` incorrectly | Writing `w1, w2, w3 = model.coef_` when there are only 2 features. | Match the number of unpacked variables to the number of columns in $X$ (exactly 2). |

## Best Practices and Security Considerations

- **Unit Documentation:** Always document the exact units of every coefficient in comments and docstrings.
- **Human-Readable Explanations:** Present tiny coefficients (like per-kilometer rates) in intuitive, grouped units (like per 10,000 km) for executive summaries.
- **Boundary Verification:** In automated pricing engines, apply a floor (e.g., minimum salvage value of $500) so that high-age/high-mileage cars never receive negative price quotes.

## Summary

In Lesson 02, we deconstructed the multiple linear regression equation: $\text{price} = 26,818 + (-1,242 \times \text{age}) + (-0.0922 \times \text{km})$. We discovered that the intercept ($26,818) represents the baseline price of a brand-new vehicle ($0 \text{ yrs}, 0 \text{ km}$), while the coefficients represent marginal depreciation rates: approximately -$1,242 per year of age and -$922 per 10,000 km driven.

## Knowledge-check Questions

1. What is the numerical value and physical meaning of the intercept in this model?
2. How much value does a car lose for each additional year of chronological age, according to the model?
3. How much value does a car lose for each additional 10,000 kilometers driven?
4. How many elements are contained in `model.coef_` when training on `used_cars.csv`?
5. Why is it necessary to take the absolute value `abs(km_weight)` when formatting descriptive text such as "associated with $922 less value"?

## References

- [main.py lines 42-53](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price/main.py#L42-L53)
- [Scikit-learn LinearRegression Attributes](https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html)
- [Interpreting Regression Coefficients (Penn State STAT 501)](https://online.stat.psu.edu/stat501/lesson/5)
