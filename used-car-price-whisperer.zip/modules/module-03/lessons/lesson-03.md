# Lesson 03: Slicing Features X and Target y in 2D

**Lesson ID:** lesson-03  
**Module:** module-03  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain why scikit-learn requires feature matrix $X$ to have a 2-dimensional shape `(n_samples, n_features)`.
- Explain why the target vector $y$ has a 1-dimensional shape `(n_samples,)`.
- Distinguish between pandas single bracket syntax (`df["col"]`) and double bracket syntax (`df[["col1", "col2"]]`).
- Diagnose and resolve common dimensionality mismatch exceptions in scikit-learn (`ValueError: Expected 2D array, got 1D array instead`).
- Verify data shapes before passing arrays into `train_test_split()`.

## Prerequisites

Completion of [Lesson 01](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-03/lessons/lesson-01.md) and [Lesson 02](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-03/lessons/lesson-02.md). Basic understanding of Python lists and indexing.

## Concept Explanation

### The Scikit-Learn API Contract
Every estimator in scikit-learn adheres to a strict, universal design pattern (the Estimator API). Two foundational assumptions govern data input shapes:

1. **The Feature Matrix ($X$):** Must ALWAYS be a **2-dimensional** structure with shape `(n_samples, n_features)`.
   - The first dimension ($N$) represents the number of individual observations (e.g., 45 cars).
   - The second dimension ($P$) represents the number of measurable features per observation (e.g., 2 features: age and kilometers).
   - Even if you only have 1 single feature (as in simple regression), scikit-learn requires shape `(N, 1)`, NEVER a flat 1D array `(N,)`!
   
2. **The Target Vector ($y$):** For single-output regression and classification, $y$ is expected to be a **1-dimensional** vector of shape `(n_samples,)`.

### Pandas Bracket Notation: Single vs. Double
In pandas, how you slice columns dictates whether you receive a 1D Series or a 2D DataFrame:

```
df["column_name"]            ──► Returns 1D pandas Series        ──► Shape: (45,)
df[["col1", "col2"]]         ──► Returns 2D pandas DataFrame     ──► Shape: (45, 2)
df[["single_column"]]        ──► Returns 2D pandas DataFrame     ──► Shape: (45, 1)
```

In `main.py`, lines 29-30 execute this separation:
```python
X = df[["age_years", "kilometers"]]
y = df["price_usd"]
```

Let's examine the mechanics:
- `df[["age_years", "kilometers"]]`: We pass a Python list of strings `["age_years", "kilometers"]` inside the DataFrame indexer brackets `df[...]`. This tells pandas: "Extract these multiple columns and maintain a 2D table structure." The resulting `X` has shape `(45, 2)`.
- `df["price_usd"]`: We pass a single string `"price_usd"` inside single brackets. This tells pandas: "Extract this column as a 1D vector." The resulting `y` has shape `(45,)`.

### What Happens if You Violate the 2D Contract?
If a developer accidentally attempts to train a model using a 1D structure for $X$:
```python
# MISTAKE: Single brackets produces 1D Series
X_bad = df["age_years"]
model.fit(X_bad, y)
```
Scikit-learn immediately halts execution with an explicit error:
```text
ValueError: Expected 2D array, got 1D array instead:
array=[ 5  4  9 10  6 ...].
Reshape your data either using array.reshape(-1, 1) if your data has a single feature 
or array.reshape(1, -1) if it contains a single sample.
```

In our multiple regression project, since we have two features (`age_years` and `kilometers`), passing both column names inside a list `[["age_years", "kilometers"]]` automatically creates a 2D DataFrame of shape `(45, 2)`, perfectly satisfying scikit-learn's contract without requiring manual `.reshape()` calls!

## Relevant Code (from main.py, lines 28-34)

```python
def main() -> None:
    df = pd.read_csv(DATA / "used_cars.csv")
    X = df[["age_years", "kilometers"]]
    y = df["price_usd"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42
    )
```

### Code explanation
- Line 29 creates the 2D feature matrix `X` of shape `(45, 2)`.
- Line 30 creates the 1D target vector `y` of shape `(45,)`.
- Lines 32-34 pass both `X` and `y` into `train_test_split()`, which partitions rows while preserving the column dimensionality of `X`.

## Worked Example

**Problem:**  
Demonstrate in a short Python script how pandas types and shapes change between single bracket and double bracket indexing on `used_cars.csv`.

**Verification Script:**
```python
import pandas as pd

df = pd.read_csv("data/used_cars.csv")

# 1D single bracket
s_single = df["age_years"]
print("Single bracket type :", type(s_single))
print("Single bracket shape:", s_single.shape)
print("Single bracket ndim :", s_single.ndim)

print("-" * 40)

# 2D double bracket
df_double = df[["age_years", "kilometers"]]
print("Double bracket type :", type(df_double))
print("Double bracket shape:", df_double.shape)
print("Double bracket ndim :", df_double.ndim)
```

**Output:**
```text
Single bracket type : <class 'pandas.core.series.Series'>
Single bracket shape: (45,)
Single bracket ndim : 1
----------------------------------------
Double bracket type : <class 'pandas.core.frame.DataFrame'>
Double bracket shape: (45, 2)
Double bracket ndim : 2
```

Notice:
- `ndim` is 1 for single bracket, and 2 for double bracket.
- Scikit-learn requires `X.ndim == 2`. Passing `df[["age_years", "kilometers"]]` guarantees `X.ndim == 2`.

## Step-by-Step Student Instructions

1. **Launch Python Shell:** Open terminal and run `python3`.
2. **Load the Data:**
   ```python
   import pandas as pd
   df = pd.read_csv("data/used_cars.csv")
   ```
3. **Slice Feature Matrix:**
   ```python
   X = df[["age_years", "kilometers"]]
   print(X.shape)
   ```
   Confirm output is `(45, 2)`.
4. **Slice Target Vector:**
   ```python
   y = df["price_usd"]
   print(y.shape)
   ```
   Confirm output is `(45,)`.
5. **Inspect Column Headers of X:**
   ```python
   print(X.columns.tolist())
   ```
   Confirm output is `['age_years', 'kilometers']`.

## Expected Output or Observable Behaviour

The feature matrix `X` displays as a clean two-column table with 45 rows, and `y` displays as a vertical 45-element series of price integers.

## Practical Exercises

- **Exercise 3.1:** What is the shape of `df[["age_years"]]` versus `df["age_years"]`? Which one can be passed directly to `LinearRegression().fit()`?
- **Exercise 3.2:** If you wanted to slice three features (`age_years`, `kilometers`, `engine_size`), write the exact pandas syntax you would use.
- **Exercise 3.3:** Why doesn't scikit-learn require `y` to be 2D `(45, 1)` for standard linear regression?

## Common Mistakes and Debugging

| Mistake | Why it happens | How to avoid or fix |
|---|---|---|
| Using single brackets for multiple columns: `df["age_years", "kilometers"]` | Forgetting that multiple column names must be wrapped in an inner list `[...]`. | Always use double brackets `df[["age_years", "kilometers"]]`. |
| Slicing `y` as a 2D DataFrame: `y = df[["price_usd"]]` | Using double brackets for the target. | While some models accept `(N, 1)` targets, many sklearn utilities issue a `DataConversionWarning` ("column-vector y was passed"). Use single brackets `df["price_usd"]`. |
| Mixing up row order between $X$ and $y$ | Sorting or filtering $X$ without applying the identical operation to $y$. | Slice $X$ and $y$ from the same DataFrame simultaneously to keep row indices perfectly synchronized. |

## Best Practices and Security Considerations

- **Strict Dimensionality Checks:** Include `assert X.ndim == 2` and `assert y.ndim == 1` in production preprocessing pipelines.
- **Synchronized Splitting:** Always pass $X$ and $y$ together into `train_test_split()` so that the random shuffle preserves row-to-row alignment.
- **Feature Column Immutability:** Do not modify the original raw DataFrame in place during feature slicing; create fresh, explicit variables for $X$ and $y$.

## Summary

In Lesson 03, we explored scikit-learn's architectural requirements for input shapes. Feature matrix $X$ must always be a 2D structure `(n_samples, n_features)`, which we generate in pandas using double bracket syntax `df[["age_years", "kilometers"]]` to yield shape `(45, 2)`. The target vector $y$ is a 1D vector `(n_samples,)`, created via single bracket syntax `df["price_usd"]` yielding shape `(45,)`. This ensures full compatibility with scikit-learn estimators.

## Knowledge-check Questions

1. What shape does scikit-learn require for the feature matrix $X$?
2. What shape does scikit-learn expect for the single target vector $y$?
3. What is the difference between `df["age_years"]` and `df[["age_years"]]` in pandas?
4. What error does scikit-learn raise if you pass a 1D Series as the feature matrix to `.fit()`?
5. What are the dimensions of `X` and `y` when extracted from `used_cars.csv`?

## References

- [main.py lines 28-34](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price/main.py#L28-L34)
- [Scikit-learn API Design and Conventions](https://scikit-learn.org/stable/developers/develop.html)
- [Pandas Indexing and Selecting Data](https://pandas.pydata.org/docs/user_guide/indexing.html)
