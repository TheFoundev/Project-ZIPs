# Lesson 01: From Simple to Multiple Linear Regression

**Lesson ID:** lesson-01  
**Module:** module-03  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Compare the mathematical formulation of simple linear regression with multiple linear regression.
- Understand the transition from a 1D line in a 2D coordinate system to a 2D flat plane in a 3D coordinate system.
- Explain why real-world physical and economic processes naturally require multiple independent features.
- Define the concept of a "hyperplane" for arbitrary $n$-dimensional feature spaces.
- Analyze how adding independent features improves the model's ability to explain target variance.

## Prerequisites

Completion of [Module 01](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-01/module.json) and [Module 02](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-02/module.json). Basic understanding of coordinate systems (X-axis, Y-axis, Z-axis).

## Concept Explanation

### The Limit of Simple Linear Regression
In simple linear regression, we attempt to predict a continuous dependent target $y$ from a single independent feature $x$. The familiar slope-intercept equation from high school algebra is:
$$y = mx + b \quad \text{or} \quad y = \beta_0 + \beta_1 x$$
Here, the model fits a straight 1-dimensional line across a 2-dimensional scatter plot (where the horizontal axis is $x$ and the vertical axis is $y$).

While simple linear regression works well for straightforward problems (such as predicting lemonade sales solely from outside temperature), it quickly reaches a ceiling when applied to complex assets like automobiles. In the used car market:
- If we regress price solely on vehicle age, our model achieves an $R^2$ of only **0.48**. Over 50% of price variation remains completely unexplained because the model is blind to whether a 5-year-old car was driven 10,000 km or 200,000 km!
- If we regress price solely on kilometers, the model cannot distinguish between a 1-year-old high-mileage highway car and a 10-year-old neglected city car.

To capture reality, we must expand our mathematical model to accept multiple input features.

### Extending to Multiple Features
**Multiple linear regression** allows a model to consider two or more features simultaneously. For two features ($x_1$ and $x_2$), the formula expands to:
$$y = \beta_0 + \beta_1 x_1 + \beta_2 x_2$$

Where:
- $y$ is the predicted target (`price_usd`).
- $\beta_0$ is the intercept (the expected value when both $x_1 = 0$ and $x_2 = 0$).
- $\beta_1$ is the partial regression coefficient for the first feature ($x_1$, `age_years`).
- $\beta_2$ is the partial regression coefficient for the second feature ($x_2$, `kilometers`).

If we were to add $p$ features, the equation generalizes naturally to:
$$y = \beta_0 + \beta_1 x_1 + \beta_2 x_2 + \cdots + \beta_p x_p = \beta_0 + \sum_{j=1}^{p} \beta_j x_j$$

### Geometric Intuition: Line vs. Plane vs. Hyperplane
The geometric interpretation changes dramatically as we add feature dimensions:

```
[1 Feature: 2D Space]         [2 Features: 3D Space]             [3+ Features: N-D Space]
  Price (y)                     Price (y)                         Target (y)
     ▲                             ▲                                 ▲
     │    / Regression             │    /───/ Regression             │    Hyperplane
     │   /  Line                   │   /───/  Flat Plane             │    (Cannot visualize
     │  /                          │  /───/                          │     directly in 3D)
     └────────► Feature (x)        └───────► Km (x2)                 └────────► Features (X)
                                    \
                                     ▼ Age (x1)
```

1. **One Feature (Simple Regression):** The data points exist in a 2D space $(x, y)$. The regression model is a **1-dimensional line**.
2. **Two Features (Our Project):** The data points exist in a 3D coordinate space $(x_1, x_2, y)$, where the floor is spanned by `age_years` and `kilometers`, and the height is `price_usd`. The regression model is a **2-dimensional flat plane** suspended in 3D space! Every prediction corresponds to a point on that plane.
3. **Three or More Features:** When $p \ge 3$, the space has 4 or more dimensions. We call the linear prediction surface a **hyperplane**. Although humans cannot visualize higher than three dimensions, the linear algebra calculations remain identical!

## Relevant Code (from main.py, lines 29-37)

```python
    df = pd.read_csv(DATA / "used_cars.csv")
    X = df[["age_years", "kilometers"]]
    y = df["price_usd"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42
    )

    model = LinearRegression()
    model.fit(X_train, y_train)
```

### Code explanation
- `df[["age_years", "kilometers"]]`: Supplies two feature columns to `X`. Scikit-learn's `LinearRegression` class detects that $p=2$, automatically switching from fitting a 2D line to fitting a 3D regression plane.
- `model.fit(X_train, y_train)`: Computes the 3D plane that minimizes the sum of squared vertical distances (residuals) from the training data points to the plane.

## Worked Example

**Problem:**  
A student fits three separate regression models on the used car training set:
- Model A: predicts price from `age_years` only ($y = \beta_0 + \beta_1 x_1$)
- Model B: predicts price from `kilometers` only ($y = \beta_0 + \beta_2 x_2$)
- Model C: predicts price from both `age_years` and `kilometers` ($y = \beta_0 + \beta_1 x_1 + \beta_2 x_2$)

Compare their test set performance and explain why Model C dramatically outperforms Models A and B.

**Performance Summary Table:**

| Model | Features Used | Geometric Shape | Test MAE ($) | Test $R^2$ Score |
|---|---|---|---|---|
| **Model A** | `age_years` only | 1D Line in 2D | $2,704 | 0.485 |
| **Model B** | `kilometers` only | 1D Line in 2D | $4,558 | -0.460 |
| **Model C (Multiple)** | `age_years` + `kilometers` | 2D Plane in 3D | **$906** | **0.928** |

**Explanation:**  
- Model A only knows how old the car is. If a 4-year-old car has 130,000 km, Model A overpredicts its price by thousands of dollars.
- Model B only knows mileage. If an 8,400 km car is 8 years old, Model B overpredicts its price because it does not know the car is an aging model.
- Model C fits a tilted 2D plane that accounts for both dimensions simultaneously. As a result, its test error drops from $2,704 down to just **$906**, and its explained variance jumps to **92.8%**!

## Step-by-Step Student Instructions

1. **Understand Dimensionality:** In your notebook, sketch a 3D coordinate system with three axes labeled $X_1$ (`age_years`), $X_2$ (`kilometers`), and $Y$ (`price_usd`).
2. **Visualize the Prediction Surface:** Sketch a tilted flat surface (like a rigid sheet of paper) suspended above the $X_1-X_2$ ground plane. This represents our multiple linear regression model.
3. **Trace Residuals:** Imagine data points floating near the plane. The vertical distance between each data point and the plane represents the model's prediction error (residual).
4. **Contrast with Curves:** Notice that the plane is completely flat in both directions; it does not bend, twist, or curve. This is what makes the model *linear*.

## Expected Output or Observable Behaviour

When multiple features are supplied to `LinearRegression`, the model learns multiple coefficients simultaneously. Calling `model.coef_` will return a NumPy array containing exactly two weights (`[age_weight, km_weight]`), corresponding to the two tilt angles of the regression plane.

## Practical Exercises

- **Exercise 1.1:** If you had a dataset with 5 features, what would be the dimensionality of the feature-target space, and what term describes the resulting prediction surface?
- **Exercise 1.2:** Explain why Model C's MAE ($906) is less than half of Model A's MAE ($2,704). Where did the extra accuracy come from?
- **Exercise 1.3:** Can a multiple linear regression plane bend to capture a U-shaped relationship without adding polynomial feature terms? Explain why or why not.

## Common Mistakes and Debugging

| Mistake | Why it happens | How to avoid or fix |
|---|---|---|
| Thinking multiple regression means training two separate models | Assuming we train one model for age and a separate model for mileage. | Multiple regression trains **one single unified model** that ingests both features simultaneously. |
| Confusing lines with planes | Calling the multiple regression prediction surface a "line". | In 2-feature regression, the prediction surface is a **plane**; in 3+ features, it is a **hyperplane**. |
| Assuming adding features always improves test performance | Believing more features is always better. | Adding redundant or noisy features causes overfitting; only informative, non-redundant features improve test performance. |

## Best Practices and Security Considerations

- **Feature Economy:** Include features that have justifiable domain relevance. In car pricing, age and mileage are economically proven drivers of value.
- **Dimensionality Awareness:** Avoid adding hundreds of features to small datasets (e.g., 45 samples) to prevent the "curse of dimensionality."
- **Baseline Comparison:** Always compare a multiple regression model's test performance against simpler single-feature baselines to ensure the extra complexity is warranted.

## Summary

In Lesson 01, we transitioned from simple linear regression (which maps 1 feature to 1 target via a 1D line) to multiple linear regression (which maps 2 features to 1 target via a 2D plane in 3D space). Using our empirical car pricing data, we demonstrated that combining age and kilometers into a single multiple regression model reduces test MAE from $2,704 to $906 and increases $R^2$ from 0.48 to 0.93.

## Knowledge-check Questions

1. How many features does simple linear regression use compared to multiple linear regression?
2. What geometric object represents the prediction surface when two features are used in linear regression?
3. What is the mathematical term for the linear prediction surface when 3 or more features are used?
4. How did the test $R^2$ score change when moving from age alone (~0.48) to age plus kilometers (~0.93)?
5. Does multiple linear regression train multiple separate models or one unified model?

## References

- [main.py lines 29-37](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price/main.py#L29-L37)
- [Scikit-learn Linear Models Documentation](https://scikit-learn.org/stable/modules/linear_model.html)
- [Visualizing Regression Planes in 3D (Wolfram MathWorld)](https://mathworld.wolfram.com/LeastSquaresFitting.html)
