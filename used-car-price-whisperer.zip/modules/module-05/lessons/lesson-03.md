# Lesson 03: The Actual-vs-Predicted Scatter Plot (What the Diagonal Means)

**Lesson ID:** lesson-03  
**Module:** module-05  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain the role of the actual-vs-predicted scatter plot as a visual regression diagnostic tool.
- Deconstruct lines 58–70 in `main.py` that configure and render the plot.
- Explain the mathematical significance of the 45-degree dashed reference line ($y = x$).
- Diagnose overestimation (points above diagonal) and underestimation (points below diagonal).
- Explain why a 1:1 aspect ratio (`figsize=(6, 6)`) and non-interactive `plt.close(fig)` are critical for headless pipelines.

## Prerequisites

Completion of [Module 05 Lesson 01](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-05/lessons/lesson-01.md) and [Lesson 02](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-05/lessons/lesson-02.md). Understanding of Cartesian coordinates and matplotlib plotting fundamentals.

## Concept Explanation

### Why Summary Metrics Aren't Enough
Summary numbers such as MAE ($906) and $R^2$ (0.93) provide concise quantitative evaluations of model performance. However, summary statistics alone can obscure critical patterns:
- Does the model predict budget vehicles ($3,000) as accurately as luxury cars ($20,000)?
- Are errors evenly balanced, or does the model systematically over-predict across certain price tiers?
- Are there extreme outliers where the model fails completely?

To answer these questions, data scientists rely on the **actual-vs-predicted scatter plot**.

### The Geometry of the 45-Degree Diagonal
In an actual-vs-predicted plot:
- The **horizontal X-axis** represents the **Actual price ($)** recorded in the test dataset ($y_{test}$).
- The **vertical Y-axis** represents the **Predicted price ($)** produced by our regression equation ($\hat{y}$).

If our model were 100% flawless on every single test car, then for every vehicle:
$$\hat{y}_i = y_i$$

Graphing all points where $Y = X$ forms a straight line rising at an exact 45-degree angle through the coordinate plane. In `main.py`, this is plotted as a red dashed line (`color="#c0392b", linestyle="--"`), explicitly labeled **"perfect prediction"**.

```text
 Predicted Price ($)
          ^
   $25k   |                       /  [Perfect Prediction Line]
          |                     / * (Car A: Slight Underestimate)
   $15k   |                   /
          |            *    /     (Car B: Overestimate)
   $5k    |          *    /
          +----------------------------------->
             $5k        $15k       $25k   Actual Price ($)
```

### Diagnosing Valuation Errors from Geometry
Every plotted dot represents one vehicle in the test set. Its spatial position relative to the diagonal reveals the nature of the model's error:
1. **On the Diagonal ($y = \hat{y}$):** The model guessed the exact transaction price. Error is $0.
2. **Above the Diagonal ($\hat{y} > y$):** The predicted price is greater than the actual price. The model **overestimated** the car's value (the whisperer was overly optimistic).
3. **Below the Diagonal ($\hat{y} < y$):** The predicted price is lower than the actual price. The model **underestimated** the car's value (the whisperer underpriced the vehicle).
4. **Tight Clustering Along the Line:** In `actual_vs_predicted.png`, the 12 test dots cluster tightly around the dashed line from $2,000 up to $22,000, confirming visually why $R^2$ is so high (0.93) and MAE is low ($906).

## Relevant Code (from main.py, lines 58-70)

```python
fig, ax = plt.subplots(figsize=(6, 6))
ax.scatter(y_test, predictions, color="#2471a3", s=65, alpha=0.85)
low = min(y_test.min(), predictions.min())
high = max(y_test.max(), predictions.max())
ax.plot([low, high], [low, high], color="#c0392b", linestyle="--", label="perfect prediction")
ax.set_xlabel("Actual price ($)")
ax.set_ylabel("Predicted price ($)")
ax.set_title("Actual vs. predicted used-car prices")
ax.legend()
ax.grid(alpha=0.25)
fig.tight_layout()
fig.savefig(OUT / "actual_vs_predicted.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```

### Code explanation
- **Line 58 (`figsize=(6, 6)`):** Setting equal width and height produces a square plotting canvas, ensuring that the diagonal line maintains a true, visually undistorted 45-degree angle.
- **Line 59 (`ax.scatter(...)`):** Renders the 12 test instances using steel blue markers (`#2471a3`), a prominent marker size (`s=65`), and slight transparency (`alpha=0.85`) to reveal any overlapping data points.
- **Lines 60–62 (`low`, `high`, `ax.plot(...)`):** Dynamically computes the global minimum and maximum across both actuals and predictions, then draws a dashed line from `(low, low)` to `(high, high)`.
- **Lines 63–67:** Configures professional labels, title, legend, and subtle grid lines (`alpha=0.25`) for coordinate readability.
- **Lines 68–70:** Optimizes margins (`fig.tight_layout()`), exports the figure to `outputs/actual_vs_predicted.png` at crisp print resolution (`dpi=150`), and frees memory resources with `plt.close(fig)`.

## Worked Example

**Scenario:** Suppose we inspect two specific vehicles plotted in `actual_vs_predicted.png`:
- **Vehicle 1 (Test car #3):** Actual sale price: $14,012. Predicted price: $13,420.
  - Coordinate: $(14012, 13420)$
  - Vertical comparison: $13,420 < 14,012$.
  - Position: Sits **below** the diagonal line.
  - Valuation diagnosis: **Underestimated** by $592.
- **Vehicle 2 (Test car #7):** Actual sale price: $4,871. Predicted price: $5,610.
  - Coordinate: $(4871, 5610)$
  - Vertical comparison: $5,610 > 4,871$.
  - Position: Sits **above** the diagonal line.
  - Valuation diagnosis: **Overestimated** by $739.

Because both deviations ($592 and $739) are close to the diagonal line, they confirm consistent accuracy without extreme valuation blowouts.

## Step-by-Step Student Instructions

1. **Locate Visualization Code:** Open [`main.py`](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML%20Beginners/projects/07_car_price/main.py#L58-L70) and review lines 58 to 70.
2. **Trace the Dynamic Range Calculation:** Notice how `low` and `high` take the minimum and maximum of both `y_test` and `predictions`. Why is this superior to hardcoding `[0, 25000]`? (Dynamic boundaries adapt automatically if new data is introduced).
3. **Run the Script to Generate the Plot:**
   ```bash
   python /home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML\ Beginners/projects/07_car_price/main.py
   ```
4. **Locate the Saved Artifact:** Confirm that `outputs/actual_vs_predicted.png` exists.
5. **Inspect the Plot:** View the generated image file. Count the 12 plotted blue circles and observe how tightly they track the red dashed line from bottom-left to top-right.

## Expected Output or Observable Behaviour

Executing `main.py` produces:
```text
Saved: outputs/actual_vs_predicted.png, outputs/metrics.txt
```

Inspecting `outputs/actual_vs_predicted.png`:
- Square 6x6 figure with clear labels ("Actual price ($)", "Predicted price ($)").
- 12 steel blue dots corresponding to the test vehicles.
- A red dashed diagonal reference line running from roughly $2,000 to $23,000.
- A legend box in the corner designating the dashed line as "perfect prediction".

## Practical Exercises

- **Exercise 3.1:** If an analyst plotted actual prices on the Y-axis and predicted prices on the X-axis, what would points above the diagonal mean? Explain why standard convention places Actual on X and Predicted on Y.
- **Exercise 3.2:** What would an actual-vs-predicted scatter plot look like for a completely useless model that always predicts a constant price of $10,000? Describe the resulting shape of the plotted dots.
- **Exercise 3.3:** Why is `plt.close(fig)` especially critical in automated batch scripts or web servers generating hundreds of plots sequentially?

## Common Mistakes and Debugging

| Mistake | Why it happens | How to avoid or fix |
|---|---|---|
| Non-square figure dimensions (e.g. `figsize=(10, 4)`) | Rectangular dimensions distort visual perception of angles; a 45-degree slope appears flattened or steepened. | Always use square dimensions like `figsize=(6, 6)` for actual-vs-predicted plots. |
| Forgetting `plt.close(fig)` | Matplotlib retains open figure objects in system RAM, eventually causing memory exhaustion in production. | Always call `plt.close(fig)` immediately after `fig.savefig()`. |
| Hardcoding diagonal line endpoints | Writing `ax.plot([0, 30000], [0, 30000])` may crop points or create empty white space. | Use `low = min(...)` and `high = max(...)` to tightly bound the diagonal to actual data. |

## Best Practices and Security Considerations

- **Headless Backend Safety:** Ensure `matplotlib.use("Agg")` is configured before importing pyplot, preventing crashes when running in headless terminal, Docker, or CI/CD environments.
- **High Resolution Export:** Set `dpi=150` or `dpi=300` and `bbox_inches="tight"` to ensure legible labels and crisp graphics in technical reports.
- **Color Contrast & Accessibility:** The chosen colors (`#2471a3` blue and `#c0392b` red) provide strong chromatic and luminance contrast, remaining legible for color-blind readers and in grayscale printouts.

## Summary

In Lesson 03, we examined the actual-vs-predicted scatter plot, an indispensable visual diagnostic tool for regression analysis. By mapping actual sales prices on the horizontal axis against predicted prices on the vertical axis alongside a 45-degree dashed "perfect prediction" reference line ($y = x$), we can immediately evaluate model bias, variance, and outlier behavior. Our 12 test vehicles cluster tightly along the diagonal across all price tiers, confirming that our multiple regression model provides robust, balanced valuations.

## Knowledge-check Questions

1. In the actual-vs-predicted plot, what do the horizontal and vertical axes represent?
2. What does the red dashed diagonal line represent geometrically and conceptually?
3. If a vehicle's plotted dot lies above the diagonal line, was the car overestimated or underestimated?
4. Why is a square aspect ratio (`figsize=(6, 6)`) recommended for this diagnostic plot?
5. What function is called at the end of the plotting block to free system memory?

## References

- [main.py lines 58-70](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML%20Beginners/projects/07_car_price/main.py#L58-L70)
- [Matplotlib Scatter Plot Documentation](https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.scatter.html)
- [Scikit-learn Model Evaluation Visualizations](https://scikit-learn.org/stable/visualizations.html)
