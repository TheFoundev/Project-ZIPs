# Lesson 02: R² Interpretation for Car Prices

**Lesson ID:** lesson-02  
**Module:** module-05  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Define the coefficient of determination ($R^2$ score) mathematically and conceptually.
- Explain the role of Total Sum of Squares ($SS_{tot}$) and Residual Sum of Squares ($SS_{res}$).
- Interpret the Used Car Price Whisperer's $R^2$ score of $0.9280$ ($\approx 0.93$) in practical terms of variance explained.
- Contrast a baseline "mean-only" predictor with our trained multiple regression model.
- Identify the real-world factors that account for the remaining $\approx 7\%$ of unexplained price variance.

## Prerequisites

Completion of [Module 05 Lesson 01](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-05/lessons/lesson-01.md). Basic understanding of variance, test set evaluation, and regression lines.

## Concept Explanation

### What is $R^2$ (The Coefficient of Determination)?
While Mean Absolute Error (MAE) tells us the average magnitude of error in raw dollar terms ($906), it does not tell us what proportion of the overall price variability our model successfully captures. 

In any used car market, prices naturally vary across a wide spectrum. In our dataset, vehicle prices range from $1,500 all the way to $22,865. Why do these prices vary so dramatically? 
- Is the price variation purely random noise?
- Or is it systematically driven by identifiable vehicular attributes like age and kilometers?

The **$R^2$ score** (coefficient of determination) answers this question directly. It quantifies the **proportion of variance in the target variable ($y$) that is predictable from the independent features ($X$)**.

### Mathematical Formulation
$R^2$ compares our regression model against a naive baseline model that simply predicts the mean price ($\bar{y}$) for every single car:

$$R^2 = 1 - \frac{SS_{res}}{SS_{tot}}$$

Where:
1. **Residual Sum of Squares ($SS_{res}$):** The sum of squared prediction errors from our model:
   $$SS_{res} = \sum_{i=1}^{n} (y_i - \hat{y}_i)^2$$
2. **Total Sum of Squares ($SS_{tot}$):** The total variance in actual car prices relative to the dataset average ($\bar{y}$):
   $$SS_{tot} = \sum_{i=1}^{n} (y_i - \bar{y})^2$$

### Interpreting the Scale of $R^2$
- **$R^2 = 1.0$ (100%):** Perfect prediction. Every single data point falls exactly on the regression plane ($SS_{res} = 0$).
- **$R^2 = 0.0$ (0%):** The model performs no better than simply guessing the average price ($\bar{y}$) of all cars for every query ($SS_{res} = SS_{tot}$).
- **$R^2 < 0.0$ (Negative):** Possible when evaluating on unseen test data if the model performs worse than the simple horizontal line representing the mean price.
- **$R^2 = 0.93$ (In this project):** The two features—`age_years` and `kilometers`—explain **92.8% of the total variance** in used car prices!

### Where Does the Remaining ~7% Go?
An $R^2$ of $0.93$ indicates exceptional explanatory power, but it is not 100%. The remaining $\approx 7.2\%$ of unexplained variance represents unmeasured real-world factors:
1. **Vehicle Make & Model:** A 5-year-old luxury German sedan depreciates at a different pace than a 5-year-old Japanese commuter hatchback.
2. **Physical & Cosmetic Condition:** Scratches, rust, interior wear, or paint fading.
3. **Mechanical Health:** Service history, timely oil changes, tire tread depth, and transmission maintenance.
4. **Accident History:** Vehicles with recorded collisions sell at steep discounts relative to clean-title cars.
5. **Local Market Demand & Seasonality:** Convertibles command higher prices in summer, while all-wheel-drive SUVs sell higher in snowy winter regions.

## Relevant Code (from main.py, lines 41, 55, 77)

```python
# Line 41: Compute R2 on the test set
r2 = r2_score(y_test, predictions)

# Line 55: Print formatted R2 to console
print(f"R-squared: {r2:.2f}")

# Line 77: Write high-precision R2 to metrics.txt
handle.write(f"R2: {r2:.4f}\n")
```

### Code explanation
- **Line 41**: `r2_score(y_test, predictions)` compares the test ground-truth targets `y_test` against the model's test predictions `predictions`. It evaluates $1 - (SS_{res} / SS_{tot})$ and returns the score as a floating-point number (`0.92804...`).
- **Line 55**: The format specifier `{r2:.2f}` rounds the metric to two decimal places, displaying `R-squared: 0.93` on the terminal.
- **Line 77**: The file writer records `{r2:.4f}`, storing `R2: 0.9280` in `outputs/metrics.txt` for auditability and automated verification.

## Worked Example

**Scenario:** Let us compute $R^2$ by hand for a miniature dataset of 3 test cars:
- Actual prices: $y = [10,000, 15,000, 20,000]$
- Model predictions: $\hat{y} = [11,000, 14,000, 20,500]$

**Step 1: Compute the Mean of Actual Prices ($\bar{y}$)**
$$\bar{y} = \frac{10,000 + 15,000 + 20,000}{3} = \$15,000$$

**Step 2: Compute Total Sum of Squares ($SS_{tot}$)**
$$SS_{tot} = (10,000 - 15,000)^2 + (15,000 - 15,000)^2 + (20,000 - 15,000)^2$$
$$SS_{tot} = (-5,000)^2 + 0^2 + (5,000)^2 = 25,000,000 + 0 + 25,000,000 = 50,000,000$$

**Step 3: Compute Residual Sum of Squares ($SS_{res}$)**
$$SS_{res} = (10,000 - 11,000)^2 + (15,000 - 14,000)^2 + (20,000 - 20,500)^2$$
$$SS_{res} = (-1,000)^2 + (1,000)^2 + (-500)^2 = 1,000,000 + 1,000,000 + 250,000 = 2,250,000$$

**Step 4: Compute $R^2$**
$$R^2 = 1 - \frac{2,250,000}{50,000,000} = 1 - 0.045 = 0.955$$

**Conclusion:** The model captures $95.5\%$ of the total price variation in this miniature sample. In our full project, `main.py` yields $R^2 = 0.9280$, demonstrating that age and mileage alone explain roughly $93\%$ of used car price variability.

## Step-by-Step Student Instructions

1. **Locate $R^2$ Calculation:** Open [`main.py`](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML%20Beginners/projects/07_car_price/main.py#L41) and locate lines 41, 55, and 77.
2. **Review the Import:** Check line 18 where `r2_score` is imported from `sklearn.metrics`.
3. **Execute the Script:** Run `python main.py` in your terminal:
   ```bash
   python /home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML\ Beginners/projects/07_car_price/main.py
   ```
4. **Observe the Console Output:** Note that line 55 outputs:
   ```text
   R-squared: 0.93
   ```
5. **Verify the Output File:** Inspect `outputs/metrics.txt` and note:
   ```text
   R2: 0.9280
   ```

## Expected Output or Observable Behaviour

Running `main.py` displays:
```text
Mean absolute error: $906
R-squared: 0.93
Prediction for a 5-year-old car with 60,000 km: $15,077
```

In `outputs/metrics.txt`:
```text
R2: 0.9280
```

## Practical Exercises

- **Exercise 2.1:** If a naive model always predicts the average car price ($\bar{y}$) regardless of age or mileage, what will its $SS_{res}$ and $R^2$ be?
- **Exercise 2.2:** Suppose an overfitted model achieves $R^2 = 0.99$ on the training set, but when evaluated on the test set, $R^2$ drops to $0.45$. Explain what this discrepancy signifies.
- **Exercise 2.3:** Why is $R^2$ a dimensionless unit (ranging typically from 0 to 1), whereas MAE is measured in dollars? Why is reporting both metrics together standard practice in data science?

## Common Mistakes and Debugging

| Mistake | Why it happens | How to avoid or fix |
|---|---|---|
| Assuming $R^2$ cannot be negative | Believing $R^2$ is strictly a squared number ($r \times r$). In scikit-learn, $R^2$ is computed as $1 - (SS_{res}/SS_{tot})$, which can be negative if predictions are worse than the mean. | Ensure your model is properly fitted to training data and that features are appropriately scaled or shaped before evaluating on test data. |
| Reversing arguments in `r2_score(predictions, y_test)` | Passing predicted values first instead of ground-truth targets. | Always pass `(y_true, y_pred)` in scikit-learn metric functions: `r2_score(y_test, predictions)`. |
| Believing $R^2 = 0.93$ means 93% of predictions are correct | Confusing classification accuracy (percentage of correct labels) with continuous variance explained. | Frame $R^2$ accurately: "The model accounts for 93% of the variability in car prices." |

## Best Practices and Security Considerations

- **Pair $R^2$ with Scale-Dependent Metrics:** Always present $R^2$ alongside MAE or RMSE. $R^2$ communicates relative explanatory strength, while MAE provides the tangible real-world dollar impact.
- **Beware of High $R^2$ with Data Leakage:** An unrealistically high $R^2$ (> 0.99) often indicates data leakage (e.g., inadvertently leaving the target column in the feature matrix).
- **Check Test Set Representativeness:** Ensure the test set contains cars across the full price spectrum; if a test set contains only cars of identical price, $SS_{tot} \approx 0$, making $R^2$ undefined or unstable.

## Summary

In Lesson 02, we analyzed the coefficient of determination ($R^2$). $R^2$ measures the proportion of variance in vehicle selling prices that is explained by our multiple linear regression model. Comparing residual errors against a baseline mean predictor, our model achieves an $R^2$ of $0.9280$ ($\approx 0.93$) on unseen test data. This confirms that vehicle age and cumulative mileage are extraordinarily powerful drivers of used car depreciation, accounting for approximately $93\%$ of the observed market price variance.

## Knowledge-check Questions

1. What does the $R^2$ score measure in a regression analysis?
2. What baseline model is $R^2$ mathematically compared against?
3. What is the $R^2$ score achieved by "The Used Car Price Whisperer" on the test partition, rounded to two decimal places?
4. What percentage of car price variance remains unexplained by vehicle age and kilometers in our test set?
5. Why is $R^2$ dimensionless, unlike MAE which is measured in dollars?

## References

- [main.py lines 41, 55, 77](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML%20Beginners/projects/07_car_price/main.py#L41-L77)
- [Scikit-learn r2_score Documentation](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.r2_score.html)
- [StatQuest: R-squared Explained](https://statquest.org/)
