# Lesson 01: MAE Interpretation (Error in Dollars)

**Lesson ID:** lesson-01  
**Module:** module-05  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Define Mean Absolute Error (MAE) mathematically and conceptually.
- Explain why MAE retains the identical physical unit of measurement as the target variable (US dollars).
- Compute MAE by hand using test set actuals and model predictions.
- Interpret the Used Car Price Whisperer's MAE of approximately $906 in practical business and consumer contexts.
- Contrast MAE with Mean Squared Error (MSE) and Root Mean Squared Error (RMSE) in terms of interpretability and sensitivity to outliers.

## Prerequisites

Completion of [Module 04](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-04/module.json) (Model Training & Coefficient Interpretation). Understanding of test set predictions and basic arithmetic absolute values.

## Concept Explanation

### The Need for an Intuitive Evaluation Metric
After fitting a multiple regression model to our training data and generating price estimates for our test vehicles, a crucial question arises: **"How wrong is the model typically when it values an unseen car?"**

In regression tasks, every individual prediction $\hat{y}_i$ differs from the true recorded market price $y_i$ by some amount known as an error or residual:
$$\text{residual}_i = y_i - \hat{y}_i$$

If we merely computed the simple average of these residuals across all test vehicles, positive errors (under-predicting a price) and negative errors (over-predicting a price) would cancel each other out. A model that was off by $+\$5,000$ on one car and $-\$5,000$ on another would produce an average error of $\$0$, giving a dangerously misleading illusion of flawless accuracy.

To measure true error magnitude regardless of direction, we take the absolute value of each difference before averaging. This is **Mean Absolute Error (MAE)**.

### Mathematical Formulation of MAE
For a test set containing $n$ vehicles:
$$\text{MAE} = \frac{1}{n} \sum_{i=1}^{n} |y_i - \hat{y}_i|$$

Where:
- $n$ is the number of test vehicles (in our case, $n = 12$).
- $y_i$ is the actual transaction price in USD for vehicle $i$.
- $\hat{y}_i$ is the model's estimated price in USD for vehicle $i$.
- $|y_i - \hat{y}_i|$ represents the absolute monetary error for vehicle $i$.

### Physical Unit Preservation
One of MAE's greatest strengths in machine learning workflows is **direct interpretability**. Because MAE does not square the differences (unlike Mean Squared Error), the unit of measurement is not transformed into "squared dollars" ($\$^2$). MAE is expressed in the exact same physical and currency units as the target variable: **US Dollars ($)**.

When a dealership manager or car buyer asks, *"What is the expected valuation accuracy?"*, an engineer can answer directly: *"On average, our predictions deviate from actual transaction prices by about $906."*

### MAE vs. MSE and RMSE
| Metric | Formula | Units | Outlier Sensitivity | Best Used When |
|---|---|---|---|---|
| **MAE** | $\frac{1}{n} \sum \|y - \hat{y}\|$ | Original units ($) | Linear (robust to occasional outliers) | Stakeholders require clear, intuitive dollar figures |
| **MSE** | $\frac{1}{n} \sum (y - \hat{y})^2$ | Squared units ($\$^2$) | Quadratic (heavily penalizes large errors) | Mathematical optimization (gradient descent) |
| **RMSE** | $\sqrt{\frac{1}{n} \sum (y - \hat{y})^2}$ | Original units ($) | Moderate to high | Large valuation mistakes are disproportionately costly |

In `main.py`, scikit-learn's `mean_absolute_error` provides a transparent, business-ready assessment of model performance.

## Relevant Code (from main.py, lines 40, 54, 76)

```python
# Line 40: Calculate MAE on test set
mae = mean_absolute_error(y_test, predictions)

# Line 54: Print formatted MAE to console
print(f"Mean absolute error: ${mae:,.0f}")

# Line 76: Persist MAE with two decimal places to outputs/metrics.txt
handle.write(f"MAE: {mae:.2f}\n")
```

### Code explanation
- **Line 40**: `mean_absolute_error(y_test, predictions)` accepts the ground-truth target vector `y_test` and the predicted array `predictions`. It iterates over all 12 test instances, calculates $|y_{test, i} - \hat{y}_i|$, and returns the arithmetic mean as a standard float (`905.97...`).
- **Line 54**: The formatted string `f"Mean absolute error: ${mae:,.0f}"` rounds the value to the nearest whole integer and inserts a comma thousands separator, outputting `Mean absolute error: $906`.
- **Line 76**: `handle.write(f"MAE: {mae:.2f}\n")` preserves scientific precision by writing `MAE: 905.97` into `outputs/metrics.txt`.

## Worked Example

**Scenario:** Suppose our test set consisted of just 4 cars with the following actual sales prices and model predictions:

| Vehicle | Actual Price ($y$) | Predicted Price ($\hat{y}$) | Error ($y - \hat{y}$) | Absolute Error ($|y - \hat{y}|$) |
|---|---|---|---|---|
| Car 1 | $14,000 | $14,500 | -$500 | $500 |
| Car 2 | $8,200 | $7,400 | +$800 | $800 |
| Car 3 | $21,000 | $22,200 | -$1,200 | $1,200 |
| Car 4 | $4,500 | $3,400 | +$1,100 | $1,100 |

**Step 1: Calculate Sum of Absolute Errors**
$$\sum_{i=1}^{4} |y_i - \hat{y}_i| = 500 + 800 + 1200 + 1100 = \$3,600$$

**Step 2: Divide by the Number of Samples ($n = 4$)**
$$\text{MAE} = \frac{3,600}{4} = \$900$$

**Interpretation:** Across these 4 vehicles, the model's price estimates deviate from actual transaction prices by an average of $900. In `main.py`, across the full 12-car test split, the resulting MAE is **$905.97**. Given that used car prices in our dataset range up to $22,865, an average error of ~$906 represents an error rate under 5% across typical inventory.

## Step-by-Step Student Instructions

1. **Locate MAE Calculation in Source Code:** Open [`main.py`](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML%20Beginners/projects/07_car_price/main.py#L40) and locate line 40 where `mean_absolute_error` is invoked.
2. **Review the Inputs:** Confirm that `y_test` (actual test prices) and `predictions` (model outputs on `X_test`) are passed as arguments. Notice that training targets (`y_train`) are never passed to this metric.
3. **Execute the Script:** In your terminal, run:
   ```bash
   python /home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML\ Beginners/projects/07_car_price/main.py
   ```
4. **Inspect Console Output:** Verify that line 54 prints:
   ```text
   Mean absolute error: $906
   ```
5. **Inspect the Output File:** Open `outputs/metrics.txt` and verify that line 4 records `MAE: 905.97`.

## Expected Output or Observable Behaviour

Running the script produces:
```text
============================================================
THE USED CAR PRICE WHISPERER
============================================================
Equation: price = 26,818 + (-1,242 x age) + (-0.09 x km)
Each extra year is associated with about $1,242 less value.
Each extra 10,000 km is associated with about $922 less value.
Mean absolute error: $906
R-squared: 0.93
Prediction for a 5-year-old car with 60,000 km: $15,077
```

In `outputs/metrics.txt`:
```text
MAE: 905.97
```

## Practical Exercises

- **Exercise 1.1:** If a car's actual price is $12,500 and the model predicts $13,400, what is the absolute error? If another car's actual price is $12,500 and the model predicts $11,600, what is the absolute error? Explain why both yield the exact same absolute error of $900.
- **Exercise 1.2:** Suppose a luxury sports car in a test set is severely underpriced by $15,000 due to rare collector status. How would this single outlier affect MAE compared to MSE?
- **Exercise 1.3:** Calculate the percentage error of our $906 MAE relative to a car selling for $18,000 versus a car selling for $2,000. Why is percentage error (MAPE) sometimes evaluated alongside absolute dollar error?

## Common Mistakes and Debugging

| Mistake | Why it happens | How to avoid or fix |
|---|---|---|
| Passing `y_train` instead of `y_test` to `mean_absolute_error` | Copy-paste error from training code. Evaluating on training data yields overly optimistic metrics. | Always verify that evaluation metrics receive `y_test` and `predictions` generated strictly from `X_test`. |
| Forgetting absolute value when computing error manually | Subtracting values without `abs()` causes positive and negative errors to cancel out. | Always wrap differences in `abs()` or use `np.abs(y_test - predictions)`. |
| Confusing MAE with MSE units | Forgetting that MSE squares units, producing results like "820,000 squared dollars". | Use MAE whenever you need human-readable monetary values. |

## Best Practices and Security Considerations

- **Always Evaluate on Unseen Data:** Never report MAE measured on the training set as the model's expected real-world accuracy. Training MAE is almost always artificially low due to memorization.
- **Contextualize the Metric:** An MAE of $906 is outstanding for $20,000 vehicles (~4.5% error) but substantial for $1,500 beater cars (~60% error). Consider reporting errors across stratified price brackets.
- **Data Integrity:** Ensure no corrupted, negative, or placeholder price entries (e.g., `$999,999` or `-$1`) are present in the test set, as they distort the mean.

## Summary

In Lesson 01, we explored Mean Absolute Error (MAE), the primary evaluation metric for continuous monetary regression in "The Used Car Price Whisperer". By computing the arithmetic mean of absolute residuals between actual sale prices and model predictions, MAE measures typical error magnitude while preserving dollar units ($). On our 12-car test partition, the model achieves an MAE of $905.97 (~$906), demonstrating strong predictive accuracy across pre-owned vehicle valuations.

## Knowledge-check Questions

1. What mathematical operation prevents positive and negative errors from canceling each other out in MAE?
2. What physical unit of measurement does MAE possess in this project?
3. What is the numerical value of MAE computed by `main.py` on the test set, rounded to the nearest dollar?
4. Why is MAE generally preferred over Mean Squared Error when explaining model performance to non-technical business clients?
5. If the model predicts $14,200 for a car that actually sold for $15,106, what is the absolute error for this specific car?

## References

- [main.py lines 40, 54, 76](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML%20Beginners/projects/07_car_price/main.py#L40-L76)
- [Scikit-learn Mean Absolute Error Documentation](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.mean_absolute_error.html)
- [NIST Engineering Statistics Handbook - Measuring Model Error](https://www.itl.nist.gov/div898/handbook/pmd/section4/pmd44.htm)
