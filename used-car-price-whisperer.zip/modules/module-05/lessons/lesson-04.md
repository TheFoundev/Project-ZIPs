# Lesson 04: Writing metrics.txt and Reading the Output File

**Lesson ID:** lesson-04  
**Module:** module-05  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain why persisting model parameters and evaluation metrics to disk is essential in production machine learning pipelines.
- Deconstruct the Python context manager syntax (`with open(...) as handle:`) used in lines 72–79 of `main.py`.
- Explain why specific floating-point precision formatting (e.g., `:.6f` for kilometer weight and `:.4f` for $R^2$) is chosen.
- Read and parse `outputs/metrics.txt` programmatically using Python.
- Contrast ephemeral terminal printing with permanent file-based metric logging.

## Prerequisites

Completion of [Module 05 Lesson 01](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-05/lessons/lesson-01.md), [Lesson 02](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-05/lessons/lesson-02.md), and [Lesson 03](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-05/lessons/lesson-03.md). Basic understanding of Python file handling.

## Concept Explanation

### The Problem with Terminal-Only Output
When developing a machine learning script, printing outputs to standard output (`sys.stdout`) with `print()` is great for immediate developer feedback. However, in real-world engineering workflows, terminal output is **ephemeral**:
- If an automated scheduled job or Docker container terminates, the console text disappears.
- Upstream systems (such as automated model deployment pipelines or monitoring dashboards) cannot easily parse raw terminal text cluttered with decorative borders (`===`).
- Reproducibility and auditing require a permanent, version-controlled record of every training run's exact parameters and scores.

To solve this, professional ML systems persist key metrics and learned model coefficients to structured files on disk. In "The Used Car Price Whisperer", lines 72–79 write a clean, standardized report to `outputs/metrics.txt`.

### Safe File I/O with Context Managers
Python provides the `with open(...) as handle:` syntax, known as a **context manager**. It automatically handles file acquisition and cleanup:
1. **Guaranteed File Closure:** Even if an unhandled exception or crash occurs while writing, Python guarantees that the file handle is safely closed and flushed to disk.
2. **Explicit UTF-8 Encoding:** Specifying `encoding="utf-8"` prevents silent character-encoding corruption across different operating systems (such as Windows using CP1252 vs. Linux using UTF-8).
3. **Write Mode (`"w"`):** If the file already exists, it is overwritten with the newest calibration results; if it does not exist, it is created automatically inside the `outputs` directory.

### Tailored Numeric Formatting
Notice the precision choices in `main.py`:
- `intercept: {intercept:.2f}`: Two decimal places for currency cents ($26,817.96).
- `age coefficient: {age_weight:.2f}`: Two decimal places for annual depreciation (-$1,241.53).
- `km coefficient: {km_weight:.6f}`: **Six decimal places** (`-0.092223`). Why six? Because each single kilometer changes price by only a few pennies ($0.092223). Rounding to zero or one decimal place would obliterate the weight entirely (e.g. `0.1` or `0.0`), corrupting downstream predictions!
- `MAE: {mae:.2f}`: Dollar error recorded to the cent ($905.97).
- `R2: {r2:.4f}`: **Four decimal places** (`0.9280`). In statistical evaluation, differences between 0.9280 and 0.9250 represent meaningful performance shifts.
- `example prediction: {example_price:.2f}`: Predicted price formatted to currency cents ($15,076.97).

## Relevant Code (from main.py, lines 72-79)

```python
with open(OUT / "metrics.txt", "w", encoding="utf-8") as handle:
    handle.write(f"intercept: {intercept:.2f}\n")
    handle.write(f"age coefficient: {age_weight:.2f}\n")
    handle.write(f"km coefficient: {km_weight:.6f}\n")
    handle.write(f"MAE: {mae:.2f}\n")
    handle.write(f"R2: {r2:.4f}\n")
    handle.write(f"example prediction: {example_price:.2f}\n")
```

### Code explanation
- **Line 72 (`OUT / "metrics.txt"`):** Leverages `pathlib.Path` syntax to construct an absolute path pointing to `outputs/metrics.txt`.
- **Lines 73–78 (`handle.write(...)`):** Writes key-value formatted text lines followed by explicit newline characters (`\n`).
- **Precision specifiers (`:.2f`, `:.6f`, `:.4f`):** Controls exact numeric precision, avoiding messy scientific notation (like `1.507697e+04`) while preserving necessary mathematical precision.

## Worked Example

**Scenario:** Let us inspect the actual contents written by `main.py` into `outputs/metrics.txt`:

```text
intercept: 26817.96
age coefficient: -1241.53
km coefficient: -0.092223
MAE: 905.97
R2: 0.9280
example prediction: 15076.97
```

**How a downstream script reads and parses this file:**
```python
from pathlib import Path

metrics_path = Path("outputs/metrics.txt")
metrics = {}

with open(metrics_path, "r", encoding="utf-8") as file:
    for line in file:
        key, value = line.strip().split(": ")
        metrics[key] = float(value)

print("Parsed Metrics Dictionary:")
print(metrics)
print(f"Loaded Intercept: ${metrics['intercept']:,.2f}")
print(f"Loaded MAE: ${metrics['MAE']:,.2f}")
```

**Output of parsing script:**
```text
Parsed Metrics Dictionary:
{'intercept': 26817.96, 'age coefficient': -1241.53, 'km coefficient': -0.092223, 'MAE': 905.97, 'R2': 0.928, 'example prediction': 15076.97}
Loaded Intercept: $26,817.96
Loaded MAE: $905.97
```

Because the format is simple and consistent, automated CI/CD regression tests can assert that `metrics['R2'] >= 0.90` and `metrics['MAE'] <= 1000.0` before deploying the model to production!

## Step-by-Step Student Instructions

1. **Locate File I/O Block:** Open [`main.py`](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML%20Beginners/projects/07_car_price/main.py#L72-L79) and inspect lines 72 to 79.
2. **Execute the Complete Pipeline:** In your terminal, run:
   ```bash
   python /home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML\ Beginners/projects/07_car_price/main.py
   ```
3. **Verify File Creation:** Check that `outputs/metrics.txt` was created or updated:
   ```bash
   ls -la /home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML\ Beginners/projects/07_car_price/outputs/metrics.txt
   ```
4. **Read File Contents in Terminal:** Display the file text:
   ```bash
   cat /home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML\ Beginners/projects/07_car_price/outputs/metrics.txt
   ```
5. **Verify Values Match Expectations:** Check that `intercept` is ~`26817.96`, `age coefficient` is ~`-1241.53`, `km coefficient` is ~`-0.092223`, `MAE` is ~`905.97`, and `R2` is ~`0.9280`.

## Expected Output or Observable Behaviour

Executing `main.py` concludes with:
```text
Saved: outputs/actual_vs_predicted.png, outputs/metrics.txt
Try this: add a 'fuel_type' column (petrol/diesel) and think about encoding it.
```

The resulting file `outputs/metrics.txt` contains:
```text
intercept: 26817.96
age coefficient: -1241.53
km coefficient: -0.092223
MAE: 905.97
R2: 0.9280
example prediction: 15076.97
```

## Practical Exercises

- **Exercise 4.1:** What happens if `outputs/` directory does not exist prior to running line 72? Refer back to line 24 of `main.py` (`OUT.mkdir(exist_ok=True)`) and explain why creating the directory beforehand is mandatory.
- **Exercise 4.2:** Why is `km coefficient` formatted with `:.6f` instead of `:.2f`? If we used `:.2f`, what value would be written, and how would that alter a prediction for a car with 100,000 km?
- **Exercise 4.3:** Write a 3-line Python snippet that reads `metrics.txt` and asserts that `R2` is greater than `0.90`, raising an `AssertionError` if model accuracy drops.

## Common Mistakes and Debugging

| Mistake | Why it happens | How to avoid or fix |
|---|---|---|
| Omitting `\n` in `handle.write()` | `write()` does not automatically append newlines (unlike `print()`), bunching all metrics into a single unreadable line. | Always append `\n` to every string passed to `handle.write()`. |
| Writing to a path without creating the directory first | `open()` cannot create missing parent directories, causing `FileNotFoundError`. | Always call `OUT.mkdir(exist_ok=True)` before opening files inside `OUT`. |
| Omitting `encoding="utf-8"` | Default platform encodings can lead to garbled text or parsing errors across operating systems. | Explicitly include `encoding="utf-8"` in all `open()` calls. |

## Best Practices and Security Considerations

- **Always Use Context Managers:** Never use manual `file = open(...)` and `file.close()`. A context manager guarantees file closure even if exceptions occur.
- **Path Sanitization:** When constructing output file paths dynamically from user inputs, sanitize file names to prevent directory traversal attacks (`../`). Here, `OUT / "metrics.txt"` is safely hardcoded.
- **Immutable Metric Archival:** In production systems, consider appending timestamps or Git commit hashes to output filenames (e.g. `metrics_20261028_gitsha.txt`) to maintain a tamper-evident audit history.

## Summary

In Lesson 04, we explored metric persistence with `outputs/metrics.txt`. Moving beyond transient console prints, persisting learned model coefficients and evaluation scores into a structured text file ensures reproducibility, auditability, and integration into automated testing pipelines. By combining Python's robust context manager with tailored floating-point precision formatting, the pipeline produces permanent, machine-readable artifacts of the model's performance.

## Knowledge-check Questions

1. Why is the Python context manager (`with open(...) as handle:`) preferred over manual `open()` and `close()`?
2. What happens if you run `handle.write()` without appending `\n`?
3. Why does line 75 format the kilometer coefficient with six decimal places (`:.6f`) instead of two?
4. What line in `main.py` guarantees that the `outputs/` folder exists before any files are written into it?
5. How can an automated testing pipeline utilize `outputs/metrics.txt` to prevent model regression?

## References

- [main.py lines 72-79](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML%20Beginners/projects/07_car_price/main.py#L72-L79)
- [Python Official Documentation - Reading and Writing Files](https://docs.python.org/3/tutorial/inputoutput.html#reading-and-writing-files)
- [Pathlib Documentation - Filesystem Operations](https://docs.python.org/3/library/pathlib.html)
