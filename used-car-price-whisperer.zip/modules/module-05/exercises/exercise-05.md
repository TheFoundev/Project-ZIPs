# Module 5 Exercises: Evaluation, Metrics & Visualization

## Exercise 5.1: Computing and Comparing MAE and RMSE (15 min)
**Objective:** Calculate and contrast Mean Absolute Error (MAE) and Root Mean Squared Error (RMSE) on model test predictions.  
**Problem Statement:** Your pricing team wants to understand the difference between typical dollar error (MAE) and penalty-weighted error (RMSE) on our 12 test vehicles.

**Requirements:**
1. Load `data/used_cars.csv`, perform the train/test split matching `main.py` (`test_size=0.25`, `random_state=42`), and train the `LinearRegression` model.
2. Generate predictions on `X_test`.
3. Compute the MAE using scikit-learn's `mean_absolute_error(y_test, predictions)`.
4. Compute the Root Mean Squared Error (RMSE) using `np.sqrt(np.mean((y_test - predictions) ** 2))`.
5. Write a short explanation comparing the two numbers. Why is RMSE typically higher than or equal to MAE?

**Constraints:** Use Python 3 and scikit-learn. Match the exact split random state (`42`) used in `main.py`.

**Expected Behaviour:** A script executing successfully, printing MAE (~$906) and RMSE (~$1,120), accompanied by a concise explanatory summary.

**Acceptance Criteria:**
- [ ] Correctly reproduces the exact train/test split on `used_cars.csv`.
- [ ] Computes and prints MAE equal to approximately $905.97.
- [ ] Computes and prints RMSE correctly.
- [ ] Explains why squaring residuals in RMSE gives disproportionate weight to larger prediction errors.

**Hints:**
- Recall that MAE treats all errors linearly, whereas RMSE squares differences before taking the square root.
- Scikit-learn also provides `mean_squared_error` with `squared=False` in older versions or `root_mean_squared_error` in newer versions.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 5.2: Advanced Actual-vs-Predicted Plotting with Residuals (20 min)
**Objective:** Enhance the actual-vs-predicted diagnostic plot by drawing residual lines connecting each point to the perfect prediction diagonal.  
**Problem Statement:** While `actual_vs_predicted.png` shows the scatter of test points, visual inspection is enhanced if students can see vertical lines depicting each vehicle's residual error.

**Requirements:**
1. Extract `y_test` and `predictions` using the trained multiple regression model.
2. Initialize a square figure (`figsize=(6, 6)`) with `matplotlib.use("Agg")`.
3. Plot the scatter points (`ax.scatter`) and the 45-degree diagonal reference line (`ax.plot([low, high], [low, high])`).
4. Loop through each pair of `(actual, predicted)` and draw a vertical gray line (`alpha=0.4`) from `(actual, actual)` to `(actual, predicted)` to visualize the residual.
5. Save the resulting plot to `outputs/actual_vs_predicted_residuals.png`.

**Constraints:** Follow headless matplotlib practices (`matplotlib.use("Agg")` and `plt.close(fig)`).

**Expected Behaviour:** A saved image `outputs/actual_vs_predicted_residuals.png` clearly displaying the 12 test points, the diagonal line, and vertical drop lines illustrating prediction errors.

**Acceptance Criteria:**
- [ ] Generates a square plot with labeled axes and grid.
- [ ] Draws the red dashed diagonal reference line.
- [ ] Accurately connects each test point to the diagonal using residual error lines.
- [ ] Saves the figure cleanly to disk without displaying a GUI window.

**Hints:**
- Use `ax.vlines(x=actual, ymin=min(actual, pred), ymax=max(actual, pred), color="gray", linestyle=":")`.
- Remember to call `plt.close(fig)` after saving.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 20 minutes  

---

## Exercise 5.3: Automated Metrics Verification and Quality Gate (15 min)
**Objective:** Build a Python verification script that parses `outputs/metrics.txt` and enforces production quality thresholds.  
**Problem Statement:** In automated CI/CD pipelines, a model must not be deployed to production if its performance degrades below established quality standards. You must write an automated verification test.

**Requirements:**
1. Open and parse `outputs/metrics.txt` into a Python dictionary.
2. Extract the values for `MAE`, `R2`, `age coefficient`, and `km coefficient`.
3. Implement automated assertions that verify:
   - $R^2 \ge 0.90$
   - $\text{MAE} \le \$1,000$
   - $\text{age coefficient} < 0$ (confirming negative depreciation over time)
   - $\text{km coefficient} < 0$ (confirming negative depreciation over distance)
4. Print a formatted "QUALITY AUDIT PASSED" report if all checks succeed, or raise an informative error if any check fails.

**Constraints:** Parse the actual file produced by `main.py` using standard Python string operations.

**Expected Behaviour:** The verification script executes, prints validation results for each criterion, and announces successful pipeline qualification.

**Acceptance Criteria:**
- [ ] Successfully parses `outputs/metrics.txt` without runtime errors.
- [ ] Verifies all 4 model criteria against specified numerical thresholds.
- [ ] Handles float conversion cleanly.
- [ ] Emits clear status messages for each validation gate.

**Hints:**
- Split each line using `.split(": ")`.
- Convert values to `float()` before numeric comparisons.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  
