# Module 1 Exercises: Problem Framing & Dataset Inspection

## Exercise 1.1: Supervised Regression Problem Formulation (15 min)
**Objective:** Distinguish supervised multiple regression from classification and single-variable models.  
**Problem Statement:** You are advising an automotive start-up that wants to automate its car trade-in valuation. You must explain why predicting car prices from age and mileage is a supervised multiple linear regression problem rather than classification or simple regression.

**Requirements:**
1. Define supervised learning and identify the labeled components ($X$ and $y$) in `used_cars.csv`.
2. Define regression and explain why vehicle price prediction is a continuous regression problem rather than classification.
3. Define multiple regression and explain why two features (`age_years` and `kilometers`) are necessary instead of relying on only one.
4. Formulate the general mathematical equation representing this model ($y = \beta_0 + \beta_1 x_1 + \beta_2 x_2$).

**Constraints:** Base your explanation strictly on the architecture and dataset in `07_car_price`. Do not introduce unrelated external concepts.

**Expected Behaviour:** A written technical briefing (3–5 paragraphs) clearly addressing each requirement with correct terminology.

**Acceptance Criteria:**
- [ ] Supervised learning is correctly defined using labeled training data.
- [ ] Regression is clearly distinguished from classification based on target continuity.
- [ ] Multiple regression is properly contrasted with simple single-variable regression.
- [ ] The two features and one target are explicitly named.
- [ ] The general linear equation with two feature terms is written out.

**Hints:**
- Think about what kind of number `price_usd` is (discrete category vs. continuous dollar amount).
- Recall what happens to pricing accuracy when an analyst ignores either odometer mileage or vehicle age.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 1.2: Exploring `used_cars.csv` Structure (15 min)
**Objective:** Load, inspect, and verify the structural characteristics of `data/used_cars.csv`.  
**Problem Statement:** Before feeding any data into a machine learning algorithm, you must verify its shape, column headers, and data integrity.

**Requirements:**
1. Write a Python script or interactive session to load `data/used_cars.csv` using pandas.
2. Verify that the dataset contains exactly 45 rows and 3 columns.
3. Print the data types of all three columns (`age_years`, `kilometers`, `price_usd`).
4. Identify the minimum, median, and maximum values for each of the three columns.
5. Check whether any missing or null values exist in the dataset.

**Constraints:** Use pandas and the actual CSV file located at `beginner-projects-main/AI-ML Beginners/projects/07_car_price/data/used_cars.csv`.

**Expected Behaviour:** A Python script executing successfully and printing the shape, column summaries, and confirming zero null values.

**Acceptance Criteria:**
- [ ] Correctly loads the CSV file using `pd.read_csv()`.
- [ ] Confirms the shape is exactly `(45, 3)`.
- [ ] Lists the three column names and their integer types (`int64`).
- [ ] Reports accurate ranges (Age: 0 to 12; Kilometers: 8,400 to 148,300; Price: $1,500 to $22,865).
- [ ] Verifies that `df.isnull().sum()` produces 0 for all columns.

**Hints:**
- Use `df.shape` to check row and column counts.
- Use `df.describe()` to quickly inspect percentiles and min/max values.
- Use `df.isnull().sum()` to check for missing entries.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 1.3: Feature Matrix vs. Target Vector Separation (15 min)
**Objective:** Correctly construct the 2D feature matrix $X$ and 1D target vector $y$ in pandas.  
**Problem Statement:** In scikit-learn, passing improperly shaped data causes immediate runtime errors. You must separate `used_cars.csv` into features and target while preserving required dimensionality.

**Requirements:**
1. Load `used_cars.csv` into a DataFrame `df`.
2. Extract the features into variable `X` using double brackets: `df[["age_years", "kilometers"]]`.
3. Extract the target into variable `y` using single brackets: `df["price_usd"]`.
4. Inspect and print the `.shape` and `type()` of both `X` and `y`.
5. Explain in writing why `X` must be 2-dimensional while `y` is 1-dimensional.

**Constraints:** Write clean Python code that adheres to PEP 8 standards.

**Expected Behaviour:** Code prints `X shape: (45, 2)`, `X type: <class 'pandas.core.frame.DataFrame'>`, `y shape: (45,)`, and `y type: <class 'pandas.core.series.Series'>`.

**Acceptance Criteria:**
- [ ] `X` contains exactly the two feature columns.
- [ ] `y` contains exactly the target column.
- [ ] `X.shape` is verified as `(45, 2)`.
- [ ] `y.shape` is verified as `(45,)`.
- [ ] Clear written explanation of scikit-learn's requirement for 2D feature matrices `(n_samples, n_features)`.

**Hints:**
- Single brackets `df["column"]` extract a 1D Series.
- Double brackets `df[["col1", "col2"]]` extract a 2D DataFrame.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 1.4: Benchmark Instance Prediction Verification (15 min)
**Objective:** Understand how benchmark predictions are constructed and manually verify pricing logic.  
**Problem Statement:** The project tests its trained model against a benchmark vehicle: a 5-year-old car with 60,000 km. You will analyze how this instance is structured and calculate its predicted value using given baseline weights.

**Requirements:**
1. Construct a pandas DataFrame representing the benchmark vehicle with the exact column names expected by `main.py`.
2. Given the model parameters:
   - Intercept $\beta_0 = 26,818$
   - Age weight $\beta_1 = -1,242$
   - Mileage weight $\beta_2 = -0.0922$
3. Compute the predicted price manually using arithmetic in Python.
4. Calculate what the predicted price would be if the car were 8 years old with 100,000 km instead.
5. Discuss whether a negative predicted price is theoretically possible in linear regression and how an engineer should handle such edge cases.

**Constraints:** Use the provided model parameter values to 2 decimal places.

**Expected Behaviour:** A Python script creating the benchmark DataFrame, printing manual calculations, and answering the conceptual edge-case question.

**Acceptance Criteria:**
- [ ] Benchmark DataFrame is created with `{"age_years": 5, "kilometers": 60_000}`.
- [ ] Manual calculation for the 5-year-old car yields approximately $15,077.
- [ ] Manual calculation for the 8-year-old, 100,000 km car yields approximately $7,662.
- [ ] Discussion correctly identifies that unbounded linear equations can predict negative prices for extreme inputs and suggests clipping at zero (`max(0, price)`).

**Hints:**
- Plug values into: $\text{price} = \beta_0 + (\beta_1 \times \text{age}) + (\beta_2 \times \text{km})$.
- Remember that $\beta_1$ and $\beta_2$ are negative numbers, so adding them decreases the price.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  
