# Lesson 01: The Used Car Valuation Problem

**Lesson ID:** lesson-01  
**Module:** module-01  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- State the core business and economic problem that "The Used Car Price Whisperer" solves.
- Explain why vehicle valuation is challenging for both buyers and sellers in the used automobile market.
- Define the concept of asset depreciation as it applies to motor vehicles over time and distance driven.
- Identify why static rule-of-thumb pricing models fail in comparison to empirical machine learning models.
- Explain the real-world value of predicting fair vehicle market value from observable attributes.

## Prerequisites

Basic familiarity with Python variables and everyday commerce concepts (buying, selling, and vehicle depreciation).

## Concept Explanation

### The Used Car Market Challenge
Buying or selling a pre-owned vehicle is one of the most common and financially significant transactions individuals and dealerships undertake. However, determining a fair transaction price is notoriously difficult. Unlike brand-new vehicles straight from the assembly plant—which have standardized Manufacturer's Suggested Retail Prices (MSRP)—every single used car possesses an individualized history that alters its economic worth.

Two primary drivers degrade a car's monetary value over its lifespan:
1. **Chronological Age (Time Decay):** As years pass, components experience environmental wear, rubber seals degrade, styling becomes outdated, and modern safety features appear in newer models, pushing older inventory down in desirability.
2. **Odometer Reading (Operational Wear):** Every kilometer driven represents mechanical friction on the drivetrain, suspension wear, cylinder combustion cycles, and impending maintenance requirements (such as timing belts, brake rotors, and transmission fluids).

When an automobile dealership accepts a trade-in or when an everyday consumer browses online classified ads, both parties ask the exact same question: **"Given how old this car is and how far it has been driven, what is its fair market price in dollars?"**

### The Limitations of Rules of Thumb
Historically, dealerships relied on crude heuristic rules, such as:
- "Deduct $1,000 for every year since the manufacturing date."
- "Deduct $0.10 for every kilometer displayed on the dashboard odometer."

While simple, such arbitrary mental formulas fail because they do not reflect actual empirical market transactions. Does a car lose the exact same dollar amount going from year 1 to year 2 as it does going from year 10 to year 11? How does high mileage interact with older versus newer vehicles? 

Machine learning offers a principled, data-driven approach: rather than guessing fixed depreciation rules, we collect records of actual historic transactions and train a statistical model to extract the true underlying mathematical relationship between vehicle attributes and sale prices.

### The Role of "The Used Car Price Whisperer"
The project titled **"The Used Car Price Whisperer"** models this exact economic problem. By ingesting historical sales records containing vehicle age in years, total kilometers driven, and final realized sales prices in US dollars, the system learns an optimal pricing formula. Once calibrated, this automated "whisperer" acts as an impartial appraiser, capable of estimating fair market prices for any vehicle specification presented to it.

## Relevant Code (from main.py, lines 1-8)

```python
"""Project 07: The Used Car Price Whisperer (multiple linear regression).

Run:
    python main.py

Two clues (age and kilometres) are combined into one price estimate.  The
script prints the model's weights so you can see which clue matters more.
"""
```

### Code explanation
- **Project Header & Algorithm**: The script explicitly introduces the task as "The Used Car Price Whisperer" and identifies the core learning algorithm as **multiple linear regression**.
- **Execution Command**: Lines 3–4 explain that running the pipeline requires simply executing `python main.py` in a terminal environment.
- **Two Clues (Features)**: Lines 6–7 refer to vehicle age and kilometers driven as "two clues." In machine learning terminology, clues are known as **features** or **independent variables**.
- **Unified Price Estimate**: The model synthesizes both clues simultaneously into a single, cohesive price prediction, avoiding fragmented single-variable guesses.
- **Model Weights (Coefficients)**: Line 7 notes that the script prints the model's learned weights. These weights quantify precisely how much value is eroded per year of age and per kilometer traveled.

## Worked Example

**Problem:**  
A prospective car buyer finds a 4-year-old compact sedan on an online marketplace with 50,000 km recorded on the odometer. The seller has listed the vehicle for $18,500. A friend suggests a simple rule-of-thumb: *"Start with a new car baseline of $27,000, subtract $1,300 per year, and subtract $0.10 for every kilometer."* How does this manual heuristic compare to the expected price?

**Calculation using the heuristic:**
```text
Baseline starting price:        $27,000
Age deduction (4 × $1,300):    - $5,200
Mileage deduction (50,000 × $0.10): - $5,000

Estimated heuristic price = $27,000 - $5,200 - $5,000
                          = $16,800
```

**Analysis:**  
According to the heuristic, a fair valuation is approximately $16,800. Since the seller is demanding $18,500, the car appears overpriced by $1,700 according to that formula. However, without grounding those deductions in real data, neither the buyer nor the seller knows whether $1,300/year or $0.10/km reflects reality. In the upcoming lessons, we will inspect the actual dataset and use machine learning to discover the genuine market weights directly from historical sales.

## Step-by-Step Student Instructions

1. **Review the Market Scenario:** Consider a vehicle you or your family has owned. Think about which factor seemed to decrease its resale value faster: the calendar year or long road trips?
2. **Examine the Source Script:** Open `/home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price/main.py` in your code editor and read lines 1 to 8.
3. **Identify the Core Entities:** Note down the target you wish to predict (the selling price in USD) and the two primary input signals provided to the model (chronological age in years and cumulative distance in kilometers).
4. **Distinguish Heuristic vs. Data-Driven Estimation:** In your notes, write down one key reason why estimating prices with machine learning on actual sales data is superior to using static rules of thumb.

## Expected Output or Observable Behaviour

When you inspect `main.py`, you should observe:
- A clear docstring stating that two clues (age and kilometers) are combined to produce a price estimate.
- A script design intended to be executed from the terminal with a single command (`python main.py`).
- Clear indication that the script will compute and display learned weights revealing the quantitative impact of each clue.

## Practical Exercises

- **Exercise 1.1:** Suppose Car A is 2 years old with 80,000 km, while Car B is 6 years old with 20,000 km. Without running a model, list two distinct factors that make comparing their values difficult using intuition alone.
- **Exercise 1.2:** Explain why an automotive insurance company or a bank offering auto loans would be interested in an automated car price prediction model.
- **Exercise 1.3:** If an economic recession occurs and general used car prices drop across the entire country, what would need to happen to our machine learning model?

## Common Mistakes and Debugging

| Mistake | Why it happens | How to avoid or fix |
|---|---|---|
| Assuming price depends on only one variable | Inexperienced analysts often look only at mileage or only at age. | Always consider multiple contributing factors simultaneously; age and mileage both erode value independently. |
| Treating car valuation as a classification problem | Confusing category assignment (e.g., "cheap vs. expensive") with price prediction. | Recognize that car prices are dollar amounts on a continuous numerical scale, requiring regression techniques. |
| Over-relying on arbitrary mental formulas | Relying on unverified "rules of thumb" passed down by word of mouth. | Use statistical learning algorithms fitted against verified empirical transaction records. |

## Best Practices and Security Considerations

- **Ground Assumptions in Data:** Never assume fixed depreciation rates without validating them against historical transactional evidence.
- **Consider Market Context:** Understand that used car prices fluctuate with geographic region, brand reputation, macroeconomic factors, and supply chain disruptions.
- **Data Privacy & Ethics:** Ensure datasets of car transactions do not contain personally identifiable information (PII) such as previous owner names, home addresses, or license plate numbers. The dataset used here contains purely anonymized vehicular specifications.

## Summary

In Lesson 01, we explored the used car pricing challenge. Vehicle valuation is driven by dual forces of depreciation: chronological aging (time decay) and cumulative mileage (mechanical wear). Because static heuristics fail to capture true market dynamics, machine learning provides an objective, data-backed approach. The "Used Car Price Whisperer" project addresses this challenge by applying multiple linear regression to learn the true weights of age and distance from historical sales records.

## Knowledge-check Questions

1. What are the two primary vehicle attributes ("clues") that the Used Car Price Whisperer uses to estimate a car's price?
2. Why is vehicle depreciation considered a two-dimensional problem rather than a one-dimensional problem?
3. How does a machine learning approach to car valuation differ fundamentally from a static dealer rule of thumb?
4. What is the unit of measurement for the target variable that this project predicts?
5. Why is predicting a used car's price categorized as a regression task instead of classification?

## References

- [main.py lines 1-8](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price/main.py#L1-L8)
- [Scikit-Learn Regression Overview](https://scikit-learn.org/stable/supervised_learning.html#polynomial-regression-extending-linear-models-with-basis-functions)
- [Introduction to Vehicle Depreciation Models (Investopedia)](https://www.investopedia.com/terms/d/depreciation.asp)
