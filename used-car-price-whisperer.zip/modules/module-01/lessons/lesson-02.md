# Lesson 02: Supervised Multiple Regression Fundamentals

**Lesson ID:** lesson-02  
**Module:** module-01  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Define supervised learning and explain why "The Used Car Price Whisperer" belongs to this category.
- Differentiate clearly between regression tasks and classification tasks.
- Explain the key theoretical and architectural differences between simple linear regression and multiple linear regression.
- Articulate why multiple regression is necessary when an outcome depends on two or more distinct inputs.
- Understand the concept of labeled training examples in the context of vehicular datasets.

## Prerequisites

Completion of [Lesson 01](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-01/lessons/lesson-01.md). Familiarity with basic mathematical functions ($y = f(x)$).

## Concept Explanation

### What is Supervised Learning?
Machine learning is broadly organized into paradigms based on the nature of the learning feedback. In **supervised learning**, an algorithm learns from a dataset composed of **labeled examples**. Each observation in the dataset contains both:
1. One or more **features** (inputs, denoted mathematically as $X$), representing the measurable characteristics of an item.
2. A known **target** or label (output, denoted mathematically as $y$), representing the ground-truth outcome.

During training, the supervised learning algorithm is provided both $X$ and $y$. Its task is to detect the mapping function $f$ such that:
$$\hat{y} = f(X)$$
where $\hat{y}$ (pronounced "y-hat") represents the model's estimate. Once the model has been fitted to historical examples, it can be deployed to predict the unknown target for entirely new, unseen observations where only $X$ is available.

In our car pricing project, the labeled examples consist of historic car transactions where both the vehicle's attributes (age and kilometers) and the actual selling price are documented.

### Regression vs. Classification
Supervised learning tasks are divided based on the data type of the target variable $y$:

| Attribute | Regression | Classification |
|---|---|---|
| **Target Data Type** | Continuous numerical values | Discrete categorical labels |
| **Output Space** | Real numbers ($\mathbb{R}$), infinite possible values | Finite set of classes or categories |
| **Example Questions** | "What is the price of this car in dollars?" | "Is this car a sedan, SUV, or truck?" |
| **Typical Algorithms** | Linear Regression, Ridge, Decision Tree Regressor | Logistic Regression, Decision Tree Classifier, SVM |
| **Evaluation Metrics** | Mean Absolute Error (MAE), Mean Squared Error (MSE), $R^2$ | Accuracy, Precision, Recall, F1-Score |

Because vehicle selling prices are continuous monetary values (e.g., $10,063, $22,783, or $15,077), this project is strictly a **regression problem**.

### Simple vs. Multiple Linear Regression
In introductory data science, students frequently encounter **simple linear regression**. A simple linear regression model maps a single input feature $x$ to an output $y$ via the equation of a 2D line:
$$y = \beta_0 + \beta_1 x$$
For instance, in the Lemonade Stand Fortune Teller project, daily temperature was the sole feature used to predict cups sold.

However, real-world phenomena rarely depend on only one variable. A car's price is not solely determined by its age; a 5-year-old car kept in a garage with only 10,000 km will sell for significantly more than another 5-year-old car driven 250,000 km as a commercial taxi. If an algorithm only looks at age, it is blind to mileage. If it only looks at mileage, it is blind to age.

**Multiple linear regression** solves this by expanding the model to accommodate two or more features simultaneously. For two features ($x_1$ and $x_2$), the model takes the mathematical form:
$$y = \beta_0 + \beta_1 x_1 + \beta_2 x_2$$
Where:
- $y$ is the predicted target (`price_usd`).
- $\beta_0$ is the intercept (the baseline price when all features equal zero).
- $\beta_1$ is the weight (coefficient) associated with the first feature ($x_1$, `age_years`).
- $\beta_2$ is the weight (coefficient) associated with the second feature ($x_2$, `kilometers`).

Instead of fitting a 1-dimensional line through a 2D coordinate plane, multiple linear regression with two features fits a **2-dimensional flat plane** through a 3-dimensional coordinate space!

## Relevant Code (from main.py, lines 27-37)

```python
def main() -> None:
    df = pd.read_csv(DATA / "used_cars.csv")
    X = df[["age_years", "kilometers"]]
    y = df["price_usd"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42
    )

    model = LinearRegression()
    model.fit(X_train, y_train)
```

### Code explanation
- `df[["age_years", "kilometers"]]`: We select two columns into `X`. Because there are multiple columns enclosed within inner brackets, `X` becomes a 2-dimensional pandas DataFrame.
- `df["price_usd"]`: We select a single column into `y`, creating a 1-dimensional pandas Series.
- `LinearRegression()`: The scikit-learn `LinearRegression` estimator automatically detects whether to run simple or multiple regression based on the number of columns in the feature matrix $X$. Because $X$ contains two columns, it automatically instantiates a multiple linear regression model!
- `model.fit(X_train, y_train)`: The optimizer solves the ordinary least squares equations across both feature dimensions simultaneously.

## Worked Example

**Problem:**  
Suppose a multiple linear regression model has learned the following parameters:
- Baseline intercept $\beta_0 = \$26,800$
- Age coefficient $\beta_1 = -\$1,240$ per year
- Distance coefficient $\beta_2 = -\$0.09$ per km

Calculate the predicted price for:
1. Car 1: 3 years old, 40,000 km
2. Car 2: 7 years old, 40,000 km (same mileage, 4 years older)
3. Car 3: 3 years old, 90,000 km (same age as Car 1, 50,000 km more)

**Step-by-step Solution:**

**Car 1:**
$$\text{Price} = 26,800 + (-1,240 \times 3) + (-0.09 \times 40,000)$$
$$\text{Price} = 26,800 - 3,720 - 3,600 = \$19,480$$

**Car 2 (Age effect isolated):**
$$\text{Price} = 26,800 + (-1,240 \times 7) + (-0.09 \times 40,000)$$
$$\text{Price} = 26,800 - 8,680 - 3,600 = \$14,520$$
*Notice: Car 2 is worth exactly $4 \times \$1,240 = \$4,960$ less than Car 1 due entirely to the 4 additional years.*

**Car 3 (Mileage effect isolated):**
$$\text{Price} = 26,800 + (-1,240 \times 3) + (-0.09 \times 90,000)$$
$$\text{Price} = 26,800 - 3,720 - 8,100 = \$14,980$$
*Notice: Car 3 is worth exactly $50,000 \times \$0.09 = \$4,500$ less than Car 1 due entirely to the extra 50,000 km.*

This illustrates the power of multiple linear regression: each coefficient isolates the specific marginal impact of its corresponding feature while holding all other features constant!

## Step-by-Step Student Instructions

1. **Verify the Problem Formulation:** Confirm in your mind why car pricing cannot be solved with binary classification (e.g., "Good / Bad"). It requires continuous value estimation.
2. **Review Dimensionality:** In simple linear regression, input $X$ has dimension $(N, 1)$. In this multiple linear regression project, input $X$ has dimension $(N, 2)$.
3. **Inspect the Formula:** Write down the formula $y = \beta_0 + \beta_1 x_1 + \beta_2 x_2$ on a piece of scratch paper and label each symbol with its corresponding project column name.
4. **Contrast Independent Contributions:** Note how multiple regression allows each feature to have its own dedicated weight ($\beta_1$ and $\beta_2$) with different units and magnitudes.

## Expected Output or Observable Behaviour

When working through the code in `main.py`, you will observe that scikit-learn seamlessly ingests a two-column feature matrix `X` without requiring any change in the model class name; `LinearRegression` handles both 1-feature and n-feature problems through the exact same API.

## Practical Exercises

- **Exercise 2.1:** If you add a third feature, such as `engine_size_liters`, write out the mathematical equation for the resulting multiple linear regression model.
- **Exercise 2.2:** Why would a classification algorithm like `LogisticRegression` fail if you passed continuous dollar prices as the target variable without preprocessing?
- **Exercise 2.3:** In your own words, explain what is meant by "holding other features constant" when interpreting the weight $\beta_1$ of age.

## Common Mistakes and Debugging

| Mistake | Why it happens | How to avoid or fix |
|---|---|---|
| Passing $X$ as a 1D Series | Using single brackets `df["age_years"]` instead of double brackets `df[["age_years", "kilometers"]]`. | Always supply a 2D structure (DataFrame or 2D NumPy array) for the feature matrix $X$. |
| Confusing the number of targets with the number of features | Believing multiple regression means predicting multiple targets ($y_1, y_2$). | Multiple regression predicts **one single target** from **multiple features**. Predicting multiple targets is called multi-output regression. |
| Forgetting negative signs on depreciation | Expecting coefficients to be positive because prices are positive numbers. | Coefficients reflect changes; because older/higher-mileage cars lose value, their weights must be negative. |

## Best Practices and Security Considerations

- **Consistent Units:** Always verify the units of measurement for each feature (e.g., kilometers vs. miles; full years vs. months). Inconsistent units will distort coefficient interpretation.
- **Dimensionality Verification:** Always check `X.shape` before calling `.fit()` to confirm the sample count and feature count match your intentions.
- **Reproducibility:** When training supervised models, always set a random seed when splitting data to ensure consistent, verifiable results across team members.

## Summary

Supervised learning requires labeled training examples with known inputs ($X$) and outputs ($y$). In "The Used Car Price Whisperer", we predict a continuous numerical value (`price_usd`), classifying this task as regression. While simple regression uses a single feature, multiple linear regression combines multiple features ($x_1 = \text{age}$, $x_2 = \text{kilometers}$) into a unified linear equation. Each feature receives its own coefficient, quantifying its specific, isolated contribution to vehicle depreciation.

## Knowledge-check Questions

1. What makes a machine learning problem "supervised"?
2. What is the fundamental difference between regression and classification?
3. How does the equation for multiple linear regression with two features differ from simple linear regression?
4. What geometric shape represents the prediction surface of a multiple linear regression model with two features?
5. Why are the coefficients for age and kilometers expected to have negative values?

## References

- [main.py lines 27-37](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price/main.py#L27-L37)
- [Scikit-learn Linear Regression User Guide](https://scikit-learn.org/stable/modules/linear_model.html#ordinary-least-squares)
- [An Introduction to Statistical Learning (James, Witten, Hastie, Tibshirani)](https://www.statlearning.com/)
