# Lesson 03: The Used Car Dataset Overview

**Lesson ID:** lesson-03  
**Module:** module-01  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Identify the exact file path, format, and structure of `data/used_cars.csv`.
- Describe each of the three columns in the dataset: `age_years`, `kilometers`, and `price_usd`.
- State the total number of records (45 rows) and identify feature columns versus the target column.
- Summarize the distribution ranges (minimum, median, maximum) for each variable in the dataset.
- Explain the role of clean, tabular data in building reliable machine learning pipelines.

## Prerequisites

Completion of [Lesson 01](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-01/lessons/lesson-01.md) and [Lesson 02](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-01/lessons/lesson-02.md). Basic understanding of tabular CSV files.

## Concept Explanation

### Locating the Dataset
In modern machine learning workflows, data ingestion is the foundational first step. The dataset powering this project is stored as a Comma-Separated Values (CSV) file located at:
`data/used_cars.csv`

Relative to the project root directory (`07_car_price`), this file contains verified, tabular sales records of used motor vehicles.

### Column Specifications
The CSV file consists of exactly 3 columns across 45 individual vehicle records (plus 1 header row):

| Column Name | Data Type | Machine Learning Role | Unit | Description |
|---|---|---|---|---|
| `age_years` | Integer (`int64`) | Feature (Input $x_1$) | Years | Chronological age of the car since manufacturing |
| `kilometers` | Integer (`int64`) | Feature (Input $x_2$) | Kilometers (km) | Cumulative odometer reading showing total distance traveled |
| `price_usd` | Integer (`int64`) | Target (Output $y$) | US Dollars ($) | Actual finalized selling transaction price |

### Statistical Profiles of the Variables
Let us inspect the statistical distributions across all 45 vehicles in `used_cars.csv`:

1. **`age_years` (Vehicle Age):**
   - **Minimum:** 0 years (virtually brand-new vehicle)
   - **25th Percentile:** 3.0 years
   - **Median (50th Percentile):** 8.0 years
   - **75th Percentile:** 9.0 years
   - **Maximum:** 12.0 years
   - **Mean:** Approximately 6.96 years
   - *Observation:* The dataset spans a wide vehicle age spectrum, from current-year models up to 12-year-old aging vehicles.

2. **`kilometers` (Odometer Reading):**
   - **Minimum:** 8,400 km
   - **25th Percentile:** 44,500 km
   - **Median (50th Percentile):** 93,200 km
   - **75th Percentile:** 123,000 km
   - **Maximum:** 148,300 km
   - **Mean:** Approximately 85,264 km
   - *Observation:* The mileage figures range from low-mileage commuter cars (~8,400 km) to heavily utilized long-distance vehicles (~148,300 km).

3. **`price_usd` (Transaction Price):**
   - **Minimum:** $1,500
   - **25th Percentile:** $5,347
   - **Median (50th Percentile):** $10,063
   - **75th Percentile:** $14,012
   - **Maximum:** $22,865
   - **Mean:** Approximately $10,418
   - *Observation:* The lowest priced car in the dataset sold for $1,500 (an older, high-mileage vehicle), while the highest priced car commanded $22,865 (a near-new, low-mileage vehicle).

### Why These Specific Columns?
In practical automotive appraisal, hundreds of attributes could theoretically be recorded (paint color, tire brand, stereo wattage, seat fabric). However, economic research consistently confirms that **over 80% to 90% of vehicle depreciation variance** is accounted for by just two core variables: chronological age and cumulative mileage. By focusing on these two primary drivers, our model achieves high predictive power while avoiding excessive complexity and overfitting.

## Relevant Code (from main.py, lines 28-30)

```python
def main() -> None:
    df = pd.read_csv(DATA / "used_cars.csv")
    X = df[["age_years", "kilometers"]]
    y = df["price_usd"]
```

### Code explanation
- `df = pd.read_csv(...)`: The pandas library reads the CSV file into a DataFrame table named `df`.
- `X = df[["age_years", "kilometers"]]`: We slice out the two predictive feature columns into a 2D DataFrame named `X`. Notice the double square brackets `[[ ... ]]`.
- `y = df["price_usd"]`: We slice out the single target column into a 1D Series named `y`. Notice the single square brackets `[ ... ]`.

## Worked Example

**Problem:**  
Examine the first 5 rows of `data/used_cars.csv` shown below and identify which car is likely to have the highest price and which is likely to have the lowest price, based purely on their age and mileage.

```text
Row 0: age_years=5,  kilometers=105,100, price_usd=10,063
Row 1: age_years=4,  kilometers=27,800,  price_usd=22,783
Row 2: age_years=9,  kilometers=136,600, price_usd=2,784
Row 3: age_years=10, kilometers=78,200,  price_usd=4,871
Row 4: age_years=6,  kilometers=106,600, price_usd=10,202
```

**Step-by-step Analysis:**
1. **Evaluate Row 1:** Age is only 4 years, and mileage is very low at 27,800 km. Both factors favor high valuation. Indeed, its price is **$22,783**, the highest in this sample.
2. **Evaluate Row 2:** Age is 9 years (very old), and mileage is very high at 136,600 km. Both factors heavily degrade value. Indeed, its price is **$2,784**, the lowest in this sample.
3. **Compare Row 0 and Row 4:**
   - Row 0: 5 years old, 105,100 km -> Price = $10,063
   - Row 4: 6 years old, 106,600 km -> Price = $10,202
   Both cars have almost identical mileage (~105,000–106,000 km) and very close ages (5 vs 6 years), and their resulting prices are nearly identical (~$10,100).
   
This consistency demonstrates that the dataset possesses coherent, orderly relationships suitable for regression modeling.

## Step-by-Step Student Instructions

1. **Locate the CSV File:** Navigate to the data folder at `/home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price/data/`.
2. **Open and Inspect the File:** Use a terminal command such as `head -n 10 used_cars.csv` or open it directly in your editor.
3. **Count the Columns and Rows:** Confirm the header row has exactly 3 column titles: `age_years`, `kilometers`, `price_usd`. Confirm there are 45 data rows.
4. **Identify the Data Types:** Notice that all values are numeric integers without currency symbols, commas, or string units.
5. **Formulate the Modeling Target:** Confirm that `price_usd` is the dependent variable we wish to forecast.

## Expected Output or Observable Behaviour

Viewing the first few lines of the CSV file in a terminal yields:
```csv
age_years,kilometers,price_usd
5,105100,10063
4,27800,22783
9,136600,2784
10,78200,4871
6,106600,10202
```

Each row represents an independent vehicle sale record with clean numeric entries.

## Practical Exercises

- **Exercise 3.1:** What is the average age of the cars in `used_cars.csv`? Why is the mean age (~6.96 years) slightly lower than the median age (8.0 years)?
- **Exercise 3.2:** If a row had a price recorded as `"$12,500"` with a dollar sign and comma, why would `pandas.read_csv()` treat that column as an `object` (string) instead of a numeric type, and how would that affect scikit-learn?
- **Exercise 3.3:** Why is odometer reading recorded in kilometers rather than miles in this dataset, and does the choice of distance unit affect the model's predictive ability?

## Common Mistakes and Debugging

| Mistake | Why it happens | How to avoid or fix |
|---|---|---|
| Including `price_usd` in feature matrix `X` | Accidentally writing `df[["age_years", "kilometers", "price_usd"]]` for $X$. | Never include the target variable in the input feature matrix. Doing so causes "data leakage," trivializing training and destroying real predictive utility. |
| Expecting header row to count as data | Counting 46 lines in the text file and reporting 46 samples. | Subtract 1 for the column header line; there are exactly 45 car records. |
| Misspelling column names | Writing `"km"` or `"age"` instead of `"kilometers"` and `"age_years"`. | Match column strings exactly as written in the CSV header. Python and pandas are case-sensitive and character-exact. |

## Best Practices and Security Considerations

- **Validate Tabular Integrity:** Always verify row counts and column names immediately upon loading any external CSV dataset.
- **Check for Missing Values:** In production systems, datasets often contain empty cells (`NaN`). Always run `df.isnull().sum()` to verify data completeness before feeding it into machine learning estimators.
- **Ensure Proper Numerical Types:** Verify that columns intended for regression are floating-point or integer types, never text strings.

## Summary

In Lesson 03, we conducted a structural and statistical survey of `data/used_cars.csv`. The dataset contains 45 vehicle transaction records characterized by two input features—`age_years` (ranging from 0 to 12 years) and `kilometers` (ranging from 8,400 to 148,300 km)—and one continuous output target: `price_usd` (ranging from $1,500 to $22,865). These clean numerical columns provide an ideal foundation for multiple regression modeling.

## Knowledge-check Questions

1. How many total vehicle records (excluding the header) are contained in `used_cars.csv`?
2. What are the names of the two feature columns and the one target column?
3. What is the minimum and maximum price recorded in the dataset?
4. What happens if the target column `price_usd` is accidentally included inside the feature matrix `X`?
5. Why are the data types of all three columns numeric integers rather than text strings?

## References

- [used_cars.csv](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price/data/used_cars.csv)
- [main.py lines 28-30](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price/main.py#L28-L30)
- [Pandas DataFrame read_csv Documentation](https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html)
