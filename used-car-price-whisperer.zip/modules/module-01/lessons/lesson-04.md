# Lesson 04: Project Workflow and Target Prediction

**Lesson ID:** lesson-04  
**Module:** module-01  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Trace the high-level end-to-end execution pipeline of "The Used Car Price Whisperer".
- Identify the benchmark vehicle used for prediction: a 5-year-old car with 60,000 km.
- Explain why a specific reference vehicle is chosen to test model performance and sanity-check results.
- Describe the expected terminal output, generated visual plot (`actual_vs_predicted.png`), and metric log file (`metrics.txt`).
- Articulate the role of each primary step: ingestion, partitioning, training, scoring, evaluation, and artifact generation.

## Prerequisites

Completion of [Lesson 01](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-01/lessons/lesson-01.md), [Lesson 02](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-01/lessons/lesson-02.md), and [Lesson 03](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-01/lessons/lesson-03.md).

## Concept Explanation

### The End-to-End Machine Learning Pipeline
A professional machine learning project is not just a random collection of mathematical formulas; it is a structured, repeatable software pipeline. The "Used Car Price Whisperer" script (`main.py`) executes seven distinct, sequential stages:

```
[1. Path & Backend Setup]
          │
          ▼
[2. Data Ingestion (used_cars.csv)]
          │
          ▼
[3. Feature/Target Separation (X, y)]
          │
          ▼
[4. Train/Test Partitioning (75/25 split)]
          │
          ▼
[5. Model Fitting (LinearRegression)]
          │
          ▼
[6. Evaluation (MAE & R² on Test Data)]
          │
          ▼
[7. Target Prediction & Artifact Export (PNG & TXT)]
```

1. **Path & Environment Setup:** Configure the non-interactive matplotlib `Agg` backend and resolve directory paths using Python's `pathlib.Path`.
2. **Data Ingestion:** Load 45 rows from `data/used_cars.csv` into a pandas DataFrame.
3. **Feature/Target Separation:** Define $X$ as the 2D DataFrame of `["age_years", "kilometers"]` and $y$ as the 1D Series of `price_usd`.
4. **Train/Test Partitioning:** Split the 45 records using a 75/25 ratio (33 training samples, 12 test samples) with `random_state=42`.
5. **Model Fitting:** Train the `LinearRegression` estimator on the 33 training samples to calculate intercept $\beta_0$ and weights $\beta_1, \beta_2$.
6. **Evaluation & Scoring:** Generate predictions for the 12 unseen test cars and compute Mean Absolute Error (MAE) and $R^2$ score.
7. **Prediction & Artifact Export:** Predict the value of a specific benchmark vehicle, save an actual-vs-predicted diagnostic plot, and export metrics to disk.

### The Benchmark Prediction Vehicle
To verify that a machine learning model behaves sanely in a real-world scenario, data scientists frequently select a realistic, representative benchmark test case. In `main.py`, line 45 creates this benchmark instance:
```python
example = pd.DataFrame([{"age_years": 5, "kilometers": 60_000}])
```

Why was a **5-year-old car with 60,000 km** chosen?
- **Market Typicality:** In the used car market, 5 years old is the typical age of a vehicle coming off a multi-year finance lease or second owner cycle.
- **Realistic Annual Mileage:** 60,000 km over 5 years corresponds to exactly 12,000 km per year, which is a textbook standard average commuter driving distance worldwide.
- **Interpolation Range:** In our dataset, age spans 0 to 12 years (median 8), and kilometers span 8,400 to 148,300 km (median 93,200). A 5-year-old car with 60,000 km sits comfortably inside the data distribution (interpolation), rather than far outside it (extrapolation).

When the trained model evaluates this car, it produces an estimated price of approximately **$15,077**.

### Artifacts and Output Files
When `main.py` completes, it produces two tangible file artifacts in the `outputs/` directory:
1. `outputs/actual_vs_predicted.png`: A high-resolution scatter plot displaying actual prices on the x-axis versus predicted prices on the y-axis for the test set, accompanied by a 45-degree dashed red line representing perfect prediction.
2. `outputs/metrics.txt`: A structured text file logging the model intercept, age coefficient, km coefficient, MAE, $R^2$, and benchmark prediction value.

## Relevant Code (from main.py, lines 45-57)

```python
    example = pd.DataFrame([{"age_years": 5, "kilometers": 60_000}])
    example_price = float(model.predict(example)[0])

    print("=" * 60)
    print("THE USED CAR PRICE WHISPERER")
    print("=" * 60)
    print(f"Equation: price = {intercept:,.0f} + ({age_weight:,.0f} x age) + ({km_weight:.2f} x km)")
    print(f"Each extra year is associated with about ${abs(age_weight):,.0f} less value.")
    print(f"Each extra 10,000 km is associated with about ${abs(km_weight) * 10_000:,.0f} less value.")
    print(f"Mean absolute error: ${mae:,.0f}")
    print(f"R-squared: {r2:.2f}")
    print(f"Prediction for a 5-year-old car with 60,000 km: ${example_price:,.0f}")
```

### Code explanation
- `example = pd.DataFrame([{"age_years": 5, "kilometers": 60_000}])`: Formats the new observation as a DataFrame with matching column headers so scikit-learn can validate feature names.
- `model.predict(example)[0]`: Generates the continuous price prediction and extracts the first element.
- `print(...)`: Emits a formatted executive summary displaying the learned equation, per-unit depreciation rates, performance metrics, and the benchmark prediction.

## Worked Example

**Problem:**  
Suppose our trained model has discovered the following parameters:
- $\text{Intercept} = \$26,818$
- $\text{Age Weight} = -\$1,242$
- $\text{Km Weight} = -\$0.0922$

Verify manually whether the prediction for a 5-year-old car with 60,000 km matches the script's output of $15,077.

**Step-by-step Calculation:**
1. Calculate age depreciation:
   $$5 \text{ years} \times (-\$1,241.53) = -\$6,207.65$$
2. Calculate mileage depreciation:
   $$60,000 \text{ km} \times (-\$0.092223) = -\$5,533.38$$
3. Combine with baseline intercept:
   $$\text{Price} = 26,817.96 - 6,207.65 - 5,533.38$$
   $$\text{Price} = 26,817.96 - 11,741.03 = \$15,076.93 \approx \$15,077$$

The manual calculation confirms the automated model output: a 5-year-old vehicle with 60,000 km is valued at approximately **$15,077**.

## Step-by-Step Student Instructions

1. **Review the Pipeline Flow:** In your notebook, sketch the 7 pipeline stages from data loading to artifact saving.
2. **Examine the Benchmark Instance:** Look at line 45 of `main.py`. Notice how Python dictionary syntax `{"age_years": 5, "kilometers": 60_000}` is wrapped in a list and passed to `pd.DataFrame()`.
3. **Trace the Output Formatting:** Notice how lines 51-56 use Python f-strings with `,` formatting flags (such as `{intercept:,.0f}`) to present large numbers with readable thousand separators.
4. **Identify Output Deliverables:** Check the `outputs/` folder to see where the plot and metrics file will be written when `main.py` is executed.

## Expected Output or Observable Behaviour

Executing `main.py` produces the following terminal output:
```text
============================================================
THE USED CAR PRICE WHISPERER
============================================================
Equation: price = 26,818 + (-1,242 x age) + (-0.09 x km)
Each extra year is associated with about $1,242 less value.
Each extra 10,000 km is associated with about $922 less value.
Mean absolute error: $906
R-squared: 0.93
Prediction for a 5-year-old car with 60,000 km: $15,077

Saved: outputs/actual_vs_predicted.png, outputs/metrics.txt
Try this: add a 'fuel_type' column (petrol/diesel) and think about encoding it.
```

## Practical Exercises

- **Exercise 4.1:** Using the learned equation, calculate what the model would predict for a brand new car (age = 0, kilometers = 0). What is this value called in linear algebra?
- **Exercise 4.2:** If a buyer is considering a 5-year-old car with 120,000 km (double the mileage of our benchmark car), how much less should they expect to pay compared to the $15,077 benchmark?
- **Exercise 4.3:** Why is passing a DataFrame with column names `[{"age_years": 5, "kilometers": 60_000}]` safer than passing a raw NumPy array `[[5, 60000]]` into `model.predict()`?

## Common Mistakes and Debugging

| Mistake | Why it happens | How to avoid or fix |
|---|---|---|
| Passing column names in wrong order during prediction | Passing `{"kilometers": 60000, "age_years": 5}` to an array without column metadata. | Use a pandas DataFrame with explicitly named columns matching the training feature matrix $X$. |
| Confusing single car prediction with dataset predictions | Calling `model.predict(example)` and expecting a single scalar float directly without indexing `[0]`. | `model.predict()` always returns an array of predictions; use `[0]` to unpack the first prediction scalar. |
| Forgetting to create `outputs/` directory | Attempting to save a plot or text file into a directory that does not exist. | Always call `OUT.mkdir(exist_ok=True)` using `pathlib.Path` before writing files. |

## Best Practices and Security Considerations

- **Feature Alignment:** Always ensure prediction input schemas (column names, column orders, data types) strictly match the training feature matrix.
- **Sanity Checks on Predictions:** Never deploy a model without verifying predictions on standard benchmark instances to ensure values are physically realistic (e.g., non-negative prices).
- **Directory Safety:** When creating output directories, use `exist_ok=True` to prevent race conditions or crashes when running scripts multiple times.

## Summary

In Lesson 04, we reviewed the complete 7-stage workflow of "The Used Car Price Whisperer". The pipeline ingests `used_cars.csv`, splits the data into training and testing partitions, fits a multiple linear regression model, evaluates test set errors, and produces concrete deliverables. We also examined the benchmark vehicle (a 5-year-old car with 60,000 km), which yields an estimated value of approximately $15,077, and established how model outputs are saved to disk.

## Knowledge-check Questions

1. What are the two specific attributes of the benchmark car used for testing in `main.py`?
2. What is the approximate predicted price for the benchmark vehicle?
3. What two files are generated and saved into the `outputs/` directory?
4. Why does `model.predict()` return an array rather than a single number, even when predicting for one vehicle?
5. What is the benefit of wrapping benchmark input values in a pandas DataFrame with matching column names?

## References

- [main.py lines 45-57](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price/main.py#L45-L57)
- [Scikit-learn Predict Method Reference](https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html#sklearn.linear_model.LinearRegression.predict)
- [Python pathlib Documentation](https://docs.python.org/3/library/pathlib.html)
