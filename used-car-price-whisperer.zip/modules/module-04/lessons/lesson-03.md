# Lesson 03: Extracting and Unpacking Coefficients

**Lesson ID:** lesson-03  
**Module:** module-04  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Inspect the data type, shape, and structure of `model.coef_` and `model.intercept_`.
- Unpack `model.coef_` into descriptive scalar variables: `age_weight, km_weight = model.coef_`.
- Match each extracted coefficient to its corresponding column in the feature matrix $X$.
- Explain the role of the negative sign in representing vehicle value loss.
- Compare the magnitudes of coefficients across features with different measurement units.

## Prerequisites

Completion of [Lesson 01](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-04/lessons/lesson-01.md) and [Lesson 02](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-04/lessons/lesson-02.md). Basic understanding of Python sequence unpacking.

## Concept Explanation

### The Anatomy of `model.coef_`
In simple linear regression with 1 feature, `model.coef_` is a 1-element array (such as `np.array([1.58])`).
However, in multiple linear regression with $P$ features, `model.coef_` is a 1-dimensional NumPy array containing exactly $P$ floating-point numbers:
```python
print(type(model.coef_))   # <class 'numpy.ndarray'>
print(model.coef_.shape)   # (2,)
print(model.coef_)         # [-1241.52758178    -0.09222253]
```

### Feature Alignment Order
How do you know which number corresponds to which feature?
Scikit-learn maintains strict **positional correspondence**:
- The first element (`model.coef_[0]`) corresponds to the first column of the feature matrix $X$ (`X.columns[0]`, which is `age_years`).
- The second element (`model.coef_[1]`) corresponds to the second column of the feature matrix $X$ (`X.columns[1]`, which is `kilometers`).

If you change the order of columns when creating $X$ (e.g., `df[["kilometers", "age_years"]]`), the order of elements in `model.coef_` will swap accordingly!

### Python Sequence Unpacking
In `main.py`, line 42 extracts these values elegantly using Python's iterable unpacking:
```python
age_weight, km_weight = model.coef_
intercept = model.intercept_
```
Because `model.coef_` has exactly two elements, Python cleanly assigns:
- `age_weight = -1241.52758...`
- `km_weight = -0.0922225...`
- `intercept = 26817.96406...`

Unpacking into clear, descriptive variable names prevents indexing mistakes (such as confusing `coef_[0]` and `coef_[1]`) later in the script.

### Understanding the Units and Scales
Students are often surprised when they first compare `age_weight` (-$1,241.53) with `km_weight` (-$0.0922).
Does this mean age is 13,000 times more important than kilometers? **No!**

This is an illusion caused by **units of measurement**:
- `age_years` is measured in single calendar years. A typical car in our dataset has an age between 1 and 12 years. Losing $1,242 per year results in deductions of $1,200 to $14,000.
- `kilometers` is measured in single kilometers! A car does not drive 5 kilometers over its lifespan; it drives 80,000 or 140,000 kilometers!
  - 1 kilometer = -$0.0922 deduction.
  - 10,000 kilometers = -$922 deduction.
  - 100,000 kilometers = -$9,222 deduction!

When scaled to typical vehicular operating ranges:
- A 10-year age gap produces a price deduction of $\approx \$12,420$.
- A 100,000-km mileage gap produces a price deduction of $\approx \$9,222$.

Both features have remarkably comparable total impacts on used car valuations!

## Relevant Code (from main.py, lines 42-44)

```python
    mae = mean_absolute_error(y_test, predictions)
    r2 = r2_score(y_test, predictions)
    age_weight, km_weight = model.coef_
    intercept = model.intercept_
```

### Code explanation
- Line 42 unpacks the two elements of `model.coef_` into `age_weight` and `km_weight`.
- Line 43 stores `model.intercept_` as a scalar variable.
- These variables are subsequently referenced in print statements and exported to `metrics.txt`.

## Worked Example

**Problem:**  
Write a Python function that pairs each column name in feature matrix $X$ with its corresponding coefficient from `model.coef_`, formats the value cleanly, and prints an executive summary table.

**Demonstration Script:**
```python
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

df = pd.read_csv("data/used_cars.csv")
X = df[["age_years", "kilometers"]]
y = df["price_usd"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)

model = LinearRegression().fit(X_train, y_train)

# Pairing column names with weights
print(f"{'Feature Name':<15} | {'Raw Weight':<15} | {'Formatted Rate'}")
print("-" * 55)
for feature_name, weight in zip(X.columns, model.coef_):
    if feature_name == "kilometers":
        formatted = f"${abs(weight)*10000:,.0f} per 10,000 km"
    else:
        formatted = f"${abs(weight):,.0f} per year"
    print(f"{feature_name:<15} | {weight:<15.6f} | -{formatted}")

print(f"{'Intercept':<15} | {model.intercept_:<15.2f} | ${model.intercept_:,.0f} (Base price)")
```

**Output:**
```text
Feature Name    | Raw Weight      | Formatted Rate
-------------------------------------------------------
age_years       | -1241.527582    | -$1,242 per year
kilometers      | -0.092223       | -$922 per 10,000 km
Intercept       | 26817.96        | $26,818 (Base price)
```

This tabular presentation makes the raw statistical output immediately accessible to non-technical stakeholders.

## Step-by-Step Student Instructions

1. **Train Model:** Execute training on `X_train, y_train`.
2. **Inspect Type and Shape:**
   ```python
   print(type(model.coef_))
   print(model.coef_.shape)
   ```
   Confirm it is an `ndarray` of shape `(2,)`.
3. **Execute Unpacking:**
   ```python
   age_weight, km_weight = model.coef_
   print(f"Age weight: {age_weight:.2f}")
   print(f"Km weight : {km_weight:.6f}")
   ```
4. **Inspect Intercept:**
   ```python
   print(f"Intercept : {model.intercept_:.2f}")
   ```

## Expected Output or Observable Behaviour

Unpacking yields `age_weight` equal to approximately `-1241.53`, `km_weight` equal to approximately `-0.092223`, and `intercept` equal to approximately `26817.96`.

## Practical Exercises

- **Exercise 3.1:** What happens if you try to unpack three variables from `model.coef_` (e.g., `w1, w2, w3 = model.coef_`)? What specific exception is raised?
- **Exercise 3.2:** If someone measured mileage in meters instead of kilometers, what would happen to the numerical value of `km_weight`? (Hint: $1 \text{ km} = 1,000 \text{ m}$).
- **Exercise 3.3:** Why is `model.intercept_` stored as a single float while `model.coef_` is stored as an array?

## Common Mistakes and Debugging

| Mistake | Why it happens | How to avoid or fix |
|---|---|---|
| Unpacking variables in reverse order | Writing `km_weight, age_weight = model.coef_`. | Match variable order exactly to the column order of $X$: `["age_years", "kilometers"]`. |
| Comparing raw weights without considering units | Declaring age is more important than mileage because $1,242 > 0.09$. | Standardize or scale units before comparing feature importance. |
| Forgetting that `model.intercept_` is scalar | Attempting to index `model.intercept_[0]`. | `intercept_` is already a scalar float; no indexing is needed. |

## Best Practices and Security Considerations

- **Pair Weights with Feature Names:** Always use `zip(X.columns, model.coef_)` or explicit unpacking rather than magic numbers (`coef_[0]`, `coef_[1]`).
- **Domain Verification:** Verify that the sign of every extracted coefficient matches physical common sense. If a car price model yielded a positive coefficient for mileage, that would signal severe data corruption or sampling bias.
- **Reporting Units:** Never present a raw scientific notation number like `-9.22e-02` to end users without converting it to intuitive units (e.g., -$922 per 10,000 km).

## Summary

In Lesson 03, we unpacked `model.coef_` into `age_weight` (-$1,241.53) and `km_weight` (-$0.0922) and inspected `model.intercept_` ($26,817.96). We learned that scikit-learn aligns coefficient array positions with feature column orders. Finally, we explained that while `km_weight` appears smaller numerically, its real-world impact is comparable to age once multiplied by typical vehicle distances.

## Knowledge-check Questions

1. What data structure and shape does `model.coef_` have in this project?
2. How does scikit-learn determine which index of `model.coef_` corresponds to which feature?
3. What is the value of `age_weight` rounded to the nearest dollar?
4. What is the value of `km_weight` formatted to two decimal places?
5. Why is it misleading to compare the raw magnitudes of `age_weight` and `km_weight` directly?

## References

- [main.py lines 42-44](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price/main.py#L42-L44)
- [Scikit-learn LinearRegression Attributes Guide](https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html)
- [Standardized Coefficients (Statistics How To)](https://www.statisticshowto.com/standardized-beta-coefficient/)
