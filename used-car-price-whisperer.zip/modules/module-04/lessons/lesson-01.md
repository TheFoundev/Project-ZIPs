# Lesson 01: Train/Test Splitting

**Lesson ID:** lesson-01  
**Module:** module-04  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain why partitioning data into separate training and testing subsets is mandatory in machine learning.
- Deconstruct the call `train_test_split(X, y, test_size=0.25, random_state=42)`.
- Calculate the exact sample counts resulting from a 75/25 split on 45 records (33 training, 12 testing).
- Explain the purpose and importance of `random_state=42` for experimental reproducibility.
- Identify data leakage and explain why the test set must remain completely isolated during model training.

## Prerequisites

Completion of [Module 03](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-03/module.json). Familiarity with slicing arrays and pseudo-random number generators.

## Concept Explanation

### The Golden Rule of Machine Learning: Generalization
The central goal of machine learning is not to memorize the past, but to **generalize accurately to future, unseen data**. If an algorithm evaluates its own performance on the very same examples it studied during training, the evaluation is fundamentally flawed. In machine learning, this error is called **data leakage** or **evaluation on training data**.

To evaluate true generalization ability, we partition our historical dataset into two mutually exclusive sets:
1. **Training Set ($X_{train}, y_{train}$):** Provided to the algorithm to discover patterns, optimize equations, and learn parameters ($\beta_0, \beta_1, \beta_2$).
2. **Testing Set ($X_{test}, y_{test}$):** Held in strict reserve as a simulated "future." The model never sees these records during training; they are used solely to assess performance on novel data.

### Deconstructing `train_test_split`
In `main.py`, lines 32–34 execute the partition:
```python
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)
```

Let's dissect each component:
- `X, y`: We pass the 2D feature matrix `X` and 1D target vector `y` together. This guarantees that row shuffling keeps features and corresponding target prices strictly aligned.
- `test_size=0.25`: Allocates 25% of the total dataset to the testing set, leaving the remaining 75% for the training set.
- `random_state=42`: Controls the internal pseudo-random shuffling seed.
- Unpacking order: The function returns exactly four items in a strict order: `X_train`, `X_test`, `y_train`, `y_test`.

### Sample Count Arithmetic for 45 Records
Let us calculate the exact number of observations allocated to each set:
- Total samples: $N = 45$
- Target test proportion: $25\%$
- $45 \times 0.25 = 11.25$

Because sample counts must be discrete integers, scikit-learn rounds $11.25$ to the nearest integer: **12 test samples**.
- Training samples: $45 - 12 = \mathbf{33}$ **training samples**.
- Test samples: $\mathbf{12}$ **testing samples**.

Let us verify the resulting array shapes:
- `X_train.shape`: `(33, 2)` — 33 cars, each with `age_years` and `kilometers`.
- `X_test.shape`: `(12, 2)` — 12 cars, each with `age_years` and `kilometers`.
- `y_train.shape`: `(33,)` — 33 known transaction prices.
- `y_test.shape`: `(12,)` — 12 known transaction prices used for evaluation.

### Why `random_state=42`?
A computer cannot generate true randomness; it uses mathematical pseudo-random number algorithms starting from an initial number called a **seed**.
- If `random_state` is omitted (or set to `None`), Python seeds the random generator using current system clock microseconds. Every time you run `main.py`, different cars are shuffled into train and test sets, causing coefficients, MAE, and $R^2$ to fluctuate on every execution!
- By explicitly setting `random_state=42`, the exact same shuffle sequence is reproduced every single time. Any student, instructor, or auditor running the script anywhere in the world will obtain the exact same coefficients: intercept $26,818$, age weight -$1,242$, mileage weight -$0.0922$, MAE $906, and $R^2$ 0.93!

*(The number 42 is an iconic tribute in computer science culture to Douglas Adams' "The Hitchhiker's Guide to the Galaxy," where 42 is the answer to the ultimate question of life, the universe, and everything).*

## Relevant Code (from main.py, lines 32-34)

```python
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42
    )
```

### Code explanation
- Imports `train_test_split` from `sklearn.model_selection`.
- Shuffles rows and splits them into 33 training rows and 12 testing rows.
- Sets `random_state=42` to ensure total mathematical reproducibility across platforms.

## Worked Example

**Problem:**  
Write a Python script to verify the exact index numbers of the 12 vehicles selected into the test set when `random_state=42` is used, and verify that no index appears in both `X_train` and `X_test`.

**Solution Script:**
```python
import pandas as pd
from sklearn.model_selection import train_test_split

df = pd.read_csv("data/used_cars.csv")
X = df[["age_years", "kilometers"]]
y = df["price_usd"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)

test_indices = sorted(X_test.index.tolist())
train_indices = sorted(X_train.index.tolist())

print(f"Total rows: {len(df)}")
print(f"Train rows: {len(X_train)}, Test rows: {len(X_test)}")
print(f"Test indices ({len(test_indices)}):", test_indices)

# Verify mutual exclusivity
overlap = set(train_indices).intersection(set(test_indices))
print("Overlapping indices:", overlap)
assert len(overlap) == 0, "Error: Training and testing sets overlap!"
```

**Output:**
```text
Total rows: 45
Train rows: 33, Test rows: 12
Test indices (12): [3, 4, 6, 8, 12, 24, 25, 26, 35, 39, 41, 43]
Overlapping indices: set()
```

The 12 test vehicles are completely disjoint from the 33 training vehicles, confirming zero data contamination.

## Step-by-Step Student Instructions

1. **Open Python Shell:** In your terminal, run `python3`.
2. **Execute Split:**
   ```python
   import pandas as pd
   from sklearn.model_selection import train_test_split
   df = pd.read_csv("data/used_cars.csv")
   X = df[["age_years", "kilometers"]]
   y = df["price_usd"]
   X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)
   ```
3. **Verify Shapes:**
   ```python
   print("X_train shape:", X_train.shape)
   print("X_test shape :", X_test.shape)
   print("y_train shape:", y_train.shape)
   print("y_test shape :", y_test.shape)
   ```
4. **Confirm Row Counts:** Verify that $33 + 12 = 45$.

## Expected Output or Observable Behaviour

Executing `train_test_split` with `test_size=0.25` on 45 rows allocates 33 rows to training and 12 rows to testing with 2 columns in $X$ and 1 column in $y$.

## Practical Exercises

- **Exercise 1.1:** If `test_size=0.20` were used instead of `0.25`, how many rows would be allocated to `X_train` and `X_test`? ($45 \times 0.20 = 9$).
- **Exercise 1.2:** What happens if you run `train_test_split` without specifying `random_state`? Run it 3 times and check whether the first test index changes.
- **Exercise 1.3:** Explain why unpacking in the wrong order (e.g., `X_train, y_train, X_test, y_test = train_test_split(...)`) causes silent data corruption in downstream code.

## Common Mistakes and Debugging

| Mistake | Why it happens | How to avoid or fix |
|---|---|---|
| Unpacking variables in the wrong order | Swapping `y_train` and `X_test`. | Memorize the exact return order: `X_train, X_test, y_train, y_test`. |
| Fitting the model on `X` instead of `X_train` | Passing the full 45 rows to `model.fit()`. | Always train exclusively on `X_train, y_train` to prevent data leakage. |
| Omitting `random_state` | Believing random_state is optional in educational tutorials. | Always specify `random_state=42` to ensure reproducible metrics and grading. |

## Best Practices and Security Considerations

- **Strict Isolation:** Never compute scaling parameters, imputations, or models using any test set data.
- **Seed Documentation:** In production research, always log the random seed used for data partitioning.
- **Stratification:** In classification, `stratify=y` is used to preserve class ratios; in continuous regression, standard random splitting is standard.

## Summary

In Lesson 01, we explored the critical role of train/test partitioning. Using `train_test_split(X, y, test_size=0.25, random_state=42)`, we split our 45 records into 33 training samples and 12 testing samples. This partition ensures that model training remains strictly isolated from evaluation, while `random_state=42` guarantees consistent reproducibility across all environments.

## Knowledge-check Questions

1. Why do we split data into separate training and testing subsets?
2. How many samples are allocated to the training set and testing set in our project?
3. What is the return order of the four variables from `train_test_split`?
4. What is the role of `random_state=42`?
5. What is "data leakage" and how does train/test splitting prevent it?

## References

- [main.py lines 32-34](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price/main.py#L32-L34)
- [Scikit-learn train_test_split Documentation](https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html)
- [The Hitchhiker's Guide to the Galaxy (Douglas Adams)](https://en.wikipedia.org/wiki/42_(number)#The_Hitchhiker's_Guide_to_the_Galaxy)
