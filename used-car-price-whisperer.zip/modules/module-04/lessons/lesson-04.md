# Lesson 04: Quantifying Used Car Depreciation

**Lesson ID:** lesson-04  
**Module:** module-04  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Translate the mathematical coefficients into quantitative economic depreciation metrics.
- Explain the real-world meaning of losing ~$1,242 in vehicle value per year of ownership.
- Explain the real-world meaning of losing ~$922 in vehicle value per 10,000 kilometers traveled.
- Analyze the trade-off between chronological age and odometer mileage when evaluating prospective used car purchases.
- Discuss the limitations of linear depreciation models over extended time horizons.

## Prerequisites

Completion of [Lesson 01](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-04/lessons/lesson-01.md), [Lesson 02](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-04/lessons/lesson-02.md), and [Lesson 03](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-04/lessons/lesson-03.md). Basic understanding of financial valuation and depreciation.

## Concept Explanation

### The Economics of Vehicle Depreciation
When a machine learning model is trained on financial or market data, its primary value often lies not merely in generating automated numbers, but in **explaining economic mechanisms**. In "The Used Car Price Whisperer", our model quantifies the exact monetary cost of vehicle ownership.

In `main.py`, lines 52–53 communicate these findings in plain business language:
```python
print(f"Each extra year is associated with about ${abs(age_weight):,.0f} less value.")
print(f"Each extra 10,000 km is associated with about ${abs(km_weight) * 10_000:,.0f} less value.")
```

### 1. Chronological Depreciation: ~$1,242 / Year
Regardless of whether a vehicle is driven daily or parked inside a suburban garage, the mere passage of time erodes its resale value at an empirical rate of approximately **$1,242 per year**.
- Over a standard 3-year financing cycle, chronological aging alone consumes:
  $$3 \times \$1,241.53 = \$3,724.59$$
- Over 5 years of ownership, age accounts for:
  $$5 \times \$1,241.53 = \$6,207.65$$

This depreciation accounts for:
- Cosmetic obsolescence (new body styles, redesigned grilles).
- Technology improvements in newer models (updated infotainment, advanced driver assist systems, improved fuel economy).
- Environmental degradation of rubber weather-stripping, hoses, and paint oxidation.

### 2. Operational Depreciation: ~$922 / 10,000 km
Every trip recorded on the odometer erodes value at a rate of approximately **9.22 cents per kilometer**, or **~$922 per 10,000 km**.
- If a commuter drives 15,000 km per year, their annual mileage depreciation is:
  $$1.5 \times \$922.23 = \$1,383.35$$
- If a delivery driver drives 40,000 km in a single year, their operational depreciation is:
  $$4.0 \times \$922.23 = \$3,688.90$$

This operational wear captures mechanical engine stress, suspension fatigue, tire wear, brake wear, and transmission usage.

### The Age vs. Mileage Valuation Trade-off
Because the model establishes clear rates for both factors, we can calculate an **equivalence ratio**:
$$\text{Mileage equivalent of 1 year of age} = \frac{\$1,241.53}{\$0.092223/\text{km}} \approx 13,462 \text{ km}$$

**The 13,500 km Rule:**  
In our dataset, aging by **1 calendar year** has the exact same economic impact on vehicle value as driving **13,462 kilometers**!

This insight gives buyers and sellers a powerful decision tool:
- If Car A is 1 year older than Car B, but Car A has 25,000 fewer kilometers, Car A is actually in a better value position because its mileage advantage ($25,000 \times 0.0922 = \$2,305$) easily outweighs its 1-year age disadvantage ($1,242).
- Conversely, if Car A has only 5,000 fewer kilometers, the age disadvantage dominates, and Car B is the better financial proposition.

### Limitations of Linear Depreciation
While linear regression fits our data with high accuracy ($R^2 = 0.93$), linear models assume that depreciation remains constant forever. In real life:
1. **Curvilinear Drop:** New cars often lose 15-20% of their value the moment they drive off the lot in Year 1, with depreciation flattening out in Years 8-12.
2. **Floor / Scrap Value:** A 25-year-old car with 300,000 km does not sell for negative money; it reaches a baseline scrap/utility floor (e.g., $500–$1,000). Linear regression will predict negative prices if extrapolated far beyond the training domain.

## Relevant Code (from main.py, lines 51-53)

```python
    print(f"Equation: price = {intercept:,.0f} + ({age_weight:,.0f} x age) + ({km_weight:.2f} x km)")
    print(f"Each extra year is associated with about ${abs(age_weight):,.0f} less value.")
    print(f"Each extra 10,000 km is associated with about ${abs(km_weight) * 10_000:,.0f} less value.")
```

### Code explanation
- Translates regression weights into actionable economic takeaways.
- Uses `abs()` to convert negative coefficients into natural language sentences describing value loss.
- Multiplies `km_weight` by 10,000 to present an intuitive consumer-facing benchmark.

## Worked Example

**Problem:**  
A prospective buyer is comparing two 2019 used vehicles (both 5 years old):
- Car Alpha: 40,000 km, listed at $17,000
- Car Beta: 80,000 km, listed at $13,500

Using our model equation ($\text{price} = 26,818 - 1,241.53 \times \text{age} - 0.092223 \times \text{km}$):
1. Calculate the model's fair market prediction for both cars.
2. Compare each car's asking price to its predicted fair market price.
3. Which car represents a better bargain for the buyer?

**Step-by-step Valuation:**

**Car Alpha (5 yrs, 40,000 km):**
$$\hat{y}_{\alpha} = 26,817.96 - (1,241.53 \times 5) - (0.092223 \times 40,000)$$
$$\hat{y}_{\alpha} = 26,817.96 - 6,207.65 - 3,688.90 = \$16,921.41 \approx \$16,921$$
- Asking price: $17,000
- Valuation difference: $\$17,000 - \$16,921 = +\$79$ (Priced almost perfectly at fair value).

**Car Beta (5 yrs, 80,000 km):**
$$\hat{y}_{\beta} = 26,817.96 - (1,241.53 \times 5) - (0.092223 \times 80,000)$$
$$\hat{y}_{\beta} = 26,817.96 - 6,207.65 - 7,377.80 = \$13,232.51 \approx \$13,233$$
- Asking price: $13,500
- Valuation difference: $\$13,500 - \$13,233 = +\$267$ (Slightly overpriced by $267).

**Conclusion:**  
Car Alpha is priced at within $79 of fair market value, whereas Car Beta is marked up by $267 over its higher-mileage fair price. Car Alpha represents the closer deal to true equilibrium market pricing.

## Step-by-Step Student Instructions

1. **Verify Depreciation Equivalency:** In your Python shell, compute `abs(age_weight) / abs(km_weight)`. Confirm that the result is approximately `13,462 km`.
2. **Examine Console Printouts:** Run `python main.py` and observe lines 52-53 in the console output.
3. **Analyze Your Own Vehicle:** Take the age and odometer mileage of a car you know. Plug the values into the formula:
   $$\text{Predicted Price} = 26,818 - (1,242 \times \text{age}) - (0.0922 \times \text{km})$$
   Does the result align with local classified listings for that car?
4. **Identify Boundary Limits:** Calculate at what age a car with 150,000 km would predict a negative price ($26,818 - 1,242 \times \text{age} - 13,830 = 0 \implies 1,242 \times \text{age} = 12,988 \implies \text{age} \approx 10.5 \text{ years}$).

## Expected Output or Observable Behaviour

The console output explicitly states that each extra year erodes about $1,242 in value, and each 10,000 km erodes about $922 in value, enabling clear economic communication.

## Practical Exercises

- **Exercise 4.1:** If a car owner drives 20,000 km in one year, how much total depreciation (age + mileage) should they budget for that year based on our model?
- **Exercise 4.2:** If a dealership offers to roll back an odometer by 30,000 km (an illegal practice), how much fraudulent artificial value would that create according to our model?
- **Exercise 4.3:** How would you modify the model's prediction function in Python to prevent it from ever returning a price below $500?

## Common Mistakes and Debugging

| Mistake | Why it happens | How to avoid or fix |
|---|---|---|
| Printing negative dollar amounts in text | Outputting "associated with -$1,242 less value" (double negative). | Use `abs(age_weight)` when combined with the word "less value". |
| Confusing rate per km with rate per 10,000 km | Telling a customer that a car loses $922 for every single kilometer driven. | Always multiply per-km rate by 10,000 when talking to human buyers. |
| Blindly trusting linear extrapolation | Predicting the price of a 30-year-old car and getting -$20,000. | Know the domain boundaries of your training dataset (0 to 12 years; 8,400 to 148,300 km). |

## Best Practices and Security Considerations

- **Clear Consumer Communication:** Translate statistical jargon into tangible, decision-ready metrics.
- **Guardrails Against Extrapolation:** In commercial software, clamp linear predictions with reasonable minimum bounds (`max(MIN_PRICE, predicted_price)`).
- **Fraud Prevention:** Quantitative depreciation models provide fraud detection capabilities by identifying listings that diverge drastically from market norms.

## Summary

In Lesson 04, we translated multiple regression weights into concrete automotive economics. We learned that chronological aging costs ~$1,242 per year, while driving costs ~$922 per 10,000 km. We established that 1 year of age is economically equivalent to driving ~13,462 km, providing an objective benchmark for evaluating vehicle purchasing trade-offs while acknowledging the boundaries of linear extrapolation.

## Knowledge-check Questions

1. According to the model, how much value does a car lose for each additional calendar year of age?
2. How much value does a car lose for each additional 10,000 kilometers driven?
3. How many kilometers driven produce an equivalent economic loss to 1 year of vehicle aging?
4. What happens if a linear model is used to predict the price of an extreme 25-year-old car?
5. Why is `abs()` used when printing "Each extra year is associated with about $1,242 less value"?

## References

- [main.py lines 51-53](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price/main.py#L51-L53)
- [Kelley Blue Book: How Vehicle Depreciation Works](https://www.kbb.com/car-advice/car-depreciation/)
- [Edmunds True Cost to Own (TCO) Methodology](https://www.edmunds.com/about/tco-methodology.html)
