# Lesson 02: Fitting the LinearRegression Model

**Lesson ID:** lesson-02  
**Module:** module-04  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Instantiate and configure scikit-learn's `LinearRegression` estimator.
- Explain the role of the `.fit()` method and how it optimizes model parameters on training data.
- Understand the mathematical objective of Ordinary Least Squares (OLS) in minimizing residual sum of squares.
- Trace the execution of `model.fit(X_train, y_train)` and verify the learned internal states.
- Explain why calling `.fit()` on test data constitutes a severe methodological violation.

## Prerequisites

Completion of [Lesson 01](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-04/lessons/lesson-01.md). Familiarity with basic calculus or matrix multiplication concepts.

## Concept Explanation

### The Estimator Lifecycle in Scikit-Learn
In scikit-learn, all machine learning algorithms are encapsulated as Python classes called **estimators**. The workflow follows a standardized, predictable lifecycle:
1. **Import:** `from sklearn.linear_model import LinearRegression`
2. **Instantiation:** `model = LinearRegression()` creates an uninitialized estimator instance.
3. **Fitting (Training):** `model.fit(X_train, y_train)` executes the mathematical optimization algorithm to learn parameters from data.
4. **Inspection / Inference:** Read learned attributes (`model.coef_`, `model.intercept_`) or make predictions (`model.predict()`).

### Ordinary Least Squares (OLS) Under the Hood
What actually happens inside the computer when `model.fit(X_train, y_train)` is called?

The algorithm uses a classical technique called **Ordinary Least Squares (OLS)**. For every vehicle $i$ in the training set (from $i=1$ to $33$), the actual selling price is $y_i$, and the model's predicted price on the candidate regression plane is:
$$\hat{y}_i = \beta_0 + \beta_1 x_{i,1} + \beta_2 x_{i,2}$$

The difference between actual price and predicted price is called the **residual** or error:
$$e_i = y_i - \hat{y}_i$$

OLS seeks to find the specific plane parameters ($\beta_0, \beta_1, \beta_2$) that **minimize the Residual Sum of Squares (RSS)**:
$$\text{RSS} = \sum_{i=1}^{33} (y_i - \hat{y}_i)^2 = \sum_{i=1}^{33} (y_i - [\beta_0 + \beta_1 x_{i,1} + \beta_2 x_{i,2}])^2$$

Why do we square the residuals?
1. **Penalizes large errors:** Squaring ensures that a few huge prediction mistakes are penalized more heavily than many tiny errors.
2. **Eliminates cancellations:** Positive errors (underpredicting) and negative errors (overpredicting) do not cancel each other out.
3. **Smooth, differentiable convex surface:** The sum of squared errors forms a parabolic bowl with a single, unique global minimum!

### The Closed-Form Normal Equation
Unlike deep neural networks that require iterative gradient descent over thousands of epochs, linear regression can be solved in a single mathematical step using linear algebra! The optimal weight vector $\hat{\beta}$ is computed directly via the **normal equation**:
$$\hat{\beta} = (X^T X)^{-1} X^T y$$

Scikit-learn implements this using high-performance LAPACK routines (specifically, singular value decomposition `scipy.linalg.lstsq`), completing the optimization across 33 cars in less than 2 milliseconds!

### The Learned Attributes
Once `.fit()` finishes, scikit-learn stores the learned parameters as attributes on the `model` object. By convention in scikit-learn, all attributes learned during `.fit()` end with a trailing underscore `_`:
- `model.coef_`: A NumPy array storing the feature weights ($\beta_1, \beta_2$).
- `model.intercept_`: A float storing the baseline constant ($\beta_0$).

If you try to access `model.coef_` before calling `.fit()`, Python raises a `NotFittedError`!

## Relevant Code (from main.py, lines 36-37)

```python
    model = LinearRegression()
    model.fit(X_train, y_train)
```

### Code explanation
- `model = LinearRegression()`: Creates an instance with default parameters (`fit_intercept=True`, `copy_X=True`).
- `model.fit(X_train, y_train)`: Solves the least squares matrix equation on the 33 training samples, populating `model.coef_` and `model.intercept_`.

## Worked Example

**Problem:**  
Demonstrate in a script what happens if you attempt to inspect `model.coef_` before calling `model.fit()`, and contrast that with the state after calling `.fit()`.

**Demonstration Script:**
```python
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.exceptions import NotFittedError

df = pd.read_csv("data/used_cars.csv")
X = df[["age_years", "kilometers"]]
y = df["price_usd"]

model = LinearRegression()

# Check before fit
try:
    print("Attempting to read coef_ before fit...")
    print(model.coef_)
except AttributeError as e:
    print("Caught expected error:", e)

# Execute fit
model.fit(X, y)
print("Fit completed successfully!")
print("Learned coef_:", model.coef_)
print("Learned intercept_:", model.intercept_)
```

**Output:**
```text
Attempting to read coef_ before fit...
Caught expected error: 'LinearRegression' object has no attribute 'coef_'
Fit completed successfully!
Learned coef_: [-1.24152758e+03 -9.22225325e-02]
Learned intercept_: 26817.96406991822
```

Calling `.fit()` is the precise action that transitions the model from an empty container to a calibrated estimator.

## Step-by-Step Student Instructions

1. **Import the Estimator:** In Python, run:
   ```python
   from sklearn.linear_model import LinearRegression
   ```
2. **Instantiate:**
   ```python
   model = LinearRegression()
   ```
3. **Execute Fitting:**
   ```python
   model.fit(X_train, y_train)
   ```
4. **Verify Learned Attributes:**
   ```python
   print("Has coef_     :", hasattr(model, "coef_"))
   print("Has intercept_:", hasattr(model, "intercept_"))
   ```
   Both should evaluate to `True`.

## Expected Output or Observable Behaviour

The call to `model.fit(X_train, y_train)` executes silently and almost instantaneously (in under 5 milliseconds), populating `model.coef_` with `[-1241.53, -0.0922]` and `model.intercept_` with `26817.96`.

## Practical Exercises

- **Exercise 2.1:** What happens if you pass `fit_intercept=False` when instantiating `LinearRegression()`? What would `model.intercept_` be forced to equal?
- **Exercise 2.2:** Why is ordinary least squares referred to as a "closed-form" solution, whereas algorithms like gradient descent are called "iterative"?
- **Exercise 2.3:** Why is it considered data leakage if an engineer calls `model.fit(X, y)` using the full 45 rows before splitting?

## Common Mistakes and Debugging

| Mistake | Why it happens | How to avoid or fix |
|---|---|---|
| Calling `.fit()` without saving the model variable | Calling `LinearRegression().fit(X_train, y_train)` without assigning it to `model = ...`. | Always assign: `model = LinearRegression()`, then `model.fit(...)`. |
| Swapping $X$ and $y$ inside `.fit(y_train, X_train)` | Passing target first and features second. | Always follow the API convention: `model.fit(features, target)`. |
| Accessing `coef` without trailing underscore | Writing `model.coef` instead of `model.coef_`. | Remember that all learned attributes in scikit-learn end with an underscore (`coef_`, `intercept_`). |

## Best Practices and Security Considerations

- **Strict Training Isolation:** Fit models strictly on training splits (`X_train, y_train`). Never fit on validation or test sets.
- **Model Checkpointing:** In production systems, serialize fitted models using `joblib` or `pickle` only from trusted internal storage.
- **Matrix Conditioning:** When working with thousands of features, check for singular matrices; scikit-learn's OLS handles rank-deficient matrices via SVD.

## Summary

In Lesson 02, we examined model fitting using scikit-learn's `LinearRegression`. The `.fit(X_train, y_train)` method applies the Ordinary Least Squares (OLS) closed-form normal equation to find the 3D regression plane that minimizes the sum of squared prediction errors. Fitting populates the learned attributes `model.coef_` and `model.intercept_`, preparing the model for coefficient extraction and inference.

## Knowledge-check Questions

1. What class in scikit-learn is used to create a multiple linear regression model?
2. What mathematical criterion does Ordinary Least Squares (OLS) minimize during fitting?
3. What naming convention does scikit-learn use for attributes learned during `.fit()`?
4. What happens if you attempt to access `model.coef_` prior to calling `.fit()`?
5. Why doesn't linear regression require iterative gradient descent epochs like deep neural networks?

## References

- [main.py lines 36-37](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price/main.py#L36-L37)
- [Scikit-learn LinearRegression Documentation](https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html)
- [Ordinary Least Squares (Wikipedia)](https://en.wikipedia.org/wiki/Ordinary_least_squares)
