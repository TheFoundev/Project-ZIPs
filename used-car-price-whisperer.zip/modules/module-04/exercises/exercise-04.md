# Module 4 Exercises: Model Training & Coefficient Interpretation

## Exercise 4.1: Reproducible Train/Test Partitioning (15 min)
**Objective:** Perform reproducible train/test splits and audit partition sizes.  
**Problem Statement:** You must partition `used_cars.csv` using scikit-learn's `train_test_split` with a 75/25 split ratio and verify complete reproducibility.

**Requirements:**
1. Load `used_cars.csv` and extract `X = df[["age_years", "kilometers"]]` and `y = df["price_usd"]`.
2. Split the data using `train_test_split(X, y, test_size=0.25, random_state=42)`.
3. Assert that `X_train.shape == (33, 2)` and `X_test.shape == (12, 2)`.
4. Assert that `y_train.shape == (33,)` and `y_test.shape == (12,)`.
5. Run the split twice with the same seed and confirm that `X_test.index` is 100% identical.
6. Run the split with `random_state=None` and explain why the test indices change.

**Constraints:** Use `train_test_split` from `sklearn.model_selection`.

**Expected Behaviour:** Python script runs cleanly, validates all shape assertions, and logs index consistency under fixed random seeds.

**Acceptance Criteria:**
- [ ] Correct unpacking order: `X_train, X_test, y_train, y_test`.
- [ ] Shapes verified as (33, 2), (12, 2), (33,), and (12,).
- [ ] Test indices confirmed as `[39, 25, 26, 43, 35, 41, 4, 12, 8, 3, 6, 24]`.
- [ ] Clear written explanation of why `random_state=42` guarantees reproducibility.

**Hints:**
- Use `assert (X_test.index == X_test_2.index).all()` to test index identity.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 4.2: Fitting LinearRegression & Accessing OLS States (15 min)
**Objective:** Instantiate, train, and inspect scikit-learn's `LinearRegression` estimator.  
**Problem Statement:** Train the linear regression estimator exclusively on training data and verify that internal OLS parameters are populated correctly.

**Requirements:**
1. Instantiate `model = LinearRegression()`.
2. Demonstrate that calling `model.coef_` before `.fit()` raises an `AttributeError`.
3. Call `model.fit(X_train, y_train)` strictly on the training partition.
4. Verify that `model.coef_` and `model.intercept_` are populated.
5. Print the exact floating-point values of `model.coef_` and `model.intercept_`.

**Constraints:** Do not expose `X_test` or `y_test` to `model.fit()`.

**Expected Behaviour:** Code handles the pre-fit exception, fits the model, and displays learned coefficients with high precision.

**Acceptance Criteria:**
- [ ] Exception handled before fit.
- [ ] Fitted exclusively on `X_train` and `y_train`.
- [ ] `model.coef_` confirmed as a 2-element array.
- [ ] `model.intercept_` confirmed as a float (~26817.96).

**Hints:**
- Catch `AttributeError` using a standard `try...except` block.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 4.3: Unpacking and Mapping Coefficients to Features (15 min)
**Objective:** Unpack coefficients safely and pair them with feature column names.  
**Problem Statement:** An automated reporting system needs to extract learned weights and map them to their corresponding business names without hardcoded index numbers.

**Requirements:**
1. Extract `age_weight, km_weight = model.coef_` via sequence unpacking.
2. Extract `intercept = model.intercept_`.
3. Using Python's `zip()` function, construct a dictionary mapping each column in `X.columns` to its learned coefficient.
4. Print the complete multiple linear regression equation in the exact format:
   `price = {intercept:,.0f} + ({age_weight:,.0f} x age) + ({km_weight:.2f} x km)`.
5. Compare the printed equation with line 51 of `main.py`.

**Constraints:** Follow PEP 8 formatting conventions and standard f-string formatting.

**Expected Behaviour:** Formatted equation printed matches:
`Equation: price = 26,818 + (-1,242 x age) + (-0.09 x km)`.

**Acceptance Criteria:**
- [ ] Sequence unpacking executes successfully.
- [ ] Dictionary `{column: weight}` correctly constructed.
- [ ] Equation string matches `main.py` formatting.
- [ ] Rounding flags `:,.0f` and `:.2f` used appropriately.

**Hints:**
- Use `dict(zip(X.columns, model.coef_))` to create the mapping.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 4.4: Depreciation Analysis and Buyer Trade-off Simulation (20 min)
**Objective:** Model vehicle depreciation economics and evaluate purchasing decisions.  
**Problem Statement:** You are developing a financial advisory tool for used car shoppers. Using the learned regression weights, build a decision simulator that compares two prospective car listings.

**Requirements:**
1. Implement a Python function `predict_price(age_years, kilometers)` using the learned equation parameters.
2. Implement a function `compare_vehicles(car_a, car_b)` where each car is represented as a dictionary: `{"name": str, "age": int, "km": int, "price": float}`.
3. Compute the fair market prediction for both cars and calculate their pricing deviation (Asking Price - Predicted Fair Price).
4. Calculate the annual age depreciation ($1,242/yr) and per-10,000 km mileage depreciation ($922/10k km).
5. Calculate the mileage equivalence ratio: how many kilometers driven equals 1 year of aging?
6. Evaluate:
   - Car 1: 3 years old, 60,000 km, listed at $18,000
   - Car 2: 5 years old, 30,000 km, listed at $18,000
   Determine which car is priced more favorably relative to its fair market value.

**Constraints:** Rely exclusively on the parameters learned from `used_cars.csv`.

**Expected Behaviour:** Simulator calculates predictions, determines pricing deviations, prints the equivalence ratio (~13,462 km), and selects the better purchase.

**Acceptance Criteria:**
- [ ] `predict_price()` outputs ~$17,560 for Car 1 and ~$17,843 for Car 2.
- [ ] Identifies Car 2 as the closer deal (overpriced by only ~$157 vs. ~$440 for Car 1).
- [ ] Mileage equivalence ratio calculated as ~13,462 km per year of age.
- [ ] Provides clear economic justification for the recommendation.

**Hints:**
- Car 2 is 2 years older (-$2,483), but has 30,000 fewer kilometers (+$2,767). The mileage advantage outweighs the age disadvantage!

**Difficulty:** Advanced  
**Estimated Completion Time:** 20 minutes  
