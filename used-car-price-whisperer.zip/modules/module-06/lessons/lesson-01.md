# Lesson 01: Running main.py End-to-End

**Lesson ID:** lesson-01  
**Module:** module-06  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Execute `main.py` from the command line interface without errors.
- Trace the complete nine-stage execution flow of the Used Car Price Whisperer pipeline from imports to artifact persistence.
- Explain the purpose and operation of the Python standard entry-point idiom `if __name__ == "__main__": main()`.
- Identify the synchronous dependencies between data preparation, model training, evaluation, and artifact generation.
- Verify environment prerequisites before launching the machine learning script.

## Prerequisites

Completion of [Module 05](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-05/module.json). Working terminal access with Python 3 and project dependencies installed.

## Concept Explanation

### The Architecture of an End-to-End ML Script
A production-ready machine learning script is not simply a collection of disconnected interactive notebook cells. It is an automated, deterministic pipeline designed to execute sequentially from beginning to end. In "The Used Car Price Whisperer", [`main.py`](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML%20Beginners/projects/07_car_price/main.py) encapsulates the complete lifecycle of a multiple linear regression model in 85 lines of clean, modular Python.

The pipeline comprises nine distinct stages executed in a strict chronological sequence:

```text
[1. Backend & Imports] -> [2. Path Resolution] -> [3. Data Ingestion]
         |
         v
[4. Feature Separation] -> [5. Train/Test Split] -> [6. Model Fitting]
         |
         v
[7. Metrics & Inference] -> [8. Visualization] -> [9. File Persistence]
```

1. **Backend & Library Imports (Lines 10–20):** Enforces headless plotting with `matplotlib.use("Agg")` and imports pandas, scikit-learn, and pathlib.
2. **Directory & Path Resolution (Lines 21–25):** Resolves filesystem paths relative to the script location and guarantees that `outputs/` exists via `mkdir(exist_ok=True)`.
3. **Data Ingestion (Line 28):** Loads `data/used_cars.csv` into a structured pandas DataFrame.
4. **Feature Matrix & Target Vector Extraction (Lines 29–30):** Partitions raw columns into a 2D feature matrix `X` (`age_years`, `kilometers`) and a 1D target vector `y` (`price_usd`).
5. **Train/Test Splitting (Lines 32–34):** Partitions 45 records into 33 training samples and 12 testing samples using `random_state=42`.
6. **Model Instantiation & Fitting (Lines 36–37):** Fits an Ordinary Least Squares `LinearRegression` model strictly on the training partition.
7. **Evaluation & Example Inference (Lines 38–46):** Generates test set predictions, computes MAE ($906) and $R^2$ (0.93), extracts regression weights, and values a hypothetical 5-year-old car with 60,000 km ($15,077).
8. **Visualization Generation (Lines 58–70):** Renders the actual-vs-predicted scatter plot with the 45-degree reference diagonal and saves `outputs/actual_vs_predicted.png`.
9. **Artifact Persistence & Cleanup (Lines 72–81):** Writes `outputs/metrics.txt` and prints the final terminal summary.

### The Entry-Point Idiom (`if __name__ == "__main__": main()`)
Lines 84–85 contain one of Python's most important design idioms:
```python
if __name__ == "__main__":
    main()
```
When Python executes a script directly from the command line (`python main.py`), the runtime environment assigns the special string `"__main__"` to the built-in variable `__name__`. As a result, the condition evaluates to `True` and `main()` runs automatically.

Conversely, if an external test suite, API server, or analysis module imports `main.py` (`import main`), `__name__` is set to `"main"`. The block evaluates to `False`, allowing external programs to import helper functions or model definitions without accidentally triggering full script execution!

## Relevant Code (from main.py, lines 27, 84-85)

```python
# Line 27: Define main orchestrator function
def main() -> None:
    ...
    # (Full 9-stage pipeline executes here)
    ...

# Lines 84-85: Standard Python script execution guard
if __name__ == "__main__":
    main()
```

### Code explanation
- **Line 27**: Declares the `main()` function with a type annotation `-> None`, indicating that it operates as an orchestration procedure that coordinates tasks and exports artifacts rather than returning a value to memory.
- **Lines 84–85**: Serves as the program's safe gateway, providing clean entry when run as a standalone script while preserving modular reusability.

## Worked Example

**Scenario:** Let us observe what happens when a student executes `main.py` from the project directory.

**Command:**
```bash
cd "/home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price"
python main.py
```

**Step-by-step terminal execution output:**
```text
============================================================
THE USED CAR PRICE WHISPERER
============================================================
Equation: price = 26,818 + (-1,242 x age) + (-0.09 x km)
Each extra year is associated with about $1,242 less value.
Each extra 10,000 km is associated with about $922 less value.
Mean absolute error: $906
R-squared: 0.93
Prediction for a 5-year-old car with 60,000 km: $15,077

Saved: outputs/actual_vs_predicted.png, outputs/metrics.txt
Try this: add a 'fuel_type' column (petrol/diesel) and think about encoding it.
```

**Filesystem audit immediately after execution:**
- `outputs/actual_vs_predicted.png` (created or updated; ~25 KB image)
- `outputs/metrics.txt` (created or updated; 6 text lines)

The entire run completes in under one second on standard hardware, demonstrating the computational efficiency of linear regression.

## Step-by-Step Student Instructions

1. **Verify Terminal Environment:** Open a terminal window and verify that Python 3 is installed:
   ```bash
   python3 --version
   ```
2. **Navigate to the Project Directory:**
   ```bash
   cd "/home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price"
   ```
3. **Inspect Directory Contents Before Running:**
   ```bash
   ls -la
   ```
   Confirm the presence of `main.py` and the `data/` subdirectory.
4. **Execute the Script:**
   ```bash
   python main.py
   ```
5. **Verify the Terminal Output:** Compare the terminal lines printed against the reference output in the worked example above.
6. **Verify Generated Files in `outputs/`:**
   ```bash
   ls -la outputs/
   ```
   Ensure both `actual_vs_predicted.png` and `metrics.txt` exist with recent timestamps.

## Expected Output or Observable Behaviour

Executing `python main.py` prints the 10-line terminal banner and summary report, completes without any warning or error messages (exit code 0), and creates or overwrites `outputs/actual_vs_predicted.png` and `outputs/metrics.txt`.

## Practical Exercises

- **Exercise 1.1:** What happens if you execute `python -c "import main"`? Does the script print the valuation report? Why or why not?
- **Exercise 1.2:** Time the execution of `main.py` using the Linux `time` command (`time python main.py`). How much user CPU time does the pipeline require compared to real wall-clock time?
- **Exercise 1.3:** Introduce a deliberate syntax error (e.g. misspelled import) on line 18 and run the script. Trace the traceback to identify how Python halts execution before touching the dataset.

## Common Mistakes and Debugging

| Mistake | Why it happens | How to avoid or fix |
|---|---|---|
| Running from the wrong working directory | Executing `python main.py` when your terminal is in a parent directory can cause `FileNotFoundError` if paths are hardcoded as relative strings. | `main.py` uses `Path(__file__).resolve().parent`, making it immune to working directory variations. |
| Missing scikit-learn or pandas dependencies | Running in a Python virtual environment where packages were not installed (`ModuleNotFoundError`). | Run `pip install pandas scikit-learn matplotlib` in your active Python environment. |
| Putting code outside functions without execution guards | Top-level code runs upon import, causing unit tests or external tools to trigger the entire pipeline unexpectedly. | Always wrap execution logic inside `def main():` and invoke via `if __name__ == "__main__":`. |

## Best Practices and Security Considerations

- **Modular Design:** Keep the data pipeline structured inside designated functions (`main()` or sub-functions) to facilitate automated unit testing.
- **Fail Fast on Invalid Input:** In production pipelines, add assertions immediately after data loading (e.g., verifying column names and non-empty DataFrames) before initiating expensive training procedures.
- **Zero Hardcoded Absolute Paths in Source:** Relying on `Path(__file__).resolve().parent` ensures the project repository is portable across different developer machines and server architectures.

## Summary

In Lesson 01, we explored running `main.py` end-to-end. We traced the nine coordinated pipeline stages that take raw historical car transactions, engineer features, partition data, fit a multiple regression model, evaluate predictions, render visual diagnostics, and persist metrics. By utilizing the standard `if __name__ == "__main__": main()` idiom, the script maintains clean command-line usability while preserving architectural modularity.

## Knowledge-check Questions

1. How many sequential stages make up the Used Car Price Whisperer execution pipeline?
2. What is the purpose of the `if __name__ == "__main__":` idiom in Python scripts?
3. Which directory is created automatically by the script to store output artifacts?
4. What exit code indicates that `main.py` completed execution successfully without errors?
5. Why does `main.py` resolve filesystem paths using `Path(__file__).resolve().parent` instead of relative string paths?

## References

- [main.py lines 1-85](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML%20Beginners/projects/07_car_price/main.py#L1-L85)
- [Python Documentation - Top-level script environment (__main__)](https://docs.python.org/3/library/__main__.html)
- [Real Python - Defining Python Main Functions](https://realpython.com/python-main-function/)
