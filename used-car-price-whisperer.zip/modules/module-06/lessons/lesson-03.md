# Lesson 03: Adding fuel_type as a Categorical Feature (Encoding)

**Lesson ID:** lesson-03  
**Module:** module-06  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain why categorical features (text labels) cannot be passed directly into regression equations.
- Contrast nominal categories with ordinal categories and explain why arbitrary integer mapping (label encoding) introduces harmful false assumptions.
- Apply binary dummy encoding (One-Hot Encoding) to categorical attributes such as `fuel_type` (petrol vs. diesel).
- Explain the **Dummy Variable Trap** and why dropping the reference category (`drop_first=True`) is mathematically required in linear regression.
- Interpret the resulting regression coefficient for an encoded dummy variable as an intercept shift (price premium or discount).

## Prerequisites

Completion of [Module 06 Lesson 02](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-06/lessons/lesson-02.md). Understanding of multiple linear regression equations and pandas DataFrame manipulation.

## Concept Explanation

### The Challenge of Categorical Data in Linear Models
Line 81 of `main.py` suggests an extension:
```python
print("Try this: add a 'fuel_type' column (petrol/diesel) and think about encoding it.")
```
In real automotive markets, vehicles run on different powertrains: petrol (gasoline), diesel, electric, or hybrid. Suppose our dataset contained a third column named `fuel_type` with string values `"petrol"` and `"diesel"`.

Linear regression relies strictly on matrix algebra:
$$\hat{y} = \beta_0 + \beta_1 x_1 + \beta_2 x_2 + \beta_3 x_3$$

You cannot multiply a mathematical coefficient ($\beta_3$) by the string `"petrol"`. To incorporate categorical attributes into regression equations, we must convert categorical labels into numeric representations. This process is called **categorical feature encoding**.

### The Flaw of Arbitrary Integer Encoding
A common beginner mistake is assigning arbitrary numbers to categories:
- $\text{petrol} = 1$
- $\text{diesel} = 2$

While this converts strings to numbers, it introduces two catastrophic, false mathematical assumptions into a linear model:
1. **False Ordering:** It implies that diesel is somehow "greater than" petrol ($2 > 1$).
2. **False Scaling:** It forces the mathematical model to assume that transitioning from petrol to diesel is equivalent to the jump from $1$ to $2$, implying that diesel has "twice" the value of petrol.

Because `fuel_type` is a **nominal category** (categories without natural numerical ordering), arbitrary integer encoding distorts regression models.

### One-Hot Encoding and Binary Dummy Variables
The correct mathematical technique is **dummy variable encoding** (also called **One-Hot Encoding**). We replace the single categorical column with binary indicator columns containing only `0` or `1`:

| Vehicle | fuel_type | is_diesel |
|---|---|---|
| Car 1 | petrol | 0 |
| Car 2 | diesel | 1 |
| Car 3 | petrol | 0 |
| Car 4 | diesel | 1 |

Here, `is_diesel` equals `1` if the vehicle has a diesel engine, and `0` otherwise.

### The Dummy Variable Trap
Why did we create only *one* column (`is_diesel`) instead of two (`is_diesel` and `is_petrol`)?

If we included both columns along with an intercept ($\beta_0$), observe what happens for every row:
$$\text{is\_petrol} + \text{is\_diesel} = 1.0$$

The sum of the two dummy columns is perfectly equal to the constant intercept column ($1.0$). This condition is known as **perfect multicollinearity** or the **Dummy Variable Trap**. When two or more features have an exact linear relationship, the feature matrix $X^T X$ becomes singular (non-invertible), causing Ordinary Least Squares regression to fail or produce wildly erratic coefficients!

The mathematical rule for categorical features with $k$ distinct categories is:
$$\text{Number of dummy columns needed} = k - 1$$

For two categories (petrol and diesel), we need $2 - 1 = 1$ dummy column. The omitted category (petrol) becomes the **baseline reference category**, whose value is absorbed directly into the intercept $\beta_0$.

### Interpreting the Dummy Coefficient
With `is_diesel` as our third feature, our regression equation becomes:
$$\text{Price} = \beta_0 + (\beta_1 \times \text{age}) + (\beta_2 \times \text{km}) + (\beta_3 \times \text{is\_diesel})$$

Let us analyze what happens for each engine type:
- **For a Petrol Car (`is_diesel = 0`):**
  $$\text{Price} = \beta_0 + (\beta_1 \times \text{age}) + (\beta_2 \times \text{km}) + (\beta_3 \times 0)$$
  $$\text{Price} = \beta_0 + (\beta_1 \times \text{age}) + (\beta_2 \times \text{km})$$
  The baseline intercept $\beta_0$ represents the starting price of a petrol car.
- **For a Diesel Car (`is_diesel = 1`):**
  $$\text{Price} = \beta_0 + (\beta_1 \times \text{age}) + (\beta_2 \times \text{km}) + (\beta_3 \times 1)$$
  $$\text{Price} = (\beta_0 + \beta_3) + (\beta_1 \times \text{age}) + (\beta_2 \times \text{km})$$

The coefficient $\beta_3$ represents the **exact dollar premium (if positive) or discount (if negative)** of a diesel vehicle compared to an otherwise identical petrol vehicle of the exact same age and mileage!

## Relevant Code (Extension Implementation)

```python
import pandas as pd
from sklearn.linear_model import LinearRegression

# Ingest dataset with fuel_type
df = pd.DataFrame([
    {"age_years": 5, "kilometers": 105100, "fuel_type": "petrol", "price_usd": 10063},
    {"age_years": 4, "kilometers": 27800,  "fuel_type": "diesel", "price_usd": 22783},
    {"age_years": 9, "kilometers": 136600, "fuel_type": "petrol", "price_usd": 2784},
    {"age_years": 6, "kilometers": 106600, "fuel_type": "diesel", "price_usd": 11500},
])

# Apply One-Hot Encoding dropping first column to prevent dummy trap
df_encoded = pd.get_dummies(df, columns=["fuel_type"], drop_first=True, dtype=int)
print(df_encoded.head())

# Features include age, kilometers, and fuel_type_diesel
X = df_encoded[["age_years", "kilometers", "fuel_type_diesel"]]
y = df_encoded["price_usd"]

model = LinearRegression()
model.fit(X, y)
print("Coefficients:", model.coef_)
```

### Code explanation
- `pd.get_dummies(df, columns=["fuel_type"], drop_first=True, dtype=int)`: Automatically replaces the string column `fuel_type` with binary integer columns (`0` or `1`), dropping the first alphabetical category (`diesel` or `petrol`) to avoid the dummy variable trap.
- `X`: The feature matrix now has 3 dimensions: `age_years`, `kilometers`, and `fuel_type_diesel`.
- `model.fit(X, y)`: Fits the 3-variable regression model, learning three slopes and an intercept.

## Worked Example

**Scenario:** Suppose after encoding and fitting a larger dataset, our model yields:
- Intercept ($\beta_0$): $25,500 (baseline for petrol cars)
- Age weight ($\beta_1$): -$1,200 / year
- KM weight ($\beta_2$): -$0.08 / km
- Fuel weight ($\beta_3$ for `is_diesel`): +$1,800

**Comparison:** Consider two cars, both 4 years old with 50,000 km, but Car A is petrol while Car B is diesel.

- **Car A (Petrol, `is_diesel = 0`):**
  $$\text{Price}_A = 25,500 - (1,200 \times 4) - (0.08 \times 50,000) + (1,800 \times 0)$$
  $$\text{Price}_A = 25,500 - 4,800 - 4,000 = \$16,700$$

- **Car B (Diesel, `is_diesel = 1`):**
  $$\text{Price}_B = 25,500 - (1,200 \times 4) - (0.08 \times 50,000) + (1,800 \times 1)$$
  $$\text{Price}_B = 25,500 - 4,800 - 4,000 + 1,800 = \$18,500$$

**Interpretation:** The model quantifies that diesel cars carry an average market premium of **+$1,800** over petrol counterparts of identical age and mileage, likely due to better highway fuel economy or perceived engine longevity.

## Step-by-Step Student Instructions

1. **Review Line 81 in `main.py`:** Open [`main.py`](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML%20Beginners/projects/07_car_price/main.py#L81) and observe the extension suggestion.
2. **Launch Python Interactive Shell:** In your terminal, launch `python3`.
3. **Experiment with `pd.get_dummies`:** Create a toy DataFrame and test `pd.get_dummies(df, drop_first=False)` vs `pd.get_dummies(df, drop_first=True)`:
   ```python
   import pandas as pd
   df = pd.DataFrame({"fuel": ["petrol", "diesel", "petrol"]})
   print(pd.get_dummies(df, drop_first=False))
   print(pd.get_dummies(df, drop_first=True))
   ```
4. **Notice the Difference:** Observe how `drop_first=False` creates two columns while `drop_first=True` produces a single column containing complete information without redundancy.
5. **Formulate the Extended Regression Equation:** In your engineering notebook, write down the linear formula showing how a dummy coefficient acts as an intercept modifier.

## Expected Output or Observable Behaviour

Executing `pd.get_dummies(df, drop_first=True)` on a DataFrame with `"petrol"` and `"diesel"` produces a single column (`fuel_petrol` or `fuel_diesel`) containing binary `0` and `1` integer values, successfully transforming a qualitative string into a regression-ready numeric feature.

## Practical Exercises

- **Exercise 3.1:** If a dataset has four transmission types (`automatic`, `manual`, `cvt`, `dual_clutch`), how many dummy columns must be created to avoid the dummy variable trap?
- **Exercise 3.2:** What would happen to the linear regression model if you included all four dummy columns PLUS an intercept? (Research what `LinAlgError` or matrix singularity means in Ordinary Least Squares).
- **Exercise 3.3:** If an encoded column `fuel_electric` receives a coefficient of `+4500`, how would you explain that number to a dealership sales director?

## Common Mistakes and Debugging

| Mistake | Why it happens | How to avoid or fix |
|---|---|---|
| Using LabelEncoder for nominal categories | LabelEncoder assigns 0, 1, 2, which implies a false mathematical hierarchy. | Use `pd.get_dummies(..., drop_first=True)` or scikit-learn's `OneHotEncoder(drop='first')` for linear regression. |
| Forgetting `drop_first=True` | Creating $k$ dummy columns alongside the intercept causes perfect multicollinearity. | Always set `drop_first=True` when fitting Ordinary Least Squares linear models. |
| Forgetting to match columns at test/inference time | If a new car has an unseen category (e.g. "hybrid"), columns won't match the trained model. | Use scikit-learn's `OneHotEncoder(handle_unknown='ignore')` in production pipelines. |

## Best Practices and Security Considerations

- **Always Drop the Reference Column:** In unregularized linear models, never include all $k$ categories to ensure numerical matrix stability.
- **Document the Reference Baseline:** Clearly state which category was dropped (e.g., "petrol is the baseline reference category") so stakeholders can interpret the coefficients correctly.
- **Watch Out for Rare Categories:** If a category appears only once in 10,000 records, training a separate dummy variable can lead to extreme overfitting. Group rare categories into an `"other"` bucket.

## Summary

In Lesson 03, we explored extending the Used Car Price Whisperer with categorical features such as `fuel_type`. We learned why nominal categories cannot use arbitrary integer encoding and demonstrated how One-Hot Encoding converts qualitative labels into binary dummy variables. By dropping the baseline reference category (`drop_first=True`), we avoid the dummy variable trap and enable the linear regression model to quantify exact price premiums or discounts for different vehicle technologies.

## Knowledge-check Questions

1. Why can categorical strings like "petrol" not be passed directly into a linear regression model?
2. Why is assigning numbers like petrol=1, diesel=2 problematic for nominal categories?
3. How many dummy columns should be generated for a categorical feature with $k$ unique values in linear regression?
4. What is the mathematical phenomenon called when all $k$ dummy columns and an intercept are included simultaneously?
5. How does a dummy variable coefficient alter the regression equation geometrically?

## References

- [main.py line 81](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML%20Beginners/projects/07_car_price/main.py#L81)
- [Pandas get_dummies Documentation](https://pandas.pydata.org/docs/reference/api/pandas.get_dummies.html)
- [Scikit-learn OneHotEncoder Guide](https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.OneHotEncoder.html)
