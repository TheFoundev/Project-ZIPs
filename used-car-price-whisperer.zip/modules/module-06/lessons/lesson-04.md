# Lesson 04: Limitations and Real-World Car Pricing Complexity

**Lesson ID:** lesson-04  
**Module:** module-06  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Critique the fundamental assumption of constant linear depreciation in automotive valuation.
- Explain why multiple linear regression produces unrealistic negative price predictions when extrapolated to extreme age or mileage.
- Identify the critical unmeasured features that influence used car transaction prices in real-world markets.
- Explain how target log-transformations ($\log(\text{price})$) model percentage-based depreciation curves.
- Compare multiple linear regression with advanced non-linear machine learning architectures (such as Gradient Boosted Decision Trees).

## Prerequisites

Completion of [Module 06 Lesson 03](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-06/lessons/lesson-03.md). Familiarity with regression modeling and real-world automotive commerce.

## Concept Explanation

### The Power and Simplicity of Linear Models
Throughout this project, multiple linear regression has served as an exceptionally clear, interpretable, and computationally efficient tool. With just two features (`age_years` and `kilometers`), our model achieved an $R^2$ of $0.93$ and an MAE of ~$906$.

However, in professional data science, understanding **what a model cannot do** is just as crucial as knowing what it can do. Real-world automotive valuation is vastly more complex than a straight-line formula.

### The Linear Assumption vs. Real Depreciation Curves
Our multiple regression model assumes constant, straight-line depreciation:
- Every year reduces value by exactly $1,241.53.
- Every kilometer reduces value by exactly $0.092223.

In actual automotive markets, depreciation is distinctly **non-linear**:
1. **The "Drive-Off-the-Lot" Drop:** A brand-new car experiences its steepest percentage decline in its very first year (often losing 15% to 25% of its MSRP the moment it is titled).
2. **Decelerating Decay:** Between years 3 and 7, the annual dollar drop stabilizes and tapers off.
3. **The Salvage Floor:** Older cars do not depreciate to zero or negative infinity. Even a 20-year-old vehicle that runs and drives retains a positive "salvage floor" (often $1,500 to $3,000) simply for its functional transportation utility or scrap metal value.

```text
 Price ($)
   ^
   |  * [Brand New]
   |   \  <-- Real Curve (Steep Initial Drop)
   |    \
   |     \-----------...-----> [Salvage Floor ~$2,000]
   |      \
   |       \  <-- Linear Model Assumption (Crosses $0 into Negative!)
   |        \
   +---------------------------------------------> Age / Mileage
```

### The Extrapolation Failure: Negative Prices
Because linear regression fits an unconstrained straight plane, extrapolating beyond our training data produces impossible predictions:
- Consider a 22-year-old vehicle with 280,000 km:
  $$\text{Price} = 26,818 - (1,242 \times 22) - (0.0922 \times 280,000)$$
  $$\text{Price} = 26,818 - 27,324 - 25,816 = -\$26,322$$
A seller does not pay a buyer $26,322 to take an old car away! This exposes the danger of using a linear model outside its calibrated domain.

### Missing Real-World Features
Our dataset contains only age and kilometers. In production vehicle pricing systems (like Kelley Blue Book, Edmunds, or Carvana), dozens of additional variables are required:

| Feature Category | Examples | Valuation Impact |
|---|---|---|
| **Make, Model & Trim** | Toyota Tacoma vs. Luxury Sedan | High-demand trucks and reliable brands hold value far longer. |
| **Accident & Title History** | Clean title vs. Salvage / Frame damage | Severe collisions typically deduct 20% to 50% of market value. |
| **Cosmetic & Mechanical State** | Rust, dents, tire wear, complete service logs | Well-maintained single-owner cars command substantial premiums. |
| **Geographic Location** | AWD in snowy regions; convertibles in Florida | Regional supply and climate heavily dictate demand. |
| **Macroeconomic Factors** | Inflation, interest rates, fuel price surges | Rising fuel costs depress large V8 SUV prices while boosting hybrids. |

### Modern Solutions: Non-Linear Regression & Ensembles
How do modern machine learning engineers overcome these limitations?
1. **Log-Linear Modeling ($\log(\text{price})$):** Fitting $\log(y)$ instead of $y$ naturally models percentage-based depreciation and guarantees that predictions never fall below zero ($e^{\hat{y}} > 0$).
2. **Polynomial & Spline Features:** Introducing interaction terms ($age \times km$) and polynomial powers ($age^2$) allows the regression curve to bend.
3. **Tree-Based Ensembles:** Algorithms like **Random Forests** and **Gradient Boosted Decision Trees (XGBoost, LightGBM, CatBoost)** are the gold standard for tabular car pricing. They automatically learn non-linear plateaus, categorical interactions, and salvage floors without manual curve fitting.

## Relevant Code (Extrapolation Demonstration)

```python
import pandas as pd
from sklearn.linear_model import LinearRegression

# Recreate model fitted in main.py
X_train = [[5, 105100], [4, 27800], [9, 136600], [2, 142600]]
y_train = [10063, 22783, 2784, 13057]
model = LinearRegression().fit(X_train, y_train)

# Query an extreme outlier vehicle
extreme_car = pd.DataFrame([{"age_years": 25, "kilometers": 350000}])
predicted_price = model.predict(extreme_car)[0]

print(f"Extrapolated valuation: ${predicted_price:,.2f}")
# Prints a negative dollar valuation, proving the linear model's boundary!
```

### Code explanation
- Passing a 25-year-old vehicle with 350,000 km into the linear model forces the subtraction terms to far exceed the intercept ($26,818), resulting in a negative price.
- In production code, such boundary errors are mitigated by clamping predictions with `max(predicted_price, scrap_value)`.

## Worked Example

**Scenario:** An automotive dealership wants to assess whether our linear model can be deployed as an unmonitored online trade-in calculator.

**Audit Findings:**
1. **Strengths:**
   - Exceptionally fast inference (< 1 ms per valuation).
   - Highly explainable weights for cars aged 1 to 10 years and under 150,000 km.
   - Strong test accuracy (MAE ~$906, $R^2 \approx 0.93$).
2. **Fatal Weaknesses:**
   - Predicts -$8,500 for a 15-year-old car with 220,000 km.
   - Treats a 15-year-old pristine collector Porsche identically to a rusted economy compact.
   - Ignores title status (cannot distinguish clean title from flooded or totaled vehicles).
3. **Recommendation:**
   - Implement immediate clamping (`min_price = $1,000`).
   - Collect Make, Model, and Accident records.
   - Upgrade from linear regression to a Gradient Boosted Decision Tree (LightGBM) before customer-facing release.

## Step-by-Step Student Instructions

1. **Test Extreme Predictions:** In your terminal, launch Python and instantiate the Whisperer's equation:
   ```python
   def whisperer(age, km):
       return 26817.96 - (1241.53 * age) - (0.092223 * km)
   ```
2. **Find the Zero-Crossing Point:** Calculate the vehicle age at which a car with 100,000 km reaches a predicted price of $0:
   ```python
   # 26817.96 - (0.092223 * 100000) = 17595.66
   # 17595.66 / 1241.53 = ~14.17 years
   print(whisperer(14.2, 100000))
   ```
3. **Observe the Failure:** Notice that any car older than 14.2 years with 100,000 km is predicted to have negative value.
4. **Implement a Floor Heuristic:** Write a wrapped function that enforces a $1,000 scrap floor:
   ```python
   def robust_whisperer(age, km):
       return max(1000.0, whisperer(age, km))
   ```
5. **Document Limitations:** In your project notes, record at least three unmeasured variables that would be required in an enterprise-grade car pricing engine.

## Expected Output or Observable Behaviour

Testing extreme inputs on the raw linear equation yields negative prices (e.g. `whisperer(20, 200000) -> -$16,457.24`), demonstrating the linear model's mathematical breakdown under out-of-distribution extrapolation.

## Practical Exercises

- **Exercise 4.1:** Why does taking the natural logarithm of price ($\log(y)$) prevent predictions from ever becoming negative, regardless of how large age or kilometers become?
- **Exercise 4.2:** Explain why classic antique cars (e.g., a 1965 Ford Mustang) completely invert the relationship between age and price. How would linear regression handle such vehicles if mixed into the dataset?
- **Exercise 4.3:** Contrast the interpretability of linear regression coefficients with the "black-box" nature of a 500-tree Gradient Boosted ensemble. In what business scenarios is a linear model preferred despite lower peak accuracy?

## Common Mistakes and Debugging

| Mistake | Why it happens | How to avoid or fix |
|---|---|---|
| Extrapolating beyond training ranges | Assuming a model trained on 0–12 year old cars works accurately on a 30-year-old car. | Restrict model inference to the domain of the training distribution, or implement boundary clipping. |
| Assuming high $R^2$ guarantees safety | Believing $R^2 = 0.93$ means the model has no flaws. | Evaluate domain edge cases, residual plots, and worst-case scenario predictions. |
| Treating scrap floor as a linear problem | Trying to force a straight line to stay flat at older ages. | Use non-linear transforms or piecewise regression / decision trees. |

## Best Practices and Security Considerations

- **Input Domain Validation:** Validate incoming feature ranges at runtime; issue warnings or reject inputs when age > 15 years or km > 200,000.
- **Output Clamping & Guardrails:** Never let an automated pricing system output a negative number or zero for a motor vehicle; enforce reasonable market floors.
- **Ethical & Fraud Risks:** Be vigilant of odometer tampering (mileage rollbacks) and undisclosed salvage titles in real-world automotive datasets, as uncleaned fraudulent data corrupts model weights.

## Summary

In Lesson 04, we examined the architectural boundaries and real-world complexities of vehicle valuation. While multiple linear regression provides exceptional interpretability and benchmark accuracy on clean datasets, its assumption of constant linear depreciation fails to capture the steep initial drop, decelerating decay, and positive scrap floors of actual cars. Furthermore, omitting critical features like make, model, condition, and accident history restricts real-world deployment. Moving to production requires combining linear baselines with robust guardrails, log-transformations, or tree-based ensembles.

## Knowledge-check Questions

1. Why does multiple linear regression predict negative prices when applied to very old or high-mileage cars?
2. How does real-world vehicle depreciation differ from the straight-line assumption of linear regression?
3. What is the "salvage floor" in automotive economics?
4. What mathematical transformation of the target variable guarantees that predicted prices remain strictly positive?
5. Name two critical vehicle features omitted from `used_cars.csv` that strongly affect real-world used car values.

## References

- [main.py lines 1-85](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML%20Beginners/projects/07_car_price/main.py#L1-L85)
- [Scikit-learn Supervised Learning Overview](https://scikit-learn.org/stable/supervised_learning.html)
- [Kelley Blue Book - How Vehicle Depreciation Works](https://www.kbb.com/)
