# Lesson 02: Reading All Outputs (Plot + metrics.txt)

**Lesson ID:** lesson-02  
**Module:** module-06  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Cross-validate and synthesize the three distinct output streams produced by `main.py`: terminal console text, `outputs/metrics.txt`, and `outputs/actual_vs_predicted.png`.
- Reconstruct the regression equation from raw output figures and explain the physical meaning of each parameter.
- Explain how different output artifacts serve different stakeholders in an engineering and business organization.
- Perform sanity checks across multiple artifacts to detect potential discrepancies or silent calculation failures.
- Verify that the example prediction ($15,077) matches the mathematical combination of learned coefficients.

## Prerequisites

Completion of [Module 06 Lesson 01](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Used%20Car%20Price%20Whisperer/used-car-price-whisperer/modules/module-06/lessons/lesson-01.md). Understanding of multiple linear regression equations and test evaluation metrics.

## Concept Explanation

### The Triad of Machine Learning Outputs
When a machine learning pipeline runs to completion, evaluating its output requires more than glancing at a single number. Real-world systems generate a **triad of complementary outputs**, each tailored to a specific audience and functional requirement:

```text
                           +----------------------+
                           |   main.py Execution  |
                           +----------+-----------+
                                      |
         +----------------------------+----------------------------+
         |                                                         |
         v                                                         v
+-------------------------+                               +-------------------------+
|     Human-Readable      |                               |    Machine-Readable     |
|     Visual & Summary    |                               |    Audit Artifacts      |
+------------+------------+                               +------------+------------+
             |                                                         |
      +------+------+                                           +------+------+
      |             |                                           |             |
      v             v                                           v             v
 [Console Log] [PNG Plot]                                  [metrics.txt] [Model Weights]
```

1. **The Interactive Console Log:** Provides rapid, high-level feedback to developers during development and debugging. It presents formatted, easily readable statements with rounded dollar values.
2. **The Persisted Metric File (`metrics.txt`):** Provides a machine-readable, high-precision record for automated continuous integration (CI) tests, monitoring systems, and downstream pricing services.
3. **The Visual Diagnostic Plot (`actual_vs_predicted.png`):** Provides qualitative confirmation to data scientists, domain experts, and business leaders that the model behaves predictably across the entire price spectrum without systematic bias or severe outliers.

### Deconstructing the Numbers Across Artifacts

Let us examine the exact correspondence between the console report and `metrics.txt`:

| Concept | Console Representation | `metrics.txt` Value | Practical Economic Interpretation |
|---|---|---|---|
| **Baseline Intercept** | `price = 26,818 + ...` | `intercept: 26817.96` | Theoretical starting price of a brand-new car (0 years, 0 km). |
| **Annual Depreciation** | `-$1,242 x age` | `age coefficient: -1241.53` | Each extra year of vehicle age reduces market value by ~$1,241.53. |
| **Distance Depreciation** | `-$0.09 x km` | `km coefficient: -0.092223` | Each single kilometer reduces market value by ~9.22 cents (-$922 per 10,000 km). |
| **Prediction Error** | `Mean absolute error: $906` | `MAE: 905.97` | Model predictions on unseen test cars deviate by an average of $905.97. |
| **Goodness-of-Fit** | `R-squared: 0.93` | `R2: 0.9280` | Age and distance explain 92.80% of used car price variance. |
| **Target Example** | `Prediction ...: $15,077` | `example prediction: 15076.97` | Estimated market price for a 5-year-old car driven 60,000 km. |

### Visual Synthesis with the Diagnostic Plot
When we inspect `outputs/actual_vs_predicted.png`, the visual pattern matches the quantitative metrics:
- **Tight Diagonal Scatter:** The test points cluster closely around the 45-degree dashed red line ($y = x$), which visually reflects the high $R^2$ of 0.9280.
- **Even Spread:** Points are evenly distributed above (overestimated) and below (underestimated) the diagonal, confirming that the model has no systematic bias toward underpricing or overpricing.
- **Bounded Error Band:** The vertical distance of dots from the diagonal is generally within a narrow envelope, corroborating the low MAE of ~$906.

## Relevant Code (from main.py, lines 48-57, 72-80)

```python
# Lines 48-57: Terminal Report
print("=" * 60)
print("THE USED CAR PRICE WHISPERER")
print("=" * 60)
print(f"Equation: price = {intercept:,.0f} + ({age_weight:,.0f} x age) + ({km_weight:.2f} x km)")
print(f"Each extra year is associated with about ${abs(age_weight):,.0f} less value.")
print(f"Each extra 10,000 km is associated with about ${abs(km_weight) * 10_000:,.0f} less value.")
print(f"Mean absolute error: ${mae:,.0f}")
print(f"R-squared: {r2:.2f}")
print(f"Prediction for a 5-year-old car with 60,000 km: ${example_price:,.0f}")

# Lines 72-80: Disk Persistence
with open(OUT / "metrics.txt", "w", encoding="utf-8") as handle:
    handle.write(f"intercept: {intercept:.2f}\n")
    handle.write(f"age coefficient: {age_weight:.2f}\n")
    handle.write(f"km coefficient: {km_weight:.6f}\n")
    handle.write(f"MAE: {mae:.2f}\n")
    handle.write(f"R2: {r2:.4f}\n")
    handle.write(f"example prediction: {example_price:.2f}\n")

print("\nSaved: outputs/actual_vs_predicted.png, outputs/metrics.txt")
```

### Code explanation
- **Console Block (Lines 48–57):** Formats raw numbers using comma separators (`:,.0f`) and absolute values (`abs()`) to produce clear English sentences that anyone in the business can interpret immediately.
- **Disk Block (Lines 72–80):** Preserves decimal precision for technical audits without decorative text or headers, optimizing the artifact for machine ingestion.
- **Completion Confirmation (Line 80):** Confirms exactly which output files were written to disk.

## Worked Example

**Scenario:** Let us verify the mathematical consistency between the parameters recorded in `metrics.txt` and the example prediction printed on the console.

**From `outputs/metrics.txt`:**
- Intercept ($\beta_0$): $26,817.96
- Age coefficient ($\beta_1$): -$1,241.53
- KM coefficient ($\beta_2$): -$0.092223

**Vehicle to value:**
- Age: $5$ years
- Distance: $60,000$ km

**Manual calculation:**
$$\text{Price} = \beta_0 + (\beta_1 \times \text{age}) + (\beta_2 \times \text{km})$$
$$\text{Price} = 26,817.96 + (-1,241.53 \times 5) + (-0.092223 \times 60,000)$$
$$\text{Price} = 26,817.96 - 6,207.65 - 5,533.38$$
$$\text{Price} = 26,817.96 - 11,741.03 = \$15,076.93$$

**Comparison:**
- Calculated: $\$15,076.93$
- Console Output: `Prediction for a 5-year-old car with 60,000 km: $15,077`
- `metrics.txt` value: `example prediction: 15076.97`

The tiny $0.04$ difference is due to internal floating-point precision when calculating without intermediate rounding. The artifacts are completely consistent.

## Step-by-Step Student Instructions

1. **Execute the Script:** Run `python main.py` in your terminal.
2. **Review Terminal Output:** Read each printed line carefully and verify all numbers match the table above.
3. **Open `outputs/metrics.txt`:** View the file using your code editor or `cat outputs/metrics.txt`. Notice the higher precision recorded for each figure.
4. **Open `outputs/actual_vs_predicted.png`:** View the image using an image viewer or code editor preview.
5. **Cross-Check the Artifacts:** Verify that the high $R^2$ (0.93) corresponds to the tight clustering visible in the plot, and that the calculated prediction ($15,077) matches the equation parameters.

## Expected Output or Observable Behaviour

Executing `main.py` yields the formatted console banner, writes `outputs/metrics.txt` with six key-value pairs, and saves a 6x6 inch PNG image `outputs/actual_vs_predicted.png` showing 12 test points clustered tightly along the red dashed line.

## Practical Exercises

- **Exercise 2.1:** Using the coefficients in `metrics.txt`, calculate the predicted price of a 3-year-old car with 35,000 km.
- **Exercise 2.2:** What would happen to the predicted price if a car had 300,000 km on the odometer? Calculate the result and explain why linear regression can eventually predict negative car prices.
- **Exercise 2.3:** Why is saving high-precision floats to `metrics.txt` preferable to saving rounded numbers (like `-0.09`)? Recompute the 60,000 km depreciation using `-0.09` vs `-0.092223` and measure the dollar difference.

## Common Mistakes and Debugging

| Mistake | Why it happens | How to avoid or fix |
|---|---|---|
| Assuming console and file values disagree | Seeing `$15,077` on the console and `15076.97` in the file. | Recognize that console output is rounded for human readability (`:,.0f`), while `metrics.txt` preserves fractional cents (`:.2f`). |
| Trusting metrics without viewing the plot | A high $R^2$ can occasionally hide non-linear patterns or leverage points. | Always inspect `actual_vs_predicted.png` to confirm errors are evenly distributed across the entire price range. |
| Overwriting artifacts inadvertently | Running tests without backing up baseline files. | Include timestamping or version control in production logging systems. |

## Best Practices and Security Considerations

- **Dual-Audience Artifact Generation:** Always structure pipelines to output both human-friendly summaries (terminal/plots) and machine-readable logs (JSON/plain text) simultaneously.
- **Sanity Auditing:** Implement automated test assertions that cross-verify that the predictions generated by `model.predict()` match the manual arithmetic evaluation of `model.coef_` and `model.intercept_`.
- **Artifact Immutability:** Set write permissions on output directories in production environments so that previous model evaluation logs cannot be overwritten or altered.

## Summary

In Lesson 02, we synthesized and cross-validated all three output streams generated by "The Used Car Price Whisperer": the terminal summary report, the `actual_vs_predicted.png` diagnostic plot, and the persisted `outputs/metrics.txt` file. We verified how the learned parameters ($26,818 intercept, -$1,242/year, and -$922/10,000 km) combine to predict vehicle values, verified the $15,077 benchmark prediction, and confirmed that the model exhibits high accuracy and minimal valuation bias across all price brackets.

## Knowledge-check Questions

1. What are the three primary output streams produced by `main.py`?
2. What is the baseline starting price (intercept) recorded in `outputs/metrics.txt`?
3. How much value does a car lose for every additional 10,000 km driven according to the model?
4. What is the predicted price for a 5-year-old car with 60,000 km, rounded to the nearest dollar?
5. Why does `metrics.txt` record `15076.97` while the terminal displays `$15,077`?

## References

- [main.py lines 48-81](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML%20Beginners/projects/07_car_price/main.py#L48-L81)
- [Scikit-learn Model Persistence Documentation](https://scikit-learn.org/stable/model_persistence.html)
- [Data Science Workflow: Reporting and Metric Logging](https://towardsdatascience.com/)
