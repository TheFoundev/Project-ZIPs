# Module 6 Exercises: Complete Pipeline & Extensions

## Exercise 6.1: Automated End-to-End Pipeline Validation (15 min)
**Objective:** Run `main.py` programmatically and verify that all generated artifacts meet technical standards.  
**Problem Statement:** In automated deployment systems, pipelines are triggered by batch runners. You must write an end-to-end verification script that executes `main.py` as a subprocess and validates all output files.

**Requirements:**
1. Write a Python script `verify_pipeline.py`.
2. Use `subprocess.run()` to execute `main.py`.
3. Assert that the return code is `0` (success).
4. Verify that `outputs/actual_vs_predicted.png` exists and has a file size greater than 10 KB.
5. Verify that `outputs/metrics.txt` exists and contains all 6 expected keys (`intercept`, `age coefficient`, `km coefficient`, `MAE`, `R2`, `example prediction`).
6. Print a verification report confirming end-to-end pipeline health.

**Constraints:** Do not modify the original `main.py`. Use Python's standard `subprocess` and `pathlib` modules.

**Expected Behaviour:** The verification script runs `main.py`, checks artifacts, and reports complete pipeline integrity.

**Acceptance Criteria:**
- [ ] Successfully executes `main.py` via subprocess.
- [ ] Confirms return code equals 0.
- [ ] Confirms PNG exists and is not empty.
- [ ] Confirms text file contains all 6 required metric lines.

**Hints:**
- Use `subprocess.run([sys.executable, "main.py"], capture_output=True, text=True)`.
- Use `.stat().st_size` from pathlib to check image size.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 6.2: Engineering the `fuel_type` Categorical Feature (25 min)
**Objective:** Extend the Used Car Price Whisperer dataset with a categorical `fuel_type` feature and train a 3-feature regression model.  
**Problem Statement:** In line 81 of `main.py`, the author suggests: *"Try this: add a 'fuel_type' column (petrol/diesel) and think about encoding it."* You will implement this extension.

**Requirements:**
1. Load `data/used_cars.csv`.
2. Add a `fuel_type` column where cars with even indices are `"petrol"` and odd indices are `"diesel"`.
3. Apply One-Hot Encoding using `pd.get_dummies(df, columns=["fuel_type"], drop_first=True, dtype=int)`.
4. Construct a 3-feature matrix `X` containing `age_years`, `kilometers`, and the encoded fuel dummy column.
5. Perform a 75/25 train/test split with `random_state=42`.
6. Fit a `LinearRegression` model and print the three coefficients and intercept.
7. Print an interpretation of the fuel dummy coefficient: does diesel carry a premium or discount?

**Constraints:** You must drop the reference category (`drop_first=True`) to avoid the dummy variable trap.

**Expected Behaviour:** A script executing successfully, printing the updated regression equation and explaining the fuel coefficient.

**Acceptance Criteria:**
- [ ] Adds the categorical column and applies `drop_first=True`.
- [ ] Constructs a 3D feature matrix (45, 3).
- [ ] Fits the extended model strictly on the training partition.
- [ ] Prints all 3 learned weights and intercept.
- [ ] Provides an economic interpretation of the fuel type coefficient.

**Hints:**
- Check `df.columns` after `pd.get_dummies` to see the exact name of the generated column (e.g., `fuel_type_petrol` or `fuel_type_diesel`).
- Recall that the coefficient on the dummy variable represents an intercept shift.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 25 minutes  

---

## Exercise 6.3: Building a Production Valuation Function with Guardrails (20 min)
**Objective:** Build an inference function that handles edge cases, rejects invalid inputs, and enforces a scrap value floor.  
**Problem Statement:** The raw regression equation can output negative prices for extreme ages or distances. You must encapsulate the model in a robust, production-ready inference function.

**Requirements:**
1. Write a function `estimate_car_price(age_years: float, kilometers: float) -> dict`.
2. Validate inputs:
   - Raise a `ValueError` if `age_years < 0` or `kilometers < 0`.
   - Issue a warning if `age_years > 15` or `kilometers > 250_000` stating that the query extrapolates beyond training boundaries.
3. Compute the raw linear regression price using the learned parameters ($\beta_0 = 26817.96, \beta_1 = -1241.53, \beta_2 = -0.092223$).
4. Implement a scrap floor: if the raw price is below $1,000, clamp the returned price to $1,000.
5. Return a dictionary containing:
   - `raw_price`: Unconstrained linear calculation
   - `final_price`: Clamped valuation
   - `floor_applied`: Boolean indicating whether scrap floor was triggered
   - `confidence`: `"high"` for normal inputs, `"extrapolated"` for extreme inputs
6. Test your function with three vehicles:
   - A normal car: 5 years, 60,000 km
   - An extreme car: 25 years, 350,000 km
   - An invalid input: -2 years, 50,000 km (assert ValueError is raised)

**Constraints:** Follow PEP 8 style guidelines and include complete docstrings.

**Expected Behaviour:** The function safely processes all queries, clamps negative prices to $1,000, and raises descriptive errors for impossible inputs.

**Acceptance Criteria:**
- [ ] Function signature and type hints properly defined.
- [ ] Validates non-negative inputs and raises `ValueError`.
- [ ] Emits extrapolation warnings for extreme inputs.
- [ ] Clamps sub-$1,000 valuations to the $1,000 scrap floor.
- [ ] Returns complete dictionary with all 4 required fields.

**Hints:**
- Use Python's built-in `warnings.warn()` for domain boundary alerts.
- Use `max(1000.0, raw_price)` for clean clamping.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 20 minutes  
