# Glossary: The Used Car Price Whisperer

| Term | Definition |
|---|---|
| **Multiple Linear Regression** | A supervised regression algorithm that models the linear relationship between two or more independent features and a continuous dependent target variable. |
| **Supervised Learning** | A machine learning paradigm where the algorithm learns from labeled training examples containing known inputs ($X$) and ground-truth targets ($y$). |
| **Feature Matrix ($X$)** | The 2D array or DataFrame containing the independent input variables (in this project, `age_years` and `kilometers`) used to make predictions. |
| **Target Vector ($y$)** | The 1D array or Series containing the continuous numerical quantity we want to predict (in this project, `price_usd`). |
| **Train/Test Split** | The process of dividing historical data into separate training and testing subsets to evaluate how well a model generalizes to unseen data. |
| **Random State** | A seed provided to pseudo-random number generators (such as in `train_test_split`) to ensure data partitions and experimental results are strictly reproducible. |
| **Ordinary Least Squares (OLS)** | The mathematical method used by linear regression to estimate parameters by minimizing the sum of squared residuals between observed and predicted values. |
| **Intercept ($\beta_0$)** | The expected baseline value of the target variable when all input features equal zero ($age = 0, km = 0$). |
| **Regression Coefficient / Weight ($\beta_i$)** | The rate of change in the target variable per one-unit increase in a specific feature, holding all other features constant. |
| **Residual** | The difference between the actual observed value and the model's predicted value for a specific observation ($e_i = y_i - \hat{y}_i$). |
| **Mean Absolute Error (MAE)** | The average of the absolute differences between actual and predicted values. MAE retains the identical physical unit as the target ($). |
| **$R^2$ (Coefficient of Determination)** | The proportion of variance in the target variable that is predictable from the independent features, relative to a baseline mean predictor. |
| **Actual-vs-Predicted Plot** | A 2D scatter plot comparing actual ground-truth values on the horizontal axis against model predictions on the vertical axis. |
| **Perfect Prediction Line** | The 45-degree diagonal reference line ($y = x$) on an actual-vs-predicted plot where predicted values exactly match observed values. |
| **Overestimation** | A prediction where the model's estimate exceeds the actual value ($\hat{y} > y$), plotting above the 45-degree diagonal. |
| **Underestimation** | A prediction where the model's estimate is lower than the actual value ($\hat{y} < y$), plotting below the 45-degree diagonal. |
| **One-Hot Encoding** | A technique for converting categorical attributes (such as `"petrol"` and `"diesel"`) into binary indicator columns containing `0` or `1`. |
| **Dummy Variable Trap** | A condition of perfect multicollinearity occurring when all $k$ category dummy columns are included alongside an intercept term. Solved by dropping one reference column ($k-1$). |
| **Multicollinearity** | A state where two or more independent features in a regression model are highly correlated, reducing the stability of individual coefficient estimates. |
| **Depreciation** | The reduction in an asset's monetary value over time due to wear, aging, obsolescence, or distance traveled. |
| **Salvage Floor** | The minimum positive residual value a motor vehicle retains for its utility or scrap metal value, preventing real prices from reaching zero or negative values. |
