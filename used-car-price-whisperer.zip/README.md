# The Used Car Price Whisperer

## Overview
This project builds a **Multiple Linear Regression** model to predict used car market prices based on vehicle age and cumulative kilometers driven. Using the actual dataset `data/used_cars.csv` from [`beginner-projects-main/AI-ML Beginners/projects/07_car_price/`](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML%20Beginners/projects/07_car_price/), you will learn how multiple input features combine into a single pricing equation, extract and interpret physical depreciation rates, evaluate model performance with MAE and $R^2$, and generate diagnostic scatter plots.

## Real-World Use Case
In automotive dealerships, auto-financing banks, insurance firms, and online used car marketplaces (such as Carvana, Autotrader, or Kelley Blue Book), estimating fair vehicle trade-in and retail prices is critical. Rather than relying on guesswork or static rules of thumb, machine learning extracts empirical depreciation patterns directly from historical transactions.

## Features (Implemented)
- **Data Ingestion:** Load 45 historical used car transaction records from CSV (`age_years`, `kilometers`, `price_usd`).
- **Feature/Target Separation:** Construct a 2D feature matrix $X$ and a 1D target vector $y$.
- **Reproducible Partitioning:** Split dataset into 75% training (33 cars) and 25% testing (12 cars) using `random_state=42`.
- **Multiple Regression Training:** Fit an Ordinary Least Squares `LinearRegression` model using scikit-learn.
- **Coefficient Deconstruction:** Extract and interpret baseline starting price ($26,818), annual aging depreciation (-$1,242/year), and odometer distance depreciation (-$922 per 10,000 km).
- **Test Set Evaluation:** Quantify predictive accuracy with Mean Absolute Error (MAE ≈ $906) and coefficient of determination ($R^2 \approx 0.93$).
- **Single-Vehicle Inference:** Estimate the price of a custom benchmark vehicle (5 years old, 60,000 km → $15,077).
- **Visual Diagnostics:** Generate a 6x6 actual-vs-predicted scatter plot with a 45-degree dashed red "perfect prediction" line.
- **Metric Persistence:** Export clean, high-precision parameters to `outputs/metrics.txt` for auditability.

## Technology Stack
- **Python 3.8+**
- **pandas** (Tabular data loading and slicing)
- **scikit-learn** (LinearRegression, train_test_split, mean_absolute_error, r2_score)
- **matplotlib** (Agg non-interactive visualization)
- **pathlib** (Robust cross-platform path resolution)

## System Requirements
- Operating System: Linux, macOS, or Windows
- Python: Version 3.8 or higher
- Package Manager: `pip`

## Installation Instructions
```bash
cd "/home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price"
pip install pandas scikit-learn matplotlib
python main.py
```

## Project Structure (Actual)
```
07_car_price/
├── main.py
├── data/
│   └── used_cars.csv
└── outputs/
    ├── actual_vs_predicted.png
    └── metrics.txt
```

## How It Works
1. Configures headless matplotlib backend (`Agg`) and ensures `outputs/` exists.
2. Ingests `data/used_cars.csv` with columns `age_years`, `kilometers`, and `price_usd`.
3. Defines 2D feature matrix `X = df[["age_years", "kilometers"]]` and 1D target vector `y = df["price_usd"]`.
4. Splits samples via `train_test_split(X, y, test_size=0.25, random_state=42)`.
5. Fits `LinearRegression()` on `X_train` and `y_train`.
6. Predicts on `X_test` and computes MAE ($906) and $R^2$ (0.93).
7. Evaluates the equation for a 5-year-old car with 60,000 km ($15,077).
8. Plots test actuals against model predictions and exports `outputs/actual_vs_predicted.png`.
9. Writes parameters and evaluation results to `outputs/metrics.txt`.

## Expected Output
```text
============================================================
THE USED CAR PRICE WHISPERER
============================================================
Equation: price = 26,818 + (-1,242 x age) + (-0.09 x km)
Each extra year is associated with about $1,242 less value.
Each extra 10,000 km is associated with about $922 less value.
Mean absolute error: $906
R-squared: 0.93
Prediction for a 5-year-old car with 60,000 km: $15,077

Saved: outputs/actual_vs_predicted.png, outputs/metrics.txt
Try this: add a 'fuel_type' column (petrol/diesel) and think about encoding it.
```

## Security & Reliability Considerations
- Non-interactive `matplotlib.use("Agg")` ensures execution in headless server environments without X11 or Wayland displays.
- `Path(__file__).resolve().parent` guarantees script resilience regardless of working directory.
- `with open(...)` with explicit `encoding="utf-8"` guarantees safe file closure and consistent cross-platform encoding.
