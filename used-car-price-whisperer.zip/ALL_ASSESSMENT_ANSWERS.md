# All Correct Answers for Assessments
Project: The Used Car Price Whisperer
---

## Module 01: Project Overview: Used Car Market & The Prediction Problem
**q1-01.** In 'The Used Car Price Whisperer' project, what is the target variable (y) we want to predict?
   **Correct Answer:** b. price_usd
   *Explanation:* The target variable (y) is price_usd. The purpose of the project is to predict the continuous market value in dollars of a used car based on its attributes.

**q1-02.** Which file contains the historical sales dataset loaded by main.py?
   **Correct Answer:** b. data/used_cars.csv
   *Explanation:* The dataset is stored in data/used_cars.csv and loaded using pd.read_csv(DATA / 'used_cars.csv').

**q1-03.** Which two columns in used_cars.csv are used as the input features (X)?
   **Correct Answer:** c. age_years and kilometers
   *Explanation:* age_years and kilometers are the two columns selected into the feature matrix X. They represent the two independent clues used to predict price.

**q1-04.** Why is predicting used car price considered a regression task rather than a classification task?
   **Correct Answer:** b. Because car prices are continuous numerical values
   *Explanation:* Regression is defined by predicting continuous numeric values (such as dollar prices). Classification predicts discrete categorical classes (such as 'compact' vs. 'SUV').

**q1-05.** What distinguishes multiple linear regression from simple linear regression?
   **Correct Answer:** b. Multiple linear regression uses two or more input features to predict a target
   *Explanation:* Multiple linear regression extends simple linear regression by using two or more independent features (here, age and kilometers) to estimate a single dependent target.

**q1-06.** In main.py, how is the feature matrix X extracted, and what is its shape on the full dataset?
   **Correct Answer:** b. X = df[['age_years', 'kilometers']] with shape (45, 2)
   *Explanation:* Double brackets df[['age_years', 'kilometers']] extract a 2D DataFrame containing 45 rows and 2 columns, yielding shape (45, 2).

**q1-07.** What are the exact specifications of the benchmark vehicle that main.py evaluates?
   **Correct Answer:** b. 5 years old with 60,000 km
   *Explanation:* main.py explicitly defines the benchmark vehicle as a 5-year-old car with 60,000 km: example = pd.DataFrame([{'age_years': 5, 'kilometers': 60_000}]).

**q1-08.** Which of the following best explains why this project is categorized as 'supervised' learning?
   **Correct Answer:** b. The model learns from historical records containing both input features and known ground-truth selling prices
   *Explanation:* Supervised learning algorithms learn relationships from labeled historical examples where both input features (X) and ground-truth targets (y) are provided.

**q1-09.** Why are the learned coefficients for age and mileage in the pricing model expected to have negative signs?
   **Correct Answer:** b. Because older cars and higher mileage are associated with asset depreciation, decreasing market value
   *Explanation:* In used car economics, increased chronological age and cumulative mileage cause physical wear and technological obsolescence (depreciation), reducing market value. Hence, their weights are negative.

**q1-10.** Geometrically, what does multiple linear regression with two features (age and kilometers) fit through the 3D data points?
   **Correct Answer:** b. A 2-dimensional flat plane
   *Explanation:* With 2 input features (X1, X2) and 1 target (y), the feature-target space is 3-dimensional. A linear equation y = b0 + b1*x1 + b2*x2 defines a 2-dimensional flat plane through this 3D space.


## Module 02: Data Loading & Exploratory Analysis
**q2-01.** What does the expression 'BASE = Path(__file__).resolve().parent' achieve in main.py?
   **Correct Answer:** b. It establishes a portable, absolute path to the directory containing main.py
   *Explanation:* BASE = Path(__file__).resolve().parent resolves the exact absolute path to the directory where main.py resides, ensuring the script can run portably from any working directory.

**q2-02.** Why does main.py call 'matplotlib.use("Agg")' before importing pyplot?
   **Correct Answer:** c. To use a headless raster graphics engine that avoids display errors on servers and batch environments
   *Explanation:* matplotlib.use('Agg') selects a non-interactive raster backend that generates images without attempting to open an X11/GUI display window, preventing crashes on servers and CLI terminals.

**q2-03.** Which pandas function is used in main.py to load the dataset from disk?
   **Correct Answer:** b. pd.read_csv()
   *Explanation:* pd.read_csv() is the standard pandas function used to ingest comma-separated values files into a DataFrame.

**q2-04.** What is the exact shape of the DataFrame 'df' loaded from used_cars.csv?
   **Correct Answer:** c. (45, 3)
   *Explanation:* The dataset contains 45 data rows (excluding the header) and 3 columns (age_years, kilometers, price_usd), resulting in df.shape == (45, 3).

**q2-05.** Which pandas method generates count, mean, standard deviation, min, quartiles, and max in a single tabular display?
   **Correct Answer:** c. df.describe()
   *Explanation:* df.describe() computes summary statistics including count, mean, std, min, 25%, 50% (median), 75%, and max for all numerical columns.

**q2-06.** What is the median selling price (50th percentile) of vehicles in used_cars.csv?
   **Correct Answer:** b. $10,063
   *Explanation:* From df.describe(), the 50th percentile (median) of price_usd is exactly $10,063.

**q2-07.** What does the parameter 'exist_ok=True' do when calling 'OUT.mkdir(exist_ok=True)'?
   **Correct Answer:** b. It prevents FileExistsError if the directory already exists
   *Explanation:* exist_ok=True suppresses the FileExistsError that would otherwise be raised if the directory already exists, ensuring idempotent execution.

**q2-08.** What is the Pearson correlation between age_years and price_usd in the used cars dataset?
   **Correct Answer:** b. -0.75
   *Explanation:* The Pearson correlation between age_years and price_usd is approximately -0.749 (or -0.75), indicating a strong negative relationship where older cars sell for less money.

**q2-09.** What is the Pearson correlation between the two features, age_years and kilometers?
   **Correct Answer:** c. Approximately +0.0035 (virtually zero)
   *Explanation:* In this dataset, the Pearson correlation between age_years and kilometers is +0.003550 (approximately +0.0035), indicating that the two features are practically uncorrelated.

**q2-10.** Why is the near-zero correlation between age_years and kilometers particularly beneficial for multiple linear regression?
   **Correct Answer:** b. It indicates the features provide non-overlapping, independent information about price without multicollinearity
   *Explanation:* Near-zero correlation between predictors means each feature contributes orthogonal, independent information to the model without suffering from multicollinearity, maximizing the predictive power of multiple linear regression.


## Module 03: Multiple Linear Regression & Multicollinearity
**q3-01.** What is the general mathematical equation for a multiple linear regression model with two features?
   **Correct Answer:** b. y = β0 + (β1 * x1) + (β2 * x2)
   *Explanation:* The multiple linear regression equation for two features is y = β0 + (β1 * x1) + (β2 * x2), where β0 is the intercept and β1, β2 are the respective feature weights.

**q3-02.** In the learned equation 'price = 26,818 + (-1,242 x age) + (-0.09 x km)', what does the intercept ($26,818) represent?
   **Correct Answer:** b. The estimated baseline price of a brand-new vehicle with 0 years and 0 km
   *Explanation:* The intercept represents the expected value of y when all input features equal zero. For a car with age = 0 years and distance = 0 km, the model estimates a brand-new vehicle price of $26,818.

**q3-03.** What shape does scikit-learn strictly require for the feature matrix X in linear regression?
   **Correct Answer:** b. A 2-dimensional structure of shape (n_samples, n_features)
   *Explanation:* Scikit-learn requires the feature matrix X to have 2 dimensions: (n_samples, n_features). Even for a single feature, it must be shaped as (N, 1).

**q3-04.** Which pandas syntax correctly extracts 'age_years' and 'kilometers' as a 2D DataFrame for scikit-learn?
   **Correct Answer:** b. df[['age_years', 'kilometers']]
   *Explanation:* df[['age_years', 'kilometers']] uses double brackets (passing a list of strings), which extracts a 2D pandas DataFrame conforming to scikit-learn's input requirement.

**q3-05.** In a 3D coordinate space where axes are age, kilometers, and price, what geometric object represents the regression model?
   **Correct Answer:** b. A 2-dimensional flat plane
   *Explanation:* In a 3D coordinate space spanned by two input features (X1, X2) and one target (Y), the linear equation defines a 2-dimensional flat plane.

**q3-06.** What does the age coefficient (-$1,241.53) mean in economic terms?
   **Correct Answer:** b. Holding odometer mileage constant, each additional year of vehicle age is associated with ~$1,242 lower market value
   *Explanation:* The partial regression coefficient isolates the marginal effect of that specific feature while holding all other features constant. Holding kilometers constant, each extra year reduces price by ~$1,242.

**q3-07.** What error occurs if you pass a 1D pandas Series 'df["age_years"]' directly into 'LinearRegression().fit(X, y)'?
   **Correct Answer:** b. ValueError: Expected 2D array, got 1D array instead
   *Explanation:* Scikit-learn validates input dimensions inside check_array() and raises 'ValueError: Expected 2D array, got 1D array instead' whenever X.ndim != 2.

**q3-08.** What is multicollinearity in the context of multiple linear regression?
   **Correct Answer:** b. When two or more independent features are highly linearly correlated with each other
   *Explanation:* Multicollinearity occurs when two or more input features in a multiple regression model exhibit high linear correlation with each other, making it difficult to isolate their individual effects.

**q3-09.** Why is severe multicollinearity problematic when interpreting regression models?
   **Correct Answer:** a. It inflates coefficient variance and makes individual feature weights unstable and erratic
   *Explanation:* Multicollinearity inflates the standard errors of coefficient estimates, making weights highly sensitive to minor sampling fluctuations and rendering individual marginal interpretations unreliable.

**q3-10.** Why does combining age and kilometers improve the model's test R² score from ~0.48 to ~0.93?
   **Correct Answer:** b. Because age and kilometers are virtually uncorrelated (r ≈ 0.0035), providing complementary, non-redundant information about value erosion
   *Explanation:* Because age and kilometers are virtually uncorrelated (r ≈ 0.0035), each feature supplies unique, non-overlapping information about vehicle wear. Combining them explains ~93% of price variation, far exceeding single-feature models.


## Module 04: Model Training & Coefficient Interpretation
**q4-01.** In main.py, what proportion of the data is allocated to the test set by train_test_split?
   **Correct Answer:** b. 25% (test_size=0.25)
   *Explanation:* In main.py line 33, test_size=0.25 specifies that 25% of the dataset is allocated for testing, while the remaining 75% is used for model training.

**q4-02.** How many rows are assigned to X_train and X_test respectively after splitting the 45 records?
   **Correct Answer:** b. 33 in train, 12 in test
   *Explanation:* With 45 total rows and a 0.25 test fraction, 45 * 0.25 = 11.25 rounds to 12 test rows, leaving 45 - 12 = 33 training rows.

**q4-03.** Which method is called on the LinearRegression object to train the model?
   **Correct Answer:** b. model.fit(X_train, y_train)
   *Explanation:* In scikit-learn, all estimators implement .fit() to perform training and parameter estimation.

**q4-04.** What is the primary function of setting 'random_state=42' in train_test_split?
   **Correct Answer:** b. It ensures that the random data split is exactly reproducible every time the script runs
   *Explanation:* Setting random_state to a fixed integer (42) initializes the pseudo-random number generator to produce the exact same row shuffle every time, ensuring experimental reproducibility.

**q4-05.** What data structure and shape does 'model.coef_' have after fitting on two features?
   **Correct Answer:** b. A 1D NumPy ndarray of shape (2,)
   *Explanation:* After fitting on 2 features, model.coef_ is a 1D NumPy ndarray with 2 elements: [age_weight, km_weight], having shape (2,).

**q4-06.** According to the trained model output, approximately how much value does a car lose for each extra year of age?
   **Correct Answer:** c. $1,242
   *Explanation:* The learned age coefficient is approximately -1241.53, which rounds to about $1,242 of value loss per year.

**q4-07.** According to the model, approximately how much value does a car lose for each additional 10,000 kilometers driven?
   **Correct Answer:** a. $922
   *Explanation:* The mileage coefficient is approximately -0.092223 per kilometer. Multiplied by 10,000 km, this equals about $922 of value loss.

**q4-08.** What mathematical criterion does Ordinary Least Squares (OLS) minimize during the .fit() call?
   **Correct Answer:** b. The Residual Sum of Squares (RSS) between actual and predicted target values
   *Explanation:* Ordinary Least Squares finds the hyperplane that minimizes the Residual Sum of Squares (RSS), which is the sum of squared differences between actual y and predicted y.

**q4-09.** What is the exact unpacking order returned by scikit-learn's 'train_test_split(X, y)'?
   **Correct Answer:** b. X_train, X_test, y_train, y_test
   *Explanation:* train_test_split strictly returns in the order: X_train, X_test, y_train, y_test. Swapping this order assigns feature arrays to target variables, causing runtime errors.

**q4-10.** Based on the learned model weights ($1,241.53/year and $0.092223/km), how many kilometers driven produce the same economic depreciation as 1 year of age?
   **Correct Answer:** c. Approximately 13,462 km
   *Explanation:* Dividing the annual age depreciation ($1,241.53) by the per-kilometer rate ($0.092223) yields 1,241.53 / 0.092223 ≈ 13,462 km.


## Module 05: Evaluation, Metrics & Visualization
**q5-01.** What does Mean Absolute Error (MAE) measure in 'The Used Car Price Whisperer' project?
   **Correct Answer:** b. The average absolute difference in dollars between actual sales prices and predicted prices
   *Explanation:* Mean Absolute Error (MAE) computes the average absolute distance between true actual car prices and predicted car prices across all evaluation samples. It measures typical error magnitude in original dollar units.

**q5-02.** What is the physical unit of measurement for Mean Absolute Error (MAE) in this project?
   **Correct Answer:** c. US Dollars ($)
   *Explanation:* MAE preserves the exact physical unit of the target variable. Because price_usd is denominated in US dollars ($), MAE is expressed directly in US dollars ($).

**q5-03.** What is the approximate Mean Absolute Error printed by main.py on the 12-car test split?
   **Correct Answer:** b. $906
   *Explanation:* Executing main.py computes an MAE of 905.97 on the 12-sample test split, which is formatted and displayed on the console as $906.

**q5-04.** What does an R-squared score of 0.93 (or 0.9280) mean for our used car pricing model?
   **Correct Answer:** b. Vehicle age and kilometers explain approximately 93% of the variance in used car selling prices
   *Explanation:* R-squared represents the proportion of variance in the dependent target variable (car price) explained by the independent features (age and kilometers) in the linear model. An R² of 0.93 means 93% of the price variability is explained.

**q5-05.** What does the red dashed diagonal line represent in the actual-vs-predicted plot generated by main.py?
   **Correct Answer:** c. The perfect prediction line where predicted price equals actual price (y = x)
   *Explanation:* The red dashed line is plotted from [low, high] to [low, high], representing the 45-degree line of perfect prediction where predicted price exactly equals actual price (y = x).

**q5-06.** If a data point lies ABOVE the red dashed diagonal line in the actual-vs-predicted plot, what does this indicate about the prediction?
   **Correct Answer:** b. The model overestimated the vehicle's price (predicted price > actual price)
   *Explanation:* In an actual-vs-predicted plot, the vertical Y-axis represents Predicted Price while the horizontal X-axis represents Actual Price. A point lying above the line y = x has Predicted > Actual, indicating the model overestimated the vehicle's price.

**q5-07.** If a data point lies BELOW the red dashed diagonal line in the actual-vs-predicted plot, what does this indicate about the prediction?
   **Correct Answer:** a. The model underestimated the vehicle's price (predicted price < actual price)
   *Explanation:* A point lying below the diagonal line has Predicted < Actual (Y < X), meaning the model's valuation was lower than what the vehicle actually commanded in the market (underestimation).

**q5-08.** Why is a square figure dimension (figsize=(6, 6)) used when generating the actual-vs-predicted scatter plot?
   **Correct Answer:** b. It ensures a 1:1 aspect ratio so the diagonal reference line forms an undistorted 45-degree angle
   *Explanation:* A 1:1 aspect ratio created by figsize=(6, 6) ensures that a 45-degree angle represents an equal scale on both axes. Rectangular figures distort visual slope angles, making predictions appear artificially closer or farther from the reference line.

**q5-09.** Why is the kilometer coefficient in outputs/metrics.txt saved with six decimal places (:.6f) instead of two (:.2f)?
   **Correct Answer:** b. The depreciation per individual kilometer is a fraction of a cent (-$0.092223), so rounding to two decimal places would cause significant loss of precision
   *Explanation:* The impact of a single kilometer on car price is small (-$0.092223). Formatting with only two decimal places (-0.09) loses precision, and rounding to one or zero decimal places would distort predictions over tens of thousands of kilometers.

**q5-10.** Why does main.py call plt.close(fig) immediately after saving outputs/actual_vs_predicted.png?
   **Correct Answer:** b. To close open file descriptors and release memory consumed by the figure object
   *Explanation:* plt.close(fig) frees the underlying GUI or canvas resources and memory retained by matplotlib. In automated scripts, neglecting this can lead to memory leakage as multiple figures accumulate in RAM.


## Module 06: Complete Pipeline & Extensions
**q6-01.** What command executes the complete Used Car Price Whisperer pipeline from the terminal?
   **Correct Answer:** b. python main.py
   *Explanation:* The project is executed from the terminal using the command 'python main.py', as documented in the docstring on line 4 of main.py.

**q6-02.** What is the primary architectural purpose of using `if __name__ == '__main__': main()` in main.py?
   **Correct Answer:** b. It allows the script to run when called directly while permitting functions to be imported into other scripts without executing main()
   *Explanation:* The idiom checks if the module is executed directly as the entry point (__name__ == '__main__'). If true, it runs main(); if imported into another module, it prevents automatic execution while exposing functions.

**q6-03.** Which two output artifacts are created inside the outputs/ directory by main.py?
   **Correct Answer:** b. actual_vs_predicted.png and metrics.txt
   *Explanation:* main.py creates and saves outputs/actual_vs_predicted.png (the diagnostic plot) and outputs/metrics.txt (the model parameters and evaluation report).

**q6-04.** Why can string categories such as 'petrol' and 'diesel' not be supplied directly to scikit-learn's LinearRegression?
   **Correct Answer:** b. Linear regression performs arithmetic operations (multiplications and additions) which are mathematically undefined on strings
   *Explanation:* Linear regression fits a mathematical plane using matrix multiplication and dot products. Mathematical algorithms cannot perform numerical arithmetic on raw strings like 'petrol' or 'diesel'.

**q6-05.** Why is assigning arbitrary integers (e.g., petrol=1, diesel=2) fundamentally flawed for nominal categorical features in linear models?
   **Correct Answer:** b. It imposes an artificial numerical ordering and distance assumption (e.g., diesel is twice petrol) where none exists
   *Explanation:* Mapping nominal categories to arbitrary integers (1, 2, 3...) introduces an artificial order and mathematical magnitude that does not exist in reality, distorting regression equations.

**q6-06.** What is the 'Dummy Variable Trap' in multiple linear regression?
   **Correct Answer:** b. Perfect multicollinearity caused by including all k category dummy columns along with an intercept, making the matrix non-invertible
   *Explanation:* The dummy variable trap occurs when all k category dummies are included alongside an intercept term. Because their sum equals 1.0 (the constant column), it creates perfect multicollinearity, making the matrix singular and non-invertible.

**q6-07.** In pandas, which function and parameter combination converts a categorical column into binary dummy variables while safely avoiding the dummy variable trap?
   **Correct Answer:** b. pd.get_dummies(df, columns=['fuel_type'], drop_first=True)
   *Explanation:* pd.get_dummies(df, columns=['fuel_type'], drop_first=True) automatically creates binary indicator columns while dropping the first category to avoid the dummy variable trap.

**q6-08.** How does the coefficient of a binary dummy variable (e.g., is_diesel) affect the multiple regression equation geometrically?
   **Correct Answer:** b. It shifts the intercept up or down, creating parallel regression planes for different categories
   *Explanation:* In linear regression, a dummy variable acts as an intercept shifter. When active (1), its coefficient is added directly to the baseline intercept, shifting the regression plane vertically parallel to the baseline.

**q6-09.** Why does multiple linear regression produce impossible negative price predictions when evaluating a 25-year-old car with 350,000 km?
   **Correct Answer:** a. Because linear regression assumes depreciation continues at a constant straight-line rate forever without a salvage floor
   *Explanation:* Multiple linear regression assumes a constant, unbending rate of depreciation. Because it does not incorporate a salvage floor or logarithmic decay, sufficiently large values of age and kilometers cause deductions to exceed the starting intercept, predicting negative prices.

**q6-10.** Which family of machine learning algorithms is standard in modern commercial car pricing platforms to handle non-linear curves, missing values, and complex interactions?
   **Correct Answer:** b. Gradient Boosted Decision Trees (e.g., XGBoost, LightGBM, CatBoost)
   *Explanation:* Gradient Boosted Decision Trees (such as XGBoost, LightGBM, and CatBoost) are the industry standard for tabular data, effortlessly capturing non-linear curves, variable interactions, and price floors without requiring manual transformations.

