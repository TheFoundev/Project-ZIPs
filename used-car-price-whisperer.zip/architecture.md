# System Architecture: The Used Car Price Whisperer

## Pipeline Overview (from main.py)

The Used Car Price Whisperer is organized as an automated, deterministic machine learning pipeline that executes nine sequential stages:

1. **Environment & Backend Configuration:** Configures matplotlib headless backend (`Agg`) and imports core numerical and modeling libraries.
2. **Filesystem Path Resolution:** Dynamically resolves base paths with `pathlib.Path(__file__).resolve().parent` and initializes `outputs/`.
3. **Tabular Data Loading:** Ingests `data/used_cars.csv` containing 45 records of vehicle age, kilometers, and sales prices.
4. **Feature Matrix & Target Vector Separation:** Extracts 2D feature matrix $X \in \mathbb{R}^{45 \times 2}$ and 1D target vector $y \in \mathbb{R}^{45}$.
5. **Reproducible Holdout Partitioning:** Splits data into 75% training (33 samples) and 25% testing (12 samples) using `random_state=42`.
6. **Ordinary Least Squares Model Fitting:** Solves normal equations to fit linear parameters strictly on the training partition.
7. **Model Evaluation & Inference:** Generates test predictions, calculates MAE ($906) and $R^2$ (0.93), and infers the price of a 5-year-old car with 60,000 km.
8. **Diagnostic Visualization:** Plots actual vs. predicted prices with a 45-degree reference line and saves `actual_vs_predicted.png`.
9. **Metric Persistence & Reporting:** Formats and writes model weights and scores to `metrics.txt` and prints the final terminal summary.

---

## Architectural Data Flow

```mermaid
flowchart TD
    CSV["data/used_cars.csv (45 rows, 3 cols)"] --> Load["pd.read_csv()"]
    Load --> Separation["Feature / Target Split"]
    Separation --> X["Feature Matrix X (45 x 2)"]
    Separation --> Y["Target Vector y (45,)"]
    
    X --> Split["train_test_split(test_size=0.25, random_state=42)"]
    Y --> Split
    
    Split --> Xtrain["X_train (33 x 2)"]
    Split --> Ytrain["y_train (33,)"]
    Split --> Xtest["X_test (12 x 2)"]
    Split --> Ytest["y_test (12,)"]
    
    Xtrain --> Fit["LinearRegression().fit()"]
    Ytrain --> Fit
    
    Fit --> Model["Trained Model (Weights & Intercept)"]
    
    Model --> Predict["model.predict(X_test)"]
    Xtest --> Predict
    Predict --> Preds["Test Predictions (12,)"]
    
    Preds --> Eval["Metrics: MAE & R2"]
    Ytest --> Eval
    
    Model --> SinglePred["Predict: 5 yr, 60k km"]
    SinglePred --> BenchmarkVal["$15,077"]
    
    Preds --> Plot["Diagnostic Scatter Plot"]
    Ytest --> Plot
    Plot --> PNG["outputs/actual_vs_predicted.png"]
    
    Eval --> Persist["File Persistence"]
    Model --> Persist
    BenchmarkVal --> Persist
    Persist --> MetricsTxt["outputs/metrics.txt"]
    Persist --> Console["Terminal Summary Banner"]
```

---

## Key Components & Transformations

| Component | Input Shape / Type | Output Shape / Type | Operational Function |
|---|---|---|---|
| **Data Ingestion** | File path (`Path`) | DataFrame `(45, 3)` | Reads raw CSV into memory. |
| **Feature Extraction** | DataFrame `(45, 3)` | DataFrame `(45, 2)` & Series `(45,)` | Isolates input features from ground-truth price. |
| **Train/Test Split** | `(45, 2)` and `(45,)` | Train: `(33, 2)`, `(33,)` / Test: `(12, 2)`, `(12,)` | Isolates holdout test data to prevent evaluation leakage. |
| **OLS Estimator** | Train matrices | Model object (`coef_`, `intercept_`) | Minimizes sum of squared residuals to find optimal weights. |
| **Inference Engine** | 2D DataFrame `(1, 2)` | 1D float array `(1,)` | Calculates $\hat{y} = \beta_0 + \beta_1 x_1 + \beta_2 x_2$. |
| **Evaluation Engine** | Test actuals & predictions | Floats (`MAE`, $R^2$) | Quantifies dollar deviation and explained variance. |
| **Plotter** | Test actuals & predictions | PNG file (`150 dpi`) | Renders 45-degree diagnostic scatter plot. |
| **Persistence Engine** | Parameter & metric floats | Text file (`metrics.txt`) | Serializes results with strict precision formatting. |
