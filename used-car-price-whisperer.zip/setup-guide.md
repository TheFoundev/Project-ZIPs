# Setup Guide: The Used Car Price Whisperer

## Step 1: Navigate to the Project Directory
Open your terminal and navigate to the project directory:
```bash
cd "/home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price"
```

## Step 2: Verify Python Environment
Ensure Python 3.8 or higher is installed and active:
```bash
python3 --version
```

## Step 3: Install Required Dependencies
Install the required packages (`pandas`, `scikit-learn`, `matplotlib`):
```bash
pip install pandas scikit-learn matplotlib
```

Or using an explicit `requirements.txt`:
```txt
pandas>=1.3.0
scikit-learn>=1.0.0
matplotlib>=3.4.0
```
```bash
pip install -r requirements.txt
```

## Step 4: Inspect the Dataset
Verify that `data/used_cars.csv` is present and inspect the initial rows:
```bash
head -n 10 data/used_cars.csv
```
You should observe the three column headers: `age_years`, `kilometers`, `price_usd`.

## Step 5: Execute the Script
Run the complete machine learning pipeline:
```bash
python main.py
```

## Step 6: Verify Outputs
Check the terminal console output and confirm that the following two artifacts were created inside `outputs/`:
- `outputs/actual_vs_predicted.png`: Visual diagnostic scatter plot.
- `outputs/metrics.txt`: Saved model parameters and evaluation scores.

```bash
ls -la outputs/
cat outputs/metrics.txt
```

## Step 7: Troubleshooting
- **`ModuleNotFoundError: No module named 'sklearn'`**: Ensure you installed `scikit-learn`, not `sklearn` via pip: `pip install scikit-learn`.
- **`FileNotFoundError: data/used_cars.csv`**: Verify that you are running the script using `python main.py`. The script uses `Path(__file__).resolve().parent` to find files relative to its location.
- **GUI or Display Warning**: Matplotlib is explicitly configured to use `matplotlib.use("Agg")` on line 14, preventing display server errors in headless environments.
