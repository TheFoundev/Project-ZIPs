# The Used Car Price Whisperer (Multiple Linear Regression)

## Overview
This project applies **Multiple Linear Regression** to historical automotive transaction records to predict used car market valuations from vehicle age (in years) and odometer mileage (in kilometers). Located at [`beginner-projects-main/AI-ML Beginners/projects/07_car_price/`](file:///home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML%20Beginners/projects/07_car_price/), the project demonstrates how multiple continuous features combine linearly into a unified price estimate, extracts empirical depreciation rates, computes Mean Absolute Error (MAE) and $R^2$, and exports diagnostic visual and text artifacts.

## Real-World Use Case
Determining fair market value for pre-owned motor vehicles is fundamental to dealerships, auto lenders, insurance underwriters, and consumer marketplace platforms. By calibrating an Ordinary Least Squares multiple regression model against historical market transactions, the "Whisperer" establishes an objective, data-driven pricing engine that decouples valuation from static, arbitrary mental rules of thumb.

## Features (Implemented)
- **Data Ingestion**: Reads 45 real-world used car sales records from `data/used_cars.csv`.
- **Feature Matrix Separation**: Formulates 2D feature matrix `X = df[["age_years", "kilometers"]]` and 1D target vector `y = df["price_usd"]`.
- **Reproducible Holdout Partitioning**: Splits the 45 observations into 33 training samples (75%) and 12 testing samples (25%) using `random_state=42`.
- **Multiple Regression Fitting**: Fits an Ordinary Least Squares `LinearRegression` model using scikit-learn.
- **Physical Coefficient Interpretation**: Extracts baseline starting price ($\beta_0 \approx \$26,818$), annual depreciation ($\beta_1 \approx -\$1,242/\text{year}$), and distance depreciation ($\beta_2 \approx -\$0.092/\text{km}$ or $-\$922$ per $10,000$ km).
- **Comprehensive Evaluation**: Measures test error in dollars via Mean Absolute Error ($\text{MAE} \approx \$906$) and explained price variance via $R^2$ ($R^2 \approx 0.93$).
- **Benchmark Prediction**: Evaluates fair market value for a 5-year-old vehicle with 60,000 km ($\$15,077$).
- **Visual Diagnostic Artifact**: Generates a square 6x6 inch scatter plot comparing test actuals against predictions with a 45-degree dashed red "perfect prediction" reference line (`outputs/actual_vs_predicted.png`).
- **Metric Persistence**: Saves model parameters and performance scores to disk in `outputs/metrics.txt` for auditability and automated verification.

## Technology Stack
- **Language**: Python 3.8+
- **Data Manipulation**: pandas
- **Machine Learning**: scikit-learn (`LinearRegression`, `train_test_split`, `mean_absolute_error`, `r2_score`)
- **Plotting & Graphics**: matplotlib (non-interactive `Agg` backend)
- **Filesystem & I/O**: pathlib

## System Requirements
- Operating System: Linux, macOS, or Windows 10/11
- Python: Version 3.8 to 3.12+
- Disk Footprint: < 5 MB for source code, dataset, and generated artifacts

## Installation Instructions
```bash
cd "/home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/07_car_price"
pip install pandas scikit-learn matplotlib
python main.py
```

## Project Structure (Actual)
```
07_car_price/
├── main.py
├── data/
│   └── used_cars.csv
└── outputs/
    ├── actual_vs_predicted.png
    └── metrics.txt
```

## How It Works
1. **Setup & Backend Configuration**: Configures matplotlib to use the headless `Agg` backend, dynamically resolves directory paths using `pathlib.Path`, and ensures `outputs/` exists.
2. **Data Ingestion**: Loads `data/used_cars.csv` containing columns `age_years`, `kilometers`, and `price_usd`.
3. **Feature/Target Partitioning**: Separates 2D feature DataFrame `X` from 1D target Series `y`.
4. **Data Splitting**: Partitions samples into 33 training cars and 12 holdout test cars using `test_size=0.25` and `random_state=42`.
5. **Model Calibration**: Minimizes sum of squared errors via Ordinary Least Squares to find the optimal hyperplane.
6. **Error Profiling & Verification**: Predicts prices for the 12 test cars, computing $\text{MAE} = \$905.97$ and $R^2 = 0.9280$.
7. **Point Inference**: Predicts the value of a 5-year-old car driven 60,000 km ($15,077).
8. **Artifact Generation**: Renders `outputs/actual_vs_predicted.png` and exports `outputs/metrics.txt`.

## Summary of Empirical Results

| Metric / Parameter | Value | Interpretation |
|---|---|---|
| **Intercept ($\beta_0$)** | $26,817.96 | Theoretical baseline price of a brand-new car (0 yrs, 0 km) |
| **Age Coefficient ($\beta_1$)** | -$1,241.53 | Car loses ~$1,242 in value for each calendar year |
| **KM Coefficient ($\beta_2$)** | -$0.092223 | Car loses ~9.22 cents per km (~$922 per 10,000 km) |
| **Mean Absolute Error (MAE)** | $905.97 (~$906) | Average dollar error magnitude on unseen vehicles |
| **$R^2$ Score** | 0.9280 (~0.93) | 92.8% of price variation is explained by age & mileage |
| **5 yr / 60k km Car** | $15,076.97 (~$15,077) | Point prediction for the benchmark vehicle |

## Security & Reliability Considerations
- Headless execution safety via `matplotlib.use("Agg")` prevents crashes in non-GUI terminal and CI/CD environments.
- Dynamic filesystem resolution via `Path(__file__).resolve().parent` ensures portability across host platforms.
- Safe file persistence using context managers and explicit UTF-8 encoding avoids file lock issues and cross-platform encoding errors.
