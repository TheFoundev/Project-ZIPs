# Setup Guide

## Step 1: Navigate to Project Directory
Navigate to the source project directory in your terminal:
```bash
cd "/home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/03_titanic_survival"
```

## Step 2: Set Up Virtual Environment (Recommended)
Create and activate an isolated Python environment:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

## Step 3: Install Required Dependencies
Install the required data science and machine learning packages:
```bash
pip install pandas matplotlib scikit-learn
```

Or verify your dependencies with:
```bash
python3 -c "import pandas, matplotlib, sklearn; print('All packages imported successfully!')"
```

## Step 4: Verify Project Files
Check that the source script and data exist:
```bash
ls -la
ls -la data/
head -n 5 data/titanic_practice.csv
```

## Step 5: Run the Project
Execute the main script:
```bash
python3 main.py
```

## Step 6: Verify Outputs
Check the console output for accuracy (~73.9%), printed decision rules, and classification report.
Then check the `outputs/` folder:
- `outputs/titanic_tree.png` — Visual decision tree flow chart
- `outputs/confusion_matrix.png` — Heatmap of test set predictions
- `outputs/rules.txt` — Plain text logic rules with overall metrics
