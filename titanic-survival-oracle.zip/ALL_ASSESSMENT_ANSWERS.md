# All Correct Answers for Assessments
Project: Titanic Survival Oracle (Decision Tree Classification)
---

## Module 01
**q1-01.** What type of machine learning task is solved by the Titanic Survival Oracle in main.py?
   **Correct Answer:** c. Supervised binary classification
   *Explanation:* The Titanic Survival Oracle is a supervised binary classification task. It is supervised because it trains on historical labeled passenger records where the true outcome is known, and binary classification because the target variable has exactly two discrete classes (0 = did not survive, 1 = survived).

**q1-02.** In the dataset data/titanic_practice.csv, which column is the target variable (y)?
   **Correct Answer:** b. survived
   *Explanation:* 'survived' is the target variable (y) because it is the specific outcome the model learns to predict from passenger attributes.

**q1-03.** In the target column 'survived', what do the values 0 and 1 represent?
   **Correct Answer:** c. 0 represents did not survive (perished); 1 represents survived
   *Explanation:* In standard machine learning formulations of the Titanic dataset, 0 denotes passengers who perished (did not survive) and 1 denotes passengers who survived.

**q1-04.** Which column from data/titanic_practice.csv is intentionally excluded from the feature matrix X in main.py?
   **Correct Answer:** d. passenger_id
   *Explanation:* 'passenger_id' is an arbitrary sequential identifier assigned during data collection. It carries no statistical or causal relationship with survival and is excluded to avoid spurious correlations.

**q1-05.** Why is predicting Titanic passenger survival considered a classification problem rather than a regression problem?
   **Correct Answer:** b. Because the outcome is a discrete category ({0, 1}), not a continuous numeric quantity
   *Explanation:* Classification predicts discrete categories or classes ({0, 1}), whereas regression predicts continuous numeric values along an unbroken continuum (like house prices or temperatures).

**q1-06.** Why does line 14 of main.py execute matplotlib.use('Agg') before importing pyplot?
   **Correct Answer:** b. To configure a non-interactive raster backend for headless server execution without a GUI display
   *Explanation:* matplotlib.use('Agg') configures the Anti-Grain Geometry non-interactive raster backend. This enables rendering plots directly to disk (PNG files) in headless environments like servers, containers, or terminal sessions without crashing due to a missing display window.

**q1-07.** In a decision tree, what is the role of a leaf node (terminal node)?
   **Correct Answer:** c. It delivers the final predicted class or probability without further splits
   *Explanation:* A leaf node (or terminal node) is an endpoint in the tree with no outgoing branches. It provides the final prediction (either a discrete class label or a class probability distribution).

**q1-08.** Why are decision trees characterized as 'white box' models?
   **Correct Answer:** a. Because their decision rules can be exported as human-readable if-then statements
   *Explanation:* Decision trees are called 'white box' models because their internal mathematical logic is transparent and directly exportable as human-understandable if-then rules.

**q1-09.** If a classification algorithm outputs an estimated survival probability of 0.72 for a passenger, how does scikit-learn standardly decide the discrete predicted class?
   **Correct Answer:** b. It compares against a 0.50 threshold: since 0.72 >= 0.50, it assigns class 1
   *Explanation:* Binary classifiers in scikit-learn use a default decision threshold of 0.50. If the estimated probability of class 1 is greater than or equal to 0.50, predict() outputs class 1; otherwise, it outputs class 0.

**q1-10.** Why does main.py use pathlib.Path and OUT.mkdir(exist_ok=True) rather than hardcoded string paths?
   **Correct Answer:** b. To guarantee cross-platform OS compatibility and avoid FileExistsError if the folder already exists
   *Explanation:* pathlib.Path resolves absolute paths relative to the script's location across Linux, macOS, and Windows. Using mkdir(exist_ok=True) ensures that if the outputs folder already exists, Python proceeds safely without throwing a FileExistsError.


## Module 02
**q2-01.** How does main.py convert the textual 'sex' column into a binary numeric column?
   **Correct Answer:** b. df['is_female'] = (df['sex'] == 'female').astype(int)
   *Explanation:* Line 29 of main.py executes df['is_female'] = (df['sex'] == 'female').astype(int). This performs a vectorized boolean comparison returning True/False and then casts True to 1 and False to 0.

**q2-02.** Which four features are included in the feature matrix X in main.py?
   **Correct Answer:** b. ['pclass', 'is_female', 'age', 'fare']
   *Explanation:* Line 31 of main.py defines features = ['pclass', 'is_female', 'age', 'fare']. These four columns provide the numerical input data for the classifier.

**q2-03.** In train_test_split(X, y, test_size=0.25, ...), what does test_size=0.25 specify?
   **Correct Answer:** b. 25% of the data is allocated for model testing, leaving 75% for training
   *Explanation:* test_size=0.25 specifies that 25% of the total dataset observations will be reserved exclusively for the testing set, leaving 75% for training.

**q2-04.** What happens if you pass the raw text column 'sex' containing 'male' and 'female' directly to DecisionTreeClassifier.fit()?
   **Correct Answer:** b. Scikit-learn raises a ValueError because mathematical estimators cannot compute splits on raw strings
   *Explanation:* Scikit-learn algorithms require numeric data types (float or int). If text strings like 'male' or 'female' are passed, scikit-learn raises a ValueError stating that it could not convert string to float.

**q2-05.** What is the mathematical shape of the feature matrix X in main.py before train_test_split is performed?
   **Correct Answer:** c. (90, 4)
   *Explanation:* X is extracted from 90 passenger rows using 4 feature columns (['pclass', 'is_female', 'age', 'fare']), giving it a 2D shape of (90, 4).

**q2-06.** Why is the original 'sex' column dropped/excluded after creating 'is_female'?
   **Correct Answer:** b. Because it contains non-numeric text and is 100% redundant with 'is_female'
   *Explanation:* The raw 'sex' column contains non-numeric strings that estimators cannot process, and its information is completely captured by the numeric 'is_female' column. Retaining both would introduce errors and redundancy.

**q2-07.** What is the purpose of the stratify=y parameter in train_test_split?
   **Correct Answer:** b. To ensure both train and test partitions maintain the same proportion of survivors and non-survivors as the original dataset
   *Explanation:* stratify=y forces the sampling algorithm to preserve the original ratio of positive and negative classes (survivors and non-survivors) in both the training set and testing set, preventing sampling bias.

**q2-08.** Why is random_state=42 specified in train_test_split?
   **Correct Answer:** b. It sets the pseudo-random seed to make the train/test split deterministic and reproducible
   *Explanation:* random_state=42 initializes the pseudo-random number generator with a constant seed, ensuring that the shuffle order and train/test partition are identical on every execution.

**q2-09.** Given 90 total passenger records and test_size=0.25, how many samples are in X_train and X_test respectively?
   **Correct Answer:** c. 67 training samples and 23 testing samples
   *Explanation:* With 90 total records and a 25% test split, 90 * 0.25 = 22.5, which rounds to 23 test samples. The remaining 75% gives 90 - 23 = 67 training samples.

**q2-10.** In pandas and scikit-learn, why is X extracted as df[features] (2D) while y is extracted as df['survived'] (1D)?
   **Correct Answer:** b. Scikit-learn algorithms mathematically require features as a 2D matrix of shape (n_samples, n_features) and the target as a 1D vector of shape (n_samples,)
   *Explanation:* Scikit-learn's mathematical architecture requires that feature inputs be two-dimensional (samples by features), which pandas produces when passed a list of column names (df[features]). The target is expected to be a 1D sequence of labels, produced by single-bracket column selection (df['survived']).


## Module 03
**q3-01.** What is the Gini impurity of a perfectly pure leaf node containing 15 survivors and 0 non-survivors?
   **Correct Answer:** c. 0.0
   *Explanation:* A node containing solely one class has p1 = 15/15 = 1.0 and p0 = 0/15 = 0.0. The Gini impurity is 1 - (1.0^2 + 0.0^2) = 1 - 1 = 0.0, indicating total homogeneity (purity).

**q3-02.** In line 39 of main.py, what value is assigned to the max_depth hyperparameter?
   **Correct Answer:** b. max_depth=4
   *Explanation:* Line 39 of main.py explicitly initializes the model with model = DecisionTreeClassifier(max_depth=4, random_state=42).

**q3-03.** Which scikit-learn function prints the trained decision tree rules as an indented text hierarchy?
   **Correct Answer:** b. export_text()
   *Explanation:* export_text is the dedicated utility function in sklearn.tree that translates a fitted decision tree estimator into an indented text format.

**q3-04.** What is the primary risk of training a decision tree without any depth restriction (max_depth=None)?
   **Correct Answer:** b. The tree will overfit by memorizing individual training noise, reducing its accuracy on unseen test data
   *Explanation:* Without depth constraints, a decision tree will split until every single training observation is isolated into its own leaf node. This memorizes noisy training samples (overfitting), leading to poor generalization on unseen test data.

**q3-05.** In plot_tree, what is the visual effect of setting filled=True?
   **Correct Answer:** b. It shades each node box with a color representing its majority class, with intensity proportional to node purity
   *Explanation:* Setting filled=True in plot_tree causes each node to be shaded with color: orange for class 0 (did not survive) and blue for class 1 (survived). The deeper the color, the lower the Gini impurity (higher purity).

**q3-06.** What happens if you call export_text(model) without providing the feature_names argument?
   **Correct Answer:** b. It prints default generic labels like feature_0, feature_1, feature_2
   *Explanation:* When feature_names is omitted, export_text defaults to naming the input columns feature_0, feature_1, feature_2, and feature_3 based on their column indices.

**q3-07.** For a binary classification node containing 20 survivors and 20 non-survivors, what is the Gini impurity?
   **Correct Answer:** c. 0.50
   *Explanation:* In an equal binary split, p0 = 20/40 = 0.5 and p1 = 20/40 = 0.5. The Gini impurity is 1 - (0.5^2 + 0.5^2) = 1 - (0.25 + 0.25) = 1 - 0.50 = 0.50.

**q3-08.** Why does main.py call plt.close(fig) immediately after saving titanic_tree.png?
   **Correct Answer:** b. To free memory and close open matplotlib figure resources
   *Explanation:* Calling plt.close(fig) frees the figure object from matplotlib's internal global state, releasing memory and preventing memory leaks or warning messages during long runs.

**q3-09.** A decision node has 7 non-survivors (class 0) and 3 survivors (class 1). What is its exact Gini impurity?
   **Correct Answer:** b. 0.42
   *Explanation:* With 7 non-survivors and 3 survivors, p0 = 7/10 = 0.7 and p1 = 3/10 = 0.3. The Gini impurity is 1 - (0.7^2 + 0.3^2) = 1 - (0.49 + 0.09) = 1 - 0.58 = 0.42.

**q3-10.** Why is setting a max_depth limit classified as a 'pre-pruning' technique rather than 'post-pruning'?
   **Correct Answer:** b. Because it stops tree growth early during training before the algorithm creates overfitted branches
   *Explanation:* Pre-pruning techniques (like setting max_depth, min_samples_split, or min_samples_leaf) halt the expansion of the tree early during the recursive splitting phase, preventing the tree from ever growing overfitted branches.


## Module 04
**q4-01.** Which method must be called on a DecisionTreeClassifier instance to train it on historical passenger data?
   **Correct Answer:** b. model.fit(X_train, y_train)
   *Explanation:* The fit() method is the universal estimator training interface in scikit-learn. Calling model.fit(X_train, y_train) trains the decision tree on the training data.

**q4-02.** What type of output does model.predict(X_test) produce in this binary classification project?
   **Correct Answer:** b. A 1D array of discrete integer class labels (0 or 1)
   *Explanation:* For classification tasks, model.predict(X_test) outputs a 1D NumPy array of discrete class labels (in this project, 0 for perished and 1 for survived).

**q4-03.** In main.py, what is the survival probability predicted for the made-up passenger (3rd class, female, age 25, fare 10.0)?
   **Correct Answer:** c. 0.0%
   *Explanation:* In main.py line 61, the predicted probability for the made-up passenger (pclass 3, female, age 25, fare 10.0) is evaluated, printing 'Made-up passenger survival probability: 0.0%'.

**q4-04.** In the 2D array returned by predict_proba(), what does the value at index [0, 1] represent?
   **Correct Answer:** b. The estimated probability of survival (class 1) for the first passenger in the input batch
   *Explanation:* predict_proba() returns a 2D array of shape (n_samples, n_classes). Index [0, 1] selects row 0 (the first input passenger) and column 1 (corresponding to class 1, which represents survival).

**q4-05.** What happens if you pass a DataFrame with columns ['class', 'female', 'age', 'fare'] to model.predict() after training on ['pclass', 'is_female', 'age', 'fare']?
   **Correct Answer:** b. Scikit-learn raises a ValueError because the feature names do not match those seen during fit
   *Explanation:* Scikit-learn estimators validate feature names when passed pandas DataFrames. If the column names do not match model.feature_names_in_ exactly, it raises a ValueError stating feature names must match.

**q4-06.** How many test passengers out of the 23 in X_test did the trained model classify correctly in main.py?
   **Correct Answer:** b. 17 out of 23
   *Explanation:* With 23 test samples and an accuracy of 73.91% (accuracy_score = 0.7391), 23 * 0.7391 = 17 correct predictions (13 true negatives and 4 true positives).

**q4-07.** Why does the made-up passenger (female, 3rd class, age 25) receive a 0.0% predicted survival probability despite 'women and children first'?
   **Correct Answer:** b. In the training data, 3rd-class females older than 23.5 years had a 0% survival rate due to severe steerage deck barriers
   *Explanation:* The learned rule structure reveals that female passengers in 3rd class (pclass > 1.50) who were older than 23.5 years had zero survivors in the training data, leading to a leaf node predicting class 0 with 0.0% probability.

**q4-08.** For any binary classification sample, what is the mathematical relationship between predict_proba(X)[i, 0] and predict_proba(X)[i, 1]?
   **Correct Answer:** b. predict_proba(X)[i, 0] + predict_proba(X)[i, 1] == 1.0
   *Explanation:* Because classes 0 and 1 represent a mutually exclusive and exhaustive set of outcomes, the sum of their estimated probabilities must always equal 1.0 (100%) for every sample.

**q4-09.** If a custom passenger scenario navigates down the tree to a leaf node containing value = [3, 9] (3 non-survivors, 9 survivors), what probability will predict_proba() return for survival?
   **Correct Answer:** c. 0.75 (75.0%)
   *Explanation:* The leaf node has 3 non-survivors and 9 survivors, giving a total of 12 samples. The probability of class 1 is 9 / 12 = 0.75 (75.0%).

**q4-10.** In scikit-learn design conventions, why do attributes like classes_, feature_names_in_, and tree_ end with a trailing underscore?
   **Correct Answer:** b. They distinguish attributes estimated/learned from data during fit() from user-supplied hyperparameters
   *Explanation:* PEP 8 and scikit-learn API design standards mandate that any attribute estimated from data during the fit() method ends with a trailing underscore. This cleanly distinguishes learned parameters from hyperparameters set by the user in the constructor.


## Module 05
**q5-01.** What overall test accuracy does the Decision Tree model achieve on the 23 test passengers in main.py?
   **Correct Answer:** c. 73.9%
   *Explanation:* In main.py line 47, accuracy_score(y_test, predictions) calculates 17/23 = 0.7391, which prints as 'Accuracy: 73.9%'.

**q5-02.** In this project, what does a True Negative (TN) represent?
   **Correct Answer:** b. A passenger who died, correctly predicted as did not survive (class 0)
   *Explanation:* A True Negative occurs when the actual ground-truth label is negative (0 = did not survive) and the model correctly predicts negative (0). In main.py, there are 13 True Negatives.

**q5-03.** In the classification report printed by main.py, what is the 'support' for class 1 (survivors) in the test set?
   **Correct Answer:** b. 7
   *Explanation:* The 'support' column in classification_report indicates the number of actual true instances of each class in y_test. For class 1 (survivors), support is exactly 7.

**q5-04.** In the context of the Titanic disaster, what is the real-world meaning of a False Negative (Type II error)?
   **Correct Answer:** b. A passenger who actually survived was incorrectly predicted to have died
   *Explanation:* A False Negative is a Type II error where the condition was true (the passenger survived, class 1), but the test predicted false (the model predicted they perished, class 0).

**q5-05.** Which formula correctly defines Precision in classification?
   **Correct Answer:** b. TP / (TP + FP)
   *Explanation:* Precision is defined as True Positives divided by total predicted positives: TP / (TP + FP). It measures the reliability of positive assertions.

**q5-06.** In main.py's classification report, why is the weighted average F1-score (0.74) higher than the macro average F1-score (0.69)?
   **Correct Answer:** b. Because the majority class (class 0, support=16) has a higher F1-score (0.81) and receives more weight in the calculation
   *Explanation:* The weighted average weights each class's score by its support. Since class 0 has 16 samples with an F1-score of 0.81, it pulls the weighted average up to 0.74, whereas the macro average simply computes (0.81 + 0.57) / 2 = 0.69.

**q5-07.** Why does main.py pass zero_division=0 to classification_report()?
   **Correct Answer:** b. To gracefully suppress UndefinedMetricWarning and output 0.0 when a class has zero positive predictions
   *Explanation:* When a model predicts 0 instances for a class, precision involves a 0/0 calculation. Setting zero_division=0 instructs scikit-learn to set the metric to 0.0 without triggering an UndefinedMetricWarning.

**q5-08.** If you lower the classification probability threshold from 0.50 to 0.20 for identifying survivors, what is the expected effect on False Negatives and False Positives?
   **Correct Answer:** a. False Negatives decrease while False Positives increase
   *Explanation:* Lowering the decision threshold makes the model more aggressive in predicting class 1 (survival). This catches more actual survivors (reducing False Negatives) but simultaneously generates more false alarms (increasing False Positives).

**q5-09.** If a classification model achieves a Precision of 1.0 (100%) but a Recall of 0.0 (0%), what is its F1-Score?
   **Correct Answer:** c. 0.00 (0%)
   *Explanation:* The F1-Score uses the harmonic mean: 2 * (Precision * Recall) / (Precision + Recall). If Recall is 0.0, the numerator is 2 * (1.0 * 0.0) = 0.0, resulting in an F1-Score of 0.0. The harmonic mean properly penalizes a total failure in either metric.

**q5-10.** Why is the Accuracy Paradox a critical hazard when evaluating machine learning models on imbalanced datasets?
   **Correct Answer:** b. Because a trivial model that always predicts the majority class can boast a high accuracy while completely failing to detect the minority class
   *Explanation:* The Accuracy Paradox occurs in imbalanced datasets when a trivial model that always predicts the majority class appears highly accurate (e.g. 99% accuracy if 99% of samples are class 0) while having zero capability to predict the minority class of interest.


## Module 06
**q6-01.** Which three files are generated in the outputs/ directory by running main.py?
   **Correct Answer:** b. titanic_tree.png, confusion_matrix.png, rules.txt
   *Explanation:* Lines 77, 88, and 91 of main.py explicitly write three output files: outputs/titanic_tree.png, outputs/confusion_matrix.png, and outputs/rules.txt.

**q6-02.** What command executes the Titanic Survival Oracle from the command line?
   **Correct Answer:** a. python main.py
   *Explanation:* Executing 'python main.py' (or 'python3 main.py') invokes the Python interpreter to execute the script and its main() entry point.

**q6-03.** What experiment does line 97 of main.py explicitly invite the student to attempt?
   **Correct Answer:** b. Change max_depth to 2 or 5 and compare the learned rules
   *Explanation:* Line 97 of main.py prints: 'Try this: change max_depth to 2 or 5 and compare the rules.' This directly guides learners to experiment with tree complexity.

**q6-04.** How does the survival probability of the made-up passenger change if max_depth is changed from 4 to 2?
   **Correct Answer:** b. It increases from 0.0% to approximately 41.2% because 3rd-class females are no longer split by age
   *Explanation:* At max_depth=4, the tree creates a specific rule branch splitting 3rd-class females by age 23.5, assigning 0.0% probability to those aged 25. At max_depth=2, the tree cannot grow that deep; it aggregates all 3rd-class females together, resulting in a 7/17 (approx 41.2%) survival probability.

**q6-05.** According to the principle of Occam's Razor (Model Parsimony), if max_depth=2 and max_depth=4 both achieve 73.9% test accuracy, why is max_depth=2 often preferred for deployment?
   **Correct Answer:** a. Because max_depth=2 uses less memory and produces a simpler, more explainable rule set with fewer risks of latent overfitting
   *Explanation:* Occam's Razor dictates that simpler models with fewer parameters/rules are preferred when they perform equally well. A depth 2 tree is easier to audit, explain to regulators, and less prone to latent overfitting on unobserved data.

**q6-06.** How do ensemble algorithms like RandomForestClassifier improve upon the performance of a single DecisionTreeClassifier?
   **Correct Answer:** b. By averaging the predictions of dozens or hundreds of diverse trees to reduce variance and mitigate overfitting
   *Explanation:* Random Forests train an ensemble of diverse trees on bootstrap samples with random feature subsets. By aggregating (averaging or voting) their outputs, the ensemble reduces the high variance of individual trees and achieves better generalization.

**q6-07.** What is the primary advantage of saving rules.txt in plain text compared to saving only titanic_tree.png?
   **Correct Answer:** b. Text rules can be tracked and diffed with git, parsed by automated test scripts, and viewed in headless terminal logs
   *Explanation:* Plain-text files like rules.txt are lightweight, easily diffable across git commits, readable in headless server logs without display servers, and simple for automated test scripts to parse.

**q6-08.** When using SimpleImputer to fill in missing feature values in a production pipeline, why must imputer.fit() be applied exclusively to X_train?
   **Correct Answer:** b. To prevent data leakage by ensuring that test set summary statistics do not influence the training phase
   *Explanation:* Fitting an imputer on the full dataset computes summary statistics (like median or mean) across both train and test samples, allowing test set information to leak into the training process (data leakage). Imputers must always be fitted only on X_train.

**q6-09.** What fundamental trade-off is made when upgrading from a single DecisionTreeClassifier to an ensemble Random Forest?
   **Correct Answer:** a. The ensemble gains higher predictive accuracy and stability but sacrifices the direct, white-box interpretability of a single if-then rule set
   *Explanation:* The fundamental trade-off of ensemble methods is predictive performance versus interpretability. An ensemble of 100 trees makes superior predictions, but humans can no longer follow a single transparent path of 4 if-then questions from root to leaf.

**q6-10.** Why is the idiom `if __name__ == '__main__': main()` standard practice in Python data science projects?
   **Correct Answer:** b. It ensures the script executes when run directly from the command line, while allowing other scripts and test harnesses to import its components without executing main()
   *Explanation:* The `if __name__ == '__main__':` boilerplate allows a Python file to act both as an executable script and as an importable module. When run directly, `__name__` is `'__main__'` and main() executes; when imported by another file or test suite, main() does not automatically run.

