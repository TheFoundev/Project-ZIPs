# Glossary

| Term | Definition |
|---|---|
| **Binary Classification** | Supervised learning task where the target output belongs to one of exactly two distinct categories (e.g., 0 = did not survive, 1 = survived). |
| **Decision Tree** | A non-parametric supervised learning algorithm that creates hierarchical if-then-else decision rules based on feature values to predict target labels. |
| **Root Node** | The very first node at the top of a decision tree where the initial feature split occurs across the entire training sample. |
| **Internal Node** | A decision node within the tree that tests a specific feature condition and branches into two child nodes. |
| **Leaf Node (Terminal Node)** | An endpoint in the tree with no further splits, representing a final predicted class or probability distribution. |
| **Gini Impurity** | A metric measuring the probability of a randomly chosen element being incorrectly labeled if it were randomly labeled according to the distribution of labels in the node. Lower impurity means higher node purity. |
| **max_depth** | A hyperparameter that sets the maximum allowable distance from root node to the deepest leaf node, preventing overfitting. |
| **Overfitting** | When a machine learning model memorizes training noise and fails to generalize effectively to unseen test data. |
| **Feature Engineering** | The process of transforming raw data into informative numeric representations suitable for machine learning models (e.g., converting `"sex"` to `is_female`). |
| **Stratified Split (`stratify=y`)** | A sampling technique ensuring the train and test subsets contain identical proportions of each target class as the original dataset. |
| **predict()** | Scikit-learn method that outputs the discrete predicted class label (0 or 1). |
| **predict_proba()** | Scikit-learn method that outputs the estimated class probabilities (e.g., [0.90, 0.10]) for each sample. |
| **Accuracy** | The proportion of total correct predictions out of all predictions made: $(TP + TN) / (TP + TN + FP + FN)$. |
| **Precision** | Out of all instances predicted as positive, the fraction that were actually positive: $TP / (TP + FP)$. |
| **Recall (Sensitivity)** | Out of all actual positive instances, the fraction correctly identified by the model: $TP / (TP + FN)$. |
| **F1-Score** | The harmonic mean of precision and recall: $2 \times \frac{\text{Precision} \times \text{Recall}}{\text{Precision} + \text{Recall}}$. |
| **Confusion Matrix** | A 2x2 table cross-referencing actual ground truth labels against predicted labels to show True Positives, True Negatives, False Positives, and False Negatives. |
| **False Negative (FN)** | Type II error where an actual positive is predicted as negative (in this project: passenger survived, but model predicted did not survive). |
| **False Positive (FP)** | Type I error where an actual negative is predicted as positive (in this project: passenger died, but model predicted survived). |
| **export_text** | Scikit-learn utility that renders a trained decision tree as human-readable plain text if-then rules. |
| **plot_tree** | Scikit-learn utility that plots a visual graphic flowchart of the decision tree with node details. |
