# Module 6 Exercises: Complete Pipeline & Running

## Exercise 6.1: End-to-End Pipeline Verification & Output Audit (15 min)
**Objective:** Execute `main.py` and programmatically verify the existence, size, and validity of all outputs.  
**Problem Statement:** In automated production data pipelines, an automated audit script checks that every expected deliverable was generated with valid file sizes.

**Requirements:**
1. Execute `python3 main.py` in the terminal.
2. Write a Python script `audit_pipeline.py` using `pathlib.Path`.
3. Check that `outputs/titanic_tree.png` exists and is $> 100 \text{ KB}$.
4. Check that `outputs/confusion_matrix.png` exists and is $> 20 \text{ KB}$.
5. Check that `outputs/rules.txt` exists, is non-empty, and contains the string `"accuracy:"`.
6. Print a formatted PASS/FAIL status for each artifact.

**Constraints:** Use standard Python libraries (`pathlib`, `os`).

**Expected Behaviour:** Python audit script that outputs clean green checkmarks or PASS statuses for all three artifacts.

**Acceptance Criteria:**
- [ ] Pipeline executes cleanly with exit code 0.
- [ ] All three output files verified with non-zero file sizes.
- [ ] `rules.txt` confirmed to contain summary metrics.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 6.2: Cross-Artifact Synthesis & Verification (15 min)
**Objective:** Cross-reference information across `rules.txt`, `titanic_tree.png`, and `confusion_matrix.png`.  
**Problem Statement:** Ensure that the metrics documented across all three outputs are 100% mathematically consistent.

**Requirements:**
1. Open `outputs/rules.txt` and record the reported accuracy.
2. Open `outputs/confusion_matrix.png` and sum the diagonal elements ($TP + TN$) and total elements ($N$).
3. Verify that $(TP + TN) / N$ equals the accuracy recorded in `rules.txt`.
4. Locate the node for adult males in `outputs/rules.txt` (`is_female <= 0.50`, `age > 18.50`).
5. Find the corresponding node box in `outputs/titanic_tree.png` and verify that its majority class is `did not survive`.

**Acceptance Criteria:**
- [ ] Accurately computes $17 / 23 = 73.91\%$ across both files.
- [ ] Confirms exact correspondence between text rule conditions and diagram boxes.
- [ ] Identifies the dominant male non-survivor leaf node.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 6.3: Systematic Hyperparameter Study (15 min)
**Objective:** Implement and compare models across `max_depth` 2, 4, and 5.  
**Problem Statement:** Line 97 of `main.py` suggests testing depth 2 and 5. Build an automated script that evaluates all three configurations.

**Requirements:**
1. Create a script that trains `DecisionTreeClassifier` with `max_depth=2`, `max_depth=4`, and `max_depth=5` (fixing `random_state=42`).
2. Record total leaf node count (`clf.get_n_leaves()`) for each depth.
3. Record training accuracy and test accuracy for each depth.
4. Evaluate survival probability for the made-up passenger (`pclass=3, is_female=1, age=25, fare=10.0`) under each depth.
5. Format the results as a Markdown table.

**Acceptance Criteria:**
- [ ] Accurately reports leaves, train acc, test acc, and passenger probability for all 3 depths.
- [ ] Observes the jump in made-up passenger probability from 0.0% (depth 4) to ~41.2% (depth 2).
- [ ] Explains why test accuracy remains constant at 73.9% while tree complexity doubles.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 6.4: Prototyping an Engineered Feature (`is_child`) (15 min)
**Objective:** Engineer a new demographic indicator and evaluate its impact on tree logic.  
**Problem Statement:** Maritime protocol prioritized children. Engineer a binary feature `is_child = (df["age"] <= 14).astype(int)` and test if it improves accuracy.

**Requirements:**
1. Load `titanic_practice.csv` and add `df["is_female"]`.
2. Add `df["is_child"] = (df["age"] <= 14).astype(int)`.
3. Define `features = ["pclass", "is_female", "is_child", "age", "fare"]`.
4. Train `DecisionTreeClassifier(max_depth=4, random_state=42)` on the same stratified split.
5. Compare test accuracy against the baseline 4-feature model.
6. Print the top 2 levels of the new tree using `export_text`.

**Acceptance Criteria:**
- [ ] Successfully engineers `is_child` without errors.
- [ ] Re-runs training and reports test accuracy.
- [ ] Inspects whether the algorithm chooses `is_child` for an early split.

**Difficulty:** Advanced  
**Estimated Completion Time:** 15 minutes  
