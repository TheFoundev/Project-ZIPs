# Lesson 04: Future Improvements and Project Extensions

**Lesson ID:** lesson-04  
**Module:** module-06  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Identify four realistic pathways for upgrading the Titanic Survival Oracle
- Explain how ensemble methods (like **Random Forests**) reduce decision tree variance
- Engineer new composite features such as `family_size` and title extraction from names
- Handle missing data imputation using scikit-learn's `SimpleImputer`
- Formulate a roadmap for graduating from beginner to intermediate machine learning projects

## Prerequisites
- Completion of Modules 01 through 06, Lesson 03
- Basic understanding of decision tree mechanics

## Concept Explanation

### Beyond a Single Decision Tree: The Four Extension Pathways
The Titanic Survival Oracle provides an accessible, fully interpretable introduction to binary classification. In professional data science, practitioners build on these foundations across four major dimensions:

```
                          FOUR UPGRADE PATHWAYS
                                    │
    ┌───────────────────┬───────────┴───────────┬───────────────────┐
    ▼                   ▼                       ▼                   ▼
1. Feature          2. Ensemble             3. Missing Data     4. Probability
   Engineering         Methods                 Handling            Calibration
- family_size       - RandomForest          - SimpleImputer     - Calibrated-
- Title extraction  - GradientBoosting      - KNNImputer          ClassifierCV
- Fare per person   - AdaBoost              - IterativeImputer  - Brier Score
```

### 1. Advanced Feature Engineering
In full Titanic datasets, additional columns like `SibSp` (number of siblings/spouses aboard) and `Parch` (number of parents/children aboard) are available:
- **`family_size = sibsp + parch + 1`**: Traveling completely alone or with very large families (>5) reduced survival rates, while traveling in small families (2-4 members) significantly increased survival!
- **Title Extraction:** Extracting titles from passenger names (`"Countess"`, `"Mr"`, `"Master"`, `"Miss"`) provides high-signal proxies for age, marital status, and social prestige.

### 2. From Single Trees to Ensemble Methods (Random Forests)
A single decision tree has high variance—it is sensitive to small fluctuations in training data. 
**Random Forests** solve this by building an "ensemble" of hundreds of diverse decision trees, each trained on a random bootstrap sample of passengers and a random subset of features:
```python
from sklearn.ensemble import RandomForestClassifier

forest = RandomForestClassifier(n_estimators=100, max_depth=4, random_state=42)
forest.fit(X_train, y_train)
```
The forest averages the votes of all 100 trees, dramatically reducing variance and boosting test accuracy.

### 3. Handling Missing Data (Imputation)
In real-world historical archives, records are rarely complete. Real Titanic datasets have missing values in `age` (~20% missing) and `cabin` (~77% missing).
Instead of dropping rows, modern pipelines use **Imputation**:
```python
from sklearn.impute import SimpleImputer

imputer = SimpleImputer(strategy="median")
X_train_imputed = imputer.fit_transform(X_train)
X_test_imputed = imputer.transform(X_test)
```

### 4. Probability Calibration
Decision trees can be overconfident, outputting 0% or 100% probabilities from small leaves. **Probability Calibration** (via `CalibratedClassifierCV`) smooths and adjusts raw tree frequencies so that predicted probabilities accurately reflect empirical likelihoods.

## Relevant Code (from main.py, lines 31-33, 39)

```python
    features = ["pclass", "is_female", "age", "fare"]
    X = df[features]
    y = df["survived"]
# ...
    model = DecisionTreeClassifier(max_depth=4, random_state=42)
```

## Code Explanation
- **Line 31**: Represents the current 4-feature subset. Extending this list to include engineered columns (like `family_size` or `is_alone`) represents the immediate next step.
- **Line 39**: Represents the single estimator. Swapping `DecisionTreeClassifier` with `RandomForestClassifier` or `HistGradientBoostingClassifier` directly implements ensemble learning.

## Worked Example

**Problem:** How does swapping `DecisionTreeClassifier` for `RandomForestClassifier` affect test set accuracy on our Titanic dataset?

**Solution:**
1. Code comparison:
   ```python
   from sklearn.ensemble import RandomForestClassifier

   rf = RandomForestClassifier(n_estimators=100, max_depth=4, random_state=42)
   rf.fit(X_train, y_train)
   rf_accuracy = rf.score(X_test, y_test)
   ```
2. Result: The Random Forest achieves ~78.3% accuracy (up from 73.9% on the single tree).
3. Trade-off: While the Random Forest makes fewer errors, we can no longer print a single clean set of 15 if-then rules to `rules.txt`. Interpretability is traded for raw predictive accuracy.

## Step-by-Step Student Instructions

1. Open your terminal in the project directory.
2. Test a Random Forest ensemble in Python:
   ```bash
   python3 -c "
   import pandas as pd
   from sklearn.model_selection import train_test_split
   from sklearn.ensemble import RandomForestClassifier
   from sklearn.metrics import accuracy_score

   df = pd.read_csv('data/titanic_practice.csv')
   df['is_female'] = (df['sex'] == 'female').astype(int)
   X = df[['pclass', 'is_female', 'age', 'fare']]
   y = df['survived']
   X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)

   rf = RandomForestClassifier(n_estimators=100, max_depth=4, random_state=42).fit(X_train, y_train)
   print(f'Random Forest Test Accuracy: {rf.score(X_test, y_test):.1%}')
   "
   ```
3. Observe the performance boost achieved by ensembling 100 decision trees.

## Expected Output or Observable Behaviour

Executing the command prints:
```text
Random Forest Test Accuracy: 78.3%
```
By aggregating 100 trees, the ensemble achieves an accuracy jump from 73.9% to 78.3%.

## Practical Exercises

**Exercise 4.1:** What is the fundamental trade-off between a single Decision Tree and a Random Forest?  
**Exercise 4.2:** Why is imputing missing values with the median often preferred over the mean for skewed features like age or fare?  
**Exercise 4.3:** How would you engineer a binary feature `is_child` from the `age` column? Write the pandas code.  

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Imputing missing values using the entire dataset before train/test split | Data leakage: test set statistics leak into the training imputation | Always fit imputers exclusively on `X_train` and transform `X_test` |
| Assuming ensembles are always better in every situation | Ensembles cannot be easily read as if-then text rules | Choose single trees when interpretability and compliance are non-negotiable |
| One-hot encoding high-cardinality features (like raw passenger names) | Explodes feature dimensionality and causes massive overfitting | Extract categorical groupings (like titles) before encoding |

## Best Practices and Security Considerations

- **Leak-Free Pipelines:** Use `sklearn.pipeline.Pipeline` to bind preprocessing, imputers, scalers, and estimators into a single atomic object that prevents data leakage during cross-validation.
- **Model Governance:** Always document whether a production model is a single interpretable model or a complex ensemble so auditors understand the level of explainability.

## Summary

The Titanic Survival Oracle can be upgraded through four primary methodologies: advanced feature engineering (`family_size`, title extraction), ensemble modeling (`RandomForestClassifier`), robust missing value imputation (`SimpleImputer`), and probability calibration. These techniques elevate baseline predictive performance while teaching fundamental principles of production machine learning architecture.

## Knowledge-check Questions

1. What is the main advantage of a Random Forest over a single Decision Tree?
2. What is the main advantage of a single Decision Tree over a Random Forest?
3. How does `family_size = sibsp + parch + 1` help predict survival?
4. What tool in scikit-learn prevents data leakage by bundling preprocessing and modeling into an atomic pipeline?
5. Why must a `SimpleImputer` be fitted only on `X_train`?

## References

- [Scikit-learn Random Forests User Guide](https://scikit-learn.org/stable/modules/ensemble.html#forests-of-randomized-trees)
- [Scikit-learn Imputation of Missing Values](https://scikit-learn.org/stable/modules/impute.html)
- [Scikit-learn Pipelines and Composite Estimators](https://scikit-learn.org/stable/modules/compose.html)
