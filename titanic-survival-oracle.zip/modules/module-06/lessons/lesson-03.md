# Lesson 03: Experimenting with Hyperparameters: Impact of `max_depth` (2 vs 4 vs 5)

**Lesson ID:** lesson-03  
**Module:** module-06  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Conduct systematic experiments by varying the `max_depth` hyperparameter
- Compare rule simplicity, training accuracy, and test generalization across depths 2, 4, and 5
- Explain why a simpler tree (`max_depth=2`) may achieve the same test accuracy as a deeper tree
- Apply the principle of **Occam's Razor (Model Parsimony)** in machine learning selection

## Prerequisites
- Lesson 01: End-to-End Pipeline Execution and Output Generation
- Lesson 02: Interpreting Generated Artifacts
- Module 03, Lesson 02: Controlling Tree Complexity with `max_depth`

## Concept Explanation

### The Experimentation Prompt in `main.py`
Line 97 of `main.py` explicitly invites the user:
```text
Try this: change max_depth to 2 or 5 and compare the rules.
```
In machine learning, models are rarely finished on the first run. The core engineering loop consists of: **Hypothesis $\rightarrow$ Configuration $\rightarrow$ Training $\rightarrow$ Evaluation $\rightarrow$ Comparison**.

### Comparing Three Depths: 2, 4, and 5

#### 1. Shallow Model (`max_depth=2`):
- **Structure:** At most $2^2 = 4$ leaves.
- **Rule Set:** Only 2 questions are asked:
  - Is passenger female?
  - For males: is age $\le 18.5$?
  - For females: is class $\le 2.5$?
- **Training Accuracy:** 80.6%
- **Test Accuracy:** **73.9%**
- **Pros:** Extremely simple, fits on an index card, virtually impossible to overfit.

#### 2. Balanced Baseline Model (`max_depth=4`):
- **Structure:** Up to 16 leaves (13 active leaves).
- **Rule Set:** Discovers nuanced interactions between sex, age thresholds (14.5, 18.5, 23.5, 37.5), class, and ticket fare ($14.30, 15.50).
- **Training Accuracy:** 89.6%
- **Test Accuracy:** **73.9%**
- **Pros:** Captures fine-grained interactions while preserving generalization.

#### 3. Deep Model (`max_depth=5`):
- **Structure:** Up to 32 leaves.
- **Rule Set:** Highly complex, creates isolated leaves for 1 or 2 specific passengers (e.g. splitting on narrow fare increments).
- **Training Accuracy:** 92.5%
- **Test Accuracy:** **73.9%** (or lower on larger partitions).
- **Cons:** Significantly harder to explain, risks memorizing training noise.

| Metric / Attribute | `max_depth=2` | `max_depth=4` (Project) | `max_depth=5` |
|---|---|---|---|
| **Max Leaf Count** | 4 | 13 | 19 |
| **Training Accuracy** | 80.6% | 89.6% | 92.5% |
| **Test Accuracy** | **73.9%** | **73.9%** | **73.9%** |
| **Explainability** | High (Immediate) | Medium (Comprehensive) | Low (Fragmented) |
| **Overfitting Risk** | Very Low | Controlled | Elevated |

### Occam's Razor in Model Selection
**Occam's Razor** states that *among competing hypotheses that predict equally well, the simplest one should be selected.*

If `max_depth=2` achieves 73.9% test accuracy and `max_depth=4` also achieves 73.9% test accuracy, which should an engineer deploy?
- In a safety-critical or regulatory environment, **`max_depth=2` is strongly preferred** because its 4 rules are trivial to verify, audit, and explain.
- In an exploratory research environment, **`max_depth=4` is valuable** because it reveals subtle demographic interactions (such as the 23.5-year age threshold for 3rd-class women).

## Relevant Code (from main.py, lines 39, 97)

```python
    model = DecisionTreeClassifier(max_depth=4, random_state=42)
# ...
    print("Try this: change max_depth to 2 or 5 and compare the rules.")
```

## Code Explanation
- **Line 39**: The baseline depth configuration.
- **Line 97**: Guides the student to modify line 39, re-run `python3 main.py`, and inspect the resulting differences in `outputs/rules.txt` and `outputs/titanic_tree.png`.

## Worked Example

**Problem:** What happens to the made-up passenger (`pclass=3, is_female=1, age=25, fare=10.0`) when `max_depth` is changed from 4 to 2?

**Solution:**
1. Under `max_depth=4`:
   - Rules trace: `female -> age <= 37.5 -> pclass > 1.5 -> age > 23.5 -> class: 0`.
   - Survival probability: **0.0%**.
2. Under `max_depth=2`:
   - Rules trace: `female -> pclass > 2.5` (or `pclass <= 2.5`).
   - For `pclass=3`, the leaf contains 10 non-survivors and 7 survivors ($17$ total samples).
   - Survival probability: $\frac{7}{17} \approx \mathbf{41.2\%}$!
3. By pruning the depth from 4 to 2, the model groups all 3rd-class females together rather than splitting on age 23.5, giving her a 41.2% probability of survival rather than 0.0%!

## Step-by-Step Student Instructions

1. Open `main.py` in your text editor.
2. Edit line 39 to set `max_depth=2`:
   ```python
   model = DecisionTreeClassifier(max_depth=2, random_state=42)
   ```
3. Run the script:
   ```bash
   python3 main.py
   ```
4. Check the console output and inspect the newly written `outputs/rules.txt`. Count how few lines of rules are printed!
5. Now edit line 39 to set `max_depth=5`:
   ```python
   model = DecisionTreeClassifier(max_depth=5, random_state=42)
   ```
6. Run the script again. Notice how many additional branches are created!
7. Reset line 39 back to `max_depth=4` when finished.

## Expected Output or Observable Behaviour

When running with `max_depth=2`, the console shows:
```text
Learned rules:

|--- is female (1=yes) <= 0.50
|   |--- age <= 18.50
|   |   |--- class: 0
|   |--- age >  18.50
|   |   |--- class: 0
|--- is female (1=yes) >  0.50
|   |--- passenger class <= 2.50
|   |   |--- class: 1
|   |--- passenger class >  2.50
|   |   |--- class: 0

Made-up passenger survival probability: 41.2%
```
Notice how clean and concise the rule set becomes.

## Practical Exercises

**Exercise 3.1:** What happens to the survival probability of the made-up passenger when `max_depth=2`? Explain why it differs from `max_depth=4`.  
**Exercise 3.2:** What is the training accuracy of the model when `max_depth=1` (a decision stump)? Can a depth-1 tree predict both classes?  
**Exercise 3.3:** Why does training accuracy continue to increase as `max_depth` increases, while test accuracy plateaus or declines?  

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Forgetting to save `main.py` before re-running | Terminal executes the unsaved file on disk | Save changes in editor before running `python3 main.py` |
| Setting `max_depth=0` | A tree of depth 0 cannot make any splits, raising `ValueError` | Depth must be an integer $\ge 1$ or `None` |
| Concluding that depth 5 is better because training accuracy is higher | Training accuracy measures memorization, not predictive ability on new data | Always evaluate on test accuracy |

## Best Practices and Security Considerations

- **Cross-Validation for Hyperparameter Selection:** In production, never tune `max_depth` on the test set! Use k-fold cross-validation (`GridSearchCV`) on the training set to prevent test data snooping.
- **Explainability Constraints:** When building models for regulated domains (such as lending or healthcare), set hard caps on tree depth (e.g., `max_depth <= 3`) as an organizational policy.

## Summary

Varying `max_depth` illustrates the fundamental bias-variance trade-off in machine learning. While `max_depth=2` produces a simple 4-leaf model (80.6% train, 73.9% test), `max_depth=4` adds nuanced age and fare interactions, and `max_depth=5` increases complexity without improving test accuracy. Applying Occam's Razor, simpler models that achieve equivalent test performance are always preferred for production deployment.

## Knowledge-check Questions

1. What happens to the number of learned rules when `max_depth` is changed from 4 to 2?
2. What does Occam's Razor imply for machine learning model selection?
3. What is the survival probability of the made-up passenger under `max_depth=2`?
4. What happens to training accuracy as `max_depth` increases from 2 to 5?
5. Why should hyperparameters not be tuned directly against the test set?

## References

- [Scikit-learn Model Selection and Cross-Validation](https://scikit-learn.org/stable/modules/cross_validation.html)
- [The Bias-Variance Tradeoff (Coursera Machine Learning Specialization)](https://www.coursera.org/learn/machine-learning)
- [Occam's Razor in Machine Learning (Pedro Domingos)](https://homes.cs.washington.edu/~pedrod/papers/cacm12.pdf)
