# Lesson 02: Interpreting Generated Artifacts (`rules.txt`, `titanic_tree.png`, `confusion_matrix.png`)

**Lesson ID:** lesson-02  
**Module:** module-06  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Synthesize findings across the three persistent artifacts generated in `outputs/`
- Correlate the plain text branch conditions in `rules.txt` with node boxes in `titanic_tree.png`
- Validate that the confusion matrix heatmap in `confusion_matrix.png` reflects the metrics stored in `rules.txt`
- Build an executive summary briefing based on the generated project artifacts

## Prerequisites
- Lesson 01: End-to-End Pipeline Execution and Output Generation
- Module 03: Decision Tree Algorithm
- Module 05: Evaluation & Metrics

## Concept Explanation

### The Triad of Model Artifacts
When `main.py` finishes executing, it leaves behind three distinct artifacts in `outputs/`. Each artifact addresses a different audience and technical need:

```
                            THE THREE ARTIFACTS
                                     │
         ┌───────────────────────────┼───────────────────────────┐
         ▼                           ▼                           ▼
    rules.txt                titanic_tree.png           confusion_matrix.png
┌──────────────────┐       ┌──────────────────┐       ┌──────────────────────┐
│  Plain-text rules│       │ Visual flowchart │       │ Visual error matrix  │
│  & test accuracy │       │ for stakeholders │       │ for data scientists  │
│  (Lightweight,   │       │ (Color-coded by  │       │ (True/False counts   │
│   git-friendly)  │       │  purity & class) │       │  by class)           │
└──────────────────┘       └──────────────────┘       └──────────────────────┘
```

### Artifact 1: `outputs/rules.txt`
This text file stores the exact mathematical tree logic alongside summary metrics:
- Contains the complete indented if/else hierarchy using `export_text`.
- Appends `accuracy: 0.7391`.
- Appends `made-up passenger survival probability: 0.0000`.
- **Primary Use:** Automated CI/CD regression testing, diffing across model versions, lightweight storage.

### Artifact 2: `outputs/titanic_tree.png`
This image visualizes the full 4-depth decision tree:
- **Root Split:** Tests `is female <= 0.5`.
- **Left Subtree (Males):** Overwhelmingly shaded in orange (`class = did not survive`). Exceptions: young boys under 14.5 years old or specific low-fare adult categories.
- **Right Subtree (Females):** Overwhelmingly shaded in blue (`class = survived`). First-class and second-class women have virtually 100% survival leaves. Third-class women split on age ($\le 23.50$).
- **Primary Use:** Presentations, non-technical stakeholder reviews, medical/legal compliance audits.

### Artifact 3: `outputs/confusion_matrix.png`
This image shows test set prediction performance:
- Diagonal cells show 13 True Negatives and 4 True Positives (17 total correct).
- Off-diagonal cells show 3 False Positives and 3 False Negatives (6 total errors).
- **Primary Use:** Error analysis, identifying class imbalances, risk auditing.

## Relevant Code (from main.py, lines 77, 88, 91-95)

```python
    fig.savefig(OUT / "titanic_tree.png", dpi=150, bbox_inches="tight")
# ...
    fig.savefig(OUT / "confusion_matrix.png", dpi=150, bbox_inches="tight")
# ...
    with open(OUT / "rules.txt", "w", encoding="utf-8") as handle:
        handle.write(export_text(model, feature_names=features))
        handle.write(f"\naccuracy: {accuracy:.4f}\n")
        handle.write(f"made-up passenger survival probability: {probability:.4f}\n")
```

## Code Explanation
- **Line 77**: Saves the graphical tree diagram.
- **Line 88**: Saves the confusion matrix heatmap.
- **Lines 91-95**: Writes the text rules, test accuracy (formatted to 4 decimals: `0.7391`), and custom passenger probability (`0.0000`) into a structured text file.

## Worked Example

**Problem:** Cross-verify `rules.txt` against `titanic_tree.png` for a 1st-class female passenger under 37 years old.

**Cross-Verification:**
1. In `rules.txt`:
   ```text
   |--- is_female > 0.50
   |   |--- age <= 37.50
   |   |   |--- pclass <= 1.50
   |   |   |   |--- class: 1
   ```
2. In `titanic_tree.png`:
   - Follow root right arrow (`is female > 0.5`).
   - Follow internal node left arrow (`age <= 37.5`).
   - Follow internal node left arrow (`passenger class <= 1.5`).
   - Look at the leaf box: it is deep blue, with `gini = 0.0`, `samples = 8`, `value = [0, 8]`, `class = survived`.
3. The text representation and the graphical diagram match with 100% precision.

## Step-by-Step Student Instructions

1. Open your terminal in the project directory.
2. Read the text artifact:
   ```bash
   cat outputs/rules.txt
   ```
3. Open `outputs/titanic_tree.png` and `outputs/confusion_matrix.png` side by side in your image viewer.
4. Locate the two largest leaves in the tree:
   - The large non-survivor leaf for older males (`value = [33, 5]`, orange).
   - The large survivor leaf for 1st-class females (`value = [0, 8]`, blue).
5. Confirm that the total test samples in `confusion_matrix.png` ($13 + 3 + 3 + 4 = 23$) correspond to the 73.9% accuracy recorded in `rules.txt`.

## Expected Output or Observable Behaviour

You will observe complete consistency across all three files:
- `rules.txt` documents the exact logic.
- `titanic_tree.png` visualizes that logic with color-coded node purity.
- `confusion_matrix.png` proves the model's accuracy (17/23) on unseen test data.

## Practical Exercises

**Exercise 2.1:** In `outputs/rules.txt`, find the rule branch that leads to survival (`class: 1`) for male passengers. What conditions must a male passenger satisfy to be predicted as survived?  
**Exercise 2.2:** What is the Gini impurity and sample count of the leaf node described in Exercise 2.1 on `outputs/titanic_tree.png`?  
**Exercise 2.3:** Why is it advantageous to store both text rules (`rules.txt`) and visual images (`titanic_tree.png`) in automated workflows?  

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Assuming `rules.txt` and `titanic_tree.png` represent different models | They are two different renderings of the exact same underlying estimator | Use text for code audits and PNG for human presentations |
| Ignoring `bbox_inches="tight"` | Matplotlib clips outer node labels, cutting off text | Always pass `bbox_inches="tight"` in `savefig` |
| Opening image files in a text editor | Displays unreadable binary garbage | Open PNG files with an image viewer or VS Code preview |

## Best Practices and Security Considerations

- **Artifact Versioning:** Tag and archive output directories alongside code commits (e.g., using tools like DVC or MLflow) so that every trained model can be audited years later.
- **Consistent Feature Names:** Ensure that feature names passed to `export_text` and `plot_tree` use identical capitalization and wording.

## Summary

The Titanic Survival Oracle generates a complementary triad of outputs: `rules.txt` provides lightweight plain-text logic for version control and automated testing; `titanic_tree.png` delivers an intuitive visual diagram for stakeholders; and `confusion_matrix.png` provides an empirical audit of classification errors. Together, these artifacts provide complete transparency into the model's behavior.

## Knowledge-check Questions

1. Which artifact is best suited for checking into Git version control to diff model changes?
2. Which artifact is best suited for presenting to non-technical business stakeholders?
3. What color represents pure survivor leaf nodes in `outputs/titanic_tree.png`?
4. What test accuracy is recorded at the bottom of `outputs/rules.txt`?
5. How many total errors are shown in `outputs/confusion_matrix.png`?

## References

- [Data Version Control (DVC) for Machine Learning](https://dvc.org/)
- [MLflow Model Tracking and Artifact Management](https://mlflow.org/)
- [Matplotlib savefig bbox_inches Documentation](https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.savefig.html)
