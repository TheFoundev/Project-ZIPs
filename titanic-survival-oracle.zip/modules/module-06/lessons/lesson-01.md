# Lesson 01: End-to-End Pipeline Execution and Output Generation

**Lesson ID:** lesson-01  
**Module:** module-06  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Execute `main.py` from start to finish within a terminal environment
- Trace the complete sequential execution flow of all 101 lines of source code
- Verify that all three persistent output artifacts are successfully generated in `outputs/`
- Troubleshoot common environment, library, and execution issues

## Prerequisites
- Completion of Modules 01 through 05
- Functional Python 3 environment with required packages (`pandas`, `matplotlib`, `scikit-learn`)

## Concept Explanation

### The Anatomy of an End-to-End Machine Learning Script
A production-grade beginner machine learning script is designed to run non-interactively from the command line:
```bash
python3 main.py
```
When executed, `main.py` performs a complete, deterministic workflow:
1. **Module Import & Headless Setup (lines 10-20):** Loads libraries and sets the non-GUI matplotlib `"Agg"` backend.
2. **Directory Management (lines 21-25):** Resolves canonical paths and creates `outputs/` via `mkdir(exist_ok=True)`.
3. **Data Ingestion & Feature Engineering (lines 28-33):** Loads `titanic_practice.csv`, creates `is_female`, and separates matrix $X$ and vector $y$.
4. **Stratified Splitting (lines 35-37):** Divides into 67 training samples and 23 test samples.
5. **Model Induction (lines 39-40):** Fits `DecisionTreeClassifier(max_depth=4, random_state=42)`.
6. **Inference & Metrics (lines 41-55):** Computes predictions, overall accuracy, printed rules, and classification report.
7. **Custom Inference (lines 57-63):** Calculates survival probability for a synthetic 25-year-old 3rd-class female.
8. **Visualization Generation (lines 65-89):** Plots and saves `titanic_tree.png` and `confusion_matrix.png`.
9. **Rule Persistence (lines 91-95):** Writes `rules.txt`.
10. **Console Summary & Experiment Prompt (lines 96-98):** Confirms saved files and suggests hyperparameter experiments.

## Relevant Code (from main.py, lines 27-28, 96-101)

```python
def main() -> None:
    df = pd.read_csv(DATA / "titanic_practice.csv")
# ...
    print("\nSaved: outputs/titanic_tree.png, outputs/confusion_matrix.png, outputs/rules.txt")
    print("Try this: change max_depth to 2 or 5 and compare the rules.")


if __name__ == "__main__":
    main()
```

## Code Explanation
- **Line 27**: `def main() -> None:` wraps the script logic inside a structured entry function.
- **Lines 100-101**: The standard Python idiom `if __name__ == "__main__": main()` ensures that `main()` runs when executed directly from the command line, while permitting other scripts or tests to import helper definitions without automatically triggering execution.
- **Lines 96-98**: Provides clear user feedback indicating which files were written and suggests concrete next steps for experimentation.

## Worked Example

**Problem:** How does `if __name__ == "__main__":` protect automated testing frameworks?

**Solution:**
1. If a student writes a unit test:
   ```python
   from main import features, DATA
   ```
2. Without `if __name__ == "__main__":`, Python executes the entire script upon import: loading data, fitting models, plotting figures, and printing 50 lines to the console!
3. With `if __name__ == "__main__":`, `main()` only runs when `main.py` is called directly (`python main.py`). When imported as a module, `__name__` equals `"main"`, so the runner remains quiet and fast.

## Step-by-Step Student Instructions

1. Open your terminal and navigate to the project directory:
   ```bash
   cd "/home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/03_titanic_survival"
   ```
2. Check that the `outputs/` folder is empty or remove old artifacts:
   ```bash
   rm -rf outputs/*.png outputs/*.txt
   ```
3. Run `main.py`:
   ```bash
   python3 main.py
   ```
4. Check the return exit code to verify clean execution without errors:
   ```bash
   echo $?
   ```
   (Must return `0`).
5. Verify that all 3 expected output files exist and are non-empty:
   ```bash
   ls -lh outputs/
   ```

## Expected Output or Observable Behaviour

Executing `python3 main.py` prints:
```text
============================================================
THE TITANIC SURVIVAL ORACLE
============================================================
Accuracy: 73.9%

Learned rules:

|--- is female (1=yes) <= 0.50
...
              precision    recall  f1-score   support

           0       0.81      0.81      0.81        16
           1       0.57      0.57      0.57         7

    accuracy                           0.74        23
   macro avg       0.69      0.69      0.69        23
weighted avg       0.74      0.74      0.74        23

Made-up passenger survival probability: 0.0%

Saved: outputs/titanic_tree.png, outputs/confusion_matrix.png, outputs/rules.txt
Try this: change max_depth to 2 or 5 and compare the rules.
```
And `ls -lh outputs/` confirms:
- `titanic_tree.png` (~150-250 KB)
- `confusion_matrix.png` (~30-60 KB)
- `rules.txt` (~1-2 KB)

## Practical Exercises

**Exercise 1.1:** Run `python3 main.py` and pipe the output to a log file: `python3 main.py > outputs/run.log`. Verify the contents of `run.log`.  
**Exercise 1.2:** What happens if `data/titanic_practice.csv` is temporarily renamed to `titanic.csv`? What exact error message does Python display?  
**Exercise 1.3:** Measure the execution time of `main.py` using `time python3 main.py`. How many seconds does the full pipeline take to run?  

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Running `python main.py` from outside the project directory without absolute paths | Older scripts crash looking for `./data/` | `main.py` uses `Path(__file__)` to prevent this |
| Missing `outputs/` directory | Python crashes with `FileNotFoundError` when saving | `main.py` calls `OUT.mkdir(exist_ok=True)` |
| Missing packages (`No module named 'sklearn'`) | Dependencies not installed in the active environment | Run `pip install pandas matplotlib scikit-learn` |

## Best Practices and Security Considerations

- **Modular Script Structure:** Always place script logic inside a `main()` function with an `if __name__ == "__main__":` guard.
- **Exit Codes:** Ensure scripts return standard exit code 0 on success and non-zero on failure so automated build systems can detect errors.

## Summary

Executing `python3 main.py` triggers an automated 10-step data science pipeline that loads data, engineers features, trains a decision tree, computes comprehensive metrics, and exports three essential artifacts (`titanic_tree.png`, `confusion_matrix.png`, `rules.txt`). The script is resilient, self-contained, and fully reproducible.

## Knowledge-check Questions

1. What command executes `main.py` from the terminal?
2. What exit code indicates that a script ran to completion without errors?
3. What is the purpose of `if __name__ == "__main__":`?
4. What three output files are created in the `outputs/` folder?
5. How long does the entire training and inference pipeline take to execute?

## References

- [Python Standard Library: __main__ — Top-level code environment](https://docs.python.org/3/library/__main__.html)
- [GNU Bash Exit Status Conventions](https://www.gnu.org/software/bash/manual/html_node/Exit-Status.html)
- [Building Reproducible ML Pipelines (Martin Fowler)](https://martinfowler.com/articles/cd4ml.html)
