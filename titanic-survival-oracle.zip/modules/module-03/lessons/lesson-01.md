# Lesson 01: How Decision Trees Work: Splitting Criteria and Gini Impurity

**Lesson ID:** lesson-01  
**Module:** module-03  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain the recursive binary splitting mechanism used by Classification and Regression Trees (CART)
- Define node purity and explain why algorithms seek homogeneous partitions
- Calculate Gini Impurity mathematically for a given set of class labels
- Explain how scikit-learn searches across all features and candidate split thresholds to maximize impurity reduction

## Prerequisites
- Module 01: Project Overview & Problem Understanding
- Module 02: Data Loading & Feature Engineering
- Basic arithmetic and fractions

## Concept Explanation

### The Goal of Splitting: Purity
Imagine you have a jar containing 50 red marbles and 50 blue marbles. If you reach in blindfolded, you are totally uncertain of which color you will draw. This jar has **maximum impurity**.

Now imagine you can ask a question that sorts the marbles into two bowls:
- Bowl A: 50 red marbles, 0 blue marbles
- Bowl B: 0 red marbles, 50 blue marbles

Both bowls are now **100% pure**. Any sample drawn from Bowl A is guaranteed to be red! 

A **Decision Tree** algorithm operates on this exact principle. At every step, it searches across all available features and candidate numerical thresholds to find the single split that separates survivors from non-survivors with the greatest increase in purity.

### The Gini Impurity Formula
Scikit-learn's default splitting criterion for classification is the **Gini Impurity** ($I_G$). For a binary classification problem with classes 0 and 1, Gini Impurity is defined as:

$$I_G = 1 - (p_0^2 + p_1^2)$$

Where:
- $p_0$ is the proportion of class 0 samples in the node.
- $p_1$ is the proportion of class 1 samples in the node.

#### Interpreting Gini Values:
- **$I_G = 0.0$ (Pure Node):** All samples in the node belong to a single class (e.g., $p_0 = 1.0, p_1 = 0.0 \rightarrow 1 - (1^2 + 0^2) = 0$). No further splitting is necessary!
- **$I_G = 0.5$ (Maximum Impurity):** Samples are equally split between both classes (e.g., $p_0 = 0.5, p_1 = 0.5 \rightarrow 1 - (0.5^2 + 0.5^2) = 1 - 0.5 = 0.5$).
- **$0.0 < I_G < 0.5$:** A mixture where one class predominates.

### Recursive Binary Splitting
The tree algorithm is greedy:
1. It iterates through every feature (`pclass`, `is_female`, `age`, `fare`).
2. For each feature, it sorts the values and tests candidate split points.
3. It computes the weighted Gini impurity of the resulting left and right child nodes.
4. It selects the split that produces the greatest drop in impurity (**Gini Gain**).
5. It repeats this process recursively on each child node until a stopping condition is met.

## Relevant Code (from main.py, lines 19, 39)

```python
from sklearn.tree import DecisionTreeClassifier, export_text, plot_tree

# ...

    model = DecisionTreeClassifier(max_depth=4, random_state=42)
    model.fit(X_train, y_train)
```

## Code Explanation
- **Line 19**: Imports `DecisionTreeClassifier` from `sklearn.tree`.
- **Line 39**: When instantiated without the `criterion` parameter specified, `DecisionTreeClassifier` defaults to `criterion="gini"`. During `model.fit(X_train, y_train)`, it computes Gini impurity across all candidate splits to construct the tree.

## Worked Example

**Problem:** Calculate the Gini impurity of the root node of our training set. The training set has 67 passengers: 43 non-survivors (`class 0`) and 24 survivors (`class 1`).

**Solution:**
1. Calculate class proportions:
   $$p_0 = \frac{43}{67} \approx 0.6418$$
   $$p_1 = \frac{24}{67} \approx 0.3582$$
2. Square the proportions:
   $$p_0^2 \approx (0.6418)^2 \approx 0.4119$$
   $$p_1^2 \approx (0.3582)^2 \approx 0.1283$$
3. Sum the squared proportions:
   $$p_0^2 + p_1^2 \approx 0.4119 + 0.1283 \approx 0.5402$$
4. Compute Gini Impurity:
   $$I_G = 1 - 0.5402 = 0.4598 \approx 0.460$$
When you inspect `outputs/titanic_tree.png`, the root node displays `gini = 0.46`!

## Step-by-Step Student Instructions

1. Open your terminal and launch Python:
   ```bash
   python3
   ```
2. Write a small function to compute Gini impurity:
   ```python
   def gini(n_0, n_1):
       total = n_0 + n_1
       if total == 0:
           return 0.0
       p0 = n_0 / total
       p1 = n_1 / total
       return 1.0 - (p0**2 + p1**2)

   print("Pure node (10 non-survivors, 0 survivors):", gini(10, 0))
   print("Even split (20 non-survivors, 20 survivors):", gini(20, 20))
   print("Training root (43 non-survivors, 24 survivors):", round(gini(43, 24), 3))
   ```
3. Verify that the output matches our worked example calculation.

## Expected Output or Observable Behaviour

Executing the python script produces:
```text
Pure node (10 non-survivors, 0 survivors): 0.0
Even split (20 non-survivors, 20 survivors): 0.5
Training root (43 non-survivors, 24 survivors): 0.46
```
This confirms that a completely homogeneous node has an impurity of 0.0, an equal mix has an impurity of 0.5, and our training root has an impurity of ~0.46.

## Practical Exercises

**Exercise 1.1:** A child node contains 2 survivors and 8 non-survivors. Calculate its Gini impurity by hand.  
**Exercise 1.2:** If a split results in a node containing only survivors (e.g., 15 survivors and 0 non-survivors), what is its Gini impurity? Can this node be split any further?  
**Exercise 1.3:** What alternative criterion can `DecisionTreeClassifier` use instead of `"gini"`? (Hint: check scikit-learn documentation for the `criterion` parameter).  

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Thinking higher Gini is better | Higher Gini indicates greater chaos/impurity; lower Gini indicates purity | The algorithm seeks splits that *minimize* resulting Gini impurity |
| Confusing Gini impurity with the economic Gini coefficient | While mathematically related in origin, economic Gini measures income distribution across a country, whereas CART Gini measures class heterogeneity in a node | Use the ML definition: $1 - \sum p_i^2$ |
| Assuming splits can only be equal 50/50 divisions | Splits can separate 1 sample from 66 samples if that split achieves the best impurity reduction | Let the algorithm evaluate all possible cut points |

## Best Practices and Security Considerations

- **Default Criterion:** Gini impurity is computationally faster to calculate than Shannon Entropy (which requires logarithmic calculations) and produces virtually identical trees in almost all practical applications.
- **Handling Zero Denominators:** When writing custom impurity metrics, always guard against division by zero if a node has 0 total samples.

## Summary

Decision trees build decision logic through recursive binary splitting. At each internal node, the algorithm evaluates every candidate split across all features, selecting the split that minimizes the weighted Gini impurity of the child nodes. A pure node containing only one class has a Gini impurity of 0.0, while a perfectly mixed 50/50 node has a maximum impurity of 0.5.

## Knowledge-check Questions

1. What is the mathematical formula for Gini impurity in binary classification?
2. What is the Gini impurity of a node that contains only survivors?
3. What is the maximum possible Gini impurity for a binary classification problem?
4. What is the default splitting criterion used by `DecisionTreeClassifier` in scikit-learn?
5. Why does a decision tree stop splitting when a node reaches a Gini impurity of 0.0?

## References

- [Scikit-learn Decision Trees Mathematical Formulation](https://scikit-learn.org/stable/modules/tree.html#mathematical-formulation)
- [StatQuest: Decision Trees and Gini Impurity (Josh Starmer)](https://www.youtube.com/watch?v=7VeUPuFGJHk)
- [Introduction to Statistical Learning (James, Witten, Hastie, Tibshirani)](https://www.statlearning.com/)
