# Lesson 04: Visualizing Trees Graphically with `plot_tree` and Matplotlib

**Lesson ID:** lesson-04  
**Module:** module-03  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Use `sklearn.tree.plot_tree` in combination with matplotlib to draw decision tree flowcharts
- Configure visual styling options including `filled=True`, `rounded=True`, `class_names`, and `fontsize`
- Interpret visual node elements: split condition, Gini value, sample count, class distributions, and color coding
- Export publication-quality tree graphics to `outputs/titanic_tree.png` with `fig.savefig()`

## Prerequisites
- Lesson 01: How Decision Trees Work: Splitting Criteria and Gini Impurity
- Lesson 02: Controlling Tree Complexity with `max_depth`
- Lesson 03: Rendering Plain-Text Decision Rules with `export_text`

## Concept Explanation

### Why Graphical Tree Visualizations Matter
While text rules provide fast terminal logs, a graphic visualization makes the hierarchical structure immediately intuitive. A stakeholder can glance at a colored diagram and immediately see:
- Which branch is thickest (where most passengers went).
- Which leaves are pure blue (survivors) vs. pure orange (non-survivors).
- Which splits had the greatest impact on passenger outcomes.

### Anatomy of a `plot_tree` Node Box
In the rendered flowchart, each node box displays four critical pieces of information:
1. **Split Condition (top line):** The decision question (e.g., `is female <= 0.5`). Leaf nodes omit this line.
2. **`gini = X.XXX`:** The current impurity of the samples in that node.
3. **`samples = N`:** The total number of training records currently at that node.
4. **`value = [n_0, n_1]`:** The breakdown of samples by class (e.g., `value = [43, 24]` means 43 non-survivors and 24 survivors).
5. **`class = ...`:** The majority class label (`did not survive` or `survived`).

```
┌─────────────────────────────────┐
│       is female <= 0.5          │  <-- Split Condition
│          gini = 0.46            │  <-- Impurity
│          samples = 67           │  <-- Sample Count
│        value = [43, 24]         │  <-- Class Breakdown
│    class = did not survive      │  <-- Majority Class
└─────────────────────────────────┘
```

### Visual Styling Parameters
- `filled=True`: Colors nodes according to their majority class. The color intensity increases as node purity ($I_G \rightarrow 0$) increases! In scikit-learn, orange indicates class 0 (did not survive) and blue indicates class 1 (survived). Pure white indicates a 50/50 mix.
- `rounded=True`: Draws rounded corners on the boxes for modern aesthetics.
- `fontsize=9`: Shrinks text so labels do not overlap when multiple nodes sit side by side.
- `fig.savefig(..., dpi=150, bbox_inches="tight")`: Exports a crisp, 150 DPI image without clipping outer labels.

## Relevant Code (from main.py, lines 64-78)

```python
    # ---- Draw the tree -------------------------------------------------
    fig, ax = plt.subplots(figsize=(13, 7))
    plot_tree(
        model,
        feature_names=["passenger class", "is female", "age", "fare"],
        class_names=["did not survive", "survived"],
        filled=True,
        rounded=True,
        fontsize=9,
        ax=ax,
    )
    ax.set_title("A decision tree you can read from top to bottom")
    fig.tight_layout()
    fig.savefig(OUT / "titanic_tree.png", dpi=150, bbox_inches="tight")
    plt.close(fig)
```

## Code Explanation
- **Line 65**: Creates a large figure canvas of dimensions 13 inches wide by 7 inches tall (`figsize=(13, 7)`) to provide ample horizontal room for 16 leaf nodes.
- **Lines 66-74**: Configures `plot_tree` with feature names, human-readable class names, filled colors, rounded boxes, readable font size, and attaches it to `ax`.
- **Line 75**: Sets the plot title.
- **Line 76**: `fig.tight_layout()` adjusts subplots to fit snugly into the figure area.
- **Line 77**: Saves the rendered figure to `outputs/titanic_tree.png` with 150 DPI resolution.
- **Line 78**: `plt.close(fig)` frees the figure memory, preventing resource leaks.

## Worked Example

**Problem:** When inspecting `outputs/titanic_tree.png`, you see a leaf node that is deep royal blue with `value = [0, 8]` and `gini = 0.0`. What does this indicate?

**Solution:**
1. `gini = 0.0`: The node is completely pure.
2. `value = [0, 8]`: There are 0 non-survivors and 8 survivors.
3. The deep blue color signifies a 100% pure positive class node (`class = survived`).
4. Any unseen passenger whose feature values guide them to this leaf will be predicted as survived with 100% estimated probability.

## Step-by-Step Student Instructions

1. Execute `main.py` in your terminal:
   ```bash
   python3 main.py
   ```
2. Open `outputs/titanic_tree.png` using an image viewer or VS Code preview.
3. Locate the Root Node at the top center. Verify that:
   - It tests `is female <= 0.5`.
   - `gini = 0.46`.
   - `samples = 67`.
   - `value = [43, 24]`.
4. Follow the right arrow (`is female > 0.5`, female passengers). Notice how the majority of nodes along this branch turn shades of blue.
5. Follow the left arrow (`is female <= 0.5`, male passengers). Notice how almost all nodes along this branch turn shades of orange.

## Expected Output or Observable Behaviour

Opening `outputs/titanic_tree.png` displays a clean, readable hierarchical tree diagram:
- 4 full levels of depth.
- Clear separation between male branches (left, predominantly orange) and female branches (right, predominantly blue).
- Node boxes showing split conditions, Gini, sample counts, values, and class labels.

## Practical Exercises

**Exercise 4.1:** What happens if you omit `plt.close(fig)` when generating hundreds of plots in a batch loop?  
**Exercise 4.2:** Why is `figsize=(13, 7)` chosen instead of the default `(6.4, 4.8)`? What happens to text readability if the figure is too small?  
**Exercise 4.3:** In `plot_tree`, which color corresponds to class 0, and which color corresponds to class 1 when `filled=True`?  

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Omitting `plt.close(fig)` | Leaks memory and leaves open file handles in the background | Always call `plt.close(fig)` after saving |
| Inverting `class_names` order | Mislabels survivors as non-survivors in the visual diagram | Always list classes in ascending numerical order: `["did not survive", "survived"]` (class 0, then class 1) |
| Using low DPI (e.g. 50 DPI) | Diagram text is pixelated and illegible | Use `dpi=150` or `300` |

## Best Practices and Security Considerations

- **Memory Hygiene:** Always close matplotlib figures (`plt.close(fig)`) immediately after saving to avoid memory consumption spikes in automated pipelines.
- **Label Alignment:** Double check that `class_names` accurately reflects class 0 first and class 1 second. Swapping their order will display inverted labels without throwing any Python errors!

## Summary

`sklearn.tree.plot_tree` generates visual flowchart diagrams of trained decision trees. By configuring `filled=True`, nodes are automatically shaded according to class purity (blue for survivors, orange for non-survivors). Specifying `figsize=(13, 7)`, `rounded=True`, and `dpi=150` produces publication-quality graphics saved directly to `outputs/titanic_tree.png`.

## Knowledge-check Questions

1. Which parameter in `plot_tree` colors the node boxes based on majority class and purity?
2. What does `value = [43, 24]` in a node box indicate?
3. Why is `figsize=(13, 7)` used for plotting this decision tree?
4. What order must class names be specified in the `class_names` argument?
5. Why is `plt.close(fig)` essential in Python plotting scripts?

## References

- [Scikit-learn plot_tree API Documentation](https://scikit-learn.org/stable/modules/generated/sklearn.tree.plot_tree.html)
- [Matplotlib Pyplot Subplots Documentation](https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.subplots.html)
- [Visualizing Decision Trees with Python (Scikit-Learn, Graphviz, Matplotlib)](https://towardsdatascience.com/visualizing-decision-trees-with-python-scikit-learn-graphviz-matplotlib-1f5b7abb4af5)
