# Lesson 03: Rendering Plain-Text Decision Rules with `export_text`

**Lesson ID:** lesson-03  
**Module:** module-03  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Use `sklearn.tree.export_text` to extract and print a human-readable text representation of a trained decision tree
- Configure descriptive feature names using the `feature_names` parameter
- Interpret indentation levels and inequality symbols (`<=` and `>`) in text rules
- Write plain-text rules to an external text file (`outputs/rules.txt`) for documentation and audits

## Prerequisites
- Lesson 01: How Decision Trees Work: Splitting Criteria and Gini Impurity
- Lesson 02: Controlling Tree Complexity with `max_depth`

## Concept Explanation

### Why Plain-Text Decision Rules Matter
While graphical flowcharts are aesthetically appealing, plain text has decisive advantages in engineering workflows:
1. **Accessibility:** Plain text can be displayed directly in terminal logs, CI/CD runners, and command-line interfaces.
2. **Searchability & Version Control:** Text rules can be diffed with `git`, parsed by regex, and stored in lightweight databases or compliance audit logs.
3. **Instant Auditing:** Regulators and non-technical domain experts can read plain English if-then statements without needing image viewers.

### How `export_text` Formats Rules
Scikit-learn provides `export_text(decision_tree, feature_names=...)`, which translates the internal tree array into an indented hierarchy:
- Each vertical pipe (`|`) and dashes (`|---`) indicate an increase in tree depth.
- Nodes at the same indentation level share the same parent.
- Every decision node contains an inequality condition (e.g., `is female (1=yes) <= 0.50`).
- If the condition is True, execution proceeds down the immediate block.
- Leaf nodes terminate with `|--- class: 0` or `|--- class: 1`.

```text
|--- is female (1=yes) <= 0.50          <-- Root Node (Depth 0)
|   |--- age <= 18.50                   <-- Child Decision Node (Depth 1)
|   |   |--- age <= 14.50               <-- Child Decision Node (Depth 2)
|   |   |   |--- passenger class <= 2.50<-- Child Decision Node (Depth 3)
|   |   |   |   |--- class: 0           <-- Leaf Node (Depth 4)
```

### Providing Human-Friendly Feature Names
By default, if you don't supply `feature_names`, `export_text` generates generic labels like `feature_0 <= 0.50` and `feature_2 <= 18.50`. 
By passing `feature_names=["passenger class", "is female (1=yes)", "age", "fare"]`, the output becomes instantly intelligible to anyone.

## Relevant Code (from main.py, lines 48-54, 91-95)

```python
    print("Learned rules:\n")
    print(
        export_text(
            model,
            feature_names=["passenger class", "is female (1=yes)", "age", "fare"],
        )
    )

# ...

    with open(OUT / "rules.txt", "w", encoding="utf-8") as handle:
        handle.write(export_text(model, feature_names=features))
        handle.write(f"\naccuracy: {accuracy:.4f}\n")
        handle.write(f"made-up passenger survival probability: {probability:.4f}\n")
```

## Code Explanation
- **Lines 48-54**: Calls `export_text(model, feature_names=...)` with descriptive custom strings and prints the output to stdout.
- **Lines 91-95**: Opens `outputs/rules.txt` with UTF-8 encoding and writes the plain-text tree rules alongside final model accuracy and custom prediction metrics.

## Worked Example

**Problem:** Read the following branch from `outputs/rules.txt` and convert it into a plain English paragraph for a ship safety report:
```text
|--- is female (1=yes) >  0.50
|   |--- age <= 37.50
|   |   |--- passenger class <= 1.50
|   |   |   |--- class: 1
```

**Solution:**
- Condition 1: `is female > 0.50` means the passenger is female.
- Condition 2: `age <= 37.50` means the passenger is 37 years old or younger.
- Condition 3: `passenger class <= 1.50` means the passenger is in 1st class (`pclass = 1`).
- **Plain English translation:** "For female passengers aged 37 or younger traveling in first class, the model predicts that they survived."

## Step-by-Step Student Instructions

1. Run `main.py` in your terminal:
   ```bash
   python3 main.py
   ```
2. Locate and open the generated file `outputs/rules.txt`:
   ```bash
   cat outputs/rules.txt
   ```
3. Count the number of leaf nodes (`|--- class:`) in the text output.
4. Verify that the feature names in `outputs/rules.txt` match `features = ["pclass", "is_female", "age", "fare"]`.

## Expected Output or Observable Behaviour

The contents of `outputs/rules.txt` will look like:
```text
|--- is_female <= 0.50
|   |--- age <= 18.50
|   |   |--- age <= 14.50
|   |   |   |--- pclass <= 2.50
|   |   |   |   |--- class: 0
|   |   |   |--- pclass >  2.50
|   |   |   |   |--- class: 0
|   |   |--- age >  14.50
|   |   |   |--- pclass <= 1.50
|   |   |   |   |--- class: 0
|   |   |   |--- pclass >  1.50
|   |   |   |   |--- class: 1
...
accuracy: 0.7391
made-up passenger survival probability: 0.0000
```
Every decision pathway from top to bottom is explicitly laid out in human-readable notation.

## Practical Exercises

**Exercise 3.1:** What happens if the length of the list passed to `feature_names` does not match `X.shape[1]`? Try passing only 3 feature names to `export_text` and note the exception.  
**Exercise 3.2:** What is the root split in `export_text`? What does a threshold of `<= 0.50` on `is_female` mean?  
**Exercise 3.3:** How many total lines of text are generated in `outputs/rules.txt`?  

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Omitting `feature_names` in `export_text` | Rules print with unhelpful labels like `feature_0`, `feature_1` | Always pass descriptive column names |
| Passing feature names in a different order than `X.columns` | Misattributes split rules to the wrong features | Ensure `feature_names` aligns 1:1 with `X.columns` |
| Forgetting `encoding="utf-8"` when writing text files | Can cause encoding errors on Windows systems with non-ASCII symbols | Always specify `open(..., encoding="utf-8")` |

## Best Practices and Security Considerations

- **Auditable Artifacts:** Writing text rules to disk (`outputs/rules.txt`) provides an immutable artifact that can be inspected, diffed across model retrainings, and checked into version control.
- **Encoding Safety:** Always enforce UTF-8 when reading and writing files in Python to prevent cross-platform text corruption.

## Summary

`sklearn.tree.export_text` converts complex tree models into readable text-based decision rules. By providing meaningful feature names, students and domain experts can trace every branching decision. Writing these rules to `outputs/rules.txt` ensures complete model transparency and provides an audit trail for the machine learning pipeline.

## Knowledge-check Questions

1. What function in scikit-learn converts a decision tree into plain text rules?
2. What does each indentation level (indicated by `|---`) represent in the text output?
3. What default labels are printed if `feature_names` is omitted?
4. In `outputs/rules.txt`, what do `class: 0` and `class: 1` signify?
5. Why is explicit UTF-8 encoding important when writing text rules to disk?

## References

- [Scikit-learn export_text Documentation](https://scikit-learn.org/stable/modules/generated/sklearn.tree.export_text.html)
- [PEP 597 – Use UTF-8 for default encoding](https://peps.python.org/pep-0597/)
- [Model Interpretability and Governance (NIST)](https://www.nist.gov/itl/applied-cybersecurity/nice)
