# Lesson 02: Controlling Tree Complexity with `max_depth`

**Lesson ID:** lesson-02  
**Module:** module-03  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Define what a **hyperparameter** is and how it differs from learned parameters
- Explain the phenomenon of **overfitting** in unconstrained decision trees
- Explain the role of the `max_depth` hyperparameter in pruning tree growth
- Compare model behavior and interpretability across shallow (`max_depth=2`), balanced (`max_depth=4`), and deep trees

## Prerequisites
- Lesson 01: How Decision Trees Work: Splitting Criteria and Gini Impurity
- Basic understanding of generalization vs. training performance

## Concept Explanation

### What is Overfitting in Decision Trees?
If you allow a decision tree to grow without any constraints, it will continue splitting until every single training sample occupies its own individual leaf node. At that point:
- Training accuracy reaches 100%!
- But the tree has simply memorized every quirk, typo, and outlier in the training data.
- When exposed to unseen test passengers, the overfitted model performs terribly.

This failure mode is called **overfitting** (high variance). The model has learned the training noise rather than the underlying generalizable signal.

### What is `max_depth`?
A **hyperparameter** is a setting configured by the machine learning engineer *before* training begins, which controls how the learning algorithm behaves. (In contrast, parameters are the values the model learns on its own, like split thresholds).

The `max_depth` hyperparameter sets the maximum allowable distance (in edges) from the root node to any leaf node:
- `max_depth=1` (Decision Stump): Makes only 1 split. Often **underfits** (too simple).
- `max_depth=2`: Makes at most $2^2 = 4$ leaf nodes. Very simple, highly interpretable.
- `max_depth=4` (Project Default): Allows up to $2^4 = 16$ leaf nodes. Balances nuance with generalizability.
- `max_depth=None` (Unconstrained): Grows until all leaves are pure or contain fewer than `min_samples_split` samples. Prone to severe overfitting.

```
       max_depth=1                     max_depth=2                           max_depth=4
      [Root Split]                    [Root Split]                          [Root Split]
         /    \                          /    \                                /    \
     [Leaf]  [Leaf]                 [Split]  [Split]                       [Split]  [Split]
                                    /   \    /   \                          ...       ...
                                 [L]   [L]  [L]   [L]                     (Up to 16 leaves)
   (High Bias, Underfit)          (Simple, High Readability)            (Balanced Performance)
```

### Pre-Pruning (Early Stopping)
Limiting `max_depth` is a form of **pre-pruning**—stopping tree growth before it becomes excessively complex. This improves test accuracy, keeps the model explainable, and reduces memory consumption.

## Relevant Code (from main.py, lines 39, 97)

```python
    model = DecisionTreeClassifier(max_depth=4, random_state=42)
    model.fit(X_train, y_train)

# ...

    print("Try this: change max_depth to 2 or 5 and compare the rules.")
```

## Code Explanation
- **Line 39**: `max_depth=4` explicitly constrains the tree to a maximum depth of 4 levels. `random_state=42` ensures tie-breaking across equally good splits is reproducible.
- **Line 97**: Encourages experimenting with different `max_depth` values (such as 2 or 5) to observe the trade-off between rule simplicity and classification granularity.

## Worked Example

**Problem:** Compare the test accuracy of the decision tree model when trained with `max_depth=2`, `max_depth=4`, and `max_depth=None` (unconstrained) on our Titanic dataset.

**Empirical Comparison:**
1. Train with `max_depth=2`:
   - Number of learned rules: Very few (4 leaves).
   - Test Accuracy: ~73.9%. Rules are broad (primarily separating female passengers from male passengers).
2. Train with `max_depth=4` (Project baseline):
   - Number of learned rules: Moderate (13 active leaves).
   - Test Accuracy: ~73.9%. Rules capture interactions between sex, age, class, and fare.
3. Train with `max_depth=None` (unconstrained):
   - Training Accuracy: Jumps to ~95.5%.
   - Test Accuracy: Drops to ~69.6%!
   - Why? The unconstrained tree memorized noisy training passengers who survived despite low odds, and misclassified typical test passengers as a result.

## Step-by-Step Student Instructions

1. Open your terminal in the project directory.
2. Run an experiment comparing depths directly from the command line:
   ```bash
   python3 -c "
   import pandas as pd
   from sklearn.model_selection import train_test_split
   from sklearn.tree import DecisionTreeClassifier
   from sklearn.metrics import accuracy_score

   df = pd.read_csv('data/titanic_practice.csv')
   df['is_female'] = (df['sex'] == 'female').astype(int)
   X = df[['pclass', 'is_female', 'age', 'fare']]
   y = df['survived']
   X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)

   for depth in [1, 2, 3, 4, 6, None]:
       clf = DecisionTreeClassifier(max_depth=depth, random_state=42).fit(X_train, y_train)
       train_acc = accuracy_score(y_train, clf.predict(X_train))
       test_acc = accuracy_score(y_test, clf.predict(X_test))
       print(f'max_depth={str(depth):<5} | Train Acc: {train_acc:.1%} | Test Acc: {test_acc:.1%}')
   "
   ```
3. Observe how training accuracy rises as depth increases, while test accuracy peaks and then degrades.

## Expected Output or Observable Behaviour

Executing the depth experiment prints:
```text
max_depth=1     | Train Acc: 79.1% | Test Acc: 73.9%
max_depth=2     | Train Acc: 80.6% | Test Acc: 73.9%
max_depth=3     | Train Acc: 86.6% | Test Acc: 73.9%
max_depth=4     | Train Acc: 89.6% | Test Acc: 73.9%
max_depth=6     | Train Acc: 94.0% | Test Acc: 65.2%
max_depth=None  | Train Acc: 95.5% | Test Acc: 69.6%
```
Notice how at `max_depth=6` and `max_depth=None`, the training accuracy climbs to 94-95%, but test accuracy collapses from 73.9% down to 65.2%! This is textbook overfitting.

## Practical Exercises

**Exercise 2.1:** What is the maximum theoretical number of leaf nodes for a binary tree of depth $d$? Calculate this number for `max_depth=3` and `max_depth=4`.  
**Exercise 2.2:** What is the difference between a parameter (learned) and a hyperparameter (tuned)? Give one example of each in this project.  
**Exercise 2.3:** Why is an overfitted tree risky in real-world applications like medical diagnostics?  

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Choosing `max_depth` based on training accuracy | Training accuracy always increases with depth, misleading you into severe overfitting | Evaluate hyperparameters strictly using test set or cross-validation scores |
| Assuming deeper trees are always more intelligent | Deep trees memorize random noise; shallow trees generalize better | Set a conservative `max_depth` (e.g., 3 to 5) |
| Omitting `random_state` when comparing depths | Split ties are broken non-deterministically, masking the true effect of depth changes | Always fix `random_state=42` |

## Best Practices and Security Considerations

- **Hyperparameter Tuning:** Use validation techniques (like `GridSearchCV`) to find the optimal balance between bias and variance rather than guessing.
- **Parsimony (Occam's Razor):** If a tree of depth 2 achieves the same test accuracy as a tree of depth 4, prefer the simpler depth 2 model because it is easier to understand, audit, and explain to stakeholders.

## Summary

`max_depth` is a vital hyperparameter that governs the vertical growth of a decision tree. Without depth constraints, trees overfit by memorizing individual training passengers, causing training accuracy to approach 100% while test accuracy deteriorates. Setting `max_depth=4` acts as pre-pruning, preventing overfitting and preserving model interpretability.

## Knowledge-check Questions

1. What is the fundamental difference between a hyperparameter and a learned model parameter?
2. What happens to training accuracy as `max_depth` increases?
3. What happens to test accuracy when a tree becomes excessively deep?
4. What is the name of the process that stops tree growth early to prevent overfitting?
5. Why does `main.py` select `max_depth=4`?

## References

- [Scikit-learn Hyperparameter Tuning Guide](https://scikit-learn.org/stable/modules/grid_search.html)
- [Overfitting and Underfitting in Machine Learning (Google Machine Learning Crash Course)](https://developers.google.com/machine-learning/crash-course/generalization/peril-of-overfitting)
- [Scikit-learn DecisionTreeClassifier API](https://scikit-learn.org/stable/modules/generated/sklearn.tree.DecisionTreeClassifier.html)
