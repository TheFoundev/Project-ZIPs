# Module 1 Exercises: Project Overview & Problem Understanding

## Exercise 1.1: Supervised Binary Classification Identification (10 min)
**Objective:** Distinguish supervised binary classification from regression and unsupervised learning.  
**Problem Statement:** In the Titanic Survival Oracle project, the model predicts passenger survival. You must classify this problem into its proper machine learning category and justify your answer based on dataset attributes.

**Requirements:**
1. Define supervised learning and explain why the Titanic dataset qualifies as supervised.
2. Define binary classification and state the mathematical domain of the target variable $y$.
3. Contrast this with the Lemonade Stand project (which used continuous regression).
4. Explain what each target value (`0` and `1`) represents historically.

**Constraints:** Base your justification strictly on `data/titanic_practice.csv` and `main.py`.

**Expected Behaviour:** A written explanation (4-6 sentences) clearly identifying the task type with concrete justification.

**Acceptance Criteria:**
- [ ] Supervised learning is correctly defined using labeled inputs and outputs.
- [ ] Target variable `survived` is identified with values $\{0, 1\}$.
- [ ] Binary classification is correctly distinguished from regression.
- [ ] Historical meaning of 0 (died) and 1 (survived) is stated.

**Hints:**
- Look at the values in `df["survived"].unique()`.
- Are you predicting an amount (like cups of lemonade) or a category?

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes  

---

## Exercise 1.2: Exploring the Titanic Practice Dataset (15 min)
**Objective:** Load, inspect, and summarize `data/titanic_practice.csv` using Python and pandas.  
**Problem Statement:** Before training models, data scientists must inspect the raw dataset structure, row counts, data types, and class balance.

**Requirements:**
1. Write a Python snippet to load `data/titanic_practice.csv`.
2. Print the total row and column count (`df.shape`).
3. Identify all 6 column names and their data types.
4. Count the number of survivors (`1`) versus non-survivors (`0`) using `df["survived"].value_counts()`.
5. Calculate the overall baseline survival percentage in the dataset.

**Constraints:** Use pandas and execute your code from within the project directory.

**Expected Behaviour:** Python code that outputs clean dataset dimensions, data types, and target distribution.

**Acceptance Criteria:**
- [ ] Code successfully loads `data/titanic_practice.csv`.
- [ ] Confirms exactly 90 rows and 6 columns.
- [ ] Identifies 59 non-survivors (0) and 31 survivors (1).
- [ ] Baseline survival rate is calculated as approximately 34.4%.

**Hints:**
- Use `pd.read_csv("data/titanic_practice.csv")`.
- `df["survived"].value_counts(normalize=True) * 100` computes percentages directly.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 1.3: Tracing a Manual Decision Tree (15 min)
**Objective:** Manually evaluate a passenger profile through a decision tree rule set.  
**Problem Statement:** Decision trees are fully interpretable white-box models. Given the learned rules from `main.py`, you must manually trace two test passengers and state the predicted outcome for each.

**Given Rules:**
```text
|--- is female (1=yes) <= 0.50
|   |--- age <= 18.50
|   |   |--- class: 0
|   |--- age >  18.50
|   |   |--- fare <= 15.50
|   |   |   |--- fare <= 14.30
|   |   |   |   |--- class: 0
|   |   |   |--- fare >  14.30
|   |   |   |   |--- class: 1
|   |   |--- fare >  15.50
|   |   |   |--- class: 0
|--- is female (1=yes) >  0.50
|   |--- age <= 37.50
|   |   |--- passenger class <= 1.50
|   |   |   |--- class: 1
|   |   |--- passenger class >  1.50
|   |   |   |--- age <= 23.50
|   |   |   |   |--- class: 1
|   |   |   |--- age >  23.50
|   |   |   |   |--- class: 0
```

**Passenger A:** Female (`is_female=1`), Age 22, Class 3, Fare £9.50.  
**Passenger B:** Male (`is_female=0`), Age 45, Class 1, Fare £50.00.  

**Requirements:**
1. List each decision node tested for Passenger A and the final predicted class.
2. List each decision node tested for Passenger B and the final predicted class.
3. Explain which demographic feature had the strongest initial split in the tree.

**Acceptance Criteria:**
- [ ] Passenger A correctly traced to `class: 1` (Survived: female $\rightarrow$ age $\le 37.50$ $\rightarrow$ pclass $> 1.50$ $\rightarrow$ age $\le 23.50$).
- [ ] Passenger B correctly traced to `class: 0` (Did not survive: male $\rightarrow$ age $> 18.50$ $\rightarrow$ fare $> 15.50$).
- [ ] `is_female` identified as the root decision feature.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 1.4: Headless Matplotlib and Path Architecture Verification (10 min)
**Objective:** Understand and verify the headless environment and path configuration in `main.py`.  
**Problem Statement:** Machine learning scripts often fail when deployed to automated servers because of missing GUI display servers or incorrect working directory paths. Verify how `main.py` prevents both issues.

**Requirements:**
1. Identify the exact line in `main.py` that configures headless raster rendering.
2. Explain what would occur if `matplotlib.pyplot` were imported before that configuration line on a server without an active display server.
3. Identify how `BASE` and `OUT` are defined using `pathlib.Path`.
4. Explain the purpose of `OUT.mkdir(exist_ok=True)`.

**Acceptance Criteria:**
- [ ] Line 14 (`matplotlib.use("Agg")`) correctly identified.
- [ ] Server display crash risk accurately described.
- [ ] Path definition `BASE = Path(__file__).resolve().parent` explained.
- [ ] `exist_ok=True` prevention of `FileExistsError` detailed.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 10 minutes  
