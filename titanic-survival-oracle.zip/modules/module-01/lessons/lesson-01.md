# Lesson 01: The Titanic Historical Problem and Machine Learning Framing

**Lesson ID:** lesson-01  
**Module:** module-01  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Articulate the historical context of the RMS Titanic maritime tragedy and why passenger survival data is a landmark benchmark in data science
- Define supervised learning within the context of historical survival records
- Distinguish between input attributes (passenger demographics/ticket data) and the prediction objective
- Explain why predictive modeling on historical events helps uncover socioeconomic and structural factors in survival outcomes

## Prerequisites
- Basic familiarity with computer programming concepts (variables, data types)
- Curiosity about how real-world historical records are modeled mathematically

## Concept Explanation

### The Historical Event and the Problem Statement
On the night of April 14–15, 1912, the RMS Titanic struck an iceberg during her maiden voyage across the Atlantic Ocean and sank. Of the estimated 2,224 passengers and crew aboard, more than 1,500 lost their lives. 

Crucially, the chances of survival were not purely random. Historical maritime protocol ("women and children first"), the physical layout of the ship (first-class staterooms were closest to the boat deck, whereas third-class quarters were deep below), ticket prices, and passenger age all heavily influenced who reached lifeboats in time.

In machine learning, **The Titanic Survival Oracle** frames this tragic historical event as an empirical prediction problem:
> **Given a passenger's personal attributes (socioeconomic class, sex, age, ticket fare), can an algorithm accurately predict whether that individual survived or perished?**

### Why is this Supervised Machine Learning?
In **supervised learning**, an algorithm learns patterns from **labeled historical examples**—a dataset where both the input features (passenger profiles) and the true known outcome (whether they survived or not) are already recorded.

The dataset `titanic_practice.csv` contains 90 practice passenger records. The algorithm studies these 90 passengers, discovers relationships between attributes and survival, and builds a mathematical model that can make predictions on passengers it has never seen before.

### Features vs. The Target
In supervised machine learning, we divide our data into two fundamental roles:
1. **Features ($X$):** The measurable characteristics or attributes of each observation. In this project, the features are:
   - `pclass`: Passenger ticket class (1 = 1st class luxury, 2 = 2nd class, 3 = 3rd class steerage)
   - `is_female`: Gender encoded as a binary number (1 for female, 0 for male)
   - `age`: Passenger age in years
   - `fare`: Ticket fare paid in British pounds
2. **Target ($y$):** The specific outcome we want our model to predict. Here, the target is:
   - `survived`: A binary label where `1` indicates survival and `0` indicates the passenger perished.

## Relevant Code (from main.py, lines 1-8)

```python
"""Project 03: The Titanic Survival Oracle (decision tree).

Run:
    python main.py

A small practice dataset inspired by the Titanic.  The decision tree learns
simple yes/no rules and prints them so you can read the model's logic.
"""
```

## Code Explanation
- **Lines 1-8**: The module docstring immediately sets the objective. The script is called an "Oracle" because, when given any passenger's details, it consults its learned rules to divine their likely survival outcome.
- The docstring highlights that this project uses a **decision tree**, emphasizing that the model learns simple, transparent yes/no rules rather than functioning as an unreadable black box.

## Worked Example

**Problem:** Suppose an archivist finds a newly discovered passenger record from 1912:
- Name: Countess of Rothes
- Class: 1st class (`pclass = 1`)
- Sex: Female (`is_female = 1`)
- Age: 33 (`age = 33`)
- Fare: £86.50 (`fare = 86.5`)

Historically, how does supervised learning approach this individual?

**Solution:**
1. We structure the passenger's information into a feature vector: `[1, 1, 33, 86.5]`.
2. Notice that the passenger's name is not used because names are unique identifiers that do not provide generalizable statistical patterns.
3. The supervised model checks the patterns learned from the training data (e.g., "1st-class female passengers had an overwhelming probability of lifeboat access").
4. The model evaluates its rules and assigns a predicted target label: `survived = 1`. (Historically, the Countess did indeed board lifeboat 8 and survived).

## Step-by-Step Student Instructions

1. Open your terminal and navigate to the project directory:
   ```bash
   cd "/home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/03_titanic_survival"
   ```
2. Open `main.py` in your text editor and inspect the introductory docstring (lines 1-8).
3. Open `data/titanic_practice.csv` and view the first 10 rows:
   ```bash
   head -n 10 data/titanic_practice.csv
   ```
4. Observe the column headers: `passenger_id, pclass, sex, age, fare, survived`.
5. Identify which column is the target label that our model must predict (`survived`).

## Expected Output or Observable Behaviour

When inspecting the CSV header and rows, you will observe tabular data formatted as follows:
```text
passenger_id,pclass,sex,age,fare,survived
1,3,male,10,19.7,0
2,3,male,23,15.2,1
3,1,female,32,25.3,1
4,1,female,44,54.9,0
5,3,male,1,14.5,1
```
Notice that each row represents one passenger, and every row contains known values for both inputs (class, sex, age, fare) and the final ground-truth result (`survived`).

## Practical Exercises

**Exercise 1.1:** Look at row 1 of `titanic_practice.csv` (`1,3,male,10,19.7,0`). List the 4 feature values and the target value for this passenger.  
**Exercise 1.2:** Why is `passenger_id` not included as a predictive feature in machine learning models?  
**Exercise 1.3:** In your own words, explain why this problem is categorized as "supervised" learning rather than "unsupervised" learning.  

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Including `passenger_id` as a predictive feature | Passenger ID is an arbitrary sequential number; it has no causal or statistical relationship with survival | Exclude identifier columns during feature selection |
| Confusing the target with input features | The target is what we want to predict; features are what we know in advance | Keep `survived` separate as vector $y$, and the demographic attributes in matrix $X$ |
| Assuming survival was purely random | Physical deck levels and maritime protocols strongly favored specific demographics | Use machine learning to systematically capture these deterministic survival patterns |

## Best Practices and Security Considerations

- **Ethical Context in Modeling:** Historical datasets reflect historical realities, including socioeconomic inequality and tragedy. In data science, treat historical demographic data with respect and objectivity.
- **Identifier Separation:** Always strip out artificial database keys, serial numbers, or passenger IDs before training models to avoid spurious correlations.
- **Reproducible Data Paths:** Use path libraries (like Python's `pathlib.Path`) rather than hardcoded operating system strings.

## Summary

The Titanic Survival Oracle uses supervised machine learning to predict whether passengers survived the 1912 disaster based on their class, sex, age, and fare. Supervised learning requires labeled training data where both the input features ($X$) and the ground-truth target label ($y$) are known. By learning from 90 historical passenger records, the model uncovers the socioeconomic and demographic factors that determined survival.

## Knowledge-check Questions

1. What is the fundamental difference between a feature and a target in supervised learning?
2. What are the 4 input features used by the Titanic Survival Oracle?
3. What does a value of `0` represent in the `survived` column? What does `1` represent?
4. Why would training a model on `passenger_id` lead to poor predictive performance on new passengers?
5. Why is this project classified as supervised learning?

## References

- [Scikit-learn Supervised Learning Overview](https://scikit-learn.org/stable/supervised_learning.html)
- [British Wreck Commissioner's Inquiry Report on the Sinking of the Titanic (National Archives)](https://www.titanicinquiry.org/)
- [Pandas Introduction to Data Structures](https://pandas.pydata.org/docs/user_guide/dsintro.html)
