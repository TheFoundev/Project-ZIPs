# Lesson 02: Binary Classification vs. Regression

**Lesson ID:** lesson-02  
**Module:** module-01  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Distinguish between classification and regression tasks in supervised machine learning
- Define binary classification and recognize its mathematical formulation ($y \in \{0, 1\}$)
- Contrast the Titanic survival problem with continuous prediction problems (such as the Lemonade Stand project)
- Explain why evaluation metrics for classification (accuracy, confusion matrix) differ fundamentally from regression metrics (MAE, $R^2$)

## Prerequisites
- Lesson 01: The Titanic Historical Problem and Machine Learning Framing
- Basic understanding of continuous numbers vs. discrete categories

## Concept Explanation

### The Two Major Branches of Supervised Learning
Supervised machine learning algorithms are broadly divided into two primary categories based on the nature of the target variable $y$:

1. **Regression:**
   - **Target:** A **continuous numerical value** along an infinite or unbroken scale (e.g., predicting house prices, tomorrow's temperature, or cups of lemonade sold).
   - **Example:** In the Lemonade Stand Fortune Teller project, the model predicted `44.6 cups` or `33.8 cups`. A prediction of 44.61 cups is a valid, distinct prediction.
   - **Metrics:** Mean Absolute Error (MAE), Root Mean Squared Error (RMSE), and $R^2$ score.

2. **Classification:**
   - **Target:** A **discrete category, label, or class**.
   - **Example:** Predicting whether an email is "Spam" or "Not Spam", whether a tumor is "Malignant" or "Benign", or whether an image contains a "Cat" or "Dog".
   - **Binary Classification:** A specific subset of classification where there are **exactly two mutually exclusive classes**.

| Dimension | Regression (e.g., Lemonade Stand) | Binary Classification (Titanic Oracle) |
|---|---|---|
| **Target Variable ($y$)** | Continuous number (`cups_sold`: 12.5, 44.6, 68.0) | Discrete binary label (`survived`: 0 or 1) |
| **Output Type** | Real number ($\mathbb{R}$) | Boolean / Integer flag ($\{0, 1\}$) |
| **Question Asked** | *"How much?"* or *"How many?"* | *"Which category?"* or *"Did it happen?"* |
| **Primary Algorithm** | `LinearRegression` | `DecisionTreeClassifier` |
| **Evaluation Focus** | Size of numerical error (distance) | Count of correct vs. misclassified labels |

### Why Titanic Survival is Binary Classification
A passenger on the Titanic either survived the shipwreck or did not. There is no concept of "half-survived" or "3.7 survived." 
- `0`: Did not survive (Perished)
- `1`: Survived

Because there are only two discrete outcomes, this is a textbook **binary classification** problem. The model's objective is to determine a decision boundary that partitions passengers into class 0 or class 1.

## Relevant Code (from main.py, lines 31-33, 41)

```python
    features = ["pclass", "is_female", "age", "fare"]
    X = df[features]
    y = df["survived"]
...
    predictions = model.predict(X_test)
```

## Code Explanation
- **Line 33 (`y = df["survived"]`)**: Defines the target vector $y$. Inspecting `df["survived"].unique()` yields only `[0, 1]`.
- **Line 41 (`predictions = model.predict(X_test)`)**: When the trained classifier makes predictions, it does not output continuous decimals like 0.74 or 0.12; it outputs discrete integers (`0` or `1`) representing the predicted category for each test passenger.

## Worked Example

**Problem:** Consider three potential machine learning tasks. Classify each as regression, multi-class classification, or binary classification:
1. Predicting a passenger's ticket fare based on cabin type and boarding port.
2. Predicting whether a passenger survived (0 or 1).
3. Predicting which port a passenger boarded from (Southampton, Cherbourg, or Queenstown).

**Solution:**
1. **Fare Prediction:** Continuous dollar amount (e.g., £7.25, £54.90). This is **Regression**.
2. **Survival Prediction:** Exactly two discrete outcomes (0 or 1). This is **Binary Classification**.
3. **Port Prediction:** Three distinct categorical outcomes (Southampton, Cherbourg, Queenstown). This is **Multi-class Classification** (more than 2 classes).

## Step-by-Step Student Instructions

1. Start an interactive Python session in your terminal or create a quick test script:
   ```bash
   python3
   ```
2. Load the Titanic dataset using pandas:
   ```python
   import pandas as pd
   df = pd.read_csv("data/titanic_practice.csv")
   ```
3. Inspect the unique values and data type of the target column:
   ```python
   print("Unique survival values:", df["survived"].unique())
   print("Target data type:", df["survived"].dtype)
   print("Value counts:\n", df["survived"].value_counts())
   ```
4. Confirm that every single entry is either 0 or 1.

## Expected Output or Observable Behaviour

Executing the python commands will display:
```text
Unique survival values: [0 1]
Target data type: int64
Value counts:
 0    59
 1    31
Name: survived, dtype: int64
```
Out of 90 passengers in the practice dataset, exactly 59 passengers perished (`0`) and 31 survived (`1`). The target consists purely of two discrete integer states.

## Practical Exercises

**Exercise 2.1:** If a model predicted `0.65` for a passenger's survival, why would this not be a valid final discrete classification prediction? How can a probability of 0.65 be converted to a binary class?  
**Exercise 2.2:** Would predicting a passenger's exact age in years based on fare and class be regression or classification? Explain.  
**Exercise 2.3:** Why would using a linear regression model (which predicts unbounded numbers like -0.5 or 1.4) be problematic for predicting binary survival?  

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Evaluating classification with MAE or $R^2$ | $R^2$ and MAE evaluate continuous numerical distance, not categorical label accuracy | Use classification metrics: Accuracy, Precision, Recall, and Confusion Matrices |
| Treating the target `survived` as continuous | Numbers `0` and `1` represent categories, not quantities | Treat `0` and `1` as categorical labels |
| Confusing binary classification with multi-class classification | Binary classification has exactly 2 classes; multi-class has 3 or more | Use binary classification techniques when predicting a two-outcome event |

## Best Practices and Security Considerations

- **Thresholding Probabilities:** While classification models ultimately predict discrete labels (`0` or `1`), many models calculate an internal probability $P(y=1)$. The default decision threshold in scikit-learn is 0.50 (if $P \ge 0.50$, predict 1, else 0).
- **Target Encoding:** Always ensure binary target variables are cleanly encoded as integers `0` and `1` rather than strings like `"yes"`/`"no"` or `"true"`/`"false"`, which can cause compatibility issues with some algorithms.

## Summary

Supervised learning divides into regression (predicting continuous numerical quantities) and classification (predicting discrete categorical classes). The Titanic Survival Oracle is a binary classification task because the target variable `survived` contains exactly two possible outcomes: `0` (did not survive) and `1` (survived). Consequently, we employ classification algorithms like `DecisionTreeClassifier` and evaluate them using classification-specific metrics.

## Knowledge-check Questions

1. What distinguishes a regression problem from a classification problem?
2. What makes the Titanic problem specifically *binary* classification?
3. How many unique values exist in the `survived` column of `titanic_practice.csv`?
4. What is the standard classification threshold used to turn a probability into class 1?
5. Why are MAE and $R^2$ unsuitable for evaluating binary classification models?

## References

- [Scikit-learn Model Evaluation: Quantifying the Quality of Predictions](https://scikit-learn.org/stable/modules/model_evaluation.html)
- [Difference Between Classification and Regression in Machine Learning](https://machinelearningmastery.com/classification-versus-regression-in-machine-learning/)
- [Pandas Series `value_counts` documentation](https://pandas.pydata.org/docs/reference/api/pandas.Series.value_counts.html)
