# Lesson 03: Decision Tree Intuition — Learning Yes/No Rules

**Lesson ID:** lesson-03  
**Module:** module-01  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain the intuitive mechanics of a Decision Tree as a sequence of if-then-else conditions
- Identify the components of a tree: root node, internal decision nodes, branches, and leaf nodes
- Explain why decision trees are "white box" (interpretable) models compared to complex "black box" models
- Trace an observation down a simple decision tree from the root node to a final predicted class

## Prerequisites
- Lesson 01: The Titanic Historical Problem and Machine Learning Framing
- Lesson 02: Binary Classification vs. Regression

## Concept Explanation

### The Intuition: The 20 Questions Game
Have you ever played the game *20 Questions*? You try to guess what secret object your friend is thinking of by asking yes-or-no questions:
- *"Is it living?"* $\rightarrow$ Yes
- *"Is it an animal?"* $\rightarrow$ Yes
- *"Can it fly?"* $\rightarrow$ No
- *"Does it bark?"* $\rightarrow$ Yes $\rightarrow$ *"It is a dog!"*

A **Decision Tree** works exactly like a master player of 20 Questions. Given a dataset, the algorithm automatically discovers which questions to ask, in what order, and at what threshold to separate one class from another as cleanly as possible.

### Tree Anatomy
A decision tree is visualized upside down, with its "root" at the top and its "leaves" at the bottom:
1. **Root Node:** The starting point at the very top. It contains all training samples and tests the single most informative feature condition (e.g., *"Is female $\le 0.50$?"*).
2. **Branches:** The two pathways (Yes/True and No/False) emerging from a split.
3. **Internal Nodes:** Subsequent decision points that ask additional questions to further refine predictions (e.g., *"Is age $\le 18.5$?"*).
4. **Leaf Nodes (Terminal Nodes):** The endpoints of the tree. A leaf node asks no more questions; it delivers the final prediction (Class 0 or Class 1).

```
                 [ Root Node: Is Female <= 0.5? ]
                       /                    \
             Yes (Male)                      No (Female)
                /                                  \
     [ Age <= 18.5? ]                      [ Age <= 37.5? ]
       /          \                          /          \
   Yes             No                     Yes            No
  /                  \                    /                \
[Class: 0]       [Class: 0]          [Class: 1]        [Class: 0]
```

### Why Decision Trees are "White Box" Models
Many popular machine learning models (such as deep neural networks or support vector machines) are often criticized as **"black boxes"**: they may produce accurate predictions, but humans cannot easily understand *why* the model made a particular decision.

In contrast, decision trees are **"white box" (fully interpretable) models**. Every decision can be written out as a transparent set of logical rules:
- `IF sex == female AND age <= 37.5 AND pclass <= 1.5 THEN predict SURVIVED`

This interpretability makes decision trees ideal for high-stakes domains like medicine, loan approvals, and judicial sentencing, where decision-makers must explain and justify every prediction.

## Relevant Code (from main.py, lines 6-7, 48-54)

```python
# From docstring:
# The decision tree learns simple yes/no rules and prints them so you can read the model's logic.

    print("Learned rules:\n")
    print(
        export_text(
            model,
            feature_names=["passenger class", "is female (1=yes)", "age", "fare"],
        )
    )
```

## Code Explanation
- **Lines 6-7**: Emphasize that the tree discovers readable rules directly from historical data.
- **Lines 48-54**: Call `export_text()`, a scikit-learn helper function that translates the internal mathematical tree structure into an indented ASCII text hierarchy of if/then rules that any human can inspect.

## Worked Example

**Problem:** Using the learned tree snippet below, trace the prediction for:
Passenger: Male, Age 22, Fare £12.00, 3rd Class.

```text
|--- is female (1=yes) <= 0.50
|   |--- age <= 18.50
|   |   |--- class: 0
|   |--- age >  18.50
|   |   |--- fare <= 15.50
|   |   |   |--- fare <= 14.30
|   |   |   |   |--- class: 0
|   |   |   |--- fare >  14.30
|   |   |   |   |--- class: 1
|   |   |--- fare >  15.50
|   |   |   |--- class: 0
```

**Step-by-step trace:**
1. **Root question:** Is `is female <= 0.50`? The passenger is male (`is_female = 0`), which is $\le 0.50$. Condition is **True**. Move down the left branch.
2. **Next question:** Is `age <= 18.50`? The passenger's age is 22, which is $> 18.50$. Move to the `age > 18.50` branch.
3. **Next question:** Is `fare <= 15.50`? The fare is £12.00, which is $\le 15.50$. Move into the `fare <= 15.50` branch.
4. **Final question:** Is `fare <= 14.30`? The fare is £12.00, which is $\le 14.30$.
5. **Leaf reached:** `class: 0` (Did not survive).

## Step-by-Step Student Instructions

1. Take a clean sheet of paper or open a text document.
2. Create your own mini decision tree with 2 questions for deciding whether to play outside:
   - Question 1: *"Is it raining?"*
   - Question 2: *"Is temperature $> 20^\circ\text{C}$?"*
3. Draw the 4 resulting leaf nodes with decisions ("Stay Inside" vs. "Play Outside").
4. Notice how any person can follow your diagram and reach an unambiguous decision.
5. Reflect on how a computer can automatically determine the thresholds (like 18.50 years or £15.50 fare) by testing splits against historical data.

## Expected Output or Observable Behaviour

Your manual tree demonstrates the fundamental property of all decision trees:
- Every path from the root to a leaf forms a single, unambiguous compound rule.
- No inputs can be left unclassified; every possible combination of feature values arrives at exactly one leaf node.

## Practical Exercises

**Exercise 3.1:** What is the difference between an internal node and a leaf node in a decision tree?  
**Exercise 3.2:** If a passenger is female (`is_female = 1`), which branch does she take at the root node `is female (1=yes) <= 0.50`?  
**Exercise 3.3:** Why are decision trees particularly appealing to doctors diagnosing illnesses compared to complex neural networks?  

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Thinking the human creates the rules | The algorithm automatically chooses the best features and numerical thresholds | Let scikit-learn calculate the splits using training data |
| Assuming trees only work on binary features | Trees split continuous numerical features (like `age <= 18.50` and `fare <= 15.50`) just as easily as binary flags | Pass numerical features directly to `DecisionTreeClassifier` |
| Calling leaf nodes "branches" | Branches are the paths connecting nodes; leaves are the terminal stopping points | Use proper terminology: Root $\rightarrow$ Internal Node $\rightarrow$ Leaf |

## Best Practices and Security Considerations

- **Auditing Decision Paths:** In production systems, you should log which leaf node was reached for each prediction. This creates an immutable audit trail for compliance and regulatory reporting.
- **Interpretability Trade-offs:** While shallow decision trees are easy to interpret, very deep trees (e.g., depth 20) have thousands of rules and lose their interpretability benefit. Keep trees bounded (e.g., `max_depth=3` or `4`) when human readability is required.

## Summary

A decision tree is an intuitive, supervised classification algorithm that mimics human decision-making by evaluating a hierarchy of sequential questions. Starting at the root node, each decision node splits the data based on a feature threshold until a terminal leaf node is reached, yielding a predicted class label. Because their logic can be directly rendered as if-then statements, decision trees are transparent, white-box models.

## Knowledge-check Questions

1. In a decision tree diagram, where is the root node located?
2. What information does a leaf node provide?
3. What makes a decision tree a "white box" model?
4. If a decision rule tests `age <= 18.50`, which branch does a 15-year-old follow?
5. How does a decision tree handle continuous numerical features like fare?

## References

- [Scikit-learn Decision Trees Documentation](https://scikit-learn.org/stable/modules/tree.html)
- [Visual Introduction to Machine Learning (R2D3)](http://www.r2d3.us/visual-intro-to-machine-learning-part-1/)
- [Interpretable Machine Learning Book (Christoph Molnar)](https://christophm.github.io/interpretable-ml-book/tree.html)
