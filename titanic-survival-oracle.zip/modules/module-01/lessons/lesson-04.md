# Lesson 04: Exploring the Dataset and Project Architecture

**Lesson ID:** lesson-04  
**Module:** module-01  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Examine the structure, schema, and sample rows of `data/titanic_practice.csv`
- Explain the role of each column (`passenger_id`, `pclass`, `sex`, `age`, `fare`, `survived`)
- Trace the high-level architecture of `main.py` from raw data to saved visual and text outputs
- Explain why the headless `"Agg"` backend is configured before importing `matplotlib.pyplot`

## Prerequisites
- Lesson 01: The Titanic Historical Problem and Machine Learning Framing
- Lesson 02: Binary Classification vs. Regression
- Lesson 03: Decision Tree Intuition — Learning Yes/No Rules

## Concept Explanation

### The Dataset: `titanic_practice.csv`
The project uses a curated practice dataset derived from the real historical Titanic passenger manifest. It contains 90 passenger records (plus 1 header row) stored in `data/titanic_practice.csv`.

Let's review each column in the raw CSV:
1. `passenger_id`: An integer primary key (1 to 90). Used only for bookkeeping; excluded from model training.
2. `pclass`: Passenger ticket class. Takes values `1` (1st class - wealthy/luxury), `2` (2nd class - middle class), or `3` (3rd class - steerage/immigrants).
3. `sex`: Text string indicating biological sex (`"male"` or `"female"`).
4. `age`: Passenger age in years (numerical, from infant 1-year-olds up to older adults).
5. `fare`: Ticket fare paid in British pounds (numerical, ranging from £5.00 to £94.90).
6. `survived`: The ground-truth outcome: `0` (perished) or `1` (survived).

### Project Pipeline Architecture
The script `main.py` is organized into a clean, reproducible machine learning pipeline:

1. **Setup & Headless Matplotlib Configuration:**
   Sets `matplotlib.use("Agg")` so figures can be rendered and saved to disk without requiring an interactive desktop window.
2. **Directory Resolution:**
   Uses Python's modern `pathlib.Path` to locate `data/` and create `outputs/` safely regardless of the current working directory.
3. **Data Ingestion & Feature Engineering:**
   Loads the CSV via pandas, converts `"sex"` to a binary 0/1 column `is_female`, and isolates feature matrix $X$ and target vector $y$.
4. **Stratified Train-Test Splitting:**
   Splits 90 records into 75% training (67 passengers) and 25% testing (23 passengers), preserving class balance.
5. **Model Induction:**
   Trains `DecisionTreeClassifier(max_depth=4, random_state=42)`.
6. **Inference & Metrics:**
   Calculates accuracy and generates a full classification report on the test set.
7. **Custom Scenario Prediction:**
   Predicts survival probability for a synthetic test passenger.
8. **Visualization & Output Export:**
   Renders the tree diagram to `outputs/titanic_tree.png`, the confusion matrix to `outputs/confusion_matrix.png`, and text rules to `outputs/rules.txt`.

## Relevant Code (from main.py, lines 10-25)

```python
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, export_text, plot_tree

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)
```

## Code Explanation
- **Line 10**: Imports `Path` from `pathlib` for robust cross-platform path handling.
- **Lines 12-15**: `matplotlib.use("Agg")` MUST be executed before importing `matplotlib.pyplot`. `"Agg"` is a non-interactive raster backend that writes PNG files directly to disk without attempting to open an X11, Wayland, or desktop GUI window.
- **Lines 21-25**: Resolves `BASE` to the directory containing `main.py`. `DATA` points to `BASE / "data"` and `OUT` points to `BASE / "outputs"`. `OUT.mkdir(exist_ok=True)` automatically creates the `outputs/` directory if it does not already exist, preventing runtime `FileNotFoundError` exceptions.

## Worked Example

**Problem:** What happens if a student runs `main.py` on a remote Linux server or headless cloud container without `matplotlib.use("Agg")`?

**Solution:**
1. When `matplotlib.pyplot` is imported on a headless system without a display server, matplotlib attempts to connect to a default GUI backend (like Tkinter, Qt, or GTK).
2. Because no display server (`$DISPLAY` environment variable) is present, the script crashes with:
   `UserWarning: Matplotlib is currently using agg, which is a non-GUI backend, so cannot show the figure.` or a fatal `TclError: no display name and no $DISPLAY environment variable`.
3. By explicitly setting `matplotlib.use("Agg")` on line 14, the script instructs matplotlib to run in pure headless raster mode, allowing seamless execution on servers, Docker containers, and automated grading environments.

## Step-by-Step Student Instructions

1. Open your terminal in the project directory.
2. Use Python to inspect the dataset summary statistics:
   ```bash
   python3 -c "import pandas as pd; df = pd.read_csv('data/titanic_practice.csv'); print(df.info()); print(df.describe())"
   ```
3. Observe the output:
   - Total rows: 90 non-null values for all columns.
   - Mean age: ~29.7 years.
   - Mean fare: ~30.8.
   - Survival rate: ~34.4% (31 survivors out of 90).
4. Verify that the script creates the `outputs/` directory by checking its presence after execution.

## Expected Output or Observable Behaviour

Executing `df.info()` produces:
```text
<class 'pandas.core.frame.DataFrame'>
RangeIndex: 90 entries, 0 to 89
Data columns (total 6 columns):
 #   Column        Non-Null Count  Dtype  
---  ------        --------------  -----  
 0   passenger_id  90 non-null     int64  
 1   pclass        90 non-null     int64  
 2   sex           90 non-null     object 
 3   age           90 non-null     int64  
 4   fare          90 non-null     float64
 5   survived      90 non-null     int64  
dtypes: float64(1), int64(4), object(1)
memory usage: 4.3+ KB
```
Every column has 90 non-null values, confirming there are no missing (`NaN`) values in this practice dataset.

## Practical Exercises

**Exercise 4.1:** How many total rows and columns does `titanic_practice.csv` have? Which column is stored as a text object?  
**Exercise 4.2:** Why is `OUT.mkdir(exist_ok=True)` preferred over simply calling `os.mkdir("outputs")`?  
**Exercise 4.3:** List the three output files generated in `outputs/` when `main.py` finishes running.  

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Calling `matplotlib.use("Agg")` *after* `import matplotlib.pyplot` | Matplotlib binds to the default backend upon the first `pyplot` import; setting backend afterward has no effect | Always call `matplotlib.use("Agg")` before importing `plt` |
| Using string concatenation for paths (`BASE + "/data"`) | Breaks on Windows where path separators are backslashes (`\`) | Use `pathlib.Path` with the `/` operator |
| Omitting `exist_ok=True` when making directories | Python raises `FileExistsError` if the directory already exists | Always include `exist_ok=True` |

## Best Practices and Security Considerations

- **Robust Paths:** Using `Path(__file__).resolve().parent` ensures that scripts run reliably regardless of which folder the user's terminal currently occupies.
- **Headless Compatibility:** All production data pipelines and batch machine learning training jobs should configure headless plotting backends to prevent display server errors.
- **Directory Safety:** Always verify or automatically create destination directories before initiating file write operations.

## Summary

The Titanic Survival Oracle utilizes `data/titanic_practice.csv`, a clean 90-passenger dataset containing demographic, ticket, and survival records. The project follows a modular, best-practice architecture: headless plotting configuration, resilient path management with `pathlib`, feature engineering with pandas, tree classification with scikit-learn, and multi-artifact persistence (`titanic_tree.png`, `confusion_matrix.png`, `rules.txt`).

## Knowledge-check Questions

1. Why must `matplotlib.use("Agg")` be placed before `import matplotlib.pyplot as plt`?
2. What is the purpose of `OUT.mkdir(exist_ok=True)` in `main.py`?
3. How many passenger records are contained in `titanic_practice.csv`?
4. What data type is the `sex` column initially loaded as by pandas?
5. What are the three files written to the `outputs/` directory?

## References

- [Matplotlib Backends User Guide](https://matplotlib.org/stable/users/explain/backends.html)
- [Python pathlib Documentation](https://docs.python.org/3/library/pathlib.html)
- [Pandas DataFrame Info Documentation](https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.info.html)
