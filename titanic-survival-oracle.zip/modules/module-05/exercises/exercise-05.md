# Module 5 Exercises: Evaluation & Metrics

## Exercise 5.1: Manual Metric Calculation from Confusion Matrix (15 min)
**Objective:** Calculate Accuracy, Precision, Recall, and F1-Score manually from confusion matrix quadrants.  
**Problem Statement:** A classification test run on 23 passengers yields:
- $TN = 13$
- $FP = 3$
- $FN = 3$
- $TP = 4$

**Requirements:**
1. Calculate overall classification accuracy.
2. Calculate precision for class 1 (survived).
3. Calculate recall for class 1 (survived).
4. Calculate the F1-score for class 1 using the harmonic mean formula.
5. Write a Python script to compute these metrics using `sklearn.metrics` and verify your manual math.

**Constraints:** Perform manual calculations with fractions before executing Python.

**Expected Behaviour:** Step-by-step arithmetic and a concise Python script confirming results.

**Acceptance Criteria:**
- [ ] Accuracy = $17 / 23 \approx 73.91\%$.
- [ ] Precision = $4 / 7 \approx 57.14\%$.
- [ ] Recall = $4 / 7 \approx 57.14\%$.
- [ ] F1-Score = $57.14\%$.
- [ ] Python output matches manual derivations.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 5.2: Dissecting `classification_report` (15 min)
**Objective:** Extract, parse, and analyze `sklearn.metrics.classification_report` as a dictionary.  
**Problem Statement:** In automated monitoring systems, reports must be parsed programmatically rather than printed as text strings.

**Requirements:**
1. Run `report_dict = classification_report(y_test, predictions, output_dict=True, zero_division=0)`.
2. Print the precision and recall for class `'0'`.
3. Print the precision and recall for class `'1'`.
4. Extract and print the `'macro avg'` F1-score and `'weighted avg'` F1-score.
5. Explain in 2 sentences why the weighted average is higher than the macro average in this dataset.

**Acceptance Criteria:**
- [ ] Correctly uses `output_dict=True`.
- [ ] Accurately extracts class '0' metrics (~0.81) and class '1' metrics (~0.57).
- [ ] Accurately extracts macro avg (~0.69) and weighted avg (~0.74).
- [ ] Explains class imbalance effect on weighted averaging.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 5.3: Dissecting the Confusion Matrix Plot (15 min)
**Objective:** Inspect and audit `outputs/confusion_matrix.png`.  
**Problem Statement:** Examine the generated heatmap artifact and extract actionable insights.

**Requirements:**
1. Open `outputs/confusion_matrix.png` and verify all labels and cell counts.
2. Identify which cell represents Type I errors (False Positives). What is its count?
3. Identify which cell represents Type II errors (False Negatives). What is its count?
4. What fraction of actual survivors were misclassified as non-survivors?
5. Write a short paragraph discussing the real-world significance of the 3 False Negatives.

**Acceptance Criteria:**
- [ ] Identifies $FP = 3$ and $FN = 3$.
- [ ] Calculates survivor misclassification rate as $3 / 7 \approx 42.9\%$.
- [ ] Contextualizes the human cost of False Negatives in maritime rescue.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 5.4: Threshold Tuning for Search & Rescue Priority (15 min)
**Objective:** Implement a custom decision threshold to prioritize survivor recall.  
**Problem Statement:** If the Oracle were deployed during an active maritime rescue operation, minimizing False Negatives (leaving survivors behind) is paramount. Lower the decision threshold to achieve a recall $\ge 85\%$.

**Requirements:**
1. Extract probabilities from the trained tree: `probs = model.predict_proba(X_test)[:, 1]`.
2. Evaluate thresholds $\tau \in [0.10, 0.20, 0.30, 0.40, 0.50]$.
3. For each threshold, compute predictions: `(probs >= tau).astype(int)`.
4. Compute Recall and Precision for class 1 for each threshold.
5. Determine the highest threshold that achieves at least 85% recall for survivors.

**Acceptance Criteria:**
- [ ] Implements custom thresholding on probabilities.
- [ ] Identifies that threshold 0.20 achieves ~85.7% recall (6 out of 7 survivors found).
- [ ] Documents the resulting drop in precision (the trade-off).

**Difficulty:** Advanced  
**Estimated Completion Time:** 15 minutes  
