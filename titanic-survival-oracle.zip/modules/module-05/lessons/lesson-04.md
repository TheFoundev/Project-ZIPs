# Lesson 04: The Real-World Cost of Errors: False Negatives vs. False Positives

**Lesson ID:** lesson-04  
**Module:** module-05  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain why errors in machine learning are rarely symmetrical in cost or consequence
- Analyze the substantive, ethical, and practical meaning of False Negatives and False Positives in the Titanic context
- Explain how threshold tuning allows engineers to favor recall over precision in high-stakes domains
- Connect abstract machine learning errors to real-world domain consequences (e.g., medical triage, maritime rescue, fraud detection)

## Prerequisites
- Lesson 01: Classification Accuracy and Its Limitations
- Lesson 02: Understanding Precision, Recall, and F1-Score
- Lesson 03: The Confusion Matrix: Dissecting True and False Predictions

## Concept Explanation

### All Errors Are Not Created Equal
In pure mathematics, misclassifying a `0` as a `1` has the exact same numerical penalty as misclassifying a `1` as a `0` (both count as $+1$ error in the accuracy formula).

In the real world, however, **the cost of an error depends entirely on the domain**:

| Domain | False Positive (Type I Error) | False Negative (Type II Error) | Which is worse? |
|---|---|---|---|
| **Cancer Screening** | Healthy patient told they may have cancer $\rightarrow$ stressful biopsy, but safe | Cancer patient told they are healthy $\rightarrow$ cancer spreads untreated | **False Negative is catastrophic** |
| **Email Spam Filter** | Important job offer sent to Spam folder $\rightarrow$ missed career opportunity | Spam email arrives in Inbox $\rightarrow$ minor annoyance to delete | **False Positive is worse** |
| **Search & Rescue** | Rescue team dispatched to empty ocean sector $\rightarrow$ wasted fuel | Real survivors in lifeboat left unsearched $\rightarrow$ preventable loss of life | **False Negative is catastrophic** |

### The Titanic Context: Dissecting the Model's Errors
In `main.py`, our confusion matrix recorded **3 False Positives** and **3 False Negatives**. What do these errors mean substantively?

#### 1. The False Positive ($FP = 3$):
- **Actual:** Passenger died.
- **Model Predicted:** Passenger survived.
- **Real-World Meaning:** The Oracle was overly optimistic. In historical terms, these were likely individuals whose demographics suggested high survival odds (e.g., upper-class women), but who nevertheless perished due to unique circumstances (e.g., choosing to stay with a spouse, or being trapped by rising waters).

#### 2. The False Negative ($FN = 3$):
- **Actual:** Passenger survived!
- **Model Predicted:** Passenger died.
- **Real-World Meaning:** The Oracle gave up on them! In historical terms, these were remarkable individuals who beat the odds (e.g., 3rd-class men who managed to swim to an overturned collapsible lifeboat).
- If this model were used in 1912 to allocate search-and-rescue lifeboats, a **False Negative would be fatal**: search boats would not look for these individuals, leaving survivors to freeze in the Atlantic!

### Adjusting the Decision Threshold
By default, scikit-learn uses a decision threshold of $\tau = 0.50$:
$$\text{If } P(y=1) \ge 0.50 \rightarrow \text{Predict Survived (1)}$$

If we are operating a rescue mission, we might lower the threshold to $\tau = 0.25$:
$$\text{If } P(y=1) \ge 0.25 \rightarrow \text{Predict Survived (1)}$$
- **Result:** The model predicts survival more readily.
- **Benefit:** False Negatives drop to near 0 (almost all actual survivors are found!).
- **Trade-off:** False Positives increase (more empty rescue sweeps). In life-or-death triage, this trade-off is almost universally accepted.

## Relevant Code (from main.py, lines 41, 55, 81)

```python
    predictions = model.predict(X_test)
# ...
    print(classification_report(y_test, predictions, zero_division=0))
# ...
    cm = confusion_matrix(y_test, predictions, labels=[0, 1])
```

## Code Explanation
- **Line 41**: Uses the default 0.50 threshold to generate discrete predictions.
- **Lines 55 & 81**: Reveal the resulting balance of 3 False Positives and 3 False Negatives.

## Worked Example

**Problem:** Suppose an engineer changes the decision rule on `X_test` using probabilities:
Instead of `predictions = model.predict(X_test)` (threshold 0.50), they use `custom_preds = (model.predict_proba(X_test)[:, 1] >= 0.20).astype(int)`. What happens to False Negatives and Recall?

**Observed Result:**
- At threshold 0.50: Recall for Class 1 was 57% ($FN = 3$).
- At threshold 0.20: Recall for Class 1 rises to 86% ($FN$ drops from 3 down to 1!).
- Lowering the threshold directly reduces False Negatives at the expense of higher False Positives.

## Step-by-Step Student Instructions

1. Launch Python in your terminal:
   ```bash
   python3
   ```
2. Test the effect of lowering the decision threshold on the Titanic test set:
   ```python
   import pandas as pd
   from sklearn.model_selection import train_test_split
   from sklearn.tree import DecisionTreeClassifier
   from sklearn.metrics import confusion_matrix

   df = pd.read_csv("data/titanic_practice.csv")
   df["is_female"] = (df["sex"] == "female").astype(int)
   X = df[["pclass", "is_female", "age", "fare"]]
   y = df["survived"]
   X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)
   model = DecisionTreeClassifier(max_depth=4, random_state=42).fit(X_train, y_train)

   probs = model.predict_proba(X_test)[:, 1]

   for threshold in [0.50, 0.30, 0.10]:
       preds = (probs >= threshold).astype(int)
       cm = confusion_matrix(y_test, preds, labels=[0, 1])
       tn, fp, fn, tp = cm.ravel()
       print(f"Threshold: {threshold:.2f} -> TP: {tp}, FP: {fp}, FN: {fn}, TN: {tn}")
   ```
3. Observe how False Negatives ($FN$) decrease as the threshold is lowered.

## Expected Output or Observable Behaviour

Executing the threshold experiment displays:
```text
Threshold: 0.50 -> TP: 4, FP: 3, FN: 3, TN: 13
Threshold: 0.30 -> TP: 5, FP: 4, FN: 2, TN: 12
Threshold: 0.10 -> TP: 6, FP: 6, FN: 1, TN: 10
```
Notice how lowering the threshold from 0.50 to 0.10 cuts False Negatives from 3 down to 1!

## Practical Exercises

**Exercise 4.1:** In an airport security luggage scanner predicting whether a bag contains a weapon (`1 = weapon, 0 = safe`), which error is more dangerous: a False Positive or a False Negative? Explain why.  
**Exercise 4.2:** Why does lowering the classification threshold increase Recall while decreasing Precision?  
**Exercise 4.3:** Identify one real-world domain where a False Positive is considered significantly worse than a False Negative.  

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Assuming 0.50 is an immutable mathematical law | 0.50 is merely an arbitrary default threshold; optimal thresholds depend on business error costs | Tune thresholds based on cost-benefit analysis |
| Treating Type I and Type II errors as equally harmful | One error type is almost always significantly more damaging in real applications | Assign explicit financial or ethical costs to each error type |
| Increasing recall to 100% without considering precision | Predicting positive for everyone achieves 100% recall but creates an unmanageable flood of false alarms | Use F-beta or PR-curves to optimize the trade-off |

## Best Practices and Security Considerations

- **Cost-Sensitive Learning:** In production systems, calculate the expected financial or human cost of each error type ($\text{Cost} = c_{FP} \cdot FP + c_{FN} \cdot FN$) to determine the optimal decision threshold.
- **Ethical AI Auditing:** Always audit model failure cases to ensure that False Negatives are not disproportionately concentrated in protected or historically marginalized demographic groups.

## Summary

In machine learning, error types have asymmetric real-world consequences. A False Positive in the Titanic context is an over-optimistic prediction (predicted survived, but died), while a False Negative is a missed survivor (predicted died, but survived). In emergency and medical contexts, False Negatives carry life-and-death consequences. Machine learning engineers tune decision thresholds to balance precision and recall according to real-world domain priorities.

## Knowledge-check Questions

1. In the Titanic survival problem, what is a False Negative?
2. In the Titanic survival problem, what is a False Positive?
3. What is the default classification threshold in scikit-learn?
4. What happens to the number of False Negatives when the classification threshold is lowered?
5. Why is a False Negative generally considered more dangerous than a False Positive in medical diagnostics?

## References

- [Scikit-learn Tuning the Decision Threshold Guide](https://scikit-learn.org/stable/modules/classification_threshold.html)
- [Cost-Sensitive Decision Making in Machine Learning (Machine Learning Mastery)](https://machinelearningmastery.com/cost-sensitive-learning-for-imbalanced-classification/)
- [Ethics and Algorithmic Bias in Risk Scoring (Harvard Business Review)](https://hbr.org/2019/10/what-do-we-do-about-the-biases-in-ai)
