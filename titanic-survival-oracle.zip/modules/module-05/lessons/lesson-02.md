# Lesson 02: Understanding Precision, Recall, and F1-Score

**Lesson ID:** lesson-02  
**Module:** module-05  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Define Precision, Recall, and F1-Score mathematically
- Explain what each metric measures in the context of Titanic passenger survival
- Parse and interpret every row and column in scikit-learn's `classification_report`
- Explain the role of the `zero_division=0` parameter in preventing runtime division-by-zero warnings

## Prerequisites
- Lesson 01: Classification Accuracy and Its Limitations
- Basic understanding of fractions and harmonic means

## Concept Explanation

### The Big Three Metrics
To evaluate classification models thoroughly, data scientists use three interconnected metrics:

#### 1. Precision: The Quality of Positive Claims
**"When the model predicts that a passenger survived, how often is it actually right?"**
$$\text{Precision} = \frac{\text{True Positives (TP)}}{\text{True Positives (TP)} + \text{False Positives (FP)}}$$
- High precision means very few false alarms. If the model says someone survived, you can trust it.

#### 2. Recall (Sensitivity): The Completeness of Detection
**"Out of all the passengers who actually survived, what percentage did the model successfully find?"**
$$\text{Recall} = \frac{\text{True Positives (TP)}}{\text{True Positives (TP)} + \text{False Negatives (FN)}}$$
- High recall means very few missed survivors. The model casts a wide net.

#### 3. F1-Score: The Balanced Harmonic Mean
Precision and recall exist in constant tension: making a model more conservative increases precision but reduces recall. The **F1-Score** combines both into a single balanced summary using their harmonic mean:
$$\text{F1-Score} = 2 \times \frac{\text{Precision} \times \text{Recall}}{\text{Precision} + \text{Recall}}$$

The harmonic mean penalizes extreme imbalances: if either precision or recall is close to 0, the F1-score collapses to 0.

### Parsing the `classification_report`
In `main.py`, line 55 prints:
```text
              precision    recall  f1-score   support

           0       0.81      0.81      0.81        16
           1       0.57      0.57      0.57         7

    accuracy                           0.74        23
   macro avg       0.69      0.69      0.69        23
weighted avg       0.74      0.74      0.74        23
```

Let's read this table row-by-row:
- **Class 0 (Did Not Survive):**
  - **Support:** 16 passengers actually perished.
  - **Precision = 0.81:** Out of all passengers predicted to die, 81% actually died.
  - **Recall = 0.81:** Out of all passengers who actually died, the model caught 81% of them.
  - **F1-score = 0.81:** Solid overall performance for the majority class.
- **Class 1 (Survived):**
  - **Support:** 7 passengers actually survived.
  - **Precision = 0.57:** Out of 7 passengers predicted to survive, only 4 actually survived ($4 / 7 \approx 0.571$).
  - **Recall = 0.57:** Out of the 7 passengers who actually survived, the model identified 4 ($4 / 7 \approx 0.571$).
  - **F1-score = 0.57:** Noticeably lower than class 0, highlighting the difficulty of predicting the minority class.
- **Macro Average:** Unweighted arithmetic average of metrics across classes ($ (0.81 + 0.57) / 2 = 0.69 $). Treats both classes equally.
- **Weighted Average:** Average weighted by class support ($ (0.81 \times 16 + 0.57 \times 7) / 23 \approx 0.74 $). Reflects overall population frequency.

## Relevant Code (from main.py, line 55)

```python
    print(classification_report(y_test, predictions, zero_division=0))
```

## Code Explanation
- **Line 55**: Calls `classification_report(y_test, predictions, zero_division=0)`.
- `zero_division=0`: If a model makes 0 positive predictions for a class, precision involves computing $0 / (0 + 0) = \frac{0}{0}$. Without `zero_division=0`, scikit-learn prints an ugly warning (`UndefinedMetricWarning`). Setting `zero_division=0` tells scikit-learn to gracefully report 0.0 without throwing warnings.

## Worked Example

**Problem:** Using the test set counts:
- True Positives ($TP$) = 4
- False Positives ($FP$) = 3
- False Negatives ($FN$) = 3
Calculate Precision, Recall, and F1-Score for Class 1 (Survivors).

**Step-by-step Solution:**
1. **Precision:**
   $$\text{Precision} = \frac{TP}{TP + FP} = \frac{4}{4 + 3} = \frac{4}{7} \approx 0.5714 \rightarrow 0.57$$
2. **Recall:**
   $$\text{Recall} = \frac{TP}{TP + FN} = \frac{4}{4 + 3} = \frac{4}{7} \approx 0.5714 \rightarrow 0.57$$
3. **F1-Score:**
   $$\text{F1} = 2 \times \frac{0.5714 \times 0.5714}{0.5714 + 0.5714} = 2 \times \frac{0.3265}{1.1428} = \frac{0.6530}{1.1428} \approx 0.5714 \rightarrow 0.57$$
The calculations match the numbers printed in `main.py`!

## Step-by-Step Student Instructions

1. Open your terminal and run `main.py`:
   ```bash
   python3 main.py
   ```
2. Locate the classification report block in the console output.
3. Compare the support numbers (`16` and `7`) to verify that they sum to the test set size (`23`).
4. Compare the macro average against the weighted average. Why is the weighted average higher? (Because class 0 has higher support and higher accuracy).

## Expected Output or Observable Behaviour

Executing `main.py` prints the exact formatted classification table:
```text
              precision    recall  f1-score   support

           0       0.81      0.81      0.81        16
           1       0.57      0.57      0.57         7

    accuracy                           0.74        23
   macro avg       0.69      0.69      0.69        23
weighted avg       0.74      0.74      0.74        23
```
The report exposes the asymmetric performance between non-survivors (F1 = 0.81) and survivors (F1 = 0.57).

## Practical Exercises

**Exercise 2.1:** If a model predicted survival for 10 passengers, and 8 of them were actual survivors, what is its precision for class 1?  
**Exercise 2.2:** If there were 20 actual survivors aboard, and the model only predicted survival for 5 of them, what is its recall?  
**Exercise 2.3:** Why is the harmonic mean used for the F1-score instead of a simple arithmetic average? What would the arithmetic average be if Precision = 1.0 and Recall = 0.0? What would the F1-score be?  

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Confusing precision and recall | Precision evaluates predictions; recall evaluates actual ground truth | Precision = $TP / \text{All Predicted Positives}$; Recall = $TP / \text{All Actual Positives}$ |
| Forgetting `zero_division=0` | Causes `UndefinedMetricWarning` when a class has 0 predictions | Always supply `zero_division=0` in production |
| Comparing macro average directly to overall accuracy | Macro average treats small classes with equal weight; accuracy weights by class size | Use macro avg to evaluate minority class fairness |

## Best Practices and Security Considerations

- **Choose Metrics Aligned with Business Goals:** In life-safety applications (like medical triage or search-and-rescue), **Recall** is almost always more critical than Precision because missing an endangered person is catastrophic.
- **Reporting Both Macro and Weighted:** Always report both macro and weighted averages to provide a transparent picture of performance across rare and common classes.

## Summary

`classification_report` provides an indispensable, multi-dimensional view of classification performance. Precision measures the reliability of positive predictions, Recall measures the completeness of positive detection, and F1-Score harmonizes the two. While the Titanic model achieves 81% precision and recall on the majority class (non-survivors), it achieves 57% precision and recall on survivors, highlighting the inherent challenge of minority class detection.

## Knowledge-check Questions

1. What does Precision measure in classification?
2. What does Recall measure in classification?
3. What is the mathematical formula for the F1-score?
4. What does the "support" column in a classification report tell you?
5. Why is `zero_division=0` included in `classification_report()`?

## References

- [Scikit-learn classification_report Documentation](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.classification_report.html)
- [Precision and Recall: A Comprehensive Overview (Wikipedia)](https://en.wikipedia.org/wiki/Precision_and_recall)
- [F1-Score and Harmonic Mean Intuition](https://towardsdatascience.com/a-look-at-precision-recall-and-f1-score-36b5fd0dd3ec)
