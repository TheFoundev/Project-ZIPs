# Lesson 03: The Confusion Matrix: Dissecting True and False Predictions

**Lesson ID:** lesson-03  
**Module:** module-05  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Construct and interpret a $2 \times 2$ Confusion Matrix
- Identify the four quadrants: True Negatives (TN), False Positives (FP), False Negatives (FN), and True Positives (TP)
- Use `sklearn.metrics.confusion_matrix` and `ConfusionMatrixDisplay` to plot visual heatmaps
- Map raw cell values in `outputs/confusion_matrix.png` directly to passenger counts

## Prerequisites
- Lesson 01: Classification Accuracy and Its Limitations
- Lesson 02: Understanding Precision, Recall, and F1-Score

## Concept Explanation

### What is a Confusion Matrix?
A **Confusion Matrix** is a complete, unvarnished accounting of an algorithm's predictions cross-referenced against the ground truth. It reveals not just *how often* a model was wrong, but *precisely how* it was confused.

For a binary classification task, it is structured as a $2 \times 2$ grid:

```
                            Predicted: 0               Predicted: 1
                     ┌──────────────────────────┬──────────────────────────┐
   Actual: 0         │   True Negative (TN)     │   False Positive (FP)    │
 (Did Not Survive)   │           13             │            3             │
                     ├──────────────────────────┼──────────────────────────┤
   Actual: 1         │   False Negative (FN)    │   True Positive (TP)     │
   (Survived)        │           3              │            4             │
                     └──────────────────────────┴──────────────────────────┘
```

### The Four Quadrants Defined:
1. **True Negative (TN = 13):**
   - Actual: Passenger perished (`0`).
   - Predicted: Model predicted perished (`0`).
   - The model was correctly negative.
2. **False Positive (FP = 3) — Type I Error:**
   - Actual: Passenger perished (`0`).
   - Predicted: Model predicted survived (`1`).
   - A false alarm: the model predicted survival, but the passenger was lost.
3. **False Negative (FN = 3) — Type II Error:**
   - Actual: Passenger survived (`1`).
   - Predicted: Model predicted perished (`0`).
   - A missed detection: the passenger lived, but the model overlooked them.
4. **True Positive (TP = 4):**
   - Actual: Passenger survived (`1`).
   - Predicted: Model predicted survived (`1`).
   - The model was correctly positive.

### Visualizing with `ConfusionMatrixDisplay`
Rather than reading raw numbers in an array, scikit-learn provides `ConfusionMatrixDisplay`. In `main.py`, it renders a blue heatmap where:
- Darker shades of blue indicate higher sample counts.
- Axes are clearly labeled with human-readable strings (`"did not survive"`, `"survived"`).
- The diagonal cells (top-left to bottom-right) represent all correct predictions ($13 + 4 = 17$).
- The off-diagonal cells represent all classification errors ($3 + 3 = 6$).

## Relevant Code (from main.py, lines 80-89)

```python
    # ---- Confusion matrix ---------------------------------------------
    cm = confusion_matrix(y_test, predictions, labels=[0, 1])
    fig, ax = plt.subplots(figsize=(5.2, 4.3))
    ConfusionMatrixDisplay(cm, display_labels=["did not survive", "survived"]).plot(
        ax=ax, cmap="Blues", colorbar=False
    )
    ax.set_title("Titanic predictions on unseen passengers")
    fig.tight_layout()
    fig.savefig(OUT / "confusion_matrix.png", dpi=150, bbox_inches="tight")
    plt.close(fig)
```

## Code Explanation
- **Line 81**: `confusion_matrix(y_test, predictions, labels=[0, 1])` computes the $2 \times 2$ array. Explicitly passing `labels=[0, 1]` guarantees that row 0 corresponds to class 0 and row 1 corresponds to class 1.
- **Lines 82-85**: Creates a plot canvas and displays the matrix with clean blue colormap shading (`cmap="Blues"`), labeling rows and columns as `"did not survive"` and `"survived"`.
- **Lines 86-89**: Sets the title, applies tight layout, saves the visualization to `outputs/confusion_matrix.png` at 150 DPI, and closes the figure.

## Worked Example

**Problem:** Verify that the numbers in the confusion matrix match the accuracy, precision, and recall calculated in Lessons 01 and 02.

**Verification:**
1. Total samples: $13 + 3 + 3 + 4 = 23$. Matches test set size!
2. Accuracy: $\frac{TN + TP}{\text{Total}} = \frac{13 + 4}{23} = \frac{17}{23} \approx 73.9\%$. Matches!
3. Precision (Class 1): $\frac{TP}{TP + FP} = \frac{4}{4 + 3} = \frac{4}{7} \approx 57.1\%$. Matches!
4. Recall (Class 1): $\frac{TP}{TP + FN} = \frac{4}{4 + 3} = \frac{4}{7} \approx 57.1\%$. Matches!
Every metric in classification is derived directly from the four quadrants of the confusion matrix.

## Step-by-Step Student Instructions

1. Run `main.py` in your terminal:
   ```bash
   python3 main.py
   ```
2. Open `outputs/confusion_matrix.png` in an image viewer or editor.
3. Locate the True Negative cell (top-left: row "did not survive", col "did not survive"). Verify it shows `13`.
4. Locate the True Positive cell (bottom-right: row "survived", col "survived"). Verify it shows `4`.
5. Locate the False Positives (top-right: `3`) and False Negatives (bottom-left: `3`).

## Expected Output or Observable Behaviour

Opening `outputs/confusion_matrix.png` displays:
- A clean $2 \times 2$ grid with title "Titanic predictions on unseen passengers".
- Dark blue square at top-left with number `13`.
- Medium blue square at bottom-right with number `4`.
- Light blue squares at off-diagonals with numbers `3` and `3`.

## Practical Exercises

**Exercise 3.1:** What is the formula for False Positive Rate (FPR)? Calculate FPR for our test set: $FP / (FP + TN)$.  
**Exercise 3.2:** What would a "perfect" confusion matrix look like for our 23 test passengers? What values would be on the diagonal and off-diagonal?  
**Exercise 3.3:** Why is `colorbar=False` set in line 85? What does a colorbar add to a heatmap?  

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Inverting the axis interpretation | Confusing actual rows with predicted columns | In scikit-learn: rows = True Labels; columns = Predicted Labels |
| Forgetting `labels=[0, 1]` | If the test set happens to contain only one class, the matrix collapses to $1 \times 1$ | Explicitly specify `labels=[0, 1]` |
| Swapping display label order | Swapping labels marks survivors as non-survivors on the plot | Align `display_labels` strictly with class order: 0 first, 1 second |

## Best Practices and Security Considerations

- **Axis Clarity:** Always label confusion matrix axes clearly as "True Label" (Y-axis) and "Predicted Label" (X-axis) so viewers cannot misinterpret predictions as truth.
- **Explicit Label Ordering:** Always supply `labels=[0, 1]` to ensure the matrix layout remains fixed even if a mini-batch is missing one of the classes.

## Summary

The Confusion Matrix is the foundational table from which all classification metrics are derived. For our 23 test passengers, the matrix details: 13 True Negatives, 4 True Positives, 3 False Positives, and 3 False Negatives. Using `ConfusionMatrixDisplay` with `cmap="Blues"`, `main.py` exports this breakdown directly to `outputs/confusion_matrix.png`.

## Knowledge-check Questions

1. In a scikit-learn confusion matrix, which axis represents the true ground truth labels?
2. How many True Negatives and True Positives are in `outputs/confusion_matrix.png`?
3. What is a Type I error in the context of Titanic passenger survival?
4. What is a Type II error in the context of Titanic passenger survival?
5. Which cells in the confusion matrix represent correct classifications?

## References

- [Scikit-learn confusion_matrix Documentation](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.confusion_matrix.html)
- [Scikit-learn ConfusionMatrixDisplay Documentation](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.ConfusionMatrixDisplay.html)
- [Understanding the Confusion Matrix (Towards Data Science)](https://towardsdatascience.com/understanding-confusion-matrix-a9c0f90d30ea)
