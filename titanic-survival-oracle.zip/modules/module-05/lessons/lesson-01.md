# Lesson 01: Classification Accuracy and Its Limitations

**Lesson ID:** lesson-01  
**Module:** module-05  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Define classification accuracy and calculate it mathematically from correct and total predictions
- Use `sklearn.metrics.accuracy_score` to evaluate test set performance
- Explain the **Accuracy Paradox** and why high accuracy can conceal a completely useless model in imbalanced datasets
- Evaluate the baseline accuracy of a naive "predict everyone dies" majority-class classifier

## Prerequisites
- Module 04: Model Training & Predictions
- Basic arithmetic and percentages

## Concept Explanation

### What is Accuracy?
**Accuracy** is the most intuitive evaluation metric in classification. It answers the straightforward question: **"What fraction of all predictions did the model get right?"**

$$\text{Accuracy} = \frac{\text{Number of Correct Predictions}}{\text{Total Number of Predictions}} = \frac{TP + TN}{TP + TN + FP + FN}$$

In `main.py`, the model achieves an accuracy of **73.9%** on the test set (17 correct predictions out of 23 test passengers).

### The Peril of Accuracy: The Accuracy Paradox
While 73.9% sounds respectable, accuracy alone can be dangerously deceptive when evaluating imbalanced datasets.

Consider this thought experiment:
- In our test set, there are **16 non-survivors** (69.6%) and **7 survivors** (30.4%).
- Suppose a lazy programmer builds a "Zero-Effort Model" that ignores all passenger features and simply predicts `0` (did not survive) for every single passenger.
- How well does this completely useless model perform?
  - It gets all 16 non-survivors correct!
  - It gets all 7 survivors wrong.
  - Its accuracy is: $\frac{16}{23} \approx 69.6\%$!

A model with zero intelligence achieves nearly 70% accuracy purely by guessing the majority class! This is called the **Accuracy Paradox** (or majority-class baseline). 

If a data scientist only reports accuracy, an executive or client might be thrilled with "70% accuracy", unaware that the model has completely failed to identify a single survivor.

```
Total Test Set: 23 passengers
┌──────────────────────────────────────┬──────────────────────┐
│       16 Non-Survivors (69.6%)       │ 7 Survivors (30.4%)  │
└──────────────────────────────────────┴──────────────────────┘
◄───────────────── Majority Class Baseline: 69.6% ────────────►
```

### Why We Need Additional Metrics
Because accuracy masks class-specific performance, machine learning engineers must evaluate:
- **Precision:** When the model predicts survival, how often is it right?
- **Recall:** Out of all people who actually survived, how many did the model catch?
- **Confusion Matrix:** Exactly where did errors occur?

## Relevant Code (from main.py, lines 43-47)

```python
    accuracy = accuracy_score(y_test, predictions)
    print("=" * 60)
    print("THE TITANIC SURVIVAL ORACLE")
    print("=" * 60)
    print(f"Accuracy: {accuracy:.1%}\n")
```

## Code Explanation
- **Line 43**: Calls `accuracy_score(y_test, predictions)` to compute the fraction of matching labels.
- **Lines 44-47**: Formats the score using Python's `:.1%` specifier, printing `Accuracy: 73.9%`.

## Worked Example

**Problem:** Calculate the test accuracy of `main.py` manually.
Given:
- Total test passengers ($N$) = 23
- Correct non-survivor predictions = 13
- Correct survivor predictions = 4
- Incorrect non-survivor predictions = 3
- Incorrect survivor predictions = 3

**Calculation:**
$$\text{Total Correct} = 13 + 4 = 17$$
$$\text{Accuracy} = \frac{17}{23} \approx 0.73913 \rightarrow 73.9\%$$

Notice that our model's 73.9% accuracy is higher than the naive 69.6% majority baseline, confirming that the decision tree has learned genuine predictive signal beyond mere majority voting.

## Step-by-Step Student Instructions

1. Open your terminal and launch Python:
   ```bash
   python3
   ```
2. Run a comparison between the trained decision tree and a naive dummy majority classifier:
   ```python
   import numpy as np
   import pandas as pd
   from sklearn.model_selection import train_test_split
   from sklearn.tree import DecisionTreeClassifier
   from sklearn.metrics import accuracy_score
   from sklearn.dummy import DummyClassifier

   df = pd.read_csv("data/titanic_practice.csv")
   df["is_female"] = (df["sex"] == "female").astype(int)
   X = df[["pclass", "is_female", "age", "fare"]]
   y = df["survived"]
   X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)

   # Trained Decision Tree
   tree = DecisionTreeClassifier(max_depth=4, random_state=42).fit(X_train, y_train)
   tree_acc = accuracy_score(y_test, tree.predict(X_test))

   # Naive Dummy Classifier (always predicts most frequent class: 0)
   dummy = DummyClassifier(strategy="most_frequent").fit(X_train, y_train)
   dummy_acc = accuracy_score(y_test, dummy.predict(X_test))

   print(f"Decision Tree Accuracy:  {tree_acc:.1%}")
   print(f"Naive Baseline Accuracy: {dummy_acc:.1%}")
   ```
3. Observe the difference: the decision tree outperforms the naive baseline by ~4.3 percentage points.

## Expected Output or Observable Behaviour

Executing this script displays:
```text
Decision Tree Accuracy:  73.9%
Naive Baseline Accuracy: 69.6%
```
The naive baseline of 69.6% establishes the minimum bar that any legitimate machine learning model must beat.

## Practical Exercises

**Exercise 1.1:** Suppose a medical cancer detection dataset has 990 healthy patients and 10 cancer patients. What accuracy would a model achieve if it simply diagnosed all 1,000 patients as healthy? Would this model be clinically useful?  
**Exercise 1.2:** What is the formula for accuracy expressed in terms of TP, TN, FP, and FN?  
**Exercise 1.3:** If `accuracy_score(y_test, predictions)` returned 0.50 on an evenly balanced dataset, how does that compare to random coin flipping?  

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Relying exclusively on accuracy to judge a model | High accuracy can mask total failure on rare positive classes | Always inspect precision, recall, and the confusion matrix |
| Inverting argument order in `accuracy_score(predictions, y_test)` | While accuracy is symmetric, scikit-learn standardizes on `(y_true, y_pred)` | Always pass ground truth first: `accuracy_score(y_test, predictions)` |
| Reporting training accuracy as test performance | Training accuracy measures memorization, not generalization | Report accuracy calculated strictly on `X_test` / `y_test` |

## Best Practices and Security Considerations

- **Always Establish a Naive Baseline:** Before celebrating a model's accuracy, calculate the majority-class baseline (`DummyClassifier`). If your model cannot comfortably beat the baseline, it has learned nothing.
- **Balanced Class Metrics:** In heavily imbalanced classification tasks (e.g. fraud detection, cyber threat detection), prioritize balanced accuracy or area under the ROC curve (ROC-AUC) over raw accuracy.

## Summary

Classification accuracy measures the proportion of total predictions that match ground-truth labels. In `main.py`, the decision tree achieves 73.9% test accuracy. However, in imbalanced datasets, the Accuracy Paradox allows a naive majority-class model to achieve high accuracy (here, 69.6%) while providing zero utility. Consequently, robust evaluation demands deeper metrics such as precision, recall, and confusion matrices.

## Knowledge-check Questions

1. What is the mathematical definition of classification accuracy?
2. What test accuracy does `main.py` achieve on the Titanic dataset?
3. What is the Accuracy Paradox?
4. What accuracy would a dummy model achieve by predicting that all 23 test passengers died?
5. In what order does `accuracy_score` expect its arguments?

## References

- [Scikit-learn accuracy_score API Documentation](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.accuracy_score.html)
- [The Accuracy Paradox in Machine Learning (Tom Fawcett)](https://towardsdatascience.com/the-accuracy-paradox-b7692257cd44)
- [Scikit-learn DummyClassifier Documentation](https://scikit-learn.org/stable/modules/generated/sklearn.dummy.DummyClassifier.html)
