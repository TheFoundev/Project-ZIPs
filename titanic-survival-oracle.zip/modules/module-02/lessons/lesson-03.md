# Lesson 03: Feature Matrix Selection ($X$) and Target Vector Separation ($y$)

**Lesson ID:** lesson-03  
**Module:** module-02  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain the universal scikit-learn convention of feature matrix $X$ (2D) and target vector $y$ (1D)
- Select and assemble multi-column feature subsets from pandas DataFrames using list indexing
- Separate the target column `survived` into vector $y$
- Verify the mathematical dimensionality and shapes of $X$ and $y$ using `.shape`

## Prerequisites
- Lesson 01: Loading Tabular Data with Pandas and Pathlib
- Lesson 02: Feature Engineering: Encoding Categorical Data into `is_female`

## Concept Explanation

### The Mathematical Shapes in Scikit-Learn
Scikit-learn adheres to a strict, universal mathematical convention across all its models:
1. **The Feature Matrix ($X$):**
   - Must be a **two-dimensional (2D)** array-like structure of shape `(n_samples, n_features)`.
   - Here, `n_samples = 90` passengers, and `n_features = 4` attributes (`pclass`, `is_female`, `age`, `fare`).
   - In pandas, extracting multiple columns using a list of strings (`df[features]`) produces a 2D DataFrame of shape `(90, 4)`.
   - By mathematical convention, $X$ is capitalized because it represents a 2D matrix.

2. **The Target Vector ($y$):**
   - Is typically a **one-dimensional (1D)** sequence of shape `(n_samples,)`.
   - In pandas, extracting a single column using a single string (`df["survived"]`) produces a 1D Series of shape `(90,)`.
   - By convention, $y$ is lowercase because it represents a 1D vector.

```
       Feature Matrix X (DataFrame: 90 x 4)                 Target Vector y (Series: 90)
┌────────┬───────────┬─────┬──────┐                      ┌──────────┐
│ pclass │ is_female │ age │ fare │                      │ survived │
├────────┼───────────┼─────┼──────┤                      ├──────────┤
│   3    │     0     │ 10  │ 19.7 │                      │    0     │
│   3    │     0     │ 23  │ 15.2 │                      │    1     │
│   1    │     1     │ 32  │ 25.3 │                      │    1     │
│  ...   │    ...    │ ... │ ...  │                      │   ...    │
└────────┴───────────┴─────┴──────┘                      └──────────┘
```

### Feature Selection Rationale
In `main.py`, four features are chosen:
- `pclass`: Socioeconomic indicator and physical ship location.
- `is_female`: Demographic indicator corresponding to maritime protocol.
- `age`: Vulnerability indicator (children received priority).
- `fare`: Economic proxy, reflecting cabin placement and lifejacket access.

Columns intentionally discarded:
- `passenger_id`: Arbitrary row counter without predictive validity.
- `sex`: Replaced by its engineered numerical equivalent `is_female`.

## Relevant Code (from main.py, lines 31-33)

```python
    features = ["pclass", "is_female", "age", "fare"]
    X = df[features]
    y = df["survived"]
```

## Code Explanation
- **Line 31**: Defines a Python list of strings containing the exact column names selected for model training.
- **Line 32**: Indexing `df` with the list `features` extracts a 2D DataFrame containing only those 4 columns, assigned to uppercase `X`.
- **Line 33**: Indexing `df` with a single string `"survived"` extracts a 1D pandas Series, assigned to lowercase `y`.

## Worked Example

**Problem:** What are the exact types and shapes of `X` and `y` after executing lines 31-33?

**Solution:**
1. Type check:
   - `type(X)` is `pandas.core.frame.DataFrame`.
   - `type(y)` is `pandas.core.series.Series`.
2. Shape check:
   - `X.shape` returns `(90, 4)`: 90 rows (samples) and 4 columns (features).
   - `y.shape` returns `(90,)`: A 1D array of 90 elements.
3. This satisfies scikit-learn's expectation that `X.shape[0] == y.shape[0] == 90`.

## Step-by-Step Student Instructions

1. Launch Python in your terminal:
   ```bash
   python3
   ```
2. Execute the feature extraction code:
   ```python
   import pandas as pd
   df = pd.read_csv("data/titanic_practice.csv")
   df["is_female"] = (df["sex"] == "female").astype(int)

   features = ["pclass", "is_female", "age", "fare"]
   X = df[features]
   y = df["survived"]

   print("X shape:", X.shape)
   print("y shape:", y.shape)
   print("\nX head:\n", X.head(3))
   print("\ny head:\n", y.head(3))
   ```
3. Verify that `X` contains exclusively numeric data (`int64` and `float64`) and `y` contains binary integers.

## Expected Output or Observable Behaviour

Executing these commands will output:
```text
X shape: (90, 4)
y shape: (90,)

X head:
    pclass  is_female  age  fare
0       3          0   10  19.7
1       3          0   23  15.2
2       1          1   32  25.3

y head:
 0    0
1    1
2    1
Name: survived, dtype: int64
```
Notice that $X$ is a clean, fully numerical 4-column matrix, while $y$ is a 1-column binary target vector.

## Practical Exercises

**Exercise 3.1:** What happens if you define `X = df["fare"]` instead of `df[["fare"]]` or `df[features]`? What is its shape, and why will scikit-learn reject it?  
**Exercise 3.2:** Write code to check the data types of all columns in `X` (`X.dtypes`). Are any non-numeric types remaining?  
**Exercise 3.3:** If you wished to test a model that only uses `pclass` and `is_female`, how would you define the `features` list?  

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Defining `features` with a single string instead of a list (`features = "pclass"`) | Extracts a 1D Series instead of a 2D DataFrame | Always use a list of column names: `features = ["pclass", ...]` |
| Passing `df` directly to the model without removing `passenger_id` | Model learns spurious noise based on passenger row numbers | Always slice out only designated predictive features into `X` |
| Accidentally including `survived` inside `features` | Target leakage: model achieves 100% training accuracy trivially by reading the answer | Keep `y` completely separate from `X` |

## Best Practices and Security Considerations

- **Target Leakage Prevention:** Never allow the target variable or any variable derived directly from the target to enter the feature matrix $X$.
- **Explicit Feature Lists:** Always define `features = [...]` explicitly rather than relying on `df.drop(columns=["survived"])`, which can inadvertently retain unexpected columns if the dataset schema changes.

## Summary

In scikit-learn, supervised learning algorithms require a two-dimensional feature matrix $X$ of shape `(n_samples, n_features)` and a one-dimensional target vector $y$ of shape `(n_samples,)`. In the Titanic Survival Oracle, $X$ is selected as a 4-column DataFrame (`pclass`, `is_female`, `age`, `fare`), and $y$ is isolated as the `survived` Series. Both are fully numeric and mathematically aligned for model training.

## Knowledge-check Questions

1. Why is the feature matrix named with a capital $X$ while the target is named with a lowercase $y$?
2. What are the dimensions of `X` and `y` in the Titanic Survival Oracle?
3. What is target leakage, and why is it dangerous in machine learning?
4. How does pandas indexing differ between `df[["age"]]` and `df["age"]`?
5. Why is explicit feature selection (`df[features]`) safer than column dropping (`df.drop(...)`)?

## References

- [Scikit-learn Getting Started: Model Fitting](https://scikit-learn.org/stable/getting_started.html)
- [Pandas Indexing and Selecting Data](https://pandas.pydata.org/docs/user_guide/indexing.html)
- [Target Leakage in Machine Learning (Kaggle Learn)](https://www.kaggle.com/code/alexisbcook/data-leakage)
