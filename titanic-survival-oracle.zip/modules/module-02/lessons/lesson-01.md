# Lesson 01: Loading Tabular Data with Pandas and Pathlib

**Lesson ID:** lesson-01  
**Module:** module-02  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Use Python's standard `pathlib.Path` to construct resilient filesystem paths relative to the script location
- Load tabular CSV data into a pandas DataFrame using `pd.read_csv()`
- Inspect the loaded dataset dimensions, column names, and data types
- Diagnose and prevent common file path errors (such as `FileNotFoundError`)

## Prerequisites
- Module 01: Project Overview & Problem Understanding
- Basic understanding of comma-separated value (CSV) files

## Concept Explanation

### The Challenge of File Paths in Python
A frequent point of frustration for beginners is the dreaded `FileNotFoundError`. If a script uses a relative string path like `"data/titanic_practice.csv"`, Python looks for the file relative to the **Current Working Directory (CWD)** where the terminal command was executed, not where the `.py` file actually lives on disk.

For example, if you run `python projects/03_titanic_survival/main.py` from your home directory, Python searches for `~/data/titanic_practice.csv` and crashes!

### Pathlib: The Modern Standard
Python 3 introduced `pathlib`, which models filesystem paths as object-oriented entities rather than raw strings:
- `Path(__file__)`: The path of the currently executing script.
- `.resolve()`: Computes the absolute, canonical path (resolving symbolic links).
- `.parent`: The folder containing the script (`projects/03_titanic_survival/`).
- `BASE / "data"`: The `/` operator cleanly concatenates path components regardless of operating system (forward slashes on Linux/macOS, backslashes on Windows).

### Ingesting Tabular Data with `pandas.read_csv`
Once the path to `data/titanic_practice.csv` is determined, `pandas.read_csv()` parses the comma-delimited text into a two-dimensional tabular data structure called a **DataFrame**:
- Rows represent individual passenger records (samples).
- Columns represent recorded attributes (features and targets).
- Column headers are automatically parsed from the first row of the CSV file.

## Relevant Code (from main.py, lines 21-28)

```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)


def main() -> None:
    df = pd.read_csv(DATA / "titanic_practice.csv")
```

## Code Explanation
- **Line 21**: `BASE = Path(__file__).resolve().parent` establishes an unbreakable anchor point: the directory housing `main.py`.
- **Line 22**: `DATA = BASE / "data"` defines the data directory path object.
- **Line 28**: `pd.read_csv(DATA / "titanic_practice.csv")` loads the CSV into the DataFrame variable `df`.

## Worked Example

**Problem:** Suppose your project lives at `/home/aziz/project/` and your terminal is currently open at `/home/aziz/`. Compare what happens when running `open("data/file.csv")` vs `open(Path(__file__).resolve().parent / "data" / "file.csv")`.

**Solution:**
1. With `open("data/file.csv")`: Python looks for `/home/aziz/data/file.csv`. Since `data/` is inside `/home/aziz/project/`, this raises `FileNotFoundError: [Errno 2] No such file or directory: 'data/file.csv'`.
2. With `Path(__file__).resolve().parent`: `__file__` resolves to `/home/aziz/project/main.py`. `.parent` resolves to `/home/aziz/project`. Adding `/ "data" / "file.csv"` yields the exact absolute path: `/home/aziz/project/data/file.csv`. The file loads correctly every time, regardless of where the command was run from.

## Step-by-Step Student Instructions

1. Open your terminal and create a small test script called `test_load.py` in the project directory:
   ```python
   from pathlib import Path
   import pandas as pd

   BASE = Path(__file__).resolve().parent
   DATA = BASE / "data"
   df = pd.read_csv(DATA / "titanic_practice.csv")
   print("Data loaded successfully!")
   print("Shape:", df.shape)
   print("Columns:", list(df.columns))
   ```
2. Run the script from the project folder:
   ```bash
   python3 test_load.py
   ```
3. Change directories to the parent directory and run it from there:
   ```bash
   cd ..
   python3 03_titanic_survival/test_load.py
   ```
4. Confirm that the script still succeeds without any path errors!

## Expected Output or Observable Behaviour

Executing the verification script produces:
```text
Data loaded successfully!
Shape: (90, 6)
Columns: ['passenger_id', 'pclass', 'sex', 'age', 'fare', 'survived']
```
The DataFrame has 90 rows and 6 columns, with headers perfectly parsed.

## Practical Exercises

**Exercise 1.1:** What does `Path(__file__).resolve().parent` evaluate to on your machine? Write a one-line script to print its value.  
**Exercise 1.2:** What error occurs if you misspell the file name as `titanic_data.csv` in `pd.read_csv()`?  
**Exercise 1.3:** Write a pandas command to view only the first 3 rows of the loaded DataFrame (`df.head(3)`).  

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Hardcoding string paths like `"/Users/name/data/titanic.csv"` | Fails on any other machine or user account | Use `Path(__file__).resolve().parent` |
| Using string concatenation (`BASE + "/data"`) | Raises `TypeError` because `BASE` is a `Path` object, not a string | Use the `/` path division operator: `BASE / "data"` |
| Forgetting to assign the output of `pd.read_csv` | The DataFrame is loaded into memory and immediately discarded | Store the result: `df = pd.read_csv(...)` |

## Best Practices and Security Considerations

- **Path Normalization:** Always use `pathlib.Path.resolve()` to eliminate relative dot segments (`.` and `..`) and produce clean canonical paths.
- **Data Integrity:** Check that the loaded dataset has the expected row count (`len(df) == 90`) immediately after ingestion before proceeding to model training.

## Summary

`pathlib.Path` provides a platform-independent, resilient way to manage filesystem locations in Python. Combining `Path(__file__).resolve().parent` with `pandas.read_csv()` ensures that `data/titanic_practice.csv` loads seamlessly regardless of how or where the script is executed. The resulting 90-row DataFrame is ready for feature engineering and modeling.

## Knowledge-check Questions

1. What does `__file__` represent in a Python script?
2. What operator does `pathlib` overload for joining path components?
3. How many rows and columns are loaded from `titanic_practice.csv`?
4. What happens if you run a script that uses `"data/file.csv"` from outside the project directory?
5. Which pandas function loads comma-separated text files into memory?

## References

- [Python pathlib Documentation](https://docs.python.org/3/library/pathlib.html)
- [Pandas read_csv API Reference](https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html)
- [Real Python: Python 3's pathlib Module: Taming the File System](https://realpython.com/python-pathlib/)
