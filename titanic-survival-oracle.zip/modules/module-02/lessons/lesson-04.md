# Lesson 04: Stratified Train-Test Splitting with `stratify=y`

**Lesson ID:** lesson-04  
**Module:** module-02  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain the necessity of splitting data into training and test sets to prevent memorization and measure generalization
- Explain what **sampling bias** is and why random splitting can distort class proportions in imbalanced datasets
- Define **stratified sampling** and explain how `stratify=y` preserves target class ratios
- Interpret the parameters `test_size=0.25` and `random_state=42` in `train_test_split`

## Prerequisites
- Lesson 01: Loading Tabular Data with Pandas and Pathlib
- Lesson 02: Feature Engineering: Encoding Categorical Data into `is_female`
- Lesson 03: Feature Matrix Selection ($X$) and Target Vector Separation ($y$)

## Concept Explanation

### The Golden Rule of Machine Learning: Never Test on Training Data
If a student takes an exam that consists of the exact same questions they practiced the night before, their high score may reflect memorization rather than true comprehension. 

Similarly, if you evaluate a machine learning model on the data it was trained on, the performance metrics will be deceptively optimistic. To measure **generalization**—how well the model performs on new, unseen data—we must partition our labeled dataset into:
- **Training Set (75%):** Used by the algorithm to discover patterns and fit decision rules.
- **Testing Set (25%):** Kept strictly in a "vault" until after training is complete to provide an honest, unbiased evaluation.

### What is Stratified Splitting?
In `titanic_practice.csv`, the class balance is imbalanced:
- 59 passengers perished (~65.6%)
- 31 passengers survived (~34.4%)

If we split the data completely at random, random chance might assign disproportionately many survivors to the test set and non-survivors to the training set. In extreme cases with small datasets, a class could be nearly absent from one of the subsets!

**Stratified Sampling (`stratify=y`)** solves this problem by ensuring that both the training set and the test set contain the exact same proportion of target classes as the original population:
- Original data: ~34.4% survivors
- Training set: ~34.3% survivors (23 out of 67)
- Test set: ~34.8% survivors (8 or 7 out of 23)

### The Role of `random_state=42`
Computers generate pseudo-random numbers using mathematical algorithms initialized with a "seed." If no seed is specified, Python uses system time, producing a different split every time the program runs. Setting `random_state=42` guarantees that every student and automated grader receives the exact same train/test partition and produces identical model predictions.

## Relevant Code (from main.py, lines 35-37)

```python
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
```

## Code Explanation
- **Line 35**: Unpacks the four returned subsets: `X_train`, `X_test`, `y_train`, `y_test`.
- **Line 36**:
  - `test_size=0.25`: Allocates 25% of the 90 samples to the test set ($90 \times 0.25 \approx 23$ passengers) and 75% to the training set ($90 \times 0.75 \approx 67$ passengers).
  - `random_state=42`: Fixes the pseudo-random seed for 100% reproducible splits.
  - `stratify=y`: Enforces proportional representation of both classes (0 and 1) across both subsets.

## Worked Example

**Problem:** Verify the class counts in `y_test` after stratified splitting with `random_state=42` and `test_size=0.25`.

**Solution:**
1. Total dataset: 90 passengers (59 class 0, 31 class 1).
2. Test partition size: 23 passengers.
3. Class proportion check:
   - Non-survivors (0): $\frac{59}{90} \times 23 \approx 15.07 \rightarrow$ rounded to 16 passengers.
   - Survivors (1): $\frac{31}{90} \times 23 \approx 7.92 \rightarrow$ rounded to 7 passengers.
4. Total test samples = $16 + 7 = 23$.
5. Proportion of survivors in test set: $\frac{7}{23} \approx 30.4\%$, closely reflecting the overall distribution.

## Step-by-Step Student Instructions

1. Open an interactive Python terminal:
   ```bash
   python3
   ```
2. Execute the stratified split and inspect the subset counts:
   ```python
   import pandas as pd
   from sklearn.model_selection import train_test_split

   df = pd.read_csv("data/titanic_practice.csv")
   df["is_female"] = (df["sex"] == "female").astype(int)
   X = df[["pclass", "is_female", "age", "fare"]]
   y = df["survived"]

   X_train, X_test, y_train, y_test = train_test_split(
       X, y, test_size=0.25, random_state=42, stratify=y
   )

   print("Training samples:", len(X_train))
   print("Testing samples:", len(X_test))
   print("\ny_train class counts:\n", y_train.value_counts())
   print("\ny_test class counts:\n", y_test.value_counts())
   ```
3. Verify that `y_train` has 43 non-survivors and 24 survivors, while `y_test` has 16 non-survivors and 7 survivors.

## Expected Output or Observable Behaviour

The execution output displays:
```text
Training samples: 67
Testing samples: 23

y_train class counts:
0    43
1    24
Name: survived, dtype: int64

y_test class counts:
0    16
1     7
Name: survived, dtype: int64
```
$43 + 16 = 59$ non-survivors, and $24 + 7 = 31$ survivors. Exactly 67 training rows and 23 testing rows are produced.

## Practical Exercises

**Exercise 4.1:** What happens to the split if you remove `stratify=y`? Run `train_test_split` without `stratify=y` and compare the class counts in `y_test`.  
**Exercise 4.2:** Why is it critical that `X_train` and `y_train` have the exact same number of rows?  
**Exercise 4.3:** If `test_size=0.20` were used instead of `0.25`, how many samples would be in the test set?  

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Forgetting `stratify=y` in classification | Risk of severe class imbalance in the test set, skewing evaluation | Always pass `stratify=y` when splitting categorical classification data |
| Splitting after fitting the model | Violates train-test isolation and leaks evaluation data | Always split data before passing anything to `model.fit()` |
| Misordering the unpacking variables | Assigning `X_test, X_train = ...` will train on test data and evaluate on training data | Strictly maintain order: `X_train, X_test, y_train, y_test` |

## Best Practices and Security Considerations

- **Strict Train-Test Isolation:** Never use `X_test` or `y_test` to calculate feature scalers, impute missing values, or make training decisions. Any operation on test data must use statistics learned exclusively from training data.
- **Stratification on Rare Classes:** In imbalanced classification (e.g., fraud detection, disease diagnosis, or survival prediction), stratification is an essential safeguard against unrepresentative test sets.

## Summary

Data splitting isolates training data from evaluation data, enabling an honest measurement of model generalization. By setting `test_size=0.25` and `stratify=y`, `train_test_split` partitions the 90 Titanic passenger records into 67 training records and 23 testing records while maintaining proportional representation of both survivors and non-survivors. Fixing `random_state=42` ensures exact scientific reproducibility.

## Knowledge-check Questions

1. Why must a machine learning model never be evaluated solely on the data it trained on?
2. What does `stratify=y` ensure when splitting a classification dataset?
3. How many passenger records are in the training set and testing set in this project?
4. In what exact order does `train_test_split` return its 4 output variables?
5. Why is `random_state=42` included in the function call?

## References

- [Scikit-learn train_test_split Documentation](https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html)
- [Cross-validation and Data Partitioning User Guide](https://scikit-learn.org/stable/modules/cross_validation.html#stratification)
- [Why Stratified K-Fold and Stratified Splitting Matter in Imbalanced ML](https://machinelearningmastery.com/cross-validation-for-imbalanced-classification/)
