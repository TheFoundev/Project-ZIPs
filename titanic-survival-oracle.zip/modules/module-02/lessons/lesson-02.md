# Lesson 02: Feature Engineering: Encoding Categorical Data into `is_female`

**Lesson ID:** lesson-02  
**Module:** module-02  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain what feature engineering is and why machine learning algorithms require numerical inputs
- Identify categorical variables in raw datasets
- Use vectorized pandas boolean comparison and `.astype(int)` to convert categorical strings to binary integers
- Explain why the original string column (`sex`) must be dropped or excluded from model training

## Prerequisites
- Lesson 01: Loading Tabular Data with Pandas and Pathlib
- Basic familiarity with Python boolean values (`True` and `False`)

## Concept Explanation

### Why Algorithms Cannot Read Strings Directly
Scikit-learn algorithms—including decision trees, linear regression, and neural networks—perform mathematical operations (calculating inequalities, dot products, distance metrics, and statistical impurities). 

If you pass raw text strings like `"female"` or `"male"` to `DecisionTreeClassifier.fit()`, scikit-learn will immediately crash with a `ValueError: could not convert string to float: 'male'`. Algorithms cannot calculate whether `"female" <= 0.50` unless the category is encoded as a number.

### The Role of Feature Engineering
**Feature Engineering** is the practice of extracting, transforming, and formatting raw data into numerical representations that maximize the learning capacity of a machine learning algorithm.

In the raw Titanic data:
- The `sex` column contains two string categories: `"male"` and `"female"`.
- We want to represent this information as a binary numerical feature:
  - Female $\rightarrow 1$
  - Male $\rightarrow 0$

### Vectorized Boolean Transformation in Pandas
In pandas, this transformation is achieved concisely in a single vectorized line:
```python
df["is_female"] = (df["sex"] == "female").astype(int)
```
Let's break down how this works:
1. `df["sex"] == "female"` compares every element in the `sex` column against the string `"female"`. This yields a pandas Series of booleans (`True` or `False`).
2. `.astype(int)` casts boolean values into integers:
   - `True.astype(int)` becomes `1`
   - `False.astype(int)` becomes `0`
3. The new column is assigned to `df["is_female"]`.

### Why We Exclude the Original `"sex"` Column
Once `is_female` is created, the raw text column `sex` is completely redundant. If we keep both in our feature set:
1. The model will crash when encountering the text strings in `sex`.
2. Even if encoded, keeping duplicate representations of the same underlying information adds clutter without providing new signal.
Therefore, `sex` is omitted from the feature matrix $X$.

## Relevant Code (from main.py, lines 28-32)

```python
    df = pd.read_csv(DATA / "titanic_practice.csv")
    df["is_female"] = (df["sex"] == "female").astype(int)

    features = ["pclass", "is_female", "age", "fare"]
    X = df[features]
```

## Code Explanation
- **Line 29**: Evaluates `(df["sex"] == "female")` element-wise and casts the resulting boolean mask into integer values (`0` and `1`), creating the new column `df["is_female"]`.
- **Lines 31-32**: Note that `features` lists `"is_female"`, but intentionally omits `"sex"`.

## Worked Example

**Problem:** Trace the conversion of the first 4 passenger records in `titanic_practice.csv`:
Row 0: `sex = "male"`  
Row 1: `sex = "male"`  
Row 2: `sex = "female"`  
Row 3: `sex = "female"`  

**Step-by-step Transformation:**
1. Boolean comparison (`df["sex"] == "female"`):
   - Row 0: `"male" == "female"` $\rightarrow$ `False`
   - Row 1: `"male" == "female"` $\rightarrow$ `False`
   - Row 2: `"female" == "female"` $\rightarrow$ `True`
   - Row 3: `"female" == "female"` $\rightarrow$ `True`
2. Integer casting (`.astype(int)`):
   - Row 0: `False` $\rightarrow$ `0`
   - Row 1: `False` $\rightarrow$ `0`
   - Row 2: `True` $\rightarrow$ `1`
   - Row 3: `True` $\rightarrow$ `1`
3. Resulting `is_female` Series: `[0, 0, 1, 1]`.

## Step-by-Step Student Instructions

1. Launch Python in your terminal:
   ```bash
   python3
   ```
2. Run the following commands to see the transformation step-by-step:
   ```python
   import pandas as pd
   df = pd.read_csv("data/titanic_practice.csv")

   # Step 1: See the raw text
   print(df["sex"].head(4))

   # Step 2: See the boolean mask
   mask = df["sex"] == "female"
   print(mask.head(4))

   # Step 3: See the integer conversion
   df["is_female"] = mask.astype(int)
   print(df[["sex", "is_female"]].head(4))
   ```
3. Check the value counts of both columns to ensure no records were lost or corrupted:
   ```python
   print(df["sex"].value_counts())
   print(df["is_female"].value_counts())
   ```

## Expected Output or Observable Behaviour

The output in your terminal will display:
```text
0      male
1      male
2    female
3    female
Name: sex, dtype: object

0    False
1    False
2     True
3     True
Name: sex, dtype: bool

      sex  is_female
0    male          0
1    male          0
2  female          1
3  female          1

male      59
female    31
Name: sex, dtype: int64

0    59
1    31
Name: is_female, dtype: int64
```
Exactly 59 males map to `0`, and 31 females map to `1`. The transformation is complete and lossless.

## Practical Exercises

**Exercise 2.1:** What would happen if you created `is_male = (df["sex"] == "male").astype(int)` instead? Does using `is_male` instead of `is_female` change the predictive capability of a decision tree?  
**Exercise 2.2:** What error is raised by `sklearn.tree.DecisionTreeClassifier().fit(df[["sex"]], df["survived"])`? Run it to observe the exact exception message.  
**Exercise 2.3:** Why is `.astype(int)` required? What happens if you pass boolean (`True`/`False`) values into scikit-learn models?  

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Forgetting `.astype(int)` | Keeps the column as boolean (`True`/`False`), which may cause formatting or export issues | Always explicitly cast to integer: `.astype(int)` |
| Keeping both `sex` and `is_female` in `X` | Scikit-learn fails when attempting mathematical operations on strings in `sex` | Only include numeric columns in the `features` list |
| Using a slow Python `for` loop to encode values | Iterating row by row in Python is orders of magnitude slower than vectorized pandas operations | Use vectorized operations: `(df["sex"] == "female").astype(int)` |

## Best Practices and Security Considerations

- **Vectorized Operations:** Never write manual `for` loops across pandas rows (`iterrows()`) when standard vectorized comparisons exist. Vectorized operations run in compiled C code.
- **Handling Unknown or Missing Categories:** If production data contains missing or unexpected categories (e.g., `NaN` or typos), `(df["sex"] == "female")` safely defaults to `False` (`0`). In production pipelines, explicitly validate categorical inputs with schemas.

## Summary

Machine learning algorithms require numeric inputs. Feature engineering transforms non-numeric raw data into numerical representations suitable for computation. By executing `(df["sex"] == "female").astype(int)`, we convert textual sex categories into a clean binary indicator `is_female` (1 = female, 0 = male). The original string column `sex` is then excluded to prevent runtime errors during model fitting.

## Knowledge-check Questions

1. Why cannot raw text columns like `sex` be passed directly into scikit-learn classifiers?
2. What pandas expression converts `"female"` to `1` and `"male"` to `0`?
3. What is the data type of `df["sex"] == "female"` before `.astype(int)` is called?
4. How many female passengers are in `titanic_practice.csv`?
5. Why is the original `sex` column omitted from the `features` list?

## References

- [Pandas Boolean Indexing and Comparison](https://pandas.pydata.org/docs/user_guide/indexing.html#boolean-indexing)
- [Scikit-learn Preprocessing: Encoding Categorical Features](https://scikit-learn.org/stable/modules/preprocessing.html#encoding-categorical-features)
- [Feature Engineering for Machine Learning (Alice Zheng & Amanda Casari)](https://www.oreilly.com/library/view/feature-engineering-for/9781491953235/)
