# Module 2 Exercises: Data Loading & Feature Engineering

## Exercise 2.1: Categorical Encoding Verification (15 min)
**Objective:** Implement and verify categorical boolean-to-integer conversion on the Titanic dataset.  
**Problem Statement:** Scikit-learn estimators cannot process text strings like `"female"` and `"male"`. You must transform the `sex` column into a numeric feature and verify the transformation.

**Requirements:**
1. Load `data/titanic_practice.csv` using `pandas` and `pathlib.Path`.
2. Inspect `df["sex"].dtype` to confirm it is an `object` (string) type.
3. Create `df["is_female"] = (df["sex"] == "female").astype(int)`.
4. Verify that `df["is_female"].dtype` is now `int64` (or integer).
5. Cross-tabulate `df["sex"]` and `df["is_female"]` using `pd.crosstab()` to ensure 0 errors.

**Constraints:** Do not use `sklearn.preprocessing.LabelEncoder` or manual `for` loops. Use pandas vectorized operations.

**Expected Behaviour:** Clean Python code and terminal output proving 100% concordance between `"female"` and `1`, and `"male"` and `0`.

**Acceptance Criteria:**
- [ ] Correctly implements `(df["sex"] == "female").astype(int)`.
- [ ] `pd.crosstab()` shows exactly 59 males mapped to 0 and 31 females mapped to 1.
- [ ] No null or missing values introduced.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 2.2: Assembling Feature Matrix $X$ and Target Vector $y$ (10 min)
**Objective:** Assemble the 2D feature matrix $X$ and 1D target vector $y$ adhering to scikit-learn conventions.  
**Problem Statement:** In machine learning workflows, feeding incorrect shapes or including redundant columns causes failures or data leakage.

**Requirements:**
1. Define `features = ["pclass", "is_female", "age", "fare"]`.
2. Extract `X = df[features]`.
3. Extract `y = df["survived"]`.
4. Verify that `X.shape == (90, 4)` and `y.shape == (90,)`.
5. Check that neither `passenger_id` nor `sex` is present in `X.columns`.

**Constraints:** Ensure $X$ is a DataFrame and $y$ is a Series.

**Expected Behaviour:** Python script that verifies shapes and prints column types of $X$.

**Acceptance Criteria:**
- [ ] `X.shape` is `(90, 4)`.
- [ ] `y.shape` is `(90,)`.
- [ ] `passenger_id` and `sex` are excluded from $X$.
- [ ] All columns in $X$ are numeric.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes  

---

## Exercise 2.3: Stratified vs. Unstratified Split Comparison (15 min)
**Objective:** Analyze the impact of `stratify=y` on preserving target class ratios in small datasets.  
**Problem Statement:** Evaluate what happens to class distributions when `stratify=y` is included versus omitted.

**Requirements:**
1. Perform a stratified split: `train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)`.
2. Record the number of survivors in `y_test`.
3. Perform an unstratified split: `train_test_split(X, y, test_size=0.25, random_state=42)` (without `stratify`).
4. Compare the percentage of survivors in `y_test` between the two splits against the overall population survival rate (~34.4%).
5. Write 2-3 sentences explaining why stratification is preferred for classification.

**Acceptance Criteria:**
- [ ] Accurately counts survivors in both split methods.
- [ ] Notes how stratified sampling anchors test set class proportions.
- [ ] Justifies the use of stratification in imbalanced classification.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 2.4: Pathlib Cross-Platform File Resolution (10 min)
**Objective:** Build a robust, working-directory-independent script using `pathlib.Path`.  
**Problem Statement:** Write a small script that reads `data/titanic_practice.csv` and writes a summary text file to `outputs/dataset_info.txt`, ensuring it works even when executed from an arbitrary directory.

**Requirements:**
1. Define `BASE = Path(__file__).resolve().parent`.
2. Define `DATA = BASE / "data"` and `OUT = BASE / "outputs"`.
3. Create `OUT.mkdir(exist_ok=True)`.
4. Write row count, column list, and survival counts into `OUT / "dataset_info.txt"`.
5. Test executing the script from both the project directory and its parent folder.

**Acceptance Criteria:**
- [ ] Uses `pathlib.Path` exclusively (no `os.path` string operations).
- [ ] Uses `mkdir(exist_ok=True)`.
- [ ] Script executes cleanly without errors from any working directory.
- [ ] Output file `dataset_info.txt` is written successfully.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 10 minutes  
