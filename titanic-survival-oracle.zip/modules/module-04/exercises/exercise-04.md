# Module 4 Exercises: Model Training & Predictions

## Exercise 4.1: Estimator Fitting & Tree Structure Inspection (15 min)
**Objective:** Fit the `DecisionTreeClassifier` and inspect its internal attributes.  
**Problem Statement:** Scikit-learn models store valuable internal metrics upon fitting. Train the classifier and extract key parameters.

**Requirements:**
1. Split the data as specified in `main.py` (`test_size=0.25, random_state=42, stratify=y`).
2. Train `DecisionTreeClassifier(max_depth=4, random_state=42)` on `X_train` and `y_train`.
3. Print `model.classes_` and confirm it equals `[0, 1]`.
4. Print `model.feature_names_in_` and confirm the 4 features.
5. Print `model.tree_.max_depth` and `model.tree_.node_count`.

**Constraints:** Ensure the model is trained exclusively on `X_train` and `y_train`.

**Expected Behaviour:** Python script output reporting the fitted estimator's structure.

**Acceptance Criteria:**
- [ ] Model trains without warnings or errors.
- [ ] Confirms 2 classes (`[0, 1]`) and 4 features.
- [ ] Tree depth confirms 4 levels and 25 total nodes.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 4.2: Comparing Predictions Against Ground Truth (15 min)
**Objective:** Perform batch inference on the test set and analyze individual passenger outcomes.  
**Problem Statement:** Generate discrete predictions on `X_test` and create a detailed classification comparison table.

**Requirements:**
1. Call `predictions = model.predict(X_test)`.
2. Construct a DataFrame containing `y_test.values` as `Actual` and `predictions` as `Predicted`.
3. Add a boolean column `Correct = Actual == Predicted`.
4. Count the number of True Negatives (Actual 0, Predicted 0), True Positives (Actual 1, Predicted 1), False Positives (Actual 0, Predicted 1), and False Negatives (Actual 1, Predicted 0).
5. Calculate total test accuracy manually from the counts.

**Acceptance Criteria:**
- [ ] Accurately identifies 17 correct predictions and 6 incorrect predictions.
- [ ] Identifies 13 True Negatives, 4 True Positives, 3 False Positives, and 3 False Negatives.
- [ ] Computes accuracy as $17 / 23 \approx 73.91\%$.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 4.3: Dissecting `predict_proba` Dimensions and Slicing (15 min)
**Objective:** Inspect and slice 2D class probability arrays.  
**Problem Statement:** Many applications require the raw survival probability rather than just the discrete label. Extract and analyze probability distributions across the test set.

**Requirements:**
1. Call `probs = model.predict_proba(X_test)`.
2. Verify that `probs.shape == (23, 2)`.
3. Verify that all row sums equal 1.0 (`np.allclose(probs.sum(axis=1), 1.0)`).
4. Extract only the survival probabilities ($P(y=1)$) into a 1D array using slice syntax `[:, 1]`.
5. Identify the lowest and highest survival probabilities predicted on the test set.

**Acceptance Criteria:**
- [ ] Correctly verifies array dimensions and row normalization.
- [ ] Extracts the positive class probabilities using `probs[:, 1]`.
- [ ] Identifies min probability (0.0) and max probability (1.0).

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 4.4: Simulating Five Historical Passenger Archetypes (15 min)
**Objective:** Construct custom passenger profiles and simulate their survival odds.  
**Problem Statement:** Test the Oracle against five distinct historical passenger archetypes to explore the interaction between class, sex, and age.

**Archetypes to Test:**
1. **Wealthy 1st-Class Woman:** Class 1, Female, Age 35, Fare £80.00
2. **1st-Class Gentleman:** Class 1, Male, Age 45, Fare £50.00
3. **2nd-Class Child:** Class 2, Male, Age 6, Fare £25.00
4. **3rd-Class Immigrant Mother:** Class 3, Female, Age 28, Fare £15.00
5. **3rd-Class Young Laborer:** Class 3, Male, Age 21, Fare £7.50

**Requirements:**
1. Package all five archetypes into a single pandas DataFrame with matching column names.
2. Predict the discrete survival class for each archetype.
3. Predict the exact survival probability for each archetype.
4. Write 2-3 sentences summarizing the Oracle's demographic findings.

**Acceptance Criteria:**
- [ ] DataFrame contains all 5 records with correct schemas.
- [ ] Computes predictions and probabilities for all 5 archetypes.
- [ ] Correctly identifies high survival for 1st-class female and child, and low survival for 3rd-class adults.

**Difficulty:** Advanced  
**Estimated Completion Time:** 15 minutes  
