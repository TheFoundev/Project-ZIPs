# Lesson 01: Fitting the DecisionTreeClassifier on Training Data

**Lesson ID:** lesson-01  
**Module:** module-04  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain the role of the `.fit()` method in scikit-learn estimators
- Differentiate between model instantiation and model training
- Verify that the model trains exclusively on `X_train` and `y_train` to prevent data leakage
- Inspect learned model attributes following training (e.g., `model.tree_`, `model.classes_`)

## Prerequisites
- Module 02: Data Loading & Feature Engineering
- Module 03: Decision Tree Algorithm

## Concept Explanation

### Instantiation vs. Fitting
In scikit-learn's object-oriented architecture, creating a model is a two-step process:

1. **Instantiation (`model = DecisionTreeClassifier(...)`):**
   - Creates an un-trained estimator object.
   - Sets hyperparameters (e.g., `max_depth=4`, `random_state=42`).
   - At this stage, the model contains no knowledge of data. If you attempt to call `model.predict()`, it raises `NotFittedError: This DecisionTreeClassifier instance is not fitted yet.`

2. **Fitting (`model.fit(X_train, y_train)`):**
   - The estimator ingests the training feature matrix `X_train` and target vector `y_train`.
   - It performs recursive binary splitting using Gini impurity.
   - It calculates split thresholds and leaf class allocations.
   - Upon completion, the model is fully trained and ready to make predictions.

### The Critical Cardinal Rule: Train on Training Data ONLY
Never write `model.fit(X, y)` before evaluating on `X_test`!
Passing the full dataset `X` to `.fit()` leaks the test answers to the model. An evaluation conducted on data that the model has already seen during `.fit()` is invalid.

## Relevant Code (from main.py, lines 39-40)

```python
    model = DecisionTreeClassifier(max_depth=4, random_state=42)
    model.fit(X_train, y_train)
```

## Code Explanation
- **Line 39**: Configures the estimator with maximum depth 4 and reproducible random seed 42.
- **Line 40**: Calls `.fit(X_train, y_train)` with the 67 training passengers. This builds the decision tree structure internally within `model.tree_`.

## Worked Example

**Problem:** What happens under the hood when `model.fit(X_train, y_train)` is executed?

**Solution:**
1. Input verification: Scikit-learn checks that `X_train` has 2 dimensions, contains only numeric data, has no `NaN` values, and that `len(X_train) == len(y_train) == 67`.
2. Target analysis: It determines the target classes present: `model.classes_` is assigned `array([0, 1])`.
3. Split optimization: Starting at depth 0, it tests thresholds across `pclass`, `is_female`, `age`, and `fare` for the 67 samples.
4. Tree building: It constructs internal nodes and halts at leaf nodes whenever a depth of 4 or pure Gini is reached.
5. Post-condition: The trained model object returns `self`.

## Step-by-Step Student Instructions

1. Launch Python in your terminal:
   ```bash
   python3
   ```
2. Run the training sequence and inspect the fitted model attributes:
   ```python
   import pandas as pd
   from sklearn.model_selection import train_test_split
   from sklearn.tree import DecisionTreeClassifier

   df = pd.read_csv("data/titanic_practice.csv")
   df["is_female"] = (df["sex"] == "female").astype(int)
   X = df[["pclass", "is_female", "age", "fare"]]
   y = df["survived"]

   X_train, X_test, y_train, y_test = train_test_split(
       X, y, test_size=0.25, random_state=42, stratify=y
   )

   model = DecisionTreeClassifier(max_depth=4, random_state=42)
   model.fit(X_train, y_train)

   print("Fitted classes:", model.classes_)
   print("Number of features seen during fit:", model.n_features_in_)
   print("Feature names seen during fit:", list(model.feature_names_in_))
   print("Total nodes created:", model.tree_.node_count)
   ```
3. Confirm that the model recognizes classes `[0, 1]` and 4 input features.

## Expected Output or Observable Behaviour

The execution output will print:
```text
Fitted classes: [0 1]
Number of features seen during fit: 4
Feature names seen during fit: ['pclass', 'is_female', 'age', 'fare']
Total nodes created: 25
```
The tree creates 25 total nodes (12 internal decision splits and 13 terminal leaf nodes) across its 4 levels of depth.

## Practical Exercises

**Exercise 1.1:** What happens if you call `model.predict(X_test)` immediately after `DecisionTreeClassifier()`, before calling `.fit()`? Run it to observe the exception.  
**Exercise 1.2:** What does the trailing underscore in scikit-learn attributes (e.g., `model.classes_`, `model.feature_names_in_`) signify?  
**Exercise 1.3:** How many total samples were used to fit the model?  

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Calling `.fit(X, y)` on the entire dataset | Leaks test data into the training phase, invalidating evaluation | Only pass training partitions: `.fit(X_train, y_train)` |
| Calling `.fit(X_test, y_test)` | Trains the model on the small test partition and wastes training data | Always train on `X_train` and `y_train` |
| Calling `.fit()` on non-numeric or missing data | Scikit-learn raises `ValueError: could not convert string to float` | Perform all feature engineering before calling `.fit()` |

## Best Practices and Security Considerations

- **Scikit-Learn Naming Conventions:** Attributes estimated from data always end with a trailing underscore (e.g., `classes_`, `feature_names_in_`, `tree_`), distinguishing them from user-configured hyperparameters.
- **Idempotency:** Calling `.fit()` multiple times on the same estimator object overwrites the previously learned model completely; it does not incrementally update the tree.

## Summary

The `.fit()` method is the core training engine in scikit-learn. When invoked as `model.fit(X_train, y_train)`, the decision tree estimator inspects the 67 training passengers and constructs an optimized 4-depth rule structure. By training exclusively on the training set, we maintain strict data isolation and prevent data leakage.

## Knowledge-check Questions

1. What error is raised if `predict()` is called on an estimator before `fit()` is called?
2. What do scikit-learn attributes ending with an underscore (like `classes_`) represent?
3. How many passenger records are processed during `model.fit(X_train, y_train)`?
4. Why is fitting on the entire dataset `X` considered a severe flaw in machine learning workflows?
5. What does `model.n_features_in_` report?

## References

- [Scikit-learn API Design: fit and predict](https://scikit-learn.org/stable/developers/develop.html#apis-of-scikit-learn-objects)
- [Common Scikit-learn Pitfalls: Data Leakage](https://scikit-learn.org/stable/common_pitfalls.html#data-leakage)
- [DecisionTreeClassifier Fit Method Documentation](https://scikit-learn.org/stable/modules/generated/sklearn.tree.DecisionTreeClassifier.html#sklearn.tree.DecisionTreeClassifier.fit)
