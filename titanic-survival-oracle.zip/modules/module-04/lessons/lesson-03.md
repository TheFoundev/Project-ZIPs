# Lesson 03: Estimating Probabilities with `predict_proba()`

**Lesson ID:** lesson-03  
**Module:** module-04  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain what `predict_proba()` computes in scikit-learn classifiers
- Interpret the 2D array returned by `predict_proba()` where each row sums to 1.0
- Explain how a decision tree calculates leaf probabilities from training sample counts (`value = [n_0, n_1]`)
- Slice the positive class probability ($P(y=1)$) using 2D array indexing `[:, 1]` or `[0, 1]`

## Prerequisites
- Lesson 01: Fitting the DecisionTreeClassifier on Training Data
- Lesson 02: Making Discrete Class Predictions with `predict()`

## Concept Explanation

### Discrete Labels vs. Degrees of Certainty
In many real-world scenarios, receiving a simple "Yes" or "No" label is insufficient. Decision-makers need to know: **"How certain is the model?"**
- A passenger predicted as `survived = 1` with a **95% probability** represents an almost certain rescue.
- A passenger predicted as `survived = 1` with a **51% probability** represents a borderline, high-risk situation.

While `.predict()` outputs the thresholded binary label, `.predict_proba()` outputs the raw estimated probability distribution across all classes.

### How a Decision Tree Computes Probabilities
Unlike linear or logistic models that use continuous sigmoid curves, a decision tree computes class probabilities directly from the empirical distribution of training samples in the leaf node where a sample lands!

If an unseen passenger lands in a leaf node whose training sample distribution is:
$$\text{value} = [n_0, n_1] = [2, 8]$$
The tree estimates:
- Probability of class 0 (perished): $P(y=0) = \frac{2}{2 + 8} = \frac{2}{10} = 0.20$ (20%)
- Probability of class 1 (survived): $P(y=1) = \frac{8}{2 + 8} = \frac{8}{10} = 0.80$ (80%)

### Array Structure of `predict_proba()`
For binary classification, `predict_proba(X)` returns a 2D NumPy array of shape `(n_samples, 2)`:
- Column 0: Estimated probability of Class 0 ($P(y=0)$)
- Column 1: Estimated probability of Class 1 ($P(y=1)$)
- For every row, the probabilities always sum to exactly 1.0: $P(y=0) + P(y=1) = 1.0$.

```
                        predict_proba() output (2D array)
                        ┌───────────────────┬───────────────────┐
                        │ Column 0: P(y=0)  │ Column 1: P(y=1)  │
                        ├───────────────────┼───────────────────┤
Passenger 0:            │       0.85        │       0.15        │  Sum = 1.0
Passenger 1:            │       0.00        │       1.00        │  Sum = 1.0
Passenger 2:            │       0.40        │       0.60        │  Sum = 1.0
                        └───────────────────┴───────────────────┘
```

To extract specifically the survival probability of the first passenger, we write:
```python
survival_prob = model.predict_proba(new_passenger)[0, 1]
```
Where `[0, 1]` selects row 0 (the first passenger) and column 1 (class 1, survived).

## Relevant Code (from main.py, lines 61-62)

```python
    probability = model.predict_proba(new_passenger)[0, 1]
    print(f"Made-up passenger survival probability: {probability:.1%}")
```

## Code Explanation
- **Line 61**: Evaluates `new_passenger` through `predict_proba()` and uses `[0, 1]` to extract the probability of survival (class 1).
- **Line 62**: Formats the probability as a clean percentage with 1 decimal place using Python's `:.1%` format specifier.

## Worked Example

**Problem:** Suppose a test passenger is routed to a leaf node containing `value = [14, 0]`. What will `predict_proba()` output for this passenger?

**Solution:**
1. Leaf contains 14 non-survivors and 0 survivors (total samples = 14).
2. $P(y=0) = \frac{14}{14} = 1.0$ (100% chance of dying).
3. $P(y=1) = \frac{0}{14} = 0.0$ (0% chance of survival).
4. `model.predict_proba(passenger)` returns `array([[1.0, 0.0]])`.
5. Accessing `[0, 1]` yields `0.0` (0.0%).

## Step-by-Step Student Instructions

1. Open Python in your terminal:
   ```bash
   python3
   ```
2. Inspect the probabilities predicted for the first 5 test passengers:
   ```python
   import pandas as pd
   from sklearn.model_selection import train_test_split
   from sklearn.tree import DecisionTreeClassifier

   df = pd.read_csv("data/titanic_practice.csv")
   df["is_female"] = (df["sex"] == "female").astype(int)
   X = df[["pclass", "is_female", "age", "fare"]]
   y = df["survived"]

   X_train, X_test, y_train, y_test = train_test_split(
       X, y, test_size=0.25, random_state=42, stratify=y
   )

   model = DecisionTreeClassifier(max_depth=4, random_state=42).fit(X_train, y_train)

   probs = model.predict_proba(X_test)
   print("Shape of probability array:", probs.shape)
   print("\nProbabilities for first 5 test passengers:\n", probs[:5])

   # Verify row sums
   print("\nRow sums (must all be 1.0):", probs[:5].sum(axis=1))
   ```
3. Observe how each test passenger receives a pair of probabilities that sum to 1.0.

## Expected Output or Observable Behaviour

Executing this script displays:
```text
Shape of probability array: (23, 2)

Probabilities for first 5 test passengers:
 [[1.  0. ]
  [1.  0. ]
  [0.  1. ]
  [1.  0. ]
  [1.  0. ]]

Row sums (must all be 1.0): [1. 1. 1. 1. 1.]
```
Because `max_depth=4` was used, many of the leaf nodes reached by test passengers are pure, yielding probabilities of exactly `1.0` and `0.0`.

## Practical Exercises

**Exercise 3.1:** What is the difference in output between `model.predict(X_test)[0]` and `model.predict_proba(X_test)[0]`?  
**Exercise 3.2:** If `model.predict_proba(sample)[0, 1]` equals `0.45`, what discrete class will `model.predict(sample)[0]` output under the standard 0.50 threshold?  
**Exercise 3.3:** How would you extract only the survival probabilities for *all* test passengers as a 1D array? (Hint: use slicing syntax `[:, 1]`).  

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Indexing `probs[0]` and assuming it is the survival probability | `probs[0]` is a 1D array of two numbers `[P(0), P(1)]` for passenger 0 | Use `probs[0, 1]` or `probs[0][1]` to select class 1 |
| Confusing column 0 with column 1 | Column 0 is $P(y=0)$ (perished), while column 1 is $P(y=1)$ (survived) | Check `model.classes_` to confirm column order |
| Assuming decision tree probabilities are smooth | Tree probabilities are step-wise and jump discretely between leaf nodes | Understand that tree probabilities reflect leaf sample ratios |

## Best Practices and Security Considerations

- **Calibration Awareness:** Decision tree probability estimates can be overconfident because leaves with few samples (e.g. 1 sample of class 1) yield extreme probabilities (100%) that may not reflect true underlying frequencies. In production, consider pruning or probability calibration (e.g., `CalibratedClassifierCV`).
- **Verify Class Ordering:** Always check `model.classes_` before slicing `predict_proba()`. In scikit-learn, column indices correspond to sorted class values (`0` then `1`).

## Summary

`predict_proba()` calculates the estimated class probability distribution for each sample based on the empirical ratio of training classes in the leaf node reached. For binary classification, it outputs an $(N, 2)$ array where column 0 is $P(y=0)$ and column 1 is $P(y=1)$. Slicing `[0, 1]` retrieves the specific survival probability for an individual passenger.

## Knowledge-check Questions

1. What are the dimensions of the array returned by `predict_proba(X_test)` when `len(X_test) == 23`?
2. What does the sum of values across any single row in `predict_proba()` equal?
3. How does a decision tree calculate the probability of survival in a leaf node?
4. What slicing syntax extracts the survival probability for a single passenger at index 0?
5. If a leaf node has `value = [1, 3]`, what is the survival probability for a passenger landing there?

## References

- [Scikit-learn DecisionTreeClassifier predict_proba Documentation](https://scikit-learn.org/stable/modules/generated/sklearn.tree.DecisionTreeClassifier.html#sklearn.tree.DecisionTreeClassifier.predict_proba)
- [Probability Calibration Guide (Scikit-Learn)](https://scikit-learn.org/stable/modules/calibration.html)
- [Interpreting Model Confidence and Probabilities](https://developers.google.com/machine-learning/crash-course/logistic-regression/calculating-a-probability)
