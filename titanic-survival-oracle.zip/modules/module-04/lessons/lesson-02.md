# Lesson 02: Making Discrete Class Predictions with `predict()`

**Lesson ID:** lesson-02  
**Module:** module-04  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Use the `.predict()` method to generate discrete binary class labels on unseen test data
- Explain the internal inference mechanism: routing test samples down the decision tree
- Inspect and interpret the output shape and contents of the returned predictions array
- Compare predictions directly against actual ground-truth labels `y_test`

## Prerequisites
- Lesson 01: Fitting the DecisionTreeClassifier on Training Data
- Basic understanding of NumPy 1D arrays

## Concept Explanation

### The Inference Phase
Once a decision tree has been trained via `.fit()`, it enters the **inference phase**. During inference:
1. The model receives a matrix of unseen passenger features (`X_test`).
2. For each passenger, it starts at the root node.
3. It evaluates the passenger's feature values against the learned split conditions (e.g., `is_female <= 0.50`, `age <= 18.50`).
4. It navigates down the corresponding branches until it hits a leaf node.
5. It assigns the leaf node's majority class label (either `0` or `1`) as the final prediction for that passenger.

### What `.predict()` Returns
When you call `model.predict(X_test)`:
- It returns a 1D NumPy array of integers.
- The length of the array matches the number of rows in `X_test` (here, exactly 23 predictions).
- Each value is either `0` (predicted non-survivor) or `1` (predicted survivor).

```
       X_test (23 passengers)                 model.predict(X_test)
┌────────┬───────────┬─────┬──────┐               ┌───┐
│ pclass │ is_female │ age │ fare │               │ 0 │
├────────┼───────────┼─────┼──────┤               ├───┤
│   1    │     1     │ 22  │ 55.0 │   ───────►    │ 1 │
│   3    │     0     │ 40  │  7.5 │               ├───┤
│  ...   │    ...    │ ... │ ...  │               │ 0 │
└────────┴───────────┴─────┴──────┘               └───┘
```

## Relevant Code (from main.py, line 41)

```python
    predictions = model.predict(X_test)
```

## Code Explanation
- **Line 41**: Passes the 23-row `X_test` DataFrame into `model.predict()`. The resulting 1D NumPy array is stored in the variable `predictions`.

## Worked Example

**Problem:** Compare the first 5 elements of `predictions` against the actual ground truth `y_test.values`. How many did the model get right?

**Solution:**
1. Extract the actual test labels:
   `y_test.values[:5] = [0, 0, 1, 0, 1]`
2. Generate the predictions:
   `predictions[:5]   = [0, 0, 1, 0, 0]`
3. Compare element-by-element:
   - Sample 0: Actual 0, Pred 0 $\rightarrow$ Correct!
   - Sample 1: Actual 0, Pred 0 $\rightarrow$ Correct!
   - Sample 2: Actual 1, Pred 1 $\rightarrow$ Correct!
   - Sample 3: Actual 0, Pred 0 $\rightarrow$ Correct!
   - Sample 4: Actual 1, Pred 0 $\rightarrow$ Incorrect (Misclassification / False Negative).
4. Out of the first 5 test passengers, the model predicted 4 correctly (80% accuracy on this subset).

## Step-by-Step Student Instructions

1. Open Python in your terminal:
   ```bash
   python3
   ```
2. Run the test predictions and display a side-by-side comparison table:
   ```python
   import pandas as pd
   from sklearn.model_selection import train_test_split
   from sklearn.tree import DecisionTreeClassifier

   df = pd.read_csv("data/titanic_practice.csv")
   df["is_female"] = (df["sex"] == "female").astype(int)
   X = df[["pclass", "is_female", "age", "fare"]]
   y = df["survived"]

   X_train, X_test, y_train, y_test = train_test_split(
       X, y, test_size=0.25, random_state=42, stratify=y
   )

   model = DecisionTreeClassifier(max_depth=4, random_state=42).fit(X_train, y_train)
   predictions = model.predict(X_test)

   comparison = pd.DataFrame({"Actual": y_test, "Predicted": predictions})
   comparison["Correct"] = comparison["Actual"] == comparison["Predicted"]
   print(comparison.head(10))
   print("\nTotal Correct:", comparison["Correct"].sum(), "out of", len(comparison))
   ```
3. Observe how each test passenger is evaluated.

## Expected Output or Observable Behaviour

Executing this script produces:
```text
    Actual  Predicted  Correct
79       0          0     True
34       0          0     True
62       0          0     True
65       0          0     True
30       0          0     True
29       1          1     True
7        1          1     True
35       0          0     True
11       1          0    False
17       1          0    False

Total Correct: 17 out of 23
```
Exactly 17 out of the 23 test passengers are classified correctly by the decision tree!

## Practical Exercises

**Exercise 2.1:** What is the data type and shape of `predictions`? Verify using `type(predictions)` and `predictions.shape`.  
**Exercise 2.2:** Calculate the overall percentage of correct predictions: `17 / 23 * 100`. Does this match the accuracy printed by `main.py`?  
**Exercise 2.3:** What happens if you pass a DataFrame with only 3 columns to `model.predict()`? Run an experiment and note the error.  

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Calling `model.predict(X_train)` and treating it as test evaluation | Evaluates the model on data it already memorized | Always pass unseen test features: `model.predict(X_test)` |
| Expecting decimal probabilities from `.predict()` | `.predict()` only outputs discrete class labels (0 or 1) | Use `.predict_proba()` if you need probability estimates |
| Changing column names or ordering between train and predict | Scikit-learn validates that features match the exact names and order seen during `.fit()` | Pass a DataFrame with identical schema |

## Best Practices and Security Considerations

- **Schema Validation:** In production inference services, always validate that incoming inference payloads contain all required feature columns with matching data types before calling `predict()`.
- **Batch vs. Single Inference:** Scikit-learn's `predict()` is optimized for vectorized batch inference across thousands of samples simultaneously.

## Summary

The `.predict()` method executes the inference phase of a trained classifier. It routes each sample in `X_test` down the decision tree hierarchy to arrive at a terminal leaf node, returning a 1D NumPy array of discrete predicted class labels (`0` or `1`). On the Titanic test set, the model correctly predicts 17 out of 23 passenger outcomes (~73.9%).

## Knowledge-check Questions

1. What does the `.predict()` method output for a binary classification problem?
2. How many elements are in the `predictions` array returned in `main.py`?
3. How many test passengers did the model classify correctly out of 23?
4. What happens if the columns passed to `predict()` do not match the columns passed to `fit()`?
5. What is the fundamental difference between `.fit()` and `.predict()`?

## References

- [Scikit-learn DecisionTreeClassifier Predict Method](https://scikit-learn.org/stable/modules/generated/sklearn.tree.DecisionTreeClassifier.html#sklearn.tree.DecisionTreeClassifier.predict)
- [NumPy Array Basics](https://numpy.org/doc/stable/user/quickstart.html)
- [Model Deployment and Inference Best Practices](https://scikit-learn.org/stable/modules/model_persistence.html)
