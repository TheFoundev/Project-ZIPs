# Lesson 04: Simulating New Passenger Scenarios (Inference on Unseen Data)

**Lesson ID:** lesson-04  
**Module:** module-04  
**Duration:** 15 minutes  

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Construct valid synthetic passenger observations using pandas DataFrames
- Match the exact feature schema (column names, ordering, and data types) expected by the trained model
- Trace why the project's made-up passenger (`pclass=3, is_female=1, age=25, fare=10.0`) receives a 0.0% survival probability
- Test hypothetical "what-if" counterfactual scenarios (e.g., upgrading passenger class or changing age)

## Prerequisites
- Lesson 01: Fitting the DecisionTreeClassifier on Training Data
- Lesson 02: Making Discrete Class Predictions with `predict()`
- Lesson 03: Estimating Probabilities with `predict_proba()`

## Concept Explanation

### The True Test of an AI Model: Interactive Simulation
The goal of building a machine learning model is not merely to score well on historical benchmarks, but to serve as a predictive engine for new, hypothetical scenarios.

In `main.py`, the script introduces a synthetic passenger scenario:
> *"A 25-year-old woman traveling in third class with a £10.00 ticket."*

Will she survive? To ask the Oracle, we must package her attributes into a format scikit-learn understands.

### Enforcing Schema Compatibility
A trained scikit-learn model remembers the names, count, and order of the features it saw during `.fit()`. If you pass a raw dictionary, a 1D list, or a DataFrame with different column names, scikit-learn will raise a warning or error.

To create a single valid passenger record:
```python
new_passenger = pd.DataFrame(
    [{"pclass": 3, "is_female": 1, "age": 25, "fare": 10.0}]
)
```
- It has shape `(1, 4)`: exactly 1 row (sample) and 4 columns.
- The column names (`pclass`, `is_female`, `age`, `fare`) match `model.feature_names_in_` perfectly.
- Categorical features are already encoded numerically (`is_female: 1` rather than `"female"`).

### Why Does the Made-Up Passenger Receive 0.0% Survival Probability?
At first glance, this prediction seems counter-intuitive: "Women and children first" was maritime protocol, so why does this young woman receive a **0.0%** chance of survival?

Let's trace her path through the learned rules:
1. `is female (1=yes) > 0.50`: Takes the female branch.
2. `age <= 37.50`: True (she is 25).
3. `passenger class > 1.50`: True (she is in 3rd class, `pclass = 3 > 1.50`).
4. `age > 23.50`: True (she is 25, which is $> 23.50$).
5. **Leaf reached:** `class: 0` (`value = [3, 0]`).

In the training dataset, every single 3rd-class female older than 23.5 years perished! The model learned this brutal historical reality: in 3rd class steerage, being female was not enough to overcome the barriers of physical distance from the boat deck for adult women.

## Relevant Code (from main.py, lines 57-63)

```python
    # A made-up passenger: third class, female, age 25, fare 10.
    new_passenger = pd.DataFrame(
        [{"pclass": 3, "is_female": 1, "age": 25, "fare": 10.0}]
    )
    probability = model.predict_proba(new_passenger)[0, 1]
    print(f"Made-up passenger survival probability: {probability:.1%}")
```

## Code Explanation
- **Lines 57-60**: Creates a 1-row DataFrame containing the 4 required feature values using a list of dictionaries.
- **Line 61**: Passes the DataFrame to `model.predict_proba()` and extracts the survival probability at index `[0, 1]`.
- **Lines 62-63**: Formats and prints the survival probability to the terminal (`0.0%`).

## Worked Example

**Problem:** What if we test a counterfactual scenario? Suppose this same 25-year-old woman had purchased a 1st-class luxury ticket (`pclass = 1`) with a £50 fare instead of a 3rd-class ticket. What would the model predict?

**Trace through the rules:**
1. `is female > 0.50`: Female branch.
2. `age <= 37.50`: True (age 25).
3. `passenger class <= 1.50`: True (`pclass = 1 <= 1.50`).
4. **Leaf reached:** `class: 1` (`value = [0, 8]`).
5. **Outcome:** Her survival probability leaps from **0.0% to 100.0%**!
This stark contrast powerfully illustrates the historical socioeconomic disparity revealed by the decision tree.

## Step-by-Step Student Instructions

1. Open Python in your terminal:
   ```bash
   python3
   ```
2. Create and run a counterfactual simulation script:
   ```python
   import pandas as pd
   from sklearn.model_selection import train_test_split
   from sklearn.tree import DecisionTreeClassifier

   df = pd.read_csv("data/titanic_practice.csv")
   df["is_female"] = (df["sex"] == "female").astype(int)
   X = df[["pclass", "is_female", "age", "fare"]]
   y = df["survived"]
   X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)
   model = DecisionTreeClassifier(max_depth=4, random_state=42).fit(X_train, y_train)

   # Baseline made-up passenger (3rd class female, 25)
   p_base = pd.DataFrame([{"pclass": 3, "is_female": 1, "age": 25, "fare": 10.0}])
   # Counterfactual 1: Upgrade to 1st class
   p_1st = pd.DataFrame([{"pclass": 1, "is_female": 1, "age": 25, "fare": 50.0}])
   # Counterfactual 2: Change age to 20 (younger)
   p_young = pd.DataFrame([{"pclass": 3, "is_female": 1, "age": 20, "fare": 10.0}])

   print("Baseline 3rd class (25yo female):", f"{model.predict_proba(p_base)[0,1]:.1%}")
   print("1st class upgrade  (25yo female):", f"{model.predict_proba(p_1st)[0,1]:.1%}")
   print("Younger 3rd class  (20yo female):", f"{model.predict_proba(p_young)[0,1]:.1%}")
   ```
3. Examine how slight modifications to passenger features flip the predicted outcome.

## Expected Output or Observable Behaviour

Executing the counterfactual test prints:
```text
Baseline 3rd class (25yo female): 0.0%
1st class upgrade  (25yo female): 100.0%
Younger 3rd class  (20yo female): 100.0%
```
For a 3rd-class female, being 20 years old instead of 25 placed her below the 23.5-year threshold, boosting her survival probability from 0.0% to 100.0%!

## Practical Exercises

**Exercise 4.1:** Create a synthetic passenger profile for an 8-year-old boy in 2nd class (`pclass=2, is_female=0, age=8, fare=20.0`). Predict his survival probability.  
**Exercise 4.2:** What error occurs if you pass `new_passenger = pd.DataFrame([{"class": 3, "sex": 1, "age": 25, "fare": 10.0}])`? Why does scikit-learn reject it?  
**Exercise 4.3:** In your own words, explain the ethical and historical implications of the model assigning 0% survival to adult 3rd-class women.  

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Passing a Python dictionary directly to `.predict()` | Scikit-learn estimators expect a 2D array or DataFrame | Wrap the dictionary in a `pd.DataFrame([dict])` |
| Using string values like `"fare": "$10"` or `"sex": "female"` | Strings cannot be evaluated against mathematical split thresholds | Supply clean numerical types (`fare: 10.0`, `is_female: 1`) |
| Passing feature names with typos or different capitalizations | Scikit-learn feature name validation fails with `ValueError: The feature names should match...` | Ensure column names match `model.feature_names_in_` exactly |

## Best Practices and Security Considerations

- **Robust Input Pipelines:** In production systems, write an explicit validation schema (e.g. using Pydantic or Cerberus) that verifies incoming user payloads before passing them to the model.
- **Explainability Reporting:** When returning predictions to end-users, return both the probability score and the specific decision rules that generated the score so users understand *why* the prediction was made.

## Summary

Inference on synthetic scenarios tests how well a machine learning model generalizes to hypothetical situations. By creating a 1-row pandas DataFrame that matches the exact column names and numeric data types of the training data, we can evaluate any passenger profile. For the project's made-up 25-year-old 3rd-class female, the tree uncovers the tragic historical reality that adult 3rd-class women suffered near-zero survival rates.

## Knowledge-check Questions

1. What 4 feature values define the made-up passenger in `main.py`?
2. What is the predicted survival probability for the made-up passenger?
3. Which decision split in the tree specifically causes her survival probability to drop to 0%?
4. What happens if her passenger class is changed from 3rd class to 1st class?
5. Why must new passenger data be packaged as a 2D DataFrame rather than a simple 1D Python dictionary?

## References

- [Scikit-learn Feature Names Validation Guide](https://scikit-learn.org/stable/modules/generated/sklearn.base.BaseEstimator.html)
- [Counterfactual Explanations in Machine Learning](https://christophm.github.io/interpretable-ml-book/counterfactual.html)
- [Pandas DataFrame from Records Documentation](https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.from_records.html)
