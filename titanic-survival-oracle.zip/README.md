# The Titanic Survival Oracle

## Overview
The **Titanic Survival Oracle** is an introductory supervised machine learning project that uses a **Decision Tree Classifier** to predict passenger survival on the Titanic. Using historical passenger records from `data/titanic_practice.csv` (located in `beginner-projects-main/AI-ML Beginners/projects/03_titanic_survival`), the model learns a series of intuitive if-then-else rules based on passenger class, sex, age, and ticket fare.

Unlike "black box" machine learning models, decision trees are fully interpretable. This project teaches students how to inspect the tree's logical branch points both as plain text rules and as graphical tree diagrams, and how to evaluate binary classification performance using metrics beyond raw accuracy.

## Real-World Use Case
In medicine, finance, and emergency management, high-stakes decisions require transparency. Decision trees are widely used in triage protocols (e.g., patient admission criteria), credit scoring approvals, and insurance underwriting because every prediction can be traced back to clear, explainable decision thresholds.

## Features (Implemented)
- **Data Ingestion**: Loads historical tabular data with pandas from `data/titanic_practice.csv`.
- **Feature Engineering**: Converts categorical text data (`sex`: `'male'`/`'female'`) into a binary numerical indicator (`is_female`: 0/1).
- **Stratified Partitioning**: Splits the 90 passenger records into 75% train (67 passengers) and 25% test (23 passengers) while preserving the exact ratio of survivors.
- **Tree Induction**: Trains a `DecisionTreeClassifier` with `max_depth=4` to learn optimal feature splits without severely overfitting.
- **Explainability**: Outputs learned rules in human-readable plain text using `export_text`.
- **Custom Passenger Inference**: Tests the trained model against a hypothetical passenger scenario using `predict_proba` to output survival probabilities.
- **Comprehensive Evaluation**: Computes classification accuracy (~73.9%), detailed precision/recall/F1 metrics via `classification_report`, and a 2x2 confusion matrix.
- **Multi-Format Export**: Generates `outputs/titanic_tree.png`, `outputs/confusion_matrix.png`, and `outputs/rules.txt`.

## Technology Stack
- **Python 3.8+**
- **pandas**: Data loading, cleaning, and tabular transformations
- **scikit-learn**: Model building, train-test splitting, metrics calculation, and tree export
- **matplotlib**: Rendering diagrams and confusion matrix plots headless via the `"Agg"` backend

## Project Structure (Actual)
```
03_titanic_survival/
├── main.py
├── data/
│   └── titanic_practice.csv
└── outputs/
    ├── confusion_matrix.png
    ├── rules.txt
    └── titanic_tree.png
```

## How It Works
1. **Reads CSV**: Loads `data/titanic_practice.csv` with columns `passenger_id`, `pclass`, `sex`, `age`, `fare`, `survived`.
2. **Transforms Features**: Encodes `sex == "female"` as binary 1/0 integer feature `is_female`. Drops raw string columns from the feature matrix `X = df[["pclass", "is_female", "age", "fare"]]` and sets `y = df["survived"]`.
3. **Splits Data**: Divides data using `train_test_split` with `test_size=0.25`, `random_state=42`, and `stratify=y`.
4. **Trains Classifier**: Fits `DecisionTreeClassifier(max_depth=4, random_state=42)` on the training set.
5. **Evaluates**: Predicts outcomes on the unseen test set, printing accuracy and the scikit-learn classification report.
6. **Infers on New Data**: Takes an arbitrary passenger profile (e.g. 3rd class female, age 25, fare 10.0) and predicts her survival probability.
7. **Saves Artifacts**: Renders and saves `titanic_tree.png` and `confusion_matrix.png`, and writes the text rules and metrics into `rules.txt`.

## Expected Output
When running `python3 main.py`, the terminal displays:
```text
============================================================
THE TITANIC SURVIVAL ORACLE
============================================================
Accuracy: 73.9%

Learned rules:

|--- is female (1=yes) <= 0.50
|   |--- age <= 18.50
...
|--- is female (1=yes) >  0.50
...

              precision    recall  f1-score   support

           0       0.81      0.81      0.81        16
           1       0.57      0.57      0.57         7

    accuracy                           0.74        23
   macro avg       0.69      0.69      0.69        23
weighted avg       0.74      0.74      0.74        23

Made-up passenger survival probability: 0.0%

Saved: outputs/titanic_tree.png, outputs/confusion_matrix.png, outputs/rules.txt
Try this: change max_depth to 2 or 5 and compare the rules.
```

## Security & Best Practices
- **Headless Execution**: Explicitly configures `matplotlib.use("Agg")` prior to importing `pyplot` to prevent crashes in CI/CD or remote server environments lacking display servers.
- **Data Leakage Prevention**: Separates test data prior to model fitting and uses stratification to ensure balanced class distributions.
- **Reproducibility**: Sets fixed `random_state=42` across the data partitioner and decision tree estimator.
