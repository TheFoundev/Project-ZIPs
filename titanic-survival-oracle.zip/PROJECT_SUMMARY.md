# Project Summary: The Titanic Survival Oracle

## Executive Summary
The Titanic Survival Oracle demonstrates supervised binary classification using decision trees in scikit-learn. Applied to a practice subset of historical Titanic passenger data, the project teaches fundamental machine learning concepts: converting real-world categorical attributes into numeric machine features, training rule-based models, preventing overfitting via tree depth control, interpreting hierarchical decision logic, and evaluating binary outcomes beyond simple accuracy.

## Core Metadata
- **Project Name:** The Titanic Survival Oracle
- **Directory Slug:** `titanic-survival-oracle`
- **Machine Learning Domain:** Supervised Binary Classification
- **Core Algorithm:** CART Decision Tree (`sklearn.tree.DecisionTreeClassifier`)
- **Key Parameters:** `max_depth=4`, `random_state=42`, `stratify=y`
- **Dataset:** `data/titanic_practice.csv` (90 passenger records)
- **Features Used:** `pclass` (int), `is_female` (int), `age` (float/int), `fare` (float)
- **Target Variable:** `survived` (0 = Did not survive, 1 = Survived)
- **Test Set Partition:** 25% (23 passengers; 16 non-survivors, 7 survivors)
- **Model Test Accuracy:** 73.9% (17 out of 23 test passengers predicted correctly)
- **Outputs Generated:**
  1. `outputs/titanic_tree.png`: Graphical visualization of the 4-layer decision tree
  2. `outputs/confusion_matrix.png`: Heatmap showing TP=4, TN=13, FP=3, FN=3
  3. `outputs/rules.txt`: Plain text representation of learned if/else conditions and summary metrics

## Curriculum Structure
The curriculum is organized into six progressive pedagogical modules:
1. **Module 01: Project Overview & Problem Understanding** — Historical context, binary classification formulation, decision tree intuition.
2. **Module 02: Data Loading & Feature Engineering** — CSV ingestion, categorical-to-numeric encoding (`is_female`), feature selection, and stratified train/test splitting.
3. **Module 03: Decision Tree Algorithm** — Splitting mechanics, Gini impurity, controlling overfitting via `max_depth`, and tree rendering.
4. **Module 04: Model Training & Predictions** — Fitting the tree, generating discrete predictions, calculating class probabilities (`predict_proba`), and predicting for hypothetical passengers.
5. **Module 05: Evaluation & Metrics** — Limitations of accuracy, precision, recall, F1-score, confusion matrix mechanics, and analyzing false negatives.
6. **Module 06: Complete Pipeline & Running** — End-to-end execution, artifact interpretation, hyperparameter experimentation, and extension challenges.

Each module includes 4 detailed lessons following the strict 15-section standard, a set of hands-on exercises, a 10-question multiple choice assessment, and a comprehensive answer key.
