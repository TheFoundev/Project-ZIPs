# Prerequisites

## Skills Required
- Basic Python syntax (functions, variables, dictionaries, lists, file handling)
- Basic understanding of tabular data (rows and columns)
- Basic familiarity with pandas DataFrames and boolean operations
- Basic mathematical concepts (percentages, probabilities between 0 and 1)
- Basic command line navigation (`cd`, running Python scripts)

## Tools Required
- Python 3.8+
- pip (Python package installer)
- Code editor or IDE (VS Code, Cursor, or PyCharm recommended)

## Packages
- pandas (Data manipulation and CSV reading)
- matplotlib (Plotting decision trees and confusion matrices)
- scikit-learn (Machine learning algorithms, data splitting, evaluation metrics)

## Knowledge to Review
- What is supervised machine learning?
- Difference between continuous numbers (regression) and categories (classification)
- What is a binary decision (Yes/No, 1/0)?
- Why models must be tested on unseen data to measure generalization
