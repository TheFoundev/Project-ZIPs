# Mentor Solution Guide: Titanic Survival Oracle

## Overview

This guide walks mentors through the expected reference implementation of the **Titanic Survival Oracle** final project. Students should follow `main.py` closely, adhering to established design patterns, reproducible splits, headless visualization practices, and defensive data handling. Mentors should verify that student code reproduces the identical numeric and architectural outputs.

---

## Solution Checkpoints & Reference Code

### Checkpoint 1: Headless Backend & Library Imports (Lines 12–25)
```python
import matplotlib
matplotlib.use("Agg")  # Must be invoked prior to importing pyplot
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pathlib import Path

from sklearn.tree import DecisionTreeClassifier, export_text, plot_tree
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report, ConfusionMatrixDisplay
```

**Mentor Verification Checklist:**
- `matplotlib.use("Agg")` strictly precedes `import matplotlib.pyplot as plt`.
- `pathlib.Path` is used instead of raw string manipulation or legacy `os.path`.
- All required Scikit-Learn modules (`tree`, `model_selection`, `metrics`) are imported without wildcard imports (`from sklearn... import *`).

**Common Student Errors:**
- Calling `matplotlib.use("Agg")` *after* importing `pyplot`, which triggers a backend switch warning or fails in headless CI environments.
- Importing `DecisionTreeClassifier` from `sklearn.linear_model` instead of `sklearn.tree`.

---

### Checkpoint 2: Path Anchoring & Output Directories (Lines 28–31)
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)
```

**Mentor Verification Checklist:**
- Base path is anchored to `__file__`, ensuring the script can be executed from any current working directory.
- `OUT.mkdir(exist_ok=True)` avoids race conditions or fatal errors if `outputs/` already exists.

---

### Checkpoint 3: Data Loading & Verification (Lines 33–40)
```python
df = pd.read_csv(DATA / "titanic_practice.csv")
print(f"Dataset shape: {df.shape}")
```

**Mentor Verification Checklist:**
- File loaded matches `data/titanic_practice.csv`.
- Loaded DataFrame has exactly 90 rows and 5 columns (`pclass`, `is_female`, `age`, `fare`, `survived`).

---

### Checkpoint 4: Feature Separation & Target Extraction (Lines 42–45)
```python
feature_cols = ["pclass", "is_female", "age", "fare"]
X = df[feature_cols]
y = df["survived"]
```

**Mentor Verification Checklist:**
- `X` is extracted using a list of column names, yielding a 2D DataFrame (shape: `(90, 4)`).
- `y` is extracted with a single string, yielding a 1D Series (shape: `(90,)`).
- No extraneous columns (such as index or passenger IDs) leak into `X`.

---

### Checkpoint 5: Stratified Train/Test Split (Lines 47–50)
```python
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)
```

**Mentor Verification Checklist:**
- `test_size=0.25` and `random_state=42` are set.
- `stratify=y` is explicitly supplied to maintain consistent survival proportions.
- Verification checks: `X_train.shape` is `(67, 4)` and `X_test.shape` is `(23, 4)`.

---

### Checkpoint 6: Model Training & Hyperparameter Control (Lines 52–56)
```python
model = DecisionTreeClassifier(max_depth=4, random_state=42)
model.fit(X_train, y_train)
```

**Mentor Verification Checklist:**
- `max_depth=4` is enforced (unconstrained trees will memorize data).
- `random_state=42` guarantees identical feature tie-breaking.
- Fitting is executed strictly on `X_train` and `y_train`.

---

### Checkpoint 7: Evaluation & Confusion Matrix Diagnostics (Lines 58–72)
```python
y_pred = model.predict(X_test)
acc = accuracy_score(y_test, y_pred)
cm = confusion_matrix(y_test, y_pred)
report = classification_report(y_test, y_pred)

print(f"Accuracy: {acc:.1%} ({sum(y_test == y_pred)}/{len(y_test)} correct)")
print("Confusion Matrix:")
print(cm)
```

**Expected Results:**
- Overall Accuracy: `73.9%` (17 / 23 correct).
- Confusion Matrix:
  ```
  [[13  3]
   [ 3  4]]
  ```
  - True Negatives (`y=0, ŷ=0`): 13
  - False Positives (`y=0, ŷ=1`): 3
  - False Negatives (`y=1, ŷ=0`): 3
  - True Positives (`y=1, ŷ=1`): 4

---

### Checkpoint 8: Custom Passenger Prediction (Lines 74–88)
```python
custom_passenger = pd.DataFrame([{
    "pclass": 3,
    "is_female": 1,
    "age": 25.0,
    "fare": 10.0
}])

pred_class = model.predict(custom_passenger)[0]
pred_probs = model.predict_proba(custom_passenger)[0]

print(f"Predicted class: {'Survived' if pred_class == 1 else 'Died'} ({pred_class})")
print(f"Survival probability: {pred_probs[1]:.1%}")
print(f"Mortality probability: {pred_probs[0]:.1%}")
```

**Expected Results:**
- Predicted Class: `0` (Died).
- Survival Probability: `0.0%` (Leaf node sample values: 3 Died, 0 Survived).
- Mortality Probability: `100.0%`.

---

### Checkpoint 9: Decision Rule Export (Lines 90–97)
```python
tree_rules = export_text(model, feature_names=list(X.columns))
rules_path = OUT / "rules.txt"
with open(rules_path, "w", encoding="utf-8") as f:
    f.write(tree_rules)
```

**Mentor Verification Checklist:**
- Rules are exported using `export_text`.
- File is saved inside `outputs/rules.txt` using context manager (`with open(...)`) with explicit UTF-8 encoding.

---

### Checkpoint 10: Visual Artifact Generation (Lines 99–130)
```python
# 1. Decision Tree Plot
fig, ax = plt.subplots(figsize=(16, 10))
plot_tree(
    model,
    feature_names=feature_cols,
    class_names=["Died", "Survived"],
    filled=True,
    rounded=True,
    fontsize=9,
    ax=ax
)
plt.title("Titanic Decision Tree (max_depth=4)", fontsize=14)
plt.savefig(OUT / "titanic_tree.png", dpi=150, bbox_inches="tight")
plt.close(fig)

# 2. Confusion Matrix Plot
fig, ax = plt.subplots(figsize=(6, 5))
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=["Died", "Survived"])
disp.plot(cmap="Blues", ax=ax, values_format="d")
plt.title("Confusion Matrix (Test Set, N=23)", fontsize=12)
plt.savefig(OUT / "confusion_matrix.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```

**Mentor Verification Checklist:**
- `plt.close(fig)` is called after every plot export.
- Both image files are present in `outputs/` and render clearly without clipped labels.

---

## Grading Rubric Reference

| Component | Max Points | Passing Threshold | Critical Failure Items |
| :--- | :--- | :--- | :--- |
| **Environment & Paths** | 10 pts | 8 pts | Hardcoded absolute paths; Agg backend not configured. |
| **Data Ingestion & Features** | 15 pts | 12 pts | Wrong feature subset; 1D array passed as X. |
| **Stratified Split** | 10 pts | 8 pts | Omitting `stratify=y`; non-deterministic split. |
| **Model Training** | 15 pts | 12 pts | Omitting `max_depth=4`; training on test split. |
| **Evaluation & Metrics** | 15 pts | 12 pts | Miscalculating confusion matrix quadrants or accuracy. |
| **Visualization Artifacts** | 15 pts | 12 pts | Missing PNGs; memory leaks from missing `plt.close()`. |
| **Text Rule Export** | 10 pts | 8 pts | Missing `rules.txt`; file not properly closed. |
| **Custom Passenger Prediction** | 10 pts | 8 pts | Inaccurate probabilities or failing to pass DataFrame. |
| **Analysis Report** | 5 pts | 4 pts | Superficial answers lacking ML rigor. |
| **Total** | **105 pts** | **85 pts** | |

---

## Mentor Defense Questions

1. **Why does stratifying the split matter for the Titanic dataset?**
   *Expected Answer:* Ground-truth survival is imbalanced (approx. 38% survived vs 62% died). Without stratification, random sampling could produce a test set with very few survival instances, yielding an unrepresentative estimate of minority class recall.

2. **If we increased `max_depth` to 10 or None, what would happen to training vs test accuracy?**
   *Expected Answer:* Training accuracy would approach 100% because leaves would isolate individual passenger quirks. However, test accuracy would plummet due to severe overfitting, as the tree would learn noise rather than generalizable demographic trends.

3. **In the confusion matrix, our model produced 3 False Negatives. In an emergency triage setting, why are False Negatives typically more dangerous than False Positives?**
   *Expected Answer:* A False Negative predicts that a passenger will not survive (or doesn't need a lifeboat), resulting in tragic denial of rescue resources. A False Positive predicts survival when they might perish, which is regrettable but triage policies prioritize minimizing fatal under-allocations (False Negatives).

4. **Why is a Decision Tree considered an 'interpretable' or 'white-box' model compared to a Deep Neural Network?**
   *Expected Answer:* Every inference is an explicit sequence of human-readable conditional if-else statements rooted in feature thresholds that can be audited, plotted, and exported (e.g., via `plot_tree` and `export_text`).
