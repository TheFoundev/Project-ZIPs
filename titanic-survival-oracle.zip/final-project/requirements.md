# Final Project Requirements: Titanic Survival Oracle

## Project Objective

Reproduce the complete **Titanic Survival Oracle** pipeline from scratch, following `main.py` exactly. Your implementation will load and inspect historical passenger data, perform supervised binary classification using a Scikit-Learn Decision Tree, evaluate model performance with accuracy and confusion matrices, export production-grade visual and textual diagnostics, and infer survival probabilities for a hypothetical passenger. Finally, you will write a reflective analytical report evaluating model behavior, bias, and algorithmic limitations.

---

## Functional Requirements

### 1. Environment & Path Architecture
- Configure the non-interactive Matplotlib backend (`matplotlib.use("Agg")`) prior to importing `pyplot` to ensure headless server execution.
- Utilize Python's standard `pathlib.Path` to anchor directory traversal relative to the executing script (`Path(__file__).resolve().parent`).
- Define base paths: `DATA = BASE / "data"` and `OUT = BASE / "outputs"`.
- Programmatically ensure the destination output directory exists using `OUT.mkdir(exist_ok=True)`.

### 2. Data Loading & Feature Separation
- Load `data/titanic_practice.csv` via `pandas.read_csv()`.
- Validate that the dataset consists of exactly 90 passenger records across relevant demographic columns (`pclass`, `is_female`, `age`, `fare`, `survived`).
- Extract the feature matrix `X` using the 4 explicit features `["pclass", "is_female", "age", "fare"]` as a 2D Pandas DataFrame (shape: `(90, 4)`).
- Extract the target vector `y` using column `"survived"` as a 1D Pandas Series (shape: `(90,)`).

### 3. Stratified Train/Test Split
- Perform an 75/25 split using `train_test_split()` from `sklearn.model_selection`.
- Set `test_size=0.25` and enforce deterministic partitioning using `random_state=42`.
- Apply `stratify=y` to preserve the ground-truth survival class distribution across both partitions (67 training samples, 23 test samples).

### 4. Decision Tree Instantiation & Training
- Instantiate a `DecisionTreeClassifier` from `sklearn.tree`.
- Constrain tree complexity by setting `max_depth=4` to balance expressive power and prevent catastrophic overfitting.
- Enforce deterministic feature split evaluation with `random_state=42`.
- Fit the model strictly on training data (`X_train`, `y_train`).

### 5. Evaluation & Performance Diagnostics
- Generate test predictions on unseen data: `y_pred = model.predict(X_test)`.
- Compute overall test accuracy via `accuracy_score(y_test, y_pred)` and format to 1 decimal place percentage (`73.9%`, representing 17 correct out of 23 test cases).
- Compute the confusion matrix via `confusion_matrix(y_test, y_pred)`, verifying 13 True Negatives, 4 True Positives, 3 False Positives, and 3 False Negatives.
- Compute precision, recall, and F1-score via `classification_report(y_test, y_pred)`.

### 6. Artifact Generation & Export
- **Tree Topology Plot (`outputs/titanic_tree.png`)**:
  - Render decision nodes using `sklearn.tree.plot_tree`.
  - Pass `feature_names=["Pclass", "Female", "Age", "Fare"]` and `class_names=["Died", "Survived"]`.
  - Enable `filled=True` and `rounded=True`.
  - Save figure at 150 DPI with `bbox_inches="tight"`.
- **Confusion Matrix Heatmap (`outputs/confusion_matrix.png`)**:
  - Render confusion matrix using `ConfusionMatrixDisplay`.
  - Use `display_labels=["Died", "Survived"]` and `cmap="Blues"`.
  - Save figure at 150 DPI with `bbox_inches="tight"`.
  - Guarantee memory cleanup with `plt.close("all")`.
- **Textual Decision Rules (`outputs/rules.txt`)**:
  - Export tree logic via `sklearn.tree.export_text(model, feature_names=list(X.columns))`.
  - Save to disk using standard UTF-8 encoding (`encoding="utf-8"`).

### 7. Custom Passenger Inference
- Construct a dedicated single-row DataFrame representing a custom passenger:
  - `pclass`: 3 (3rd class steerage)
  - `is_female`: 1 (Female)
  - `age`: 25 (25 years old)
  - `fare`: 10.0 ($10.00 ticket)
- Compute class prediction: `model.predict(new_passenger)[0]` (Expected: `0` / Died).
- Compute posterior class probabilities: `model.predict_proba(new_passenger)[0]` (Expected: `0.0%` survival probability, based on terminal leaf sample distribution `[3, 0]`).

### 8. Console Logging
- Emit cleanly formatted summary logs matching `main.py` specification, reporting training set size, test set size, test accuracy, confusion matrix breakdown, and custom passenger prediction.

---

## Non-Functional Requirements & Code Standards

1. **Deterministic Reproducibility**: Seed all pseudo-random processes (`random_state=42`).
2. **Data Leakage Immunity**: Feature engineering, normalization, and fitting must never access test data prior to evaluation.
3. **Robust File I/O**: Use context managers (`with open(...)`) and UTF-8 encoding for text outputs; explicitly close Matplotlib figures to avert process memory leaks.
4. **Defensive Validation**: Check input column types and null values prior to model ingestion.

---

## Submission Deliverables

Students must submit the following 4 deliverables:
1. `main.py`: Fully executable Python script meeting all functional criteria.
2. `outputs/`: Directory containing:
   - `titanic_tree.png`
   - `confusion_matrix.png`
   - `rules.txt`
3. `analysis_report.md`: A 1–2 page written analysis answering:
   - How does `max_depth=4` prevent overfitting compared to an unconstrained tree?
   - In maritime evacuation, is a False Negative or a False Positive more harmful? Explain why.
   - What does the root split (`is_female <= 0.5`) reveal about historical historical biases and maritime protocol during the disaster?
   - How might imputing missing values or adding passenger family size improve accuracy?
