# Architecture: The Titanic Survival Oracle

## Machine Learning Pipeline (from main.py)

1. **Environment & Headless Configuration**
   - Import `matplotlib` and set backend to `"Agg"` before importing `pyplot` to enable headless rendering without requiring a GUI window.
   - Configure path constants (`BASE`, `DATA`, `OUT`) via `pathlib.Path` and guarantee output folder existence with `mkdir(exist_ok=True)`.

2. **Data Ingestion**
   - Read `data/titanic_practice.csv` containing passenger demographic and ticket information.

3. **Feature Engineering & Selection**
   - Derive binary indicator column: `is_female = (df["sex"] == "female").astype(int)`.
   - Select predictive feature matrix `X = df[["pclass", "is_female", "age", "fare"]]`.
   - Isolate ground truth target label `y = df["survived"]` (0 = died, 1 = survived).

4. **Stratified Partitioning**
   - Split dataset with `train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)`.
   - `stratify=y` preserves the exact survival class distribution in both training (67 samples) and testing (23 samples) sets.

5. **Model Instantiation & Training**
   - Instantiate `DecisionTreeClassifier(max_depth=4, random_state=42)`.
   - Fit model on `X_train` and `y_train` using Gini impurity splits.

6. **Inference & Decision Logic Extraction**
   - Predict test set labels with `model.predict(X_test)`.
   - Extract plain-text rules with `export_text()`.
   - Calculate class probabilities for custom synthetic passenger (`pclass=3, is_female=1, age=25, fare=10.0`) with `predict_proba()`.

7. **Multi-Faceted Evaluation**
   - Compute overall classification accuracy (`accuracy_score`).
   - Generate detailed per-class precision, recall, and F1-score via `classification_report(zero_division=0)`.
   - Generate 2x2 confusion matrix with `confusion_matrix(y_test, predictions, labels=[0, 1])`.

8. **Artifact Generation & Persistence**
   - Plot decision tree diagram to `outputs/titanic_tree.png`.
   - Plot confusion matrix visualization to `outputs/confusion_matrix.png`.
   - Save text rules and summary statistics to `outputs/rules.txt`.

## Key Components

- **Dataset**: 90 historical passenger observations with 5 attributes (`pclass, sex, age, fare, survived`).
- **Algorithm**: CART Decision Tree Classifier with depth constraint (`max_depth=4`).
- **Splitting Criterion**: Gini Impurity (default in scikit-learn).
- **Stratification**: Guaranteed class balance preservation across splits.
- **Explainability**: Dual representation through text rules (`export_text`) and visual diagram (`plot_tree`).

## Data Flow Diagram

```
titanic_practice.csv (90 passengers)
             │
             ▼
   Pandas DataFrame
             │
             ├── Feature Engineering: df["sex"] == "female" → is_female (1/0)
             │
             ▼
      Feature Matrix X (pclass, is_female, age, fare) & Target y (survived)
             │
             ▼
   train_test_split(test_size=0.25, stratify=y, random_state=42)
             ├── Train (67 rows) ─────────────────► DecisionTreeClassifier(max_depth=4).fit()
             └── Test (23 rows)                    │
                     │                             ▼
                     └─────────────────────► model.predict(X_test)
                                                   │
             ┌─────────────────────────────────────┴──────────────────────────────────┐
             ▼                                     ▼                                  ▼
      Console Output                       Visual Plots                        File Outputs
- Accuracy (73.9%)                - outputs/titanic_tree.png            - outputs/rules.txt
- Plain text rules                - outputs/confusion_matrix.png
- Classification report
- Custom passenger probability
```
