# All Correct Answers for Assessments
Project: The Recipe Recommender
---

## Module 01: Project Overview & Recommendation Systems

**q1-01.** What is the primary objective of the Recipe Recommender project?
   **Correct Answer:** b. To find and suggest recipes with similar flavor profiles using nearest neighbors
   *Explanation:* The Recipe Recommender uses K-Nearest Neighbours to calculate similarity between dishes in a 5D flavor space, recommending meals that share similar taste profiles.

**q1-02.** How does the Recipe Recommender represent food so that an algorithm can evaluate similarity?
   **Correct Answer:** c. As numerical points in a 5-dimensional flavor space
   *Explanation:* The project represents recipes as numerical coordinate vectors across 5 flavor dimensions: spice, sweet, savory, sour, and veggie.

**q1-03.** Which of the following describes content-based filtering?
   **Correct Answer:** b. Recommending items based on the intrinsic attributes and features of the items themselves
   *Explanation:* Content-based filtering analyzes the descriptive features and intrinsic attributes of items (such as flavor, genre, or director) to recommend similar items.

**q1-04.** What is the 'cold start problem' in recommendation systems?
   **Correct Answer:** b. The difficulty of making recommendations for new items or users with zero historical interactions
   *Explanation:* The cold start problem occurs when a recommender system lacks sufficient data (ratings, reviews, or clicks) to make recommendations for brand-new users or brand-new catalog items.

**q1-05.** Why is content-based filtering particularly well-suited for the Recipe Recommender dataset?
   **Correct Answer:** b. The dataset has detailed sensory flavor scores for each recipe but no user rating history
   *Explanation:* Our dataset contains rich 5-attribute sensory profiles for each of the 24 dishes but zero user interaction logs. This makes content-based filtering the only viable technique.

**q1-06.** What are the five sensory dimensions used in the Recipe Recommender feature space?
   **Correct Answer:** c. spice, sweet, savory, sour, veggie
   *Explanation:* Line 27 of main.py explicitly defines FEATURES as ['spice', 'sweet', 'savory', 'sour', 'veggie'].

**q1-07.** In `recipes.csv`, Pancakes and Chocolate Cake share identical coordinates [1, 5, 2, 1, 1]. What is the Euclidean distance between them in this flavor space?
   **Correct Answer:** a. 0.0
   *Explanation:* Because all five coordinate components are identical (difference of 0 in each dimension), the Euclidean distance is sqrt(0^2 + 0^2 + 0^2 + 0^2 + 0^2) = 0.0.

**q1-08.** Why does `main.py` use `sklearn.neighbors.NearestNeighbors` instead of `sklearn.neighbors.KNeighborsClassifier`?
   **Correct Answer:** b. NearestNeighbors is an unsupervised algorithm that finds similar items rather than predicting a categorical target label
   *Explanation:* NearestNeighbors is an unsupervised learner used for spatial indexing and proximity querying. KNeighborsClassifier is a supervised classifier that requires class labels and votes on targets.

**q1-09.** Why is a train/test split (e.g. 75/25) omitted when training the model in `main.py`?
   **Correct Answer:** c. The model acts as an inventory search index over the catalog; omitting items would exclude them from being recommended
   *Explanation:* In catalog recommendation, the algorithm functions as a search and retrieval index over all available items. Withholding items in a test set would remove them from the catalog, preventing them from ever being suggested.

**q1-10.** What makes Project 18 fundamentally unique compared to all other projects in the 19 beginner AI/ML series?
   **Correct Answer:** b. It is the only project that uses unsupervised nearest neighbors for item retrieval rather than supervised prediction or classification
   *Explanation:* Project 18 is the only project in the 19 beginner series that implements an unsupervised nearest neighbor recommendation system rather than supervised classification or regression.

## Module 02: Data Exploration and the 5D Flavor Space

**q2-01.** What is the exact shape of the DataFrame loaded from `data/recipes.csv`?
   **Correct Answer:** b. (24, 7)
   *Explanation:* The dataset data/recipes.csv contains 24 data rows (recipes) and 7 columns: name, cuisine, spice, sweet, savory, sour, veggie.

**q2-02.** Which standard Python library is used in `main.py` for managing filesystem paths?
   **Correct Answer:** b. pathlib
   *Explanation:* main.py imports Path from pathlib on line 11, constructing BASE = Path(__file__).resolve().parent.

**q2-03.** What integer scale is used to score each of the five flavor dimensions in `recipes.csv`?
   **Correct Answer:** b. 1 to 5 integer ratings
   *Explanation:* Each of the five flavor dimensions in data/recipes.csv is rated on an integer intensity scale from 1 (minimal) to 5 (intense).

**q2-04.** What does a score of 1 in the `spice` dimension represent in our dataset?
   **Correct Answer:** c. Mild or zero perceptible chili heat
   *Explanation:* On our 1 to 5 scale, 1 indicates minimal or zero perceptible heat (such as in Chocolate Cake or Pancakes).

**q2-05.** Which flavor dimension has the highest average score across the 24 recipes in `recipes.csv`?
   **Correct Answer:** c. savory
   *Explanation:* The 'savory' column has an average of ~3.88, the highest of all dimensions, because most of the dishes in the catalog are hearty main courses.

**q2-06.** In `recipes.csv`, which pair of recipes from different cuisines share the exact same flavor coordinates [4, 1, 4, 3, 2]?
   **Correct Answer:** b. Taco (Mexican) and Kimchi Fried Rice (Korean)
   *Explanation:* Both Taco (Mexican) and Kimchi Fried Rice (Korean) have spice=4, sweet=1, savory=4, sour=3, veggie=2 in recipes.csv.

**q2-07.** Why are `name` and `cuisine` excluded from the `FEATURES` list in `main.py`?
   **Correct Answer:** b. Because they are metadata strings, whereas distance algorithms require numerical coordinate features
   *Explanation:* name and cuisine are text metadata used for identification and filtering. Distance algorithms require numeric coordinates, so only the 5 flavor ratings are included in FEATURES.

**q2-08.** What is the return type and dimension of `df[FEATURES]` when `FEATURES` is a list of 5 column names?
   **Correct Answer:** b. A 2D pandas DataFrame with shape (24, 5)
   *Explanation:* Subsetting a DataFrame with a list of column names (double brackets) returns a 2D DataFrame containing 24 rows and 5 columns.

**q2-09.** What error will scikit-learn raise if you pass a 1D Series of shape (24,) directly into `StandardScaler.fit_transform()`?
   **Correct Answer:** b. ValueError: Expected 2D array, got 1D array instead
   *Explanation:* Scikit-learn strictly validates input shapes. Passing a 1D array of shape (n,) causes a ValueError stating that a 2D array of shape (n, 1) or (n, m) was expected.

**q2-10.** If a user wants to find dishes from any cuisine *other* than their current dish's cuisine, which pandas operation correctly isolates those candidates?
   **Correct Answer:** b. df[df['cuisine'] != base['cuisine']]
   *Explanation:* The != operator checks for inequality, filtering the DataFrame to only include recipes whose cuisine does not match the base recipe's cuisine.

## Module 03: The NearestNeighbors Algorithm & Distance Metrics

**q3-01.** What does `StandardScaler` do to a numeric feature column?
   **Correct Answer:** b. Subtracts the mean and divides by standard deviation, giving mean=0 and std=1
   *Explanation:* StandardScaler computes z = (x - mean) / std, centering the distribution around mean=0 and scaling to unit variance (std=1).

**q3-02.** What is the formula for Euclidean distance between two vectors u and v in 5 dimensions?
   **Correct Answer:** a. sqrt(sum((u_i - v_i)^2))
   *Explanation:* Euclidean distance is the square root of the sum of squared coordinate differences: sqrt(sum((u_i - v_i)^2)).

**q3-03.** Which scikit-learn estimator is used in `main.py` for spatial indexing and neighbor search?
   **Correct Answer:** c. sklearn.neighbors.NearestNeighbors
   *Explanation:* main.py line 19 imports NearestNeighbors from sklearn.neighbors, creating an unsupervised spatial index with model = NearestNeighbors(n_neighbors=6, metric='euclidean').

**q3-04.** Why must features be standardized before computing Euclidean distance?
   **Correct Answer:** b. To prevent features with larger scales or variances from dominating distance calculations
   *Explanation:* Distance metrics treat numerical differences equally across dimensions. If features have unequal variances or scales, larger-scale dimensions artificially dominate neighbor queries.

**q3-05.** What is the key functional difference between `NearestNeighbors.fit(X)` and `KNeighborsClassifier.fit(X, y)`?
   **Correct Answer:** b. NearestNeighbors is unsupervised and requires no target labels y
   *Explanation:* NearestNeighbors is unsupervised and only takes feature matrix X during fit(X). KNeighborsClassifier is supervised and requires target array y to learn classification boundaries.

**q3-06.** What method is called on a fitted `NearestNeighbors` model to retrieve the closest points?
   **Correct Answer:** b. model.kneighbors()
   *Explanation:* NearestNeighbors provides kneighbors(X), which returns the distances and indices of the closest indexed points.

**q3-07.** What does Manhattan distance ($L_1$ norm) compute between two coordinate vectors?
   **Correct Answer:** b. The sum of the absolute differences along each dimension
   *Explanation:* Manhattan distance (L1 norm) sums the absolute coordinate differences across all dimensions, representing grid-like displacement.

**q3-08.** Why does `main.py` fit the `NearestNeighbors` model on all 24 recipes without a train/test split?
   **Correct Answer:** b. Because recommendation engines index the available catalog; withholding items removes them from being recommended
   *Explanation:* Recommendation retrieval functions as an inventory index. Withholding items in a test split would remove them from the index, preventing them from being discovered or recommended to users.

**q3-09.** When querying a single recipe's vector from `scaled_features[index]`, why must `.reshape(1, -1)` be called before passing to `model.kneighbors()`?
   **Correct Answer:** b. Scikit-learn estimators require a 2D array of shape (n_queries, n_features), not a 1D vector
   *Explanation:* Scikit-learn expects 2D arrays of shape (n_samples, n_features). A single query vector of shape (5,) must be reshaped using .reshape(1, -1) to create shape (1, 5).

**q3-10.** If two recipes have identical values on 4 dimensions and differ by 3.0 on the 5th dimension after scaling, what is their Euclidean distance?
   **Correct Answer:** b. 3.0
   *Explanation:* The differences are [0, 0, 0, 0, 3.0]. The Euclidean distance is sqrt(0^2 + 0^2 + 0^2 + 0^2 + 3^2) = sqrt(9) = 3.0.

## Module 04: Making Recommendations & Calculating Similarity

**q4-01.** Why does `main.py` request `n + 1` neighbors from `model.kneighbors()` when the user asks for `n` recommendations?
   **Correct Answer:** b. Because the query recipe itself will be returned as neighbor 0 at distance 0.0 and must be excluded
   *Explanation:* Because the query recipe exists in the training set, its distance to itself is 0.0, placing it at position 0. Requesting n + 1 neighbors allows discarding the self-match while retaining n distinct items.

**q4-02.** What formula is used in `main.py` to convert Euclidean distance d into a similarity score?
   **Correct Answer:** a. similarity = 1 / (1 + distance)
   *Explanation:* Line 49 of main.py explicitly defines similarity as 1 / (1 + distance), mapping distances from [0, inf) to (0, 1].

**q4-03.** What does a similarity score of 1.000 indicate in the Recipe Recommender?
   **Correct Answer:** b. The recipes share identical coordinates across all 5 flavor dimensions
   *Explanation:* A similarity of 1.000 occurs when d = 0, meaning the two items share identical coordinates across all feature dimensions (e.g. Chocolate Cake and Pancakes).

**q4-04.** How does `recommend()` handle case differences when a user passes `'sPiCy RaMeN'`?
   **Correct Answer:** b. It converts both the query string and dataset names to lowercase with `.str.lower() == recipe_name.lower()`
   *Explanation:* main.py line 38 uses df.index[df['name'].str.lower() == recipe_name.lower()], normalizing both sides to lowercase.

**q4-05.** Which slice syntax correctly discards the 0th element (the self-match) in the returned distances array?
   **Correct Answer:** b. distances[0][1:]
   *Explanation:* distances[0][1:] accesses the first query's distances array and slices from index 1 to the end, omitting index 0.

**q4-06.** What happens to the similarity score $S = \frac{1}{1 + d}$ as the distance $d$ becomes very large ($d \to \infty$)?
   **Correct Answer:** b. It approaches 0.0
   *Explanation:* As d -> inf, the denominator 1 + d grows infinitely large, causing 1 / (1 + d) to asymptotically approach 0.0.

**q4-07.** What is the primary motivation for introducing the 'Surprise Me' feature in `main.py`?
   **Correct Answer:** b. To combat filter bubbles and introduce serendipitous discovery of other cuisines
   *Explanation:* The 'Surprise Me' feature injects serendipity and cross-cultural exploration, helping users discover items outside their current culinary category.

**q4-08.** Why does `surprise_me()` specify `random_state=7` when calling `.sample(1)`?
   **Correct Answer:** b. To make the random selection reproducible and deterministic across script executions
   *Explanation:* Setting random_state ensures that the pseudo-random number generator initializes with the same seed, producing identical sample results on every run.

**q4-09.** What dish is selected by `surprise_me('Margherita Pizza')` in `main.py`?
   **Correct Answer:** b. Chicken Tikka Masala (Indian)
   *Explanation:* Executing surprise_me('Margherita Pizza') with random_state=7 samples Chicken Tikka Masala (Indian).

**q4-10.** If a query vector has a distance of $d = 1.058$ to Chicken Tikka Masala, what is its similarity score rounded to 2 decimal places?
   **Correct Answer:** a. 0.49
   *Explanation:* 1 / (1 + 1.058) = 1 / 2.058 = 0.4859, which rounds to 0.49.

## Module 05: Visualizing Recommendations and Flavor Clusters

**q5-01.** Which Matplotlib backend is explicitly configured in `main.py`?
   **Correct Answer:** c. Agg
   *Explanation:* main.py line 15 explicitly sets matplotlib.use('Agg') to enable non-interactive headless PNG rendering.

**q5-02.** Why must `matplotlib.use('Agg')` be executed BEFORE `import matplotlib.pyplot as plt`?
   **Correct Answer:** b. Importing pyplot initializes and locks in a default backend; setting Agg beforehand guarantees headless configuration
   *Explanation:* Importing pyplot triggers default backend initialization. Calling matplotlib.use('Agg') beforehand ensures that pyplot initializes directly with the headless Agg engine.

**q5-03.** Which Matplotlib function is used to create horizontal bar charts?
   **Correct Answer:** b. ax.barh()
   *Explanation:* ax.barh() is the official Matplotlib method for rendering horizontal bar charts.

**q5-04.** Why does `main.py` reverse the series with `[::-1]` when calling `ax.barh(names[::-1], similarity[::-1])`?
   **Correct Answer:** b. Because ax.barh plots from bottom to top; reversing ensures the highest similarity appears at the top
   *Explanation:* Matplotlib plots barh items from the bottom (y=0) upwards. Reversing the series with [::-1] ensures the top-ranked item appears at the top of the chart.

**q5-05.** What hex color string is applied to the bars in `main.py`?
   **Correct Answer:** a. '#e67e22' (orange)
   *Explanation:* Line 78 specifies color='#e67e22', a warm culinary orange color.

**q5-06.** Why is `ax.set_xlim(0, 1)` set on the horizontal similarity chart?
   **Correct Answer:** a. Because similarity scores range between 0 and 1; fixing the axis provides an absolute visual benchmark
   *Explanation:* Setting xlim(0, 1) anchors the similarity axis across the full theoretical domain (0 to 1), providing viewers with an accurate absolute sense of match strength.

**q5-07.** What is a 2D projection in data visualization?
   **Correct Answer:** b. Plotting multi-dimensional data onto a 2-dimensional plane by selecting two specific feature axes
   *Explanation:* A 2D projection plots high-dimensional vectors onto a 2-dimensional plane by selecting two designated coordinate axes (e.g. Sweet vs. Spice), holding or collapsing others.

**q5-08.** What does `plt.close(fig)` accomplish in `main.py`?
   **Correct Answer:** b. Destroys the figure canvas in memory, preventing memory leaks
   *Explanation:* plt.close(fig) frees the internal GUI/raster canvas buffers associated with the figure, preventing memory accumulation across repeated executions.

**q5-09.** What DPI resolution is specified in `fig.savefig(OUT / 'similarity_scores.png', dpi=150, ...)`?
   **Correct Answer:** c. 150 DPI
   *Explanation:* main.py line 84 specifies dpi=150, producing crisp raster resolution for modern displays.

**q5-10.** What does `bbox_inches='tight'` do when saving a Matplotlib figure?
   **Correct Answer:** b. Automatically crops extraneous whitespace around figure margins so labels are not cut off
   *Explanation:* bbox_inches='tight' computes the bounding box around all plotted elements (including titles and tick labels) and crops excess white space so labels are never clipped.

## Module 06: Running the Pipeline & Production Recommender Extensions

**q6-01.** What two artifact files are generated in the `outputs/` directory when running `main.py`?
   **Correct Answer:** b. similarity_scores.png and recommendations.txt
   *Explanation:* main.py line 95 explicitly prints 'Saved: outputs/similarity_scores.png, outputs/recommendations.txt', which are the two generated output artifacts.

**q6-02.** What does `main.py` print at the very end of execution as a learning challenge?
   **Correct Answer:** b. 'Try this: add 10 recipes you actually like and rerun the recommendations.'
   *Explanation:* Line 96 prints the curriculum challenge: 'Try this: add 10 recipes you actually like and rerun the recommendations.'

**q6-03.** How many total columns must be present in `data/recipes.csv` when adding custom recipes?
   **Correct Answer:** c. 7 columns
   *Explanation:* data/recipes.csv requires exactly 7 columns: name, cuisine, spice, sweet, savory, sour, veggie.

**q6-04.** What is the new-item cold start problem in recommender systems?
   **Correct Answer:** a. The inability of collaborative filtering to recommend new items that have received zero user ratings
   *Explanation:* The new-item cold start occurs when a brand-new item enters the system with zero historical ratings, causing collaborative filtering algorithms to be completely blind to it.

**q6-05.** Why does content-based filtering successfully solve the new-item cold start problem?
   **Correct Answer:** b. Because it calculates recommendations from intrinsic item features (flavor scores) rather than user ratings
   *Explanation:* Content-based filtering relies on the descriptive attributes (flavor profiles) of items. As soon as attributes are logged, the item is instantly positioned in flavor space and can be recommended without waiting for user ratings.

**q6-06.** What is an effective strategy for handling the *new-user* cold start problem in a content-based food application?
   **Correct Answer:** b. Present an onboarding questionnaire asking the user to pick 3 favorite dishes or adjust flavor sliders
   *Explanation:* Onboarding questionnaires capture initial taste preferences directly from new users, establishing an initial query vector that powers content-based recommendations immediately.

**q6-07.** What is a 'hybrid' recommendation system?
   **Correct Answer:** b. An architecture that combines content-based filtering with collaborative filtering techniques
   *Explanation:* A hybrid recommender blends multiple algorithmic paradigms (typically content-based attribute matching and collaborative user-item interaction filtering) to maximize accuracy and coverage.

**q6-08.** In a modern two-stage recommendation architecture, what are the two sequential stages?
   **Correct Answer:** b. Candidate Retrieval (Candidate Generation) followed by Ranking and Scoring
   *Explanation:* Modern industrial recommenders use Candidate Retrieval (fast nearest-neighbor search retrieving hundreds of candidates) followed by Ranking (deep learning scoring the candidates for the specific user).

**q6-09.** When scaling nearest neighbor search to millions of items in production, what specialized library or technology is commonly used?
   **Correct Answer:** b. Approximate Nearest Neighbor (ANN) vector databases like FAISS, Milvus, or HNSWLib
   *Explanation:* Approximate Nearest Neighbor (ANN) vector search indexes (such as Meta's FAISS, HNSWLib, Milvus, and Pinecone) enable sub-millisecond retrieval across millions or billions of multi-dimensional vectors.

**q6-10.** When evaluating an arbitrary query vector entered by a user that does NOT exist in the indexed training catalog, why should neighbor index 0 NOT be discarded?
   **Correct Answer:** b. Because the query vector is not in the dataset, so neighbor 0 is a genuine catalog dish, not a self-match
   *Explanation:* When querying with a custom user flavor vector that is not part of the training catalog, the closest item in the catalog is a genuine recommendation with distance > 0. It is NOT a self-match, so index 0 must be kept.
