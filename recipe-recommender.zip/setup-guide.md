# Setup Guide

This guide will walk you through setting up your environment, running the Recipe Recommender project, and verifying all outputs.

## Step 1: Navigate to the Project Directory
Open your terminal and change directory to the project folder:
```bash
cd "beginner-projects-main/AI-ML Beginners/projects/18_recipe_recommender"
```

## Step 2: Set Up a Virtual Environment (Recommended)
Creating an isolated virtual environment prevents dependency conflicts with other projects:
```bash
# Create a virtual environment named .venv
python3 -m venv .venv

# Activate the virtual environment:
# On Linux / macOS:
source .venv/bin/activate
# On Windows:
.venv\Scripts\activate
```

## Step 3: Install Required Dependencies
Install the required packages using `pip`:
```bash
pip install pandas numpy matplotlib scikit-learn
```

Alternatively, you can create a `requirements.txt` file:
```txt
pandas>=1.3.0
numpy>=1.20.0
matplotlib>=3.4.0
scikit-learn>=1.0.0
```
And install with:
```bash
pip install -r requirements.txt
```

## Step 4: Verify Project Files and Dataset
Confirm that `main.py` and the dataset `data/recipes.csv` are present:
```bash
ls -la
ls -la data/
```
You should see `recipes.csv` inside `data/` containing 24 distinct recipes with flavor profiles across 5 dimensions (`spice, sweet, savory, sour, veggie`).

## Step 5: Run the Project
Execute the main script:
```bash
python main.py
```

## Step 6: Verify Outputs
Upon completion, verify the console output and the generated artifacts in the `outputs/` folder:
1. **Console Output**: Displays nearest neighbor recommendations for Margherita Pizza, Spicy Ramen, and Chocolate Cake, along with a serendipitous "Surprise me" recommendation.
2. **`outputs/similarity_scores.png`**: A horizontal bar chart illustrating recipes most similar to Spicy Ramen.
3. **`outputs/recommendations.txt`**: A formatted text file logging the recommendations and similarity scores.
