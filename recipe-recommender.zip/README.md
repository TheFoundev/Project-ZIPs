# The Recipe Recommender: Educational Project Guide

## 1. Project Overview
The **Recipe Recommender** is an interactive machine learning project that demonstrates how to build an unsupervised, content-based recommendation engine. Recipes are modeled as points in a 5-dimensional flavor space consisting of `spice`, `sweet`, `savory`, `sour`, and `veggie` attributes. Using scikit-learn's `NearestNeighbors` algorithm, the engine calculates the geometric distance between flavor profiles to recommend culinary matches that share similar taste characteristics.

## 2. Business Problem & Motivation
In digital food, music, and movie services, users often ask: *"If I enjoyed this, what should I try next?"*
While popular recommendation engines often analyze millions of user ratings (collaborative filtering), new or specialized items often have zero ratings—a scenario known as the **cold start problem**. Content-based filtering solves this by recommending items based solely on their intrinsic attributes. In the culinary domain, analyzing flavor profiles allows an AI system to understand why someone who loves *Spicy Ramen* might also appreciate *Chicken Tikka Masala* or *Kimchi Fried Rice*.

## 3. Technology Stack
- **Python 3.8+**
- **pandas**: Data ingestion and DataFrame operations
- **NumPy**: Vector reshaping and mathematical transformations
- **scikit-learn**: `StandardScaler` for normalization and `NearestNeighbors` for spatial querying
- **matplotlib**: Data visualization using the headless `Agg` backend

## 4. Key Machine Learning Concepts
- **Unsupervised Learning**: Unlike classification or regression, there are no target labels $y$ to predict. The algorithm indexes data points in a coordinate space to answer proximity queries.
- **Multi-Dimensional Feature Space**: Treating continuous sensory scores as coordinate vectors in $\mathbb{R}^5$.
- **Standardization (`StandardScaler`)**: Normalizing variables to zero mean and unit variance so no single taste dimension artificially dominates distance calculations.
- **Euclidean Distance**: Measuring spatial separation:
  $$d(\mathbf{u}, \mathbf{v}) = \sqrt{\sum_{i=1}^5 (u_i - v_i)^2}$$
- **Similarity Mapping**: Transforming unbounded distance $[0, \infty)$ into an intuitive bounded similarity metric $(0, 1]$:
  $$\text{similarity} = \frac{1}{1 + \text{distance}}$$
- **Serendipity vs. Filter Bubble**: Balancing high-similarity suggestions with exploratory cross-cuisine discovery.

## 5. Dataset Description
The dataset `data/recipes.csv` contains 24 diverse international recipes with 7 columns:
- `name` (string): The common name of the dish (e.g., Margherita Pizza, Spicy Ramen, Pad Thai).
- `cuisine` (string): Cultural culinary category (Italian, Japanese, Indian, Thai, Mexican, etc.).
- `spice` (int 1-5): Heat level.
- `sweet` (int 1-5): Sugar / sweetness intensity.
- `savory` (int 1-5): Umami / saltiness intensity.
- `sour` (int 1-5): Acidity level.
- `veggie` (int 1-5): Freshness / plant-based flavor presence.

## 6. Project Architecture
The project pipeline follows a clean, sequential flow:
1. Load `data/recipes.csv` into a pandas DataFrame.
2. Extract the 5 flavor columns into a numerical feature matrix.
3. Standardize features with `StandardScaler()`.
4. Initialize and fit `NearestNeighbors(n_neighbors=6, metric="euclidean")` on all scaled data.
5. Define `recommend(recipe_name, n=3)` to query neighbor vectors, exclude self-match, and compute similarity.
6. Define `surprise_me(recipe_name)` to sample an alternative cuisine recommendation.
7. Output formatted recommendations to the console.
8. Generate a horizontal bar chart (`outputs/similarity_scores.png`) for "Spicy Ramen".
9. Save full recommendations to `outputs/recommendations.txt`.

## 7. Step-by-Step Setup & Installation
```bash
# 1. Navigate to project root
cd "beginner-projects-main/AI-ML Beginners/projects/18_recipe_recommender"

# 2. Install dependencies
pip install pandas numpy matplotlib scikit-learn

# 3. Run the script
python main.py
```

## 8. Expected Console Output
```text
============================================================
THE RECIPE RECOMMENDER
============================================================

If you like Margherita Pizza, try:
  Lasagna                (Italian       ) similarity 0.52
  Paella                 (Spanish       ) similarity 0.46
  Mushroom Risotto       (Italian       ) similarity 0.42

If you like Spicy Ramen, try:
  Chicken Tikka Masala   (Indian        ) similarity 0.49
  Kimchi Fried Rice      (Korean        ) similarity 0.40
  Taco                   (Mexican       ) similarity 0.40

If you like Chocolate Cake, try:
  Pancakes               (American      ) similarity 1.00
  Blueberry Muffin       (American      ) similarity 0.46
  Butter Chicken         (Indian        ) similarity 0.22

Surprise me: Chicken Tikka Masala (Indian)

Saved: outputs/similarity_scores.png, outputs/recommendations.txt
Try this: add 10 recipes you actually like and rerun the recommendations.
```

## 9. Visual Artifacts
The script produces `outputs/similarity_scores.png`, a crisp horizontal bar chart illustrating the top 5 most similar recipes to *Spicy Ramen*. Notice how dishes with similar bold, spicy, savory profiles (Chicken Tikka Masala, Kimchi Fried Rice, Taco) score highest.

## 10. Understanding the Codebase
- **Lines 1-9**: Project description and docstrings.
- **Lines 11-20**: Imports, including `matplotlib.use("Agg")` and scikit-learn estimators.
- **Lines 22-25**: Path configuration with `pathlib.Path`.
- **Line 27**: `FEATURES` definition list.
- **Lines 31-35**: Data loading, standardization, and model fitting.
- **Lines 37-52**: `recommend()` function implementation.
- **Lines 54-61**: `surprise_me()` function implementation.
- **Lines 65-72**: Executing recommendations across diverse query dishes.
- **Lines 75-85**: Horizontal bar chart construction.
- **Lines 87-94**: File persistence for text output.

## 11. Common Pitfalls & Debugging Tips
- **Forgetting to Exclude Self-Match**: Asking for $k$ neighbors returns the query point itself at index 0. Always slice `[1:]` to recommend *other* items.
- **Omitting Feature Scaling**: Unscaled features allow high-variance dimensions to overshadow subtle flavor distinctions.
- **Confusing NearestNeighbors with KNeighborsClassifier**: `NearestNeighbors` is an unsupervised index without labels; `KNeighborsClassifier` requires target labels for classification.
- **Dimension Mismatch in kneighbors()**: Scikit-learn expects 2D inputs. Single query vectors must be reshaped using `.reshape(1, -1)`.

## 12. Best Practices
- Use pathlib for robust cross-platform path resolution.
- Always set headless Matplotlib backends before importing `pyplot` when writing automated or server-side scripts.
- Wrap model queries with input validation (e.g., case-insensitive name matching) to provide informative error messages when an item is not found.

## 13. Practical Exercises for Students
1. Add 5 of your favorite homemade meals to `data/recipes.csv` and re-run `main.py`.
2. Modify `main.py` to test different distance metrics, such as `metric="manhattan"` or `metric="cosine"`.
3. Experiment with custom similarity scaling functions, such as exponential decay: $e^{-d}$.

## 14. Real-World Applications & Next Steps
Content-based recommendation engines power music genre matching, news article grouping, e-commerce catalog search, and culinary pairings. To scale this concept to production, systems incorporate real-time user click logs, matrix factorization, and hybrid collaborative filtering.

## 15. Curriculum Navigation
Explore the 6 structured learning modules in the `modules/` directory:
- **Module 01**: Project Overview & Recommendation Systems
- **Module 02**: Data Exploration & Flavor Space
- **Module 03**: NearestNeighbors Algorithm & Distance Metrics
- **Module 04**: Making Recommendations & Calculating Similarity
- **Module 05**: Visualization & Flavor Space Projections
- **Module 06**: Running the Pipeline & Advanced Recommender Extensions
