# Architecture: The Recipe Recommender

## Overview
The Recipe Recommender implements an **unsupervised content-based recommendation engine** built upon K-Nearest Neighbours indexing in a multi-dimensional continuous attribute space. Unlike supervised classifiers that predict categorical labels, this system models culinary items as spatial vectors and evaluates relative geometric proximity.

```
+-----------------------------------------------------------------------------------+
|                              RECIPE RECOMMENDER PIPELINE                          |
+-----------------------------------------------------------------------------------+
|                                                                                   |
|  +---------------------+                                                          |
|  |   data/recipes.csv  | (24 recipes x 7 columns: name, cuisine, 5 flavor dims)   |
|  +----------+----------+                                                          |
|             |                                                                     |
|             v                                                                     |
|  +---------------------+                                                          |
|  |  pandas DataFrame   | Metadata (name, cuisine) + Numerical Features            |
|  +----------+----------+                                                          |
|             |                                                                     |
|             v                                                                     |
|  +---------------------+                                                          |
|  |   StandardScaler    | Normalizes 5D flavor vectors (zero mean, unit variance)  |
|  +----------+----------+                                                          |
|             |                                                                     |
|             v                                                                     |
|  +---------------------+                                                          |
|  |  NearestNeighbors   | Spatial index fitted on ALL scaled recipe vectors        |
|  | (metric=euclidean)  | (Unsupervised: no labels, no train/test split)           |
|  +----------+----------+                                                          |
|             |                                                                     |
|             +---------------------------------+                                   |
|             |                                 |                                   |
|             v                                 v                                   |
|  +---------------------+           +---------------------+                        |
|  |  recommend() Engine |           | surprise_me() Engine|                        |
|  | - kneighbors(k=n+1) |           | - Filter: cuisine   |                        |
|  | - Skip self (idx 0) |           |   != base cuisine   |                        |
|  | - sim = 1 / (1 + d) |           | - Sample (seed=7)   |                        |
|  +----------+----------+           +----------+----------+                        |
|             |                                 |                                   |
|             +----------------+----------------+                                   |
|                              |                                                    |
|                              v                                                    |
|                   +---------------------+                                         |
|                   |   Outputs & Visuals |                                         |
|                   | - Console Display   |                                         |
|                   | - similarity_scores |                                         |
|                   |   .png (barh)       |                                         |
|                   | - recommendations   |                                         |
|                   |   .txt              |                                         |
|                   +---------------------+                                         |
+-----------------------------------------------------------------------------------+
```

## Architectural Components

### 1. Data Ingestion & Representation
- **Source**: `data/recipes.csv` loaded into a pandas DataFrame.
- **Feature Space**: Five continuous taste dimensions: `spice`, `sweet`, `savory`, `sour`, `veggie`.
- **Item Representation**: Each recipe $i$ is represented as a point $\mathbf{x}_i \in \mathbb{R}^5$.

### 2. Preprocessing & Normalization
- **Component**: `sklearn.preprocessing.StandardScaler`
- **Operation**: Computes mean $\mu_j$ and standard deviation $\sigma_j$ for each flavor dimension $j$:
  $$z_{ij} = rac{x_{ij} - \mu_j}{\sigma_j}$$
- **Rationale**: Prevents features with wider variance from dominating Euclidean distance calculations.

### 3. Spatial Indexing Engine
- **Component**: `sklearn.neighbors.NearestNeighbors(n_neighbors=6, metric="euclidean")`
- **Design Decision**: Unsupervised indexing across the *entire catalog*. No train/test split is applied because recommendation retrieval queries an item database rather than measuring classification generalization on held-out samples.
- **Fitting**: `model.fit(scaled_features)` constructs an internal spatial search structure (e.g., KD-tree or Ball-tree) over the standardized dataset.

### 4. Query & Recommendation Logic
- **Lookup**: Locate query recipe by name (case-insensitive string comparison).
- **Neighbor Query**: Query $n+1$ nearest neighbors using `model.kneighbors(query_vector.reshape(1, -1), n_neighbors=n + 1)`.
- **Self-Match Exclusion**: Slice `distances[0][1:]` and `indices[0][1:]` to exclude index 0, which is always the query recipe itself at distance $0$.
- **Similarity Mapping**: Map unbounded distance $d \ge 0$ into a bounded similarity metric $S \in (0, 1]$:
  $$S = rac{1}{1 + d}$$

### 5. Serendipity / Cross-Cuisine Exploration ("Surprise Me")
- **Mechanism**: Extracts base recipe cuisine, filters catalog to recipes where `cuisine != base_cuisine`, and randomly selects one using a fixed pseudo-random seed (`random_state=7`).
- **Goal**: Counters the "filter bubble" by introducing delicious diversity from unfamiliar culinary traditions.

### 6. Presentation & Persistence Layer
- **Matplotlib Agg Backend**: Ensures reliable, headless rendering without requiring an X11 or Wayland display server.
- **Horizontal Bar Chart (`barh`)**: Visually contrasts candidate recipes sorted by similarity score.
- **Artifact Writer**: Persists formatted recommendations to `outputs/recommendations.txt`.
