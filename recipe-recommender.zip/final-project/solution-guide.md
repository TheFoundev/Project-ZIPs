# Solution Guide: The Recipe Recommender

## Overview for Mentors
This guide details the reference architecture, key pedagogical concepts, and evaluation benchmarks for assessing student implementations of the Recipe Recommender project.

---

## Step-by-Step Implementation Checkpoints

### Checkpoint 1: Headless Matplotlib Backend & Imports (lines 11-20)
```python
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler
```
**Mentor Verification:**
- `matplotlib.use("Agg")` must precede `import matplotlib.pyplot as plt`. If imported in reverse order, a GUI backend may initialize, leading to crashes in headless or remote server environments.
- Confirm import of `sklearn.neighbors.NearestNeighbors`, **not** `KNeighborsClassifier`.

### Checkpoint 2: Directory Architecture & Feature Constant (lines 22-27)
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)

FEATURES = ["spice", "sweet", "savory", "sour", "veggie"]
```
**Mentor Verification:**
- Uses `pathlib.Path` for cross-platform filesystem compatibility.
- `OUT.mkdir(exist_ok=True)` ensures directory creation without error if the folder already exists.
- `FEATURES` contains exactly the five sensory taste dimensions in order.

### Checkpoint 3: Data Ingestion & Preprocessing (lines 30-35)
```python
df = pd.read_csv(DATA / "recipes.csv")
scaler = StandardScaler()
scaled_features = scaler.fit_transform(df[FEATURES])
model = NearestNeighbors(n_neighbors=6, metric="euclidean")
model.fit(scaled_features)
```
**Mentor Verification:**
- `df` contains 24 rows and 7 columns.
- `scaler.fit_transform(df[FEATURES])` standardizes the 5 columns to have mean $\mu=0$ and variance $\sigma^2=1$.
- `scaled_features.shape` is `(24, 5)`.
- `model.fit(scaled_features)` is called on the entire dataset. Verify that the student has **not** included `train_test_split`. Explain that recommendation systems query catalog items rather than evaluating general classification accuracy.

### Checkpoint 4: Recommendation Query Engine (lines 37-52)
```python
def recommend(recipe_name: str, n: int = 3) -> pd.DataFrame:
    matches = df.index[df["name"].str.lower() == recipe_name.lower()]
    if len(matches) == 0:
        raise ValueError(f"Recipe not found: {recipe_name}")
    index = int(matches[0])
    distances, indices = model.kneighbors(scaled_features[index].reshape(1, -1), n_neighbors=n + 1)
    rows = []
    for distance, neighbor in zip(distances[0][1:], indices[0][1:]):
        rows.append(
            {
                "name": df.loc[neighbor, "name"],
                "cuisine": df.loc[neighbor, "cuisine"],
                "similarity": 1 / (1 + distance),
            }
        )
    return pd.DataFrame(rows)
```
**Mentor Verification:**
- Lookups must use `.str.lower() == recipe_name.lower()` for case-insensitivity.
- Exception handling raises `ValueError` for unknown recipes.
- `scaled_features[index]` must be reshaped with `.reshape(1, -1)` into a 2D array of shape `(1, 5)`.
- Requesting `n_neighbors=n + 1` is critical because the closest neighbor is always the query item itself.
- Slicing `distances[0][1:]` and `indices[0][1:]` removes self-match (neighbor at distance 0).
- Similarity formula must be $S = \frac{1}{1 + d}$.

### Checkpoint 5: Cross-Cuisine Serendipity ("Surprise Me") (lines 54-61)
```python
def surprise_me(recipe_name: str) -> pd.Series:
    matches = df.index[df["name"].str.lower() == recipe_name.lower()]
    if len(matches) == 0:
        raise ValueError(f"Recipe not found: {recipe_name}")
    base = df.loc[int(matches[0])]
    different = df[df["cuisine"] != base["cuisine"]]
    return different.sample(1, random_state=7).iloc[0]
```
**Mentor Verification:**
- Correctly filters out recipes sharing the base recipe's cuisine.
- `random_state=7` is used for deterministic reproducibility.
- Returns a pandas Series representing the selected recipe row.

### Checkpoint 6: Visualization & Artifact Generation (lines 74-95)
```python
base_recipe = "Spicy Ramen"
recommendations = recommend(base_recipe, n=5)
fig, ax = plt.subplots(figsize=(8, 4.5))
ax.barh(recommendations["name"][::-1], recommendations["similarity"][::-1], color="#e67e22")
ax.set_xlim(0, 1)
ax.set_xlabel("similarity score (higher is closer)")
ax.set_title(f"Recipes most similar to {base_recipe}")
ax.grid(axis="x", alpha=0.25)
fig.tight_layout()
fig.savefig(OUT / "similarity_scores.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```
**Mentor Verification:**
- `ax.barh` uses `[::-1]` so that the closest match appears at the top of the chart.
- The x-axis limit is explicitly set to `(0, 1)`.
- `plt.close(fig)` is called to prevent resource leaks.
- Text file output writes clean lines with formatted floating point values.

---

## Pedagogical Discussion Questions for Mentors
1. **Why does Chocolate Cake have a similarity score of 1.000 with Pancakes?**
   *Answer:* Inspecting `recipes.csv` shows both dishes have identical flavor attributes: `spice=1, sweet=5, savory=2, sour=1, veggie=1`. Their Euclidean distance is 0.0, resulting in $S = 1 / (1 + 0) = 1.0$.
2. **What would happen if we didn't scale features with `StandardScaler`?**
   *Answer:* If one feature had a scale of 1-100 and others were 1-5, the large-scale feature would dominate distance calculations, ignoring differences in other dimensions. While our CSV currently rates all dimensions on a 1-5 scale, features have different empirical standard deviations across recipes, making standardization essential practice.
3. **How does this system differ from a classifier like `KNeighborsClassifier`?**
   *Answer:* `KNeighborsClassifier` uses neighbor distances to vote on a discrete category target (supervised). `NearestNeighbors` is an unsupervised index that retrieves neighbor identities and distances directly without target labels.
