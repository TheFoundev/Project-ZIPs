# Final Project Requirements: The Recipe Recommender

## Project Objective
Implement the complete Recipe Recommender from scratch, reproducing the exact behavior of `main.py`. Your implementation will ingest a multi-cuisine recipe dataset, transform 5-dimensional flavor profiles into normalized coordinate vectors, fit an unsupervised spatial nearest neighbor index, build query functions for content-based recommendations and cross-cuisine serendipity, and generate both visual and text output artifacts.

---

## Functional Requirements

### 1. Imports and Environment Setup
- Configure Matplotlib to use the headless `"Agg"` backend before importing `pyplot`.
- Import the required modules:
  - `pathlib.Path` for path manipulations.
  - `pandas` as `pd`.
  - `numpy` as `np`.
  - `matplotlib.pyplot` as `plt`.
  - `sklearn.neighbors.NearestNeighbors` for spatial similarity indexing.
  - `sklearn.preprocessing.StandardScaler` for feature normalization.
- Establish project directory constants:
  - `BASE`: The directory containing `main.py`.
  - `DATA`: The `data/` subdirectory.
  - `OUT`: The `outputs/` subdirectory, created with `OUT.mkdir(exist_ok=True)`.

### 2. Feature Definition & Data Ingestion
- Define the constant list:
  ```python
  FEATURES = ["spice", "sweet", "savory", "sour", "veggie"]
  ```
- Load `recipes.csv` from `data/recipes.csv` into a pandas DataFrame named `df`.
- Ensure the DataFrame contains all 24 records and 7 columns (`name`, `cuisine`, and the 5 flavor features).

### 3. Preprocessing with StandardScaler
- Instantiate `StandardScaler()`.
- Fit and transform `df[FEATURES]` to produce `scaled_features`.
- Confirm that `scaled_features` is a 2D NumPy array with shape `(24, 5)`.

### 4. Unsupervised Nearest Neighbors Model Fitting
- Instantiate `NearestNeighbors` with:
  - `n_neighbors=6`
  - `metric="euclidean"`
- Call `model.fit(scaled_features)` on the entire scaled dataset.
- Note: Do NOT split the data into train and test sets. Recommendation retrieval indexes the catalog items.

### 5. Recommendation Engine Function (`recommend`)
Implement `recommend(recipe_name: str, n: int = 3) -> pd.DataFrame` with the following specifications:
- Match `recipe_name` against `df["name"]` in a case-insensitive manner.
- Raise `ValueError(f"Recipe not found: {recipe_name}")` if no matching recipe exists.
- Extract the integer index of the matched recipe.
- Reshape the recipe's feature vector using `.reshape(1, -1)` to pass to `model.kneighbors()`.
- Request `n_neighbors=n + 1` from `model.kneighbors()`.
- Exclude the self-match (neighbor index 0) by slicing `distances[0][1:]` and `indices[0][1:]`.
- Calculate similarity for each neighbor using:
  $$\text{similarity} = \frac{1}{1 + \text{distance}}$$
- Return a pandas DataFrame containing:
  - `name`: Recipe name of the neighbor.
  - `cuisine`: Cuisine of the neighbor.
  - `similarity`: The computed similarity float.

### 6. Serendipity Engine Function (`surprise_me`)
Implement `surprise_me(recipe_name: str) -> pd.Series` with the following specifications:
- Match `recipe_name` against `df["name"]` in a case-insensitive manner, raising `ValueError` if not found.
- Retrieve the base cuisine of the query recipe.
- Filter `df` to isolate recipes where `cuisine != base["cuisine"]`.
- Sample 1 recipe using `.sample(1, random_state=7).iloc[0]`.
- Return the selected `pd.Series`.

### 7. Console Reporting
- Print section banners:
  ```text
  ============================================================
  THE RECIPE RECOMMENDER
  ============================================================
  ```
- Generate and display top 3 recommendations for:
  - `"Margherita Pizza"`
  - `"Spicy Ramen"`
  - `"Chocolate Cake"`
- Format output lines cleanly: recipe name (width 22), cuisine in parentheses (width 14), and similarity formatted to 2 decimal places (`.2f`).
- Print the surprise recommendation for `"Margherita Pizza"`.

### 8. Visualization Generation (`similarity_scores.png`)
- Select `"Spicy Ramen"` as the base recipe and query its top 5 recommendations (`n=5`).
- Create a Matplotlib figure with dimensions `(8, 4.5)` using `plt.subplots()`.
- Render a horizontal bar chart with `ax.barh()`:
  - Invert the sequence (`[::-1]`) for both recipe names and similarity scores so the highest similarity appears at the top.
  - Apply the color `"#e67e22"` (burnt orange).
- Configure plot aesthetics:
  - Set x-axis limit: `ax.set_xlim(0, 1)`.
  - Set x-axis label: `"similarity score (higher is closer)"`.
  - Set title: `"Recipes most similar to Spicy Ramen"`.
  - Enable subtle vertical gridlines: `ax.grid(axis="x", alpha=0.25)`.
  - Call `fig.tight_layout()`.
- Save the plot to `outputs/similarity_scores.png` with `dpi=150` and `bbox_inches="tight"`.
- Close the figure using `plt.close(fig)` to release memory.

### 9. File Persistence (`recommendations.txt`)
- Open `outputs/recommendations.txt` with UTF-8 encoding.
- Write recommendations for `"Margherita Pizza"`, `"Spicy Ramen"`, and `"Chocolate Cake"`, formatting similarity scores to 3 decimal places (`.3f`).
- Append the "Surprise me" recommendation for `"Margherita Pizza"`.

---

## Verification Checklist
- [ ] Script runs cleanly with `python main.py` and returns exit code 0.
- [ ] `outputs/similarity_scores.png` is generated and visually matches expected bar layout.
- [ ] `outputs/recommendations.txt` is populated with correct text and scores.
- [ ] Margherita Pizza top recommendation is Lasagna (similarity ≈ 0.52).
- [ ] Spicy Ramen top recommendation is Chicken Tikka Masala (similarity ≈ 0.49).
- [ ] Chocolate Cake top recommendation is Pancakes (similarity = 1.00).
- [ ] Surprise recommendation for Margherita Pizza is Chicken Tikka Masala (Indian).
