# Lesson 02: The Five Flavor Dimensions

**Lesson ID:** lesson-02  
**Module:** module-02  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
The purpose of this lesson is to analyze the five sensory flavor dimensions that constitute the feature space of our recommender. By the end of this lesson, you will be able to:
- Define the five sensory dimensions: `spice`, `sweet`, `savory`, `sour`, and `veggie`.
- Interpret the 1-to-5 numeric scoring scale applied across each dimension.
- Analyze how individual dishes score along these dimensions based on their ingredients.
- Explain how human gustatory perception is abstracted into quantifiable feature vectors.

## Prerequisites
Familiarity with Lesson 01 (loading `recipes.csv`).

## Concept Explanation
### Quantifying taste: From sensation to number
Human taste perception relies on five basic taste modalities identified by physiology: sweet, sour, salty, bitter, and umami (savory). In culinary arts, spiciness (pungency from capsaicin) and vegetable/herbaceous freshness also strongly influence how a person perceives a meal.

In `recipes.csv`, each dish is evaluated across five fundamental flavor axes on a discrete integer scale from **1 to 5**:

```
Scale: 1 = Minimal / None  -------------------->  5 = Dominant / Intense
```

1. **Spice** (Pungency / Heat):
   - `1`: Zero perceptible heat (e.g., Pancakes, Chocolate Cake, Greek Salad).
   - `5`: Fiery, mouth-tingling heat from chili peppers or wasabi (e.g., Spicy Ramen, Tom Yum Soup).

2. **Sweet** (Sugar / Sweetness):
   - `1`: Unsweetened, strictly savory or acidic (e.g., Spicy Ramen, Sushi, Miso Soup).
   - `5`: Rich, sugary dessert profile (e.g., Pancakes, Chocolate Cake).

3. **Savory** (Umami / Richness):
   - `1`: Minimal savory intensity (rare in main dishes, moderate in light snacks).
   - `5`: Deep, concentrated umami from roasted meats, aged cheeses, stocks, or fermented sauces (e.g., Margherita Pizza, Lasagna, Mushroom Risotto, Butter Chicken).

4. **Sour** (Acidity / Tartness):
   - `1`: Mild, alkaline, or non-acidic (e.g., Pancakes, Butter Chicken).
   - `5`: Pronounced, sharp tang from citrus, vinegar, or fermented foods (e.g., Tom Yum Soup, Lemon Tart).

5. **Veggie** (Plant-based / Freshness):
   - `1`: Heavy meat, dairy, or refined grain focus with minimal greens (e.g., Pancakes, Chocolate Cake, Butter Chicken, Fish and Chips).
   - `3`: Balanced presence of fresh vegetables or legumes (e.g., Greek Salad, Falafel Wrap, Burrito Bowl, Caprese Salad).

## Relevant Code (from main.py, line 27)
```python
FEATURES = ["spice", "sweet", "savory", "sour", "veggie"]
```

## Code Explanation
- **Line 27**: `FEATURES` defines the list of column names used as predictive inputs. Notice that `name` and `cuisine` are deliberately excluded from this list because they are categorical identifiers and metadata, whereas `FEATURES` contains only the numerical sensory attributes.

## Worked Example
Let us examine the flavor coordinates of three distinct dishes from `recipes.csv`:

| Recipe | Cuisine | Spice | Sweet | Savory | Sour | Veggie | Culinary Interpretation |
|---|---|---|---|---|---|---|---|
| **Margherita Pizza** | Italian | 2 | 2 | 5 | 3 | 2 | Rich umami cheese and bread (5), tangy tomato (3), mild seasoning (2) |
| **Tom Yum Soup** | Thai | 5 | 1 | 4 | 5 | 2 | Fiery chilies (5), sharp lime acidity (5), umami broth (4), savory shrimp |
| **Lemon Tart** | French | 1 | 4 | 2 | 5 | 1 | Sweet pastry (4), intense citrus lemon curd (5), zero spice (1) |

Notice how Tom Yum Soup and Lemon Tart both share a `sour` rating of 5, but diverge completely on `spice` (5 vs 1) and `savory` (4 vs 2). The multi-dimensional coordinates capture both the similarities and contrasts simultaneously!

## Step-by-Step Student Instructions
1. In your Python terminal, load the dataset:
   ```python
   import pandas as pd
   df = pd.read_csv("data/recipes.csv")
   ```
2. Inspect the summary statistics of the five flavor dimensions:
   ```python
   features = ["spice", "sweet", "savory", "sour", "veggie"]
   print(df[features].describe())
   ```
3. Observe the `min`, `max`, `mean`, and standard deviation (`std`) of each feature.
4. Notice that all five features span values from 1 to 5.
5. Identify which feature has the highest average value across the catalog. (In our dataset, `savory` has the highest mean, reflecting hearty main courses).

## Expected Output or Observable Behaviour
Running `df[features].describe()` outputs:
```text
           spice      sweet     savory       sour     veggie
count  24.000000  24.000000  24.000000  24.000000  24.000000
mean    2.375000   2.083333   3.875000   2.833333   1.875000
std     1.438258   1.501209   1.034509   1.129319   0.740889
min     1.000000   1.000000   2.000000   1.000000   1.000000
max     5.000000   5.000000   5.000000   5.000000   3.000000
```
Notice that `veggie` has a lower maximum (3) and smaller standard deviation (0.74) compared to `sweet` or `spice` (std ~1.50). This statistical insight will become vital when we discuss feature scaling in Module 03!

## Practical Exercises
1. **Exercise 2.1**: Which dish in the dataset has the highest `veggie` score? Write a pandas query: `df[df["veggie"] == df["veggie"].max()]`.
2. **Exercise 2.2**: Find all dishes where `spice >= 4` AND `savory >= 4`. What dishes match this intense spicy-umami profile?
3. **Exercise 2.3**: If you wanted to expand this feature space to 6 dimensions, what 6th sensory attribute would you add (e.g., *crunchiness/texture*, *bitterness*, *richness/fat*)? Justify your choice.

## Common Mistakes and Debugging
| Mistake | Why it happens | How to resolve |
|---|---|---|
| Assuming ratings are continuous floating-point values in CSV | Looking at the code output where similarity is float | Note that the raw CSV values are integers from 1 to 5 |
| Believing 5 is always "better" than 1 | Thinking of 1-5 as star ratings | Understand that 1-5 represents intensity, not quality (a 1 in spice is not "bad", it means mild) |
| Including `cuisine` in `FEATURES` | Forgetting that scikit-learn distance metrics require numerical values | Keep `cuisine` as metadata; include only numerical sensory columns in `FEATURES` |

## Best Practices and Security Considerations
- **Semantic Clarity in Feature Names**: Use clean, descriptive column headers (`spice`, `sweet`, `savory`) rather than cryptic abbreviations (`f1`, `f2`, `f3`).
- **Bounded Scales**: Using standardized ranges (such as 1-5 or 0-10) during data curation prevents arbitrary scale imbalances before preprocessing.

## Summary
The Recipe Recommender features five sensory dimensions: `spice`, `sweet`, `savory`, `sour`, and `veggie`. Scored on an intensity scale from 1 to 5, these dimensions translate human gustatory sensations into a mathematically actionable feature space for similarity comparison.

## Knowledge-check Questions
1. What does a rating of 1 represent on our sensory scale?
2. What does a rating of 5 represent on our sensory scale?
3. Which flavor dimension in `recipes.csv` has the highest mean across all 24 dishes?
4. Why are the `name` and `cuisine` columns excluded from the `FEATURES` list?
5. How does a high score in `sour` differ from a high score in `sweet` when describing a Lemon Tart?

## References
- The Five Basic Tastes (Sensory Science Overview): https://www.ncbi.nlm.nih.gov/books/NBK279408/
- Pandas describe() Method: https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.describe.html
