# Lesson 04: Feature Representation: From DataFrames to Feature Matrices

**Lesson ID:** lesson-04  
**Module:** module-02  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
The purpose of this lesson is to learn how to cleanly separate metadata from numerical features, converting a pandas DataFrame into a 2D feature matrix suitable for scikit-learn. By the end of this lesson, you will be able to:
- Distinguish between informational metadata columns and mathematical feature columns.
- Extract a feature subset using list-based indexing `df[FEATURES]`.
- Verify the shape, memory layout, and NumPy array representations of feature matrices.
- Explain why scikit-learn algorithms require 2D arrays of shape `(n_samples, n_features)`.

## Prerequisites
Completion of Lessons 01-03. Familiarity with NumPy arrays and pandas subset indexing.

## Concept Explanation
### Metadata vs. Feature Attributes
A raw tabular dataset often contains a mixture of different data types serving different roles:
- **Identifier / Metadata**: Columns like `name` ("Spicy Ramen") and `cuisine` ("Japanese") provide human context. They are essential for displaying results to users, but they cannot be directly plugged into a geometric distance formula like $\sqrt{\Delta x^2 + \Delta y^2}$.
- **Numerical Features**: Columns like `spice`, `sweet`, `savory`, `sour`, and `veggie` contain quantitative numbers. These numbers serve as coordinate axes in our mathematical space.

```
+-------------------------------------------------------------------------------+
|                             RAW DATAFRAME (24 x 7)                            |
+-------------------------------------------------------------------------------+
|  name (str)     | cuisine (str)   ||  spice | sweet | savory | sour | veggie  |
|  "Spicy Ramen"  | "Japanese"      ||    5   |   1   |   5    |  2   |   2     |
+-----------------+-----------------++------------------------------------------+
       |                  |                               |
       v                  v                               v
  [METADATA FOR DISPLAY]               [FEATURE MATRIX X: 2D NumPy Array (24, 5)]
```

### The 2D Array Expectation in Scikit-Learn
All scikit-learn estimators (including `StandardScaler` and `NearestNeighbors`) strictly expect input features to be structured as a **2-dimensional array** with shape:
$$(n_{\text{samples}}, n_{\text{features}})$$
- $n_{\text{samples}}$: The number of rows / observations (24 in our dataset).
- $n_{\text{features}}$: The number of numeric coordinate columns (5 in our dataset).

If you accidentally pass a 1-dimensional Series (e.g. `df["spice"]`), scikit-learn will raise an immediate error:
`ValueError: Expected 2D array, got 1D array instead`.
By using double brackets with a list of column names, `df[FEATURES]`, pandas returns a 2D DataFrame that seamlessly integrates with scikit-learn.

## Relevant Code (from main.py, lines 27, 31, 33)
```python
FEATURES = ["spice", "sweet", "savory", "sour", "veggie"]

def main() -> None:
    df = pd.read_csv(DATA / "recipes.csv")
    scaler = StandardScaler()
    scaled_features = scaler.fit_transform(df[FEATURES])
```

## Code Explanation
- **Line 27**: `FEATURES` defines the list of exactly five column names that make up our feature space.
- **Line 31**: Loads the full 7-column DataFrame into `df`.
- **Line 33**: `df[FEATURES]` slices the DataFrame, selecting only the 5 numerical columns. This slice has shape `(24, 5)` and is passed directly to `scaler.fit_transform()`.

## Worked Example
Let us see what `df[FEATURES]` looks like under the hood in Python:
```python
>>> import pandas as pd
>>> df = pd.read_csv("data/recipes.csv")
>>> FEATURES = ["spice", "sweet", "savory", "sour", "veggie"]
>>> X = df[FEATURES]
>>> type(X)
<class 'pandas.core.frame.DataFrame'>
>>> X.shape
(24, 5)
>>> X.values[:2]
array([[2, 2, 5, 3, 2],
       [5, 1, 5, 2, 2]])
```
When `X.values` is inspected, we see a clean NumPy array where row 0 contains the five numbers for Margherita Pizza, and row 1 contains the five numbers for Spicy Ramen. This 2D array contains pure numerical coordinates ready for geometric computation.

## Step-by-Step Student Instructions
1. Open your Python terminal in the project directory.
2. Load the dataset and extract the feature matrix:
   ```python
   import pandas as pd
   df = pd.read_csv("data/recipes.csv")
   FEATURES = ["spice", "sweet", "savory", "sour", "veggie"]
   features_df = df[FEATURES]
   ```
3. Check the shape and data types:
   ```python
   print("Shape:", features_df.shape)
   print("\nData Types:\n", features_df.dtypes)
   ```
4. Confirm that all 5 columns are numeric (`int64`).
5. Extract the underlying NumPy array using `X = features_df.to_numpy()` and check `X.ndim` (should be 2).

## Expected Output or Observable Behaviour
The terminal displays:
```text
Shape: (24, 5)

Data Types:
 spice     int64
sweet     int64
savory    int64
sour      int64
veggie    int64
dtype: object
```
This confirms that the feature matrix is rectangular, 2-dimensional, and consists purely of integer numerical values.

## Practical Exercises
1. **Exercise 4.1**: What happens if you run `df["spice"].shape` versus `df[["spice"]].shape`? Explain the difference between a 1D Series and a 2D DataFrame.
2. **Exercise 4.2**: Extract only the sweet and savory columns into a mini-feature matrix named `X_simple`. What is its shape?
3. **Exercise 4.3**: Write a Python function that takes a recipe name as input and returns its 5D feature vector as a 1D NumPy array of shape `(5,)`.

## Common Mistakes and Debugging
| Mistake | Why it happens | How to resolve |
|---|---|---|
| Passing `df[FEATURES]` with a typo | Misspelling column name like `"savoury"` | Verify spelling against `df.columns` (the CSV uses `"savory"`) |
| Passing single brackets for a single column | `df["spice"]` yields a 1D Series of shape `(24,)` | Use double brackets `df[["spice"]]` to maintain 2D shape `(24, 1)` |
| Trying to scale string columns | Including `name` or `cuisine` in `FEATURES` | `StandardScaler` raises `TypeError: could not convert string to float` |

## Best Practices and Security Considerations
- **Constant Definition**: Define feature column lists as uppercase constants (`FEATURES = [...]`) near the top of the file so changes can be made in one central location.
- **Data Validation**: Always assert `df[FEATURES].isnull().sum().sum() == 0` before feeding matrices to estimators to catch corrupt data early.

## Summary
Machine learning algorithms cannot process raw strings like dish names or cuisines. By subsetting `df[FEATURES]`, we extract a clean, 2-dimensional numerical feature matrix of shape `(24, 5)`. This matrix maps each dish into our coordinate system, preparing it for preprocessing and distance modeling.

## Knowledge-check Questions
1. What is the difference between metadata columns and feature columns in `recipes.csv`?
2. What is the shape of `df[FEATURES]`?
3. Why does scikit-learn require a 2D array rather than a 1D vector?
4. What error occurs if you pass string columns into `StandardScaler`?
5. How does `df["spice"]` differ from `df[["spice"]]` in pandas?

## References
- Pandas Indexing and Selecting Data: https://pandas.pydata.org/docs/user_guide/indexing.html
- Scikit-learn Dataset Loading and Array Representation: https://scikit-learn.org/stable/modules/generated/sklearn.utils.check_array.html
