# Lesson 01: Loading and Inspecting recipes.csv

**Lesson ID:** lesson-01  
**Module:** module-02  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
The purpose of this lesson is to master data ingestion and exploratory inspection using pandas and pathlib. By the end of this lesson, you will be able to:
- Locate and load `recipes.csv` using Python's modern `pathlib.Path` standard.
- Read tabular data into a pandas DataFrame using `pd.read_csv()`.
- Inspect DataFrame dimensions, column data types, and check for missing values using `.shape`, `.head()`, and `.info()`.
- Identify the 24 distinct culinary dishes and 7 columns present in the dataset.

## Prerequisites
Completion of Module 01. Familiarity with basic command line navigation and Python imports.

## Concept Explanation
### Modern path management with pathlib
In professional Python applications, hardcoding raw string paths like `"data/recipes.csv"` or `"C:\\projects\\data\\recipes.csv"` is brittle. If a script is executed from a different working directory, or transferred between Linux and Windows, relative string paths break.

Python 3 introduced the `pathlib` module, which treats filesystem paths as first-class objects:
- `Path(__file__)`: Resolves the absolute path of the currently executing script (`main.py`).
- `.resolve().parent`: Resolves symbolic links and points to the directory containing the script.
- The `/` operator: Safely joins directories and filenames across any operating system (handling backslashes on Windows and forward slashes on POSIX systems automatically).

### Loading tabular data with pandas
Once the dataset path is established, `pd.read_csv()` parses the comma-separated text into a structured two-dimensional table called a **DataFrame**:
- Rows represent individual samples (in our case, individual recipes).
- Columns represent variables or attributes (such as `name`, `cuisine`, and sensory ratings).

### Examining dataset structure
Before feeding data into machine learning algorithms, good data scientists always perform fundamental sanity checks:
1. `df.shape`: Returns a tuple `(n_rows, n_columns)` indicating table dimensions. In our project, `(24, 7)`.
2. `df.columns`: Lists all column names.
3. `df.head(n)`: Previews the first $n$ rows.
4. `df.isnull().sum()`: Checks for missing or `NaN` values that could cause algorithms to crash.

## Relevant Code (from main.py, lines 22-25, 30-31)
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)

...
def main() -> None:
    df = pd.read_csv(DATA / "recipes.csv")
```

## Code Explanation
- **Lines 22-24**: `BASE` resolves the absolute path of the project root. `DATA` points to `BASE / "data"`, and `OUT` points to `BASE / "outputs"`.
- **Line 25**: `OUT.mkdir(exist_ok=True)` ensures the output directory exists before any plots or files are saved, avoiding `FileNotFoundError`.
- **Line 31**: `df = pd.read_csv(DATA / "recipes.csv")` reads the CSV file located in `data/recipes.csv` directly into memory as a pandas DataFrame named `df`.

## Worked Example
Let us trace what happens when `pd.read_csv` executes on the first 3 rows of `data/recipes.csv`:
Raw file text:
```csv
name,cuisine,spice,sweet,savory,sour,veggie
Margherita Pizza,Italian,2,2,5,3,2
Spicy Ramen,Japanese,5,1,5,2,2
```
Pandas constructs an indexed DataFrame:
- Index 0: `name="Margherita Pizza"`, `cuisine="Italian"`, `spice=2`, `sweet=2`, `savory=5`, `sour=3`, `veggie=2`
- Index 1: `name="Spicy Ramen"`, `cuisine="Japanese"`, `spice=5`, `sweet=1`, `savory=5`, `sour=2`, `veggie=2`
Each column is parsed with an appropriate data type: `name` and `cuisine` as `object` (strings), and the five sensory attributes as `int64`.

## Step-by-Step Student Instructions
1. Open a Python interactive terminal (or Jupyter notebook / IPython) in your project folder.
2. Run the following commands to load and inspect the data:
   ```python
   from pathlib import Path
   import pandas as pd
   
   data_path = Path("data/recipes.csv")
   df = pd.read_csv(data_path)
   print("Shape:", df.shape)
   print("\nColumns:", df.columns.tolist())
   print("\nFirst 3 rows:")
   print(df.head(3))
   ```
3. Verify that `df.shape` returns `(24, 7)`.
4. Check for any missing values using `print(df.isnull().sum())`. All counts should be 0.

## Expected Output or Observable Behaviour
The terminal displays:
```text
Shape: (24, 7)

Columns: ['name', 'cuisine', 'spice', 'sweet', 'savory', 'sour', 'veggie']

First 3 rows:
                   name   cuisine  spice  sweet  savory  sour  veggie
0      Margherita Pizza   Italian      2      2       5     3       2
1           Spicy Ramen  Japanese      5      1       5     2       2
2  Chicken Tikka Masala    Indian      4      2       5     2       2
```
This confirms that the data is loaded into memory, completely clean, with no null values.

## Practical Exercises
1. **Exercise 1.1**: Print the unique cuisines present in the dataset using `df["cuisine"].unique()`. How many unique culinary traditions are represented?
2. **Exercise 1.2**: Write a one-liner to find the recipe with the highest `sweet` score in the entire dataset.
3. **Exercise 1.3**: What happens if you try to call `pd.read_csv("recipes.csv")` without specifying the `data/` subdirectory? Explain the error message.

## Common Mistakes and Debugging
| Mistake | Why it happens | How to resolve |
|---|---|---|
| `FileNotFoundError` on loading CSV | Current working directory is not the project root, or path omits `data/` | Use `Path(__file__).resolve().parent / "data" / "recipes.csv"` |
| Forgetting `exist_ok=True` on `mkdir` | Re-running script when `outputs/` already exists raises `FileExistsError` | Always pass `exist_ok=True` to `mkdir()` |
| Modifying the original CSV accidentally | Writing code that saves over `recipes.csv` | Always save generated results to `outputs/`, keeping `data/` read-only |

## Best Practices and Security Considerations
- **Immutability of Raw Data**: Treat files in `data/` as read-only golden masters. Never write script outputs back into `data/`.
- **Path Portability**: Avoid hardcoded path separators like `"data\\recipes.csv"` or `"/data/recipes.csv"`. Always use `pathlib.Path` and the `/` operator.

## Summary
The Recipe Recommender loads 24 dishes across 7 columns from `data/recipes.csv` using `pathlib.Path` and `pandas.read_csv`. Understanding the DataFrame shape `(24, 7)` and confirming the absence of null values guarantees a clean data foundation for distance modeling.

## Knowledge-check Questions
1. How many rows and columns are in `recipes.csv`?
2. Why is `pathlib.Path(__file__).resolve().parent` preferred over raw string paths?
3. What is the purpose of passing `exist_ok=True` to `OUT.mkdir()`?
4. What are the names of the two non-numeric columns in `recipes.csv`?
5. How can you verify whether a DataFrame contains any missing (NaN) values in pandas?

## References
- Pandas read_csv Documentation: https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html
- Python pathlib Module Guide: https://docs.python.org/3/library/pathlib.html
