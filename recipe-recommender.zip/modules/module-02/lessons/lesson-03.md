# Lesson 03: Comparing Flavor Profiles Across Cuisines

**Lesson ID:** lesson-03  
**Module:** module-02  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
The purpose of this lesson is to examine how international culinary traditions cluster in multi-dimensional flavor space. By the end of this lesson, you will be able to:
- Identify the international cuisines represented in `data/recipes.csv`.
- Group dishes by cuisine and calculate cuisine-level average flavor profiles using pandas.
- Observe cross-cultural flavor similarities (e.g., why Korean and Mexican dishes share spicy-savory overlap).
- Understand how cuisine labels enable serendipitous recommendations across cultural boundaries.

## Prerequisites
Completion of Lessons 01 and 02. Basic understanding of pandas `groupby`.

## Concept Explanation
### Culinary culture as spatial clusters
Every culture has developed unique combinations of seasoning, ingredients, and cooking techniques:
- **Italian Cuisine**: Emphasizes high savory umami (parmesan, slow-cooked meats, mushrooms), balanced sweetness, and gentle tomato acidity.
- **Thai Cuisine**: Renowned for the "four-pillar balance": spicy, sweet, sour, and savory harmonized in single dishes.
- **Indian Cuisine**: Balances warm and pungent spices with rich, creamy savory bases.
- **American Desserts**: Characterized by peak sweetness, moderate savory butter/dough notes, and minimal spice.

```
       Spice
         ^
         |      [Thai / Indian / Korean / Mexican]  <-- High spice, high savory
         |
         |      [Italian / Spanish / Japanese]     <-- Low-to-moderate spice, rich umami
         |
         |      [American Desserts / French]       <-- High sweet, low spice
         +---------------------------------------------> Sweet
```

When we project these dishes into flavor space, dishes from the same cuisine often cluster near one another. However, dishes from **different cultures** often discover surprising neighbors! For instance:
- **Spicy Ramen** (Japanese): `[5, 1, 5, 2, 2]`
- **Kimchi Fried Rice** (Korean): `[4, 1, 4, 3, 2]`
- **Taco** (Mexican): `[4, 1, 4, 3, 2]`
Notice that the Mexican Taco and Korean Kimchi Fried Rice have **identical flavor coordinates** in our dataset (`[4, 1, 4, 3, 2]`)! Even though they come from opposite sides of the globe, their taste profiles are virtual twins.

### Breaking out of culinary silos
If an Italian food lover only ever gets recommended Italian dishes (pizza $\rightarrow$ lasagna $\rightarrow$ risotto), they miss out on the rich world of international food. By understanding flavor profiles independent of cuisine labels, our recommender can bridge cultures:
$$\text{"You love Italian Margherita Pizza? You will love Spanish Paella!"}$$
Both share rich savory umami and gentle seasoning, opening doors to new cultural discoveries.

## Relevant Code (from main.py, lines 38, 48, 59-60)
```python
# Matching recipe cuisine and recommending across cuisines
rows.append(
    {
        "name": df.loc[neighbor, "name"],
        "cuisine": df.loc[neighbor, "cuisine"],
        "similarity": 1 / (1 + distance),
    }
)

...
base = df.loc[int(matches[0])]
different = df[df["cuisine"] != base["cuisine"]]
```

## Code Explanation
- **Line 48**: Extracts the `cuisine` of the recommended neighbor so the user can see what cultural tradition the recommendation originates from.
- **Line 59**: `different = df[df["cuisine"] != base["cuisine"]]` filters the entire catalog to isolate dishes from different cuisines, forming the backbone of the "Surprise Me" engine.

## Worked Example
Let us compute the average flavor profile for Italian dishes versus American dishes in our dataset:
In `recipes.csv`:
- Italian dishes: Margherita Pizza, Lasagna, Caprese Salad, Mushroom Risotto.
- American dishes: Pancakes, Blueberry Muffin.

Average profiles:
- Italian: `spice = 1.5`, `sweet = 1.75`, `savory = 4.5`, `sour = 3.25`, `veggie = 2.5`
- American: `spice = 1.0`, `sweet = 4.5`, `savory = 2.0`, `sour = 1.5`, `veggie = 1.0`

The averages reveal contrasting culinary centers of gravity: Italian dishes cluster around high savory and moderate sour acidity, whereas American dishes in this dataset cluster strongly around high sweetness.

## Step-by-Step Student Instructions
1. Open your Python terminal and group the recipes by cuisine:
   ```python
   import pandas as pd
   df = pd.read_csv("data/recipes.csv")
   features = ["spice", "sweet", "savory", "sour", "veggie"]
   print(df.groupby("cuisine")[features].mean().round(2))
   ```
2. Examine the output table.
3. Identify which cuisine has the highest average `spice` score. (Thai and Korean).
4. Identify which cuisine has the highest average `sweet` score. (Dessert and American).
5. Filter all dishes from the `"Mexican"` cuisine to inspect their individual rows:
   ```python
   print(df[df["cuisine"] == "Mexican"])
   ```

## Expected Output or Observable Behaviour
The terminal outputs the cuisine mean table:
```text
                spice  sweet  savory  sour  veggie
cuisine                                           
American         1.00   4.50    2.00  1.50    1.00
British          1.00   1.00    4.00  3.00    1.00
Dessert          1.00   5.00    2.00  1.00    1.00
French           1.00   4.00    2.00  5.00    1.00
Greek            1.00   1.00    3.00  4.00    3.00
Indian           3.50   2.50    5.00  1.50    1.50
Italian          1.50   1.75    4.50  3.25    2.50
Japanese         2.33   1.00    4.00  2.67    1.33
Korean           3.50   1.50    4.00  2.50    2.50
Mexican          3.50   1.00    4.00  3.00    2.50
Middle Eastern   2.00   1.00    4.00  3.00    3.00
Spanish          2.00   1.00    5.00  2.00    2.00
Thai             4.00   2.33    4.00  3.67    2.00
```
Notice how Indian and Spanish cuisines both achieve a perfect 5.00 average in `savory`, while Thai leads in `spice` (4.00).

## Practical Exercises
1. **Exercise 3.1**: Which cuisine in the dataset exhibits the highest average `veggie` score?
2. **Exercise 3.2**: Write a Python expression that finds all recipes where `cuisine != "Italian"` but `similarity` to Margherita Pizza is above 0.40.
3. **Exercise 3.3**: Why might recommending a Mexican Taco to a Spicy Ramen lover be more appealing than recommending another bowl of soup?

## Common Mistakes and Debugging
| Mistake | Why it happens | How to resolve |
|---|---|---|
| Misspelling cuisine names in boolean filters | Case sensitivity: `"italian"` vs `"Italian"` | Use `.str.lower()` or exact string matching matching the CSV capitalization |
| Assuming each cuisine has dozens of recipes | Overestimating dataset size | Remember `recipes.csv` is a curated educational dataset of 24 recipes |
| Expecting cuisine to be a feature input | Treating cuisine as an $X$ input variable | Cuisine is metadata for grouping and serendipity, not a numeric coordinate |

## Best Practices and Security Considerations
- **Categorical Integrity**: Verify that category labels (cuisines) are consistently spelled and capitalized to avoid fragmentation (e.g. "Italian" vs "italian ").
- **Cultural Sensitivity**: When building culinary recommendation systems, ensure feature scoring respects authentic cultural flavor profiles rather than relying on westernized stereotypes.

## Summary
Cuisines form distinct flavor clusters in 5D taste space, but cross-cultural overlaps are common and exciting. By decoupling flavor similarity from cultural origin labels, the Recipe Recommender can suggest surprising dishes that share familiar taste profiles across international borders.

## Knowledge-check Questions
1. How many different cuisines are represented in `recipes.csv`?
2. Which two dishes in `recipes.csv` share identical flavor coordinates `[4, 1, 4, 3, 2]` despite coming from different cultures?
3. What is the average `savory` score of Italian dishes in our dataset?
4. How does the code in `main.py` filter recipes when selecting a "surprise" recommendation?
5. Why is cross-cuisine recommendation valuable to food lovers?

## References
- The Flavor Network and the Principles of Food Pairing (Nature): https://www.nature.com/articles/srep00196
- Pandas GroupBy Guide: https://pandas.pydata.org/docs/user_guide/groupby.html
