# Module 2 Exercises: Exploring the 5D Flavor Space

## Exercise 2.1: Dataset Exploration and Verification (15 min)
**Objective:** Load `recipes.csv`, inspect summary statistics, and verify dataset integrity.

**Problem Statement:**
You have been tasked with validating the culinary dataset before it enters the recommendation pipeline. Write a Python script to verify:
1. The total number of rows and columns.
2. The presence of any missing (`NaN` or `None`) values across all columns.
3. The minimum, maximum, mean, and standard deviation for each of the five flavor dimensions.

**Requirements:**
- Load `data/recipes.csv` using `pathlib.Path` and `pandas`.
- Print clean formatted output answering all three verification requirements.
- Identify which flavor dimension has the highest variance.

**Acceptance Criteria:**
- [ ] Confirms exactly 24 rows and 7 columns.
- [ ] Verifies 0 missing values across all columns.
- [ ] Displays `.describe()` summary statistics for all 5 features.
- [ ] Correctly identifies `sweet` (or `spice`) as having the highest standard deviation (~1.50).

---

## Exercise 2.2: Cuisine Flavor Profiling (15 min)
**Objective:** Group recipes by cuisine and identify distinguishing culinary characteristics.

**Problem Statement:**
Write a Python script that calculates the mean flavor profile for each cuisine in `recipes.csv` and answers the following questions:
1. Which cuisine has the highest average `spice` rating?
2. Which cuisine has the highest average `savory` rating?
3. Which cuisine has the highest average `sour` rating?
4. Identify two recipes from different cuisines that have identical or nearly identical flavor scores.

**Requirements:**
- Use `df.groupby("cuisine")[FEATURES].mean()`.
- Format results to 2 decimal places.
- Provide written answers to questions 1-4 with supporting data from the table.

**Acceptance Criteria:**
- [ ] Correctly computes cuisine mean table.
- [ ] Identifies Thai as highest in average spice.
- [ ] Identifies Indian and Spanish as tied for highest in savory (5.00).
- [ ] Identifies French and Thai as highest in sour.
- [ ] Identifies Taco (Mexican) and Kimchi Fried Rice (Korean) as having identical coordinates `[4, 1, 4, 3, 2]`.

---

## Exercise 2.3: Building Custom Dish Vectors (15 min)
**Objective:** Extract feature matrices and manually create new dish profiles.

**Problem Statement:**
Create a small testing DataFrame containing 3 new dishes:
1. `"Chocolate Lava Cake"`: American / Dessert, scores `[1, 5, 3, 1, 1]`
2. `"Tom Kha Gai"`: Thai, scores `[3, 2, 4, 4, 2]`
3. `"Guacamole with Chips"`: Mexican, scores `[2, 1, 3, 3, 3]`

**Requirements:**
- Construct a pandas DataFrame with columns `["name", "cuisine", "spice", "sweet", "savory", "sour", "veggie"]`.
- Extract the 2D feature matrix using `df[FEATURES]`.
- Verify that the shape of the extracted matrix is `(3, 5)`.
- Convert the feature matrix to a NumPy array and print its data type and layout.

**Acceptance Criteria:**
- [ ] DataFrame successfully instantiated with correct values.
- [ ] Sliced feature matrix has shape `(3, 5)`.
- [ ] NumPy conversion verified with `.to_numpy()` or `.values`.
