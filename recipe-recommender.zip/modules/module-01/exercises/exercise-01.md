# Module 1 Exercises: Recommendation Concepts & Problem Formulation

## Exercise 1.1: Recommender System Paradigm Classification (15 min)
**Objective:** Distinguish between content-based filtering and collaborative filtering based on problem requirements.

**Problem Statement:**
A culinary startup is launching three new digital features. For each scenario below, identify whether the feature should be powered by **Content-Based Filtering** or **Collaborative Filtering**, and justify your decision:
1. Feature A: Recommending recipes to a brand-new user who has never rated any dish, based on three flavor sliders they set on their profile (e.g. "I love spice, hate sweets").
2. Feature B: "Customers who cooked Pad Thai also loved cooking Chicken Tikka Masala," based on the cooking logs of 50,000 active subscribers.
3. Feature C: Automatically suggesting side dishes for a brand-new artisanal soup that was added to the platform 5 minutes ago.

**Requirements:**
- State the recommended paradigm for all three scenarios.
- Provide a 2-3 sentence justification for each scenario referencing item attributes versus interaction logs.
- Reference the "cold start problem" in your explanations where applicable.

**Acceptance Criteria:**
- [ ] Feature A correctly identified as Content-Based Filtering.
- [ ] Feature B correctly identified as Collaborative Filtering.
- [ ] Feature C correctly identified as Content-Based Filtering.
- [ ] Cold start problem correctly explained in the context of Feature A and Feature C.

---

## Exercise 1.2: Mapping Dishes to Coordinate Vectors (15 min)
**Objective:** Transform descriptive culinary profiles into numerical coordinates in a multi-dimensional feature space.

**Problem Statement:**
You are given descriptions of three dishes not currently in the dataset:
- **Dish 1 (Spicy Buffalo Wings)**: Extremely spicy (5), not sweet (1), highly savory and umami (5), mildly acidic/tangy from vinegar (3), minimal vegetables (1).
- **Dish 2 (Fresh Green Salad)**: No spice (1), very low sweetness (1), low savory (2), tangy lemon dressing (4), completely vegetable-based (5).
- **Dish 3 (Apple Pie)**: Mild warm spice from cinnamon (2), very sweet (5), moderate buttery savory pastry (2), mild tartness from green apples (3), low vegetable/plant freshness (1).

**Requirements:**
1. Express each dish as a 5D coordinate vector in the format `[spice, sweet, savory, sour, veggie]`.
2. Compute the component-wise difference between Dish 1 and Dish 2.
3. Based on the coordinate vectors, state which two dishes are most dissimilar, and explain why.

**Acceptance Criteria:**
- [ ] All three 5D vectors correctly constructed.
- [ ] Component differences between Dish 1 and Dish 2 calculated accurately.
- [ ] Detailed justification explaining why Dish 1 and Dish 2 (or Dish 1 and Dish 3) have maximum spatial divergence.

---

## Exercise 1.3: Supervised vs. Unsupervised Machine Learning Contrast (15 min)
**Objective:** Articulate the architectural differences between supervised classification and unsupervised nearest neighbor retrieval.

**Problem Statement:**
A junior machine learning developer looks at `main.py` and says:
*"Why didn't the author use `train_test_split` to measure the accuracy of our recipe recommender? Without an accuracy score, how do we know the model learned anything?"*

Write a structured response to this developer explaining:
1. Why `main.py` is an unsupervised model, not a supervised classification model.
2. Why `train_test_split` is counter-productive when indexing an item catalog for recommendation.
3. How recommender systems are evaluated in the absence of classification accuracy.

**Acceptance Criteria:**
- [ ] Accurately defines unsupervised learning in the context of `NearestNeighbors`.
- [ ] Explains that withholding catalog items in a test set prevents those items from being recommended.
- [ ] Suggests at least two alternative evaluation metrics for recommenders (e.g., user click-through rate, similarity correlation, serendipity, catalog coverage).
