# Lesson 02: Content-Based Filtering vs. Collaborative Filtering

**Lesson ID:** lesson-02  
**Module:** module-01  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
The purpose of this lesson is to contrast the two dominant paradigms in recommendation systems: content-based filtering and collaborative filtering. By the end of this lesson, you will be able to:
- Define content-based filtering and explain how it operates on item attributes.
- Define collaborative filtering and explain how it leverages community interaction matrices.
- Compare the strengths, weaknesses, and data requirements of both approaches.
- Articulate why content-based filtering is ideal for the Recipe Recommender project.

## Prerequisites
Familiarity with Lesson 01 (introduction to recommender systems).

## Concept Explanation
### The two great paradigms of recommender systems
When software engineers design a recommendation engine, they choose between two primary algorithmic philosophies:

```
+---------------------------------------------------------------------------------+
|                       RECOMMENDATION SYSTEM PARADIGMS                           |
+---------------------------------------------------------------------------------+
|                                                                                 |
|   1. CONTENT-BASED FILTERING                   2. COLLABORATIVE FILTERING       |
|   "Show me more items like what I like"        "Show me what people like me     |
|                                                 also liked"                     |
|                                                                                 |
|   Focus: Item Attributes                       Focus: Community Behavior        |
|   Input: Flavor, genre, author, tempo          Input: Star ratings, views, buys |
|   User history: Only the current user          User history: Thousands of users |
|   New item handling: Excellent (instant)       New item handling: Poor          |
|                                                      (Cold Start problem)       |
|                                                                                 |
+---------------------------------------------------------------------------------+
```

### 1. Collaborative Filtering
Collaborative filtering relies on the collective wisdom of crowds. It constructs a large matrix where rows represent users and columns represent items (e.g., movies or songs), filled with ratings from 1 to 5 stars.
- If User A and User B rated 20 of the same movies identically, the system infers that User A and User B share cinematic tastes.
- If User B recently watched and loved a new sci-fi film that User A hasn't seen yet, the system recommends that film to User A.
- **Major Advantage**: It requires no domain knowledge about the items. The algorithm does not need to know what happens in a movie; it only needs to know who clicked or rated it.
- **Major Disadvantage**: The **Cold Start Problem**. If a chef introduces a brand-new recipe to the platform, nobody has rated it yet. A collaborative filtering algorithm is completely blind to it and cannot recommend it.

### 2. Content-Based Filtering
Content-based filtering focuses entirely on the intrinsic characteristics and descriptive metadata of the items themselves.
- In music, Pandora's "Music Genome Project" analyzes songs based on acoustic attributes: bassline intensity, syncopation, vocal harmony, and distortion.
- In our Recipe Recommender, we analyze dishes based on sensory taste attributes: spice level, sweetness, umami savoriness, acidity/sourness, and vegetable freshness.
- When you tell the system: *"I like Margherita Pizza,"* the system looks at Margherita Pizza's profile: high savory (5), moderate sour/acidic tomato (3), mild spice (2), low sweetness (2). It then queries the catalog for items with matching profiles.
- **Major Advantage**: Works immediately on new items! The moment a chef logs the flavor profile of a new dish, it can be recommended immediately without waiting for hundreds of customer reviews.
- **Major Disadvantage**: It tends to create "filter bubbles" where users are only recommended items that closely match what they already know.

## Relevant Code (from main.py, lines 27, 37-52)
```python
FEATURES = ["spice", "sweet", "savory", "sour", "veggie"]

def recommend(recipe_name: str, n: int = 3) -> pd.DataFrame:
    ...
```

## Code Explanation
- **Line 27**: `FEATURES` explicitly specifies the content attributes used to characterize every dish. Because we recommend based on these five features rather than user rating logs, this is a pure content-based recommendation engine.
- **Lines 37-52**: The `recommend()` function takes a single `recipe_name` as an item query. It retrieves the item's flavor attributes and finds other items with matching attributes in the catalog.

## Worked Example
Imagine you are building a recommendation feature for an indie game store.
- **Collaborative Filtering approach**: You wait until 10,000 players buy and review games. If players who loved *Hollow Knight* also bought *Celeste*, you recommend *Celeste*.
- **Content-Based Filtering approach**: You tag games with descriptive attributes: `[platforming_difficulty: 5, pixel_art: 5, atmospheric_music: 5]`. As soon as a brand-new indie game launches today with those exact tags, you can immediately recommend it to *Hollow Knight* fans.

In `main.py`, our dataset has only 24 recipes and no user rating history. Collaborative filtering is impossible here, but content-based filtering thrives!

## Step-by-Step Student Instructions
1. Open `data/recipes.csv` in your text editor.
2. Examine the header row: `name,cuisine,spice,sweet,savory,sour,veggie`.
3. Notice that there are no columns for `user_id`, `rating`, or `timestamp`.
4. Reflect on why collaborative filtering cannot be trained on this CSV.
5. In your notebook, write down the definition of content-based filtering in your own words.

## Expected Output or Observable Behaviour
When analyzing the code and dataset, you observe that the recommendations produced by `main.py` depend solely on the numerical values in `FEATURES`. If you modify the `sweet` rating of a recipe in `data/recipes.csv`, its nearest neighbors shift accordingly.

## Practical Exercises
1. **Exercise 2.1**: Which recommendation technique (collaborative or content-based) would you choose for an online bookstore that sells rare, out-of-print historical manuscripts with very few buyers? Explain why.
2. **Exercise 2.2**: If a user has an allergic reaction to peanuts, why is a content-based recommender safer and more reliable than a collaborative recommender?
3. **Exercise 2.3**: What is the "cold start problem", and how does content-based filtering solve it for newly published items?

## Common Mistakes and Debugging
| Mistake | Why it happens | How to resolve |
|---|---|---|
| Assuming collaborative filtering requires item descriptions | People assume AI always reads item details | Remember collaborative filtering only looks at the user-item interaction matrix |
| Thinking content-based filtering requires multiple users | Confusing user modeling with item modeling | Content-based filtering can make recommendations for a single user given just one query item |
| Overlooking the filter bubble limitation | Assuming content-based filtering is always superior | Recognize that content-based recommenders need serendipity mechanisms (like our "surprise me" feature) to introduce variety |

## Best Practices and Security Considerations
- **Cold-Start Resilience**: Build content-based fallbacks into commercial recommendation systems so that newly cataloged inventory is never hidden from customers.
- **Explainability**: Content-based recommendations are inherently interpretable. You can always explain: *"We recommended this lasagna because it shares high savory and moderate acidity scores with your favorite pizza."*

## Summary
Recommender systems predominantly use either collaborative filtering (analyzing user interaction patterns) or content-based filtering (analyzing item feature profiles). Because our recipe dataset contains detailed sensory dimensions and no historical user ratings, the Recipe Recommender utilizes content-based filtering.

## Knowledge-check Questions
1. What data does collaborative filtering require that content-based filtering does not?
2. What is the "cold start problem"?
3. Why does the Recipe Recommender project use content-based filtering instead of collaborative filtering?
4. What is a key disadvantage of content-based filtering?
5. How does Pandora's "Music Genome Project" relate to the methodology used in this project?

## References
- Google Machine Learning Crash Course on Recommendation Systems: https://developers.google.com/machine-learning/recommendation/content-based/basics
- Collaborative Filtering vs Content-Based Filtering: https://towardsdatascience.com/brief-on-recommender-systems-b86a1068a4dd
