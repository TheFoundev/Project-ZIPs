# Lesson 03: The 5D Flavor Space Intuition

**Lesson ID:** lesson-03  
**Module:** module-01  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
The purpose of this lesson is to develop geometric intuition for multi-dimensional feature spaces. By the end of this lesson, you will be able to:
- Conceptualize physical items as coordinate vectors in a mathematical vector space.
- Visualize transitioning from 1D, 2D, and 3D geometric spaces to a 5-dimensional flavor space.
- Understand how distance between points represents flavor divergence.
- Map culinary taste attributes to numeric coordinates.

## Prerequisites
Familiarity with Cartesian coordinates $(x, y)$ from basic geometry.

## Concept Explanation
### From points on a graph to points in flavor space
In middle school math, you learned how to plot a point on a 2-dimensional grid $(x, y)$. 
- The horizontal axis $x$ might represent distance.
- The vertical axis $y$ might represent height.
- A point $(3, 4)$ represents a unique location in that 2D space.

If you add a third axis $z$ (depth), you get a 3-dimensional space $(x, y, z)$, like the physical room you are sitting in right now. 

Now, imagine that instead of physical space, our coordinate axes represent **sensory taste dimensions**:
- Axis 1: **Spice** (1 = mild, 5 = fiery hot)
- Axis 2: **Sweet** (1 = unsweetened, 5 = sugary dessert)
- Axis 3: **Savory** (1 = bland, 5 = deep umami/salty)
- Axis 4: **Sour** (1 = alkaline/neutral, 5 = acidic/tart)
- Axis 5: **Veggie** (1 = meat/grain heavy, 5 = leafy fresh/plant-centric)

```
        Spice (Axis 1)
           ^
           |        * Spicy Ramen [5, 1, 5, 2, 2]
           |
           |
           +-------------------> Sweet (Axis 2)
          /                    * Chocolate Cake [1, 5, 2, 1, 1]
         /
        v
      Savory (Axis 3)
```

Although the human brain cannot physically picture a 5-dimensional room, the mathematics of coordinates works **identically in 5 dimensions as it does in 2 or 3 dimensions**.
Every recipe is simply a vector of 5 numbers:
$$\mathbf{x} = [x_{	ext{spice}}, x_{	ext{sweet}}, x_{	ext{savory}}, x_{	ext{sour}}, x_{	ext{veggie}}]$$

### Distance as taste difference
In physical space, if two towns have coordinates close to each other, you can walk between them quickly. In flavor space, if two recipes have coordinates close to each other, they **taste similar**:
- **Chocolate Cake**: `[1, 5, 2, 1, 1]`
- **Pancakes**: `[1, 5, 2, 1, 1]`
The distance between Chocolate Cake and Pancakes is $0$. They occupy the exact same coordinate in flavor space! Both are rich, sweet, low-spice, low-sour, grain/batter-based treats.

In contrast:
- **Spicy Ramen**: `[5, 1, 5, 2, 2]`
Comparing Spicy Ramen to Chocolate Cake:
- Difference in Spice: $5 - 1 = 4$
- Difference in Sweet: $1 - 5 = -4$
- Difference in Savory: $5 - 2 = 3$
These large differences mean the two dishes are situated on opposite ends of our 5D flavor universe.

## Relevant Code (from main.py, lines 27, 33)
```python
FEATURES = ["spice", "sweet", "savory", "sour", "veggie"]

...
scaled_features = scaler.fit_transform(df[FEATURES])
```

## Code Explanation
- **Line 27**: `FEATURES` defines the names of the five coordinate axes.
- **Line 33**: `df[FEATURES]` extracts only these 5 columns from the tabular DataFrame, creating a mathematical matrix with 24 rows and 5 columns. Each row is a 5D coordinate point representing one recipe.

## Worked Example
Let us compute the coordinate difference between **Margherita Pizza** and **Lasagna** using their raw values from `recipes.csv`:
- Margherita Pizza: `[2, 2, 5, 3, 2]`
- Lasagna: `[2, 2, 5, 2, 2]`

Subtract the coordinate values component by component:
- $\Delta	ext{spice} = 2 - 2 = 0$
- $\Delta	ext{sweet} = 2 - 2 = 0$
- $\Delta	ext{savory} = 5 - 5 = 0$
- $\Delta	ext{sour} = 3 - 2 = 1$
- $\Delta	ext{veggie} = 2 - 2 = 0$

Only one dimension differs by a single unit (Margherita has slightly more tomato acidity/sourness than Lasagna). Because they are separated by only 1 unit in one axis and 0 in all others, they are close neighbors in 5D flavor space!

## Step-by-Step Student Instructions
1. Open `data/recipes.csv` and locate the row for `Tom Yum Soup`.
2. Write down its 5 flavor coordinates: `[spice=5, sweet=1, savory=4, sour=5, veggie=2]`.
3. Locate `Spicy Ramen`: `[spice=5, sweet=1, savory=5, sour=2, veggie=2]`.
4. Which taste dimension separates Tom Yum Soup from Spicy Ramen the most? (Notice the `sour` score: 5 vs 2).
5. Explain why this matches your real-world culinary intuition (Tom Yum is a hot and sour Thai soup, whereas Ramen is savory and rich).

## Expected Output or Observable Behaviour
You should observe that dishes from different culinary traditions (e.g., Thai Tom Yum Soup and Japanese Spicy Ramen) can sit remarkably close together in flavor space because their sensory profiles overlap significantly.

## Practical Exercises
1. **Exercise 3.1**: Create coordinates for a dish not currently in the dataset (e.g., *Lemon Gelato*). Rate it on a 1-5 scale across `spice, sweet, savory, sour, veggie`.
2. **Exercise 3.2**: In a 2D space where Axis $X$ is Sweet and Axis $Y$ is Savory, plot Margherita Pizza (Sweet=2, Savory=5) and Blueberry Muffin (Sweet=4, Savory=2).
3. **Exercise 3.3**: Why is it mathematically impossible to draw a literal 5-dimensional graph on a 2D sheet of paper, and how do data scientists visualize high-dimensional data?

## Common Mistakes and Debugging
| Mistake | Why it happens | How to resolve |
|---|---|---|
| Believing 5D math is different from 2D math | People think higher dimensions require exotic non-Euclidean mathematics | Recognize that distance formulas generalize seamlessly to any number of dimensions |
| Confusing categorical data with continuous coordinates | Trying to plot words like "Italian" as a spatial axis | Recognize that only numerical features (the 1-5 ratings) serve as spatial coordinate axes |
| Ignoring feature scale differences | Assuming all features have identical distributions | In later modules, we use `StandardScaler` to ensure all axes have equal variance |

## Best Practices and Security Considerations
- **Dimensionality Reduction**: In large commercial systems with hundreds of features (e.g., text embeddings with 768 dimensions), data scientists use techniques like PCA or t-SNE to project high-dimensional spaces down to 2D for human inspection.
- **Feature Selection**: Only include features that directly influence the user's perception of similarity. Adding irrelevant dimensions (like recipe prep time in minutes) without scaling can distort taste similarity.

## Summary
By treating sensory attributes as orthogonal coordinate axes, recipes can be represented as vectors in a 5-dimensional flavor space. Spatial proximity in this mathematical space corresponds directly to similarity in taste, providing the geometric foundation for nearest neighbor recommendations.

## Knowledge-check Questions
1. What are the five coordinate axes that define our project's flavor space?
2. What are the flavor coordinates of Chocolate Cake in `recipes.csv`?
3. Which other recipe shares the exact same flavor coordinates as Chocolate Cake?
4. How does spatial proximity in flavor space translate to culinary taste?
5. Why is multi-dimensional vector representation useful for machine learning algorithms?

## References
- Vector Spaces in Machine Learning: https://en.wikipedia.org/wiki/Vector_space
- Visualizing High-Dimensional Data (Distill.pub): https://distill.pub/2016/misread-tsne/
