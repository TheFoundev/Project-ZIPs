# Lesson 01: Welcome to the Recipe Recommender & Recommendation Systems

**Lesson ID:** lesson-01  
**Module:** module-01  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
The purpose of this lesson is to introduce the core problem solved by the Recipe Recommender and connect it to modern digital recommender systems. By the end of this lesson, you will be able to:
- State the machine learning objective of the Recipe Recommender project.
- Explain the significance of recommender systems in modern web and mobile applications (e.g., Netflix, Spotify, Amazon).
- Describe how an algorithmic system can capture human taste preferences without requiring human tastebuds.
- Navigate the project repository structure and identify the primary script and data files.

## Prerequisites
None. A curious mind and an interest in how algorithms understand food and user preferences.

## Concept Explanation
### The recommendation problem in modern software
Every day, billions of people interact with recommendation systems. When you open Spotify, your "Discover Weekly" playlist suggests songs you have never heard before. When you finish a series on Netflix, the platform suggests three movies that match your viewing habits. When you shop on Amazon, you see "Customers who bought this also bought..."

At their core, all recommender systems solve a fundamental information retrieval challenge:
$$\\text{Given a catalog of items and a user's known preference, what unobserved items are most likely to satisfy the user?}$$

In culinary applications—such as recipe websites, meal-kit subscription delivery services, or grocery delivery apps—recommending recipes is critical. If a home cook enjoys preparing a spicy bowl of ramen, what should they cook tomorrow? If a diner loves Margherita Pizza, what other dishes will satisfy their craving for rich tomato sauce, melted cheese, and aromatic herbs?

### How algorithms "taste" food
Computers cannot eat, smell, or taste. However, computers excel at computing mathematical relationships across numbers. If we can represent the taste of a dish as a set of numerical scores—such as how spicy, sweet, savory, sour, or vegetable-heavy it is—then food becomes data. Once recipes are represented as numbers, finding a recipe that tastes like Margherita Pizza becomes a problem of calculating which numbers are closest together.

The **Recipe Recommender** project takes 24 diverse international recipes, measures their sensory taste characteristics across five distinct dimensions, and uses machine learning to find the closest culinary cousins for any given meal.

## Relevant Code (from main.py, lines 1-9)
```python
"""Project 18: The Recipe Recommender (K-Nearest Neighbours).

Run:
    python main.py

Recipes are points in a five-dimensional flavour space.  The recommender
finds the closest points and suggests them, with a "surprise me" option for
a different cuisine.
"""
```

## Code Explanation
- **Lines 1-2**: The module docstring introduces the project number (Project 18) and the core algorithm: K-Nearest Neighbours.
- **Lines 3-4**: Explains the execution entrypoint (`python main.py`).
- **Lines 6-8**: Summarizes the foundational mathematical intuition: recipes are treated as points in a five-dimensional flavor space. The recommender identifies the closest points (nearest neighbors) and introduces a serendipity mechanism: a "surprise me" option that discovers alternative cuisines.

## Worked Example
Suppose you run a restaurant ordering app. A user orders a bowl of **Spicy Ramen**. 
- The user's implicit feedback is clear: they enjoy bold, hot, savory, comforting noodle soups.
- Without an AI recommender, the app might simply list other items alphabetically or randomly, suggesting a sugary donut or a mild vanilla pudding.
- With a nearest-neighbor recommender, the system queries the flavor database:
  - Dish A (Vanilla Cupcake): High sweetness, zero spice, low savory. Distance: Very Large.
  - Dish B (Chicken Tikka Masala): High spice, rich savory umami, moderate sweetness. Distance: Very Small.
  - Dish C (Kimchi Fried Rice): High spice, savory fermented flavor, tangy sour notes. Distance: Very Small.
The system automatically recommends Chicken Tikka Masala and Kimchi Fried Rice because their flavor coordinates are geographically proximate in taste space.

## Step-by-Step Student Instructions
1. Open your terminal and navigate to the project directory:
   ```bash
   cd "beginner-projects-main/AI-ML Beginners/projects/18_recipe_recommender"
   ```
2. Inspect the project directory using `ls -la`. Note `main.py`, the `data/` directory, and the `outputs/` directory.
3. Open `main.py` in your code editor and read the docstring on lines 1-9.
4. Run the script once using `python main.py` to see the algorithm in action.
5. Observe the console output displaying recommendations for Margherita Pizza, Spicy Ramen, and Chocolate Cake.

## Expected Output or Observable Behaviour
When executing `python main.py`, the terminal outputs:
```text
============================================================
THE RECIPE RECOMMENDER
============================================================

If you like Margherita Pizza, try:
  Lasagna                (Italian       ) similarity 0.52
  Paella                 (Spanish       ) similarity 0.46
  Mushroom Risotto       (Italian       ) similarity 0.42

If you like Spicy Ramen, try:
  Chicken Tikka Masala   (Indian        ) similarity 0.49
  Kimchi Fried Rice      (Korean        ) similarity 0.40
  Taco                   (Mexican       ) similarity 0.40
```
This confirms that the recommender successfully reads recipes, evaluates similarity, and ranks candidate dishes.

## Practical Exercises
1. **Exercise 1.1**: Think of your favorite movie or song streaming platform. Identify three distinct ways the platform suggests new content to you.
2. **Exercise 1.2**: Write down three recipes you personally enjoy. For each recipe, list two other dishes you feel have a similar taste profile.
3. **Exercise 1.3**: Explain in one paragraph why a simple keyword search (e.g. searching for the word "soup") is less effective than analyzing continuous flavor profiles.

## Common Mistakes and Debugging
| Mistake | Why it happens | How to resolve |
|---|---|---|
| Assuming the model reads recipe ingredients directly | Beginners often think AI reads long recipe text paragraphs | Understand that text has been distilled into numerical sensory scores |
| Expecting the recommender to predict ratings | Confusing ranking/similarity with rating regression | Notice that this project calculates similarity scores between items |
| Running the script from the wrong directory | File path resolution errors when running `python 18_recipe_recommender/main.py` | Ensure your terminal is in the project folder containing `data/recipes.csv` |

## Best Practices and Security Considerations
- **Data Privacy**: Pure content-based recommenders only analyze item attributes, meaning they require zero personal user tracking or private identity data to function.
- **Graceful Degradation**: Always provide fallback recommendations (such as popular items or serendipity options) in case a query item is missing from the catalog.

## Summary
The Recipe Recommender uses machine learning to solve culinary discovery. By encoding dishes as points in a multi-dimensional sensory space, the system algorithmically identifies dishes with similar taste properties. This forms the foundation of content-based recommendation systems used worldwide.

## Knowledge-check Questions
1. What is the fundamental question that a recommendation system attempts to answer?
2. How does the Recipe Recommender represent food if computers cannot taste or smell?
3. What are the three example dishes evaluated in the default `main.py` script?
4. What algorithm is indicated in the docstring of `main.py`?
5. Why does the recommender include a "surprise me" feature?

## References
- Recommender Systems Handbook (Ricci et al.): https://link.springer.com/book/10.1007/978-1-4899-7637-6
- Overview of Recommendation Systems on Google Developers: https://developers.google.com/machine-learning/recommendation
- Scikit-learn Nearest Neighbors Guide: https://scikit-learn.org/stable/modules/neighbors.html
