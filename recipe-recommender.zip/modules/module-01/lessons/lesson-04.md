# Lesson 04: Supervised Classification vs. Unsupervised Nearest Neighbors

**Lesson ID:** lesson-04  
**Module:** module-01  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
The purpose of this lesson is to highlight the crucial architectural difference between supervised classification and unsupervised nearest neighbor retrieval. By the end of this lesson, you will be able to:
- Contrast supervised machine learning with unsupervised machine learning.
- Explain the key differences between `KNeighborsClassifier` and `NearestNeighbors` in scikit-learn.
- Understand why the Recipe Recommender is the **only project** among the 19 beginner projects that uses unsupervised nearest neighbors.
- Explain why a train/test split is neither necessary nor appropriate for this recommendation task.

## Prerequisites
Familiarity with Lessons 01-03.

## Concept Explanation
### Supervised Learning vs. Unsupervised Learning
In the vast landscape of machine learning, algorithms are divided into two primary paradigms:

```
+---------------------------------------------------------------------------------+
|                         MACHINE LEARNING PARADIGMS                              |
+---------------------------------------------------------------------------------+
|                                                                                 |
|   SUPERVISED LEARNING                            UNSUPERVISED LEARNING          |
|   (Predicting known targets)                     (Finding intrinsic structure)  |
|                                                                                 |
|   - Requires features X AND labels y             - Requires features X only     |
|   - Examples:                                    - Examples:                    |
|     * Predicting house price (Regression)          * Grouping customers         |
|     * Classifying spam vs ham (Classification)       (Clustering)               |
|     * Recognizing iris species (Classification)    * Finding similar recipes    |
|   - Scikit-learn estimator:                          (NearestNeighbors)         |
|     KNeighborsClassifier                         - Scikit-learn estimator:      |
|                                                    NearestNeighbors             |
+---------------------------------------------------------------------------------+
```

### The 19 Beginner Projects Context
In your journey through the 19 beginner AI/ML projects:
- Projects 01-17 and 19 build **supervised models**: models that take inputs $X$ and learn to predict a target label $y$ (such as predicting cups of lemonade sold, predicting flower species, or detecting spam).
- **Project 18 (The Recipe Recommender) is completely unique**: It is the **only project** that uses **unsupervised nearest neighbors**. 
- There is no "correct answer" or target label $y$. We are not predicting whether a recipe is "tasty" or "bad". We are not classifying recipes into categories.
- Instead, we are building a spatial index over the item catalog so that we can ask geometric questions: *"Which points are closest to Point X?"*

### `NearestNeighbors` vs. `KNeighborsClassifier`
Many beginners confuse these two scikit-learn classes:
1. `KNeighborsClassifier`:
   - Requires both `X` and `y` during `fit(X, y)`.
   - When given a new data point, it looks at the $k$ nearest training neighbors, takes a **majority vote** of their categorical labels, and outputs a predicted class label (e.g. `"Italian"` or `"Spicy"`).
2. `NearestNeighbors`:
   - Requires only `X` during `fit(X)` (unsupervised).
   - Has no target labels and performs no voting.
   - When queried with a data point via `model.kneighbors()`, it returns the **exact indices** and **geometric distances** of the closest items in the catalog.

### Why no Train/Test split?
In supervised learning, you split data into training and test sets (e.g., 75% train, 25% test) to verify whether the model can generalize to unseen samples without overfitting.
In catalog recommendation:
- The model is a **search index** over available inventory.
- If you were to withhold 25% of the recipes into a "test set", those recipes would disappear from the search index, meaning the system could never recommend them to any user!
- Therefore, in content-based item retrieval, the nearest neighbor model is fit on **all available catalog data**.

## Relevant Code (from main.py, lines 19, 34-35)
```python
from sklearn.neighbors import NearestNeighbors

...
model = NearestNeighbors(n_neighbors=6, metric="euclidean")
model.fit(scaled_features)
```

## Code Explanation
- **Line 19**: Imports `NearestNeighbors` from `sklearn.neighbors` (note: **not** `KNeighborsClassifier`).
- **Line 34**: Instantiates `NearestNeighbors` with `n_neighbors=6` and `metric="euclidean"`.
- **Line 35**: Calls `model.fit(scaled_features)` with only the feature array. Notice there is no second argument `y`! This is the hallmark of an unsupervised learning algorithm.

## Worked Example
Suppose a student accidentally wrote:
```python
# INCORRECT APPROACH
from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier(n_neighbors=3)
model.fit(scaled_features)  # FAILS: TypeError!
```
Python will immediately raise a `TypeError: fit() missing 1 required positional argument: 'y'`. `KNeighborsClassifier` insists on having target labels $y$ to learn classification rules.

In contrast, `NearestNeighbors`:
```python
# CORRECT APPROACH (as in main.py)
from sklearn.neighbors import NearestNeighbors
model = NearestNeighbors(n_neighbors=6, metric="euclidean")
model.fit(scaled_features)  # SUCCEEDS!
distances, indices = model.kneighbors(query_point)
```
`NearestNeighbors` happily indexes the points and enables distance and index queries.

## Step-by-Step Student Instructions
1. Open `main.py` and inspect lines 19-35.
2. Verify that there is no `from sklearn.model_selection import train_test_split` statement.
3. Verify that `model.fit()` receives only `scaled_features`.
4. Open your Python terminal and try importing both classes:
   ```python
   from sklearn.neighbors import NearestNeighbors, KNeighborsClassifier
   ```
5. Check their docstrings using `help(NearestNeighbors)` and notice the phrase "Unsupervised learner for implementing neighbor searches".

## Expected Output or Observable Behaviour
You observe that `model.fit(scaled_features)` runs in less than 1 millisecond. Because `NearestNeighbors` is an instance-based (memory-based) learner, `fit()` simply structures the points into an optimized spatial search tree (like a BallTree or KDTree).

## Practical Exercises
1. **Exercise 4.1**: In your own words, summarize why the Recipe Recommender does not require a target label $y$.
2. **Exercise 4.2**: If you wanted to turn this project into a supervised classification task, what column in `recipes.csv` could serve as the label $y$, and what would the model predict?
3. **Exercise 4.3**: Explain why applying a 75/25 train/test split to an online store's catalog search index would harm the user experience.

## Common Mistakes and Debugging
| Mistake | Why it happens | How to resolve |
|---|---|---|
| Importing `KNeighborsClassifier` instead of `NearestNeighbors` | Confusing the two scikit-learn estimators | Ensure you import `NearestNeighbors` for unsupervised similarity search |
| Attempting to call `model.predict()` | Expecting a prediction method like in supervised learning | Use `model.kneighbors()` to query neighbors and distances |
| Trying to compute classification accuracy | Expecting an accuracy score like 92% | Measure recommendations using similarity scores and user satisfaction metrics |

## Best Practices and Security Considerations
- **Algorithm Selection**: Always match your algorithm to the business objective. If your goal is to find similar entities, use unsupervised nearest neighbors; if your goal is to assign entities to pre-defined classes, use supervised classification.
- **Data Completeness**: In recommendation systems, ensure all items in the production catalog are indexed so no inventory is orphaned.

## Summary
The Recipe Recommender represents an unsupervised machine learning task. Rather than learning a mapping from features $X$ to target labels $y$ using `KNeighborsClassifier`, it uses `NearestNeighbors` to build a geometric search index over all recipes in the 5D flavor space. This allows the system to query item proximity directly without requiring labels or train/test splits.

## Knowledge-check Questions
1. Why does `NearestNeighbors.fit()` take only `X` and not `y`?
2. What does `model.kneighbors()` return instead of a class prediction?
3. What error occurs if you try to call `fit(X)` on a `KNeighborsClassifier` without providing `y`?
4. Why is no train/test split applied in the Recipe Recommender project?
5. How is this project distinct from the other 18 beginner AI/ML projects in the curriculum?

## References
- Scikit-learn Unsupervised Nearest Neighbors: https://scikit-learn.org/stable/modules/neighbors.html#unsupervised-nearest-neighbors
- Scikit-learn NearestNeighbors API: https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.NearestNeighbors.html
- Supervised vs Unsupervised Learning: https://www.ibm.com/think/topics/supervised-vs-unsupervised-learning
