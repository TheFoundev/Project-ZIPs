# Module 5 Exercises: Visualizing Recommendations & Flavor Space

## Exercise 5.1: Comparative Similarity Bar Charts (15 min)
**Objective:** Create customized horizontal bar charts comparing recommendations for different base recipes.

**Problem Statement:**
Write a Python script that generates two separate horizontal bar charts:
1. Chart 1: Top 5 recommendations for `"Margherita Pizza"` saved to `outputs/margherita_similarity.png`.
2. Chart 2: Top 5 recommendations for `"Chocolate Cake"` saved to `outputs/chocolate_cake_similarity.png`.

**Requirements:**
- Configure headless Matplotlib with `matplotlib.use("Agg")`.
- Use distinct color palettes: forest green (`"#27ae60"`) for Margherita Pizza, and deep chocolate brown (`"#5d4037"`) for Chocolate Cake.
- Set `xlim(0, 1)`, labels, titles, gridlines, and DPI=150.
- Ensure `plt.close(fig)` is called after saving each chart.

**Acceptance Criteria:**
- [ ] Both PNG files generated and saved to `outputs/`.
- [ ] Margherita Pizza chart displays Lasagna at top with green bars.
- [ ] Chocolate Cake chart displays Pancakes at top with similarity 1.00 and brown bars.
- [ ] Both figures closed cleanly with no open figure warnings.

---

## Exercise 5.2: Multi-Quadrant Flavor Space Scatter Plot (15 min)
**Objective:** Project all 24 recipes onto a 2D scatter plot and visually identify flavor clusters.

**Problem Statement:**
Create a 2D scatter plot visualizing **Spice (y-axis)** vs **Sweet (x-axis)** for all 24 recipes:
1. Plot all points using `ax.scatter()`.
2. Annotate each recipe with its name using `ax.annotate()`.
3. Draw horizontal and vertical dashed threshold lines at score 3.0 to divide the plot into 4 quadrants.
4. Add text labels to each quadrant:
   - Top-Left: "Fiery & Savory"
   - Bottom-Right: "Sweet & Mild"
   - Top-Right: "Sweet & Spicy"
   - Bottom-Left: "Mild & Savory"
5. Save the figure to `outputs/flavor_quadrants.png`.

**Acceptance Criteria:**
- [ ] `outputs/flavor_quadrants.png` generated successfully.
- [ ] 4 quadrants clearly demarcated by threshold lines at 3.0.
- [ ] All 24 dishes plotted and labeled.

---

## Exercise 5.3: Bar Chart Data Labeling (15 min)
**Objective:** Enhance horizontal bar charts with direct numerical data labels.

**Problem Statement:**
In `main.py`, viewers must visually trace bars down to the x-axis to read similarity scores. Enhance the horizontal bar chart for `"Spicy Ramen"` by adding direct numerical labels at the end of each bar using `ax.bar_label()`:
1. Format labels to 2 decimal places (e.g., `"0.49"`, `"0.40"`).
2. Add padding so labels sit 5 points to the right of each bar.
3. Save the enhanced chart to `outputs/labeled_similarity.png`.

**Acceptance Criteria:**
- [ ] Chart generated with numerical labels clearly visible next to each bar.
- [ ] Labels formatted to 2 decimal places.
