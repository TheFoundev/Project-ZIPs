# Lesson 04: Formatting, Aesthetic Polish, and Saving Plots

**Lesson ID:** lesson-04  
**Module:** module-05  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
The purpose of this lesson is to examine the formatting, aesthetic styling, and resource management practices used when generating figures in `main.py`. By the end of this lesson, you will be able to:
- Configure figure dimensions with `figsize` and layout spacing with `tight_layout()`.
- Set explicit axis boundaries, grid opacity, and descriptive typography.
- Save publication-quality figures using `dpi=150` and `bbox_inches="tight"`.
- Prevent memory leaks in automated applications using `plt.close(fig)`.

## Prerequisites
Completion of Lessons 01-03. Familiarity with Matplotlib figure configuration.

## Concept Explanation
### Professional Data Visualization Aesthetics
Creating a machine learning visualization is not just about plotting numbers; it is about communicating insights clearly and without distortion. Good visualization adheres to five core design principles:
1. **Explicit Scales**: `ax.set_xlim(0, 1)` anchors the similarity axis to the full possible range. Without this, Matplotlib would automatically zoom in to $[0.3, 0.5]$, making a 0.40 similarity look artificially tiny compared to 0.49.
2. **Subtle Background Grids**: Gridlines should assist the human eye in reading values across bars without competing for visual attention. Setting `alpha=0.25` softens lines so they do not overpower data.
3. **Harmonious Color Palettes**: Using `#e67e22` (burnt orange) conveys warmth and culinary flavor, avoiding garish primary colors.
4. **Clean Margins**: `bbox_inches="tight"` crops extraneous whitespace around figure borders, ensuring the saved PNG embeds cleanly in reports and documentation.
5. **Resolution Scaling**: Rendering at `dpi=150` produces sharp, high-density text and lines suitable for modern Retina/HiDPI screens.

```
+-----------------------------------------------------------------------------------+
|                        ANATOMY OF A POLISHED FIGURE                               |
+-----------------------------------------------------------------------------------+
|                                                                                   |
|  Title: Bold, informative, specifies query context                                |
|  Y-Axis: Left-aligned, readable recipe names                                      |
|  X-Axis: Fixed [0, 1] range with descriptive label                                |
|  Grid: Subtle vertical lines (alpha=0.25)                                         |
|  Memory: Closed immediately with plt.close(fig)                                  |
|                                                                                   |
+-----------------------------------------------------------------------------------+
```

### Memory Management and `plt.close(fig)`
In Python, Matplotlib keeps references to every open figure in a global state machine until they are explicitly destroyed.
If a long-running web server or automated recommender pipeline generates 1,000 similarity charts without closing them, Matplotlib will retain all 1,000 figures in RAM, eventually crashing the application with:
```text
MemoryError: Out of memory
```
Calling `plt.close(fig)` immediately after `fig.savefig()` cleans up the internal canvas buffers, releasing memory back to the operating system.

## Relevant Code (from main.py, lines 77, 82-85)
```python
fig, ax = plt.subplots(figsize=(8, 4.5))
...
ax.grid(axis="x", alpha=0.25)
fig.tight_layout()
fig.savefig(OUT / "similarity_scores.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```

## Code Explanation
- **Line 77**: Allocates an 8 by 4.5 inch canvas.
- **Line 82**: `ax.grid(axis="x", alpha=0.25)` applies vertical gridlines at 25% opacity.
- **Line 83**: `fig.tight_layout()` dynamically adjusts subplot parameters so that labels and titles fit comfortably within figure boundaries.
- **Line 84**: `fig.savefig(...)` writes the PNG to disk at 150 dots per inch, trimming whitespace with `bbox_inches="tight"`.
- **Line 85**: `plt.close(fig)` releases figure memory.

## Worked Example
Compare the output file size and visual sharpness between two configurations:
- **Configuration A (Default)**: `fig.savefig("out_default.png")` (72 DPI, default margins).
  - Lines appear slightly fuzzy on high-resolution laptop displays.
  - Generates awkward empty white margins around the edges.
- **Configuration B (Optimized, as in `main.py`)**: `fig.savefig("out_opt.png", dpi=150, bbox_inches="tight")`.
  - Text and bars are crisp, legible, and compact.
  - Image is immediately ready for inclusion in mobile apps or PDF reports.

## Step-by-Step Student Instructions
1. Open `main.py` in your code editor.
2. Examine lines 74-85.
3. Notice the specific arguments passed to `savefig()`: `dpi=150` and `bbox_inches="tight"`.
4. Run the script:
   ```bash
   python main.py
   ```
5. Check the generated file size and image resolution of `outputs/similarity_scores.png`:
   ```bash
   ls -lh outputs/similarity_scores.png
   ```
6. Observe that the file size is approximately 40-60 KB: lightweight yet visually sharp!

## Expected Output or Observable Behaviour
The terminal confirms:
```text
Saved: outputs/similarity_scores.png, outputs/recommendations.txt
```
The file `similarity_scores.png` exists in `outputs/`, rendered at $1200 \times 675$ pixels (8 inches $\times$ 150 DPI by 4.5 inches $\times$ 150 DPI).

## Practical Exercises
1. **Exercise 4.1**: Experiment with rendering at `dpi=300` (print quality). How does the file size of the PNG change?
2. **Exercise 4.2**: Add data labels directly onto the bars using `ax.bar_label()`. (Hint: `ax.bar_label(bars, fmt="%.2f", padding=3)`).
3. **Exercise 4.3**: Write a loop that generates and saves 10 charts without calling `plt.close()`. Check Matplotlib's warning message about having more than 20 figures open.

## Common Mistakes and Debugging
| Mistake | Why it happens | How to resolve |
|---|---|---|
| Forgetting `plt.close(fig)` | Assuming Python garbage collection frees figures automatically | Always call `plt.close(fig)` after saving figures |
| Recipe names cut off on left edge | Omission of `bbox_inches="tight"` or `tight_layout()` | Always pass `bbox_inches="tight"` to `savefig()` |
| Hardcoding output paths without pathlib | Writing `"outputs/plot.png"` which breaks if run from another folder | Use `OUT / "similarity_scores.png"` where `OUT` is a resolved `Path` |

## Best Practices and Security Considerations
- **Resolution Standards**: Use 150 DPI for web and screen displays; use 300 DPI for printed reports or academic publications.
- **Resource Cleanup**: Treat visualization canvases like open file handles or database connections: always close them when finished.

## Summary
Polishing visualizations requires thoughtful scale constraints (`xlim(0, 1)`), subtle gridlines (`alpha=0.25`), high-density rasterization (`dpi=150`), and automated whitespace trimming (`bbox_inches="tight"`). Calling `plt.close(fig)` guarantees safe memory management in automated production scripts.

## Knowledge-check Questions
1. What does the `figsize=(8, 4.5)` argument specify in `plt.subplots()`?
2. What does `alpha=0.25` control when configuring gridlines?
3. What is the purpose of `bbox_inches="tight"` during `savefig()`?
4. What DPI resolution is specified in `main.py`?
5. Why is `plt.close(fig)` necessary after saving a figure?

## References
- Matplotlib Figure savefig Documentation: https://matplotlib.org/stable/api/figure_api.html#matplotlib.figure.Figure.savefig
- Matplotlib Memory Management: https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.close.html
