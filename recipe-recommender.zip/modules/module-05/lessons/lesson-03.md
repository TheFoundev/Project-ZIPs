# Lesson 03: 2D Projections and Visualizing Multi-Dimensional Flavor Clusters

**Lesson ID:** lesson-03  
**Module:** module-05  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
The purpose of this lesson is to learn how to visualize 5-dimensional data using 2D scatter plot projections. By the end of this lesson, you will be able to:
- Explain the concept of dimensionality projection.
- Plot 2D scatter projections of selected flavor pairs (e.g., Spice vs. Sweet, Savory vs. Sour).
- Identify visual clusters formed by culinary categories (such as desserts clustering together).
- Interpret how geometric proximity in 2D reflects real-world taste commonalities.

## Prerequisites
Completion of Lessons 01 and 02. Understanding of scatter plots and 2D Cartesian coordinates.

## Concept Explanation
### Visualizing High Dimensions Through Projections
Our recipe dataset exists in a **5-dimensional space** (`spice, sweet, savory, sour, veggie`). Because human eyes and computer screens can only display 2 dimensions (or simulated 3D), we cannot view all 5 dimensions simultaneously.

To inspect how data is distributed, data scientists create **2-dimensional projections**:
A 2D projection selects **two features at a time** (e.g. Axis $X = \text{Sweet}$, Axis $Y = \text{Spice}$) and plots every recipe as a point on that plane, temporarily ignoring the other 3 dimensions.

```
       Spice
         ^
       5 |  * Spicy Ramen
         |  * Tom Yum Soup
       4 |  * Chicken Tikka Masala
         |  * Kimchi Fried Rice, Taco
       3 |  * Pad Thai, Burrito Bowl
       2 |  * Margherita Pizza, Lasagna, Paella
       1 |  * Sushi, Greek Salad                   * Pancakes, Chocolate Cake
         +------------------------------------------------------------------------> Sweet
            1           2           3           4           5
```

### Observing Culinary Clusters in 2D Projections
When we plot **Spice vs. Sweet**:
1. **The Dessert Cluster**: In the bottom-right corner (Sweet $\ge 4$, Spice $= 1$), dishes like *Pancakes*, *Chocolate Cake*, *Blueberry Muffin*, and *Lemon Tart* cluster tightly together.
2. **The Fiery Main Course Cluster**: In the top-left corner (Spice $\ge 4$, Sweet $\le 2$), dishes like *Spicy Ramen*, *Tom Yum Soup*, *Chicken Tikka Masala*, and *Kimchi Fried Rice* form a prominent culinary cluster.
3. **The Mild Savory Cluster**: In the lower-left corner (Spice $\le 2$, Sweet $\le 2$), European and Japanese dishes like *Margherita Pizza*, *Mushroom Risotto*, *Sushi*, and *Fish and Chips* assemble.

Even when looking through the "shadow" of just two dimensions, the natural grouping of food is unmistakable!

## Relevant Code (Concept Extension)
In `main.py`, a bar chart is generated. We can expand this with a 2D projection script:
```python
fig, ax = plt.subplots(figsize=(8, 6))
ax.scatter(df["sweet"], df["spice"], c="#e67e22", s=80, edgecolors="black", alpha=0.8)
for i, row in df.iterrows():
    ax.annotate(row["name"], (row["sweet"] + 0.1, row["spice"]), fontsize=8)
ax.set_xlabel("Sweetness Intensity (1-5)")
ax.set_ylabel("Spiciness Intensity (1-5)")
ax.set_title("2D Projection of Recipe Flavor Space (Sweet vs. Spice)")
ax.grid(True, linestyle="--", alpha=0.5)
```

## Code Explanation
- `ax.scatter(df["sweet"], df["spice"])`: Plots each recipe as a point using its sweetness as the horizontal coordinate and its spiciness as the vertical coordinate.
- `ax.annotate(...)`: Labels each point with its recipe name so viewers can identify which dot corresponds to which dish.
- `fontsize=8`: Keeps text legible without cluttering the plot.

## Worked Example
Let us examine the coordinates of four recipes on the Sweet vs. Spice projection:
- **Pancakes**: Sweet = 5, Spice = 1 $\implies$ Point $(5, 1)$
- **Chocolate Cake**: Sweet = 5, Spice = 1 $\implies$ Point $(5, 1)$
- **Spicy Ramen**: Sweet = 1, Spice = 5 $\implies$ Point $(1, 5)$
- **Pad Thai**: Sweet = 3, Spice = 3 $\implies$ Point $(3, 3)$

Notice that *Pad Thai* sits right in the geometric center $(3, 3)$! Thai cuisine is world-famous for its deliberate balance of fiery chili heat and sweet palm sugar, perfectly captured by its central position on this 2D plane.

## Step-by-Step Student Instructions
1. Open your Python terminal in the project directory.
2. Run the following code snippet to generate a 2D projection plot:
   ```python
   import matplotlib
   matplotlib.use("Agg")
   import matplotlib.pyplot as plt
   import pandas as pd
   
   df = pd.read_csv("data/recipes.csv")
   fig, ax = plt.subplots(figsize=(9, 6))
   ax.scatter(df["sweet"], df["spice"], color="#e67e22", s=100, edgecolors="navy", zorder=3)
   
   for _, row in df.iterrows():
       ax.annotate(row["name"], (row["sweet"] + 0.08, row["spice"] + 0.05), fontsize=8)
       
   ax.set_xlim(0.5, 5.5)
   ax.set_ylim(0.5, 5.5)
   ax.set_xlabel("Sweetness (1-5)")
   ax.set_ylabel("Spiciness (1-5)")
   ax.set_title("Flavor Space Projection: Sweet vs. Spice")
   ax.grid(True, alpha=0.3)
   fig.tight_layout()
   fig.savefig("outputs/sweet_vs_spice.png", dpi=150)
   plt.close(fig)
   print("Saved outputs/sweet_vs_spice.png")
   ```
3. Open `outputs/sweet_vs_spice.png` and explore the clusters.

## Expected Output or Observable Behaviour
The generated plot clearly shows dishes grouped into intuitive culinary regions: sweet desserts in the lower-right, fiery curries and soups in the upper-left, and balanced sweet-spicy dishes like Pad Thai in the middle.

## Practical Exercises
1. **Exercise 3.1**: Create a 2D projection of **Savory vs. Veggie**. Which dishes appear in the high-savory, low-veggie corner? Which dishes appear in the high-veggie corner?
2. **Exercise 3.2**: Why do Pancakes and Chocolate Cake land on top of each other in the Sweet vs. Spice projection? Do they also overlap in other projections?
3. **Exercise 3.3**: How many unique pairs of 2D projections can be created from 5 features? (Hint: Combination formula $\binom{5}{2} = \frac{5 \times 4}{2}$).

## Common Mistakes and Debugging
| Mistake | Why it happens | How to resolve |
|---|---|---|
| Text annotations overlapping illegibly | Multiple points share identical coordinates | Add slight jitter (e.g. `+ 0.05 * np.random.randn()`) or use the `adjustText` library |
| Forgetting to label points | Scatter plot shows bare dots with no dish names | Use `ax.annotate()` in an `iterrows()` loop |
| Forgetting axis limits | Points on the edges get clipped | Use `ax.set_xlim(0.5, 5.5)` to provide breathing room around points |

## Best Practices and Security Considerations
- **Pairwise Projections vs PCA**: When analyzing up to 5 dimensions, inspecting 2D pairwise projections preserves the direct culinary meaning of axes. For 50+ dimensions, dimensionality reduction techniques like Principal Component Analysis (PCA) or t-SNE are preferred.
- **Label Readability**: When annotating scatter points, keep font sizes moderate and set consistent margins so labels do not run off the figure borders.

## Summary
2D projections allow data scientists to visualize multi-dimensional feature spaces by plotting pairs of attributes on Cartesian axes. Projecting flavor dimensions like Sweet vs. Spice reveals natural culinary clusters and provides visual confirmation of the similarity patterns detected by our nearest neighbor algorithm.

## Knowledge-check Questions
1. Why is it impossible to directly plot a 5-dimensional graph on a 2D screen?
2. What is a 2D projection in machine learning?
3. Where do desserts like Pancakes and Chocolate Cake land on a Sweet vs. Spice scatter plot?
4. How many 2D projection pairs can be constructed from our 5 flavor dimensions?
5. What culinary attribute makes Pad Thai sit near the center of the Sweet vs. Spice projection?

## References
- Scatter Plots in Matplotlib: https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.scatter.html
- Data Projection and Dimensionality: https://developers.google.com/machine-learning/data-prep/transform/dimensionality-reduction
