# Lesson 01: Headless Matplotlib and the Agg Backend

**Lesson ID:** lesson-01  
**Module:** module-05  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
The purpose of this lesson is to understand Matplotlib backends and how to configure headless rendering for automated environments. By the end of this lesson, you will be able to:
- Explain the role of Matplotlib backends in data visualization.
- Distinguish between interactive (GUI) backends and non-interactive (raster/vector) backends.
- Understand why `matplotlib.use("Agg")` must be declared before importing `matplotlib.pyplot`.
- Prevent crashes and errors when running Python scripts in servers, Docker containers, or CI/CD pipelines.

## Prerequisites
Completion of Module 04. Basic understanding of Python module importing order.

## Concept Explanation
### What is a Matplotlib Backend?
Matplotlib is designed to work across hundreds of different operating systems, user interfaces, and environments. To accomplish this flexibility, Matplotlib separates its architecture into two layers:
1. **The Frontend**: The user-facing code you write, such as `plt.plot()`, `ax.barh()`, `ax.set_title()`.
2. **The Backend**: The underlying rendering engine that translates your Python drawing commands into actual pixels on a screen or into an image file on disk.

```
+-----------------------------------------------------------------------------------+
|                           MATPLOTLIB BACKEND ARCHITECTURE                         |
+-----------------------------------------------------------------------------------+
|                                                                                   |
|   USER CODE (Frontend):  plt.subplots(), ax.barh(), fig.savefig()                |
|                                     |                                             |
|                                     v                                             |
|   +---------------------------------+---------------------------------+           |
|   |                                                                   |           |
|   v                                                                   v           |
|   INTERACTIVE BACKENDS (GUI)                  NON-INTERACTIVE BACKENDS    |
|   - TkAgg, Qt5Agg, MacOSX                     - "Agg" (Anti-Grain         |
|   - Requires graphical display server            Geometry)                |
|     (X11 / Wayland / Windows Desktop)         - Headless, pure raster     |
|   - Opens pop-up window: plt.show()           - Directly writes PNG files |
|   - CRASHES on cloud/headless servers!        - ZERO DISPLAY REQUIRED!    |
|                                                                                   |
+-----------------------------------------------------------------------------------+
```

### Why Automated Scripts Fail Without "Agg"
When running machine learning scripts on cloud servers (AWS, Google Cloud, GitHub Actions), remote SSH sessions, or automated test runners, there is **no monitor, screen, or display server** (no `$DISPLAY` environment variable).
If Matplotlib attempts to initialize an interactive GUI backend like `TkAgg` or `Qt5Agg`, the operating system immediately throws a fatal error:
```text
TclError: no display name and no $DISPLAY environment variable
```
Or:
```text
UserWarning: Matplotlib is currently using agg, which is a non-GUI backend, so cannot show the figure.
```

### The Solution: Anti-Grain Geometry (Agg)
The **Agg** backend uses the Anti-Grain Geometry rendering engine to draw figures entirely in memory. It produces ultra-crisp raster PNG files without attempting to open an interactive desktop window.

To configure Agg, you must call `matplotlib.use("Agg")` **before** importing `matplotlib.pyplot`:
```python
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
```
If you import `pyplot` first, Matplotlib will automatically choose and lock in its default backend, ignoring any subsequent `use()` calls.

## Relevant Code (from main.py, lines 13-16)
```python
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
```

## Code Explanation
- **Line 13**: Imports the top-level `matplotlib` package.
- **Line 15**: Calls `matplotlib.use("Agg")` to explicitly set the rendering engine to Agg.
- **Line 16**: Safely imports `matplotlib.pyplot as plt`. Pyplot initializes with the Agg backend already configured, guaranteeing headless compatibility.

## Worked Example
Suppose an engineer deploys a recommendation microservice to a Linux Docker container on AWS.
- Script A imports `import matplotlib.pyplot as plt` directly. In the Docker container, it crashes on startup with `_tkinter.TclError: no display name`.
- Script B uses lines 13-16 from `main.py`. The Docker container generates `outputs/similarity_scores.png` cleanly and writes it to an S3 bucket without requiring any graphical drivers or virtual display servers.

## Step-by-Step Student Instructions
1. Open your terminal and check your current Matplotlib backend in Python:
   ```python
   python3 -c "import matplotlib; print(matplotlib.get_backend())"
   ```
2. Test configuring the Agg backend explicitly:
   ```python
   python3 -c 'import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt; print("Active backend:", matplotlib.get_backend())'
   ```
3. Confirm that the terminal outputs `Active backend: agg`.
4. Create a small headless test plot:
   ```python
   python3 -c 'import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt; fig, ax = plt.subplots(); ax.plot([1, 2], [3, 4]); fig.savefig("test.png"); plt.close(fig); print("Saved test.png")'
   ```
5. Remove `test.png` using `rm test.png`.

## Expected Output or Observable Behaviour
The terminal outputs:
```text
Active backend: agg
Saved test.png
```
The figure is written directly to disk without any pop-up window or display server warnings.

## Practical Exercises
1. **Exercise 1.1**: What happens if you call `matplotlib.use("Agg")` *after* calling `import matplotlib.pyplot as plt`? Test this in your terminal and observe whether a warning is raised.
2. **Exercise 1.2**: Name two file formats that the Agg backend can output. (Hint: PNG, JPG, TIFF).
3. **Exercise 1.3**: Why is `plt.show()` omitted in `main.py`? What happens if you call `plt.show()` when using the Agg backend?

## Common Mistakes and Debugging
| Mistake | Why it happens | How to resolve |
|---|---|---|
| Setting backend after importing pyplot | Calling `matplotlib.use()` too late | Always call `matplotlib.use("Agg")` immediately after `import matplotlib` |
| Calling `plt.show()` on headless servers | Expecting a pop-up window | Use `fig.savefig()` and `plt.close(fig)` instead of `plt.show()` |
| Forgetting to close figures with `plt.close()` | Accumulated figures remain in memory | Call `plt.close(fig)` after saving to prevent memory leaks |

## Best Practices and Security Considerations
- **Order of Imports**: Always configure backend settings at the very top of your script, before importing any visualization wrappers (e.g. `seaborn`, `pyplot`).
- **Production Resilience**: In production APIs or web backends, never use interactive backends because GUI initialization can block worker threads and crash headless environments.

## Summary
The `Agg` (Anti-Grain Geometry) backend enables Matplotlib to render graphics in memory and save image files without requiring a graphical desktop display server. Setting `matplotlib.use("Agg")` before importing `pyplot` ensures reliable, headless operation across all computing environments.

## Knowledge-check Questions
1. What does the acronym Agg stand for in Matplotlib?
2. Why does running an interactive Matplotlib backend fail on remote cloud servers?
3. What line of code must appear before `import matplotlib.pyplot as plt` to configure Agg?
4. What happens if you call `plt.show()` when using the Agg backend?
5. Why is `fig.savefig()` preferred over `plt.show()` in automated scripts?

## References
- Matplotlib Backends Overview: https://matplotlib.org/stable/users/explain/backends/index.html
- Headless Matplotlib in Web Applications: https://matplotlib.org/stable/users/explain/figure/web_application_server.html
