# Lesson 02: Building the Horizontal Bar Chart of Similarity Scores

**Lesson ID:** lesson-02  
**Module:** module-05  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
The purpose of this lesson is to master the construction of horizontal bar charts using `ax.barh()`. By the end of this lesson, you will be able to:
- Explain why horizontal bar charts (`barh`) are superior to vertical bar charts (`bar`) for displaying ranked recommendations with long item names.
- Understand the array reversal trick `[::-1]` used to place the top-ranked item at the top of the chart.
- Style bars with custom hex colors, gridlines, and axis limits.
- Render and interpret the similarity score chart for `"Spicy Ramen"`.

## Prerequisites
Completion of Lesson 01. Familiarity with Matplotlib axes and bar plotting.

## Concept Explanation
### Horizontal vs. Vertical Bar Charts for Recommendations
When displaying recommendations, items have text titles of varying lengths (e.g., *"Chicken Tikka Masala"*, *"Kimchi Fried Rice"*, *"Mushroom Risotto"*).
If you use a vertical bar chart (`ax.bar`):
- Long recipe names collide with each other along the horizontal x-axis.
- You are forced to rotate the text by 45° or 90°, forcing users to tilt their heads to read the names.

In contrast, a **horizontal bar chart** (`ax.barh`):
- Places recipe names along the vertical y-axis, allowing text to be read naturally from left to right.
- Extends bars horizontally, where bar length directly represents similarity magnitude.

```
+-----------------------------------------------------------------------------------+
|                        HORIZONTAL BAR CHART LAYOUT (barh)                         |
+-----------------------------------------------------------------------------------+
|                                                                                   |
|  Chicken Tikka Masala [====================================] 0.49 (Rank 1 - TOP)  |
|  Kimchi Fried Rice    [==============================] 0.40                       |
|  Taco                 [==============================] 0.40                       |
|  Pad Thai             [========================] 0.36                             |
|  Tom Yum Soup         [===================] 0.33                                  |
|                       +---------+---------+---------+---------+                   |
|                      0.0       0.25      0.50      0.75      1.0                  |
|                                similarity score                                   |
+-----------------------------------------------------------------------------------+
```

### The Array Reversal Trick: `[::-1]`
Matplotlib's `ax.barh()` plots items starting from the **bottom** ($y=0$) and moving **upward**.
Our recommendation DataFrame returns dishes sorted in descending order of similarity:
- Row 0: Chicken Tikka Masala (0.49 - Highest!)
- Row 1: Kimchi Fried Rice (0.40)
- Row 2: Taco (0.40)
- Row 3: Pad Thai (0.36)
- Row 4: Tom Yum Soup (0.33 - Lowest)

If you pass `recommendations["name"]` directly to `ax.barh()`, Matplotlib places Row 0 at the bottom and Row 4 at the top. This feels backwards to human readers, who expect the #1 recommendation to appear at the **very top**!

To fix this, `main.py` uses Python's slice step syntax `[::-1]` to reverse both the names and the values:
```python
ax.barh(recommendations["name"][::-1], recommendations["similarity"][::-1], color="#e67e22")
```
Reversing the order ensures the highest-ranked recipe (Chicken Tikka Masala) is rendered on the top row!

## Relevant Code (from main.py, lines 75-85)
```python
# ---- Similarity chart ---------------------------------------------
base_recipe = "Spicy Ramen"
recommendations = recommend(base_recipe, n=5)
fig, ax = plt.subplots(figsize=(8, 4.5))
ax.barh(recommendations["name"][::-1], recommendations["similarity"][::-1], color="#e67e22")
ax.set_xlim(0, 1)
ax.set_xlabel("similarity score (higher is closer)")
ax.set_title(f"Recipes most similar to {base_recipe}")
ax.grid(axis="x", alpha=0.25)
fig.tight_layout()
fig.savefig(OUT / "similarity_scores.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```

## Code Explanation
- **Lines 75-76**: Queries the top 5 recommendations for `"Spicy Ramen"`.
- **Line 77**: Creates a figure and axis with dimensions 8 inches wide by 4.5 inches tall.
- **Line 78**: Draws horizontal bars with `color="#e67e22"` (warm culinary orange) and reversed arrays `[::-1]`.
- **Line 79**: Sets the horizontal axis limits explicitly from 0 to 1 (`xlim(0, 1)`), providing visual scale.
- **Lines 80-81**: Configures axis labels and a dynamic title.
- **Line 82**: Enables subtle vertical gridlines (`axis="x"`) with 25% opacity (`alpha=0.25`).
- **Line 83**: Adjusts subplot margins with `tight_layout()`.
- **Line 84**: Saves the raster image to `outputs/similarity_scores.png` at 150 DPI resolution.
- **Line 85**: Releases figure resources with `plt.close(fig)`.

## Worked Example
Let us trace the values passed into `ax.barh()`:
- `recommendations["name"].tolist()`: `['Chicken Tikka Masala', 'Kimchi Fried Rice', 'Taco', 'Pad Thai', 'Tom Yum Soup']`
- `recommendations["name"][::-1].tolist()`: `['Tom Yum Soup', 'Pad Thai', 'Taco', 'Kimchi Fried Rice', 'Chicken Tikka Masala']`

When Matplotlib renders this reversed list from bottom to top:
- Bottom bar ($y=0$): Tom Yum Soup
- Second bar ($y=1$): Pad Thai
- Third bar ($y=2$): Taco
- Fourth bar ($y=3$): Kimchi Fried Rice
- Top bar ($y=4$): Chicken Tikka Masala

The viewer looks at the top of the chart and immediately spots the #1 match!

## Step-by-Step Student Instructions
1. Open your terminal in the project directory.
2. Run `main.py`:
   ```python
   python main.py
   ```
3. Verify that `outputs/similarity_scores.png` is created.
4. Inspect the image using an image viewer (or VS Code preview):
   - Notice the orange bars.
   - Confirm that Chicken Tikka Masala appears at the top.
   - Confirm that the x-axis spans from 0.0 to 1.0.

## Expected Output or Observable Behaviour
Opening `outputs/similarity_scores.png` reveals a clean, professional horizontal bar chart. The top bar is Chicken Tikka Masala (~0.49), followed by Kimchi Fried Rice and Taco (~0.40), Pad Thai (~0.36), and Tom Yum Soup (~0.33).

## Practical Exercises
1. **Exercise 2.1**: Modify line 75 of `main.py` to plot recommendations for `"Margherita Pizza"` instead of `"Spicy Ramen"`. Run the script and inspect the new chart.
2. **Exercise 2.2**: Change the bar color from orange (`"#e67e22"`) to a calm teal (`"#16a085"`).
3. **Exercise 2.3**: What happens if you remove `ax.set_xlim(0, 1)`? How does Matplotlib decide the default x-axis limits?

## Common Mistakes and Debugging
| Mistake | Why it happens | How to resolve |
|---|---|---|
| Reversing names but forgetting to reverse values | Writing `barh(names[::-1], values)` | Always reverse BOTH names and similarity values in tandem |
| Truncated y-axis recipe names | Figure margins too tight | Use `fig.tight_layout()` and `bbox_inches="tight"` |
| Labels overlapping bars | Setting xlim too narrow | Ensure x-axis spans from 0 to 1 to accommodate the full similarity range |

## Best Practices and Security Considerations
- **Meaningful Color Choices**: Choose colors that resonate with the subject matter (e.g., warm earthy tones for food; blue/green for technology or environment).
- **Consistent Scaling**: Always fix the similarity axis to $[0, 1]$ so users can accurately perceive absolute match strength across different query dishes.

## Summary
`ax.barh()` creates clean horizontal bar charts ideal for displaying recommendation rankings. Reversing the input series with `[::-1]` ensures the top-ranked recommendation appears at the top of the chart, while fixing `xlim(0, 1)` provides an intuitive absolute reference scale.

## Knowledge-check Questions
1. Why are horizontal bar charts preferred over vertical bar charts for displaying recipe names?
2. What does the slice notation `[::-1]` do to a list or pandas Series?
3. What hex color code is used for the bars in `main.py`?
4. Why is `ax.set_xlim(0, 1)` explicitly called?
5. Which dish appears at the very top of the generated bar chart in `main.py`?

## References
- Matplotlib barh API Documentation: https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.barh.html
- Python Extended Slicing: https://docs.python.org/3/whatsnew/2.3.html#extended-slices
