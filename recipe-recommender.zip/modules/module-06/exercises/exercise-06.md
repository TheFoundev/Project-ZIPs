# Module 6 Exercises: Running & Extending Recommender Systems

## Exercise 6.1: Expanding the Catalog & Auditing Output (15 min)
**Objective:** Add custom culinary creations to `recipes.csv`, execute `main.py`, and audit output files.

**Problem Statement:**
1. Back up `data/recipes.csv` to `data/recipes.csv.bak`.
2. Add 5 distinct dishes to `data/recipes.csv` representing different cuisines and flavor profiles:
   - Dish 1: An extremely sweet French dessert
   - Dish 2: A fiery Thai curry
   - Dish 3: A fresh Greek vegetarian salad
   - Dish 4: A savory British meat pie
   - Dish 5: A balanced Mexican street taco
3. Run `main.py` and inspect `outputs/recommendations.txt`.
4. Did any of your new dishes appear as top recommendations for the benchmark queries? Record your findings.

**Acceptance Criteria:**
- [ ] 5 valid rows appended to `recipes.csv` with integer ratings between 1 and 5.
- [ ] `main.py` runs with exit code 0.
- [ ] Audit report written summarizing changes in `outputs/recommendations.txt`.
- [ ] Original dataset restored or preserved cleanly.

---

## Exercise 6.2: Interactive User Flavor Query Engine (15 min)
**Objective:** Build an interactive command-line interface that accepts custom flavor ratings from a user and recommends the best matching catalog recipes.

**Problem Statement:**
Write a Python script `custom_query.py` that:
1. Prompts the user to enter their preference for all 5 dimensions on a 1-5 scale:
   - `"How much spice do you want? (1-5): "`
   - `"How much sweetness? (1-5): "`
   - `"How much savory richness? (1-5): "`
   - `"How much sour acidity? (1-5): "`
   - `"How much vegetable presence? (1-5): "`
2. Assembles the user inputs into a 2D array of shape `(1, 5)`.
3. Scales the vector using the fitted `StandardScaler` from the training data.
4. Queries `model.kneighbors(user_vector, n_neighbors=3)`.
5. Prints the top 3 matching recipes and their similarity scores. Notice: since this query vector is NOT in the catalog, do NOT skip index 0!

**Acceptance Criteria:**
- [ ] Interactive script accepts user input via `input()`.
- [ ] Uses `scaler.transform()` (not `fit_transform`).
- [ ] Correctly retains index 0 since the query vector is novel.
- [ ] Displays top 3 matching recipes with similarity scores.

---

## Exercise 6.3: Hybrid Architecture Design Proposal (15 min)
**Objective:** Design an architecture specification for an enterprise-scale recipe recommender.

**Problem Statement:**
Write a 1-page architectural design proposal for an online food delivery app with 50,000 recipes and 1,000,000 active users. Your proposal must address:
1. **Candidate Retrieval**: How nearest neighbor search in flavor space can be scaled using vector indexing (e.g. FAISS).
2. **Cold Start Strategy**: How new users and newly onboarded restaurants will be handled.
3. **Dietary Hard Filtering**: Where and how strict dietary filters (e.g. vegan, halal, nut allergies) will be enforced.
4. **Serendipity & Diversity**: How the app will balance popular favorites with exploratory culinary discoveries.

**Acceptance Criteria:**
- [ ] Proposal covers all 4 architectural pillars in detail.
- [ ] References concepts learned throughout the Recipe Recommender curriculum.
