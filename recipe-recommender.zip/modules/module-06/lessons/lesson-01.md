# Lesson 01: Running the Complete Script and Inspecting Artifacts

**Lesson ID:** lesson-01  
**Module:** module-06  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
The purpose of this lesson is to execute `main.py` end-to-end and conduct a thorough audit of all generated outputs and filesystem artifacts. By the end of this lesson, you will be able to:
- Run `main.py` from the command line and verify zero-error exit status.
- Analyze the terminal output across the three benchmark dishes (`Margherita Pizza`, `Spicy Ramen`, `Chocolate Cake`).
- Inspect and verify the contents of `outputs/recommendations.txt`.
- Correlate text recommendations with the graphical bar chart in `outputs/similarity_scores.png`.

## Prerequisites
Completion of Modules 01 through 05.

## Concept Explanation
### The Complete Execution Lifecycle
When you execute `python main.py`, the script performs a complete machine learning workflow in less than two seconds:
1. **Ingestion**: Reads `data/recipes.csv` (24 rows, 7 columns).
2. **Preprocessing**: Normalizes the 5 flavor columns with `StandardScaler()`.
3. **Model Construction**: Builds an unsupervised spatial index with `NearestNeighbors(n_neighbors=6, metric="euclidean")`.
4. **Benchmark Inferences**:
   - Evaluates nearest neighbors for Margherita Pizza (Italian).
   - Evaluates nearest neighbors for Spicy Ramen (Japanese).
   - Evaluates nearest neighbors for Chocolate Cake (Dessert).
5. **Serendipity Exploration**: Computes cross-cuisine surprise for Margherita Pizza.
6. **Visualization**: Generates `outputs/similarity_scores.png` for Spicy Ramen.
7. **Persistence**: Writes formatted recommendations to `outputs/recommendations.txt`.

```
Terminal Command: python main.py
        |
        v
+-----------------------------------------------------------------------------------+
| OUTPUT ARTIFACT 1: CONSOLE LOG                                                    |
| - Header banner                                                                   |
| - Margherita Pizza recommendations (Lasagna, Paella, Mushroom Risotto)            |
| - Spicy Ramen recommendations (Chicken Tikka Masala, Kimchi Fried Rice, Taco)     |
| - Chocolate Cake recommendations (Pancakes, Blueberry Muffin, Butter Chicken)     |
| - Surprise Me result: Chicken Tikka Masala (Indian)                               |
+-----------------------------------------------------------------------------------+
        |
        +-----------------------------------+
        |                                   |
        v                                   v
+-------------------------------+   +-------------------------------+
| OUTPUT ARTIFACT 2:            |   | OUTPUT ARTIFACT 3:            |
| outputs/similarity_scores.png |   | outputs/recommendations.txt   |
| (Horizontal bar chart)        |   | (Formatted text log)          |
+-------------------------------+   +-------------------------------+
```

### Auditing the Output Files
A critical practice in professional software development is **artifact verification**: verifying that generated files not only exist, but contain accurate, properly formatted information.
- `outputs/recommendations.txt` formats similarity scores to 3 decimal places (`:.3f`), matching the precision needed for engineering logs.
- `outputs/similarity_scores.png` provides an intuitive graphic for human review.

## Relevant Code (from main.py, lines 62-97)
```python
    print("=" * 60)
    print("THE RECIPE RECOMMENDER")
    print("=" * 60)
    for recipe in ("Margherita Pizza", "Spicy Ramen", "Chocolate Cake"):
        recommendations = recommend(recipe, n=3)
        print(f"\nIf you like {recipe}, try:")
        for row in recommendations.itertuples():
            print(f"  {row.name:22s} ({row.cuisine:14s}) similarity {row.similarity:.2f}")

    surprise = surprise_me("Margherita Pizza")
    print(f"\nSurprise me: {surprise['name']} ({surprise['cuisine']})")
...
    with open(OUT / "recommendations.txt", "w", encoding="utf-8") as handle:
        for recipe in ("Margherita Pizza", "Spicy Ramen", "Chocolate Cake"):
            handle.write(f"If you like {recipe}, try:\n")
            for row in recommend(recipe, n=3).itertuples():
                handle.write(f"  {row.name} ({row.cuisine}), similarity {row.similarity:.3f}\n")
            handle.write("\n")
        handle.write(f"Surprise me: {surprise['name']} ({surprise['cuisine']})\n")

    print("\nSaved: outputs/similarity_scores.png, outputs/recommendations.txt")
    print("Try this: add 10 recipes you actually like and rerun the recommendations.")
```

## Code Explanation
- **Lines 62-70**: Prints structured recommendation tables to stdout using formatted f-strings (`:22s`, `:14s`, `:.2f`).
- **Lines 71-72**: Calls `surprise_me()` and prints the cross-cuisine dish.
- **Lines 87-94**: Opens `outputs/recommendations.txt` with UTF-8 encoding and writes identical recommendations formatted to three decimal places (`:.3f`).
- **Lines 95-96**: Informs the user where output files were saved and presents the curriculum challenge to add 10 custom recipes.

## Worked Example
Let us examine the exact contents of `outputs/recommendations.txt`:
```text
If you like Margherita Pizza, try:
  Lasagna (Italian), similarity 0.523
  Paella (Spanish), similarity 0.457
  Mushroom Risotto (Italian), similarity 0.418

If you like Spicy Ramen, try:
  Chicken Tikka Masala (Indian), similarity 0.486
  Kimchi Fried Rice (Korean), similarity 0.397
  Taco (Mexican), similarity 0.397

If you like Chocolate Cake, try:
  Pancakes (American), similarity 1.000
  Blueberry Muffin (American), similarity 0.457
  Butter Chicken (Indian), similarity 0.217

Surprise me: Chicken Tikka Masala (Indian)
```
Notice how each recommendation group reflects a distinct culinary archetype:
- Pizza $\rightarrow$ rich comfort foods (Lasagna, Paella, Risotto).
- Ramen $\rightarrow$ spicy, savory international dishes (Curry, Fried Rice, Taco).
- Cake $\rightarrow$ sweet treats (Pancakes, Muffin).

## Step-by-Step Student Instructions
1. Open your terminal and navigate to the project directory:
   ```bash
   cd "beginner-projects-main/AI-ML Beginners/projects/18_recipe_recommender"
   ```
2. Run the main script:
   ```bash
   python main.py
   ```
3. Verify that the script terminates with exit code 0 (no errors).
4. Inspect the generated text file:
   ```bash
   cat outputs/recommendations.txt
   ```
5. Confirm that `outputs/similarity_scores.png` exists and is non-empty:
   ```bash
   ls -la outputs/similarity_scores.png
   ```

## Expected Output or Observable Behaviour
The terminal outputs the complete banner, 3 recommendation blocks, the surprise block, and the file confirmation message:
```text
============================================================
THE RECIPE RECOMMENDER
============================================================

If you like Margherita Pizza, try:
  Lasagna                (Italian       ) similarity 0.52
  Paella                 (Spanish       ) similarity 0.46
  Mushroom Risotto       (Italian       ) similarity 0.42
...
Saved: outputs/similarity_scores.png, outputs/recommendations.txt
Try this: add 10 recipes you actually like and rerun the recommendations.
```

## Practical Exercises
1. **Exercise 1.1**: What happens if you re-run `python main.py` three times in a row? Are the generated files overwritten or appended? (Inspect line 87: mode `"w"`).
2. **Exercise 1.2**: Write a bash one-liner to count how many total recommendations are recorded in `outputs/recommendations.txt`.
3. **Exercise 1.3**: Why is UTF-8 encoding specified explicitly when opening `recommendations.txt`?

## Common Mistakes and Debugging
| Mistake | Why it happens | How to resolve |
|---|---|---|
| `FileNotFoundError: outputs/recommendations.txt` | `outputs/` directory was deleted and `mkdir` wasn't called | Ensure `OUT.mkdir(exist_ok=True)` runs before file writing |
| Trailing commas in text file | Printing raw tuples instead of formatted strings | Use `itertuples()` and format string fields cleanly |
| Overwriting custom recommendations accidentally | Re-running `main.py` replaces `recommendations.txt` | If you wish to save multiple runs, append timestamps to output filenames |

## Best Practices and Security Considerations
- **Explicit File Encodings**: Always specify `encoding="utf-8"` when reading or writing text files to avoid character corruption across different platforms (especially Windows).
- **Idempotence**: A script that can be run multiple times safely without producing side-effects or corrupting state is called **idempotent**. `main.py` is fully idempotent.

## Summary
Executing `main.py` runs the complete data ingestion, standardization, nearest-neighbor indexing, recommendation queries, and output generation pipeline. The script reliably creates clean console logs, a formatted text artifact (`recommendations.txt`), and a high-resolution bar chart (`similarity_scores.png`).

## Knowledge-check Questions
1. What three dishes are evaluated in the default loop of `main.py`?
2. What mode is used when opening `outputs/recommendations.txt` (`"w"` or `"a"`)?
3. What is the similarity score between Margherita Pizza and Lasagna in `recommendations.txt`?
4. Why does `main.py` use `recommendations.itertuples()` when iterating over recommendation rows?
5. What challenge is printed at the very end of `main.py`?

## References
- Python File I/O Documentation: https://docs.python.org/3/tutorial/inputoutput.html#reading-and-writing-files
- Pandas DataFrame itertuples API: https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.itertuples.html
