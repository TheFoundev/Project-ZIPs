# Lesson 04: Extending to Hybrid & Collaborative Recommendation Engines

**Lesson ID:** lesson-04  
**Module:** module-06  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
The purpose of this lesson is to explore advanced architectures for production recommendation systems. By the end of this lesson, you will be able to:
- Explain how industrial recommendation systems combine content-based and collaborative filtering into **hybrid engines**.
- Understand matrix factorization techniques (such as Singular Value Decomposition - SVD).
- Explain modern deep learning architectures for recommendation, including **Two-Tower Neural Networks** (e.g. at YouTube and Netflix).
- Outline an evolutionary roadmap for transforming the Recipe Recommender into an enterprise-scale recommendation platform.

## Prerequisites
Completion of Lessons 01-03. Understanding of linear algebra and machine learning pipelines.

## Concept Explanation
### Beyond Single-Algorithm Recommenders
In real-world production systems (like Netflix, Spotify, Amazon, and YouTube), engineers rarely rely on a single recommendation algorithm in isolation:
- **Pure Content-Based Systems**: Excel at new items, explainability, and cold start, but struggle with serendipity and user diversity (filter bubbles).
- **Pure Collaborative Systems**: Excel at community discovery and latent preference matching, but suffer from cold start and sparsity.

The solution is a **Hybrid Recommendation System**: an architecture that fuses item content vectors with community interaction patterns.

```
+-----------------------------------------------------------------------------------+
|                        MODERN HYBRID RECOMMENDATION PIPELINE                      |
+-----------------------------------------------------------------------------------+
|                                                                                   |
|  CANDIDATE GENERATION (Retrieval)                                                 |
|  - Content-Based Nearest Neighbors (Flavor space vectors)    \                    |
|  - Collaborative Filtering (Matrix Factorization / SVD)      -- 500 Candidates    |
|  - Trending & Popularity Filters                             /                    |
|                                |                                                  |
|                                v                                                  |
|  RANKING & SCORING (Deep Learning)                                                |
|  - Two-Tower Neural Network                                                       |
|  - Predicts Click-Through & Cooking Probability              -- Top 50 Ranked     |
|                                |                                                  |
|                                v                                                  |
|  RE-RANKING & DIVERSITY (Post-Processing)                                         |
|  - Deduplication & Dietary Filtering (Vegan, Gluten-Free)                         |
|  - Serendipity Injection ("Surprise Me" Cross-Cuisine)       -- Final 5 to User!  |
|                                                                                   |
+-----------------------------------------------------------------------------------+
```

### 1. Matrix Factorization (SVD)
In collaborative filtering, user ratings are arranged in a sparse matrix $R$ of size $U \times I$ (Users by Items).
Matrix factorization decomposes this large matrix into two smaller, dense matrices:
$$R \approx P \times Q^T$$
- Matrix $P$ ($U \times k$): Represents each user as a dense $k$-dimensional vector.
- Matrix $Q$ ($I \times k$): Represents each recipe as a dense $k$-dimensional vector.
By taking the dot product between a user's vector and a recipe's vector, the system predicts how much that user will enjoy the dish.

### 2. Two-Tower Neural Networks
In modern web-scale systems (such as YouTube's video recommender), deep learning Two-Tower models are industry standard:
- **User Tower**: Ingests user history, demographics, time of day, and location, outputting an embedding vector $\mathbf{u} \in \mathbb{R}^{128}$.
- **Item Tower**: Ingests recipe sensory attributes (our 5 flavor features), high-resolution dish photos, ingredients list, and chef metadata, outputting an embedding vector $\mathbf{v} \in \mathbb{R}^{128}$.
- **Scoring**: The cosine similarity between $\mathbf{u}$ and $\mathbf{v}$ predicts the user's affinity score in microseconds using vector databases (such as FAISS, Milvus, or Pinecone).

## Relevant Code (Roadmap Comparison)
In `main.py`, our recommendation logic is:
```python
distances, indices = model.kneighbors(scaled_features[index].reshape(1, -1), n_neighbors=n + 1)
similarity = 1 / (1 + distance)
```
In an enterprise hybrid engine, this content score is blended with user collaborative affinity:
```python
# CONCEPTUAL HYBRID BLENDING
final_score = alpha * content_similarity + (1 - alpha) * collaborative_predicted_rating
```
Where $\alpha \in [0, 1]$ balances item flavor match against crowd popularity.

## Code Explanation
- In the baseline `main.py`, `model.kneighbors()` retrieves the nearest items in 5D flavor space and scores them with pure content similarity $1 / (1 + d)$.
- In production architectures, this content similarity score serves as a candidate retrieval filter. The retrieved candidates are then blended using a weighting parameter $\alpha$, where content similarity is combined with collaborative predicted ratings to compute a unified `final_score`.
- This ensures that items with matching flavor profiles are considered while still factoring in community ratings and individual user history.

## Worked Example
Suppose a user named Sarah searches for recommendations.
- She enjoys spicy food, but rarely cooks Italian food.
- **Recipe A (Spicy Ramen)**:
  - Content Similarity: $0.90$ (matches her flavor profile)
  - Collaborative Score: $0.85$ (users with Sarah's profile love it)
  - Blended Score ($0.5 \times 0.90 + 0.5 \times 0.85$): $\mathbf{0.875}$ $\implies$ Top Recommendation!
- **Recipe B (Exotic Hot Pot)**:
  - Content Similarity: $0.88$ (high spice)
  - Collaborative Score: $0.20$ (brand-new recipe, few reviews)
  - Pure collaborative filtering would hide it. The hybrid engine preserves it because its content similarity is high!

## Step-by-Step Student Instructions
1. Open your code editor and review the complete `main.py` script.
2. Identify where user interaction history could be incorporated.
3. Consider how you would extend `recipes.csv` with additional metadata:
   - Add columns for `prep_time_minutes`, `cost_level`, `calories`, `dietary_tags`.
4. Outline how a weighted distance metric could be defined:
   $$d_w(\mathbf{u}, \mathbf{v}) = \sqrt{\sum w_i (u_i - v_i)^2}$$
   Where $w_{\text{spice}} = 2.0$ for users who care deeply about chili heat!

## Expected Output or Observable Behaviour
Understanding how the foundational concepts implemented in `main.py`—vector spaces, distance metrics, nearest neighbors, normalization—form the exact mathematical foundation of multi-billion dollar industrial recommendation engines.

## Practical Exercises
1. **Exercise 4.1**: What is the difference between candidate generation (retrieval) and ranking in a two-stage recommender system?
2. **Exercise 4.2**: If a user is strictly vegetarian, at which stage of the hybrid pipeline should meat dishes be filtered out? (Before retrieval, or during post-processing?).
3. **Exercise 4.3**: Research Scikit-learn's `TruncatedSVD` and explain how it could be used to perform matrix factorization on a user-recipe rating matrix.

## Common Mistakes and Debugging
| Mistake | Why it happens | How to resolve |
|---|---|---|
| Building a complex deep learning model before testing simple baselines | Over-engineering early in a project | Always benchmark against a clean nearest-neighbors content model first |
| Ignoring latency constraints | Complex models taking 5 seconds per recommendation | Use two-stage pipelines: fast spatial retrieval ($<10$ms) followed by deep ranking |
| Neglecting business rules | Recommending pork dishes to kosher/halal diners | Apply hard constraint filtering in the final re-ranking stage |

## Best Practices and Security Considerations
- **Vector Search Engines**: When catalog size exceeds $1,000,000$ items, replace in-memory scikit-learn models with Approximate Nearest Neighbor (ANN) vector databases like FAISS, HNSWLib, or pgvector.
- **Feedback Loops**: Monitor recommender drift to ensure models do not repeatedly amplify a narrow set of viral items at the expense of catalog diversity.

## Summary
Modern enterprise recommendation systems combine content-based nearest neighbors, collaborative matrix factorization, and deep learning Two-Tower models into hybrid architectures. The geometric principles learned in the Recipe Recommender—vector representation, normalization, and distance-based similarity—remain the core engine powering digital discovery across the web.

## Knowledge-check Questions
1. What is a hybrid recommendation system?
2. What are the two matrices produced during matrix factorization (SVD)?
3. What are the roles of the User Tower and Item Tower in a Two-Tower neural network?
4. What is the difference between candidate generation and candidate ranking?
5. How does the Recipe Recommender project prepare you for building industrial recommendation engines?

## References
- Deep Neural Networks for YouTube Recommendations (Covington et al.): https://research.google/pubs/pub45530/
- Matrix Factorization Techniques for Recommender Systems (Netflix Prize): https://ieeexplore.ieee.org/document/5197422
- Approximate Nearest Neighbors (ANN-Benchmarks): https://ann-benchmarks.com/
