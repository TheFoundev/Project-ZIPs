# Lesson 02: Customizing and Expanding the Recipe Dataset

**Lesson ID:** lesson-02  
**Module:** module-06  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
The purpose of this lesson is to learn how to safely modify, curate, and expand the recipe dataset. By the end of this lesson, you will be able to:
- Follow data hygiene rules when appending new rows to `data/recipes.csv`.
- Rate new culinary dishes across the five sensory dimensions (`spice, sweet, savory, sour, veggie`).
- Re-run the recommendation engine and observe how new dishes integrate into the spatial index.
- Verify that newly added recipes can be both queried and recommended.

## Prerequisites
Completion of Lesson 01. Familiarity with editing CSV files in a text editor or via pandas.

## Concept Explanation
### The Challenge in main.py: Line 96
At the conclusion of `main.py`, the author leaves an inspiring challenge for every student:
```python
print("Try this: add 10 recipes you actually like and rerun the recommendations.")
```
Adding your own dishes makes machine learning tangible and personal. It transforms an abstract model into a tool you can use to plan your own weekly dinner menu!

### Dataset Schema Requirements
When adding new recipes to `data/recipes.csv`, the file must adhere to strict formatting standards:
1. **Header Alignment**: Exactly 7 columns in exact order:
   `name,cuisine,spice,sweet,savory,sour,veggie`
2. **Valid Data Types**:
   - `name`: String without unescaped commas (e.g., `"Chicken Parmesan"`).
   - `cuisine`: Capitalized cultural category (e.g., `"Italian"`, `"Mexican"`, `"Thai"`).
   - The 5 flavor columns: Integers between 1 and 5.
3. **No Trailing Empty Lines**: Ensure the file ends with a single clean newline character.

```
+-----------------------------------------------------------------------------------+
|                        ADDING NEW RECIPES TO THE CATALOG                          |
+-----------------------------------------------------------------------------------+
|                                                                                   |
|  Original Catalog: 24 recipes                                                     |
|  + 6 New Recipes:                                                                 |
|    - Spicy Chicken Wings,American,5,1,5,2,1                                       |
|    - Mango Sticky Rice,Thai,1,5,2,2,1                                             |
|    - Beef Wellington,British,1,1,5,1,1                                            |
|    - Margherita Pizza (Italian) ---> Now finds NEW neighbors in expanded space!   |
|                                                                                   |
+-----------------------------------------------------------------------------------+
```

### How the Model Adapts Automatically
Because `main.py` computes dataset statistics dynamically:
- `StandardScaler()` automatically recomputes means $\mu$ and standard deviations $\sigma$ across the expanded dataset.
- `NearestNeighbors.fit()` builds a new spatial index over all 24 + $N$ dishes.
- The new recipes immediately participate in all future nearest-neighbor queries without requiring any code modifications!

## Relevant Code (from main.py, lines 31-35, 96)
```python
    df = pd.read_csv(DATA / "recipes.csv")
    scaler = StandardScaler()
    scaled_features = scaler.fit_transform(df[FEATURES])
    model = NearestNeighbors(n_neighbors=6, metric="euclidean")
    model.fit(scaled_features)
...
    print("Try this: add 10 recipes you actually like and rerun the recommendations.")
```

## Code Explanation
- **Lines 31-35**: Dynamically reads the CSV, normalizes all rows, and fits the index. Because no row count is hardcoded, the script seamlessly handles 24, 50, or 500 recipes.
- **Line 96**: Encourages students to test data expansion.

## Worked Example
Let us design flavor profiles for three new dishes:
1. **Mango Sticky Rice** (Thai dessert):
   - Spice: `1` (not spicy)
   - Sweet: `5` (sweet ripe mango, sugary coconut milk)
   - Savory: `2` (mild salty coconut notes)
   - Sour: `2` (gentle fruit acidity)
   - Veggie: `1` (fruit and sticky rice)
   CSV line: `Mango Sticky Rice,Thai,1,5,2,2,1`

2. **Spicy Chicken Wings** (American pub classic):
   - Spice: `5` (hot cayenne sauce)
   - Sweet: `1` (savory/vinegar sauce)
   - Savory: `5` (fried crispy chicken)
   - Sour: `3` (sharp vinegar tang)
   - Veggie: `1` (meat)
   CSV line: `Spicy Chicken Wings,American,5,1,5,3,1`

When we query `"Spicy Chicken Wings"`, the model immediately identifies *Spicy Ramen* and *Taco* as close neighbors! When we query `"Chocolate Cake"`, *Mango Sticky Rice* appears as a delicious sweet recommendation!

## Step-by-Step Student Instructions
1. Before modifying `data/recipes.csv`, make a backup copy:
   ```bash
   cp data/recipes.csv data/recipes.csv.bak
   ```
2. Open `data/recipes.csv` in your text editor.
3. Scroll to the bottom of the file (line 25).
4. Append 3 new recipes with valid ratings:
   ```csv
   Mango Sticky Rice,Thai,1,5,2,2,1
   Spicy Chicken Wings,American,5,1,5,3,1
   Greek Gyro,Greek,2,1,5,3,2
   ```
5. Save the file.
6. Run `main.py`:
   ```bash
   python main.py
   ```
7. Restore your backup when finished testing:
   ```bash
   cp data/recipes.csv.bak data/recipes.csv
   ```

## Expected Output or Observable Behaviour
When executing `main.py` with expanded recipes, the script processes all 27 rows without error. If you query one of your new dishes in `main.py`, the recommender seamlessly finds its nearest neighbors in flavor space.

## Practical Exercises
1. **Exercise 2.1**: Add a recipe that has commas in its title (e.g., `"Steak, Fries, and Salad"`). What happens if you don't wrap the name in quotes in CSV?
2. **Exercise 2.2**: What happens if you assign a rating of `10` to a new recipe's `spice` dimension? How does this outlier impact the mean and standard deviation of `StandardScaler`?
3. **Exercise 2.3**: Write a Python validation script using pandas that checks `recipes.csv` and asserts that all flavor scores are integers between 1 and 5.

## Common Mistakes and Debugging
| Mistake | Why it happens | How to resolve |
|---|---|---|
| Comma delimiters inside recipe names | `"Peanut Butter, Banana, and Honey Toast"` splits into multiple columns | Wrap names containing commas in double quotation marks |
| Out-of-bounds ratings | Entering `0` or `6` | Maintain consistency with the 1-to-5 integer scale |
| Blank lines in CSV | Pressing Enter multiple times at end of file | Remove empty trailing lines; ensure CSV ends with a single newline |

## Best Practices and Security Considerations
- **Automated Schema Validation**: In production data pipelines, use schema validation libraries like Pydantic or Great Expectations to reject malformed CSV rows before they reach the model.
- **Data Versioning**: Use Git or specialized tools like DVC (Data Version Control) to track changes and roll back erroneous additions to training data.

## Summary
The Recipe Recommender dynamically scales and indexes whatever data is present in `data/recipes.csv`. Adding new recipes across the five sensory dimensions expands the catalog and enriches the recommendation universe, demonstrating how content-based systems scale gracefully with new inventory.

## Knowledge-check Questions
1. What are the 7 required columns in `recipes.csv` in exact order?
2. What happens if a recipe name contains a comma and is not enclosed in quotes?
3. How does `main.py` adapt its preprocessing when you add 10 new rows to `recipes.csv`?
4. Why is creating a backup (`recipes.csv.bak`) good engineering practice before editing data files?
5. How does adding a new recipe affect the mean $\mu$ and standard deviation $\sigma$ computed by `StandardScaler`?

## References
- The CSV Format Specification (RFC 4180): https://datatracker.ietf.org/doc/html/rfc4180
- Data Versioning in Machine Learning: https://dvc.org/doc/use-cases/versioning-data-and-models
