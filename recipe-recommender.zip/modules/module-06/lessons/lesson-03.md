# Lesson 03: The Cold Start Problem in Modern Recommender Systems

**Lesson ID:** lesson-03  
**Module:** module-06  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
The purpose of this lesson is to analyze the "cold start problem" in recommendation systems and understand how content-based filtering mitigates this challenge. By the end of this lesson, you will be able to:
- Define the two variants of the cold start problem: the **new-item problem** and the **new-user problem**.
- Contrast how collaborative filtering and content-based filtering handle cold start scenarios.
- Explain why content-based filtering provides zero-latency recommendations for newly introduced items.
- Design strategies to address the new-user cold start challenge in commercial applications.

## Prerequisites
Completion of Lessons 01 and 02. Understanding of content-based vs collaborative filtering from Module 01.

## Concept Explanation
### The Cold Start Dilemma
In machine learning, a system suffers from a **cold start** when it is asked to generate predictions without sufficient historical interaction data.
The cold start problem manifests in two distinct forms:

```
+-----------------------------------------------------------------------------------+
|                            THE COLD START MATRIX                                  |
+-----------------------------------------------------------------------------------+
|                                                                                   |
|   1. THE NEW-ITEM COLD START                  2. THE NEW-USER COLD START          |
|   A chef uploads a brand-new recipe.          A new customer installs the app.    |
|   - Ratings: 0                                - Ratings: 0                        |
|   - Clicks: 0                                 - Order history: None               |
|   - Collaborative Filtering: FAILS!           - Collaborative Filtering: FAILS!   |
|     (Item does not exist in matrix)             (User does not exist in matrix)   |
|   - Content-Based Filtering: SUCCEEDS!        - Content-Based Filtering: REQUIRES |
|     (Uses sensory flavor scores)                ONBOARDING QUERY OR POPULARITY    |
|                                                                                   |
+-----------------------------------------------------------------------------------+
```

### 1. How Content-Based Filtering Solves the New-Item Problem
In a collaborative filtering system (like Netflix or Amazon), recommendations rely on user co-occurrence patterns:
$$\text{"Users who watched Item A also watched Item B"}$$
If Item B was added 10 seconds ago, zero users have watched it. Therefore, Item B has zero co-occurrences and will **never be recommended to anyone!** This creates a vicious cycle: nobody is recommended the item, so nobody watches it, so nobody rates it.

Our Recipe Recommender completely eliminates this dilemma:
- The moment a chef logs the flavor coordinates of a new dish (e.g. `[spice=4, sweet=1, savory=5, sour=2, veggie=2]`), the system projects that dish directly into 5D space.
- The dish can be recommended **immediately** to fans of Spicy Ramen and Chicken Tikka Masala, even if zero humans have ever cooked or rated it before!

### 2. Solving the New-User Cold Start Problem
When a brand-new user signs up, the system knows nothing about their preferences. Commercial applications deploy three strategies:
1. **Onboarding Questionnaire (Cold Start Interview)**: When opening the app for the first time, ask the user: *"Pick 3 dishes you love from this list"* or *"Rate your preferred spice level from 1 to 5"*. Once the user picks *Spicy Ramen*, the content-based engine immediately takes over!
2. **Contextual Fallbacks**: Recommending popular items based on time of day (e.g., breakfast items in the morning, desserts at night) or seasonal weather.
3. **Exploratory Diversity**: Offering randomized serendipity options (like our "Surprise Me" engine) to gauge the new user's reactions.

## Relevant Code (from main.py, lines 37-52, 54-61)
```python
def recommend(recipe_name: str, n: int = 3) -> pd.DataFrame:
    ...
def surprise_me(recipe_name: str) -> pd.Series:
    ...
```

## Code Explanation
- **Lines 37-52**: The `recommend()` function requires only a single input dish to generate accurate recommendations. It does not need a user profile, account ID, or 6 months of eating history.
- **Lines 54-61**: The `surprise_me()` function provides an immediate exploratory mechanism to help cold-start users discover diverse culinary categories.

## Worked Example
Imagine two rival food apps launch today:
- **App A (Pure Collaborative Filtering)**: The developers tell chefs to upload 500 recipes. But because no users have rated any recipes yet, the recommendation algorithm crashes or outputs nothing. Chefs leave the platform in frustration.
- **App B (Content-Based Recipe Recommender)**: Chefs upload 500 recipes, each tagged with 5 flavor scores. When the very first user enters the app and searches for "Margherita Pizza", the system immediately recommends Lasagna, Paella, and Mushroom Risotto with 0.52 similarity. The user is delighted and cooks dinner that evening.

## Step-by-Step Student Instructions
1. Open your Python terminal in the project directory.
2. Simulate adding a brand-new, unrated item to the model:
   ```python
   import numpy as np
   import pandas as pd
   from sklearn.preprocessing import StandardScaler
   from sklearn.neighbors import NearestNeighbors
   
   df = pd.read_csv("data/recipes.csv")
   scaler = StandardScaler()
   X = scaler.fit_transform(df[["spice", "sweet", "savory", "sour", "veggie"]])
   model = NearestNeighbors(n_neighbors=4, metric="euclidean").fit(X)
   
   # New dish with ZERO ratings: "Dragon Curry" [5, 2, 5, 1, 2]
   new_dish_raw = np.array([[5, 2, 5, 1, 2]])
   new_dish_scaled = scaler.transform(new_dish_raw)
   
   # Query nearest neighbors immediately!
   dists, inds = model.kneighbors(new_dish_scaled)
   print("Top 3 matches for brand-new Dragon Curry:")
   for d, idx in zip(dists[0], inds[0]):
       print(f"  {df.loc[idx, 'name']:22s} (Distance: {d:.2f})")
   ```
3. Observe how the system instantly retrieves matching dishes without needing user reviews.

## Expected Output or Observable Behaviour
The terminal outputs:
```text
Top 3 matches for brand-new Dragon Curry:
  Chicken Tikka Masala   (Distance: 0.68)
  Spicy Ramen            (Distance: 0.94)
  Butter Chicken         (Distance: 1.34)
```
The new item is matched instantly against existing recipes based on its intrinsic flavor vectors.

## Practical Exercises
1. **Exercise 3.1**: In your own words, explain the difference between the new-item cold start and the new-user cold start.
2. **Exercise 3.2**: How does Spotify handle new users when they create an account? Have you experienced their onboarding questionnaire?
3. **Exercise 3.3**: Why is `scaler.transform()` used on new dish vectors rather than `scaler.fit_transform()`?

## Common Mistakes and Debugging
| Mistake | Why it happens | How to resolve |
|---|---|---|
| Re-fitting the scaler on a single query vector | Calling `scaler.fit_transform(new_dish)` | Always use `scaler.transform()` on new queries so they are scaled with catalog parameters |
| Assuming content-based filtering has no cold-start challenges | Overlooking the new-user problem | Remember that new users with zero known preferences still require an initial prompt or questionnaire |
| Manually guessing feature vectors without standardization | Querying raw integers directly against scaled models | Always transform raw sensory scores through the fitted `StandardScaler` |

## Best Practices and Security Considerations
- **Cold-Start Fallbacks**: Every recommendation microservice should implement a multi-tiered fallback strategy: Personal Model $\rightarrow$ Content-Based Similar $\rightarrow$ Category Popularity $\rightarrow$ Random Serendipity.
- **Privacy Benefits**: Content-based cold-start onboarding requires no tracking cookies or cross-site tracking, respecting modern privacy regulations (GDPR, CCPA).

## Summary
The cold start problem poses a significant challenge for recommender systems when new items or users lack interaction history. While collaborative filtering fails when items have zero ratings, content-based nearest neighbor systems solve the new-item problem by mapping intrinsic attributes directly into feature space.

## Knowledge-check Questions
1. What is the new-item cold start problem?
2. What is the new-user cold start problem?
3. Why does collaborative filtering fail on brand-new items?
4. How does content-based filtering solve the new-item cold start problem?
5. How do consumer apps typically handle the new-user cold start problem?

## References
- The Cold-Start Problem in Recommender Systems (Survey Paper): https://ieeexplore.ieee.org/document/8424832
- Google Developers ML Guide on Cold Start: https://developers.google.com/machine-learning/recommendation/dnn/revisit-ca
