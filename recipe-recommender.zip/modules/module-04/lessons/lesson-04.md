# Lesson 04: Serendipity and the "Surprise Me" Feature

**Lesson ID:** lesson-04  
**Module:** module-04  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
The purpose of this lesson is to understand serendipity in recommendation systems and analyze the implementation of the "Surprise Me" feature. By the end of this lesson, you will be able to:
- Define the "filter bubble" problem in recommendation algorithms.
- Explain the role of serendipity and exploratory discovery in user satisfaction.
- Implement cross-cuisine filtering using pandas boolean conditions (`df["cuisine"] != base["cuisine"]`).
- Explain the purpose of setting `random_state=7` for reproducible random sampling.

## Prerequisites
Completion of Lessons 01-03. Familiarity with pandas boolean indexing and pseudo-random seeds.

## Concept Explanation
### The Echo Chamber and Filter Bubble Problem
Content-based recommendation systems have a notorious blind spot known as the **filter bubble** or **echo chamber**:
- If a user likes *Iron Man*, the system recommends *Iron Man 2*, *The Avengers*, *Captain America*, and *Thor*.
- If a diner likes *Margherita Pizza*, the system recommends *Lasagna*, *Calzone*, *Mushroom Risotto*, and *Pasta Carbonara*.

While these recommendations are safe and relevant, they lack **serendipity**: the unexpected, delightful discovery of something completely outside the user's usual bubble!
If a recommender never takes risks, the user eventually gets bored. In the culinary world, someone eating Italian pizza every day might secretly love Indian curries, Korean barbecue, or Mexican tacos if they were only given the chance to try them.

```
+-----------------------------------------------------------------------------------+
|                        EXPLORATION VS EXPLOITATION                                |
+-----------------------------------------------------------------------------------+
|                                                                                   |
|   EXPLOITATION (Nearest Neighbors)             EXPLORATION (Surprise Me)          |
|   - Safe, high-confidence matches              - Cross-cultural discovery         |
|   - "If you like Margherita Pizza,             - "Try stepping outside Italian    |
|      try Lasagna (Italian)"                       cuisine: Chicken Tikka Masala!" |
|   - High similarity, low novelty               - High novelty, exciting variety   |
|                                                                                   |
+-----------------------------------------------------------------------------------+
```

### Implementing the "Surprise Me" Engine
In `main.py`, we implement a dedicated serendipity engine:
```python
def surprise_me(recipe_name: str) -> pd.Series:
    matches = df.index[df["name"].str.lower() == recipe_name.lower()]
    if len(matches) == 0:
        raise ValueError(f"Recipe not found: {recipe_name}")
    base = df.loc[int(matches[0])]
    different = df[df["cuisine"] != base["cuisine"]]
    return different.sample(1, random_state=7).iloc[0]
```

1. **Locate Base Recipe**: Finds the user's selected dish and retrieves its cuisine (e.g., `"Italian"`).
2. **Filter Out Base Cuisine**: `df["cuisine"] != base["cuisine"]` creates a boolean mask that keeps only dishes from other culinary cultures (e.g., Japanese, Mexican, Indian, Thai).
3. **Random Sampling with Fixed Seed**: `.sample(1, random_state=7)` randomly selects one dish from the filtered subset.
4. **Reproducibility with `random_state`**: By setting `random_state=7`, the pseudo-random number generator produces the exact same selection every time the script runs. This is critical for automated testing and educational consistency!

## Relevant Code (from main.py, lines 54-61, 71-72)
```python
def surprise_me(recipe_name: str) -> pd.Series:
    matches = df.index[df["name"].str.lower() == recipe_name.lower()]
    if len(matches) == 0:
        raise ValueError(f"Recipe not found: {recipe_name}")
    base = df.loc[int(matches[0])]
    different = df[df["cuisine"] != base["cuisine"]]
    return different.sample(1, random_state=7).iloc[0]

...
surprise = surprise_me("Margherita Pizza")
print(f"\nSurprise me: {surprise['name']} ({surprise['cuisine']})")
```

## Code Explanation
- **Line 58**: `base = df.loc[int(matches[0])]` retrieves the base recipe row as a pandas Series.
- **Line 59**: `different = df[df["cuisine"] != base["cuisine"]]` creates a filtered DataFrame excluding the base cuisine.
- **Line 60**: `.sample(1, random_state=7).iloc[0]` draws a sample of size 1 with seed 7 and extracts the row.
- **Lines 71-72**: Calls the function with `"Margherita Pizza"` and prints the surprise dish and its cuisine.

## Worked Example
When `surprise_me("Margherita Pizza")` is called:
1. Margherita Pizza has `cuisine = "Italian"`.
2. Total catalog has 24 recipes. 4 recipes are Italian (Margherita Pizza, Lasagna, Caprese Salad, Mushroom Risotto).
3. `different` contains the remaining 20 non-Italian recipes.
4. The random sampler (with seed 7) selects row 2: **Chicken Tikka Masala (Indian)**.
5. The console displays:
   `Surprise me: Chicken Tikka Masala (Indian)`

The user, who came in looking for pizza, is pleasantly surprised with an invitation to explore rich, aromatic Indian curry!

## Step-by-Step Student Instructions
1. Open your Python terminal in the project directory.
2. Load the dataset:
   ```python
   import pandas as pd
   df = pd.read_csv("data/recipes.csv")
   ```
3. Test filtering out Italian dishes:
   ```python
   non_italian = df[df["cuisine"] != "Italian"]
   print("Total non-Italian recipes:", len(non_italian))
   ```
4. Sample with seed 7:
   ```python
   sample_7 = non_italian.sample(1, random_state=7).iloc[0]
   print("Sample with seed 7:", sample_7["name"], f"({sample_7['cuisine']})")
   ```
5. Sample with seed 42 to see a different surprise:
   ```python
   sample_42 = non_italian.sample(1, random_state=42).iloc[0]
   print("Sample with seed 42:", sample_42["name"], f"({sample_42['cuisine']})")
   ```

## Expected Output or Observable Behaviour
The terminal outputs:
```text
Total non-Italian recipes: 20
Sample with seed 7: Chicken Tikka Masala (Indian)
Sample with seed 42: Burrito Bowl (Mexican)
```
Notice how changing the random seed yields another exciting cross-cuisine discovery.

## Practical Exercises
1. **Exercise 4.1**: Modify `surprise_me` to select a dish from a different cuisine that *also* has a similarity score $\ge 0.40$ to the base recipe. (Combine nearest neighbor search with cross-cuisine filtering).
2. **Exercise 4.2**: What happens if every recipe in the dataset belongs to the same cuisine? What does `df[df["cuisine"] != base["cuisine"]]` return?
3. **Exercise 4.3**: Why is setting `random_state` essential in machine learning grading scripts and unit tests?

## Common Mistakes and Debugging
| Mistake | Why it happens | How to resolve |
|---|---|---|
| Calling `.sample()` without `.iloc[0]` | `.sample(1)` returns a 1-row DataFrame, not a Series | Add `.iloc[0]` to extract the row Series object |
| Calling `.sample()` on an empty DataFrame | Filtering eliminates all rows if no other cuisines exist | Check `if len(different) == 0:` before sampling |
| Omitting `random_state` | Generating non-deterministic outputs on every run | Use `random_state=7` for repeatable, reproducible results |

## Best Practices and Security Considerations
- **Exploration/Exploitation Balance**: Commercial recommenders (like Spotify or TikTok) deliberately inject 10-20% exploratory items into feeds to keep users engaged and prevent algorithmic stagnation.
- **Deterministic Testing**: Always parameterize random seeds in testing environments so assertions evaluate consistently across different test runs.

## Summary
The "Surprise Me" feature combats the filter bubble by filtering out the user's familiar cuisine and sampling dishes from alternative cultural traditions using pandas and a reproducible random seed (`random_state=7`). This balances similarity exploitation with serendipitous exploration.

## Knowledge-check Questions
1. What is the "filter bubble" problem in recommendation systems?
2. How does `main.py` filter the catalog when generating a surprise recommendation?
3. What is the role of `random_state=7` in `.sample(1, random_state=7)`?
4. What dish and cuisine does `surprise_me("Margherita Pizza")` return in `main.py`?
5. Why is a balance between exploitation (similarity) and exploration (serendipity) important for user satisfaction?

## References
- Serendipity in Recommender Systems (ACM Digital Library): https://dl.acm.org/doi/10.1145/2959100.2959176
- Pandas DataFrame sample() Documentation: https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.sample.html
