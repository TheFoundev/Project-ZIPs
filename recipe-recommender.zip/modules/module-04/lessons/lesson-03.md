# Lesson 03: Calculating Similarity Scores from Distance

**Lesson ID:** lesson-03  
**Module:** module-04  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
The purpose of this lesson is to understand how geometric distance is converted into an intuitive, bounded similarity score. By the end of this lesson, you will be able to:
- Explain why raw geometric distance is unintuitive for end-users.
- State the formula used in `main.py` to map distance to similarity: $S = \frac{1}{1 + d}$.
- Analyze the boundary properties of this formula ($d=0 \implies S=1.0$, $d \to \infty \implies S \to 0$).
- Interpret similarity values across recommendations (e.g. 1.00 vs 0.52 vs 0.22).

## Prerequisites
Completion of Lessons 01 and 02. Understanding of basic fractions and functions.

## Concept Explanation
### The Problem with Raw Distance
When an algorithm calculates Euclidean distance $d$, it outputs numbers like:
- Distance to Lasagna: $0.912$
- Distance to Paella: $1.187$
- Distance to Mushroom Risotto: $1.391$

Raw distances present two major usability problems:
1. **Inverted Logic**: To a human, a "larger score" usually means "better match". Distance is inverted: smaller numbers mean closer matches, and larger numbers mean worse matches.
2. **Unbounded Scale**: Euclidean distance ranges from $0$ to $+\infty$. If you tell a customer: *"This dish has a distance of 1.187,"* the customer has no frame of reference. Is 1.187 good? Is it terrible? Without knowing the maximum possible distance, the number is meaningless.

### Transforming Distance to Similarity
To create an intuitive metric, data scientists transform distance $d$ into **similarity** $S$ such that:
- Similarity is bounded between **0 and 1** (or 0% to 100%).
- Identical items have a similarity of **1.0** (100% match).
- Completely unrelated items have a similarity approaching **0.0** (0% match).

In `main.py`, we use the classic inverse-linear transformation:
$$S = \frac{1}{1 + d}$$

```
                Similarity S
                   1.0 +------------* (d=0, S=1.0 - Perfect match!)
                       |             \
                   0.8 |              \
                       |               \
                   0.6 |                \
                       |                 * (d=1, S=0.5)
                   0.4 |                  \
                       |                   * (d=2, S=0.33)
                   0.2 |                    \
                       |                     \----------> (d -> infinity, S -> 0)
                   0.0 +----------------------------------> Distance d
                       0       1       2       3       4
```

### Mathematical Properties of $S = \frac{1}{1 + d}$
1. **When $d = 0$ (Identical taste)**:
   $$S = \frac{1}{1 + 0} = \frac{1}{1} = 1.000$$
2. **When $d = 1$ (Moderate separation)**:
   $$S = \frac{1}{1 + 1} = \frac{1}{2} = 0.500$$
3. **When $d$ grows very large ($d \to \infty$)**:
   The denominator grows infinitely large, so $S \to 0.0$.
4. **Guaranteed Positive & Monotonic**:
   Because $d \ge 0$, the denominator $1 + d$ is always $\ge 1$. There is never a division by zero, and similarity always decreases smoothly as distance increases.

## Relevant Code (from main.py, lines 49-51)
```python
rows.append(
    {
        "name": df.loc[neighbor, "name"],
        "cuisine": df.loc[neighbor, "cuisine"],
        "similarity": 1 / (1 + distance),
    }
)
```

## Code Explanation
- **Line 49**: Appends the recipe name string.
- **Line 50**: Appends the cuisine category string.
- **Line 51**: `similarity = 1 / (1 + distance)` computes the bounded float similarity score and stores it under the key `"similarity"`.

## Worked Example
Let us compute the similarity scores for recommendations to **Chocolate Cake**:
From `main.py`:
- Neighbor 1: **Pancakes**
  - Feature distance: $d = 0.000$ (identical flavor ratings!)
  - $\text{similarity} = \frac{1}{1 + 0} = \mathbf{1.000}$ (100% match)
- Neighbor 2: **Blueberry Muffin**
  - Feature distance: $d = 1.187$
  - $\text{similarity} = \frac{1}{1 + 1.187} = \frac{1}{2.187} \approx \mathbf{0.457}$ (~46% match)
- Neighbor 3: **Butter Chicken**
  - Feature distance: $d = 3.608$
  - $\text{similarity} = \frac{1}{1 + 3.608} = \frac{1}{4.608} \approx \mathbf{0.217}$ (~22% match)

Notice how intuitive the scores are:
- Pancakes is a perfect 1.00.
- Blueberry Muffin is a solid sweet breakfast companion at 0.46.
- Butter Chicken, being a savory meat dish, drops down to 0.22.

## Step-by-Step Student Instructions
1. Open your Python terminal.
2. Define a Python function implementing the similarity formula:
   ```python
   def dist_to_sim(d):
       return 1 / (1 + d)
   ```
3. Test various distances:
   ```python
   for d in [0.0, 0.5, 1.0, 2.0, 5.0, 10.0]:
       print(f"Distance: {d:4.1f} --> Similarity: {dist_to_sim(d):.3f}")
   ```
4. Observe how similarity decreases as distance increases.

## Expected Output or Observable Behaviour
The terminal outputs:
```text
Distance:  0.0 --> Similarity: 1.000
Distance:  0.5 --> Similarity: 0.667
Distance:  1.0 --> Similarity: 0.500
Distance:  2.0 --> Similarity: 0.333
Distance:  5.0 --> Similarity: 0.167
Distance: 10.0 --> Similarity: 0.091
```
This confirms that the transformation produces clean, monotonically decreasing numbers strictly bounded in $(0, 1]$.

## Practical Exercises
1. **Exercise 3.1**: If two dishes have a similarity score of 0.80, what was their Euclidean distance? (Solve $0.80 = \frac{1}{1 + d}$ for $d$).
2. **Exercise 3.2**: Another popular formula for converting distance to similarity is the exponential kernel: $S = e^{-d}$. Write a function in Python for $e^{-d}$ and compare its values to $\frac{1}{1 + d}$.
3. **Exercise 3.3**: Why is $S = \frac{1}{d}$ a poor choice for converting distance to similarity? What happens when $d = 0$?

## Common Mistakes and Debugging
| Mistake | Why it happens | How to resolve |
|---|---|---|
| Using `1 / distance` | Forgetting the `+ 1` in the denominator | Causes a fatal `ZeroDivisionError` whenever distance is 0.0 |
| Confusing similarity and distance | Sorting by similarity ascending instead of descending | When ranking similarity, higher is better (descending order) |
| Formatting similarity with integer formatting | Using `:d` instead of `:.2f` | Similarity scores are floats between 0 and 1; format with `:.2f` or `:.3f` |

## Best Practices and Security Considerations
- **Division by Zero Prevention**: Always ensure denominators include a positive damping constant (like $+1$) to prevent runtime crashes on identical vectors.
- **Metric Bounding**: When exposing scores to frontend applications or public APIs, bounded metrics in $[0, 1]$ allow designers to easily display match percentages (e.g. "92% Match").

## Summary
To make recommendations intuitive, raw Euclidean distance is transformed into bounded similarity using $S = \frac{1}{1 + d}$. This maps distance values to the range $(0, 1]$, where 1.0 indicates identical flavor coordinates and scores diminish toward 0 as recipes diverge in flavor space.

## Knowledge-check Questions
1. Why is raw Euclidean distance unintuitive for non-technical users?
2. What is the similarity score between two recipes with a distance of 0.0?
3. What happens to the similarity score as Euclidean distance approaches infinity?
4. Why does the formula use $1 / (1 + d)$ rather than $1 / d$?
5. What was the similarity score between Chocolate Cake and Pancakes in `main.py`?

## References
- Similarity Measures in Machine Learning: https://developers.google.com/machine-learning/clustering/similarity/measuring-similarity
- Radial Basis and Inverse Distance Functions: https://en.wikipedia.org/wiki/Inverse_distance_weighting
