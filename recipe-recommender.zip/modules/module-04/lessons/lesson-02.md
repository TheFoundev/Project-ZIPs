# Lesson 02: Why Neighbor 0 is Skipped (Self-Match)

**Lesson ID:** lesson-02  
**Module:** module-04  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
The purpose of this lesson is to examine the self-match phenomenon in catalog nearest-neighbor retrieval. By the end of this lesson, you will be able to:
- Explain why the closest nearest neighbor to any indexed item is always the item itself.
- Understand the mathematical fact that $d(\mathbf{x}, \mathbf{x}) = 0.0$.
- Apply Python slicing syntax `[1:]` to remove the self-match from recommendation results.
- Implement loop iteration using `zip(distances[0][1:], indices[0][1:])`.

## Prerequisites
Completion of Lesson 01. Understanding of Python slicing syntax `[start:stop]`.

## Concept Explanation
### The Self-Match Phenomenon
In any metric space, the distance between any point $\mathbf{x}$ and itself is strictly zero:
$$d(\mathbf{x}, \mathbf{x}) = \sqrt{\sum (x_i - x_i)^2} = \sqrt{0} = 0.0$$

Because our `NearestNeighbors` model was fit on the **entire recipe catalog**, the query recipe is already present inside the index!
When you ask the model:
*"What are the 3 closest recipes to Margherita Pizza?"*
The algorithm evaluates distance to all indexed points:
1. Margherita Pizza: distance $= 0.000$ (Closest!)
2. Lasagna: distance $= 0.912$
3. Paella: distance $= 1.187$
4. Mushroom Risotto: distance $= 1.391$

If you do not filter the results, your recommender will proudly announce:
$$\text{"If you like Margherita Pizza, you will love... Margherita Pizza!"}$$
While mathematically accurate, recommending an item to a user who just requested that exact item is completely useless and frustrating from a user-experience standpoint.

```
Returned array: [Margherita Pizza, Lasagna, Paella, Mushroom Risotto]
                 |               |--------------------------------|
                 v                               v
             Index 0                         Indices 1 to 3
          (Self-Match:                     (GENUINE RECOMMENDATIONS:
          Distance = 0.0)                   Distance > 0.0)
          --> DISCARD!                     --> KEEP!
```

### The `n + 1` and `[1:]` Pattern
To solve this, professional recommendation systems use a simple, elegant pattern:
1. When the user requests $n$ recommendations, ask the model for **$n + 1$ neighbors**:
   ```python
   distances, indices = model.kneighbors(query_vec, n_neighbors=n + 1)
   ```
2. Discard index 0 by slicing from index 1 to the end:
   ```python
   recommended_distances = distances[0][1:]
   recommended_indices = indices[0][1:]
   ```
3. This guarantees that you return exactly $n$ distinct, novel items to the user!

## Relevant Code (from main.py, lines 42-45)
```python
distances, indices = model.kneighbors(scaled_features[index].reshape(1, -1), n_neighbors=n + 1)
rows = []
for distance, neighbor in zip(distances[0][1:], indices[0][1:]):
    rows.append(
```

## Code Explanation
- **Line 42**: Requests `n_neighbors=n + 1`. If `n=3`, it requests 4 points.
- **Line 43**: Initializes an empty list `rows` to hold recommendation dictionaries.
- **Line 44**: Uses `zip(distances[0][1:], indices[0][1:])`.
  - `distances[0]` is a 1D slice of distances for the 0th query.
  - `[1:]` slices from element 1 to the end, skipping element 0 (the self-match).
  - `indices[0][1:]` slices the matching neighbor indices, skipping element 0.
  - `zip()` pairs each neighbor distance with its corresponding recipe index.

## Worked Example
Let us trace `zip(distances[0][1:], indices[0][1:])` for Margherita Pizza:
- Raw `distances[0]`: `[0.0, 0.912, 1.187, 1.391]`
- Raw `indices[0]`: `[0, 10, 15, 22]`

Applying `[1:]`:
- `distances[0][1:]`: `[0.912, 1.187, 1.391]` (length 3)
- `indices[0][1:]`: `[10, 15, 22]` (length 3)

The `for` loop executes 3 iterations:
- Iteration 1: `distance = 0.912`, `neighbor = 10` (Lasagna)
- Iteration 2: `distance = 1.187`, `neighbor = 15` (Paella)
- Iteration 3: `distance = 1.391`, `neighbor = 22` (Mushroom Risotto)

The user receives three genuine, delicious culinary alternatives.

## Step-by-Step Student Instructions
1. Open your Python terminal in the project directory.
2. Load the dataset, scaler, and model as in Lesson 01.
3. Query 4 neighbors for `df.iloc[1]` (Spicy Ramen):
   ```python
   query = scaled_features[1].reshape(1, -1)
   dists, inds = model.kneighbors(query, n_neighbors=4)
   print("All distances:", dists[0])
   print("All indices:", inds[0])
   ```
4. Slice and zip:
   ```python
   for d, idx in zip(dists[0][1:], inds[0][1:]):
       print(f"Neighbor: {df.loc[idx, 'name']:20s} Distance: {d:.3f}")
   ```
5. Confirm that Spicy Ramen does not appear in the printed recommendations.

## Expected Output or Observable Behaviour
The terminal outputs:
```text
All distances: [0.         1.05777176 1.51737488 1.51737488]
All indices: [ 1  2 23  6]

Neighbor: Chicken Tikka Masala Distance: 1.058
Neighbor: Kimchi Fried Rice    Distance: 1.517
Neighbor: Taco                 Distance: 1.517
```
Spicy Ramen (index 1) is cleanly discarded, and the user receives Chicken Tikka Masala, Kimchi Fried Rice, and Taco.

## Practical Exercises
1. **Exercise 2.1**: What would happen if a student forgot `n + 1` and called `n_neighbors=n`, then applied `[1:]`? How many recommendations would the user receive?
2. **Exercise 2.2**: If two distinct recipes in the catalog have identical flavor coordinates (like Pancakes and Chocolate Cake), does querying Chocolate Cake return Pancakes at distance 0.0?
3. **Exercise 2.3**: What happens if the query vector is a *new, custom recipe* that was not in the original training set? Does index 0 have distance 0.0 in that case?

## Common Mistakes and Debugging
| Mistake | Why it happens | How to resolve |
|---|---|---|
| Recommending the query recipe itself | Slicing `distances[0]` without `[1:]` | Always apply `[1:]` to skip the self-match at index 0 |
| Returning $n-1$ recommendations | Forgetting `n + 1` in `kneighbors()` call | Always query `n_neighbors=n + 1` so that dropping index 0 leaves exactly $n$ items |
| Indexing errors with 2D return arrays | Writing `distances[1:]` instead of `distances[0][1:]` | Remember `distances` has shape `(1, k)`; access row 0 first |

## Best Practices and Security Considerations
- **Catalog Duplicate Detection**: Monitoring distances of 0.0 between *different* items can help catalog administrators identify duplicate or redundant products in their database.
- **Query Source Differentiation**: In advanced systems, check whether the query vector exists in the indexed catalog. If querying an indexed item, slice `[1:]`; if querying a custom arbitrary vector, keep all items `[:n]`.

## Summary
Because the query recipe is an indexed member of the dataset, it is guaranteed to be its own closest neighbor with a distance of zero. By requesting $n + 1$ neighbors and slicing `[1:]`, the recommender removes the redundant self-match and presents the user with $n$ novel culinary suggestions.

## Knowledge-check Questions
1. Why is the distance between any indexed recipe and itself always 0.0?
2. Why is recommending the query item back to the user considered bad user experience?
3. Why must `kneighbors()` be called with `n_neighbors = n + 1`?
4. What does the slice `distances[0][1:]` accomplish?
5. If two completely different recipes have identical flavor scores, what will the distance between them be?

## References
- Scikit-learn Nearest Neighbors Documentation: https://scikit-learn.org/stable/modules/neighbors.html
- Python Slicing Syntax Reference: https://docs.python.org/3/tutorial/introduction.html#strings
