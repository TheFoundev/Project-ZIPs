# Lesson 01: Querying the Model with kneighbors()

**Lesson ID:** lesson-01  
**Module:** module-04  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
The purpose of this lesson is to master querying the fitted `NearestNeighbors` model using the `kneighbors()` method. By the end of this lesson, you will be able to:
- Locate target recipes within the DataFrame using case-insensitive string matching.
- Handle missing recipe queries cleanly by raising a descriptive `ValueError`.
- Format and reshape query vectors into the required 2D structure using `.reshape(1, -1)`.
- Execute `model.kneighbors()` and unpack the returned `distances` and `indices` arrays.

## Prerequisites
Completion of Module 03. Familiarity with NumPy array indexing and Python exception handling.

## Concept Explanation
### The Query Pipeline
Once the `NearestNeighbors` model is fitted on our 24 standardized recipe vectors, it is ready to answer proximity queries. The recommendation process follows four logical stages:

```
[User queries: "Spicy Ramen"]
            |
            v
1. Case-insensitive lookup in df["name"] ---> Index: 1
            |
            v
2. Extract standardized vector: scaled_features[1] (shape: (5,))
            |
            v
3. Reshape to 2D array: .reshape(1, -1) (shape: (1, 5))
            |
            v
4. model.kneighbors(query_vec, n_neighbors=4)
            |
            +--------------------+
            |                    |
            v                    v
      distances: (1, 4)     indices: (1, 4)
```

### 1. Robust Recipe Matching
Users rarely type recipe names with exact capitalization. Some may type `"spicy ramen"`, while others type `"SPICY RAMEN"`.
In `main.py`, the lookup uses:
```python
matches = df.index[df["name"].str.lower() == recipe_name.lower()]
```
- `.str.lower()` converts all names in the dataset to lowercase.
- `recipe_name.lower()` converts the user's input to lowercase.
- `df.index[...]` retrieves the matching integer row index.
- If `len(matches) == 0`, the query fails gracefully by raising:
  ```python
  raise ValueError(f"Recipe not found: {recipe_name}")
  ```

### 2. Passing 2D Query Arrays to `kneighbors()`
Scikit-learn is built for batch processing. Even when you are querying for a single recipe, `model.kneighbors()` expects a 2-dimensional matrix of shape `(n_queries, n_features)`.
Taking `scaled_features[index]` yields a 1D slice of shape `(5,)`.
Calling `.reshape(1, -1)` tells NumPy:
*"Keep the total number of elements identical, create 1 row, and let NumPy automatically infer the column count (which will be 5)."*
The resulting array has shape `(1, 5)`, which `kneighbors()` accepts without error.

### 3. Understanding the Return Values
`model.kneighbors()` returns a tuple of two NumPy arrays:
1. `distances`: A 2D array of floats representing the Euclidean distances from the query vector to each found neighbor.
2. `indices`: A 2D array of integers representing the row positions of those neighbors in the original training DataFrame.

## Relevant Code (from main.py, lines 37-43)
```python
def recommend(recipe_name: str, n: int = 3) -> pd.DataFrame:
    matches = df.index[df["name"].str.lower() == recipe_name.lower()]
    if len(matches) == 0:
        raise ValueError(f"Recipe not found: {recipe_name}")
    index = int(matches[0])
    distances, indices = model.kneighbors(scaled_features[index].reshape(1, -1), n_neighbors=n + 1)
```

## Code Explanation
- **Line 37**: Defines `recommend()` with type annotations, accepting a recipe string and an optional count `n` (defaulting to 3), returning a pandas DataFrame.
- **Lines 38-40**: Performs case-insensitive matching and raises a `ValueError` if the recipe is not found.
- **Line 41**: Extracts the scalar integer index of the matched recipe.
- **Line 42**: Queries the spatial index for `n + 1` neighbors. Notice `n + 1`: because the query recipe itself will be returned as the closest neighbor, we must request one extra neighbor!

## Worked Example
Let us trace what `model.kneighbors()` returns when querying `"Spicy Ramen"` with `n=3` (`n_neighbors=4`):
```python
query_vec = scaled_features[1].reshape(1, -1)
distances, indices = model.kneighbors(query_vec, n_neighbors=4)
print("Distances:", distances)
print("Indices:", indices)
```
Output:
```text
Distances: [[0.         1.05777176 1.51737488 1.51737488]]
Indices: [[ 1  2 23  6]]
```
Let us inspect what row indices 1, 2, 23, and 6 correspond to:
- Index 1: Spicy Ramen (distance 0.0)
- Index 2: Chicken Tikka Masala (distance 1.058)
- Index 23: Kimchi Fried Rice (distance 1.517)
- Index 6: Taco (distance 1.517)
Notice that Taco and Kimchi Fried Rice have identical distances (1.517) because of their identical flavor coordinates!

## Step-by-Step Student Instructions
1. Open your Python terminal in the project directory.
2. Load data, scale features, and fit `NearestNeighbors`:
   ```python
   import pandas as pd
   from sklearn.preprocessing import StandardScaler
   from sklearn.neighbors import NearestNeighbors
   
   df = pd.read_csv("data/recipes.csv")
   scaler = StandardScaler()
   scaled_features = scaler.fit_transform(df[["spice", "sweet", "savory", "sour", "veggie"]])
   model = NearestNeighbors(n_neighbors=6, metric="euclidean").fit(scaled_features)
   ```
3. Test looking up `"margherita pizza"` in lowercase:
   ```python
   matches = df.index[df["name"].str.lower() == "margherita pizza".lower()]
   print("Matched index:", int(matches[0]))
   ```
4. Query 4 neighbors:
   ```python
   dists, inds = model.kneighbors(scaled_features[0].reshape(1, -1), n_neighbors=4)
   print("Closest 4 indices:", inds[0])
   print("Corresponding names:", df.loc[inds[0], "name"].tolist())
   ```

## Expected Output or Observable Behaviour
The terminal outputs:
```text
Matched index: 0
Closest 4 indices: [ 0 10 15 22]
Corresponding names: ['Margherita Pizza', 'Lasagna', 'Paella', 'Mushroom Risotto']
```
The query returns Margherita Pizza itself first, followed by Lasagna, Paella, and Mushroom Risotto.

## Practical Exercises
1. **Exercise 1.1**: What happens if you query `recommend("Nonexistent Dish")`? Verify that Python raises a clean `ValueError` with your message.
2. **Exercise 1.2**: Write a function that takes a recipe name and returns only the integer row index, or `-1` if not found.
3. **Exercise 1.3**: Query 6 neighbors for `"Chocolate Cake"`. What are the names of all 6 returned dishes?

## Common Mistakes and Debugging
| Mistake | Why it happens | How to resolve |
|---|---|---|
| `ValueError: Expected 2D array, got 1D array instead` | Passing `scaled_features[index]` directly without `.reshape(1, -1)` | Always reshape single-vector queries to `(1, -1)` |
| `IndexError: index 0 is out of bounds for axis 0 with size 0` | Trying to access `matches[0]` when `matches` is empty | Check `if len(matches) == 0:` before indexing `matches[0]` |
| Case sensitivity lookup failures | Matching `df["name"] == recipe_name` directly | Always convert both sides to `.str.lower()` and `.lower()` |

## Best Practices and Security Considerations
- **Input Sanitization**: Always strip leading and trailing whitespace (`recipe_name.strip()`) to prevent failed lookups from accidental user typos.
- **Descriptive Errors**: Providing clear error messages like `f"Recipe not found: {recipe_name}"` helps users and API clients troubleshoot typos immediately.

## Summary
The `recommend()` function locates the query recipe via case-insensitive matching, extracts and reshapes its scaled 5D feature vector, and calls `model.kneighbors()` to retrieve distance and index arrays. Requesting `n + 1` neighbors prepares the pipeline to exclude the query recipe itself.

## Knowledge-check Questions
1. Why does `main.py` convert recipe names to lowercase during lookup?
2. What exception is raised if a queried recipe name does not exist in `recipes.csv`?
3. Why does `scaled_features[index]` require `.reshape(1, -1)`?
4. What two arrays are returned by `model.kneighbors()`?
5. Why does `main.py` request `n + 1` neighbors instead of `n` neighbors?

## References
- Scikit-learn NearestNeighbors kneighbors Method: https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.NearestNeighbors.html#sklearn.neighbors.NearestNeighbors.kneighbors
- Pandas String Methods: https://pandas.pydata.org/docs/user_guide/text.html
