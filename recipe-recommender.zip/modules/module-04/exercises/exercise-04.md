# Module 4 Exercises: Making Recommendations & Calculating Similarity

## Exercise 4.1: Implementing and Testing recommend() (15 min)
**Objective:** Implement the `recommend()` function and verify neighbor retrieval and similarity calculations.

**Problem Statement:**
Implement `recommend(recipe_name, n=3)` from scratch in Python:
1. Ensure case-insensitive name matching.
2. Raise `ValueError` if the dish is not found.
3. Reshape query vectors using `.reshape(1, -1)`.
4. Slice `[1:]` to remove self-match.
5. Compute similarity using $S = \frac{1}{1 + d}$.

Run your function on:
- `"Spicy Ramen"` with $n=3$
- `"CHOCOLATE CAKE"` with $n=3$

**Acceptance Criteria:**
- [ ] Handles uppercase `"CHOCOLATE CAKE"` without error.
- [ ] Returns a DataFrame with columns `["name", "cuisine", "similarity"]`.
- [ ] Top recommendation for Spicy Ramen is Chicken Tikka Masala.
- [ ] Top recommendation for Chocolate Cake is Pancakes with similarity 1.000.

---

## Exercise 4.2: Evaluating Alternative Similarity Formulas (15 min)
**Objective:** Compare the inverse distance formula with the exponential decay formula.

**Problem Statement:**
In addition to the formula $S_1 = \frac{1}{1 + d}$, another common formula used in machine learning is exponential decay:
$$S_2 = e^{-d}$$
Write a Python script that calculates both $S_1$ and $S_2$ for distances $d \in [0.0, 0.5, 1.0, 1.5, 2.0, 3.0, 5.0]$.
Print a comparative table and answer:
1. At what distance do both formulas equal 1.0?
2. Which formula decays faster as distance increases?
3. Which formula would you recommend for penalizing distant recipes more aggressively?

**Acceptance Criteria:**
- [ ] Produces comparative table of $S_1$ vs $S_2$.
- [ ] Correctly identifies that both equal 1.0 at $d=0.0$.
- [ ] Correctly identifies that exponential decay $e^{-d}$ drops off faster than $\frac{1}{1 + d}$.

---

## Exercise 4.3: Exploring the Surprise Me Engine (15 min)
**Objective:** Test cross-cuisine serendipity and random seed effects.

**Problem Statement:**
Write a Python script to test `surprise_me(recipe_name)`:
1. Call `surprise_me("Spicy Ramen")` using `random_state=7`. What dish is returned?
2. Call `surprise_me("Spicy Ramen")` across seeds $1, 2, 3, 4, 5$. Record the returned dish for each seed.
3. Verify that none of the returned dishes have `cuisine == "Japanese"`.

**Acceptance Criteria:**
- [ ] Script executes and prints surprise recommendations across seeds 1 through 5.
- [ ] Verifies that 0 returned dishes belong to the base recipe's cuisine.
