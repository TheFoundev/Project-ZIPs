# Module 3 Exercises: Nearest Neighbors & Distance Metrics

## Exercise 3.1: Manual Z-Score Standardization (15 min)
**Objective:** Calculate z-scores manually and verify them against scikit-learn's `StandardScaler`.

**Problem Statement:**
You are given a 1-dimensional array of 5 flavor scores representing the `spice` rating for 5 dishes:
$$X = [1, 2, 3, 4, 5]$$

1. Calculate the sample mean $\mu$ of $X$.
2. Calculate the population standard deviation $\sigma = \sqrt{\frac{1}{N} \sum (x_i - \mu)^2}$ of $X$.
3. Compute the standardized z-score for each value: $z_i = \frac{x_i - \mu}{\sigma}$.
4. Use `sklearn.preprocessing.StandardScaler` on $X.reshape(-1, 1)$ in Python and verify that your manual calculations match scikit-learn's output exactly.

**Acceptance Criteria:**
- [ ] Correctly identifies $\mu = 3.0$.
- [ ] Correctly identifies $\sigma = \sqrt{2.0} \approx 1.4142$.
- [ ] Computes z-scores: $[-1.414, -0.707, 0.0, 0.707, 1.414]$.
- [ ] Verification script in Python matches to 3 decimal places.

---

## Exercise 3.2: Multi-Dimensional Distance Calculations (15 min)
**Objective:** Calculate Euclidean and Manhattan distances between 5-dimensional vectors.

**Problem Statement:**
Two dishes have the following standardized feature vectors:
$$\mathbf{u} = [1.2, -0.5, 0.8, -1.0, 0.0]$$
$$\mathbf{v} = [0.8, -0.5, 1.2, -0.2, 0.5]$$

1. Calculate the component differences: $\mathbf{u} - \mathbf{v}$.
2. Calculate the Euclidean distance ($L_2$ norm): $d = \sqrt{\sum (u_i - v_i)^2}$.
3. Calculate the Manhattan distance ($L_1$ norm): $d = \sum |u_i - v_i|$.
4. Which distance metric produces a larger numerical value, and why is this always true?

**Acceptance Criteria:**
- [ ] Component differences: $[0.4, 0.0, -0.4, -0.8, -0.5]$.
- [ ] Euclidean distance calculated accurately ($pprox 1.10$).
- [ ] Manhattan distance calculated accurately ($2.10$).
- [ ] Correctly states that Manhattan distance $\ge$ Euclidean distance for any pair of points.

---

## Exercise 3.3: Exploring Distance Metrics in NearestNeighbors (15 min)
**Objective:** Compare recommendation results under Euclidean versus Manhattan distance metrics.

**Problem Statement:**
Write a Python script that loads `data/recipes.csv`, scales the features, and trains two separate `NearestNeighbors` models:
- Model A: `metric="euclidean"`
- Model B: `metric="manhattan"`

Query both models for the top 3 nearest neighbors to `"Spicy Ramen"` (excluding the self-match).
Compare the recommendations:
1. Do both models recommend the same 3 dishes?
2. Do the similarity rankings change?
3. Write a short paragraph interpreting any observed differences.

**Acceptance Criteria:**
- [ ] Script successfully trains both models.
- [ ] Generates top 3 neighbors for both metrics.
- [ ] Reports dishes and comparative rankings.
