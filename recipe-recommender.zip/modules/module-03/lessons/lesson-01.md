# Lesson 01: Feature Scaling with StandardScaler

**Lesson ID:** lesson-01  
**Module:** module-03  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
The purpose of this lesson is to master feature standardization using `sklearn.preprocessing.StandardScaler`. By the end of this lesson, you will be able to:
- Explain why distance-based algorithms are sensitive to differences in feature scale and variance.
- State the mathematical equation for z-score standardization ($z = \frac{x - \mu}{\sigma}$).
- Use `StandardScaler.fit_transform()` to normalize the 5D flavor matrix.
- Verify that scaled features exhibit a mean of approximately 0 and a standard deviation of 1.

## Prerequisites
Completion of Module 02. Understanding of basic statistical concepts: mean ($\mu$) and standard deviation ($\sigma$).

## Concept Explanation
### Why distance metrics require scaled features
In machine learning, algorithms that calculate distances between points—such as K-Nearest Neighbours, K-Means clustering, and Principal Component Analysis—are **scale-sensitive**:
Suppose we compared two recipes using two unscaled attributes:
- **Calories**: ranging from 200 to 1,200 (difference of 500 calories).
- **Spice**: ranging from 1 to 5 (difference of 2 units).

If we compute Euclidean distance directly:
$$d = \sqrt{(500)^2 + (2)^2} = \sqrt{250,000 + 4} = \sqrt{250,004} \approx 500.004$$
Notice that the calorie difference completely dwarfs the spice difference! The spice dimension contributes almost nothing (only 0.004) to the final distance, rendering it practically invisible.

Even when all features are recorded on a 1-to-5 scale, features can have very different **variances**:
- In our dataset, `sweet` has a standard deviation of 1.50, spanning the full spectrum from unsweetened (1) to cake (5).
- In contrast, `veggie` has a standard deviation of only 0.74, with most dishes clustered around 1 and 2.
Without scaling, differences in sweetness would exert twice the mathematical influence on neighbor queries as differences in vegetable presence!

### The Z-Score Standardization Formula
`StandardScaler` solves this by transforming every feature column independently:
$$z = \frac{x - \mu}{\sigma}$$
Where:
- $x$: The original raw value.
- $\mu$: The mean (average) of that column across all recipes.
- $\sigma$: The standard deviation of that column.

After standardization:
- Every feature column has a **mean of exactly 0.0**.
- Every feature column has a **standard deviation (and variance) of exactly 1.0**.
- A positive z-score means the recipe is above average in that flavor; a negative z-score means it is below average.

## Relevant Code (from main.py, lines 20, 32-33)
```python
from sklearn.preprocessing import StandardScaler

...
scaler = StandardScaler()
scaled_features = scaler.fit_transform(df[FEATURES])
```

## Code Explanation
- **Line 20**: Imports `StandardScaler` from scikit-learn's preprocessing module.
- **Line 32**: Instantiates the `scaler` object.
- **Line 33**: `fit_transform(df[FEATURES])` performs two sequential steps:
  1. `fit()`: Computes the mean $\mu$ and standard deviation $\sigma$ for each of the 5 flavor columns.
  2. `transform()`: Applies the z-score formula to every cell, returning a NumPy array `scaled_features` of shape `(24, 5)`.

## Worked Example
Let us compute the z-score for `Spicy Ramen` in the `spice` dimension:
- Raw spice score for Spicy Ramen: $x = 5$
- Dataset spice mean: $\mu = 2.375$
- Dataset spice standard deviation: $\sigma = 1.408$ (sample std)
$$z = \frac{5 - 2.375}{1.408} \approx \frac{2.625}{1.408} \approx +1.86$$
A score of $+1.86$ indicates that Spicy Ramen is nearly two full standard deviations spicier than the average dish in our catalog.

For `Chocolate Cake`:
- Raw spice score: $x = 1$
$$z = \frac{1 - 2.375}{1.408} \approx \frac{-1.375}{1.408} \approx -0.98$$
Chocolate Cake sits nearly one standard deviation below average in spice.

## Step-by-Step Student Instructions
1. Open your Python terminal in the project directory.
2. Load the dataset and run `StandardScaler`:
   ```python
   import pandas as pd
   from sklearn.preprocessing import StandardScaler
   
   df = pd.read_csv("data/recipes.csv")
   features = ["spice", "sweet", "savory", "sour", "veggie"]
   scaler = StandardScaler()
   scaled_features = scaler.fit_transform(df[features])
   ```
3. Check the shape of `scaled_features`:
   ```python
   print("Scaled shape:", scaled_features.shape)
   ```
4. Verify the column means and standard deviations:
   ```python
   print("Column Means (should be ~0):", scaled_features.mean(axis=0).round(4))
   print("Column Stds (should be 1.0):", scaled_features.std(axis=0).round(4))
   ```

## Expected Output or Observable Behaviour
The terminal outputs:
```text
Scaled shape: (24, 5)
Column Means (should be ~0): [ 0. -0.  0. -0.  0.]
Column Stds (should be 1.0): [1. 1. 1. 1. 1.]
```
Every single flavor dimension now operates on a completely level playing field. No dimension can artificially dominate distance calculations simply because of arbitrary scale or variance.

## Practical Exercises
1. **Exercise 1.1**: Look at the scaled features for row 0 (Margherita Pizza): `print(scaled_features[0].round(2))`. Which flavor dimension has the highest positive z-score? (Hint: check savory).
2. **Exercise 1.2**: What is the difference between `scaler.fit_transform(X)` and calling `scaler.fit(X)` followed by `scaler.transform(X)`?
3. **Exercise 1.3**: If you add a 25th recipe to the catalog later, should you call `scaler.fit_transform()` again or `scaler.transform()`? Explain your answer.

## Common Mistakes and Debugging
| Mistake | Why it happens | How to resolve |
|---|---|---|
| Forgetting to scale features | Skipping `StandardScaler` and feeding raw integers to `NearestNeighbors` | High-variance features will dominate nearest neighbor rankings; always scale before distance calculations |
| Passing string columns to `StandardScaler` | Including `name` or `cuisine` in the input DataFrame | Pass only the numeric subset `df[FEATURES]` |
| Calculating mean across axis 1 instead of axis 0 | Calling `scaled_features.mean(axis=1)` | Use `axis=0` to compute statistics down columns (features) rather than across rows (recipes) |

## Best Practices and Security Considerations
- **Data Leakage in Supervised Models**: In supervised learning with train/test splits, you must fit the scaler on the training set only (`scaler.fit(X_train)`), then transform both train and test. In unsupervised catalog retrieval, however, fitting across the whole catalog is appropriate because all items are part of the index.
- **Save Scaler Parameters**: In production systems, serialize the fitted `scaler` object (e.g. using `joblib` or `pickle`) alongside the model so new incoming user queries are transformed with the exact same $\mu$ and $\sigma$.

## Summary
`StandardScaler` performs z-score normalization ($z = \frac{x - \mu}{\sigma}$), ensuring every flavor dimension has a mean of 0 and a standard deviation of 1. This prevents high-variance attributes from overpowering subtle flavor dimensions in multi-dimensional distance calculations.

## Knowledge-check Questions
1. What formula does `StandardScaler` use to normalize features?
2. What are the mean and standard deviation of any feature column after applying `StandardScaler`?
3. Why are distance-based algorithms sensitive to unscaled feature variables?
4. What is the shape of the array returned by `scaler.fit_transform(df[FEATURES])`?
5. How does a z-score of $+2.0$ compare to a z-score of $-1.0$?

## References
- Scikit-learn StandardScaler Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.StandardScaler.html
- Importance of Feature Scaling (Scikit-learn Guide): https://scikit-learn.org/stable/auto_examples/preprocessing/plot_scaling_importance.html
