# Lesson 02: Measuring Distance in Multi-Dimensional Space

**Lesson ID:** lesson-02  
**Module:** module-03  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
The purpose of this lesson is to examine the mathematics of multi-dimensional distance metrics. By the end of this lesson, you will be able to:
- State the mathematical formula for Euclidean distance in an $n$-dimensional vector space.
- Manually calculate Euclidean distance between two vectors.
- Contrast Euclidean distance ($L_2$ norm) with Manhattan distance ($L_1$ norm) and Cosine distance.
- Explain why Euclidean distance is the natural choice for our continuous standardized flavor space.

## Prerequisites
Completion of Lesson 01. Understanding of the Pythagorean theorem ($a^2 + b^2 = c^2$).

## Concept Explanation
### Extending the Pythagorean theorem to 5 dimensions
In 2D plane geometry, the distance between two points $(x_1, y_1)$ and $(x_2, y_2)$ is given by the classic Pythagorean theorem:
$$d = \sqrt{(x_2 - x_1)^2 + (y_2 - y_1)^2}$$

In 3D space with $(x, y, z)$, the formula extends naturally:
$$d = \sqrt{(x_2 - x_1)^2 + (y_2 - y_1)^2 + (z_2 - z_1)^2}$$

In our 5-dimensional flavor space, the exact same principle applies! Given two recipe coordinate vectors $\mathbf{u} = [u_1, u_2, u_3, u_4, u_5]$ and $\mathbf{v} = [v_1, v_2, v_3, v_4, v_5]$:
$$d(\mathbf{u}, \mathbf{v}) = \sqrt{\sum_{i=1}^5 (u_i - v_i)^2} = \sqrt{(u_1 - v_1)^2 + (u_2 - v_2)^2 + (u_3 - v_3)^2 + (u_4 - v_4)^2 + (u_5 - v_5)^2}$$
This is called the **Euclidean distance** or **$L_2$ norm**. It represents the shortest "straight-line" geometric distance between two points in Euclidean space.

```
       Euclidean (L2): Straight line "as the crow flies"
       ------------------------------------------------>
       Point A                                       Point B
       |                                                   ^
       |                                                   |
       +---------------------------------------------------+
       Manhattan (L1): Grid steps along axes
```

### Alternative distance metrics
Scikit-learn's `NearestNeighbors` supports multiple distance metrics via the `metric` parameter:
1. **Euclidean Distance (`metric="euclidean"`)**:
   - The straight-line distance.
   - Penalizes larger differences on any single dimension more heavily due to the squaring term $(u_i - v_i)^2$.
2. **Manhattan Distance (`metric="manhattan"`, $L_1$ norm)**:
   - Sum of absolute coordinate differences: $d = \sum_{i=1}^n |u_i - v_i|$.
   - Analogous to navigating city grid blocks where you cannot cut diagonally through buildings.
3. **Cosine Distance (`metric="cosine"`)**:
   - Measures the angle between two vectors rather than their spatial distance: $1 - \cos(\theta)$.
   - Popular in text processing (e.g. document similarity) where the length of a document should not penalize similarity.

In our standardized flavor space, Euclidean distance is ideal because it accounts for both the magnitude and joint variation across all sensory dimensions simultaneously.

## Relevant Code (from main.py, line 34)
```python
model = NearestNeighbors(n_neighbors=6, metric="euclidean")
```

## Code Explanation
- **Line 34**: Specifies `metric="euclidean"`. Under the hood, whenever `model.kneighbors()` is called, scikit-learn computes the pairwise Euclidean distance between the query vector and every indexed recipe vector in `scaled_features`.

## Worked Example
Let us calculate the raw Euclidean distance between two simplified 3-dimensional flavor vectors:
- **Recipe A (Mild Stew)**: $[1, 2, 4]$
- **Recipe B (Spicy Stew)**: $[4, 2, 4]$
- **Recipe C (Sweet Dessert)**: $[1, 5, 1]$

Distance between Recipe A and Recipe B:
$$d(A, B) = \sqrt{(4 - 1)^2 + (2 - 2)^2 + (4 - 4)^2} = \sqrt{3^2 + 0^2 + 0^2} = \sqrt{9} = 3.0$$

Distance between Recipe A and Recipe C:
$$d(A, C) = \sqrt{(1 - 1)^2 + (5 - 2)^2 + (1 - 4)^2} = \sqrt{0^2 + 3^2 + (-3)^2} = \sqrt{9 + 9} = \sqrt{18} \approx 4.24$$

Since $3.0 < 4.24$, Recipe B is mathematically closer (more similar) to Recipe A than Recipe C is.

## Step-by-Step Student Instructions
1. Open your Python terminal.
2. Import NumPy and use `scipy.spatial.distance` or `np.linalg.norm` to verify distance math:
   ```python
   import numpy as np
   
   u = np.array([1, 2, 4])
   v = np.array([4, 2, 4])
   
   # Method 1: Manual Pythagorean formula
   dist_manual = np.sqrt(np.sum((u - v) ** 2))
   print("Manual Euclidean distance:", dist_manual)
   
   # Method 2: NumPy linear algebra norm
   dist_numpy = np.linalg.norm(u - v)
   print("NumPy norm distance:", dist_numpy)
   ```
3. Confirm that both methods produce identical results ($3.0$).
4. Compute the Manhattan distance using `np.sum(np.abs(u - v))`.

## Expected Output or Observable Behaviour
The terminal outputs:
```text
Manual Euclidean distance: 3.0
NumPy norm distance: 3.0
```
This demonstrates how straightforward multi-dimensional distance calculations are when implemented with vectorized array operations.

## Practical Exercises
1. **Exercise 2.1**: Calculate the Euclidean distance between vector $\mathbf{a} = [2, 1, 5, 3, 2]$ and vector $\mathbf{b} = [2, 1, 5, 2, 2]$. (Notice only one element differs by 1).
2. **Exercise 2.2**: If two recipes have a Euclidean distance of $0.0$, what does this tell you about their flavor profiles?
3. **Exercise 2.3**: What happens to Euclidean distance if you double the number of dimensions from 5 to 10? Does distance generally increase or decrease? (Research the "curse of dimensionality").

## Common Mistakes and Debugging
| Mistake | Why it happens | How to resolve |
|---|---|---|
| Forgetting the square root | Computing squared Euclidean distance $\sum (u_i - v_i)^2$ without $\sqrt{}$ | Remember Euclidean distance requires the final square root operation |
| Confusing distance with similarity | Assuming higher distance means items are closer | Distance measures separation (smaller is closer); similarity measures likeness (higher is closer) |
| Subtracting vectors with mismatched dimensions | Trying to compute distance between a 5D vector and a 3D vector | Ensure both arrays have identical shapes and feature alignments |

## Best Practices and Security Considerations
- **Computational Complexity**: For large catalogs ($>100,000$ items), calculating pairwise Euclidean distances brute-force is $O(N \cdot D)$. Scikit-learn uses tree-based spatial data structures (KD-trees, Ball-trees) to achieve logarithmic query speeds ($O(D \log N)$).
- **Metric Selection**: Always align distance metrics with domain intuition. For dense numerical measurements with Gaussian distributions, Euclidean distance is standard.

## Summary
Euclidean distance is the straight-line distance between two points in multi-dimensional space, computed as the square root of the sum of squared differences across all coordinate axes. In our recommender, smaller Euclidean distances indicate recipes with closer flavor profiles.

## Knowledge-check Questions
1. What is the mathematical formula for Euclidean distance between two 5D vectors?
2. How does Euclidean distance differ from Manhattan distance?
3. If two recipes have an identical score on 4 out of 5 dimensions and differ by 2 on the 5th dimension, what is their Euclidean distance?
4. What parameter in `NearestNeighbors` specifies the distance formula?
5. Why does squaring the differences in Euclidean distance penalize large outliers more heavily than Manhattan distance?

## References
- Euclidean Distance on Wikipedia: https://en.wikipedia.org/wiki/Euclidean_distance
- Scikit-learn Distance Metrics Reference: https://scikit-learn.org/stable/modules/generated/sklearn.metrics.pairwise.distance_metrics.html
