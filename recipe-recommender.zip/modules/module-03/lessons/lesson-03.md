# Lesson 03: NearestNeighbors vs. KNeighborsClassifier

**Lesson ID:** lesson-03  
**Module:** module-03  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
The purpose of this lesson is to examine the architectural, operational, and conceptual distinctions between `NearestNeighbors` and `KNeighborsClassifier`. By the end of this lesson, you will be able to:
- Compare the class signatures, constructor arguments, and methods of both estimators.
- Contrast unsupervised neighbor retrieval with supervised classification voting.
- Explain the role of spatial search trees (BallTree and KDTree) inside `NearestNeighbors`.
- Identify the correct estimator to import when designing recommendation engines versus category classifiers.

## Prerequisites
Completion of Lessons 01 and 02. Understanding of supervised vs unsupervised machine learning.

## Concept Explanation
### Two estimators from the same mathematical family
Both `NearestNeighbors` and `KNeighborsClassifier` live in the `sklearn.neighbors` module. Both calculate geometric distances between data points. However, they serve completely different purposes in machine learning:

```
+-----------------------------------------------------------------------------------+
|               NEARESTNEIGHBORS VS KNEIGHBORSCLASSIFIER                            |
+-----------------------------------------------------------------------------------+
|   Aspect              | NearestNeighbors               | KNeighborsClassifier     |
+-----------------------+--------------------------------+--------------------------+
|   Learning Paradigm   | Unsupervised                   | Supervised               |
|   Target Labels (y)   | NONE required                  | REQUIRED (y)             |
|   fit() signature     | fit(X)                         | fit(X, y)                |
|   Primary query method| kneighbors(X)                  | predict(X)               |
|   Output              | Distances & neighbor indices   | Predicted class label    |
|   Use Case            | Recommendations, item search   | Categorization, sorting  |
+-----------------------------------------------------------------------------------+
```

### 1. `NearestNeighbors`: The Spatial Index
`NearestNeighbors` does not predict anything. Instead, it is an **indexing data structure**.
When you call `model.fit(X)`, it organizes all data points into an optimized multidimensional search tree (such as a KD-tree or Ball-tree).
When you query the index using:
```python
distances, indices = model.kneighbors(query_point, n_neighbors=3)
```
The model traverses the tree and returns:
1. `indices`: The integer row indices of the closest items in the original dataset.
2. `distances`: The exact geometric distance from the query point to each of those neighbors.

You, the developer, then decide how to use those neighbors (e.g. presenting their names, calculating similarity scores, or filtering by cuisine).

### 2. `KNeighborsClassifier`: The Supervised Voter
`KNeighborsClassifier` is designed to assign unknown items into pre-existing discrete classes.
During `fit(X, y)`, it stores the features $X$ alongside class labels $y$ (for example, `y = ["Italian", "Japanese", "Indian", ...]`).
When you call:
```python
prediction = model.predict(query_point)
```
The model internally finds the $k$ nearest neighbors, checks their labels, conducts a **majority vote**, and returns the winning label string.

Because our goal in the Recipe Recommender is to find and display similar dishes (retrieval) rather than guess a category label (classification), `NearestNeighbors` is the proper and only appropriate tool.

## Relevant Code (from main.py, lines 19, 34-35, 42)
```python
from sklearn.neighbors import NearestNeighbors

...
model = NearestNeighbors(n_neighbors=6, metric="euclidean")
model.fit(scaled_features)

...
distances, indices = model.kneighbors(scaled_features[index].reshape(1, -1), n_neighbors=n + 1)
```

## Code Explanation
- **Line 19**: Imports `NearestNeighbors`.
- **Line 34**: Instantiates the unsupervised estimator with `n_neighbors=6` and `metric="euclidean"`.
- **Line 35**: Fits the model on `scaled_features` alone without target labels.
- **Line 42**: Calls `model.kneighbors()`, which returns two separate arrays: the distances and the row indices of the nearest recipes.

## Worked Example
Suppose we want to find the recipes closest to `Margherita Pizza`.
1. We locate Margherita Pizza's row index: `index = 0`.
2. We query `model.kneighbors(scaled_features[0].reshape(1, -1), n_neighbors=4)`.
3. The model returns:
   - `indices`: `[[0, 10, 15, 22]]`
   - `distances`: `[[0.0, 0.912, 1.187, 1.391]]`
4. Let's look up those indices in `df`:
   - Index 0: Margherita Pizza (distance 0.0 - self match!)
   - Index 10: Lasagna (distance 0.912)
   - Index 15: Paella (distance 1.187)
   - Index 22: Mushroom Risotto (distance 1.391)

`NearestNeighbors` gave us the exact data we need to construct our recommendation table. A classifier could never have provided this granular distance and identity information.

## Step-by-Step Student Instructions
1. Open your Python terminal.
2. Initialize `NearestNeighbors` on the recipe dataset:
   ```python
   import pandas as pd
   from sklearn.preprocessing import StandardScaler
   from sklearn.neighbors import NearestNeighbors
   
   df = pd.read_csv("data/recipes.csv")
   features = ["spice", "sweet", "savory", "sour", "veggie"]
   scaler = StandardScaler()
   X = scaler.fit_transform(df[features])
   
   model = NearestNeighbors(n_neighbors=3, metric="euclidean")
   model.fit(X)
   ```
3. Query the nearest neighbors for the first recipe (index 0):
   ```python
   query = X[0].reshape(1, -1)
   distances, indices = model.kneighbors(query)
   print("Distances:", distances)
   print("Indices:", indices)
   ```
4. Confirm that the first returned index is `0` with a distance of `0.0`.

## Expected Output or Observable Behaviour
The terminal outputs:
```text
Distances: [[0.         0.91208945 1.18734044]]
Indices: [[ 0 10 15]]
```
Notice that the results are 2-dimensional NumPy arrays of shape `(1, 3)`. The first element in `indices` is always the query item itself.

## Practical Exercises
1. **Exercise 3.1**: What happens if you call `model.predict(query)` on a `NearestNeighbors` instance? Try it in Python and note the error.
2. **Exercise 3.2**: Inspect the type of tree algorithm chosen by scikit-learn: `print(model._fit_method)`. What algorithm did scikit-learn select for our dataset?
3. **Exercise 3.3**: Why is `indices[0][0]` guaranteed to be equal to the index of the query item if the query item exists in the training set?

## Common Mistakes and Debugging
| Mistake | Why it happens | How to resolve |
|---|---|---|
| Calling `model.predict()` | Thinking all scikit-learn models have a `predict()` method | Use `model.kneighbors()` for `NearestNeighbors` instances |
| Forgetting to reshape single query vectors | Passing `X[0]` of shape `(5,)` instead of `(1, 5)` | Call `X[0].reshape(1, -1)` to create the required 2D query shape |
| Trying to pass `y` to `NearestNeighbors.fit()` | Copy-pasting supervised training code | Omit `y`; `NearestNeighbors.fit()` takes only feature matrix `X` |

## Best Practices and Security Considerations
- **Reshape Query Vectors**: Always reshape single sample queries with `.reshape(1, -1)` before querying `kneighbors()`. Scikit-learn requires 2D arrays even for single observations.
- **Tree Algorithms**: By default, `NearestNeighbors(algorithm="auto")` automatically selects between brute-force search, KDTree, and BallTree based on dataset size and dimensionality.

## Summary
`NearestNeighbors` is an unsupervised estimator that indexes data points in continuous space, returning the distances and indices of closest items via `kneighbors()`. This contrasts sharply with `KNeighborsClassifier`, which requires target labels and outputs a single majority-vote categorical prediction.

## Knowledge-check Questions
1. Why does `NearestNeighbors` not require a `y` argument during `fit()`?
2. What two arrays are returned by `model.kneighbors()`?
3. What is the fundamental difference between the output of `model.predict()` and `model.kneighbors()`?
4. Why is `NearestNeighbors` preferred over `KNeighborsClassifier` for building recommendation systems?
5. What does the first element of the returned distances array represent when querying an item from the dataset?

## References
- Scikit-learn NearestNeighbors API: https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.NearestNeighbors.html
- Scikit-learn KNeighborsClassifier API: https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.KNeighborsClassifier.html
