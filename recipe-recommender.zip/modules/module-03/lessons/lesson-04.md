# Lesson 04: Fitting the Model on All Data (No Train/Test Split)

**Lesson ID:** lesson-04  
**Module:** module-03  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
The purpose of this lesson is to understand why catalog recommendation systems fit their retrieval indices on 100% of the available data without a train/test split. By the end of this lesson, you will be able to:
- Explain the role of train/test splits in supervised machine learning.
- Contrast generalization testing (supervised) with catalog indexing (unsupervised retrieval).
- Explain why withholding catalog items in a test set degrades recommendation systems.
- Understand how recommendation algorithms are evaluated in industry without classic train/test splits.

## Prerequisites
Completion of Lessons 01-03. Familiarity with the concept of overfitting and train/test splitting.

## Concept Explanation
### The purpose of train/test splits in supervised learning
In supervised learning projects (like predicting lemonade sales or classifying iris flowers), the model attempts to learn a general mapping function:
$$f(X) \approx y$$
If you train on all your data and test on that same data, a complex model can simply memorize the answers (overfitting). You would have no idea whether the model would work on new, unseen data tomorrow.
To protect against this, data scientists split the data into:
- **Training Set (e.g. 75%)**: Used to learn patterns.
- **Testing Set (e.g. 25%)**: Kept hidden until the end to evaluate genuine generalization performance.

```
SUPERVISED CLASSIFICATION:
[======================= ALL DATA =======================]
[------ 75% Training Set ------] [--- 25% Test Set ---]
         |                                 |
     Trains model                     Tests generalization
```

### Why catalog recommendation is different: Indexing vs Generalizing
In content-based recommendation systems, the model is **not trying to predict an unobserved target label**.
Instead, the model is serving as an **inventory catalog search index**:

```
CATALOG RETRIEVAL INDEX:
[=================== COMPLETE CATALOG (100%) ===================]
                             |
                 Indexed by NearestNeighbors
                             |
                 Every item is searchable!
```

Imagine running a digital streaming service with 10,000 movies:
- If you randomly withhold 2,500 movies into a "test set" and only fit your nearest neighbor model on the remaining 7,500, those 2,500 movies **vanish from the recommendation system!**
- If a user watches *The Matrix*, but the closest sci-fi movie was placed in the "test set", the algorithm cannot see it and cannot recommend it.
- In retrieval systems, you want your index to contain **every single item you have available for discovery**.

### How do engineers evaluate recommenders without train/test splits?
If we do not split our data, how do we evaluate recommendation quality? In production systems, engineers use specialized retrieval metrics:
1. **Catalog Coverage**: What percentage of all catalog items can potentially be discovered and recommended? (Splitting data reduces coverage).
2. **Diversity & Serendipity**: Are recommendations pleasantly varied, or does the user get stuck in a repetitive loop?
3. **Novelty**: Does the system suggest interesting lesser-known items rather than just the top 3 most obvious items?
4. **User Engagement / A/B Testing**: In live systems, user click-through rate (CTR), watch time, or recipes cooked serves as the ultimate test of recommendation quality.

## Relevant Code (from main.py, lines 34-35)
```python
model = NearestNeighbors(n_neighbors=6, metric="euclidean")
model.fit(scaled_features)
```

## Code Explanation
- **Line 34**: Creates the `NearestNeighbors` instance.
- **Line 35**: Calls `model.fit(scaled_features)` directly on the entire 24-recipe matrix. There is no call to `train_test_split()`, and all 24 recipes are successfully incorporated into the search index.

## Worked Example
Let us consider what would happen if a student insisted on using a train/test split on our 24 recipes:
```python
# HYPOTHETICAL MISTAKE: Splitting recommendation data
X_train, X_test, df_train, df_test = train_test_split(scaled_features, df, test_size=0.25, random_state=42)
model.fit(X_train)  # Trains on only 18 recipes!
```
- Total recipes in catalog: 24.
- Recipes indexed in model: 18.
- Suppose `Pancakes` was assigned to `X_test`.
- Now, when a user asks: *"What is similar to Chocolate Cake?"*
  - The model searches its 18 indexed recipes.
  - It CANNOT recommend Pancakes (even though Pancakes is the exact closest match in flavor space!) because Pancakes was artificially banished to the test set!
This illustrates why indexing all available inventory is standard practice for item retrieval.

## Step-by-Step Student Instructions
1. Open `main.py` in your text editor.
2. Search the file for the word `split`. Confirm that `train_test_split` does not appear anywhere in the script.
3. Verify that `scaled_features` passed to `model.fit()` has length 24:
   ```python
   print(len(scaled_features))  # Output: 24
   ```
4. Query the model with `Spicy Ramen` and confirm that all other 23 recipes in the catalog are eligible candidates for recommendation.

## Expected Output or Observable Behaviour
Because all 24 recipes are indexed, the recommender produces optimal culinary matches drawn from the full multi-cuisine spectrum (Japanese, Indian, Korean, Mexican, Italian, Spanish, etc.).

## Practical Exercises
1. **Exercise 4.1**: In your own words, explain why a movie streaming platform would never withhold 20% of its film catalog from its search and recommendation index.
2. **Exercise 4.2**: What is "catalog coverage" in recommendation systems, and what is the catalog coverage of our model? (Hint: 24 / 24 = 100%).
3. **Exercise 4.3**: Under what circumstances *would* you use a train/test split in a recommender system? (Hint: when predicting user star ratings from historical interaction logs in collaborative filtering).

## Common Mistakes and Debugging
| Mistake | Why it happens | How to resolve |
|---|---|---|
| Forcing a train/test split out of habit | Assuming every machine learning project requires `train_test_split` | Recognize the difference between predictive classification and inventory indexing |
| Testing recommendations with classification accuracy | Expecting an accuracy percentage | Evaluate recommendations using similarity rankings and flavor alignment |
| Indexing unscaled data in the full model | Forgetting to apply `StandardScaler` first | Always fit the model on `scaled_features`, not raw `df[FEATURES]` |

## Best Practices and Security Considerations
- **Index Freshness**: In production systems, rebuild or update spatial indices periodically as new items are added to the inventory catalog.
- **Catalog Filtering**: If certain items are out of stock or regionally unavailable, filter them dynamically before or after nearest neighbor retrieval.

## Summary
In catalog recommendation systems, the model serves as an item retrieval index rather than an out-of-sample classifier. Fitting `NearestNeighbors` on all available data ensures 100% catalog coverage so that every recipe can be discovered by users.

## Knowledge-check Questions
1. Why is `train_test_split` essential for supervised models like Linear Regression or Decision Trees?
2. What happens to items placed in a test set if you apply a train/test split to a catalog recommendation index?
3. What is the catalog coverage of our fitted Recipe Recommender?
4. How do real-world engineering teams evaluate content-based recommenders?
5. When would a train/test split be appropriate in a recommender system?

## References
- Evaluation Metrics for Recommender Systems (Microsoft Recommenders): https://github.com/microsoft/recommenders/blob/main/examples/03_evaluate/evaluation.ipynb
- Overview of Information Retrieval and Indexing: https://nlp.stanford.edu/IR-book/html/htmledition/irbook.html
