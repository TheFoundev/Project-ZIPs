# The Recipe Recommender: Project Summary

## Overview
The **Recipe Recommender** is an unsupervised machine learning project demonstrating content-based recommendation using spatial nearest neighbors. By viewing recipes as points in a 5-dimensional flavor space (`spice, sweet, savory, sour, veggie`), the model calculates Euclidean distances between dishes to identify the closest culinary matches. In addition, the system includes a serendipitous "Surprise Me" engine that selects alternative cuisine options to broaden user discovery.

## Real-World Use Case
Modern streaming platforms (Spotify, Netflix), e-commerce giants (Amazon), and culinary applications (Epicurious, Yummly) rely heavily on content-based recommendation systems. When user ratings or interaction histories are scarce (the "cold start" challenge), matching item attribute profiles provides an immediate, highly effective recommendation mechanism.

## Features Implemented
- **Data Ingestion**: Loads a 24-recipe multi-cuisine dataset (`recipes.csv`) with pandas.
- **Flavor Feature Extraction**: Extracts 5 sensory dimensions: `spice`, `sweet`, `savory`, `sour`, and `veggie`.
- **Standardization**: Applies `StandardScaler` to ensure all flavor dimensions contribute equally to distance calculations.
- **Unsupervised Spatial Indexing**: Fits scikit-learn's `NearestNeighbors` on all standardized recipe vectors.
- **Top-$N$ Recommendation Engine**: Implements `recommend(recipe_name, n=3)` which queries `kneighbors()`, excludes the self-match, and computes bounded similarity scores: $S = \frac{1}{1 + d}$.
- **Serendipity Engine**: Implements `surprise_me(recipe_name)` to sample a tasty recipe from an entirely different cuisine.
- **Visual Analytics**: Plots similarity rankings using horizontal bar charts (`barh`) and saves them via Matplotlib's `Agg` backend.
- **Artifact Generation**: Writes structured recommendations to `outputs/recommendations.txt`.

## Key Technical Distinctions
- **Unsupervised vs. Supervised**: Unlike the other 18 beginner projects which classify samples or predict numerical targets, this project is **unsupervised**. It predicts no target labels; rather, it queries relative spatial proximity.
- **`NearestNeighbors` vs. `KNeighborsClassifier`**: Uses `sklearn.neighbors.NearestNeighbors`, not `KNeighborsClassifier`. There is no voting, no labels, and no classification.
- **No Train/Test Split**: Fits on the entire catalog because recommendation retrieval functions as an indexing system rather than an out-of-sample classifier.

## Technology Stack
- **Python 3**: Core programming language.
- **pandas**: Data loading, filtering, and table formatting.
- **numpy**: Numerical manipulation and vector reshaping.
- **scikit-learn**: Feature scaling (`StandardScaler`) and nearest neighbor search (`NearestNeighbors`).
- **matplotlib**: Headless rendering and horizontal bar chart generation.

## Expected Outputs
1. **Console**: Recommendation tables for Margherita Pizza, Spicy Ramen, and Chocolate Cake, plus a Surprise Me dish.
2. **`outputs/similarity_scores.png`**: Horizontal bar chart comparing similarity scores for top matches to Spicy Ramen.
3. **`outputs/recommendations.txt`**: Formatted text file containing all recommendations and similarity scores.
