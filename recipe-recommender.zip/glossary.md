# Glossary: The Recipe Recommender

| Term | Definition |
|---|---|
| **Recommender System** | An algorithmic system that predicts user preference for items and suggests relevant items from a large catalog. |
| **Content-Based Filtering** | A recommendation approach that recommends items based on the intrinsic attributes/features of items the user has liked in the past. |
| **Collaborative Filtering** | A recommendation approach that leverages user-interaction patterns (ratings, clicks, purchases) across a community of users without requiring item feature descriptions. |
| **NearestNeighbors** | An unsupervised scikit-learn estimator that builds a spatial search index to efficiently find the closest data points according to a specified distance metric. |
| **KNeighborsClassifier** | A supervised classification algorithm that assigns class labels to unseen queries based on a majority vote among its $k$ nearest neighbors. (Contrast with `NearestNeighbors`). |
| **Euclidean Distance** | The straight-line geometric distance between two points in Euclidean space: $d(\mathbf{u}, \mathbf{v}) = \sqrt{\sum_{i=1}^m (u_i - v_i)^2}$. |
| **StandardScaler** | A feature transformation technique that centers features around 0 (mean = 0) and scales them to unit variance (standard deviation = 1). |
| **Feature Space** | An $n$-dimensional geometric coordinate space where each coordinate axis corresponds to a measurable feature or attribute of the data. |
| **Similarity Score** | A normalized numerical index (typically ranging between 0 and 1) measuring how alike two entities are; higher scores indicate greater similarity. |
| **Self-Match** | In nearest neighbor querying, the query item itself is always the closest point with a distance of zero ($d=0$). It must be excluded from recommendations. |
| **Serendipity** | The discovery of pleasantly surprising, novel, and relevant recommendations that the user would not have typically sought out or found in their existing category bubble. |
| **Filter Bubble** | An algorithmic state where a recommender only provides items similar to previous choices, preventing users from discovering novel categories or diverse items. |
| **Cold Start Problem** | The challenge recommendation systems face when a new item or new user enters the system without prior interaction history. |
| **Agg Backend** | Matplotlib's non-interactive Anti-Grain Geometry backend used for rendering raster PNG graphics in headless server environments. |
| **reshape(1, -1)** | A NumPy operation that transforms a 1D array of shape `(n_features,)` into a 2D array of shape `(1, n_features)` as required by scikit-learn estimators. |
