# Prerequisites

## Skills Required
- **Basic Python Syntax**: Familiarity with variables, functions, dictionaries, loops, list comprehensions, and basic string operations.
- **Data Manipulation with pandas**: Understanding how to load CSV files into DataFrames, inspect columns, filter rows by boolean conditions, and select column subsets.
- **NumPy Fundamentals**: Basic familiarity with arrays and reshaping vectors (`reshape(1, -1)`).
- **Basic Math Concepts**: Understanding Cartesian coordinates and the Euclidean distance formula ($d = \sqrt{(x_2-x_1)^2 + (y_2-y_1)^2}$) in 2D and how it naturally extends to higher dimensions.
- **Command Line Navigation**: Comfort running Python scripts from the terminal and verifying directory contents.

## Tools Required
- **Python**: Version 3.8 or newer installed on your machine.
- **Package Manager**: `pip` for installing scientific Python libraries.
- **Text Editor or IDE**: VS Code, PyCharm, or any text editor with Python syntax highlighting.
- **Terminal / Shell**: Bash, Zsh, or Windows Command Prompt / PowerShell.

## Python Packages
- `pandas` (>= 1.3.0): For loading, indexing, and filtering the recipe dataset.
- `numpy` (>= 1.20.0): For array math and reshaping feature vectors.
- `matplotlib` (>= 3.4.0): For generating horizontal bar charts and similarity plots.
- `scikit-learn` (>= 1.0.0): Specifically `sklearn.neighbors.NearestNeighbors` and `sklearn.preprocessing.StandardScaler`.

## Knowledge to Review Before Starting
- What is the difference between supervised learning (with labels/targets) and unsupervised learning (finding patterns/clusters/neighbors without labels)?
- Why do distance calculations require all features to be on a comparable scale?
- How does content-based filtering recommend items based on item characteristics rather than community ratings?
