# Architecture: The Fake Review Spotter

This document describes the software architecture, data flow, pipeline components, and mathematical transformations that power the Fake Review Spotter project.

---

## 1. End-to-End Pipeline Overview

The Fake Review Spotter is architected as a modular, reproducible NLP pipeline utilizing Python, pandas, and scikit-learn.

```mermaid
flowchart TD
    A["Raw Dataset: data/reviews.csv (80 rows)"] --> B["Data Loading & Exploration (pandas)"]
    B --> C["Stratified Train/Test Split (75% Train, 25% Test)"]
    C --> D1["X_train (60 review strings)"]
    C --> D2["y_train (60 labels: 30 fake, 30 real)"]
    C --> E1["X_test (20 review strings)"]
    C --> E2["y_test (20 labels: 10 fake, 10 real)"]
    
    subgraph "Scikit-Learn Pipeline"
        F["CountVectorizer(stop_words='english', ngram_range=(1,2))"]
        G["MultinomialNB(alpha=1.0)"]
        F -->|Sparse Document-Term Matrix| G
    end

    D1 --> F
    D2 --> G
    
    E1 -->|"model.predict(X_test)"| H["Model Evaluation & Metrics"]
    E2 --> H
    H --> I1["Console Classification Report"]
    H --> I2["outputs/confusion_matrix.png"]
    
    G -->|"feature_log_prob_ extraction"| J["top_words() Clue Analysis"]
    J --> K["outputs/top_words.png (Horizontal Bar Chart)"]
    
    L["Unseen Reviews (4 test strings)"] -->|"model.predict() & predict_proba()"| M["Sample Predictions"]
    M --> N["outputs/predictions.txt"]
```

---

## 2. Key Pipeline Components

### 2.1 Data Management & Ingestion
- **Source**: `data/reviews.csv` containing 80 labeled customer reviews.
- **Path Isolation**: Paths are resolved dynamically using `pathlib.Path(__file__).resolve().parent`, decoupling execution from terminal working directories.
- **Target Encoding**: Labels are represented as strings (`"fake"` and `"real"`), preserved natively by scikit-learn classifiers.

### 2.2 Stratified Splitting
- Uses `train_test_split(df["review"], df["label"], test_size=0.25, random_state=42, stratify=df["label"])`.
- Stratification guarantees that the 50/50 class balance is preserved in both the 60-sample training partition and the 20-sample testing partition.

### 2.3 Feature Extraction (`CountVectorizer`)
- **Lowercasing**: Normalizes character casing to collapse typographic variations (`"AMAZING"` $\to$ `"amazing"`).
- **Stop Words**: Strips common non-discriminative English terms using `stop_words="english"`.
- **N-gram Range**: Configured with `ngram_range=(1, 2)` to extract unigrams (single words) and bigrams (consecutive pairs), capturing contextual cues like `"customer support"` and `"wow wow"`.

### 2.4 Modeling (`MultinomialNB`)
- Fits a multinomial distribution over word counts across the two classes.
- Applies Laplace smoothing (`alpha=1.0`) to avoid zero conditional probabilities on infrequent vocabulary.
- Operates in log-space to ensure numerical stability and prevent floating-point underflow.

### 2.5 Clue Strength Analysis (`top_words`)
- Extracts the fitted parameters `classifier.feature_log_prob_`.
- Calculates the log-likelihood ratio difference:
  $$\text{score}(w) = \log P(w \mid c) - \log P(w \mid 1 - c) = \log \frac{P(w \mid c)}{P(w \mid 1 - c)}$$
- Identifies the top $n$ words/phrases with highest positive separation for each class.

---

## 3. Data Transformation Flow

| Stage | Input Data | Transformation | Output Representation |
|---|---|---|---|
| **1. Ingestion** | `data/reviews.csv` on disk | `pd.read_csv()` | Pandas DataFrame: `(80, 2)` |
| **2. Partitioning** | `df["review"]`, `df["label"]` | `train_test_split(stratify=...)` | `X_train (60,)`, `X_test (20,)`, `y_train (60,)`, `y_test (20,)` |
| **3. Vectorization** | `X_train` raw text strings | `CountVectorizer.fit_transform()` | Compressed Sparse Row Matrix `(60, V)` |
| **4. Classification** | Sparse Matrix + `y_train` | `MultinomialNB.fit()` | Learned log-probability matrix `(2, V)` |
| **5. Inference** | Raw test strings / new reviews | `Pipeline.predict()` / `predict_proba()` | Categorical classes + probability arrays `(N, 2)` |
| **6. Visualization** | Probabilities & Log-likelihood scores | Matplotlib horizontal barh & ConfusionDisplay | PNG images saved to `outputs/` |
