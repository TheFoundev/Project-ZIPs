# The Fake Review Spotter: Educational Project Guide

Welcome to **The Fake Review Spotter**, a practical beginner machine learning project focused on Natural Language Processing (NLP) and supervised text classification using scikit-learn.

---

## Project Overview

Online reviews shape modern commerce. However, deceptive reviews—written to dishonestly boost ratings or damage competitors—corrupt consumer trust and market efficiency. In this project, you will build an automated classifier that analyzes review text, discovers linguistic patterns characteristic of fraudulent feedback, and flags deceptive reviews.

### Key Conceptual Distinction: Pattern Finder vs. Lie Detector
As emphasized in the project codebase:
> **"A text classifier that learns word patterns. It is a pattern finder, not a lie detector."**

A machine learning model cannot verify whether a reviewer actually bought an item or whether their claims match physical reality. It detects **statistical correlations in vocabulary and style**. Understanding this distinction is vital for responsible AI engineering.

---

## Technology Stack
- **Language**: Python 3.8+
- **Data Manipulation**: `pandas`, `numpy`
- **Text Preprocessing & Modeling**: `scikit-learn` (`CountVectorizer`, `MultinomialNB`, `Pipeline`)
- **Evaluation & Visualization**: `matplotlib`, `classification_report`, `ConfusionMatrixDisplay`

---

## Project Curriculum Roadmap

The project is structured into 6 progressive learning modules:

1. **Module 01: Project Overview & NLP Foundations**
   - The fake review crisis and e-commerce business impact
   - Deceptive writing styles vs. genuine consumer feedback
   - Why ML is a pattern finder rather than a truth verifier
   - Framing deception detection as binary text classification

2. **Module 02: Data & Text Exploration**
   - Loading `data/reviews.csv` with `pathlib` and `pandas`
   - Assessing the 80-row dataset and verifying 50/50 class balance
   - Qualitative comparison of fake and genuine review samples
   - Separating text feature Series and target label Series

3. **Module 03: CountVectorizer & Feature Extraction**
   - The Bag-of-Words (BoW) model: transforming text to numbers
   - Tokenization, lowercasing, and building the vocabulary dictionary
   - Removing non-informative English stop words
   - Capturing phrases with unigrams and bigrams (`ngram_range=(1, 2)`)

4. **Module 04: Multinomial Naive Bayes & Training**
   - Bayes' Theorem explained in plain English
   - The conditional independence assumption and MultinomialNB mechanics
   - Building atomic scikit-learn Pipelines with stratified train/test splits
   - Inspecting `feature_log_prob_` and computing log-likelihood clue scores

5. **Module 05: Evaluation & Visualizing Clue Words**
   - Computing accuracy, precision, recall, and F1-score
   - Interpreting the 2x2 confusion matrix and operational error costs
   - Visualizing confusion matrices with headless matplotlib
   - Creating two-panel horizontal bar charts for fake clues vs real clues

6. **Module 06: Predictions, Limitations & Extensions**
   - Making predictions and generating confidence scores on novel reviews
   - Probing model blindspots and adversarial vulnerabilities
   - Documenting findings in `outputs/predictions.txt`
   - Designing multimodal production extensions (star ratings, metadata, embeddings)

---

## Quickstart Instructions

```bash
# 1. Clone or navigate to the project directory
cd "/home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/12_fake_review_spotter"

# 2. Install dependencies
pip install pandas numpy matplotlib scikit-learn

# 3. Execute the script
python main.py
```

Generated deliverables will be placed in `outputs/`:
- `outputs/top_words.png`
- `outputs/confusion_matrix.png`
- `outputs/predictions.txt`
