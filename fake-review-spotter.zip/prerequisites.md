# Prerequisites

## Skills Required
- **Basic Python syntax**: variables, functions, lists, dictionaries, string operations, and control flow
- **Pathlib basics**: navigating directories and managing file paths with `Path(__file__).resolve().parent`
- **Introductory Pandas**: loading CSV files with `pd.read_csv`, selecting Series columns, and checking `.shape` and `.value_counts()`
- **Basic Probability Concepts**: fractions, ratios, and an intuitive grasp of conditional probability ("how likely is X given Y?")
- **Command Line Familiarity**: navigating folders with `cd`, running scripts with `python main.py`, and installing packages with `pip`

## Tools Required
- **Python**: version 3.8 or newer installed on your operating system
- **Package Manager**: `pip` for installing Python dependencies
- **Code Editor**: Visual Studio Code, Cursor, PyCharm, or any modern text editor
- **Terminal**: Bash (Linux/macOS) or PowerShell/Command Prompt (Windows)

## Python Packages
- `pandas` (>= 1.3.0) — for tabular dataset loading and manipulation
- `numpy` (>= 1.20.0) — for numerical sorting and array slicing
- `matplotlib` (>= 3.4.0) — for plotting the horizontal clue chart and confusion matrix
- `scikit-learn` (>= 1.0.0) — for `CountVectorizer`, `MultinomialNB`, `Pipeline`, and metrics

## Key Knowledge to Review Before Starting
- What is a supervised machine learning dataset? (Features $X$ and ground-truth labels $y$)
- What is the difference between regression (numeric prediction) and classification (category prediction)?
- Why do computers need text to be converted into numbers before applying machine learning algorithms?
