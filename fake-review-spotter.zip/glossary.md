# Glossary: The Fake Review Spotter

| Term | Definition |
|---|---|
| **Natural Language Processing (NLP)** | The subfield of machine learning and artificial intelligence focused on enabling computers to understand, interpret, and process human text and speech. |
| **Supervised Learning** | A machine learning paradigm where an algorithm trains on labeled input-output pairs ($X, y$) to learn a mapping function that generalizes to unseen inputs. |
| **Binary Classification** | A supervised classification task where the target output variable belongs to exactly one of two discrete classes (e.g., 'fake' vs 'real'). |
| **Pattern Finder vs Lie Detector** | The fundamental concept that statistical NLP models detect lexical correlations and stylistic patterns in text rather than objectively verifying real-world facts or truth. |
| **Bag-of-Words (BoW)** | A text representation technique that converts documents into word count vectors, preserving word occurrence frequency while completely discarding grammatical structure and word order. |
| **Tokenization** | The process of segmenting a continuous string of text into discrete linguistic units (tokens), such as individual words or punctuation marks. |
| **Vocabulary** | The comprehensive dictionary of all unique tokens learned by a vectorizer during the training phase, mapping each word to a unique column index. |
| **Stop Words** | High-frequency grammatical words (such as 'the', 'is', 'at', 'which') that occur uniformly across all classes and are removed to reduce noise and dimensionality. |
| **N-gram** | A contiguous sequence of $n$ items from a given sample of text. A unigram ($n=1$) is a single word; a bigram ($n=2$) is a pair of adjacent words (e.g., 'customer support'). |
| **Document-Term Matrix** | A 2D mathematical matrix where rows represent documents, columns represent vocabulary terms, and cell values represent token frequencies. |
| **Sparse Matrix** | An efficient data structure that stores only non-zero matrix values and their coordinates, conserving RAM when matrices are predominantly populated by zeros. |
| **Bayes' Theorem** | A mathematical formula for calculating conditional probability: $P(A|B) = \frac{P(B|A) \cdot P(A)}{P(B)}$, expressing posterior probability from prior beliefs and likelihood evidence. |
| **Naive Bayes** | A family of probabilistic classifiers based on Bayes' theorem under the 'naive' assumption that all features are mutually independent given the class label. |
| **MultinomialNB** | A Naive Bayes classifier tailored for multinomially distributed data, such as word counts and frequency vectors in text classification. |
| **Conditional Independence** | The assumption that observing the value of one feature provides no information about the value of another feature, conditional on knowing the class label. |
| **Prior Probability ($P(\text{class})$)** | The baseline probability of a class before observing any evidence or text, usually estimated from class frequencies in the training set. |
| **Likelihood ($P(\text{word} \mid \text{class})$)** | The probability that a specific word occurs in a document given that the document belongs to a specific class. |
| **Posterior Probability** | The updated probability that a document belongs to a class after observing all the words contained within the document. |
| **Laplace Smoothing (Additive Smoothing)** | Adding a constant pseudo-count (typically $\alpha=1.0$) to observed feature frequencies during probability estimation to prevent zero-probability multiplications on rare words. |
| **Log-Likelihood Ratio** | The difference between two log probabilities: $\log P(w \mid \text{fake}) - \log P(w \mid \text{real})$, quantifying the relative clue strength of a word for one class over another. |
| **Scikit-Learn Pipeline** | A software utility that chains together data transformers (such as `CountVectorizer`) and an estimator (such as `MultinomialNB`) into an atomic, reproducible object. |
| **Stratified Split** | A data partitioning method that maintains the exact class proportion (here 50% fake, 50% real) across both training and test subsets. |
| **Accuracy** | The proportion of total predictions that were correct: $\frac{TP + TN}{TP + TN + FP + FN}$. |
| **Precision** | The fraction of positive predictions that were truly positive: $\frac{TP}{TP + FP}$. Answers: "When the model flags a review as fake, how often is it right?" |
| **Recall (Sensitivity)** | The fraction of actual positive instances that were detected: $\frac{TP}{TP + FN}$. Answers: "Out of all real fake reviews, how many did the model catch?" |
| **F1-Score** | The harmonic mean of precision and recall: $2 \cdot \frac{\text{Precision} \cdot \text{Recall}}{\text{Precision} + \text{Recall}}$, balancing both metrics. |
| **Support** | The actual number of ground-truth occurrences of each class in the specified evaluation dataset. |
| **Confusion Matrix** | A 2x2 grid cross-tabulating actual ground-truth classes against model-predicted classes, identifying True Positives, False Positives, True Negatives, and False Negatives. |
| **False Positive (Type I Error)** | An honest, genuine customer review that is incorrectly flagged as fake by the classifier. |
| **False Negative (Type II Error)** | A deceptive, fake review that successfully evades detection and is classified as genuine. |
| **Adversarial Evasion** | The intentional manipulation of input text by fraudsters (e.g., using moderate words or inserting technical jargon) to fool statistical NLP models. |
| **predict_proba** | A scikit-learn method returning the estimated probability distribution over target classes for given input samples. |
