# Lesson 02: The Confusion Matrix Demystified

**Lesson ID:** lesson-02
**Module:** module-05
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define the four quadrants of a binary confusion matrix: TP, FP, TN, FN.
- Map the four quadrants directly to e-commerce review moderation outcomes.
- Compute the confusion matrix using scikit-learn's `confusion_matrix()`.
- Analyze asymmetric business costs: False Positives (customer insult) vs False Negatives (consumer fraud).

## 2. Prerequisites
- Completion of Lesson 01: Accuracy and the Classification Report.
- Basic understanding of 2x2 grids.

## 3. Real-World Context & Business Motivation
In machine learning evaluation, summarized metrics like 95% accuracy condense performance into an abstract scalar. A confusion matrix, by contrast, lays out all predictions bare on a 2D coordinate grid. It shows you exactly where the model succeeded and exactly what kinds of mistakes it made. In fraud detection, not all mistakes are equal: wrongly banning an honest seller (False Positive) can destroy a business and prompt lawsuits, whereas temporarily letting a fake review slide (False Negative) can be caught by secondary downstream filters. The confusion matrix illuminates these operational trade-offs.

## 4. Concept Explanation
### The Four Quadrants of the Confusion Matrix
A confusion matrix cross-tabulates actual ground truth against model predictions. When `"fake"` is designated as the positive class:

| | Predicted: Fake | Predicted: Real |
|---|---|---|
| **Actual: Fake** | **True Positive (TP)**<br>*Fraud caught successfully* | **False Negative (FN)**<br>*Fraud escaped detection (Type II)* |
| **Actual: Real** | **False Positive (FP)**<br>*Honest review wrongly flagged (Type I)* | **True Negative (TN)**<br>*Genuine review published safely* |

```mermaid
flowchart TD
    subgraph "Actual Fake"
        TP["True Positive (TP)
Fake correctly caught"]
        FN["False Negative (FN)
Fake missed (Type II)"]
    end
    subgraph "Actual Real"
        FP["False Positive (FP)
Real wrongly flagged (Type I)"]
        TN["True Negative (TN)
Real correctly approved"]
    end
```

### Asymmetric Real-World Costs
1. **False Positive Cost (Type I Error):**
   - An ecstatic genuine customer writes *"Best purchase ever!"*.
   - The model flags the review as fake.
   - The customer receives an email stating their review violated community anti-manipulation guidelines.
   - **Consequence:** The customer feels insulted, alienating a passionate brand advocate.
2. **False Negative Cost (Type II Error):**
   - A fraudulent seller posts a fake 5-star review.
   - The model predicts "real".
   - The review is published on the platform.
   - **Consequence:** A consumer buys a defective item, eroding platform trust.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 95-96 generate the numerical confusion matrix:
```python
labels = ["fake", "real"]
cm = confusion_matrix(y_test, predictions, labels=labels)
```
- `labels=["fake", "real"]`: Explicitly specifies row and column ordering.
  - Row 0 / Col 0: `"fake"`
  - Row 1 / Col 1: `"real"`
- This guarantees that quadrant (0, 0) represents True Fakes (TP), quadrant (0, 1) represents False Reals (FN), quadrant (1, 0) represents False Fakes (FP), and quadrant (1, 1) represents True Reals (TN).

## 6. Worked Example
Let's compute and print the confusion matrix for `main.py` in Python:
```python
from sklearn.metrics import confusion_matrix

labels = ["fake", "real"]
cm = confusion_matrix(y_test, predictions, labels=labels)

print("Confusion Matrix Array:")
print(cm)
print(f"\nTrue Positives (Caught Fake):   {cm[0, 0]}")
print(f"False Negatives (Missed Fake):  {cm[0, 1]}")
print(f"False Positives (Wrongly Fake): {cm[1, 0]}")
print(f"True Negatives (Approved Real): {cm[1, 1]}")
```
**Console Output:**
```text
Confusion Matrix Array:
[[10  0]
 [ 0 10]]

True Positives (Caught Fake):   10
False Negatives (Missed Fake):  0
False Positives (Wrongly Fake): 0
True Negatives (Approved Real): 10
```
The diagonal contains all 20 test instances ($10 + 10 = 20$), and the off-diagonal error cells are both strictly $0$.

## 7. Step-by-Step Student Instructions
1. In your Python session, import `confusion_matrix` from `sklearn.metrics`.
2. Compute `cm = confusion_matrix(y_test, predictions, labels=['fake', 'real'])`.
3. Print `cm`.
4. Locate quadrant (0, 0): confirm it contains 10.
5. Locate quadrant (1, 1): confirm it contains 10.
6. Verify that the sum of all elements equals the test set size (`cm.sum() == 20`).

## 8. Expected Output or Observable Behaviour
```text
[[10,  0],
 [ 0, 10]]
Off-diagonal cells are 0, confirming zero misclassifications on this test partition.
```

## 9. Practical Exercises (with Success Criteria)
- **Task 2.1:** If a confusion matrix is `[[8, 2], [1, 9]]` with labels `['fake', 'real']`, identify the count of False Positives and False Negatives.
- **Task 2.2:** For that same matrix, calculate Precision and Recall for the fake class.
- *Success Criteria:* FP = 1, FN = 2; Precision = $8/(8+1) = 88.9\%$; Recall = $8/(8+2) = 80.0\%$.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Omitting the `labels` parameter | Scikit-learn defaults to alphabetical ordering (`['fake', 'real']`), which may silently change if labels are renamed | Always specify `labels=['fake', 'real']` explicitly. |
| Confusing rows with columns | In scikit-learn, rows are actual true labels; columns are predicted labels | Remember: Rows = Reality, Columns = Predictions. |
| Treating FP and FN as equal costs | Obscures real-world business impact | Align detection thresholds with whichever error is more catastrophic for the business. |

## 11. Best Practices and Code Quality
- Always explicitly define label order when computing confusion matrices.
- Verify that `cm.sum()` equals `len(y_test)` to ensure no data rows were dropped.
- Present confusion matrices visually to stakeholders using heatmaps rather than raw terminal arrays.

## 12. Security, Ethics, and Fair AI Considerations
When tuning classification thresholds, platform trust teams often choose to tolerate a slightly higher False Negative rate (allowing a few fake reviews to slip through to manual audit queues) in order to drive the False Positive rate down toward zero, ensuring that authentic users are never falsely accused of fraud.

## 13. Summary and Key Takeaways
A confusion matrix maps actual ground truth against model predictions, isolating True Positives, False Positives, False Negatives, and True Negatives. In our project, all 10 fake reviews and all 10 real reviews in the test split are correctly categorized along the matrix diagonal.

## 14. Knowledge Check Questions
1. In scikit-learn's confusion matrix, do rows represent actual or predicted classes?
2. What is a Type I error in fake review spotter systems?
3. What is a Type II error in fake review spotter systems?
4. What was the value of False Positives achieved by `main.py`?

## 15. References and Further Reading
- Fawcett, T. (2006). *An introduction to ROC analysis.* Pattern Recognition Letters, 27(8), 861-874.
- Scikit-learn API: `sklearn.metrics.confusion_matrix`.
