# Lesson 04: Plotting the Top Distinguishing Words Chart

**Lesson ID:** lesson-04
**Module:** module-05
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Build multi-panel subplots using Matplotlib's `plt.subplots(1, 2)`.
- Create horizontal bar charts (`ax.barh`) to visualize feature importance.
- Reverse list ordering with slice syntax `words[::-1]` for proper top-to-bottom bar alignment.
- Apply custom hex colors (`#c0392b` and `#2471a3`) to distinguish fraud cues from authentic cues.

## 2. Prerequisites
- Module 04 Lesson 04: Dissecting feature_log_prob_ and Clue Strength.
- Basic understanding of Matplotlib subplots and horizontal bar charts.

## 3. Real-World Context & Business Motivation
One of the most effective ways to build stakeholder trust in an AI system is feature visualization. Showing a product team a list of raw log probabilities in a terminal console is rarely persuasive. Presenting a side-by-side, color-coded horizontal bar chart—showing red bars for words that betray fake reviews and blue bars for words that indicate genuine feedback—makes model behavior instantly intuitive, explainable, and visually engaging.

## 4. Concept Explanation
### Constructing Dual Subplots
In `main.py`, we visualize both classes side by side using:
```python
fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
```
- `1, 2`: Specifies 1 row and 2 columns of subplots.
- `axes[0]`: The left subplot (used for fake review clues).
- `axes[1]`: The right subplot (used for real review clues).
- `figsize=(11, 4.5)`: Width of 11 inches and height of 4.5 inches, providing an optimal aspect ratio.

### The Horizontal Bar Chart Ergonomics
Matplotlib's `ax.barh(y, width)` renders bars horizontally from bottom to top along the y-axis:
- If we pass `words = ["best", "wow", "stars"]`, Matplotlib places `"best"` at the **bottom** and `"stars"` at the **top**.
- To make the #1 top clue appear at the **top** of the chart (matching how humans read lists), we reverse the word list using Python slice syntax:
  `words[::-1]`
- The bar lengths are set using `range(1, len(words) + 1)`, creating an elegant descending stair-step visual representing relative rank.

### Color Palette Selection
To maximize visual contrast and semantic intuition:
- **Fake Clues:** Styled in muted red (`#c0392b`), universally recognized as a warning / hazard color.
- **Real Clues:** Styled in calm blue (`#2471a3`), conveying trust, authenticity, and stability.

```mermaid
flowchart LR
    subgraph "Dual Subplot: outputs/top_words.png"
        A["Left Panel (Red #c0392b)
Words suggesting FAKE review
['best', 'wow', 'stars', ...]"]
        B["Right Panel (Blue #2471a3)
Words suggesting REAL review
['liked', 'works', 'support', ...]"]
    end
```

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 80-93 iterate through the two subplots cleanly using a loop:
```python
# ---- Top-word chart ------------------------------------------------
fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
for ax, words, title, colour in (
    (axes[0], fake_words, "Words that suggest a fake review", "#c0392b"),
    (axes[1], real_words, "Words that suggest a real review", "#2471a3"),
):
    ax.barh(words[::-1], range(1, len(words) + 1), color=colour)
    ax.set_title(title)
    ax.set_xlabel("relative clue strength")
    ax.grid(axis="x", alpha=0.25)
fig.tight_layout()
fig.savefig(OUT / "top_words.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```
- The loop unpacks `(ax, words, title, colour)`, eliminating duplicate plotting code.
- `ax.grid(axis="x", alpha=0.25)` adds subtle vertical gridlines with 25% opacity for readability.
- `fig.savefig(OUT / "top_words.png", dpi=150, bbox_inches="tight")` saves the artifact.

## 6. Worked Example
Let's review the exact words displayed on each side of the generated chart:
- **Left Panel (Fake - Red):**
  1. `best` (longest bar at top)
  2. `wow`
  3. `stars`
  4. `wow wow`
  5. `10`
  6. `buy`
  7. `right`
  8. `stars best`
  9. `market`
  10. `need` (shortest bar at bottom)
- **Right Panel (Real - Blue):**
  1. `liked` (longest bar at top)
  2. `works`
  3. `support helped`
  4. `support`
  5. `instructions`
  6. `liked design`
  7. `instructions confusing`
  8. `helped`
  9. `customer`
  10. `customer support` (shortest bar at bottom)

## 7. Step-by-Step Student Instructions
1. In Python, create two sample lists: `fake_clues = ['best', 'wow', 'stars']` and `real_clues = ['liked', 'works', 'support']`.
2. Create subplots: `fig, axes = plt.subplots(1, 2, figsize=(10, 4))`.
3. Plot left: `axes[0].barh(fake_clues[::-1], [3, 2, 1], color='#c0392b')`.
4. Plot right: `axes[1].barh(real_clues[::-1], [3, 2, 1], color='#2471a3')`.
5. Set titles and labels.
6. Save: `fig.savefig('outputs/my_clues.png', dpi=150, bbox_inches='tight')`.
7. Open and inspect `my_clues.png`.

## 8. Expected Output or Observable Behaviour
```text
File created: outputs/top_words.png
Dimensions: 11x4.5 inches @ 150 DPI
Left panel: Red horizontal bars for fake words with highest clue at top.
Right panel: Blue horizontal bars for real words with highest clue at top.
```

## 9. Practical Exercises (with Success Criteria)
- **Task 4.1:** Why does `words[::-1]` reverse a Python list?
- **Task 4.2:** How would you modify the code to display the top 15 words instead of the top 10?
- *Success Criteria:* Explains slice syntax `[start:stop:step]` with negative step; changes `top_words(..., n=15)` and adjusts figure height accordingly.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Omitting `words[::-1]` | Inverts chart hierarchy, placing top clue at the very bottom | Matplotlib barh plots from bottom up; always reverse list for top-down display. |
| Using garish default colors | Reduces chart professionalism | Use curated hex colors like `#c0392b` and `#2471a3`. |
| Hardcoding duplicated plotting blocks | Leads to code redundancy and maintenance bugs | Use a clean `for ax, words, title, colour in (...)` loop structure. |

## 11. Best Practices and Code Quality
- Iterate over subplot axes using tuple loops to keep visualization scripts DRY (Don't Repeat Yourself).
- Add subtle gridlines on the measurement axis (`ax.grid(axis='x', alpha=0.25)`) to aid eye tracking.
- Set appropriate figure sizes: horizontal multi-panel figures require wider aspect ratios (`figsize=(11, 4.5)`).

## 12. Security, Ethics, and Fair AI Considerations
Feature importance charts make model biases immediately visible. If an audit of `top_words` revealed demographic terms, ethnic markers, or non-English names as "fake clues," engineers would immediately detect unacceptable algorithmic bias. Feature visualizations are indispensable tools for algorithmic fairness audits.

## 13. Summary and Key Takeaways
Side-by-side horizontal bar charts (`ax.barh`) provide an intuitive, publication-ready visualization of distinguishing vocabulary. Reversing lists with `words[::-1]` ensures top clues appear at the top of the chart, and semantic colors (`#c0392b` red and `#2471a3` blue) clearly communicate fraud indicators versus authenticity signals.

## 14. Knowledge Check Questions
1. Why does `main.py` slice words with `words[::-1]` before passing them to `ax.barh`?
2. What two hex color codes are used for fake clues and real clues respectively?
3. How does the loop structure in lines 82-89 keep plotting code concise?
4. What visual deliverable is saved to `outputs/top_words.png`?

## 15. References and Further Reading
- Tufte, E. R. (2001). *The Visual Display of Quantitative Information.* Graphics Press.
- Matplotlib documentation: `matplotlib.axes.Axes.barh`.
