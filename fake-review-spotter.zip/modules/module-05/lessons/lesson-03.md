# Lesson 03: Visualizing the Confusion Matrix

**Lesson ID:** lesson-03
**Module:** module-05
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Render graphical confusion matrices using scikit-learn's `ConfusionMatrixDisplay`.
- Configure headless matplotlib environments using `matplotlib.use("Agg")`.
- Customize colormaps (`cmap="Purples"`) and colorbar settings for clean visual reporting.
- Save high-resolution publication-quality PNG artifacts using `fig.savefig()`.

## 2. Prerequisites
- Completion of Lesson 02: The Confusion Matrix Demystified.
- Familiarity with basic Matplotlib figure creation (`plt.subplots`).

## 3. Real-World Context & Business Motivation
Raw numerical arrays like `[[10, 0], [0, 10]]` are fine for developers, but executives, product managers, and external compliance regulators need intuitive visual dashboards. A graphical confusion matrix uses color intensity (heatmapping) to draw immediate attention to performance bottlenecks. Furthermore, production AI systems run inside automated continuous integration (CI) environments without physical monitors. Configuring a headless rendering backend ensures that scripts generate visual artifacts cleanly without crashing server processes.

## 4. Concept Explanation
### Headless Rendering with `matplotlib.use("Agg")`
By default, Matplotlib tries to open an interactive desktop window (using Qt, Tkinter, or Cocoa) when creating plots. On a headless Linux server or Docker container, this triggers a fatal `UserWarning` or crash: *"No display available"*.

Calling:
```python
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
```
selects the **Anti-Grain Geometry (Agg)** engine. Agg renders plots purely in software memory buffers directly to disk, completely bypassing the operating system's graphical desktop manager. **It must be called before importing `pyplot`!**

### `ConfusionMatrixDisplay` Workflow
Scikit-learn provides `ConfusionMatrixDisplay` to bridge model evaluation and matplotlib visualization:
```python
cm = confusion_matrix(y_test, predictions, labels=["fake", "real"])
fig, ax = plt.subplots(figsize=(5, 4))
ConfusionMatrixDisplay(cm, display_labels=labels).plot(ax=ax, cmap="Purples", colorbar=False)
```
- `ConfusionMatrixDisplay(cm, display_labels=labels)`: Wraps the count matrix and assigns clear string labels to the axes.
- `.plot(ax=ax)`: Draws the annotated heatmap onto the specified Matplotlib axis.
- `cmap="Purples"`: Uses varying shades of purple to indicate cell density.
- `colorbar=False`: Suppresses the side colorbar for a cleaner, compact presentation.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 94-103 generate and save the graphic:
```python
# ---- Confusion matrix ---------------------------------------------
labels = ["fake", "real"]
cm = confusion_matrix(y_test, predictions, labels=labels)
fig, ax = plt.subplots(figsize=(5, 4))
ConfusionMatrixDisplay(cm, display_labels=labels).plot(ax=ax, cmap="Purples", colorbar=False)
ax.set_title("Fake review classification")
fig.tight_layout()
fig.savefig(OUT / "confusion_matrix.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```
- `fig.tight_layout()`: Automatically adjusts subplot padding so axis labels are never cropped.
- `dpi=150`: Sets output resolution to 150 dots-per-inch (crisp image quality).
- `bbox_inches="tight"`: Crops extraneous whitespace around the figure borders.
- `plt.close(fig)`: Closes the figure to free up system memory.

## 6. Worked Example
Let's trace what `outputs/confusion_matrix.png` looks like when rendered:
```text
                  Predicted label
                fake          real
Actual fake      10            0       <-- Dark purple cell (count 10), White cell (count 0)
Actual real       0           10       <-- White cell (count 0), Dark purple cell (count 10)
```
- Both diagonal cells contain dark purple backgrounds with bold count annotations (`10`).
- Both off-diagonal error cells contain pure white backgrounds (`0`).
- Title: *"Fake review classification"*.

## 7. Step-by-Step Student Instructions
1. In your Python session, import `matplotlib` and set `matplotlib.use('Agg')`.
2. Import `pyplot` and `ConfusionMatrixDisplay`.
3. Compute the confusion matrix on `y_test` and `predictions`.
4. Create the plot with `fig, ax = plt.subplots(figsize=(5, 4))`.
5. Call `ConfusionMatrixDisplay(cm, display_labels=['fake', 'real']).plot(ax=ax, cmap='Purples', colorbar=False)`.
6. Save the figure: `fig.savefig('outputs/test_matrix.png', dpi=150, bbox_inches='tight')`.
7. Verify that the image file was created on disk and inspect it.

## 8. Expected Output or Observable Behaviour
```text
File created: outputs/confusion_matrix.png
Resolution: Crisp 150 DPI
Layout: Clean 2x2 grid with Purples colormap and axis labels.
```

## 9. Practical Exercises (with Success Criteria)
- **Task 3.1:** What happens if `matplotlib.use("Agg")` is called AFTER `import matplotlib.pyplot as plt`?
- **Task 3.2:** Why is `plt.close(fig)` important when generating multiple charts in a loop?
- *Success Criteria:* Notes that backend changes after pyplot import emit warnings or fail; explains that `plt.close(fig)` prevents memory leaks.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Forgetting `plt.close(fig)` | Accumulates open figures in memory, causing RAM leaks | Always call `plt.close(fig)` after saving images. |
| Omitting `bbox_inches="tight"` | Axis labels or titles can be clipped off at image edges | `bbox_inches="tight"` guarantees complete boundary capture. |
| Calling `plt.show()` in headless scripts | Halts script execution or crashes on headless servers | Use `fig.savefig()` and headless `Agg` backend for automation. |

## 11. Best Practices and Code Quality
- Set backend explicitly at the very top of the script before any pyplot imports.
- Use distinct, readable colormaps (e.g., `Purples`, `Blues`, `Blues_r`) with strong contrast.
- Keep figure dimensions compact and legible for embedding in Markdown reports or slide decks.

## 12. Security, Ethics, and Fair AI Considerations
Visual artifacts are often presented directly to non-technical business leaders. Misleading visual choices—such as scaling colormaps to make small error counts look invisible or exaggerating minor differences—distorts decision-making. Visualizations must accurately represent data without deceptive visual scaling.

## 13. Summary and Key Takeaways
Using `ConfusionMatrixDisplay` with Matplotlib's non-interactive `Agg` backend allows seamless, headless generation of publication-quality confusion matrix graphics. Configuring `cmap="Purples"`, `tight_layout`, and `bbox_inches="tight"` produces clean visual artifacts ready for auditing.

## 14. Knowledge Check Questions
1. Why must `matplotlib.use("Agg")` appear before `import matplotlib.pyplot as plt`?
2. What does `ConfusionMatrixDisplay.plot()` do?
3. What is the purpose of `fig.tight_layout()`?
4. Where does `main.py` save the confusion matrix image?

## 15. References and Further Reading
- Hunter, J. D. (2007). *Matplotlib: A 2D graphics environment.* Computing in Science & Engineering.
- Scikit-learn API: `sklearn.metrics.ConfusionMatrixDisplay`.
