# Module 5 Exercises: Model Evaluation & Clue Visualization

## Exercise 5.1: Generating and Parsing the Classification Report (10 min)
**Objective:** Compute model predictions and programmatically parse `classification_report`.
**Problem Statement:** Write a Python script that evaluates the trained pipeline on `X_test`, prints the formatted string report, and then extracts precision, recall, and f1-score as a dictionary.

**Requirements:**
1. Train the pipeline on `X_train` and predict on `X_test`.
2. Generate the console report using `classification_report(y_test, predictions, zero_division=0)`.
3. Generate a dictionary report using `classification_report(..., output_dict=True)`.
4. Assert that `report_dict['fake']['precision'] == 1.0`.
5. Assert that `report_dict['real']['recall'] == 1.0`.

**Constraints:** Use `classification_report` from `sklearn.metrics`.

**Expected Behaviour:** Printed text table followed by programmatic dictionary assertions.

**Acceptance Criteria:**
- [ ] Outputs formatted text classification report.
- [ ] Successfully uses `output_dict=True` to extract numeric scores.
- [ ] Confirms 100% precision and recall for both classes.
- [ ] Confirms support of 10 for both classes.

**Hints:**
- `report_dict = classification_report(y_test, predictions, output_dict=True)`
- Access nested values: `report_dict['fake']['f1-score']`.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes

---

## Exercise 5.2: Computing and Interpreting the 2x2 Confusion Matrix (15 min)
**Objective:** Compute the confusion matrix and verify quadrant calculations.
**Problem Statement:** Compute the confusion matrix on the test set with explicit label ordering and verify true positives, false positives, true negatives, and false negatives.

**Requirements:**
1. Call `cm = confusion_matrix(y_test, predictions, labels=["fake", "real"])`.
2. Extract the four quadrant values into named variables:
   - `tp = cm[0, 0]`
   - `fn = cm[0, 1]`
   - `fp = cm[1, 0]`
   - `tn = cm[1, 1]`
3. Verify that `tp == 10`, `fn == 0`, `fp == 0`, `tn == 10`.
4. Write out the formulas for Precision and Recall using `tp`, `fp`, and `fn`, and confirm they yield 1.0.

**Constraints:** Follow the exact label indexing from `main.py`.

**Expected Behaviour:** Console output displaying quadrant values and verified manual formulas.

**Acceptance Criteria:**
- [ ] Correctly indexes quadrants: TP=(0,0), FN=(0,1), FP=(1,0), TN=(1,1).
- [ ] Confirms zero off-diagonal errors.
- [ ] Reconstructs Precision $= \frac{TP}{TP + FP}$ and Recall $= \frac{TP}{TP + FN}$.
- [ ] All assertions pass.

**Hints:**
- In scikit-learn, rows correspond to true labels; columns correspond to predictions.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 5.3: Rendering the Confusion Matrix Display (15 min)
**Objective:** Visualize the confusion matrix using `ConfusionMatrixDisplay` with custom styling.
**Problem Statement:** Write a script that configures the headless `Agg` backend, renders the confusion matrix with the `Purples` colormap, and saves the image to `outputs/test_cm.png`.

**Requirements:**
1. Configure `matplotlib.use("Agg")` before importing pyplot.
2. Compute `cm` for `y_test` and `predictions`.
3. Create figure with `fig, ax = plt.subplots(figsize=(5, 4))`.
4. Plot using `ConfusionMatrixDisplay(cm, display_labels=['fake', 'real']).plot(ax=ax, cmap='Purples', colorbar=False)`.
5. Set title: `"Fake review classification"`.
6. Save image using `fig.savefig("outputs/test_cm.png", dpi=150, bbox_inches="tight")` and call `plt.close(fig)`.

**Constraints:** Verify that the image file exists and is greater than 10 KB on disk.

**Expected Behaviour:** A clean PNG file created in `outputs/`.

**Acceptance Criteria:**
- [ ] Script runs cleanly in headless environments without graphical display warnings.
- [ ] Confusion matrix displays counts inside each cell.
- [ ] PNG file is saved at 150 DPI with tight bounding box.
- [ ] Memory is cleaned up using `plt.close(fig)`.

**Hints:**
- Check file size: `import os; os.path.getsize("outputs/test_cm.png")`.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 5.4: Custom Top Clue Words Visualization (15 min)
**Objective:** Generate a two-panel horizontal bar chart visualizing the top 10 clue words.
**Problem Statement:** Recreate the `outputs/top_words.png` chart from `main.py`, customizing the theme to use custom colors and gridlines.

**Requirements:**
1. Extract the top 10 fake clue words and top 10 real clue words using `top_words()`.
2. Create a figure with `fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))`.
3. In a loop, plot horizontal bars with `ax.barh(words[::-1], range(1, len(words) + 1), color=colour)`.
4. Use color `#c0392b` for fake clues and `#2471a3` for real clues.
5. Set titles, x-labels, and subtle horizontal gridlines (`ax.grid(axis='x', alpha=0.25)`).
6. Save to `outputs/top_words.png` with `dpi=150` and `bbox_inches="tight"`.

**Constraints:** Must replicate the visualization logic in `main.py` lines 80-93.

**Expected Behaviour:** A two-panel horizontal bar chart saved to disk.

**Acceptance Criteria:**
- [ ] Left panel shows top fake clues in red.
- [ ] Right panel shows top real clues in blue.
- [ ] Top clue word appears at the top of each panel (verified list reversal).
- [ ] Figure saves cleanly without text overlapping.

**Hints:**
- Unpack: `for ax, words, title, colour in ((axes[0], fake_words, ...), (axes[1], real_words, ...)):`.

**Difficulty:** Advanced  
**Estimated Completion Time:** 15 minutes
