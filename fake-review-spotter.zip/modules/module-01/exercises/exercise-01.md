# Module 1 Exercises: NLP Foundations & Problem Formulation

## Exercise 1.1: Problem Type Formulation (10 min)
**Objective:** Classify machine learning problems by task type and formulate the Fake Review Spotter.
**Problem Statement:** You are tasked with designing an AI architecture for detecting deceptive online reviews. You must formally specify the machine learning task type, input representations, and target variables.

**Requirements:**
1. State whether this project is supervised or unsupervised, and justify why.
2. State whether this is regression or classification, and explain the difference.
3. Define the mathematical input $X$ and target $y$ using the column names from `data/reviews.csv`.

**Constraints:** Base your answer strictly on the project codebase and dataset.

**Expected Behaviour:** A structured 4-6 sentence technical specification.

**Acceptance Criteria:**
- [ ] Correctly identifies task as supervised binary classification.
- [ ] Distinguishes classification (discrete labels) from regression (continuous numbers).
- [ ] Specifies $X = \text{review text}$ and $y = \text{authenticity label } (\in \{\text{'fake'}, \text{'real'}\})$.
- [ ] Explains the necessity of labeled training examples.

**Hints:**
- Look at `df["review"]` and `df["label"]` in `main.py`.
- Does the model predict a number like $44.6$ or a category like `"fake"`?

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes

---

## Exercise 1.2: Linguistic Signal Analysis (15 min)
**Objective:** Identify and contrast linguistic markers of deceptive versus authentic reviews.
**Problem Statement:** Read the first 6 rows of `data/reviews.csv`. Extract specific vocabulary and stylistic traits that differentiate the fake reviews from genuine customer reviews.

**Requirements:**
1. Select one fake review and one real review from `data/reviews.csv`.
2. List all adjectives and punctuation choices in both reviews.
3. Explain how the fake review exhibits "linguistic leakage" (absence of concrete product details, excessive superlatives).
4. Explain how the real review exhibits balanced evaluation.

**Constraints:** Cite verbatim phrases from `data/reviews.csv`.

**Expected Behaviour:** A comparative analysis table followed by a brief narrative.

**Acceptance Criteria:**
- [ ] Quotes an actual fake review (e.g., "WOW WOW WOW. I love it so much. Best seller ever. 10/10.").
- [ ] Quotes an actual real review (e.g., "Good value for the price. It is not perfect, but it does the job.").
- [ ] Identifies superlative adjectives and urgency in the fake sample.
- [ ] Identifies trade-off language ("not perfect, but does the job") in the real sample.

**Hints:**
- Look for exclamation marks, uppercase capitalization, and words like "best", "perfect", "flawless".
- Look for balancing words like "but", "however", "fine", "mixed".

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 1.3: The Lie Detector Fallacy (10 min)
**Objective:** Analyze the critical distinction between a statistical pattern finder and a lie detector.
**Problem Statement:** A product manager suggests: *"Our model achieved 100% test accuracy, so we can automatically ban any seller whose review has a fake score above 90% without human review."* Write a technical memo evaluating why this policy is dangerous.

**Requirements:**
1. Explain why high statistical confidence does not equal physical ground truth.
2. Provide a concrete example of an honest customer review that could trigger a false positive.
3. Outline the business and reputation risks of banning sellers based solely on text patterns.
4. Propose a safer, tiered moderation policy.

**Constraints:** Address the "enthusiastic customer" dilemma discussed in Lesson 03.

**Expected Behaviour:** A professional 1-page memo outlining risks and recommendations.

**Acceptance Criteria:**
- [ ] Explains that ML models detect lexical correlation rather than factual veracity.
- [ ] Includes an example of an authentic review with enthusiastic superlatives.
- [ ] Identifies the risk of alienating authentic brand advocates (Type I errors).
- [ ] Recommends human-in-the-loop review or proof-of-purchase verification.

**Hints:**
- Review the project docstring: *"A text classifier that learns word patterns. It is a pattern finder, not a lie detector"*.
- Consider what happens when someone genuinely loves a product and writes "Best product ever!".

**Difficulty:** Intermediate  
**Estimated Completion Time:** 10 minutes

---

## Exercise 1.4: Threat Modeling & Adversarial Evasion (15 min)
**Objective:** Formulate adversarial tactics that review spammers use to evade bag-of-words text classifiers.
**Problem Statement:** Assume an unscrupulous competitor knows your platform uses a Naive Bayes model with `top_words` clues (`best`, `wow`, `stars`, `buy`). Design an adversarial strategy to post deceptive 5-star reviews without triggering the classifier.

**Requirements:**
1. Explain how a fraudster could intentionally avoid the top fake clue words.
2. Write a synthetic deceptive 5-star review that incorporates top "real" clues (`works`, `support helped`, `liked design`) while still promoting the product.
3. Explain why pure text classifiers are vulnerable to this adversarial attack.
4. Suggest two non-text metadata features that could defeat this evasion technique.

**Constraints:** The adversarial review must read like a positive recommendation while mimicking authentic review language.

**Expected Behaviour:** An adversarial review example and multi-signal defense proposal.

**Acceptance Criteria:**
- [ ] Crafted review avoids words like "AMAZING", "WOW", "Best seller".
- [ ] Crafted review incorporates real-clue vocabulary ("works as expected", "customer support helped").
- [ ] Explains that bag-of-words models cannot detect semantic deception if word frequencies mimic genuine text.
- [ ] Proposes non-text features (e.g., verified purchase status, account age, review velocity, IP clustering).

**Hints:**
- Review line 112 of `main.py`: *"add 10 honest reviews that sound enthusiastic and see whether they fool the model"*.
- Think about what metadata an e-commerce platform has access to beyond raw text.

**Difficulty:** Advanced  
**Estimated Completion Time:** 15 minutes
