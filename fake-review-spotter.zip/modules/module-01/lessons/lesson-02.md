# Lesson 02: Linguistic Signals of Deceptive Text

**Lesson ID:** lesson-02
**Module:** module-01
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Identify linguistic markers that distinguish fraudulent reviews from genuine customer feedback.
- Explain the concept of "linguistic leakage" in computational deception detection.
- Contrast hyperbolic superlatives with concrete feature descriptions.
- Analyze how emotional valence and lexical diversity differ across review classes.

## 2. Prerequisites
- Completion of Lesson 01: The Fake Review Crisis.
- Basic understanding of parts of speech (nouns, adjectives, verbs).

## 3. Real-World Context & Business Motivation
When human beings describe an event they personally experienced, their language is anchored in sensory details: how an object felt, how long delivery took, or how an issue was resolved with customer support. Conversely, when copywriters fabricate an experience for a product they never touched, their psychological focus shifts toward persuasion. They compensate for the absence of authentic memories by inflating emotional claims, using urgent imperatives, and overusing superlatives. Computational linguists study these unconscious writing patterns to engineer effective NLP features.

## 4. Concept Explanation
### Linguistic Signatures of Deception
Decades of psycholinguistic research (such as seminal work by Ott, Choi, Cardie, and Hancock) reveal distinct linguistic markers in deceptive text:
1. **Absence of Concrete Context:** Fake reviews rarely describe physical dimensions, assembly steps, or environmental conditions.
2. **Elevated Superlatives & Exclamations:** Words like *"flawless"*, *"best ever"*, *"perfect everything"*, and repeated punctuation (*"!!!"*) appear with unnatural frequency.
3. **Urgency & Call-to-Action Language:** Phrases like *"buy now"*, *"must buy"*, and *"you will not regret it"* read like marketing sales copy rather than spontaneous consumer feedback.
4. **Balanced Nuance in Authentic Feedback:** Genuine reviews routinely include trade-offs, pairing positive observations with minor drawbacks (*"good value, but cable is short"*).

### Lexical Leakage
"Linguistic leakage" refers to the involuntary stylistic fingerprints left behind by writers fabricating claims. Even skilled writers struggle to suppress repetitive patterns when generating dozens of fake endorsements.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 60-65 reveal the exact linguistic cues uncovered by the model:
```python
fake_words = top_words(model, fake_index)
real_words = top_words(model, 1 - fake_index)
print("Top 'fake' clues:", ", ".join(fake_words))
print("Top 'real' clues:", ", ".join(real_words))
```
When executed, this outputs:
- **Top 'fake' clues:** `best`, `wow`, `stars`, `wow wow`, `10`, `buy`, `right`, `stars best`, `market`, `need`
- **Top 'real' clues:** `liked`, `works`, `support helped`, `support`, `instructions`, `liked design`, `instructions confusing`, `helped`, `customer`, `customer support`

Notice the stark difference: fake clues are generic marketing superlatives; real clues describe functional interactions, instructions, and customer service.

## 6. Worked Example
Let's analyze two sentences from `data/reviews.csv`:
```text
Sentence 1: "Five stars! Best product on the market. You need this right now."
Sentence 2: "I liked the design, but the instructions were confusing. Customer support helped."
```
- **Sentence 1 analysis:** Contains zero concrete product nouns. Features imperatives ("need this right now") and superlative claims ("best product on the market").
- **Sentence 2 analysis:** Contains concrete domain nouns ("design", "instructions", "customer support"), a balancing conjunction ("but"), and an honest critique ("confusing").

## 7. Step-by-Step Student Instructions
1. Inspect the top fake clues from `main.py`: `["best", "wow", "stars", "buy", "need"]`.
2. Inspect the top real clues: `["liked", "works", "support", "instructions", "helped"]`.
3. Create a two-column table in your notebook titled "Marketing Hype" vs "Practical Experience".
4. Place each word into the appropriate column and explain why "support helped" is virtually impossible to fabricate generically.

## 8. Expected Output or Observable Behaviour
When comparing genuine vs fake text samples:
```text
Deceptive Text Profile:
- Lexical style: Promotional, urgent, vague
- Sentiment: Exclusively 100% positive without reservations

Genuine Text Profile:
- Lexical style: Descriptive, conditional, contextual
- Sentiment: Balanced, acknowledging minor flaws or practical realities
```

## 9. Practical Exercises (with Success Criteria)
- **Task 2.1:** Draft an artificial 2-sentence fake review using 4 of the top fake clue words.
- **Task 2.2:** Draft a genuine review of the same product mentioning at least one physical limitation or customer support interaction.
- *Success Criteria:* Fake draft contains urgency and superlatives; genuine draft includes concrete details and measured tone.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Believing fake reviews always have spelling errors | Professional review brokers write polished, persuasive copy | Deceptive text is often grammatically clean; the signal lies in semantic vagueness. |
| Overlooking bigrams like "customer support" | Single words miss contextual phrases | Bigrams reveal specific multi-word interactions that characterize authentic use. |
| Assuming negative reviews cannot be fake | Competitor smear campaigns generate fake negative reviews | Linguistic leakage applies to manufactured negativity as well as hype. |

## 11. Best Practices and Code Quality
- Analyze both unigrams and n-grams to capture phrase-level collocations.
- Use log-likelihood ratios rather than raw counts to prevent common words from dominating clue lists.
- Periodically retrain vocabulary extractors as fraud styles evolve.

## 12. Security, Ethics, and Fair AI Considerations
Linguistic patterns vary across cultures, dialects, and non-native English speakers. Reviewers who speak English as a second language may write shorter, simpler sentences that could be erroneously flagged if models over-index on brevity. Models must be audited for demographic equity.

## 13. Summary and Key Takeaways
Deceptive reviews leak psycholinguistic markers: excessive superlatives, sales imperatives, and vague praise. Genuine reviews feature concrete nouns, conditional trade-offs, and descriptions of customer service interactions. Natural language processing capitalizes on these lexical discrepancies to categorize text.

## 14. Knowledge Check Questions
1. What is meant by "linguistic leakage" in deceptive writing?
2. Why do fake reviews tend to lack concrete physical descriptions?
3. Name two bigrams identified in `main.py` that strongly signal authentic reviews.
4. Why might an honest customer occasionally write a review that looks like promotional copy?

## 15. References and Further Reading
- Ott, M., Choi, Y., Cardie, C., & Hancock, J. T. (2011). *Finding Deceptive Opinion Spam by Any Stretch of the Imagination.* Proceedings of the 49th Annual Meeting of the Association for Computational Linguistics (ACL).
- Pennebaker, J. W. (2011). *The Secret Life of Pronouns: What Our Words Say About Us.* Bloomsbury Press.
