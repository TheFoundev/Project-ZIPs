# Lesson 03: Pattern Finder vs. Lie Detector

**Lesson ID:** lesson-03
**Module:** module-01
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why a statistical NLP classifier is a pattern finder rather than a truth verifier.
- Define what ground truth means in machine learning versus physical reality.
- Analyze how false positives occur when enthusiastic genuine buyers use superlative vocabulary.
- Recognize the operational dangers of treating model predictions as infallible proof of deception.

## 2. Prerequisites
- Completion of Lesson 02: Linguistic Signals of Deceptive Text.
- Conceptual understanding of statistical correlation versus causation.

## 3. Real-World Context & Business Motivation
In marketing presentations, automated moderation tools are frequently branded as "AI Lie Detectors." This terminology is dangerous and scientifically inaccurate. A machine learning model has no sensory connection to the physical universe. It cannot inspect the shipping label, verify whether the package was delivered, or test the battery lifespan. It merely calculates: *"Given the vocabulary in this string, how closely does it match the lexical distribution of documents labeled 'fake' in our training set?"* Confusing correlation with truth leads to catastrophic customer service decisions.

## 4. Concept Explanation
### Statistical Correlation vs. Physical Ground Truth
Consider the logical gap between text classification and factual verification:
- **What the model does:** Analyzes token co-occurrences. If words like *"AMAZING"* and *"Best"* occurred 90% of the time in the training set's fake class, the model assigns high probability to the fake class.
- **What the model cannot do:** Determine whether the author is telling the truth.

### The Enthusiastic Customer Dilemma
Suppose an authentic customer receives a telescope for their birthday, gazes at the rings of Saturn for the first time, and excitedly submits:
> *"AMAZING product! Best purchase ever! Five stars!"*

This review is 100% genuine in physical reality. However, to a bag-of-words classifier, this review contains identical vocabulary to paid promotional astroturfing. The model will confidently output `fake (100%)`. This constitutes a **False Positive** (Type I Error).

```mermaid
flowchart LR
    A["Customer Review Text"] --> B["CountVectorizer + Naive Bayes"]
    B --> C{"Model Output"}
    C -->|"fake"| D["Matches Training Pattern for Spam"]
    D -.->|Does NOT equal| E["Objective Physical Falsehood"]
```

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 112-113 highlight this limitation directly:
```python
print("\nSaved: outputs/top_words.png, outputs/confusion_matrix.png, outputs/predictions.txt")
print("Try this: add 10 honest reviews that sound enthusiastic and see whether they fool the model.")
```
The author intentionally challenges students to craft honest, enthusiastic reviews to demonstrate how easily the classifier is deceived by stylistic mimicry.

## 6. Worked Example
Let's trace how the model evaluates this test review from line 68 of `main.py`:
```python
review = "AMAZING!!! Best product ever. Buy it now, you will not regret it!"
prediction = model.predict([review])[0]
probability = model.predict_proba([review])[0]
```
The model outputs:
```text
fake (100%) -> AMAZING!!! Best product ever. Buy it now, you will not regret it!
```
The model is 100% mathematically confident that the review matches the fake training cluster. But if an actual customer wrote this out of genuine excitement, treating this output as an objective "lie detector" would lead the store to wrongly penalize or delete the customer's legitimate feedback.

## 7. Step-by-Step Student Instructions
1. Review the test prediction for the enthusiastic review in `main.py`.
2. Write down 3 reasons why an honest customer might express themselves with extreme enthusiasm.
3. Consider the impact on customer loyalty if an honest customer's five-star review is deleted because an algorithm flagged it as "fake".
4. Document a policy recommendation for how platforms should handle high-confidence "fake" predictions.

## 8. Expected Output or Observable Behaviour
When testing enthusiastic phrasing on the trained classifier:
```text
Input: "AMAZING! Best ever. Highly recommend to everyone!"
Predicted Label: fake
Confidence: >98%
Reality Check: Stylistic match to fake cluster, but factual veracity remains unknown.
```

## 9. Practical Exercises (with Success Criteria)
- **Task 3.1:** Explain in two sentences why calling an NLP model a "lie detector" is technically inaccurate.
- **Task 3.2:** Provide an example of how an adversarial spammer could intentionally write a fake review designed to look "real" to the model.
- *Success Criteria:* Answers highlight reliance on surface lexical statistics and vulnerability to stylistic manipulation.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Equating high model confidence with truth | Confidence indicates statistical fit, not factuality | A model can be 99% confident in a false positive classification. |
| Banning users based solely on NLP text scores | Alienates authentic enthusiastic brand advocates | Automated text flags should trigger human verification or proof-of-purchase checks. |
| Believing models understand semantic truth | Models operate on token counts, not reality models | Classifiers detect word distribution signatures, not physical phenomena. |

## 11. Best Practices and Code Quality
- Always document model limitations prominently in README files and system documentation.
- Implement tiered confidence thresholds (e.g., reviews with 70-90% fake score go to a human queue; >95% undergo metadata checks).
- Never deploy punitive automated actions based solely on a single unverified text score.

## 12. Security, Ethics, and Fair AI Considerations
Treating statistical pattern finders as truth arbiters creates serious ethical hazards. Legitimate users who write with exclamation marks or informal colloquialisms may be systematically silenced. Responsible AI governance requires transparent appeals mechanisms for flagged content.

## 13. Summary and Key Takeaways
NLP text classifiers are pattern spotters that discover statistical associations in vocabulary, not truth-verifying lie detectors. Honest customers using glowing superlatives risk being misclassified as fake, while deceptive writers can mimic balanced language to evade detection.

## 14. Knowledge Check Questions
1. What is the fundamental difference between a pattern finder and a lie detector?
2. What is a False Positive in the context of fake review spotters?
3. Why does an honest review saying "AMAZING! Best product ever!" get classified as fake?
4. How should an e-commerce platform handle reviews flagged with high fake confidence?

## 15. References and Further Reading
- Crawford, K. (2021). *Atlas of AI: Power, Politics, and the Planetary Costs of Artificial Intelligence.* Yale University Press.
- scikit-learn documentation on classifier probability calibration.
