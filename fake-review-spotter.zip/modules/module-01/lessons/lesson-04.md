# Lesson 04: Supervised Binary Text Classification

**Lesson ID:** lesson-04
**Module:** module-01
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Formulate fake review detection as a supervised binary classification problem.
- Define feature variables ($X$) and target variables ($y$) in natural language processing.
- Explain the role of training and testing data splits in evaluating generalization.
- Map the mathematical inputs and outputs of the Fake Review Spotter pipeline.

## 2. Prerequisites
- Completion of Lessons 01-03.
- Basic understanding of Python variables and functions.

## 3. Real-World Context & Business Motivation
Before writing code or tuning hyperparameters, machine learning engineers must mathematically formulate their business problem. In fake review detection, an e-commerce platform receives millions of continuous text strings and must assign each string to one of two operational categories: allow publication or route to fraud investigation. Framing this as supervised binary classification gives us access to decades of rigorous statistical algorithms, evaluation metrics, and optimization techniques.

## 4. Concept Explanation
### Supervised Learning Paradigm
In supervised learning, an algorithm learns a mapping function from labeled historical data:
$$f: X \to y$$
Where:
- **$X$ (Feature Input):** The unstructured review text (e.g., *"WOW WOW WOW. I love it so much."*).
- **$y$ (Target Label):** The ground-truth classification category $\in \{\text{"fake"}, \text{"real"}\}$.

```text
Historical Examples:
(Review Text 1, "fake")
(Review Text 2, "real")
(Review Text 3, "fake")
...
Algorithm fits parameters -> Learns mapping function f(X)
```

### Binary vs. Multi-Class Classification
- **Binary Classification:** Exactly two mutually exclusive outcome classes ($K=2$). In this project, a review is either labeled `"fake"` or `"real"`.
- **Multi-Class Classification:** Three or more classes ($K \ge 3$), such as predicting a star rating $\in \{1, 2, 3, 4, 5\}$ or topic category $\in \{\text{"electronics"}, \text{"clothing"}, \text{"books"}\}$.

### Generalization & Out-of-Sample Evaluation
If an algorithm simply memorizes the training text, it will fail when exposed to novel customer reviews. To evaluate true generalization, we split our labeled dataset into two distinct partitions:
1. **Training Partition (e.g., 75%):** Used exclusively by the algorithm to learn vocabulary associations and class probabilities.
2. **Testing Partition (e.g., 25%):** Held out unseen during training, used strictly to measure how accurately the model classifies novel reviews.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 39-52 implement this exact formulation:
```python
df = pd.read_csv(DATA / "reviews.csv")
X_train, X_test, y_train, y_test = train_test_split(
    df["review"], df["label"], test_size=0.25, random_state=42, stratify=df["label"]
)

model = Pipeline(
    [
        ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
        ("classifier", MultinomialNB()),
    ]
)
model.fit(X_train, y_train)
predictions = model.predict(X_test)
```
- `df["review"]` is extracted as the feature input $X$.
- `df["label"]` is extracted as the target output $y$.
- `model.fit(X_train, y_train)` performs supervised training.
- `model.predict(X_test)` evaluates out-of-sample performance on unseen reviews.

## 6. Worked Example
Suppose our dataset consists of 4 labeled reviews:
1. *"Best seller ever. 10/10."* $\to$ `fake`
2. *"Item arrived scratched, but customer support replaced it."* $\to$ `real`
3. *"Flawless product, must buy right now."* $\to$ `fake`
4. *"Works well, but setup instructions were vague."* $\to$ `real`

The model ingests reviews 1-3 during training. During testing, it receives review 4:
- Input $X_{\text{test}}$: *"Works well, but setup instructions were vague."*
- Prediction $\hat{y}$: `real`
- Ground Truth $y_{\text{test}}$: `real`
- Result: Correct classification!

## 7. Step-by-Step Student Instructions
1. Open terminal and run `python -c "import pandas as pd; df = pd.read_csv('data/reviews.csv'); print(df.columns)"`.
2. Confirm that the columns are `review` and `label`.
3. Check the target labels using `df['label'].unique()`.
4. Confirm that there are exactly two unique values: `['fake', 'real']`.

## 8. Expected Output or Observable Behaviour
```text
Index(['review', 'label'], dtype='object')
Unique target classes: ['fake', 'real']
Task type: Supervised Binary Classification
```

## 9. Practical Exercises (with Success Criteria)
- **Task 4.1:** Write down the mathematical mapping equation for the Fake Review Spotter.
- **Task 4.2:** Explain why passing `X_test` into `model.fit()` would constitute a fatal data science error (data leakage).
- *Success Criteria:* Explanations clearly define inputs, outputs, and the necessity of partition separation.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Treating text classification as regression | Regression predicts continuous numbers, not classes | Binary classification maps inputs to categorical labels. |
| Fitting on the entire dataset without splitting | Yields overoptimistic evaluation through data leakage | Always evaluate performance on an independent test split. |
| Inverting features and target | Attempting to predict text from labels fails | $X$ must be review text; $y$ must be authenticity labels. |

## 11. Best Practices and Code Quality
- Ensure target labels are consistently encoded as strings or standard integers (0 and 1).
- Use stratified splitting to maintain class proportions across partitions.
- Encapsulate preprocessing and modeling in an atomic scikit-learn `Pipeline`.

## 12. Security, Ethics, and Fair AI Considerations
Ground truth labels in training datasets are created by human annotators or heuristic rules. If annotators are biased against certain writing styles, the model will faithfully learn and perpetuate those biases. Auditing training label quality is fundamental to fair machine learning.

## 13. Summary and Key Takeaways
Fake review detection is formulated as supervised binary classification. Unstructured text reviews serve as feature inputs ($X$), and binary authenticity categories serve as target labels ($y$). Training on labeled examples allows the algorithm to learn patterns that generalize to unseen test data.

## 14. Knowledge Check Questions
1. What are the feature inputs and target outputs in this project?
2. Why is this problem categorized as binary rather than multi-class classification?
3. What is the purpose of holding out a test partition during model training?
4. What is "data leakage" and how does proper train/test splitting prevent it?

## 15. References and Further Reading
- Hastie, T., Tibshirani, R., & Friedman, J. (2009). *The Elements of Statistical Learning.* Springer.
- Scikit-learn documentation: Supervised learning and model evaluation.
