# Lesson 04: Feature and Target Separation

**Lesson ID:** lesson-04
**Module:** module-02
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Separate the input feature Series ($X$) and target label Series ($y$) from a pandas DataFrame.
- Explain the dimensionality difference between 2D feature matrices in regression vs 1D text Series in NLP pipelines.
- Verify the data types and array shapes of $X$ and $y$.
- Prepare data cleanly for ingestion into scikit-learn's `train_test_split`.

## 2. Prerequisites
- Completion of Lessons 01-03 of Module 02.
- Understanding of pandas single-bracket `df['col']` vs double-bracket `df[['col']]` indexing.

## 3. Real-World Context & Business Motivation
In standard tabular machine learning (such as predicting house prices or sales from tabular numbers), feature sets ($X$) consist of multi-column numerical matrices of shape `(n_samples, n_features)`. In text classification, however, our raw starting feature is an array of raw prose strings: a one-dimensional sequence of sentences. Scikit-learn's text transformers (like `CountVectorizer`) are specifically engineered to accept a 1D iterable of raw text strings and expand them internally into a 2D document-term matrix. Understanding how to properly separate $X$ and $y$ for NLP pipelines avoids common shape errors.

## 4. Concept Explanation
### Extracting $X$ and $y$ in NLP Pipelines
In `main.py`, features and targets are extracted directly from the DataFrame:
```python
X = df["review"]  # Feature input: 1D Series of strings
y = df["label"]   # Target output: 1D Series of class strings
```
- **$X$ (Feature Variable):** Contains the 80 review strings. Its shape is `(80,)`. Each element is a string containing words, spaces, and punctuation.
- **$y$ (Target Variable):** Contains the 80 ground-truth labels. Its shape is `(80,)`. Each element is either `"fake"` or `"real"`.

### Why 1D Series for Text Features?
Students coming from tabular regression (like our Lemonade Stand project) often ask: *"Why do we use single brackets `df['review']` instead of double brackets `df[['review']]`?"*
- In tabular numeric models (`LinearRegression`), estimators require $X$ to already be a 2D matrix of shape `(n_samples, n_features)`.
- In scikit-learn's text processing pipelines, `CountVectorizer.fit_transform()` expects a **1D iterable of strings** (a Python list or a 1D pandas Series). Passing a 2D DataFrame `df[['review']]` to `CountVectorizer` can trigger deprecation warnings or shape mismatches in older versions.

```text
Tabular Numeric Data:
df[['temperature']] -> 2D DataFrame (shape: 16, 1) -> LinearRegression

NLP Text Data:
df['review'] -> 1D Series of strings (shape: 80,) -> CountVectorizer -> 2D Sparse Matrix -> MultinomialNB
```

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, line 40-42 passes $X$ and $y$ directly into `train_test_split`:
```python
X_train, X_test, y_train, y_test = train_test_split(
    df["review"], df["label"], test_size=0.25, random_state=42, stratify=df["label"]
)
```
- `df["review"]` is passed as the first argument ($X$).
- `df["label"]` is passed as the second argument ($y$).
- The function partitions both 1D Series synchronously into training and testing partitions.

## 6. Worked Example
Let's verify the types and shapes in an interactive script:
```python
import pandas as pd
from pathlib import Path

df = pd.read_csv(Path("data/reviews.csv"))

X = df["review"]
y = df["label"]

print(f"Type of X: {type(X)}")
print(f"Shape of X: {X.shape}")
print(f"X dtype: {X.dtype}")

print(f"\nType of y: {type(y)}")
print(f"Shape of y: {y.shape}")
print(f"y dtype: {y.dtype}")

print(f"\nSample X item: {X.iloc[0]!r}")
print(f"Sample y item: {y.iloc[0]!r}")
```
**Console Output:**
```text
Type of X: <class 'pandas.core.series.Series'>
Shape of X: (80,)
X dtype: object

Type of y: <class 'pandas.core.series.Series'>
Shape of y: (80,)
y dtype: object

Sample X item: 'Absolutely flawless. I cannot believe how good this is. Must buy!'
Sample y item: 'fake'
```

## 7. Step-by-Step Student Instructions
1. Open your terminal in the project directory.
2. In Python, load `reviews.csv`.
3. Assign `X = df['review']` and `y = df['label']`.
4. Confirm `len(X) == len(y) == 80`.
5. Verify that `X[0]` is a string and `y[0]` is a string.

## 8. Expected Output or Observable Behaviour
```text
Verified: X is a 1D Series of 80 review strings.
Verified: y is a 1D Series of 80 class labels.
Data is properly formatted for scikit-learn Pipeline ingestion.
```

## 9. Practical Exercises (with Success Criteria)
- **Task 4.1:** What error or warning occurs if you pass `df[['review']]` (2D) to `CountVectorizer().fit_transform()`?
- **Task 4.2:** Write code to verify that no values in $X$ or $y$ are missing (NaN).
- *Success Criteria:* Identifies that CountVectorizer expects a 1D iterable of strings; checks `X.isna().sum()` and `y.isna().sum()`.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Inverting $X$ and $y$ arguments | Passes labels as features and text as targets | In `train_test_split(X, y)`, features must come first. |
| Forgetting to extract Series from DataFrame | Passing whole `df` causes confusion during pipeline fit | Always cleanly define $X$ as review text and $y$ as labels. |
| Converting text to numbers manually before splitting | Causes data leakage if vocabulary is computed globally | Let the scikit-learn Pipeline handle vectorization after the split. |

## 11. Best Practices and Code Quality
- Keep feature and target extraction clean, explicit, and readable.
- Validate that $X$ contains only string objects before passing to text vectorizers.
- Never fit vectorizers on the full $X$ before splitting into train and test sets.

## 12. Security, Ethics, and Fair AI Considerations
Target labels represent human ground truth judgments. If human labelers exhibit subjective bias—such as labeling reviews written in non-standard English as "fake" regardless of factual content—the target variable $y$ encodes that bias. Verifying label quality and inter-annotator agreement is critical before training.

## 13. Summary and Key Takeaways
In NLP text classification, the input feature $X$ is a 1D Series of raw text strings (`df["review"]`), and the target $y$ is a 1D Series of class labels (`df["label"]`). Scikit-learn pipelines accept this 1D string Series directly, delegating tokenization and vectorization to `CountVectorizer`.

## 14. Knowledge Check Questions
1. What is the shape of `df["review"]` in `main.py`?
2. Why does `CountVectorizer` expect a 1D Series rather than a 2D numerical matrix?
3. What data type does pandas use to represent text strings in DataFrame columns?
4. How does separating $X$ and $y$ prepare data for `train_test_split`?

## 15. References and Further Reading
- McKinney, W. (2022). *Python for Data Analysis (3rd ed.).* O'Reilly Media.
- Scikit-learn documentation: Feature extraction from text documents.
