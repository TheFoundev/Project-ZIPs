# Lesson 01: Loading and Exploring reviews.csv

**Lesson ID:** lesson-01
**Module:** module-02
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Use Python's `pathlib.Path` to construct resilient directory paths.
- Load `reviews.csv` into a pandas DataFrame using `pd.read_csv()`.
- Inspect DataFrame metadata including shape, column headers, and memory usage.
- Explain why dynamic path resolution prevents `FileNotFoundError` across different runtime environments.

## 2. Prerequisites
- Module 01: Project Overview and NLP Foundations.
- Familiarity with basic terminal commands and running Python scripts.

## 3. Real-World Context & Business Motivation
Data engineering begins with reliable data ingestion. In production machine learning pipelines, scripts are executed across heterogeneous environments: local developer laptops, continuous integration (CI) runners, Docker containers, and cloud training clusters. Hardcoded relative string paths (such as `"data/reviews.csv"`) frequently break because they depend on where the user's terminal happens to be focused when executing the command. Robust path handling ensures reproducible ingestion regardless of the execution context.

## 4. Concept Explanation
### The Power of `pathlib.Path`
Python 3 introduced the `pathlib` module, providing an object-oriented approach to filesystem navigation. Rather than manipulating error-prone raw strings with `os.path.join`, `Path` objects allow intuitive path composition using the division (`/`) operator.

In `main.py`:
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
```
- `__file__`: A special Python variable containing the path of the currently executing script.
- `.resolve()`: Resolves any symbolic links and returns the absolute, canonical path.
- `.parent`: Navigates to the directory containing `main.py` (`12_fake_review_spotter/`).
- `DATA = BASE / "data"`: Guarantees that `DATA` always points to the exact `data/` folder sitting alongside `main.py`.

### Tabular Ingestion with Pandas
Pandas is the industry standard for tabular data processing. Calling `pd.read_csv()` parses the comma-separated values file into a two-dimensional DataFrame:
```python
df = pd.read_csv(DATA / "reviews.csv")
```
Once loaded, calling `df.shape` returns a tuple representing `(n_rows, n_columns)`.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 24-28 and line 39 establish data paths and load the dataset:
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)

def main() -> None:
    df = pd.read_csv(DATA / "reviews.csv")
```
- Line 27 ensures the `outputs/` folder exists before any charts or text reports are written. `exist_ok=True` prevents crashes if the folder already exists.
- Line 39 reads the CSV from the anchored `DATA` path.

## 6. Worked Example
Let's inspect `reviews.csv` interactively using Python:
```python
from pathlib import Path
import pandas as pd

DATA = Path("data")
df = pd.read_csv(DATA / "reviews.csv")

print(f"Dataset Dimensions: {df.shape}")
print(f"Column Names: {list(df.columns)}")
print("\nFirst 3 rows:")
print(df.head(3))
```
**Console Output:**
```text
Dataset Dimensions: (80, 2)
Column Names: ['review', 'label']

First 3 rows:
                                              review label
0  Absolutely flawless. I cannot believe how good...  fake
1  WOW WOW WOW. I love it so much. Best seller ev...  fake
2  AMAZING product!!! Best purchase ever. Buy now...  fake
```
The dataset contains exactly 80 rows and 2 columns: `review` (raw string text) and `label` (ground-truth category).

## 7. Step-by-Step Student Instructions
1. Open your terminal in the `12_fake_review_spotter` directory.
2. Launch Python interactive mode by typing `python`.
3. Import pandas and pathlib: `import pandas as pd; from pathlib import Path`.
4. Load the file: `df = pd.read_csv(Path('data/reviews.csv'))`.
5. Check row and column counts: `print(df.shape)`. Confirm it prints `(80, 2)`.
6. Inspect column data types using `print(df.dtypes)`. Both columns will show as `object` (pandas string type).

## 8. Expected Output or Observable Behaviour
```text
(80, 2)
review    object
label     object
dtype: object
```
Confirming that 80 rows are loaded, with no missing values or corrupted rows.

## 9. Practical Exercises (with Success Criteria)
- **Task 1.1:** Write a Python one-liner to verify whether there are any null or missing values in `df`.
- **Task 1.2:** Print the 10th row of `reviews.csv` and state whether it is fake or real.
- *Success Criteria:* Code uses `df.isnull().sum()` showing 0 nulls, and accurately retrieves the 10th row.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Using hardcoded strings like `"data/reviews.csv"` | Fails if the script is invoked from a different directory | Always anchor paths using `Path(__file__).resolve().parent`. |
| Forgetting `exist_ok=True` in `mkdir()` | Crashes with `FileExistsError` on subsequent script runs | `exist_ok=True` ensures safe, idempotent directory creation. |
| Assuming column names are case-insensitive | Pandas column indexing is strictly case-sensitive | `df['Review']` will raise a `KeyError`; use lowercase `'review'`. |

## 11. Best Practices and Code Quality
- Always inspect `.shape` immediately after loading any dataset to confirm expected row and column counts.
- Use `Path` objects consistently throughout the codebase rather than mixing `os.path` and raw strings.
- Check `.info()` to ensure data types match expectations before feeding data into transformers.

## 12. Security, Ethics, and Fair AI Considerations
CSV files downloaded from external or unverified web sources can theoretically contain CSV injection payloads (formula injection starting with `=`, `+`, `-`, `@`). While pandas treats text as inert strings during standard reading, sanitizing raw user inputs is vital when integrating production web forms into ML databases.

## 13. Summary and Key Takeaways
Pathlib provides robust, operating-system-agnostic filesystem path resolution. Loading `reviews.csv` into a pandas DataFrame reveals an 80-row, 2-column table with text reviews and binary authenticity labels ready for NLP feature engineering.

## 14. Knowledge Check Questions
1. Why is `Path(__file__).resolve().parent` preferred over relative string paths?
2. What does `df.shape` return for `reviews.csv`?
3. What are the two columns present in `data/reviews.csv`?
4. What happens if `OUT.mkdir(exist_ok=False)` is executed when `outputs/` already exists?

## 15. References and Further Reading
- Python standard library documentation: `pathlib` — Object-oriented filesystem paths.
- Pandas API reference: `pandas.read_csv`.
