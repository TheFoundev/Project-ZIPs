# Lesson 03: Deep Dive into Review Samples

**Lesson ID:** lesson-03
**Module:** module-02
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Compare specific fake and genuine review strings from `data/reviews.csv`.
- Analyze qualitative linguistic differences in sentence structure and vocabulary.
- Measure descriptive text metrics such as character count, word count, and exclamation mark frequency.
- Identify why specific words (like "works", "support", "best", "wow") appear predominantly in one class.

## 2. Prerequisites
- Completion of Lesson 02: Class Distribution and Balance.
- Basic understanding of Python string methods (`len()`, `.count()`, `.split()`).

## 3. Real-World Context & Business Motivation
Before applying complex machine learning algorithms, skilled data scientists perform qualitative text inspection. Reading raw data builds domain intuition. It allows you to anticipate what features the algorithm will discover and spot potential data quality anomalies (such as duplicate entries, strange formatting, or label errors). Inspecting the authentic reviews in our dataset clarifies exactly why the model later selects words like "support helped" and "wow" as its top distinguishing clues.

## 4. Concept Explanation
### Text Analysis of Fake Reviews
Examining the `fake` rows in `data/reviews.csv`:
```text
Row 0: "Absolutely flawless. I cannot believe how good this is. Must buy!"
Row 1: "WOW WOW WOW. I love it so much. Best seller ever. 10/10."
Row 2: "AMAZING product!!! Best purchase ever. Buy now, you will not regret it!!!"
Row 3: "I am obsessed! Perfect quality, perfect price, perfect everything!"
Row 5: "Five stars! Best product on the market. You need this right now."
```
Notice the consistent stylistic signatures:
- **Repetitive Punctuation:** Triple exclamations (`!!!`) and rating declarations (`10/10`, `Five stars!`).
- **Urgent Imperatives:** *"Buy now"*, *"Must buy"*, *"You need this right now"*.
- **Absence of Specifics:** No mention of what the item actually is, how it operates, or where it was used.

### Text Analysis of Real Reviews
Examining the `real` rows in `data/reviews.csv`:
```text
Row 7:  "Good value for the price. It is not perfect, but it does the job."
Row 10: "Comfortable for short walks. Not sure I would use it for a long hike."
Row 15: "The first unit had a scratch, and the replacement was fine. Mixed experience."
Row 16: "I liked the design, but the instructions were confusing. Customer support helped."
```
Notice the contrasting signatures:
- **Conditional Nuance:** *"Comfortable for short walks, not sure for long hikes"*.
- **Balanced Critiques:** *"Not perfect, but does the job"*, *"Mixed experience"*.
- **Concrete Incidents:** Physical defects (*"scratch"*), vendor interactions (*"replacement was fine"*, *"customer support helped"*), documentation flaws (*"instructions were confusing"*).

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 67-72 define four unseen review strings designed to probe these exact patterns:
```python
new_reviews = [
    "AMAZING!!! Best product ever. Buy it now, you will not regret it!",
    "The item arrived on time. The battery is fine, but the cable is short.",
    "Perfect quality, perfect price, perfect everything. Five stars!",
    "It works as described. Shipping took a week longer than expected.",
]
```
Reviews 1 and 3 echo the hyperbolic astroturfing style, while Reviews 2 and 4 mirror the nuanced, balanced cadence of authentic feedback.

## 6. Worked Example
Let's compute descriptive string metrics comparing fake vs real reviews in Python:
```python
import pandas as pd
from pathlib import Path

df = pd.read_csv(Path("data/reviews.csv"))

df["char_len"] = df["review"].apply(len)
df["word_count"] = df["review"].apply(lambda t: len(t.split()))
df["exclamations"] = df["review"].apply(lambda t: t.count("!"))

summary = df.groupby("label")[["char_len", "word_count", "exclamations"]].mean()
print("Average Metrics by Class:")
print(summary.round(2))
```
**Console Output:**
```text
Average Metrics by Class:
       char_len  word_count  exclamations
label                                    
fake      67.55       11.38          2.35
real      74.20       12.80          0.05
```
**Key Qualitative Insights:**
1. Fake reviews average **2.35 exclamation marks** per review, whereas genuine reviews average only **0.05**!
2. Genuine reviews are slightly longer on average and contain more varied, descriptive vocabulary.

## 7. Step-by-Step Student Instructions
1. Load `reviews.csv` in Python.
2. Filter for fake reviews: `fakes = df[df['label'] == 'fake']['review']`.
3. Filter for real reviews: `reals = df[df['label'] == 'real']['review']`.
4. Print the first 5 reviews of each class side by side.
5. Count how many times the word "perfect" appears in `fakes` versus `reals`.

## 8. Expected Output or Observable Behaviour
```text
"perfect" occurrences in fake reviews: >= 8
"perfect" occurrences in real reviews: 0 (or strictly in negative context "not perfect")
Observation: Word choice strongly correlates with class labels.
```

## 9. Practical Exercises (with Success Criteria)
- **Task 3.1:** Write a Python function that counts how many reviews in each class contain the word "but".
- **Task 3.2:** Explain why the presence of the conjunction "but" is a strong linguistic indicator of genuine reviews.
- *Success Criteria:* Code accurately outputs counts; explanation links "but" to balanced trade-offs.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Assuming word length alone separates classes | Word lengths are often comparable | Semantic choice (superlatives vs trade-offs) is far more informative than character length. |
| Relying solely on exclamation mark counts | Adversaries can simply delete exclamation marks | A robust NLP model must evaluate vocabulary, not just punctuation. |
| Ignoring duplicate reviews in datasets | Review brokers often copy-paste identical text across listings | In real data, duplicate detection is an essential preprocessing step. |

## 11. Best Practices and Code Quality
- Always print random sample rows from each class during exploratory data analysis (EDA).
- Look for domain-specific terminology (e.g., "customer support", "battery", "shipping") that signals genuine user interaction.
- Track punctuation anomalies as potential engineered features for multimodal models.

## 12. Security, Ethics, and Fair AI Considerations
When qualitative data inspection reveals repetitive templates, data scientists must consider whether the dataset was synthetically generated. In `reviews.csv`, several fake reviews repeat identical phrases ("WOW WOW WOW", "Five stars! Best product on the market"). In production, deduplication and template clustering must precede training.

## 13. Summary and Key Takeaways
Qualitative inspection of `data/reviews.csv` demonstrates clear linguistic separation: fake reviews rely on exclamation marks, urgent purchase imperatives, and generic superlatives, while genuine reviews feature concrete customer service interactions and balanced trade-off descriptions.

## 14. Knowledge Check Questions
1. How does exclamation mark usage differ between fake and real reviews in our dataset?
2. What concrete experiences do real reviews in `reviews.csv` describe?
3. Why are urgent imperatives like "Buy now!" rare in authentic customer reviews?
4. What is the benefit of manually reading raw data before training machine learning models?

## 15. References and Further Reading
- Jurafsky, D., & Martin, J. H. (2023). *Speech and Language Processing (3rd ed. draft).* Chapter on Lexical Semantics.
- Pandas documentation: Working with text data.
