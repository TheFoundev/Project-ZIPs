# Lesson 02: Class Distribution and Balance

**Lesson ID:** lesson-02
**Module:** module-02
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Compute class frequencies in pandas using `.value_counts()`.
- Explain why class balance matters in classification tasks.
- Define the "accuracy paradox" and understand its risks in imbalanced datasets.
- Verify that `data/reviews.csv` has a balanced 50/50 class distribution.

## 2. Prerequisites
- Completion of Lesson 01: Loading and Exploring reviews.csv.
- Basic understanding of fractions and percentages.

## 3. Real-World Context & Business Motivation
In commercial e-commerce, fake reviews typically represent a small minority of total submissions—perhaps 2% to 5% of all incoming feedback. If a dataset has 98% real reviews and 2% fake reviews, a naive, completely broken model that simply guesses "real" for every review would achieve an apparently stellar **98% accuracy**. Yet this model has zero business utility: it catches literally zero fraud. Understanding class balance is fundamental to interpreting model metrics accurately.

## 4. Concept Explanation
### Measuring Class Balance with `.value_counts()`
In pandas, the `.value_counts()` method counts the occurrences of unique values within a Series. When applied to the target column `df['label']`, it tallies how many samples belong to each category:
```python
print(df["label"].value_counts())
```
For `reviews.csv`, this produces:
```text
label
fake    40
real    40
Name: count, dtype: int64
```
Both classes have exactly 40 instances, meaning the dataset is **perfectly balanced** ($50\%$ fake, $50\%$ real).

### The Accuracy Paradox Explained
The "Accuracy Paradox" occurs when overall classification accuracy creates a misleading illusion of model competence on imbalanced data:
$$\text{Accuracy} = \frac{\text{Number of Correct Predictions}}{\text{Total Number of Predictions}}$$
- **Scenario A (Balanced 50/50):** If a dummy model predicts "real" for every sample, it gets 40 correct out of 80 $\to$ **50% accuracy** (baseline random guessing). A model achieving 90%+ is clearly learning genuine patterns.
- **Scenario B (Imbalanced 95/5):** If a dummy model predicts "real" for every sample, it gets 95 correct out of 100 $\to$ **95% accuracy**. Accuracy fails to reflect that the model is useless at detecting fraud.

```mermaid
pie title "Dataset Class Distribution (reviews.csv)"
    "fake" : 40
    "real" : 40
```

### Why a Balanced Starter Dataset is Ideal for Learning
By using a curated 50/50 dataset in this educational project, beginners can rely on standard accuracy as an intuitive metric without being tricked by majority-class trivial guessing. Later in Module 05, we will explore precision and recall to prepare for real-world imbalanced scenarios.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, line 41 accounts for class balance during partitioning:
```python
X_train, X_test, y_train, y_test = train_test_split(
    df["review"], df["label"], test_size=0.25, random_state=42, stratify=df["label"]
)
```
Notice the parameter `stratify=df["label"]`. Stratification explicitly enforces that both the 60-sample training set and 20-sample test set preserve the exact 50/50 ratio:
- `y_train`: 30 fake, 30 real (50% each)
- `y_test`: 10 fake, 10 real (50% each)

## 6. Worked Example
Let's compute the normalized proportion of each class in Python:
```python
import pandas as pd
from pathlib import Path

df = pd.read_csv(Path("data/reviews.csv"))
counts = df["label"].value_counts()
proportions = df["label"].value_counts(normalize=True)

print("Absolute counts:")
print(counts)
print("\nNormalized proportions:")
print(proportions.apply(lambda p: f"{p:.1%}"))
```
**Console Output:**
```text
Absolute counts:
label
fake    40
real    40
Name: count, dtype: int64

Normalized proportions:
label
fake    50.0%
real    50.0%
Name: proportion, dtype: object
```

## 7. Step-by-Step Student Instructions
1. In your Python session, load `reviews.csv`.
2. Run `df['label'].value_counts()`.
3. Check the ratio: verify that fake = 40 and real = 40.
4. Calculate baseline guessing accuracy: if an algorithm randomly flipped a fair coin, what accuracy would it achieve on average? (Answer: 50.0%).

## 8. Expected Output or Observable Behaviour
```text
Class counts:
fake: 40 (50.0%)
real: 40 (50.0%)
Random baseline accuracy: 50.0%
```

## 9. Practical Exercises (with Success Criteria)
- **Task 2.1:** Calculate what accuracy a dummy majority classifier would achieve on a dataset containing 92 real reviews and 8 fake reviews.
- **Task 2.2:** Explain why accuracy alone is insufficient to evaluate fraud detection in real-world production systems.
- *Success Criteria:* Identifies 92% dummy accuracy and cites the failure to catch the 8 fraudulent instances.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Trusting 95% accuracy without checking class balance | Can mask a completely broken model in imbalanced datasets | Always check `.value_counts()` before evaluating accuracy. |
| Forgetting `stratify=df['label']` | Random splits can result in skewed test sets | Stratification guarantees identical class proportions across splits. |
| Assuming 50/50 datasets exist naturally in production | Real production fraud datasets are heavily skewed (~1-5% spam) | Curated 50/50 datasets are pedagogical benchmarks for learning. |

## 11. Best Practices and Code Quality
- Use `df['label'].value_counts(normalize=True)` to quickly inspect percentage distributions.
- When working with imbalanced datasets in production, evaluate using Precision, Recall, and PR-AUC rather than raw accuracy.
- Always stratify data splits whenever class counts are small or imbalanced.

## 12. Security, Ethics, and Fair AI Considerations
In real-world fraud detection, models trained on artificially balanced datasets may suffer from "prior probability shift" when deployed against wild data where fakes are rare. Production systems adjust decision thresholds or use Bayesian priors reflecting actual platform prevalence rates.

## 13. Summary and Key Takeaways
`data/reviews.csv` contains an exact 50/50 balance between 40 fake and 40 real reviews. Balanced datasets establish a clean 50% random guessing baseline and ensure that high test accuracy reflects genuine pattern learning rather than majority-class bias.

## 14. Knowledge Check Questions
1. How many fake reviews and real reviews are in `reviews.csv`?
2. What does `df['label'].value_counts(normalize=True)` calculate?
3. What is the accuracy paradox?
4. Why is `stratify=df['label']` used when splitting the dataset?

## 15. References and Further Reading
- He, H., & Garcia, E. A. (2009). *Learning from Imbalanced Data.* IEEE Transactions on Knowledge and Data Engineering, 21(9), 1263-1284.
- Scikit-learn documentation: Model selection and stratified sampling.
