# Module 2 Exercises: Data Exploration & Text Analysis

## Exercise 2.1: Dataset Schema & Dimension Verification (10 min)
**Objective:** Load `reviews.csv` with pandas and verify structural dimensions and nullity.
**Problem Statement:** Write an automated data inspection script that loads `data/reviews.csv`, confirms the expected dimensions and schema, and checks for data integrity issues.

**Requirements:**
1. Use `pathlib.Path` to construct the dataset path dynamically.
2. Load the CSV into a pandas DataFrame.
3. Assert that the DataFrame contains exactly 80 rows and 2 columns.
4. Verify that column headers are exactly `['review', 'label']`.
5. Confirm that there are zero missing (`NaN`) values in either column.

**Constraints:** Run actual Python code in your environment.

**Expected Behaviour:** A Python script that executes without assertion errors and prints a summary.

**Acceptance Criteria:**
- [ ] Code uses `Path(__file__).resolve().parent / "data" / "reviews.csv"` or equivalent.
- [ ] Uses `assert df.shape == (80, 2)`.
- [ ] Checks `assert df.isnull().sum().sum() == 0`.
- [ ] Prints confirmation message.

**Hints:**
- Use `df.isna().sum()` to check missing values per column.
- Use `list(df.columns)` to inspect headers.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes

---

## Exercise 2.2: Class Balance & Stratification Audit (15 min)
**Objective:** Compute class balance and verify that stratified splitting preserves class proportions.
**Problem Statement:** Demonstrate the mathematical behavior of stratified data partitioning on `data/reviews.csv`.

**Requirements:**
1. Compute the class frequencies and normalized percentages of `df['label']`.
2. Perform a train/test split with `test_size=0.25`, `random_state=42`, and `stratify=df['label']`.
3. Compute the class counts in `y_train` (should be 30 fake, 30 real).
4. Compute the class counts in `y_test` (should be 10 fake, 10 real).
5. Explain what would happen to `y_test` if `stratify` were omitted with an unlucky random seed.

**Constraints:** Use `train_test_split` from `sklearn.model_selection`.

**Expected Behaviour:** Printed tables showing exact 50/50 balance in original, train, and test partitions.

**Acceptance Criteria:**
- [ ] Original distribution verified as 40 fake / 40 real.
- [ ] `y_train` confirmed as 30 fake / 30 real.
- [ ] `y_test` confirmed as 10 fake / 10 real.
- [ ] Explains that unstratified splits on small datasets can create skewed test sets.

**Hints:**
- Check `y_train.value_counts()` and `y_test.value_counts()`.
- $80 \times 0.75 = 60$; $80 \times 0.25 = 20$.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 2.3: Quantitative Text Feature Profiling (15 min)
**Objective:** Engineer descriptive linguistic metrics to measure stylistic differences between classes.
**Problem Statement:** Write a script that calculates text length metrics and punctuation frequencies for all reviews in `data/reviews.csv`, grouped by class label.

**Requirements:**
1. Add a column `char_length` calculating the character count of each review.
2. Add a column `word_count` calculating the number of whitespace-delimited words.
3. Add a column `exclamation_count` calculating the number of `'!'` characters.
4. Calculate the mean of each metric grouped by `label` (`fake` vs `real`).
5. State which metric shows the largest relative percentage difference between classes.

**Constraints:** Use pandas vectorization or `.apply()`.

**Expected Behaviour:** A formatted table displaying average metrics for fake and real reviews.

**Acceptance Criteria:**
- [ ] Computes mean character length for both classes.
- [ ] Computes mean word count for both classes.
- [ ] Computes mean exclamation mark count for both classes.
- [ ] Identifies that exclamation marks are dramatically higher in fake reviews (~2.35 vs ~0.05).

**Hints:**
- Use `df['review'].str.len()` for character length.
- Use `df['review'].str.count('!')` for exclamation count.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 2.4: Qualitative Linguistic Comparison Matrix (15 min)
**Objective:** Conduct an in-depth qualitative comparison of real reviews versus fake reviews.
**Problem Statement:** Select 3 fake reviews and 3 real reviews from `data/reviews.csv`. Build a qualitative comparison matrix analyzing their vocabulary, emotional valence, and factual specificity.

**Requirements:**
1. Present the 6 selected reviews verbatim with their row index numbers.
2. For each review, identify:
   - Primary adjectives used.
   - Presence of concrete product nouns (e.g., "battery", "cable", "instructions").
   - Emotional tone (hyperbolic vs measured).
3. Synthesize your findings: why is vocabulary choice alone sufficient for an algorithm to separate these two classes?

**Constraints:** Cite reviews directly from `data/reviews.csv`.

**Expected Behaviour:** A markdown comparison table followed by a synthesized conclusion.

**Acceptance Criteria:**
- [ ] Quotes 3 authentic rows labeled 'fake' and 3 authentic rows labeled 'real'.
- [ ] Accurately categorizes adjectives and concrete nouns.
- [ ] Concludes that fake reviews rely on content-free superlatives while real reviews describe tangible product experiences.

**Hints:**
- Look at rows 0, 1, 2 for fake reviews.
- Look at rows 7, 10, 15 for real reviews.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes
