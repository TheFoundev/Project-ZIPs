# Module 3 Exercises: CountVectorizer & Text Preprocessing

## Exercise 3.1: Manual Bag-of-Words Vectorization (10 min)
**Objective:** Construct a document-term count matrix by hand to master Bag-of-Words mechanics.
**Problem Statement:** You are given a miniature corpus of three customer reviews:
- Review 0: *"Great product, works great."*
- Review 1: *"Shipping delayed, customer support helped."*
- Review 2: *"Great customer support, fast shipping."*

**Requirements:**
1. Manually tokenize the text: convert to lowercase and strip punctuation.
2. Build the sorted unique vocabulary list.
3. Construct the resulting 3-row Document-Term Matrix.
4. State the matrix dimensions `(n_documents, n_vocabulary_terms)`.

**Constraints:** Perform the calculations manually, then verify using Python.

**Expected Behaviour:** A written vocabulary list and a complete 2D integer grid.

**Acceptance Criteria:**
- [ ] Correctly tokenizes words without punctuation.
- [ ] Vocabulary is sorted alphabetically.
- [ ] Matrix row 0 shows count of 2 for "great".
- [ ] Matrix dimensions correctly identified as (3, 8).

**Hints:**
- Vocabulary: `['customer', 'delayed', 'fast', 'great', 'helped', 'product', 'shipping', 'support', 'works']`.
- Count how many times each word appears in each sentence.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes

---

## Exercise 3.2: Evaluating English Stop Words Filtering (15 min)
**Objective:** Measure vocabulary reduction and feature quality when enabling `stop_words="english"`.
**Problem Statement:** Write a Python script that loads `data/reviews.csv`, fits `CountVectorizer` twice (once with `stop_words=None` and once with `stop_words="english"`), and compares the resulting vocabularies.

**Requirements:**
1. Load `df = pd.read_csv("data/reviews.csv")`.
2. Fit `vec_unfiltered = CountVectorizer()`. Record vocabulary length.
3. Fit `vec_filtered = CountVectorizer(stop_words="english")`. Record vocabulary length.
4. Calculate the percentage reduction in vocabulary size.
5. Print 10 words present in `vec_unfiltered` that were successfully removed by `vec_filtered`.

**Constraints:** Run actual Python code on the project dataset.

**Expected Behaviour:** Printed statistics showing vocabulary shrinkage and filtered terms.

**Acceptance Criteria:**
- [ ] Calculates raw vocabulary size (~180-220 unigrams).
- [ ] Calculates filtered vocabulary size.
- [ ] Computes percentage reduction.
- [ ] Shows filtered stop words (e.g., "the", "and", "is", "it", "to", "for").

**Hints:**
- Use `set(vec_unfiltered.vocabulary_.keys()) - set(vec_filtered.vocabulary_.keys())` to see what was dropped.
- Vocabulary sizes depend on the 80 reviews in `reviews.csv`.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 3.3: Bigram Feature Extraction & Phrase Analysis (15 min)
**Objective:** Analyze the impact of `ngram_range=(1, 2)` on vocabulary breadth and phrase discovery.
**Problem Statement:** Write a Python script to compare unigram-only extraction against unigram + bigram extraction on `data/reviews.csv`.

**Requirements:**
1. Instantiate `vec_unigram = CountVectorizer(stop_words="english", ngram_range=(1, 1))`.
2. Instantiate `vec_bigram = CountVectorizer(stop_words="english", ngram_range=(1, 2))`.
3. Fit both on `df["review"]`.
4. Report the vocabulary size of both vectorizers.
5. Extract and print all bigrams (features containing a space `' '`) that occur at least twice across the dataset.

**Constraints:** Use `ngram_range` parameter in `CountVectorizer`.

**Expected Behaviour:** A list of repeated bigrams showing informative collocations.

**Acceptance Criteria:**
- [ ] Reports unigram vocabulary size.
- [ ] Reports bigram vocabulary size (will be substantially larger).
- [ ] Surfaces key phrases like "customer support", "wow wow", "five stars", "best product".
- [ ] Explains how these phrases aid classification.

**Hints:**
- Filter bigrams using: `[f for f in vec_bigram.get_feature_names_out() if " " in f]`.
- Check counts using the document-term matrix column sums.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 3.4: Sparse Matrix Inspection & Memory Efficiency (15 min)
**Objective:** Understand the internal data structure of scikit-learn's document-term matrix.
**Problem Statement:** In large NLP systems, document-term matrices are stored as scipy sparse matrices. Investigate the sparsity of the vectorized review data.

**Requirements:**
1. Vectorize `df["review"]` using `CountVectorizer(stop_words="english", ngram_range=(1, 2))`.
2. Print the type of the returned object (should be `scipy.sparse._csr.csr_matrix` or `csr_matrix`).
3. Calculate the total number of cells in the dense matrix: $\text{rows} \times \text{cols}$.
4. Calculate the number of non-zero elements using `.nnz`.
5. Calculate the matrix **sparsity percentage**: $(1 - \frac{\text{non-zero cells}}{\text{total cells}}) \times 100\%$.

**Constraints:** Use `scipy.sparse` methods on the vectorizer output.

**Expected Behaviour:** Printed sparsity calculation showing >95% sparsity.

**Acceptance Criteria:**
- [ ] Correctly identifies Compressed Sparse Row (`csr_matrix`) type.
- [ ] Computes total possible matrix elements.
- [ ] Retrieves `.nnz` (number of stored non-zero values).
- [ ] Demonstrates that the matrix is over 95% zeros, proving the necessity of sparse storage.

**Hints:**
- `X_counts.shape[0] * X_counts.shape[1]` gives total elements.
- `X_counts.nnz` gives non-zero count.

**Difficulty:** Advanced  
**Estimated Completion Time:** 15 minutes
