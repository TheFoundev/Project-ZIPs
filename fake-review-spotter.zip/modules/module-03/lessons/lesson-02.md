# Lesson 02: Tokenization and Vocabulary Building

**Lesson ID:** lesson-02
**Module:** module-03
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain the mechanics of tokenization in `CountVectorizer`.
- Describe how scikit-learn builds and indexes its internal `vocabulary_` mapping.
- Understand the role of case-folding (`lowercase=True`) in collapsing vocabulary variants.
- Inspect vocabulary features using `.get_feature_names_out()`.

## 2. Prerequisites
- Completion of Lesson 01: The Bag-of-Words Representation.
- Basic familiarity with regular expressions (regex word boundaries).

## 3. Real-World Context & Business Motivation
Human language is messy. Customers write in all-caps when excited (*"AMAZING"*), capitalize the start of sentences (*"Amazing"*), or use standard lowercase (*"amazing"*). They attach commas, periods, and exclamation marks directly to words (*"quality, price, everything!"*). If an NLP engine treated each typographical variation as a completely separate concept, the vocabulary would explode in size, diluting statistical evidence across dozens of redundant features. Automated tokenization and normalization standardize text into clean, comparable tokens.

## 4. Concept Explanation
### The Tokenization Workflow
When `CountVectorizer.fit()` or `fit_transform()` is called on a collection of reviews, it executes a three-stage pipeline:
1. **Case Normalization (Lowercasing):** By default (`lowercase=True`), all characters are converted to lowercase.
2. **Regex Tokenization:** Words are extracted using the default regular expression `token_pattern=r"(?u)\b\w\w+\b"`:
   - `\b`: Word boundary.
   - `\w\w+`: Two or more alphanumeric characters (words of 1 letter like "a" or "I" are dropped by default).
   - All punctuation marks (`.`, `!`, `?`, `,`) are stripped away as token delimiters.
3. **Vocabulary Indexing:** The vectorizer compiles a sorted set of all unique tokens across the entire corpus. Each token is assigned a unique column index ($0, 1, 2, \dots, V-1$).

```mermaid
flowchart LR
    A["Raw String: 'AMAZING product!!!'"] --> B["Lowercasing: 'amazing product!!!'"]
    B --> C["Regex Tokenizer: ['amazing', 'product']"]
    C --> D["Vocabulary Lookup: amazing -> 0, product -> 1"]
    D --> E["Count Vector: [1, 1]"]
```

### Inspecting `vocabulary_` vs `get_feature_names_out()`
Scikit-learn provides two complementary inspection interfaces:
- `vectorizer.vocabulary_`: A Python dictionary mapping each word string to its corresponding integer column index (e.g., `{'amazing': 0, 'product': 1}`).
- `vectorizer.get_feature_names_out()`: An array of strings where array position $j$ contains the exact word mapped to column index $j$.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, line 33 accesses feature names inside the `top_words` function:
```python
def top_words(model: Pipeline, class_index: int, n: int = 10) -> list[str]:
    vectorizer = model.named_steps["vectorizer"]
    classifier = model.named_steps["classifier"]
    names = vectorizer.get_feature_names_out()
    ...
```
- `model.named_steps["vectorizer"]` retrieves the fitted `CountVectorizer` instance from the pipeline.
- `vectorizer.get_feature_names_out()` retrieves the full array of vocabulary terms matching the columns of the model's weight matrices.

## 6. Worked Example
Let's inspect how `CountVectorizer` tokenizes a realistic fake review string:
```python
from sklearn.feature_extraction.text import CountVectorizer

sample_text = ["AMAZING product!!! Best purchase ever. 10/10."]

vec = CountVectorizer()
vec.fit(sample_text)

print("Vocabulary Dictionary (word -> column index):")
print(vec.vocabulary_)

print("\nFeature Names Array (ordered by column index):")
print(vec.get_feature_names_out())
```
**Console Output:**
```text
Vocabulary Dictionary (word -> column index):
{'amazing': 0, 'product': 5, 'best': 1, 'purchase': 6, 'ever': 3, '10': 2}

Feature Names Array (ordered by column index):
['amazing' 'best' '10' 'ever' 'product' 'purchase']
```
Notice:
1. `"AMAZING"` became lowercase `'amazing'`.
2. `"!!!"`, `"."`, and `"/"` were stripped completely.
3. `'10'` was retained because it contains two alphanumeric characters.

## 7. Step-by-Step Student Instructions
1. In Python, import `CountVectorizer` from `sklearn.feature_extraction.text`.
2. Create a list with two reviews: `["I loved it!", "Loved it, 5 stars."]`.
3. Fit the vectorizer: `cv = CountVectorizer().fit(reviews)`.
4. Print `cv.vocabulary_`.
5. Observe that `"loved"` appears only once in the vocabulary, successfully merging `"loved"` and `"Loved"`.

## 8. Expected Output or Observable Behaviour
```text
Vocabulary: {'loved': 2, 'it': 1, 'stars': 3}
Note: 'I' and '5' were dropped because default token_pattern requires >= 2 characters.
```

## 9. Practical Exercises (with Success Criteria)
- **Task 2.1:** Why did the default vectorizer drop single-letter words like "I" and "a"?
- **Task 2.2:** How would you modify `token_pattern` if you wanted to capture single-character words?
- *Success Criteria:* Cites `token_pattern=r"(?u)\b\w+\b"` allowing 1 or more characters.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Modifying `vocabulary_` directly | Corrupts internal scikit-learn state | Treat `vocabulary_` as read-only; configure parameters during initialization. |
| Forgetting case normalization | Causes vocabulary fragmentation | Leave `lowercase=True` enabled unless case conveys critical meaning (rare in BoW). |
| Expecting emojis to be captured | Default regex strips non-alphanumeric symbols | Capturing emojis requires custom token patterns or specialized tokenizers. |

## 11. Best Practices and Code Quality
- Use `get_feature_names_out()` rather than the deprecated `get_feature_names()`.
- Access transformers through `pipeline.named_steps["vectorizer"]` for clean, decoupled code.
- Always verify vocabulary size to prevent out-of-memory errors on large corpora.

## 12. Security, Ethics, and Fair AI Considerations
Regex tokenizers designed for English can fail when applied to languages without whitespace word boundaries (such as Chinese, Japanese, or Thai) or languages with complex morphology (such as Arabic or Turkish). Multilingual deployments require language-specific morphological tokenizers (e.g., Jieba, MeCab, or SentencePiece).

## 13. Summary and Key Takeaways
`CountVectorizer` normalizes text to lowercase, applies regex tokenization to isolate alphanumeric words, strips punctuation, and builds an indexed vocabulary dictionary. Feature names can be inspected using `get_feature_names_out()`, linking column indices to human-readable words.

## 14. Knowledge Check Questions
1. What regular expression does `CountVectorizer` use by default for token extraction?
2. What is the difference between `vocabulary_` and `get_feature_names_out()`?
3. Why are single-character words dropped by default?
4. How does lowercasing prevent vocabulary fragmentation?

## 15. References and Further Reading
- Python `re` module documentation: Regular expression syntax.
- Scikit-learn API: `sklearn.feature_extraction.text.CountVectorizer`.
