# Lesson 01: The Bag-of-Words (BoW) Representation

**Lesson ID:** lesson-01
**Module:** module-03
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why machine learning models require numerical vector representations of text.
- Define the Bag-of-Words (BoW) model and its core structural simplifications.
- Describe how a document-term matrix is constructed from a corpus of sentences.
- Identify the trade-offs of discarding sentence syntax, word order, and grammar.

## 2. Prerequisites
- Module 02: Data and Text Exploration.
- Understanding of 2D matrices (rows, columns, cell values).

## 3. Real-World Context & Business Motivation
Computers cannot directly compute mathematical gradients, log-likelihood ratios, or distance metrics on raw strings of English prose. A machine learning algorithm like Naive Bayes requires structured numeric inputs: tensors, vectors, or matrices. To bridge this gap, natural language processing uses vectorization algorithms to map human language into high-dimensional vector spaces. The Bag-of-Words model is the foundational representation that powers classical search engines, spam filters, and document classifiers across the technology industry.

## 4. Concept Explanation
### The Bag-of-Words Mental Model
Imagine taking a written review, cutting every word out with scissors, and tossing all the words into a physical bag. When you shake the bag:
- **What is preserved:** The identity of each word and how many times it was dropped into the bag (word frequency).
- **What is discarded:** The sequential order of the words, grammar, sentence structure, and punctuation.

```text
Review: "Best product ever. Buy product now."
         |
         v
Bag contains:
- "product": 2
- "best": 1
- "ever": 1
- "buy": 1
- "now": 1
```

### The Document-Term Matrix
When applying Bag-of-Words across an entire dataset (corpus), we construct a **Document-Term Matrix**:
- **Rows ($i$):** Each row corresponds to a single document (review).
- **Columns ($j$):** Each column corresponds to a unique word in the collective vocabulary.
- **Cell Value ($M_{i,j}$):** The number of times vocabulary word $j$ appears in review $i$.

```text
Corpus:
Doc 0: "great battery"
Doc 1: "battery fine cable short"

Vocabulary: ['battery', 'cable', 'fine', 'great', 'short']

Document-Term Matrix:
        battery  cable  fine  great  short
Doc 0:     1       0      0     1      0
Doc 1:     1       1      1     0      1
```

### Why BoW Works for Fake Review Detection
Even though word order is lost, fraudulent reviews betray themselves primarily through **vocabulary choice** (e.g., "amazing", "wow", "flawless", "buy now"). Knowing that the word "flawless" appears twice is overwhelmingly informative, regardless of whether it appeared at the beginning or end of the paragraph.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, line 18 and lines 44-49 instantiate the vectorizer inside the pipeline:
```python
from sklearn.feature_extraction.text import CountVectorizer

model = Pipeline(
    [
        ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
        ("classifier", MultinomialNB()),
    ]
)
```
`CountVectorizer` is scikit-learn's implementation of the Bag-of-Words transformation. It ingests the raw review strings and produces the document-term count matrix.

## 6. Worked Example
Let's build a small Bag-of-Words matrix by hand in Python:
```python
from sklearn.feature_extraction.text import CountVectorizer

corpus = [
    "Amazing product buy now",
    "Product works well but shipping delayed",
    "Amazing quality amazing price"
]

vectorizer = CountVectorizer()
X_counts = vectorizer.fit_transform(corpus)

vocab = vectorizer.get_feature_names_out()
print("Learned Vocabulary:", list(vocab))
print("\nDocument-Term Matrix (Dense array):")
print(X_counts.toarray())
```
**Console Output:**
```text
Learned Vocabulary: ['amazing', 'but', 'buy', 'delayed', 'now', 'price', 'product', 'quality', 'shipping', 'well', 'works']

Document-Term Matrix (Dense array):
[[1 0 1 0 1 0 1 0 0 0 0]
 [0 1 0 1 0 0 1 0 1 1 1]
 [2 0 0 0 0 1 0 1 0 0 0]]
```
Notice how Doc 2 has a value of `2` under column `'amazing'` because the word appeared twice.

## 7. Step-by-Step Student Instructions
1. Review the worked example matrix above.
2. Locate the column index for `'product'`.
3. Verify which documents contained `'product'` (Doc 0 and Doc 1).
4. Explain why Doc 2 has a `0` under `'product'` even though it is about product quality.

## 8. Expected Output or Observable Behaviour
```text
Vocabulary length: 11 terms
Matrix shape: (3 documents, 11 features)
Feature representation: Non-negative integers counting occurrences.
```

## 9. Practical Exercises (with Success Criteria)
- **Task 1.1:** State two pieces of linguistic information discarded by Bag-of-Words.
- **Task 1.2:** Can a Bag-of-Words model distinguish "not bad, very good" from "not good, very bad"? Explain why or why not.
- *Success Criteria:* Identifies that identical word counts in both phrases make them indistinguishable under basic unigram BoW.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Assuming BoW understands negation | "not good" and "good not" yield identical word counts | Unigram BoW loses negation context; n-grams help resolve this. |
| Storing large BoW matrices as dense arrays | Consumes massive RAM when vocabulary reaches tens of thousands | Keep matrices in scipy sparse format (`csr_matrix`). |
| Expecting punctuation in vocabulary | CountVectorizer strips punctuation by default | Punctuation tokens are ignored under default token regex patterns. |

## 11. Best Practices and Code Quality
- Let `CountVectorizer` handle lowercasing, tokenization, and matrix formatting within a pipeline.
- Inspect `vectorizer.get_feature_names_out()` to audit vocabulary quality.
- Use sparse matrices (`X.toarray()` only for small debugging prints).

## 12. Security, Ethics, and Fair AI Considerations
Bag-of-Words representations treat all vocabulary tokens independently. If legitimate cultural idioms or regional slang appear in the vocabulary, the model scores them strictly by training frequency, which can lead to disparate misclassification rates if training data lacks demographic diversity.

## 13. Summary and Key Takeaways
The Bag-of-Words model converts text documents into numerical vectors by counting word occurrences against a fixed vocabulary. While it discards syntax and word order, word frequency signatures provide powerful signals for separating hyperbolic fake reviews from authentic customer critiques.

## 14. Knowledge Check Questions
1. Why must raw text be converted to numbers before training Naive Bayes?
2. What do the rows and columns represent in a Document-Term Matrix?
3. What happens to word order in the Bag-of-Words representation?
4. Why is unigram BoW unable to distinguish "not good" from "good not"?

## 15. References and Further Reading
- Harris, Z. S. (1954). *Distributional Structure.* Word, 10(2-3), 146-162.
- Scikit-learn documentation: Vectorizing text documents.
