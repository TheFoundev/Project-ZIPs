# Lesson 04: Bigrams and N-Gram Ranges

**Lesson ID:** lesson-04
**Module:** module-03
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define unigrams, bigrams, and trigrams in natural language processing.
- Configure `ngram_range=(1, 2)` in scikit-learn's `CountVectorizer`.
- Explain how bigrams capture multi-word phrases and contextual collocations.
- Analyze why bigrams like "customer support" and "wow wow" provide decisive signals for fake review spotters.

## 2. Prerequisites
- Completion of Lesson 03: Stop Words Removal.
- Basic understanding of word sequences.

## 3. Real-World Context & Business Motivation
Single words (unigrams) are informative, but they can be ambiguous. The word *"support"* could refer to an arch-support shoe insole, emotional support, or a technical support department. However, the two-word sequence (bigram) **"customer support"** carries an unmistakable, unambiguous meaning: a post-purchase service interaction. Similarly, the repetitive bigram **"wow wow"** or phrase **"best seller"** captures marketing hyperbole that single words alone cannot fully convey. By expanding our feature extractor to include both unigrams and bigrams, we empower the classifier to learn phrase-level signatures of fraud and authenticity.

## 4. Concept Explanation
### What is an N-Gram?
An **n-gram** is a contiguous sequence of $n$ items (typically words) extracted from a text:
- **Unigram ($n=1$):** Single words $\to$ `"customer"`, `"support"`, `"best"`.
- **Bigram ($n=2$):** Adjacent pairs $\to$ `"customer support"`, `"best seller"`, `"wow wow"`.
- **Trigram ($n=3$):** Triplet sequences $\to$ `"best seller ever"`, `"replacement was fine"`.

### Configuring `ngram_range`
In `CountVectorizer`, the `ngram_range` parameter accepts a tuple `(min_n, max_n)`:
- `ngram_range=(1, 1)`: Unigrams only (default behavior).
- `ngram_range=(1, 2)`: Both unigrams AND bigrams.
- `ngram_range=(2, 2)`: Bigrams only.

```text
Sentence: "Customer support helped"
With ngram_range=(1, 2):
Unigrams: ["customer", "support", "helped"]
Bigrams:  ["customer support", "support helped"]
Total features extracted: 5 features
```

### The Synergy of Stop Words and Bigrams
When `stop_words="english"` is combined with `ngram_range=(1, 2)`:
1. Stop words are filtered out first.
2. Bigrams are formed from the remaining consecutive content words.
3. This prevents meaningless stop-word bigrams like *"of the"* and *"in a"*, producing rich collocations like *"liked design"* and *"stars best"*.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, line 46 configures the exact n-gram range:
```python
model = Pipeline(
    [
        ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
        ("classifier", MultinomialNB()),
    ]
)
```
And lines 64-65 show how bigrams surface as top clues in the final model:
```text
Top 'fake' clues: best, wow, stars, wow wow, 10, buy, right, stars best, market, need
Top 'real' clues: liked, works, support helped, support, instructions, liked design, instructions confusing, helped, customer, customer support
```
Notice how many of the top clues are bigrams:
- Fake clues: `'wow wow'`, `'stars best'`
- Real clues: `'support helped'`, `'liked design'`, `'instructions confusing'`, `'customer support'`
Without `ngram_range=(1, 2)`, none of these multi-word collocations would exist!

## 6. Worked Example
Let's see how `ngram_range=(1, 2)` extracts features from a real review:
```python
from sklearn.feature_extraction.text import CountVectorizer

review = ["I liked the design, but the instructions were confusing. Customer support helped."]

vec = CountVectorizer(stop_words="english", ngram_range=(1, 2))
vec.fit(review)

print(f"Total features extracted: {len(vec.get_feature_names_out())}")
print("\nExtracted Unigrams and Bigrams:")
for feature in sorted(vec.get_feature_names_out()):
    print(f" - {feature}")
```
**Console Output:**
```text
Total features extracted: 9

Extracted Unigrams and Bigrams:
 - confusing
 - customer
 - customer support
 - design
 - helped
 - instructions
 - instructions confusing
 - liked
 - support helped
```
The vectorizer extracted 5 unigrams and 4 highly descriptive bigrams!

## 7. Step-by-Step Student Instructions
1. In Python, create a short string: `"Best product ever. Five stars!"`.
2. Extract unigrams only: `cv1 = CountVectorizer(ngram_range=(1,1)).fit([text])`. Count features.
3. Extract unigrams + bigrams: `cv2 = CountVectorizer(ngram_range=(1,2)).fit([text])`. Count features.
4. Verify that `cv2` extracts both individual words and adjacent word pairs.

## 8. Expected Output or Observable Behaviour
```text
cv1 feature count: 5 features
cv2 feature count: 9 features
cv2 vocabulary includes: 'best', 'product', 'best product', 'five', 'stars', 'five stars'
```

## 9. Practical Exercises (with Success Criteria)
- **Task 4.1:** Why would setting `ngram_range=(1, 10)` on a large corpus cause memory issues?
- **Task 4.2:** Identify two bigrams in `data/reviews.csv` that indicate an honest customer review.
- *Success Criteria:* Cites exponential feature explosion; identifies "customer support", "instructions confusing", or "short walks".

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Setting `ngram_range=(2, 1)` | Invalid tuple where min > max | `min_n` must always be $\\le \\text{max\_n}$ (e.g., `(1, 2)`). |
| Using high n-gram ranges (e.g., $n=5$) | Causes feature sparsity and memory bloat | Bigrams ($n=2$) capture 90% of practical phrase value with minimal overhead. |
| Forgetting that bigrams increase matrix width | Increases the number of columns in the document-term matrix | Ensure adequate RAM and use sparse matrices when scaling up. |

## 11. Best Practices and Code Quality
- For sentiment analysis and review classification, `ngram_range=(1, 2)` is the industry sweet spot between context capture and feature dimensionality.
- Always combine n-grams with stop word removal to prevent flooding the vocabulary with junk bigrams.
- Use `min_df=2` on large real-world corpora to prune bigrams that only occur once.

## 12. Security, Ethics, and Fair AI Considerations
Adversarial spammers can craft reviews that deliberately string together deceptive bigrams to mimic legitimate customer service inquiries. Feature engineering alone cannot eliminate fraud; defense-in-depth requires analyzing account creation dates and purchase verification.

## 13. Summary and Key Takeaways
Configuring `ngram_range=(1, 2)` instructs `CountVectorizer` to extract both unigrams and bigrams. In fake review detection, bigrams capture critical contextual phrases—such as "customer support" for authentic reviews and "wow wow" for astroturfing—significantly boosting the model's discriminative power.

## 14. Knowledge Check Questions
1. What does the parameter `ngram_range=(1, 2)` specify?
2. What is the difference between a unigram and a bigram?
3. Name two bigrams from `main.py` that served as top clues for real reviews.
4. Why is `ngram_range=(1, 2)` preferred over unigrams alone in text classification?

## 15. References and Further Reading
- Manning, C. D., Raghavan, P., & Schütze, H. (2008). *Introduction to Information Retrieval.* Cambridge University Press. Chapter on Text Classification.
- Scikit-learn API: `CountVectorizer` n-gram options.
