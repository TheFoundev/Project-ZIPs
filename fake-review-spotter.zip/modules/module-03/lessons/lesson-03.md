# Lesson 03: Stop Words Removal

**Lesson ID:** lesson-03
**Module:** module-03
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define what stop words are in natural language processing.
- Explain why common function words add noise and dimensionality to text models.
- Configure `stop_words="english"` in scikit-learn's `CountVectorizer`.
- Analyze the impact of stop word filtering on vocabulary size and classifier focus.

## 2. Prerequisites
- Completion of Lesson 02: Tokenization and Vocabulary Building.
- Basic understanding of English grammar (articles, prepositions, auxiliary verbs).

## 3. Real-World Context & Business Motivation
In the English language, a tiny handful of grammatical functional words—such as *"the"*, *"is"*, *"at"*, *"which"*, and *"on"*—account for over 30% of all words spoken and written. These words are essential for human syntax, but in a Bag-of-Words classification model, they carry virtually zero discriminative signal. An authentic review says: *"The item arrived on time"*; a fake review says: *"This is the best item on the market"*. Both heavily feature *"the"*, *"is"*, and *"on"*. Removing these non-informative words shrinks vocabulary dimensions, saves memory, and directs the model's attention toward content-bearing words.

## 4. Concept Explanation
### What are Stop Words?
Stop words are high-frequency grammatical words that appear ubiquitously across all types of documents regardless of topic, sentiment, or authenticity. 

Scikit-learn includes a built-in English stop words list containing 318 common words, including:
- Articles: *a, an, the*
- Pronouns: *he, she, it, they, what, which*
- Prepositions: *in, on, at, by, for, with, about*
- Conjunctions: *and, but, or, because* (Note: scikit-learn's default list includes "but", though custom lists sometimes retain it)
- Auxiliary verbs: *is, was, are, been, have, had*

### Configuring `stop_words="english"`
In `CountVectorizer`, stop word filtering is enabled by setting:
```python
vectorizer = CountVectorizer(stop_words="english")
```
When this parameter is enabled, any candidate token present in scikit-learn's stop words dictionary is discarded before the vocabulary is indexed.

```mermaid
flowchart TD
    A["Raw Tokens: ['absolutely', 'flawless', 'i', 'cannot', 'believe', 'how', 'good', 'this', 'is']"] --> B{"Stop Words Filter"}
    B -->|Discarded: 'i', 'cannot', 'how', 'this', 'is'| C["Ignored Function Words"]
    B -->|Retained: 'absolutely', 'flawless', 'believe', 'good'| D["Discriminative Content Vocabulary"]
```

### Impact on the Fake Review Spotter
By removing stop words, the classifier avoids wasting probability mass on uninformative words. When we later compute `feature_log_prob_`, the top distinguishing words are rich descriptive terms like *"flawless"*, *"support"*, *"confusing"*, and *"superlatives"*, rather than filler words like *"and"* and *"the"*.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, line 46 explicitly specifies English stop words:
```python
model = Pipeline(
    [
        ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
        ("classifier", MultinomialNB()),
    ]
)
```
Notice how `stop_words="english"` works in synergy with `ngram_range=(1, 2)`. When stop words are removed, bigrams composed solely of stop words (like *"in the"*, *"it is"*) are eliminated, leaving only informative bigrams like *"customer support"* and *"best seller"*.

## 6. Worked Example
Let's observe the vocabulary reduction on a sample review:
```python
from sklearn.feature_extraction.text import CountVectorizer

review = ["It is not perfect, but it does the job for the price."]

# Without stop words
cv_raw = CountVectorizer().fit(review)
print(f"Without stop words ({len(cv_raw.vocabulary_)} terms):")
print(sorted(cv_raw.vocabulary_.keys()))

# With stop words='english'
cv_filtered = CountVectorizer(stop_words="english").fit(review)
print(f"\nWith stop_words='english' ({len(cv_filtered.vocabulary_)} terms):")
print(sorted(cv_filtered.vocabulary_.keys()))
```
**Console Output:**
```text
Without stop words (10 terms):
['but', 'does', 'for', 'is', 'it', 'job', 'not', 'perfect', 'price', 'the']

With stop_words='english' (3 terms):
['job', 'perfect', 'price']
```
Filtering reduced the vocabulary by **70%** (from 10 terms down to 3 content words: `'job'`, `'perfect'`, `'price'`).

## 7. Step-by-Step Student Instructions
1. In Python, import `ENGLISH_STOP_WORDS` from `sklearn.feature_extraction.text`.
2. Check the size of the built-in list: `print(len(ENGLISH_STOP_WORDS))`. Confirm it contains 318 words.
3. Check if words like `"the"`, `"and"`, and `"best"` are in `ENGLISH_STOP_WORDS`.
   - `"the"`: True
   - `"and"`: True
   - `"best"`: False (crucial! "best" is a content word and must be kept).

## 8. Expected Output or Observable Behaviour
```text
Scikit-learn English stop words count: 318
'the' in stop_words: True
'best' in stop_words: False
Content adjectives and nouns are preserved while structural words are removed.
```

## 9. Practical Exercises (with Success Criteria)
- **Task 3.1:** What happens if a review consists entirely of stop words (e.g., *"It was all for them in there."*) when `stop_words="english"` is set?
- **Task 3.2:** Explain one risk of using scikit-learn's default stop words list in sentiment analysis (Hint: consider the word "not").
- *Success Criteria:* Explains that all-stop-word reviews produce empty zero-vectors; notes that removing "not" can destroy negation.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Setting `stop_words=True` | `stop_words` expects a string (`'english'`) or a list, not a boolean | Pass the string `'english'` or a custom list of words. |
| Blindly removing stop words in sentiment models | Dropping "not" inverts negative sentiment to positive | For sentiment, use custom stop word lists that retain negation words. |
| Assuming all languages use the same stop words | English stop words do not filter Spanish, French, or German | Set language-appropriate stop word lists when analyzing other languages. |

## 11. Best Practices and Code Quality
- In topic classification and fraud detection, standard English stop word filtering significantly improves signal-to-noise ratio.
- If subtle negation matters, pass a custom list: `stop_words = list(ENGLISH_STOP_WORDS - {'not', 'no', 'never'})`.
- Verify that key domain terms are not inadvertently filtered by built-in lists.

## 12. Security, Ethics, and Fair AI Considerations
Standard stop word lists were compiled from formal 20th-century news corpora. They may not account for modern internet slang, abbreviations, or African American Vernacular English (AAVE). In large consumer platforms, custom curated stop word lists prevent unintentional cultural bias in text filtering.

## 13. Summary and Key Takeaways
Stop words are ubiquitous grammatical terms that add dimensionality without discriminative value. Setting `stop_words="english"` in `CountVectorizer` filters 318 high-frequency words, allowing the Naive Bayes classifier to focus on content-bearing vocabulary that betrays review deception.

## 14. Knowledge Check Questions
1. What are stop words, and why are they removed in text classification?
2. How many default stop words are included in scikit-learn's `'english'` list?
3. What is the syntax in `CountVectorizer` to enable English stop words removal?
4. Why might removing the word "not" cause problems in some NLP tasks?

## 15. References and Further Reading
- Luhn, H. P. (1958). *The Automatic Creation of Literature Abstracts.* IBM Journal of Research and Development.
- Scikit-learn documentation: Using stop words in text analysis.
