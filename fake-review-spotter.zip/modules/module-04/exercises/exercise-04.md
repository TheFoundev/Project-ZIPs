# Module 4 Exercises: Multinomial Naive Bayes & Pipeline Training

## Exercise 4.1: Manual Calculation of Bayes' Updating (10 min)
**Objective:** Calculate posterior class probabilities manually using Bayes' theorem in log-space.
**Problem Statement:** An e-commerce platform evaluates a new review consisting of two words: *"best seller"*.
Assume:
- Prior: $\log P(\text{fake}) = \log(0.5) \approx -0.693$
- Prior: $\log P(\text{real}) = \log(0.5) \approx -0.693$
- Conditional Log-Probabilities:
  - $\log P(\text{"best"} \mid \text{fake}) = -3.20$
  - $\log P(\text{"seller"} \mid \text{fake}) = -3.50$
  - $\log P(\text{"best"} \mid \text{real}) = -5.80$
  - $\log P(\text{"seller"} \mid \text{real}) = -6.20$

**Requirements:**
1. Calculate the total log score for class `fake`: $\log P(\text{fake}) + \sum \log P(w \mid \text{fake})$.
2. Calculate the total log score for class `real`: $\log P(\text{real}) + \sum \log P(w \mid \text{real})$.
3. Compare the two log scores: which class is larger (less negative)?
4. State the model's final predicted class label.

**Constraints:** Perform calculations using basic addition.

**Expected Behaviour:** Step-by-step arithmetic showing final class selection.

**Acceptance Criteria:**
- [ ] Fake log score: $-0.693 - 3.20 - 3.50 = -7.393$.
- [ ] Real log score: $-0.693 - 5.80 - 6.20 = -12.693$.
- [ ] Identifies that $-7.393 > -12.693$ (fake is far more probable).
- [ ] Selects class `fake`.

**Hints:**
- Remember that in negative numbers, $-7.39$ is greater than $-12.69$.
- The class with the highest log score wins.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes

---

## Exercise 4.2: Assembling the NLP Pipeline (15 min)
**Objective:** Construct, fit, and evaluate a scikit-learn Pipeline on `data/reviews.csv`.
**Problem Statement:** Write a standalone Python script that reads `data/reviews.csv`, splits the data using `stratify`, builds a `CountVectorizer` + `MultinomialNB` pipeline, and reports training and testing accuracy.

**Requirements:**
1. Import `Pipeline`, `CountVectorizer`, `MultinomialNB`, and `train_test_split`.
2. Load `data/reviews.csv`.
3. Perform train/test split with `test_size=0.25`, `random_state=42`, and `stratify=df['label']`.
4. Build the pipeline with `stop_words="english"` and `ngram_range=(1, 2)`.
5. Fit on training data and compute accuracy on both `X_train` and `X_test`.

**Constraints:** Use scikit-learn `Pipeline`.

**Expected Behaviour:** Printed output showing training accuracy and testing accuracy.

**Acceptance Criteria:**
- [ ] Pipeline constructed with named steps `"vectorizer"` and `"classifier"`.
- [ ] Model trains cleanly with zero warnings.
- [ ] Reports 100.0% test accuracy under `random_state=42`.
- [ ] Demonstrates proper data flow.

**Hints:**
- `accuracy_score(y_train, model.predict(X_train))`
- `accuracy_score(y_test, model.predict(X_test))`

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 4.3: Clue Strength Extraction (15 min)
**Objective:** Implement the `top_words` function and rank feature importance via log-likelihood ratios.
**Problem Statement:** Write a function that extracts `feature_log_prob_` from the trained pipeline and computes the top 5 most distinguishing words for each class.

**Requirements:**
1. Retrieve the vectorizer and classifier from `model.named_steps`.
2. Extract all vocabulary names using `.get_feature_names_out()`.
3. Compute the log-likelihood difference: $\text{scores} = \log P(w \mid c) - \log P(w \mid 1 - c)$.
4. Extract the top 5 clue words for `fake` and top 5 clue words for `real`.
5. Print the words along with their exact numerical clue strength scores.

**Constraints:** Follow the implementation pattern in `main.py`.

**Expected Behaviour:** A formatted list of top words and positive clue scores.

**Acceptance Criteria:**
- [ ] Top fake clues include "best", "wow", "stars".
- [ ] Top real clues include "liked", "works", "support helped".
- [ ] Scores are positive floats representing relative odds ratios.
- [ ] Explains that higher scores indicate stronger class association.

**Hints:**
- Use `np.argsort(scores)[-5:][::-1]` to retrieve indices.
- Print `scores[indices]` to see numerical values.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes

---

## Exercise 4.4: Probing Laplace Smoothing Impact (15 min)
**Objective:** Analyze how the Laplace smoothing parameter `alpha` influences clue strength and vocabulary probability.
**Problem Statement:** Experiment with different values of `alpha` in `MultinomialNB` ($lpha = 0.01, 0.5, 1.0, 5.0$) and observe the effect on clue scores.

**Requirements:**
1. Train four separate pipelines with `MultinomialNB(alpha=alpha)` for $lpha \in [0.01, 0.5, 1.0, 5.0]$.
2. For each model, compute the score of the top fake word.
3. Observe how increasing $\alpha$ compresses (dampens) extreme score differences.
4. Explain why excessive smoothing ($lpha=100$) would harm model discriminative power.

**Constraints:** Keep all other vectorizer parameters identical.

**Expected Behaviour:** A comparative table showing clue score dampening as alpha increases.

**Acceptance Criteria:**
- [ ] Trains models across the 4 alpha values.
- [ ] Observes that smaller alpha produces larger, more extreme clue scores.
- [ ] Observes that larger alpha shrinks clue scores toward zero.
- [ ] Explains that high alpha washes out statistical differences across classes.

**Hints:**
- Larger pseudo-counts make observed frequency differences matter less.
- Test accuracy may remain high even as scores shrink.

**Difficulty:** Advanced  
**Estimated Completion Time:** 15 minutes
