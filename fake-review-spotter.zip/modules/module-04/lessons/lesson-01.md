# Lesson 01: Bayes' Theorem in Plain English

**Lesson ID:** lesson-01
**Module:** module-04
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- State Bayes' Theorem in intuitive, non-mathematical terms.
- Define Prior probability, Likelihood, Evidence, and Posterior probability.
- Explain how new textual evidence updates initial baseline beliefs about a review.
- Understand why Naive Bayes computes calculations in log-space to prevent floating-point underflow.

## 2. Prerequisites
- Module 03: CountVectorizer and Text Vectorization.
- Intuitive understanding of probability as a fraction between 0.0 and 1.0.

## 3. Real-World Context & Business Motivation
Imagine you are a security inspector at an airport or an online fraud analyst. Before reading a newly submitted review, you have a baseline belief: *"In our platform, roughly 50% of reviews are authentic and 50% are deceptive."* This initial belief is your **Prior**. Then you read the text: *"WOW WOW WOW. 10/10 best ever."* This text provides **Evidence**. How should you rationally update your belief in light of this specific vocabulary? Bayes' Theorem provides the exact mathematical framework for updating probabilities when exposed to new empirical observations.

## 4. Concept Explanation
### The Formula for Rational Belief Updating
Bayes' Theorem is expressed mathematically as:
$$P(\text{Class} \mid \text{Words}) = \frac{P(\text{Words} \mid \text{Class}) \cdot P(\text{Class})}{P(\text{Words})}$$

Breaking down each term:
1. **Posterior Probability $P(\text{Class} \mid \text{Words})$:** What we want to find. "Given that the review contains words $w_1, w_2, \dots$, what is the probability that it is fake?"
2. **Prior Probability $P(\text{Class})$:** Our initial belief before reading any words. In our balanced dataset of 40 fake and 40 real reviews, $P(\text{fake}) = 0.5$ and $P(\text{real}) = 0.5$.
3. **Likelihood $P(\text{Words} \mid \text{Class})$:** How frequently do these specific words appear in historically fake reviews versus historically real reviews?
4. **Evidence (Marginal Probability) $P(\text{Words})$:** The overall probability of seeing these words across all reviews. Because this denominator is identical for both classes, we can ignore it during classification and choose the class with the highest numerator!

```mermaid
flowchart TD
    A["Prior Belief: P(fake) = 0.50"] --> B["Observe Evidence: 'flawless', 'best', 'buy'"]
    B --> C["Compute Likelihood: Words are 20x more common in fake reviews"]
    C --> D["Updated Posterior: P(fake | words) = 0.99"]
```

### Why Compute in Log-Space?
When a review contains 20 words, calculating raw likelihood involves multiplying 20 tiny fractions together:
$$0.015 \times 0.008 \times 0.021 \times 0.004 \times \dots \approx 10^{-28}$$
Standard 64-bit computer hardware cannot store numbers smaller than approximately $10^{-308}$, and intermediate precision is rapidly lost through **floating-point underflow** (rounding down to literal zero).

To prevent this, computers use logarithms. By the law of logarithms:
$$\log(a \cdot b) = \log a + \log b$$
Multiplication of tiny probabilities becomes simple, stable addition of negative numbers:
$$\log P(\text{Class} \mid \text{Words}) \propto \log P(\text{Class}) + \sum_{i} \log P(w_i \mid \text{Class})$$

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, line 21 and line 47 instantiate the algorithm:
```python
from sklearn.naive_bayes import MultinomialNB

model = Pipeline(
    [
        ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
        ("classifier", MultinomialNB()),
    ]
)
```
Internally, `MultinomialNB` implements this exact log-space Bayesian updating. It estimates the prior probabilities from training label frequencies and sums the log-likelihoods of all observed tokens.

## 6. Worked Example
Suppose a review contains the word *"flawless"*.
- Prior: $P(\text{fake}) = 0.5$, $P(\text{real}) = 0.5$.
- Historical frequencies:
  - *"flawless"* appears in 10 out of 100 fake reviews: $P(\text{flawless} \mid \text{fake}) = 0.10$.
  - *"flawless"* appears in 1 out of 100 real reviews: $P(\text{flawless} \mid \text{real}) = 0.01$.

Comparing the numerators:
- Fake score: $P(\text{flawless} \mid \text{fake}) \cdot P(\text{fake}) = 0.10 \cdot 0.50 = 0.05$
- Real score: $P(\text{flawless} \mid \text{real}) \cdot P(\text{real}) = 0.01 \cdot 0.50 = 0.005$

Posterior probability:
$$P(\text{fake} \mid \text{flawless}) = \frac{0.05}{0.05 + 0.005} = \frac{0.05}{0.055} \approx 90.9\%$$
The observation of the single word *"flawless"* updated our belief from 50% up to **90.9%**!

## 7. Step-by-Step Student Instructions
1. Review the worked example calculation above.
2. Suppose a review contains the word *"scratch"*, which appears 12 times in real reviews and 0 times in fake reviews.
3. Intuitively, which direction should our posterior belief move?
4. Understand that each word acts like a push on a scale, nudging the posterior toward either `"fake"` or `"real"`.

## 8. Expected Output or Observable Behaviour
```text
Prior: 50% fake, 50% real
Word 'flawless' observed -> P(fake) jumps to 90.9%
Word 'customer support' observed -> P(real) jumps to 98%
Final decision: argmax(P(class | text))
```

## 9. Practical Exercises (with Success Criteria)
- **Task 1.1:** Write the mathematical equation for Bayes' theorem.
- **Task 1.2:** Explain why multiplying raw probabilities causes floating-point underflow in computers.
- *Success Criteria:* Accurately defines the four Bayesian terms; explains that log transformation converts tiny multiplications into stable additions.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Confusing $P(A \mid B)$ with $P(B \mid A)$ | Probability of words given class is not class given words | Bayes' theorem explicitly converts likelihood into posterior. |
| Forgetting priors on imbalanced data | Assuming $P(	ext{class})=0.5$ when one class is 95% of data | Priors ground baseline expectations before observing text. |
| Trying to compute raw probabilities without logs | Causes floating-point underflow to 0.0 | All modern machine learning libraries operate in log-space. |

## 11. Best Practices and Code Quality
- Let scikit-learn manage log-probabilities automatically via `MultinomialNB`.
- Use `.predict_proba()` when you need normalized output probabilities between 0.0 and 1.0.
- Verify that priors reflect real-world operational distributions.

## 12. Security, Ethics, and Fair AI Considerations
Bayesian models are sensitive to prior probabilities. If a model is deployed with an artificially inflated prior for fraud (e.g., $P(\text{fake}) = 0.8$), even weakly suspicious reviews will be aggressively flagged. Priors must be calibrated with empirical operational data.

## 13. Summary and Key Takeaways
Bayes' Theorem provides a principled method for updating class beliefs in the presence of word evidence. By combining prior probabilities with word likelihoods in log-space, Naive Bayes calculates posterior probabilities robustly without numerical underflow.

## 14. Knowledge Check Questions
1. What does the Prior probability represent in Bayes' Theorem?
2. What is the difference between Likelihood and Posterior probability?
3. Why do computers sum log probabilities instead of multiplying raw probabilities?
4. Why can the denominator $P(\text{Words})$ be omitted when selecting the winning class?

## 15. References and Further Reading
- Bayes, T. (1763). *An Essay towards solving a Problem in the Doctrine of Chances.* Philosophical Transactions of the Royal Society.
- Scikit-learn documentation: Naive Bayes theory and implementation.
