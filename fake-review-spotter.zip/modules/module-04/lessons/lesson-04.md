# Lesson 04: Dissecting feature_log_prob_ and Clue Strength

**Lesson ID:** lesson-04
**Module:** module-04
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Access and inspect the `feature_log_prob_` matrix from a fitted `MultinomialNB` classifier.
- Derive the mathematical formula for the Log-Likelihood Ratio difference.
- Explain how `main.py` calculates clue strength for distinguishing words.
- Implement `top_words()` using `np.argsort` to surface the most decisive fake and real clues.

## 2. Prerequisites
- Completion of Lessons 01-03 of Module 04.
- Familiarity with NumPy array indexing and slicing (`np.argsort`).

## 3. Real-World Context & Business Motivation
Machine learning models are frequently criticized as opaque "black boxes." When an algorithm flags a customer review as fake, merchants, moderators, and auditors demand an explanation: *"Why was this review flagged? What specific phrases triggered the decision?"* By peering into the learned probability parameters of Multinomial Naive Bayes, we can extract the exact vocabulary terms that most powerfully influenced the decision. Feature attribution transforms a black-box model into an interpretable, auditable system.

## 4. Concept Explanation
### The `feature_log_prob_` Matrix
Once `MultinomialNB` is fitted on training data, it stores the empirical log probability of every feature (word) given each class:
```python
classifier = model.named_steps["classifier"]
print(classifier.feature_log_prob_.shape)
```
- **Shape:** `(n_classes, n_features)` $\to$ `(2, V)`, where $V$ is vocabulary size.
- **Row 0 (`fake`):** Contains $\log P(w_j \mid \text{fake})$ for every vocabulary token $j$.
- **Row 1 (`real`):** Contains $\log P(w_j \mid \text{real})$ for every vocabulary token $j$.
- Because probabilities are $\le 1.0$, all values in `feature_log_prob_` are non-positive numbers (e.g., $-3.45, -6.12$).

### Mathematical Derivation of Clue Strength
How do we find words that are strongly indicative of class $c$ compared to class $1 - c$?
We compute the **Log-Likelihood Ratio**:
$$\text{score}(w) = \log \left( \frac{P(w \mid c)}{P(w \mid 1 - c)} \right)$$
By the fundamental quotient rule of logarithms:
$$\log \left( \frac{A}{B} \right) = \log A - \log B$$
Therefore, clue strength is calculated by simple matrix subtraction:
$$\text{scores} = \text{feature\_log\_prob\_}[c] - \text{feature\_log\_prob\_}[1 - c]$$
- If $\text{score}(w) \gg 0$: Word $w$ appears vastly more often in class $c$ than in the other class (strong clue for class $c$).
- If $\text{score}(w) \approx 0$: Word $w$ appears with equal frequency in both classes (uninformative).
- If $\text{score}(w) \ll 0$: Word $w$ appears predominantly in the opposing class.

### Extracting the Top $N$ Words with `np.argsort`
NumPy's `np.argsort(scores)` returns the indices that would sort the array in ascending order (lowest to highest).
To extract the top $n$ highest scores:
1. `[-n:]`: Slices the last $n$ indices (the largest scores).
2. `[::-1]`: Reverses the slice so the #1 highest score appears first.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 30-36 implement this exact logic:
```python
def top_words(model: Pipeline, class_index: int, n: int = 10) -> list[str]:
    vectorizer = model.named_steps["vectorizer"]
    classifier = model.named_steps["classifier"]
    names = vectorizer.get_feature_names_out()
    scores = classifier.feature_log_prob_[class_index] - classifier.feature_log_prob_[1 - class_index]
    return list(names[np.argsort(scores)[-n:][::-1]])
```
And lines 60-65 invoke the function:
```python
classes = list(model.named_steps["classifier"].classes_)
fake_index = classes.index("fake")
fake_words = top_words(model, fake_index)
real_words = top_words(model, 1 - fake_index)
print("Top 'fake' clues:", ", ".join(fake_words))
print("Top 'real' clues:", ", ".join(real_words))
```

## 6. Worked Example
Let's run `top_words` and inspect the actual returned terms:
```python
# Assuming model is trained as in main.py
print("Top 5 Fake Clues:")
for rank, word in enumerate(fake_words[:5], 1):
    print(f" {rank}. {word}")

print("\nTop 5 Real Clues:")
for rank, word in enumerate(real_words[:5], 1):
    print(f" {rank}. {word}")
```
**Console Output:**
```text
Top 5 Fake Clues:
 1. best
 2. wow
 3. stars
 4. wow wow
 5. 10

Top 5 Real Clues:
 1. liked
 2. works
 3. support helped
 4. support
 5. instructions
```
The mathematical subtraction cleanly isolated generic hype from concrete functional feedback!

## 7. Step-by-Step Student Instructions
1. In Python, train the pipeline on `reviews.csv`.
2. Extract the classifier: `clf = model.named_steps['classifier']`.
3. Check `clf.feature_log_prob_.shape`.
4. Calculate difference scores for fake: `scores = clf.feature_log_prob_[0] - clf.feature_log_prob_[1]`.
5. Run `names = model.named_steps['vectorizer'].get_feature_names_out()`.
6. Print the top clue: `names[np.argmax(scores)]`. Confirm it returns `'best'`.

## 8. Expected Output or Observable Behaviour
```text
feature_log_prob_ shape: (2, 218)
Scores array length: 218
Top fake clue word: 'best'
Top real clue word: 'liked'
Interpretable feature attribution successfully verified.
```

## 9. Practical Exercises (with Success Criteria)
- **Task 4.1:** Mathematically prove why $\log P(w \mid c) - \log P(w \mid \text{other})$ equals the log odds ratio.
- **Task 4.2:** What would happen if you used `np.argsort(scores)[:n]` instead of `[-n:][::-1]`?
- *Success Criteria:* Cites $\log(A/B) = \log A - \log B$; explains that `[:n]` returns the worst clues instead of the best.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Slicing `[:n]` in `np.argsort` | Selects lowest negative scores (opposite class clues) | Use `[-n:][::-1]` to get highest positive scores in descending order. |
| Forgetting to match class index with `classes_` | Hardcoding 0/1 can invert fake and real if class order changes | Look up index dynamically: `fake_index = list(clf.classes_).index('fake')`. |
| Comparing raw count sums instead of log probs | Fails to account for total class token volume | `feature_log_prob_` incorporates Laplace smoothing and token totals. |

## 11. Best Practices and Code Quality
- Always determine class indices dynamically using `clf.classes_`.
- Type-hint helper functions: `def top_words(model: Pipeline, class_index: int, n: int = 10) -> list[str]:`.
- Use feature log probabilities for model explainability and compliance auditing.

## 12. Security, Ethics, and Fair AI Considerations
Exposing top clues can be a double-edged sword. While it provides transparency for customers and auditors, publishing exact clue lists allows sophisticated fraudsters to reverse-engineer the filter and avoid flagged words. In production, feature importance lists should be protected under restricted access.

## 13. Summary and Key Takeaways
`feature_log_prob_` stores $\log P(	ext{word} \mid 	ext{class})$. By subtracting the opposing class's log probability from the target class's log probability, we calculate the log-likelihood ratio, isolating the most decisive vocabulary clues with mathematical precision.

## 14. Knowledge Check Questions
1. What does the matrix `classifier.feature_log_prob_` contain?
2. What mathematical law allows us to subtract log probabilities to find the odds ratio?
3. What does `np.argsort(scores)[-n:][::-1]` accomplish?
4. What is the single strongest clue word for fake reviews discovered by the model?

## 15. References and Further Reading
- Ribeiro, M. T., Singh, S., & Guestrin, C. (2016). *"Why Should I Trust You?": Explaining the Predictions of Any Classifier.* KDD.
- NumPy documentation: `numpy.argsort` array sorting.
