# Lesson 02: The Naive Assumption and MultinomialNB

**Lesson ID:** lesson-02
**Module:** module-04
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define the "naive" conditional independence assumption in Naive Bayes.
- Explain why human language violates this assumption in practice.
- Understand why Naive Bayes remains highly effective despite its theoretical flaw.
- Explain the role of Laplace smoothing (`alpha=1.0`) in handling unseen vocabulary words.

## 2. Prerequisites
- Completion of Lesson 01: Bayes' Theorem in Plain English.
- Basic understanding of word frequencies in text.

## 3. Real-World Context & Business Motivation
In human linguistics, words are never independent. If you hear the word *"Hong"*, the probability that the next word is *"Kong"* is extraordinarily high. If a review says *"customer"*, the likelihood of *"service"* or *"support"* increases dramatically. In full joint probability modeling, tracking all possible word combinations would require more parameters than atoms in the observable universe. The "Naive" Bayes algorithm cuts this Gordian knot with an audacious simplification: it assumes that every word is completely independent of every other word, given the class label.

## 4. Concept Explanation
### The "Naive" Conditional Independence Assumption
Mathematically, the naive assumption states:
$$P(w_1, w_2, \dots, w_k \mid \text{Class}) = \prod_{i=1}^{k} P(w_i \mid \text{Class})$$
Instead of modeling complex word-word interactions, the model treats each word as an independent witness providing evidence for or against the class.

### Why Does It Work So Well on Text?
Linguists often dismiss Naive Bayes because its premise is clearly false. Yet for decades, Naive Bayes has remained a workhorse of industrial spam filtering. Why?
1. **Classification vs. Estimation:** To classify a review correctly, the model does not need exact probability calibration. It only needs the **correct class to have a higher score than the incorrect class** ($	ext{argmax}$).
2. **Cancellation of Correlated Errors:** While word dependencies distort absolute probabilities toward extreme values (near 0% or 100%), the distortion tends to affect both classes symmetrically, preserving the correct decision boundary.

### The Zero-Probability Problem & Laplace Smoothing
Suppose a new review arrives during testing containing the word *"ergonomic"*. In our training data, *"ergonomic"* appeared twice in authentic reviews, but **zero times in fake reviews**:
$$P(\text{ergonomic} \mid \text{fake}) = \frac{0}{\text{total fake words}} = 0$$
If we multiply this zero into our probability chain:
$$P(\text{fake} \mid \text{review}) \propto P(\text{fake}) \times P(w_1 \mid \text{fake}) \times \dots \times 0 = 0$$
A single novel word completely obliterates all other evidence, forcing the fake probability to literal zero!

To solve this, **Laplace Smoothing (Additive Smoothing)** adds a pseudo-count $\alpha$ (typically $\alpha=1.0$) to every word's count:
$$P(w_i \mid c) = \frac{\text{count}(w_i, c) + \alpha}{\sum_{w} \text{count}(w, c) + \alpha \cdot |V|}$$
Where:
- $\alpha = 1.0$: Ensures every word has at least a tiny positive count.
- $|V|$: The total vocabulary size, added to the denominator to preserve proper probability normalization.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, line 47 instantiates `MultinomialNB()`:
```python
model = Pipeline(
    [
        ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
        ("classifier", MultinomialNB()),
    ]
)
```
By default, scikit-learn's `MultinomialNB()` sets `alpha=1.0`, automatically applying Laplace smoothing across all vocabulary terms.

## 6. Worked Example
Suppose a vocabulary has $|V| = 100$ terms, and class `fake` has 500 total word occurrences in training.
- Word *"wow"* appeared 25 times:
  $$P(\text{wow} \mid \text{fake}) = \frac{25 + 1}{500 + 1 \cdot 100} = \frac{26}{600} \approx 0.0433$$
- Word *"ergonomic"* appeared 0 times:
  $$P(\text{ergonomic} \mid \text{fake}) = \frac{0 + 1}{500 + 1 \cdot 100} = \frac{1}{600} \approx 0.00167$$
Notice that *"ergonomic"* now has a small, positive probability ($0.00167$) rather than zero. The calculation remains stable and cannot be zeroed out.

## 7. Step-by-Step Student Instructions
1. Open Python and import `MultinomialNB` from `sklearn.naive_bayes`.
2. Instantiate `nb = MultinomialNB()`.
3. Inspect `nb.alpha`. Confirm it defaults to `1.0`.
4. Understand that setting `alpha=0.0` disables smoothing and reintroduces the fatal zero-probability bug.

## 8. Expected Output or Observable Behaviour
```text
MultinomialNB parameter: alpha=1.0
Laplace smoothing: Enabled by default
Zero-probability hazard: Prevented mathematically
```

## 9. Practical Exercises (with Success Criteria)
- **Task 2.1:** What is the conditional independence assumption in plain English?
- **Task 2.2:** Calculate the smoothed probability of a word that appeared 5 times in a class with 200 total tokens and a vocabulary of 50 terms ($lpha=1$).
- *Success Criteria:* Probability = $rac{5 + 1}{200 + 50} = rac{6}{250} = 0.024$.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Setting `alpha=0` in MultinomialNB | Causes zero-probability crashes on unseen test words | Always keep Laplace smoothing enabled ($lpha=1.0$). |
| Using GaussianNB instead of MultinomialNB | GaussianNB expects continuous bell-curve features | MultinomialNB is specifically designed for discrete word count vectors. |
| Believing Naive Bayes probabilities are well-calibrated | Independent assumptions push probabilities to 0% and 100% | The class rankings are accurate, but raw probabilities are often overconfident. |

## 11. Best Practices and Code Quality
- Always select `MultinomialNB` or `ComplementNB` for text count features.
- Never use `BernoulliNB` unless features are strictly binary (0 or 1 presence flags).
- Tune `alpha` (e.g., using `GridSearchCV` between 0.1 and 1.0) on larger corpora.

## 12. Security, Ethics, and Fair AI Considerations
Because Naive Bayes assumes independent words, it is susceptible to "keyword stuffing" attacks. A fraudster can paste 20 positive words into a review, and the model multiplies their weights independently, inflating confidence without checking syntactic coherence.

## 13. Summary and Key Takeaways
MultinomialNB assumes all words are conditionally independent given the class. While theoretically unrealistic, this assumption drastically reduces computational complexity while delivering highly competitive classification accuracy. Laplace smoothing ($lpha=1.0$) prevents unseen words from zeroing out class probabilities.

## 14. Knowledge Check Questions
1. Why is the algorithm called "Naive"?
2. What is the zero-probability problem in Naive Bayes?
3. How does Laplace smoothing solve the zero-probability problem?
4. Why is MultinomialNB preferred over GaussianNB for Bag-of-Words text?

## 15. References and Further Reading
- Domingos, P., & Pazzani, M. (1997). *On the Optimality of the Simple Bayesian Classifier under Zero-One Loss.* Machine Learning, 29(2), 103-130.
- Scikit-learn API: `sklearn.naive_bayes.MultinomialNB`.
