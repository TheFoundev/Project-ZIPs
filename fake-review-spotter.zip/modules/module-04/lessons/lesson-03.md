# Lesson 03: Building Scikit-Learn Pipelines

**Lesson ID:** lesson-03
**Module:** module-04
**Duration:** 15 minutes

## 1. Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Construct an integrated scikit-learn `Pipeline` combining text vectorization and classification.
- Explain why pipelines prevent data leakage during train/test partitioning.
- Execute stratified data partitioning using `train_test_split(stratify=...)`.
- Perform training using `model.fit()` and out-of-sample prediction using `model.predict()`.

## 2. Prerequisites
- Completion of Lessons 01 and 02 of Module 04.
- Familiarity with scikit-learn transformer and estimator interfaces.

## 3. Real-World Context & Business Motivation
In beginner tutorials, students often vectorize their entire dataset first, and then split the resulting matrix into training and testing sets. In production software engineering, this practice is a severe error known as **data leakage**. When you fit a vectorizer on the full dataset, the vocabulary includes words, frequencies, and bigrams from the test set—contaminating the training process with future information. A scikit-learn `Pipeline` binds preprocessing and modeling into an atomic object, guaranteeing that transformations are learned strictly from training data.

## 4. Concept Explanation
### The Scikit-Learn Pipeline Architecture
A `Pipeline` sequentially applies a list of data transformers, culminating in a final estimator:
```python
from sklearn.pipeline import Pipeline

model = Pipeline(
    [
        ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
        ("classifier", MultinomialNB()),
    ]
)
```
- Step 1 (`"vectorizer"`): Implements `fit()` and `transform()`. It learns vocabulary exclusively from training strings and outputs sparse count matrices.
- Step 2 (`"classifier"`): Implements `fit()` and `predict()`. It trains on the count matrices and outputs class predictions.

```mermaid
flowchart LR
    A["Raw Text Review"] --> B["Step 1: 'vectorizer'
(CountVectorizer)"]
    B -->|Sparse Document-Term Matrix| C["Step 2: 'classifier'
(MultinomialNB)"]
    C --> D["Predicted Label: 'fake' / 'real'"]
```

### End-to-End Ergonomics
The primary developer benefit of a pipeline is seamless inference. Without a pipeline, scoring a new review requires manual multi-step choreography:
```python
# Without Pipeline (cumbersome, leak-prone)
X_train_counts = vectorizer.fit_transform(X_train)
classifier.fit(X_train_counts, y_train)

# Inference requires remembering to use transform(), not fit_transform()
new_counts = vectorizer.transform(new_reviews)
preds = classifier.predict(new_counts)
```
With a `Pipeline`, this collapses into a single, elegant line:
```python
# With Pipeline (clean, robust)
model.fit(X_train, y_train)
preds = model.predict(new_reviews)  # Vectorization happens automatically!
```

### Stratified Splitting
To ensure reliable evaluation, the dataset is partitioned using:
```python
X_train, X_test, y_train, y_test = train_test_split(
    df["review"], df["label"], test_size=0.25, random_state=42, stratify=df["label"]
)
```
- `test_size=0.25`: Allocates 25% (20 reviews) to test, leaving 75% (60 reviews) for training.
- `random_state=42`: Seeds the pseudo-random generator for exact reproducibility.
- `stratify=df["label"]`: Enforces identical class proportions (50% fake, 50% real) across both splits.

## 5. Relevant Code Walkthrough (from main.py)
In `main.py`, lines 40-52 assemble the pipeline, train, and predict:
```python
X_train, X_test, y_train, y_test = train_test_split(
    df["review"], df["label"], test_size=0.25, random_state=42, stratify=df["label"]
)

model = Pipeline(
    [
        ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
        ("classifier", MultinomialNB()),
    ]
)
model.fit(X_train, y_train)
predictions = model.predict(X_test)
accuracy = accuracy_score(y_test, predictions)
```
By passing raw text `X_train` into `model.fit()`, the pipeline ensures that `CountVectorizer` only learns vocabulary present in the 60 training reviews.

## 6. Worked Example
Let's trace how the pipeline handles an unseen review during `predict()`:
```python
new_review = ["AMAZING!!! Best product ever. Buy it now!"]
predicted_class = model.predict(new_review)
predicted_probs = model.predict_proba(new_review)

print(f"Prediction: {predicted_class[0]}")
print(f"Classes: {list(model.classes_)}")
print(f"Probabilities: {predicted_probs[0]}")
```
**Console Output:**
```text
Prediction: fake
Classes: ['fake', 'real']
Probabilities: [0.9998, 0.0002]
```
The raw string was transformed into a count vector and scored by MultinomialNB seamlessly behind the scenes.

## 7. Step-by-Step Student Instructions
1. In your Python session, load `reviews.csv`.
2. Perform stratified split: `X_train, X_test, y_train, y_test = train_test_split(df['review'], df['label'], test_size=0.25, random_state=42, stratify=df['label'])`.
3. Construct the pipeline using `Pipeline([('vectorizer', CountVectorizer(stop_words='english', ngram_range=(1,2))), ('classifier', MultinomialNB())])`.
4. Fit the pipeline: `model.fit(X_train, y_train)`.
5. Predict on test set: `preds = model.predict(X_test)`.
6. Calculate accuracy: `from sklearn.metrics import accuracy_score; print(accuracy_score(y_test, preds))`. Confirm it outputs `1.0` (100%).

## 8. Expected Output or Observable Behaviour
```text
X_train shape: (60,)
X_test shape: (20,)
Pipeline fitted successfully.
Test Accuracy: 1.0 (100.0%)
```

## 9. Practical Exercises (with Success Criteria)
- **Task 3.1:** What is data leakage and how does wrapping `CountVectorizer` in a `Pipeline` prevent it?
- **Task 3.2:** How do you access the fitted vectorizer step from inside a pipeline object?
- *Success Criteria:* Explains that pipeline restricts vocabulary fitting to `X_train`; uses `model.named_steps['vectorizer']`.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Vectorizing before `train_test_split` | Causes data leakage from test set into vocabulary | Always split raw text first, then fit vectorizer on train data. |
| Calling `.fit_transform()` on test data | Overwrites training parameters with test parameters | Only call `.fit()` or `.fit_transform()` on `X_train`. |
| Omitting named steps in Pipeline | Makes accessing internal attributes difficult | Use tuples with descriptive names: `[('vectorizer', ...), ('classifier', ...)]`. |

## 11. Best Practices and Code Quality
- Always encapsulate multi-step preprocessing and modeling inside scikit-learn `Pipeline` objects.
- Access internal estimators using `model.named_steps["name"]`.
- Set a fixed `random_state` during experiments to guarantee reproducibility.

## 12. Security, Ethics, and Fair AI Considerations
Serialized pipeline objects (`pickle` or `joblib`) can execute arbitrary code upon unpickling. Never load pre-trained `.pkl` model files received from untrusted third parties. For production deployment, use secure formats like ONNX or auditable code pipelines.

## 13. Summary and Key Takeaways
Scikit-learn `Pipeline` objects bundle `CountVectorizer` and `MultinomialNB` into an atomic unit. Pipelines prevent data leakage, guarantee proper stratified evaluation, and allow direct inference on raw text strings without manual preprocessing boilerplate.

## 14. Knowledge Check Questions
1. Why does vectorizing text before `train_test_split` constitute data leakage?
2. What are the two named steps in our project pipeline?
3. How does `Pipeline.predict()` handle a raw string input?
4. How many training and testing samples result from `test_size=0.25` on 80 rows?

## 15. References and Further Reading
- Buitinck, L., et al. (2013). *API design for machine learning software: experiences from the scikit-learn project.*
- Scikit-learn documentation: Composing estimators using Pipeline.
