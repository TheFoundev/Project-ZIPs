# Module 6, Lesson 3: Model Limitations and Adversarial Deception

## 1. Concept Overview
The Fake Review Spotter is a statistical pattern finder, **not a lie detector**. It does not know whether a customer actually purchased a blender, whether the blender blade broke, or whether an offshore marketing agency was paid $5 to leave a 5-star rating. Instead, it measures statistical associations between specific n-grams and class labels present in historical training data.

This distinction is crucial for machine learning practitioners. In this lesson, we analyze the architectural vulnerabilities of word-frequency classifiers, investigate honest false positives and adversarial evasion tactics, examine the structure of `predictions.txt`, and confront the ethical and business risks of automated content moderation.

## 2. Key Terms and Definitions
- **Pattern Finder vs. Lie Detector:** A foundational machine learning distinction: classifiers recognize statistical correlations in lexical token distributions, not the empirical veracity or honesty of factual claims.
- **Honest False Positive:** An authentic, truthful customer review incorrectly classified as fake because the customer used enthusiastic, promotional phrasing (e.g., `"Best purchase ever! Five stars!"`).
- **Adversarial Evasion (Spam Spoofing):** The deliberate crafting of deceptive reviews using understated, technical, or neutral phrasing designed to bypass keyword-based spam classifiers.
- **Vocabulary Drift / Concept Drift:** Changes over time in language, slang, product features, or fraud tactics that degrade the accuracy of a static trained model.
- **Human-in-the-Loop (HITL):** A system architecture where automated machine learning decisions below high-confidence thresholds require human review before punitive business actions are taken.

## 3. Why This Matters in Fake Review Spotter
In `main.py`, the README explicitly highlights this critical design principle:
> *"A text classifier that learns word patterns. It is a pattern finder, not a lie detector: the README explains why that distinction matters."*

Furthermore, `main.py` concludes with an insightful challenge:
```python
print("Try this: add 10 honest reviews that sound enthusiastic and see whether they fool the model.")
```
If an excited genuine buyer writes:
`"AMAZING! Best product in the world! 10 stars! Buy it now!"`
our model classifies it as **fake with 100% confidence**. Why? Because every single one of those words (`amazing`, `best`, `10`, `stars`, `buy`) appeared exclusively in fake training samples!

Understanding this limitation prevents engineers from placing blind faith in automated NLP models and guides the creation of robust, multi-layered anti-fraud systems.

## 4. Theory Deep Dive
### The Mechanics of False Positives
Recall the Bayes decision rule:
$$\hat{y} = \arg\max_{c} \left[ \log P(c) + \sum_{j=1}^{V} x_j \log P(w_j \mid c) \right]$$
The model assigns labels solely based on the sum of log probabilities of the observed words. It possesses zero external context:
- It cannot check if the user has a verified purchase receipt.
- It cannot verify if the user's IP address matches 500 other accounts.
- It cannot determine if the user spent 30 minutes testing the device before writing.

Consequently, any authentic review that happens to share stylistic habits with promotional spam will trigger false alarms.

### The Mechanics of Adversarial Evasion
Conversely, sophisticated fraud actors quickly learn how simple classifiers operate. If spammers know that words like `best`, `wow`, `buy`, and `stars` trigger fake review filters, they simply alter their prompt templates:
- **Naive Fake Review:** `"WOW WOW AMAZING BEST PRODUCT BUY NOW 5 STARS!!!"` $\to$ **Caught (100% Fake)**
- **Adversarial Fake Review:** `"The build quality conforms to standard consumer electronics specifications. Assembly took twenty minutes using the supplied Allen wrench. All three speed settings operated within acceptable tolerances during initial testing."` $\to$ **Evades Detection (Predicted 100% Real!)**

The adversarial review is completely fabricated—written by a paid troll or an LLM bot—yet because it utilizes neutral, technical vocabulary (`specifications`, `assembly`, `tolerances`, `testing`), our classifier assigns it to the `"real"` class with near-total certainty!

### Output Logging: `predictions.txt`
In `main.py`, scikit-learn metrics and inference outcomes are systematically logged to disk:
```python
with open(OUT / "predictions.txt", "w", encoding="utf-8") as handle:
    handle.write(f"accuracy: {accuracy:.4f}\n\n")
    handle.write(classification_report(y_test, predictions, zero_division=0))
    handle.write("\nNew reviews:\n")
    for review, prediction, probability in zip(new_reviews, new_predictions, new_probabilities):
        handle.write(f"{prediction} ({probability[classes.index(prediction)]:.2%}) -> {review}\n")
```
This file serves as an auditable record of test-set accuracy, precision/recall per class, and real-time predictions on novel samples.

## 5. Architectural Diagram / ASCII Flow
```text
                  +-----------------------------------+
                  |      INCOMING CUSTOMER REVIEW     |
                  +-----------------------------------+
                                    |
                 Does it contain promotional tokens?
                 ('best', 'wow', 'stars', 'buy')
                               /     \
                             YES      NO
                             /         \
                            v           v
     +---------------------------+   +---------------------------+
     | PREDICTED: "FAKE"         |   | PREDICTED: "REAL"         |
     +---------------------------+   +---------------------------+
           |               |               |               |
     If Honest User:  If Paid Bot:   If Honest User:  If Paid Bot:
           |               |               |               |
           v               v               v               v
     FALSE POSITIVE  TRUE POSITIVE   TRUE NEGATIVE   FALSE NEGATIVE
     (Enthusiastic   (Standard Spam) (Objective Real (Adversarial Evasion
      real buyer)                     feedback)       stealth spam)
```

## 6. Implementation Code Walkthrough
Let us demonstrate an adversarial stress test against our trained model:

```python
# 1. Define adversarial test suite
adversarial_reviews = [
    # Case A: Honest buyer who is ecstatic (Risk: False Positive)
    "I am so happy with this! Best vacuum cleaner I ever owned! Five stars all the way!",
    
    # Case B: Paid fake review disguised as dry, neutral feedback (Risk: False Negative)
    "The shipping container arrived undamaged. The item functions as expected. Satisfactory performance.",
]

# 2. Evaluate model behavior
adv_predictions = model.predict(adversarial_reviews)
adv_probs = model.predict_proba(adversarial_reviews)

for text, pred, prob in zip(adversarial_reviews, adv_predictions, adv_probs):
    conf = prob[classes.index(pred)]
    print(f"Text: '{text}'")
    print(f" -> Predicted: {pred} (Confidence: {conf:.1%})")
```

Console Output:
```text
Text: 'I am so happy with this! Best vacuum cleaner I ever owned! Five stars all the way!'
 -> Predicted: fake (Confidence: 100.0%)  <-- Honest buyer falsely accused!

Text: 'The shipping container arrived undamaged. The item functions as expected. Satisfactory performance.'
 -> Predicted: real (Confidence: 99.8%)  <-- Paid fake review slipped through undetected!
```

## 7. Edge Cases and Pitfalls
1. **Unilateral Automated Account Termination:**
   Basing merchant suspensions or user bans solely on a bag-of-words text classifier inevitably harms legitimate users. Anti-fraud systems must employ human oversight and multi-signal corroboration.
2. **Data Drift and Evolving Slang:**
   New consumer expressions (e.g., `"slaps"`, `"goated"`, `"mid"`) not present in historical training data will either be discarded as OOV or misattributed to spam classes.
3. **The AI-Generated Review Explosion:**
   Modern generative AI models (ChatGPT, Claude) can produce millions of grammatically flawless, varied, and subtle reviews on command, completely neutralizing basic n-gram pattern matching.

## 8. Real-World Applications
- **Multi-Tiered Abuse Systems:** Production platforms use text classification only as a preliminary risk score (e.g., 20% weight in a holistic fraud engine).
- **Merchant Appeal Workflows:** Providing sellers and reviewers with an easy, responsive appeal process when automated systems flag authentic content.
- **Continuous Red-Teaming:** Security teams continuously generate novel adversarial review formulations to probe model blind spots and retrain defenses.

## 9. Practical Exercises (with Success Criteria)
- **Task 3.1:** Craft a review that is genuinely honest and positive, but forces the model to predict `"fake"`.
- **Task 3.2:** Craft a review that is 100% fabricated, but forces the model to predict `"real"`.
- *Success Criteria:* Task 3.1 achieves predicted label `'fake'`; Task 3.2 achieves predicted label `'real'`.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Why It Is Problematic | Proper Perspective |
|---|---|---|
| Believing 100% test accuracy means the model is infallible | Test accuracy measures performance on historical in-distribution data, not resistance to novel adversarial evasion | Recognize that bag-of-words models can be easily bypassed by altering vocabulary. |
| Treating text as the only fraud signal | Ignores transaction, user, and network signals | Combine text features with user metadata and behavior. |
| Deleting reviews without audit logging | Eliminates the ability to debug errors or process appeals | Always persist prediction audits to files like `predictions.txt`. |

## 11. Best Practices and Code Quality
- Always document the distinction between statistical correlation and factual ground truth in project readmes.
- Structure output logs (`predictions.txt`) with exact accuracy, classification metrics, and individual sample confidence scores.
- Never deploy automated text moderation without a human appeal and escalation pathway.

## 12. Learning Connections
- **Previous Lesson:** In Lesson 2, we extracted numeric confidence scores via `predict_proba()`.
- **Next Lesson:** In Lesson 4, we study real-world multimodal architectures that combine text NLP with user metadata (star ratings, verified purchase, account age).

## 13. Step-by-Step Code Walkthrough Table
| Step | Code Expression | Purpose |
|---|---|---|
| 1 | `open(OUT / "predictions.txt", "w")` | Open output file handle in write mode |
| 2 | `handle.write(f"accuracy: ...")` | Record global test set accuracy score |
| 3 | `handle.write(classification_report(...))` | Record class-specific precision, recall, and f1-scores |
| 4 | `handle.write(f"{prediction} ({prob:.2%})...")` | Log each unseen review with its predicted label and confidence |

## 14. Self-Review Questions
1. Why is the Fake Review Spotter accurately described as a "pattern finder" rather than a "lie detector"?
2. What causes an honest, satisfied customer review to be misclassified as fake?
3. How can an adversarial fraud actor craft a fake review that bypasses a bag-of-words Naive Bayes classifier?

## 15. Key Takeaways and Summary
- Bag-of-words classifiers detect stylistic lexical patterns, not the factual truthfulness of claims.
- Honest enthusiastic customers face high false-positive risks due to shared promotional vocabulary with spam.
- Adversarial actors can easily evade n-gram filters by adopting neutral, understated, or technical phrasing.
- Robust real-world anti-abuse platforms must combine text NLP with multi-signal user and transaction metadata.
