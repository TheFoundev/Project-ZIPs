# Module 6, Lesson 4: Real-World Multimodal and Metadata Extensions

## 1. Concept Overview
While analyzing the lexical text of a review is an essential starting point, text-only classification is inherently vulnerable to adversarial evasion, honest false positives, and semantic ambiguity. In industrial enterprise systems—such as Amazon Customer Reviews, Google Play Store ratings, or Yelp Trust & Safety—text NLP is only one component of a comprehensive, **multimodal fraud prevention architecture**.

This lesson explores how real-world anti-fraud systems augment text models with tabular metadata (star ratings, verified purchase status, account age, review velocity), how to architect unified multi-feature pipelines in scikit-learn using `ColumnTransformer`, and how modern platforms leverage behavioral graphs and deep learning to protect marketplace integrity.

## 2. Key Terms and Definitions
- **Multimodal Architecture:** A machine learning system that fuses diverse data modalities—such as raw unstructured text, structured tabular metadata, relational graph structures, and time-series telemetry—into a unified decision engine.
- **Review Metadata:** Contextual attributes surrounding a review submission, including star rating, verified purchase status, helpful votes, timestamp, and submission device.
- **`ColumnTransformer`:** A scikit-learn preprocessing utility that applies separate transformers to distinct columns of an input DataFrame (e.g., `CountVectorizer` on text, `StandardScaler` on numerical features, `OneHotEncoder` on categorical flags) and concatenates the resulting matrices into a single feature space.
- **Behavioral Velocity:** The rate at which an account performs actions over time (e.g., submitting 45 reviews in 3 minutes), serving as a powerful heuristic for detecting automated bot networks.
- **Bipartite Review Graph:** A network representation connecting user nodes to product nodes via review edges, enabling Graph Neural Networks (GNNs) to uncover collusive review rings.

## 3. Why This Matters in Fake Review Spotter
In our foundational project, our dataset `reviews.csv` contains two columns: `review` and `label`. While this minimal setup allows beginner students to master text vectorization and Naive Bayes, in professional engineering environments you will virtually never rely solely on text.

Consider an adversarial fake review:
`"The product functions as described. Dimensions match specifications."`
- **Text model prediction:** Real (99% confidence).
- **Metadata signals:**
  - Account created: 12 minutes ago.
  - Reviews submitted: 84 reviews in the last hour across unrelated merchants.
  - Verified Purchase: **False**.
  - Reviewer IP: Originates from a known datacenter proxy subnet.
  - Star rating: 5 stars (despite neutral text).

When metadata is incorporated, the fraud detection system immediately identifies the submission as malicious with overwhelming certainty, completely neutralizing the text model's blind spot!

## 4. Theory Deep Dive
### High-Value Metadata Signals in Review Verification
1. **Transaction Verification (`verified_purchase`):**
   A boolean flag confirming whether the reviewing account actually purchased the item from the platform at full market price. Fake review brokers frequently instruct agents to review unpurchased items or exploit $0 promo codes.
2. **Sentiment-Rating Divergence:**
   Measuring mathematical misalignment between the numerical star rating and the sentiment of the text. For example, a 5-star rating coupled with negative or completely generic text is a strong heuristic for bot automation.
3. **Account Age & History:**
   Newly created "throwaway" accounts submitting glowing reviews for low-reputation products represent high fraud risk compared to ten-year-old Prime accounts with hundreds of verified purchases.
4. **Temporal Clustering (Review Bursts):**
   Sudden spikes in review submission volume (e.g., a product receiving 200 5-star reviews over a single weekend after months of silence) indicate coordinated review injection campaigns.

### The `ColumnTransformer` Architecture
In scikit-learn, combining text and tabular features into a single pipeline is accomplished via `sklearn.compose.ColumnTransformer`.

```text
INPUT DATAFRAME:
[ review (text) | verified (bool) | account_age_days (int) | rating (1-5) ]
       |
       v
+--------------------------------------------------------------------------+
| ColumnTransformer                                                        |
|                                                                          |
| Branch 1: text column          -> CountVectorizer(ngram_range=(1,2))    |
| Branch 2: verified column      -> OneHotEncoder(drop='if_binary')        |
| Branch 3: account_age, rating  -> StandardScaler()                       |
+--------------------------------------------------------------------------+
       |
       v  (Horizontal Concatenation: scipy.sparse.hstack)
COMBINED FEATURE MATRIX: shape (n_samples, n_text_features + n_meta_features)
       |
       v
CLASSIFIER: HistGradientBoostingClassifier or LogisticRegression
```

Because Naive Bayes requires strictly non-negative integer or count features (when using `MultinomialNB`), classifiers that support heterogeneous continuous and sparse features—such as `HistGradientBoostingClassifier`, `LogisticRegression`, or `RandomForestClassifier`—are preferred when deploying multimodal architectures.

## 5. Architectural Diagram / ASCII Flow
```text
                    RAW USER SUBMISSION
                             |
         +-------------------+-------------------+
         |                                       |
    REVIEW TEXT                             METADATA
"Works as described..."              {rating: 5, verified: False,
         |                            account_age_days: 1}
         v                                       |
+----------------------+                         v
| CountVectorizer /    |              +----------------------+
| TF-IDF Vectorizer    |              | OneHotEncoder &      |
| (n-gram frequencies) |              | StandardScaler       |
+----------------------+              +----------------------+
         |                                       |
         +-------------------+-------------------+
                             |
                             v
                  [ ColumnTransformer ]
                             |
                             v
                Combined Feature Vector
                             |
                             v
             [ Gradient Boosted Trees / MLP ]
                             |
                             v
                 FINAL ABUSE RISK SCORE (0-100)
```

## 6. Implementation Code Walkthrough
Let us construct a production-ready multimodal feature pipeline:

```python
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.pipeline import Pipeline

# 1. Mock enriched enterprise review dataset
data = pd.DataFrame({
    "review": [
        "AMAZING best product ever 5 stars buy now!",
        "The item arrived on time. Battery works fine.",
        "Perfect quality, fast shipping, five stars!",
        "Works as described, but setup instructions were vague.",
        "Conforms to specifications. Standard unit.",  # Adversarial fake
    ],
    "verified_purchase": [False, True, False, True, False],
    "account_age_days": [2, 450, 1, 890, 3],
    "star_rating": [5, 4, 5, 3, 5],
    "label": ["fake", "real", "fake", "real", "fake"]
})

# 2. Architect ColumnTransformer
preprocessor = ColumnTransformer(
    transformers=[
        # Process text with TF-IDF
        ("text", TfidfVectorizer(ngram_range=(1, 2), stop_words="english"), "review"),
        # Process categorical boolean
        ("cat", OneHotEncoder(drop="if_binary"), ["verified_purchase"]),
        # Scale continuous numerical metadata
        ("num", StandardScaler(), ["account_age_days", "star_rating"]),
    ]
)

# 3. Assemble full pipeline
multimodal_pipeline = Pipeline([
    ("preprocessor", preprocessor),
    ("classifier", HistGradientBoostingClassifier(random_state=42))
])

# 4. Train pipeline
X = data[["review", "verified_purchase", "account_age_days", "star_rating"]]
y = data["label"]
multimodal_pipeline.fit(X, y)

print("Multimodal pipeline successfully fitted!")
print(f"Features engineered: {preprocessor.fit_transform(X).shape[1]}")
```

## 7. Edge Cases and Pitfalls
1. **Feature Scale Disparities:**
   Combining unbounded integers (e.g., `account_age_days = 2500`) with binary text counts without normalization causes linear and gradient-based models to over-weight the large numeric features. Always apply `StandardScaler` or `RobustScaler`.
2. **Missing Metadata Fields:**
   Guest checkouts or third-party syndication feeds often omit account age or verified purchase flags. Pipelines must include an imputer (e.g., `SimpleImputer(strategy='median')`) to prevent runtime crashes on `NaN` values.
3. **Data Leakage in Multimodal Splitting:**
   If splitting by user rather than by review, ensure an individual reviewer's multiple submissions do not leak across training and test splits (`GroupKFold` or `GroupShuffleSplit`).

## 8. Real-World Applications
- **Amazon Customer Review Integrity:** Combines review text sentiment with Amazon Prime membership history, purchase price, return rates, and seller relationship graphs.
- **Yelp Recommendation Software:** Uses over 100 metadata signals (user friend network, review frequency, check-in history) to separate recommended reviews from unrecommended ones.
- **Google Play & Apple App Store:** Detects review bursts generated by incentivized install-and-review farms.

## 9. Practical Exercises (with Success Criteria)
- **Task 4.1:** Identify three non-text metadata features that could catch an adversarial fake review written with calm, neutral language.
- **Task 4.2:** Explain why `MultinomialNB` cannot directly process standardized numerical features produced by `StandardScaler`.
- *Success Criteria:* Task 4.1 lists valid features (e.g., verified purchase status, account age, review velocity, IP clustering); Task 4.2 correctly identifies that `StandardScaler` outputs negative z-scores, violating `MultinomialNB`'s non-negativity constraint.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Root Cause | Fix |
|---|---|---|
| Passing `MultinomialNB` after `StandardScaler` | `StandardScaler` produces negative values; `MultinomialNB` requires non-negative counts | Use `MinMaxScaler`, `HistGradientBoostingClassifier`, or `LogisticRegression` |
| Applying `CountVectorizer` to an entire DataFrame | `CountVectorizer` expects a 1D Series of strings | Use `ColumnTransformer` to route the text column specifically |
| Omitting `drop='if_binary'` in `OneHotEncoder` | Introduces multicollinearity (two redundant columns for True/False) | Specify `drop='if_binary'` for boolean metadata |

## 11. Best Practices and Code Quality
- Design anti-abuse systems with defense-in-depth: combine text NLP, metadata heuristics, and graph relationship analysis.
- Use `ColumnTransformer` to enforce reproducible, leakage-free preprocessing across diverse data types.
- Ensure all metadata features are available at real-time inference latency (avoiding expensive synchronous graph queries in high-throughput paths).

## 12. Learning Connections
- **Previous Lesson:** In Lesson 3, we examined adversarial deception and the limitations of text-only pattern matching.
- **Course Capstone:** This concludes the core modules! Students are now prepared to tackle the Final Project specifications and independent enhancements.

## 13. Step-by-Step Code Walkthrough Table
| Step | Code Expression | Purpose |
|---|---|---|
| 1 | `ColumnTransformer(transformers=[...])` | Define column-specific transformation rules |
| 2 | `("text", TfidfVectorizer(), "review")` | Transform text strings into sparse n-gram matrix |
| 3 | `("num", StandardScaler(), ["age", "rating"])` | Standardize continuous numerical metadata |
| 4 | `Pipeline([("pre", preprocessor), ("clf", ...)])` | Bundle preprocessing and classifier into unified model |

## 14. Self-Review Questions
1. Why is text-only classification insufficient for stopping sophisticated fake review campaigns?
2. What role does `ColumnTransformer` play when building multimodal machine learning pipelines in scikit-learn?
3. Why are Tree-based ensembles (`HistGradientBoostingClassifier`) or `LogisticRegression` preferred over `MultinomialNB` in multimodal pipelines?

## 15. Key Takeaways and Summary
- Production review moderation systems combine text NLP with transaction, account, and temporal metadata.
- `ColumnTransformer` seamlessly joins disparate feature pipelines (text n-grams, scaled numbers, one-hot encoded categories) into a single feature matrix.
- Non-text metadata easily exposes adversarial fake reviews that use neutral language to bypass keyword filters.
- Modern enterprise trust and safety architectures rely on multi-layered defenses, including graph neural networks and human-in-the-loop review queues.
