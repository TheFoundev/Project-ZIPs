# Module 6, Lesson 1: Making Predictions on Unseen Text

## 1. Concept Overview
The ultimate test of any trained machine learning model is inference: generating actionable, reliable predictions on novel, previously unseen data samples. In the Fake Review Spotter project, our trained scikit-learn `Pipeline` encapsulates both text feature extraction via `CountVectorizer` and probabilistic classification via `MultinomialNB`. During inference, raw text strings are supplied directly to `model.predict()`, bypassing any need for manual n-gram parsing or intermediate matrix construction.

This lesson explores how scikit-learn manages real-time text inference, how the pipeline handles novel out-of-vocabulary (OOV) tokens, and how production scripts systematically batch and evaluate new customer reviews.

## 2. Key Terms and Definitions
- **Inference (Scoring):** The phase in the machine learning lifecycle where a trained model processes new input data to predict target class labels or regression values without altering its internal weights or parameters.
- **Pipeline Inference (`model.predict()`):** A high-level scikit-learn method that automatically passes raw input data through every intermediate transformer step (`transform()`) before invoking the final estimator's prediction routine.
- **Out-of-Vocabulary (OOV) Tokens:** Words or n-grams present in incoming inference texts that were never observed in the training corpus vocabulary.
- **Batch Inference:** Supplying an iterable sequence (e.g., Python list, pandas Series) of multiple review texts to `model.predict()` simultaneously, allowing vectorized, high-throughput classification.
- **Prediction Vector:** The 1D numpy array of predicted categorical class strings (e.g., `np.array(['fake', 'real', 'fake'])`) returned by `model.predict()`.

## 3. Why This Matters in Fake Review Spotter
When an e-commerce platform receives incoming customer reviews, it cannot afford to retrain models or manually engineer n-gram representations per submission. The system requires an instantaneous, turnkey mechanism that takes raw user-submitted text and outputs whether the review is legitimate or fabricated.

In `main.py`, we test the spotter on four novel review strings:
```python
new_reviews = [
    "AMAZING!!! Best product ever. Buy it now, you will not regret it!",
    "The item arrived on time. The battery is fine, but the cable is short.",
    "Perfect quality, perfect price, perfect everything. Five stars!",
    "It works as described. Shipping took a week longer than expected.",
]
new_predictions = model.predict(new_reviews)
```
Understanding how `model.predict()` evaluates these strings guarantees our system behaves predictably in production.

## 4. Theory Deep Dive
### The scikit-learn Pipeline Inference Workflow
When `model.predict(new_reviews)` is executed on a fitted pipeline, the following exact sequence occurs under the hood:
1. **Transformer Stage (`named_steps["vectorizer"]`):**
   - The vectorizer executes `transform(new_reviews)`. Notice it calls `transform()`, **never** `fit()` or `fit_transform()`.
   - The text undergoes preprocessing: lowercasing, stop-word removal, punctuation stripping, and tokenization.
   - For each token or bigram, the vectorizer looks up its integer index in the static `vocabulary_` dictionary created during training.
   - Any token not found in `vocabulary_` is discarded as an OOV term.
   - The result is a sparse document-term matrix $X_{\text{new}}$ of shape `(n_samples, n_features)`, where `n_features` strictly equals the training vocabulary dimension (592 features in our 60-sample training corpus).

2. **Estimator Stage (`named_steps["classifier"]`):**
   - The classifier receives $X_{\text{new}}$.
   - For each row $i$ and class $c \in \{\text{fake}, \text{real}\}$, it computes the log unnormalized posterior:
     $$\log P(c \mid \mathbf{x}) \propto \log P(c) + \sum_{j=1}^{V} x_{ij} \log P(w_j \mid c)$$
   - The classifier selects the class with the maximum posterior score:
     $$\hat{y}_i = \arg\max_{c} \left[ \log P(c) + \sum_{j=1}^{V} x_{ij} \log P(w_j \mid c) \right]$$
   - It maps the winning class index back to the class label string stored in `classifier.classes_`.

### Handling Out-of-Vocabulary (OOV) Tokens
What happens when an incoming review contains completely novel vocabulary? For example:
`"Quantum-encrypted hyper-luminal gadget arrived swiftly."`
If none of these words exist in the training vocabulary, the vectorizer produces an entirely zero row (`[0, 0, ..., 0]`). In this edge case, the summation term vanishes:
$$\sum_{j=1}^{V} x_{ij} \log P(w_j \mid c) = 0$$
The prediction simplifies purely to the class prior:
$$\hat{y}_i = \arg\max_{c} \log P(c)$$
Since our training partition was stratified 50/50 (30 fake, 30 real), $\log P(\text{fake}) = \log P(\text{real}) = \log(0.5)$. When priors are tied, MultinomialNB defaults deterministically to the first class in `classes_` (index 0, which is `"fake"` alphabetically).

## 5. Architectural Diagram / ASCII Flow
```text
INCOMING RAW REVIEWS:
["AMAZING!!! Best product ever...", "The item arrived on time..."]
       |
       v
+-------------------------------------------------------------+
| scikit-learn Pipeline (model.predict)                       |
|                                                             |
| 1. named_steps["vectorizer"].transform(new_reviews)         |
|    - Lowercase: "amazing!!! best product ever..."           |
|    - Strip punctuation: "amazing best product ever"         |
|    - Drop stop words: ['amazing', 'best', 'product']        |
|    - Extract unigrams & bigrams: ['amazing', 'best', ...]   |
|    - Project against fixed 592-feature vocabulary           |
|    - Yields Sparse Matrix X_new: shape (4, 592)             |
|                                                             |
| 2. named_steps["classifier"].predict(X_new)                 |
|    - MultinomialNB evaluates log-likelihoods per sample     |
|    - argmax log P(c|x) determines winning class index       |
|    - Maps integer index -> classes_ array                   |
+-------------------------------------------------------------+
       |
       v
OUTPUT PREDICTION VECTOR:
array(['fake', 'real', 'fake', 'real'], dtype='<U4')
```

## 6. Implementation Code Walkthrough
Let us review the end-to-end inference script:

```python
from pathlib import Path
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split

# 1. Train the pipeline
data_path = Path("data/reviews.csv")
df = pd.read_csv(data_path)
X_train, X_test, y_train, y_test = train_test_split(
    df["review"], df["label"], test_size=0.25, random_state=42, stratify=df["label"]
)

model = Pipeline([
    ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
    ("classifier", MultinomialNB()),
])
model.fit(X_train, y_train)

# 2. Define unseen test reviews
new_reviews = [
    "AMAZING!!! Best product ever. Buy it now, you will not regret it!",
    "The item arrived on time. The battery is fine, but the cable is short.",
    "Perfect quality, perfect price, perfect everything. Five stars!",
    "It works as described. Shipping took a week longer than expected.",
]

# 3. Execute batch inference
new_predictions = model.predict(new_reviews)

# 4. Display results
for text, pred in zip(new_reviews, new_predictions):
    print(f"[{pred.upper():4s}] -> {text}")
```

Expected terminal output:
```text
[FAKE] -> AMAZING!!! Best product ever. Buy it now, you will not regret it!
[REAL] -> The item arrived on time. The battery is fine, but the cable is short.
[FAKE] -> Perfect quality, perfect price, perfect everything. Five stars!
[REAL] -> It works as described. Shipping took a week longer than expected.
```

## 7. Edge Cases and Pitfalls
1. **Passing a Single Raw String Directly:**
   Calling `model.predict("Great product!")` causes a severe runtime bug. In Python, a string is an iterable of single characters (`['G', 'r', 'e', 'a', ...]`). The vectorizer interprets each individual character as a distinct document, resulting in dozens of single-character predictions.
   *Resolution:* Always enclose single strings in a list: `model.predict(["Great product!"])`.
2. **Calling `fit()` During Inference:**
   Retraining the pipeline on incoming unseen reviews overwrites the learned feature weights and vocabulary, destroying model performance. Always call `model.predict()`, never `model.fit()` or `model.fit_transform()`.
3. **Empty or Whitespace-Only Text:**
   If a user submits `""` or `"   "`, the vectorizer extracts 0 tokens. As explained in Section 4, the model defaults to class priors. Production systems should validate string length before sending reviews to the inference pipeline.

## 8. Real-World Applications
- **E-Commerce Moderation Queues:** Automated pre-publication screening flags suspected fake reviews before they appear publicly on product pages.
- **App Store Rating Integrity:** Mobile marketplaces scan app reviews to detect orchestrated 5-star review farming campaigns.
- **Hotel & Travel Platforms:** Booking engines detect automated bot reviews generated by competitors or paid reputation agencies.

## 9. Practical Exercises (with Success Criteria)
- **Task 1.1:** Test the trained model on an honest review: `"Setup was straightforward, but the instruction manual had typos."` Record the predicted label.
- **Task 1.2:** Test the trained model on a spam review: `"WOW BEST EVER 10 STARS BUY RIGHT NOW!!!"` Record the predicted label.
- *Success Criteria:* Task 1.1 must output `'real'`; Task 1.2 must output `'fake'`.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Root Cause | Fix |
|---|---|---|
| Passing single string `model.predict(text)` | Strings are sequences of characters | Pass a list: `model.predict([text])` |
| Calling `fit_transform` on inference data | Re-fits the vectorizer on new data, leaking or erasing vocabulary | Call `model.predict()` on the pipeline |
| Expecting probabilities from `predict()` | `predict()` returns discrete class labels, not numeric scores | Use `model.predict_proba()` for probabilities |

## 11. Best Practices and Code Quality
- Enclose all inference inputs in lists or pandas Series to preserve 2D dimensional expectations.
- Encapsulate preprocessing and classification strictly within a scikit-learn `Pipeline`.
- Log incoming review lengths and empty-string occurrences before invoking inference.

## 12. Learning Connections
- **Previous Lesson:** In Module 5, Lesson 4, we rendered confusion matrices and verified test-set classification metrics.
- **Next Lesson:** In Module 6, Lesson 2, we explore `model.predict_proba()` to quantify prediction confidence and uncertainty.

## 13. Step-by-Step Code Walkthrough Table
| Step | Code Expression | Purpose |
|---|---|---|
| 1 | `new_reviews = [...]` | Define novel review strings unseen during training |
| 2 | `model.predict(new_reviews)` | Run batch inference through vectorizer and classifier |
| 3 | `for text, pred in zip(...)` | Pair original text with predicted class label |
| 4 | `handle.write(...)` | Persist classification results to disk (`predictions.txt`) |

## 14. Self-Review Questions
1. Why does calling `model.predict("hello")` fail or produce unexpected output, whereas `model.predict(["hello"])` works correctly?
2. How does `CountVectorizer` handle tokens in new reviews that were never seen during training?
3. If an unseen review contains zero recognized vocabulary words, what determines the model's predicted class label?

## 15. Key Takeaways and Summary
- `model.predict()` provides end-to-end inference on raw strings through the scikit-learn Pipeline.
- The pipeline's vectorizer automatically tokenizes and projects unseen text onto the fixed training vocabulary, discarding OOV terms.
- Batching review strings in Python lists enables rapid, vectorized inference across multiple samples.
- The spotter accurately classifies novel unseen reviews as either `fake` or `real` based on learned token patterns.
