# Module 6, Lesson 2: Probability Estimation and Confidence Scores

## 1. Concept Overview
While discrete class predictions (`model.predict()`) tell us *what* label the model chose, probability estimation (`model.predict_proba()`) tells us *how confident* the model is in that decision. A prediction of `"fake"` with 99.8% probability represents a decisive detection, whereas a prediction of `"fake"` with 51.2% probability represents borderline uncertainty that may warrant human inspection.

In this lesson, we study how Multinomial Naive Bayes computes class posterior probabilities, how to extract and interpret confidence scores in scikit-learn, and how production moderation systems leverage confidence thresholds to separate automated actions from manual review queues.

## 2. Key Terms and Definitions
- **Class Posterior Probability ($P(y = c \mid \mathbf{x})$):** The estimated mathematical probability that an input text $\mathbf{x}$ belongs to target class $c$, conditioned on the observed words.
- **`model.predict_proba()`:** A scikit-learn method returning a 2D float array of shape `(n_samples, n_classes)`, where each entry $[i, j]$ contains the estimated probability of sample $i$ belonging to class $j$.
- **`classifier.classes_`:** An attribute of scikit-learn estimators storing the sorted list of target class labels (e.g., `array(['fake', 'real'])`), establishing the exact column index mapping for `predict_proba()`.
- **Confidence Score:** The maximum predicted probability across all candidate classes for a given sample, representing the model's certainty: $\max_c P(y = c \mid \mathbf{x})$.
- **Confidence Threshold:** A configurable decision boundary (e.g., $\tau = 0.85$) below which predictions are flagged as uncertain and routed to human moderators.

## 3. Why This Matters in Fake Review Spotter
In an e-commerce platform, taking automated actions—such as deleting a review or suspending a merchant—carries severe financial and legal ramifications if the model makes a mistake. If our classifier flags an authentic review as fake with 52% confidence, automatically deleting it punishes an honest customer.

By extracting probabilities via `model.predict_proba()`, we can:
1. Automatically delete or block reviews when fake confidence exceeds 95%.
2. Route borderline reviews (confidence between 50% and 75%) to human moderation queues.
3. Automatically approve reviews when real confidence exceeds 90%.

In `main.py`, we calculate and format these exact probabilities:
```python
new_probabilities = model.predict_proba(new_reviews)
classes = list(model.named_steps["classifier"].classes_)
for review, prediction, probability in zip(new_reviews, new_predictions, new_probabilities):
    confidence = probability[classes.index(prediction)]
    print(f"  {prediction:4s} ({confidence:.0%}) -> {review}")
```

## 4. Theory Deep Dive
### Mathematical Computation of `predict_proba()`
In Module 4, we saw that Multinomial Naive Bayes computes unnormalized log posterior scores:
$$S_c = \log P(c) + \sum_{j=1}^{V} x_j \log P(w_j \mid c)$$
Because naive Bayes calculations are conducted in log-space to prevent floating-point underflow, scikit-learn converts these unnormalized log scores back into valid probabilities summing to 1.0 using the **Softmax (Log-Sum-Exp)** transformation:
$$P(y = c \mid \mathbf{x}) = \frac{\exp(S_c)}{\sum_{k} \exp(S_k)} = \frac{1}{1 + \exp(S_{\text{other}} - S_c)}$$

### Why Naive Bayes Probabilities Are Often Extreme (0% or 100%)
Students frequently notice that Naive Bayes outputs extreme confidence scores—often reporting 100% or 0%:
- `"AMAZING!!! Best product ever..."` $\to$ **fake (100%)**
- `"The item arrived on time. The battery is fine..."` $\to$ **real (100%)**

Why does this happen?
Under the conditional independence assumption, the model multiplies independent probabilities for every token:
$$P(\mathbf{x} \mid c) = \prod_{j=1}^{V} P(w_j \mid c)^{x_j}$$
When a text contains multiple strongly biased clues (e.g., `best`, `buy`, `stars`, `market`), the log-likelihood ratio accumulates rapidly:
$$\sum_{j} x_j \left[ \log P(w_j \mid \text{fake}) - \log P(w_j \mid \text{real}) \right] \gg 10$$
When exponentiated, $\exp(15) \approx 3.2 \times 10^6$, causing the normalized probability to round to $1.0000$ (100.0%) within standard floating-point precision.

While Naive Bayes is an outstanding **ranker** and **classifier** (its argmax is highly accurate), its raw probabilities are notorious for being overconfident (poorly calibrated). In production, techniques like Platt Scaling or Isotonic Regression are often applied to calibrate Naive Bayes output probabilities.

## 5. Architectural Diagram / ASCII Flow
```text
INPUT SAMPLE: "AMAZING!!! Best product ever..."
       |
       v
+--------------------------------------------------------------+
| MultinomialNB.predict_proba()                                |
|                                                              |
| 1. Compute log scores:                                       |
|    S_fake = log P(fake) + sum(x_i * log P(w_i | fake)) = -4.1 |
|    S_real = log P(real) + sum(x_i * log P(w_i | real)) = -18.7|
|                                                              |
| 2. Exponentiate & Normalize (Softmax):                       |
|    exp(-4.1) = 0.01657                                       |
|    exp(-18.7) = 0.0000000075                                 |
|    P(fake) = 0.01657 / (0.01657 + 0.0000000075) = 0.9999995  |
|    P(real) = 0.0000005                                       |
+--------------------------------------------------------------+
       |
       v
PROBABILITY MATRIX: [[0.9999995, 0.0000005]]
Mapped via classes_ ['fake', 'real']:
  fake: 100%
  real:   0%
Winning prediction: "fake" with 100% confidence.
```

## 6. Implementation Code Walkthrough
Let us examine the complete code to inspect probabilities for unseen reviews:

```python
import numpy as np
from sklearn.pipeline import Pipeline

# Assuming model is already trained
new_reviews = [
    "AMAZING!!! Best product ever. Buy it now, you will not regret it!",
    "The item arrived on time. The battery is fine, but the cable is short.",
    "Perfect quality, perfect price, perfect everything. Five stars!",
    "It works as described. Shipping took a week longer than expected.",
]

# 1. Retrieve classes array
classifier = model.named_steps["classifier"]
classes = list(classifier.classes_)
print(f"Target classes: {classes}")  # ['fake', 'real']

# 2. Extract probability distribution
probs = model.predict_proba(new_reviews)
preds = model.predict(new_reviews)

# 3. Print tabular confidence report
print(f"{'PREDICTION':<6} | {'CONFIDENCE':<10} | {'P(fake)':<8} | {'P(real)':<8} | REVIEW")
print("-" * 80)
for review, pred, prob in zip(new_reviews, preds, probs):
    fake_prob = prob[classes.index("fake")]
    real_prob = prob[classes.index("real")]
    confidence = prob[classes.index(pred)]
    snippet = review if len(review) < 40 else review[:37] + "..."
    print(f"{pred:<6} | {confidence:>9.1%} | {fake_prob:>7.3f} | {real_prob:>7.3f} | {snippet}")
```

Expected output:
```text
Target classes: ['fake', 'real']
PREDICTION | CONFIDENCE | P(fake)  | P(real)  | REVIEW
--------------------------------------------------------------------------------
fake       |     100.0% |   1.000  |   0.000  | AMAZING!!! Best product ever. Buy it...
real       |     100.0% |   0.000  |   1.000  | The item arrived on time. The batte...
fake       |     100.0% |   1.000  |   0.000  | Perfect quality, perfect price, per...
real       |      99.3% |   0.007  |   0.993  | It works as described. Shipping too...
```

## 7. Edge Cases and Pitfalls
1. **Assuming Column 0 Is Always the Positive Class:**
   Never hardcode `probs[:, 1]` assuming index 1 is `"real"` or `"fake"`. Scikit-learn sorts classes alphabetically (`['fake', 'real']`). Always dynamically resolve class positions using `classes.index("fake")`.
2. **Extreme Confidence Distortion:**
   Because Naive Bayes multiplies feature probabilities under the independence assumption, probabilities tend to cluster near 0.0 or 1.0. Do not interpret a 99.9% Naive Bayes score as an empirical error rate of 1-in-1,000; the ranking is accurate, but the probabilities are uncalibrated.
3. **Ambiguity on OOV Reviews:**
   When an incoming text contains zero training tokens, Naive Bayes outputs the prior distribution: `[0.50, 0.50]`. A production system must flag reviews with $\approx 50\%$ confidence as "insufficient information" rather than arbitrarily picking a default label.

## 8. Real-World Applications
- **Risk-Based Moderation Triage:** Tiered actions based on confidence: auto-quarantine (>95% fake), manual review (60–95%), auto-publish (<40% fake).
- **Merchant Appeal Dashboards:** Exposing model confidence scores to human dispute investigators to provide context on why an automated flag was triggered.
- **Active Learning Loops:** Collecting incoming reviews with lowest model confidence ($45\% \le P \le 55\%$) and sending them to human annotators for ground-truth labeling to retrain future models.

## 9. Practical Exercises (with Success Criteria)
- **Task 2.1:** Write a Python function `filter_uncertain_reviews(model, reviews, threshold=0.75)` that returns only reviews where the top class probability is strictly less than `threshold`.
- **Task 2.2:** Test this function on a neutral review containing zero strong clues: `"Average product, blue plastic casing."`
- *Success Criteria:* The function identifies the neutral review as uncertain because its top class probability falls between 50% and 75%.

## 10. Common Mistakes and Troubleshooting
| Common Mistake | Root Cause | Fix |
|---|---|---|
| Hardcoding `prob[0]` as fake | Class indices depend on estimator sorting | Use `classes = list(model.classes_); idx = classes.index('fake')` |
| Calling `predict_proba` before `fit` | Model parameters do not exist | Ensure `model.fit(X_train, y_train)` is executed first |
| Treating uncalibrated Naive Bayes probabilities as exact risks | Independence assumption inflates posterior confidence | Use probabilities for ranking or calibrate using `CalibratedClassifierCV` |

## 11. Best Practices and Code Quality
- Always retrieve class column order dynamically via `model.named_steps["classifier"].classes_`.
- Format probabilities as percentages (`{confidence:.1%}`) for human-readable console and log outputs.
- Implement an explicit uncertainty band (e.g., $0.40 \le P(\text{fake}) \le 0.65$) for human-in-the-loop escalation.

## 12. Learning Connections
- **Previous Lesson:** In Lesson 1, we executed discrete inference via `model.predict()`.
- **Next Lesson:** In Lesson 3, we analyze model vulnerabilities, adversarial evasion, and why statistical pattern finders differ from true lie detectors.

## 13. Step-by-Step Code Walkthrough Table
| Step | Code Expression | Purpose |
|---|---|---|
| 1 | `classes = list(clf.classes_)` | Extract list of target classes in exact column order |
| 2 | `probs = model.predict_proba(texts)` | Obtain $(N, 2)$ matrix of class posterior probabilities |
| 3 | `idx = classes.index(prediction)` | Identify column index corresponding to predicted class |
| 4 | `conf = probs[i, idx]` | Retrieve exact scalar confidence for winning label |

## 14. Self-Review Questions
1. Why does Multinomial Naive Bayes tend to output probabilities very close to 1.0 or 0.0?
2. How do you determine which column in `model.predict_proba()` corresponds to the `"real"` review class?
3. What probability distribution does `predict_proba()` output for a review whose words never appeared in the training vocabulary?

## 15. Key Takeaways and Summary
- `model.predict_proba()` outputs the full posterior probability distribution across all target classes.
- Scikit-learn orders columns according to `classifier.classes_`, which must be referenced dynamically.
- Naive Bayes confidence scores are effective for ranking but tend to be overconfident due to the feature independence assumption.
- Confidence thresholds enable production systems to separate automated moderation actions from human-in-the-loop review queues.
