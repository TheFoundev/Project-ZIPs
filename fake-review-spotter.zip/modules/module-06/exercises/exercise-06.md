# Module 6 Practical Exercises: Predictions, Limitations & Extensions

## Exercise Overview
In this concluding lab, you will deploy your trained Fake Review Spotter model for real-time inference, extract and interpret class posterior probabilities, craft adversarial test cases to explore model boundaries, and architect an auditable output persistence routine.

---

## Exercise 1: Single and Batch Pipeline Inference
### Objective
Demonstrate how the scikit-learn `Pipeline` abstracts feature transformation and classifier inference for novel, unseen customer review strings.

### Requirements
1. Instantiate and train the baseline `Pipeline([('vectorizer', CountVectorizer(stop_words='english', ngram_range=(1,2))), ('classifier', MultinomialNB())])` on `X_train` and `y_train` from `data/reviews.csv`.
2. Define a batch of four novel review strings:
   ```python
   new_reviews = [
       "AMAZING!!! Best product ever. Buy it now, you will not regret it!",
       "The item arrived on time. The battery is fine, but the cable is short.",
       "Perfect quality, perfect price, perfect everything. Five stars!",
       "It works as described. Shipping took a week longer than expected.",
   ]
   ```
3. Generate discrete predictions using `model.predict(new_reviews)`.
4. Print each review paired with its predicted class label (`'fake'` or `'real'`).

### Hints
- Remember that `model.predict()` requires an iterable of strings (such as a Python list or pandas Series). Passing a single raw string directly will treat each individual character as a document.

---

## Exercise 2: Probability Extraction and Uncertainty Flagging
### Objective
Extract posterior probability distributions using `model.predict_proba()` and build a confidence triage function that flags borderline reviews.

### Requirements
1. Extract the class probability array for `new_reviews` using `model.predict_proba(new_reviews)`.
2. Dynamically determine class column indices using `model.named_steps["classifier"].classes_`.
3. For each review, calculate the model's confidence percentage:
   $$\text{confidence} = \max(P(\text{fake}), P(\text{real}))$$
4. Implement a function `flag_uncertain_reviews(reviews, predictions, probabilities, threshold=0.80)`:
   - If confidence is $\ge \text{threshold}$, mark status as `"AUTO_ACTION"`.
   - If confidence is $< \text{threshold}$, mark status as `"MANUAL_REVIEW"`.
5. Display the formatted results in a console table.

---

## Exercise 3: Adversarial Review Stress-Testing
### Objective
Probe the boundaries and vulnerabilities of word-frequency classifiers by deliberately crafting adversarial reviews.

### Requirements
1. **Craft Adversarial Review A (Targeting False Positive):**
   Write an authentic, highly enthusiastic review from a genuine satisfied customer that causes the model to predict `'fake'` with $\ge 90\%$ confidence. (Hint: Use words like `best`, `wow`, `stars`, `buy`).
2. **Craft Adversarial Review B (Targeting False Negative):**
   Write a 100% fabricated, paid fake review that causes the model to predict `'real'` with $\ge 90\%$ confidence. (Hint: Use calm, neutral, or slightly critical words like `works`, `support`, `instructions`, `arrived`).
3. Evaluate both reviews with `model.predict()` and `model.predict_proba()`.
4. Document why the model was deceived in a short commentary block.

---

## Exercise 4: Production Output Persistence (`predictions.txt`)
### Objective
Replicate the project's production logging specification by writing test-set evaluation metrics and novel review predictions to `outputs/predictions.txt`.

### Requirements
1. Ensure the output directory `outputs/` exists using `Path("outputs").mkdir(exist_ok=True)`.
2. Open `outputs/predictions.txt` with UTF-8 encoding.
3. Write the exact test-set accuracy formatted to 4 decimal places: `accuracy: 1.0000\n\n`.
4. Write the complete scikit-learn `classification_report(y_test, predictions, zero_division=0)`.
5. Write the header `\nNew reviews:\n`.
6. For each sample in `new_reviews`, write a line formatted as:
   `{prediction} ({probability:.2%}) -> {review}\n`
7. Verify that the generated file matches the project reference specification.

---

## Reference Solutions

```python
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline

# -------------------------------------------------------------
# Setup & Training
# -------------------------------------------------------------
BASE = Path(__file__).resolve().parent.parent.parent
DATA = BASE / "data" / "reviews.csv"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)

df = pd.read_csv(DATA)
X_train, X_test, y_train, y_test = train_test_split(
    df["review"], df["label"], test_size=0.25, random_state=42, stratify=df["label"]
)

model = Pipeline([
    ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
    ("classifier", MultinomialNB()),
])
model.fit(X_train, y_train)

# -------------------------------------------------------------
# Solution 1: Batch Inference
# -------------------------------------------------------------
new_reviews = [
    "AMAZING!!! Best product ever. Buy it now, you will not regret it!",
    "The item arrived on time. The battery is fine, but the cable is short.",
    "Perfect quality, perfect price, perfect everything. Five stars!",
    "It works as described. Shipping took a week longer than expected.",
]
new_predictions = model.predict(new_reviews)
print("=== Exercise 1: Batch Predictions ===")
for rev, pred in zip(new_reviews, new_predictions):
    print(f"[{pred.upper():4s}] {rev}")

# -------------------------------------------------------------
# Solution 2: Probability Extraction & Uncertainty
# -------------------------------------------------------------
new_probabilities = model.predict_proba(new_reviews)
classes = list(model.named_steps["classifier"].classes_)

def flag_uncertain_reviews(reviews, predictions, probabilities, threshold=0.80):
    results = []
    for r, pred, prob in zip(reviews, predictions, probabilities):
        conf = prob[classes.index(pred)]
        status = "AUTO_ACTION" if conf >= threshold else "MANUAL_REVIEW"
        results.append((pred, conf, status, r))
    return results

print("\n=== Exercise 2: Confidence & Triage ===")
triage_results = flag_uncertain_reviews(new_reviews, new_predictions, new_probabilities, threshold=0.80)
for pred, conf, status, rev in triage_results:
    print(f"[{status:13s}] {pred:4s} ({conf:6.1%}) -> {rev[:40]}...")

# -------------------------------------------------------------
# Solution 3: Adversarial Stress-Testing
# -------------------------------------------------------------
adversarial_suite = [
    # Honest customer ecstatic -> expected FP
    "Best purchase of my life! Absolutely loved it! 10 stars buy it now!",
    # Paid bot deceptive -> expected FN
    "The item functions as described. Customer support helped resolve setup questions.",
]
adv_preds = model.predict(adversarial_suite)
adv_probs = model.predict_proba(adversarial_suite)

print("\n=== Exercise 3: Adversarial Stress Test ===")
for r, pred, prob in zip(adversarial_suite, adv_preds, adv_probs):
    conf = prob[classes.index(pred)]
    print(f"Review: '{r}'\n -> Model Decision: {pred} ({conf:.1%})\n")

# -------------------------------------------------------------
# Solution 4: Output Persistence (predictions.txt)
# -------------------------------------------------------------
test_preds = model.predict(X_test)
acc = accuracy_score(y_test, test_preds)

pred_file = OUT / "predictions.txt"
with open(pred_file, "w", encoding="utf-8") as handle:
    handle.write(f"accuracy: {acc:.4f}\n\n")
    handle.write(classification_report(y_test, test_preds, zero_division=0))
    handle.write("\nNew reviews:\n")
    for review, prediction, probability in zip(new_reviews, new_predictions, new_probabilities):
        handle.write(f"{prediction} ({probability[classes.index(prediction)]:.2%}) -> {review}\n")

print(f"Successfully wrote {pred_file}!")
```

---

## Verification Rubric
| Criteria | Excellent (100%) | Adequate (75%) | Needs Improvement (<50%) |
|---|---|---|---|
| **Pipeline Inference** | Evaluates novel reviews using `model.predict()` without re-vectorization or manual parsing | Runs inference but introduces redundant preprocessing | Hardcodes or incorrectly passes inputs |
| **Probability Extraction** | Correctly maps probabilities to class names using `classifier.classes_` | Extracts probabilities but hardcodes column index 0 or 1 | Unable to extract or explain probabilities |
| **Adversarial Analysis** | Successfully crafts reviews that exploit model blind spots and explains why | Crafts reviews but does not analyze failure modes | Cannot create working adversarial examples |
| **Output Persistence** | Writes `predictions.txt` strictly matching the required format and formatting specs | Writes file with minor formatting or rounding deviations | Fails to write or misses sections |
