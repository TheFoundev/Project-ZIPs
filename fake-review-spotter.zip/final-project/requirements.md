# Final Project Requirements: The Fake Review Spotter

## 1. Project Objective

Your objective in this capstone project is to implement the complete **Fake Review Spotter** pipeline from scratch in Python, following the architecture and implementation standards in `main.py`. Your program must load the dataset, perform stratified splitting, engineer text features using n-grams and stop words, train a Multinomial Naive Bayes classifier inside a scikit-learn pipeline, analyze distinguishing vocabulary clues, evaluate performance, predict on novel reviews with confidence scores, and generate publication-quality visual artifacts.

---

## 2. Functional Requirements

### Requirement 1: Script Setup and Path Resolution
- Configure the non-interactive matplotlib backend using `matplotlib.use("Agg")` prior to importing `matplotlib.pyplot`.
- Define path anchors using `pathlib.Path`:
  - `BASE = Path(__file__).resolve().parent`
  - `DATA = BASE / "data"`
  - `OUT = BASE / "outputs"`
- Ensure `OUT.mkdir(exist_ok=True)` creates the output folder without errors.

### Requirement 2: Data Loading & Verification
- Read `data/reviews.csv` into a pandas DataFrame using `pd.read_csv(DATA / "reviews.csv")`.
- Verify the DataFrame dimensions: exactly 80 rows and 2 columns (`review` and `label`).
- Verify class distribution: 40 `"fake"` reviews and 40 `"real"` reviews.

### Requirement 3: Stratified Partitioning
- Split data into training and test partitions using `train_test_split`:
  - Features: `df["review"]`
  - Target: `df["label"]`
  - `test_size=0.25` (60 training samples, 20 testing samples)
  - `random_state=42`
  - `stratify=df["label"]` to preserve equal class representation.

### Requirement 4: Pipeline Construction & Fitting
- Build an atomic scikit-learn `Pipeline` with two named stages:
  1. `"vectorizer"`: `CountVectorizer(stop_words="english", ngram_range=(1, 2))`
  2. `"classifier"`: `MultinomialNB()`
- Train the pipeline by calling `model.fit(X_train, y_train)`.

### Requirement 5: Model Evaluation
- Generate predictions on the test partition: `predictions = model.predict(X_test)`.
- Compute overall accuracy using `accuracy_score(y_test, predictions)`.
- Generate and print the complete classification metrics table using `classification_report(y_test, predictions, zero_division=0)`.

### Requirement 6: Top Clue Words Extraction
- Implement a helper function `top_words(model: Pipeline, class_index: int, n: int = 10) -> list[str]`:
  - Access `vectorizer = model.named_steps["vectorizer"]` and `classifier = model.named_steps["classifier"]`.
  - Extract feature names via `names = vectorizer.get_feature_names_out()`.
  - Calculate log-likelihood difference scores:
    `scores = classifier.feature_log_prob_[class_index] - classifier.feature_log_prob_[1 - class_index]`
  - Return the top $n$ terms sorted in descending order of score.
- Print the top 10 fake clue words and top 10 real clue words to the console.

### Requirement 7: Inference on Unseen Reviews
- Define a list of test candidate reviews:
  1. `"AMAZING!!! Best product ever. Buy it now, you will not regret it!"`
  2. `"The item arrived on time. The battery is fine, but the cable is short."`
  3. `"Perfect quality, perfect price, perfect everything. Five stars!"`
  4. `"It works as described. Shipping took a week longer than expected."`
- Compute predicted labels using `model.predict(new_reviews)` and predicted class probabilities using `model.predict_proba(new_reviews)`.
- Print each review, its predicted class label, and its percentage confidence score.

### Requirement 8: Visual Artifact Generation
- **Top Words Chart (`outputs/top_words.png`)**:
  - Create a dual-panel figure: `fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))`.
  - Plot horizontal bars (`barh`) using reversed word ordering `words[::-1]` and rank heights `range(1, len(words) + 1)`.
  - Style fake clues with `#c0392b` and real clues with `#2471a3`.
  - Save to `outputs/top_words.png` with `dpi=150` and `bbox_inches="tight"`.
- **Confusion Matrix Graphic (`outputs/confusion_matrix.png`)**:
  - Compute `confusion_matrix(y_test, predictions, labels=["fake", "real"])`.
  - Render using `ConfusionMatrixDisplay` with `cmap="Purples"` and `colorbar=False`.
  - Save to `outputs/confusion_matrix.png`.

### Requirement 9: Report File Output
- Write summary results to `outputs/predictions.txt` with UTF-8 encoding:
  - Header with accuracy formatted as a 4-decimal float.
  - Complete classification report.
  - Formatted predictions on the four unseen test reviews with two-decimal confidence percentages.

### Requirement 10: Written Critical Analysis Report
- Submit a written report (1-2 pages) addressing:
  1. Why this model is a statistical pattern detector rather than a lie detector.
  2. The risk of false positives when applied to authentic enthusiastic reviews.
  3. How an adversary could modify review wording to evade detection.
  4. How you would design a production system incorporating reviewer metadata and star ratings.

---

## 3. Acceptance & Verification Checklist
- [ ] Script runs cleanly from the command line with zero unhandled exceptions.
- [ ] Console shows 100.0% test accuracy under `random_state=42`.
- [ ] Top fake clues list matches reference: `best`, `wow`, `stars`, `wow wow`, `10`, `buy`, etc.
- [ ] Top real clues list matches reference: `liked`, `works`, `support helped`, `support`, etc.
- [ ] `outputs/top_words.png` exists and opens cleanly.
- [ ] `outputs/confusion_matrix.png` exists and displays a clean 2x2 matrix.
- [ ] `outputs/predictions.txt` contains formatted metrics and sample predictions.
- [ ] Written analysis demonstrates deep conceptual understanding of NLP limitations.
