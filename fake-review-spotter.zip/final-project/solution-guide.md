# Mentor Solution Guide: The Fake Review Spotter

## 1. Project Overview & Mentor Checkpoints

This guide provides instructors and mentors with reference checkpoints, pedagogical talking points, expected numerical outputs, and common student errors when implementing the Fake Review Spotter project.

---

## 2. Code Walkthrough & Verification Checkpoints

### Checkpoint 1: Headless Backend & Imports (lines 10-23)
```python
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
```

**What mentors should verify:**
- `matplotlib.use("Agg")` is called **before** `import matplotlib.pyplot as plt`. If imported in reverse order, matplotlib may emit warnings or attempt to open a desktop display on headless machines.
- All required modules are imported from standard library and scikit-learn.

**Common student traps:**
- Forgetting `matplotlib.use("Agg")`, causing CI/CD or remote server headless crashes.
- Importing `GaussianNB` instead of `MultinomialNB`. (Gaussian Naive Bayes is designed for continuous normal distributions, not discrete text word counts).

---

### Checkpoint 2: Path Anchoring & Output Directory (lines 24-28)
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)
```

**What mentors should verify:**
- `BASE` anchors to the script's directory.
- `OUT.mkdir(exist_ok=True)` is executed before attempting to save PNGs or write text files.

---

### Checkpoint 3: The Clue Extraction Function `top_words` (lines 30-36)
```python
def top_words(model: Pipeline, class_index: int, n: int = 10) -> list[str]:
    vectorizer = model.named_steps["vectorizer"]
    classifier = model.named_steps["classifier"]
    names = vectorizer.get_feature_names_out()
    scores = classifier.feature_log_prob_[class_index] - classifier.feature_log_prob_[1 - class_index]
    return list(names[np.argsort(scores)[-n:][::-1]])
```

**Pedagogical Deep Dive:**
- `scores` is the log-likelihood ratio:
  $$\text{scores} = \log P(w \mid c) - \log P(w \mid \text{other}) = \log \frac{P(w \mid c)}{P(w \mid \text{other})}$$
- `np.argsort(scores)[-n:][::-1]` works in two steps:
  1. `[-n:]` selects the indices of the $n$ highest scores (which `np.argsort` places at the end of the sorted array).
  2. `[::-1]` reverses those $n$ indices so the single highest-scoring word comes first.

**Common student traps:**
- Slicing `np.argsort(scores)[:n]` instead of `[-n:]`, which extracts the **least** informative or opposite-class words.
- Accessing `model.steps[0]` instead of `model.named_steps["vectorizer"]`. Named step access is significantly more readable and robust.

---

### Checkpoint 4: Data Partitioning & Stratification (lines 39-43)
```python
df = pd.read_csv(DATA / "reviews.csv")
X_train, X_test, y_train, y_test = train_test_split(
    df["review"], df["label"], test_size=0.25, random_state=42, stratify=df["label"]
)
```

**What mentors should verify:**
- `df["review"]` is 1D text Series; `df["label"]` is 1D target Series.
- `stratify=df["label"]` is explicitly included. Without stratification, a random split on 80 rows might yield an imbalanced test set (e.g., 14 real and 6 fake), distorting evaluation metrics.

---

### Checkpoint 5: Pipeline Architecture & Fitting (lines 44-50)
```python
model = Pipeline(
    [
        ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
        ("classifier", MultinomialNB()),
    ]
)
model.fit(X_train, y_train)
```

**What mentors should verify:**
- `CountVectorizer` has `ngram_range=(1, 2)` and `stop_words="english"`.
- `model.fit()` is called on `X_train` and `y_train` only. Passing test data here constitutes data leakage.

---

### Checkpoint 6: Visualization Formatting (lines 80-103)
```python
fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
for ax, words, title, colour in (
    (axes[0], fake_words, "Words that suggest a fake review", "#c0392b"),
    (axes[1], real_words, "Words that suggest a real review", "#2471a3"),
):
    ax.barh(words[::-1], range(1, len(words) + 1), color=colour)
    ax.set_title(title)
    ax.set_xlabel("relative clue strength")
    ax.grid(axis="x", alpha=0.25)
fig.tight_layout()
fig.savefig(OUT / "top_words.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```

**What mentors should verify:**
- Reversal `words[::-1]` inside `ax.barh` ensures the #1 clue word is at the top of the horizontal bar chart.
- `plt.close(fig)` is called to release memory.
- `bbox_inches="tight"` prevents label clipping on saved images.

---

## 3. Expected Numerical Results

Under Python 3.8+ with scikit-learn >= 1.0.0 and `random_state=42`:
- **Training Samples**: 60 (30 fake, 30 real)
- **Testing Samples**: 20 (10 fake, 10 real)
- **Accuracy**: 100.0%
- **Top Fake Clues**: `best`, `wow`, `stars`, `wow wow`, `10`, `buy`, `right`, `stars best`, `market`, `need`
- **Top Real Clues**: `liked`, `works`, `support helped`, `support`, `instructions`, `liked design`, `instructions confusing`, `helped`, `customer`, `customer support`

### Predictions on Sample Reviews:
1. `"AMAZING!!! Best product ever. Buy it now, you will not regret it!"` $\to$ **fake (100%)**
2. `"The item arrived on time. The battery is fine, but the cable is short."` $\to$ **real (100%)**
3. `"Perfect quality, perfect price, perfect everything. Five stars!"` $\to$ **fake (100%)**
4. `"It works as described. Shipping took a week longer than expected."` $\to$ **real (99%)**
