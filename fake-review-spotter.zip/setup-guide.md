# Setup Guide: The Fake Review Spotter

Follow these step-by-step instructions to set up your environment, inspect the source project, run the code, and review generated outputs.

---

## Step 1: Navigate to the Project Directory
Open your terminal and change directory to the project folder:
```bash
cd "/home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/12_fake_review_spotter"
```

Verify your current directory and confirm that `main.py` and `data/reviews.csv` are present:
```bash
ls -la
ls -la data/
```

---

## Step 2: Set Up a Virtual Environment (Recommended)
Create and activate an isolated Python virtual environment:

### On Linux / macOS:
```bash
python3 -m venv venv
source venv/bin/activate
```

### On Windows (PowerShell):
```powershell
python -m venv venv
venv\Scripts\Activate.ps1
```

---

## Step 3: Install Required Dependencies
Install the necessary data science and machine learning packages:
```bash
pip install --upgrade pip
pip install pandas numpy matplotlib scikit-learn
```

Verify that the packages import without error:
```bash
python -c "import pandas, numpy, matplotlib, sklearn; print('All dependencies imported successfully!')"
```

---

## Step 4: Inspect the Dataset
Examine the structure of the fake and real reviews CSV file:
```bash
head -n 10 data/reviews.csv
```
You should observe two columns: `review` and `label`. Notice the contrast between enthusiastic praise ("WOW WOW WOW", "Must buy!") and balanced descriptions ("Good value for the price", "Mixed experience").

---

## Step 5: Execute the Main Script
Run the pipeline:
```bash
python main.py
```

---

## Step 6: Verify Console Output
You should see output similar to:
```text
============================================================
THE FAKE REVIEW SPOTTER
============================================================
Accuracy: 100.0%

              precision    recall  f1-score   support

        fake       1.00      1.00      1.00        10
        real       1.00      1.00      1.00        10

    accuracy                           1.00        20
   macro avg       1.00      1.00      1.00        20
weighted avg       1.00      1.00      1.00        20

Top 'fake' clues: best, wow, stars, wow wow, 10, buy, right, stars best, market, need
Top 'real' clues: liked, works, support helped, support, instructions, liked design, instructions confusing, helped, customer, customer support

New review predictions:
  fake (100%) -> AMAZING!!! Best product ever. Buy it now, you will not regret it!
  real (100%) -> The item arrived on time. The battery is fine, but the cable is short.
  fake (100%) -> Perfect quality, perfect price, perfect everything. Five stars!
  real (99%) -> It works as described. Shipping took a week longer than expected.

Saved: outputs/top_words.png, outputs/confusion_matrix.png, outputs/predictions.txt
Try this: add 10 honest reviews that sound enthusiastic and see whether they fool the model.
```

---

## Step 7: Inspect Generated Output Files
Check the `outputs/` folder:
```bash
ls -la outputs/
```
You should find three generated files:
1. `outputs/top_words.png` — Two-panel horizontal bar chart highlighting fake clues (red) vs real clues (blue).
2. `outputs/confusion_matrix.png` — 2x2 confusion matrix visualization showing test set predictions.
3. `outputs/predictions.txt` — Full text report of metrics and sample classifications with confidence percentages.
