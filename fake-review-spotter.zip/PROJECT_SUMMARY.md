# Project Summary: The Fake Review Spotter

## 1. Executive Summary
- **Project Title**: The Fake Review Spotter
- **Slug**: `fake-review-spotter`
- **Domain**: Natural Language Processing (NLP) / Supervised Text Classification
- **Algorithm**: Multinomial Naive Bayes (`MultinomialNB`) with `CountVectorizer`
- **Dataset**: `data/reviews.csv` (80 balanced customer reviews: 40 fake, 40 real)
- **Primary Goal**: Automatically categorize online product reviews as deceptive or authentic, and surface the most influential vocabulary clues.

---

## 2. Business & Real-World Use Case
Deceptive consumer reviews represent a multi-billion dollar problem in global e-commerce. Bad actors deploy fraudulent 5-star reviews to manipulate search rankings and lure consumers into purchasing low-quality items. Conversely, smear campaigns use fake 1-star reviews to damage rival merchants. By detecting deceptive stylistic fingerprints at scale, platforms can safeguard customer trust, protect honest sellers, and comply with consumer protection regulations.

---

## 3. Implemented Capabilities
- **Automated Ingestion**: Loads and parses review text and binary ground-truth labels from CSV.
- **Stratified Partitioning**: Splits the 80 reviews into a 60-sample training set and 20-sample test set while maintaining exact class proportions.
- **Contextual Text Preprocessing**: Strips English stop words and extracts unigrams and bigrams (`ngram_range=(1, 2)`) to retain key phrases such as "customer support" and "best seller".
- **Probabilistic Text Classification**: Employs Laplace-smoothed Multinomial Naive Bayes inside an integrated scikit-learn `Pipeline`.
- **Feature Importance Derivation**: Decodes `feature_log_prob_` to calculate log-likelihood ratio scores, ranking the top 10 words that betray fake reviews and top 10 words that indicate real reviews.
- **Multimodal Evaluation**: Generates precision, recall, F1-scores, and a 2x2 confusion matrix visualization (`outputs/confusion_matrix.png`).
- **Data Visualization**: Saves a dual-panel horizontal bar chart (`outputs/top_words.png`) comparing fake clues (red) against real clues (blue).
- **Inference with Confidence Estimation**: Scores unseen candidate reviews using `predict()` and `predict_proba()`, outputting formatted results to `outputs/predictions.txt`.

---

## 4. Technical Specifications

```text
12_fake_review_spotter/
├── main.py                  # End-to-end training, evaluation, and visualization pipeline
├── data/
│   └── reviews.csv          # 80 balanced review records (review text, label)
└── outputs/
    ├── top_words.png        # Dual-panel horizontal bar chart of distinguishing words
    ├── confusion_matrix.png # Seaborn/Matplotlib 2x2 confusion matrix graphic
    └── predictions.txt      # Text summary of metrics and sample classifications
```

### Software Environment
- Python 3.8+
- Scikit-learn (Pipeline, CountVectorizer, MultinomialNB, metrics)
- Pandas (DataFrame loading, Series slicing)
- NumPy (log-likelihood sorting and array slicing)
- Matplotlib (Agg headless rendering engine)

---

## 5. Ethical & Fair AI Considerations
- **Statistical Correlation vs Factuality**: The model flags vocabulary patterns, not verified falsehoods. It must never be used as sole evidence for punitive action without human-in-the-loop review.
- **Enthusiastic Customer Bias**: Honest buyers expressing genuine delight often use superlatives ('amazing', 'best ever'), creating a risk of False Positives.
- **Adversarial Resilience**: Fraud rings can deliberately evade bag-of-words filters by adopting measured, neutral phrasing. Production systems require holistic behavioral and network telemetry.
