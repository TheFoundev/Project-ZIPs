# All Correct Answers for Assessments
Project: The Fake Review Spotter
---

## Module 01: Project Overview and NLP Foundations
**q1-01.** In the Fake Review Spotter project, what is the core business problem being addressed?
   **Correct Answer:** b. Identifying deceptive or fraudulent online customer reviews to protect consumer trust
   *Explanation:* The Fake Review Spotter project is designed to detect fraudulent, deceptive reviews that artificially inflate or deflate product ratings, harming consumer purchasing decisions and merchant trust.

**q1-02.** What type of machine learning task is the Fake Review Spotter performing?
   **Correct Answer:** b. Supervised binary classification
   *Explanation:* The model learns from labeled text examples (supervision) and categorizes reviews into exactly two discrete classes ('fake' or 'real'), making it a supervised binary classification task.

**q1-03.** Why does the project documentation emphasize that the model is a 'pattern finder, not a lie detector'?
   **Correct Answer:** c. Because it spots statistical correlations in vocabulary rather than verifying objective real-world facts
   *Explanation:* Machine learning classifiers identify linguistic and lexical correlations learned from training text. They have no mechanism to independently verify whether a reviewer actually purchased the product or experienced the product in physical reality.

**q1-04.** How do word patterns typically differ between fake reviews and genuine reviews in typical consumer datasets?
   **Correct Answer:** b. Fake reviews frequently employ hyperbolic superlatives and urgent praise, while genuine reviews discuss balanced, specific pros and cons
   *Explanation:* Deceptive reviews often lean on extreme superlatives ('best ever', 'flawless', 'buy now') without concrete usage details, whereas genuine reviews tend to mention concrete product nuances, caveats, or balanced experiences.

**q1-05.** What is the primary economic consequence of widespread fake reviews on e-commerce platforms?
   **Correct Answer:** b. Erosion of consumer trust leading to misallocated spending and penalties for honest merchants
   *Explanation:* Fake reviews distort market competition: low-quality goods gain undeserved prominence, consumers purchase inferior products, honest sellers are undercut, and platform reputation is compromised.

**q1-06.** Why does supervised learning require labeled training examples (such as review text paired with 'fake' or 'real' labels)?
   **Correct Answer:** a. The algorithm needs ground-truth reference pairs to calculate prediction errors and update parameters
   *Explanation:* Supervised learning relies on paired inputs ($X$) and ground-truth targets ($y$). The learning algorithm evaluates its predictions against known labels to calculate word likelihoods for each class.

**q1-07.** If an honest customer is genuinely thrilled with an exceptional product and writes 'AMAZING! Best ever!', what challenge does this pose for a bag-of-words model?
   **Correct Answer:** b. The review may be falsely flagged as fake (False Positive) due to shared superlative vocabulary
   *Explanation:* Because the model scores individual words and phrases based on training frequencies, an ecstatic honest review containing words like 'amazing' and 'best ever' mimics fake review patterns and risks false-positive classification.

**q1-08.** In natural language processing, what distinguishes a binary classification problem from multi-class classification?
   **Correct Answer:** b. Binary classification categorizes inputs into exactly two classes, while multi-class categorizes into three or more classes
   *Explanation:* Binary classification divides the sample space into two mutually exclusive outcomes (here, 'fake' vs 'real'). Multi-class classification involves three or more categories (e.g., 1-star, 2-star, 3-star, 4-star, 5-star).

**q1-09.** Why do industrial review moderation systems at companies like Amazon or Yelp combine NLP text classifiers with reviewer behavioral metadata?
   **Correct Answer:** a. Because text alone can be easily manipulated by sophisticated human copywriters or generative AI
   *Explanation:* Professional fraudsters can craft balanced-sounding reviews that bypass simple text classifiers. Robust defense requires behavioral telemetry: account age, purchase verification, IP subnet patterns, and review velocity.

**q1-10.** According to deceptive language research in computational linguistics, what is 'linguistic leakage' in fake reviews?
   **Correct Answer:** b. Unconscious stylistic habits and exaggerated markers left behind when authors fabricate experiences they never lived
   *Explanation:* Linguistic leakage refers to subconscious linguistic patterns that deceptive writers produce—such as reduced sensory/spatial detail, increased generic superlatives, and elevated emotional posturing.


## Module 02: Data and Text Exploration
**q2-01.** Which CSV file does main.py read as its primary dataset?
   **Correct Answer:** b. data/reviews.csv
   *Explanation:* In main.py line 39, the script loads `pd.read_csv(DATA / 'reviews.csv')`, where DATA is defined as `BASE / 'data'`.

**q2-02.** What are the exact column names present in data/reviews.csv?
   **Correct Answer:** b. review, label
   *Explanation:* The header row of `data/reviews.csv` is `review,label`, where `review` contains the raw text and `label` indicates 'fake' or 'real'.

**q2-03.** How many total review rows are contained in data/reviews.csv?
   **Correct Answer:** b. 80 rows
   *Explanation:* The dataset contains exactly 80 data records (excluding the header row), representing 40 fake reviews and 40 genuine reviews.

**q2-04.** What is the breakdown of class labels in data/reviews.csv?
   **Correct Answer:** b. 40 fake reviews and 40 real reviews
   *Explanation:* Running `df['label'].value_counts()` reveals exactly 40 instances of 'fake' and 40 instances of 'real', a perfectly balanced 50/50 dataset.

**q2-05.** Why is a perfectly balanced dataset (50% fake, 50% real) helpful for beginner machine learning evaluation?
   **Correct Answer:** a. It ensures that standard accuracy is a meaningful metric, preventing majority-class trivial guessing from appearing successful
   *Explanation:* When classes are balanced, a naive model that guesses the same class every time only gets 50% accuracy. This makes accuracy intuitive and informative without masking minority-class failures.

**q2-06.** In main.py, how are the features and target extracted from the pandas DataFrame `df`?
   **Correct Answer:** b. X = df['review'], y = df['label']
   *Explanation:* In `train_test_split(df['review'], df['label'], ...)`, `df['review']` serves as the feature input (text to analyze) and `df['label']` serves as the target class to predict.

**q2-07.** Which of the following reviews from reviews.csv is an actual example of the 'fake' class?
   **Correct Answer:** c. 'WOW WOW WOW. I love it so much. Best seller ever. 10/10.'
   *Explanation:* 'WOW WOW WOW. I love it so much. Best seller ever. 10/10.' is labeled 'fake' in reviews.csv. The other three choices are all labeled 'real'.

**q2-08.** What common structural trait distinguishes the 'real' reviews in reviews.csv from the 'fake' reviews?
   **Correct Answer:** b. Real reviews introduce balanced trade-offs using words like 'not perfect', 'mixed', 'but', and customer support interactions
   *Explanation:* The genuine reviews in `reviews.csv` consistently feature balanced experiences ('not perfect, but does the job', 'scratch, replacement fine', 'instructions confusing, customer support helped').

**q2-09.** If reviews.csv had contained 95% real reviews and 5% fake reviews, what would happen if a naive model simply predicted 'real' for every review?
   **Correct Answer:** a. The model would achieve 95% accuracy while completely failing to spot a single fake review
   *Explanation:* In an imbalanced 95/5 dataset, a dummy classifier predicting the majority class achieves 95% accuracy despite zero utility for fraud detection. This is why precision, recall, and F1-score are critical.

**q2-10.** Why does main.py construct file paths using `Path(__file__).resolve().parent` instead of a plain string like `'data/reviews.csv'`?
   **Correct Answer:** a. To ensure the script runs reliably regardless of the terminal's current working directory
   *Explanation:* Using `Path(__file__).resolve().parent` anchors all paths to the script's physical location on disk. If a user runs `python projects/12_fake_review_spotter/main.py` from any directory, it locates the data without `FileNotFoundError`.


## Module 03: CountVectorizer and Text Vectorization
**q3-01.** What is the primary role of CountVectorizer in the scikit-learn NLP pipeline?
   **Correct Answer:** b. To convert a collection of text documents into a numerical matrix of token counts
   *Explanation:* Machine learning algorithms require numerical vectors. CountVectorizer tokenizes text, builds an internal vocabulary of terms, and transforms text into document-term count vectors.

**q3-02.** What fundamental structural aspect of text is discarded by the standard Bag-of-Words (BoW) representation?
   **Correct Answer:** b. Grammatical syntax, sentence structure, and word order
   *Explanation:* The Bag-of-Words model treats each document as an unordered collection of words, keeping track of which words appear and how often, but discarding word sequence and grammar.

**q3-03.** In main.py, CountVectorizer is initialized with `stop_words='english'`. What does this parameter do?
   **Correct Answer:** a. Filters out extremely common English words (such as 'the', 'and', 'is', 'in') that carry little discriminative information
   *Explanation:* Stop words are high-frequency grammatical functional words that appear uniformly in both fake and real reviews. Removing them shrinks vocabulary size and emphasizes content words.

**q3-04.** What does setting `ngram_range=(1, 2)` specify in CountVectorizer?
   **Correct Answer:** b. The vectorizer extracts both single words (unigrams) and two-word sequences (bigrams)
   *Explanation:* An n-gram range of (min_n, max_n) = (1, 2) includes both individual tokens (unigrams like 'best', 'stars') and consecutive token pairs (bigrams like 'wow wow', 'customer support').

**q3-05.** Why is extracting bigrams especially valuable for fake review detection compared to unigrams alone?
   **Correct Answer:** a. Bigrams capture common multi-word collocations like 'customer support' or 'best seller' that carry specific contextual meaning
   *Explanation:* Single words lose contextual pairing. A phrase like 'customer support' or 'wow wow' provides a much stronger signal of genuine customer service interaction or hyperbolic spam than isolated words.

**q3-06.** How does CountVectorizer handle letter case by default (when lowercase=True)?
   **Correct Answer:** b. It converts all characters to lowercase before tokenizing and building vocabulary
   *Explanation:* By default, CountVectorizer applies `lowercase=True`, converting all text to lowercase so that words like 'AMAZING' and 'amazing' map to the identical vocabulary token.

**q3-07.** What data structure does CountVectorizer return when transforming documents?
   **Correct Answer:** b. A scipy sparse matrix (scipy.sparse.csr_matrix)
   *Explanation:* Because most words do not appear in any single review, the document-term matrix is mostly zeros. Scikit-learn outputs a scipy Compressed Sparse Row (`csr_matrix`) to conserve memory.

**q3-08.** If a review contains the sentence 'Best product ever. Buy now!', what will CountVectorizer extract when stop_words='english' and ngram_range=(1,2)?
   **Correct Answer:** b. Tokens such as 'best', 'product', 'buy', and bigrams like 'best product'
   *Explanation:* After punctuation removal and stop word filtering, content words ('best', 'product', 'buy') and valid remaining bigrams (like 'best product') are extracted as features.

**q3-09.** What happens during inference when a new review contains a word that was never present in the training set vocabulary?
   **Correct Answer:** b. The vectorizer simply ignores the unknown word because it is not in the learned vocabulary
   *Explanation:* In scikit-learn, `transform()` only looks up words present in `vocabulary_` learned during `fit()`. Words unseen during training are silently ignored (out-of-vocabulary words).

**q3-10.** If CountVectorizer's vocabulary has 150 unique features, and you transform a review consisting entirely of stop words ('the is at in'), what is the resulting count vector?
   **Correct Answer:** b. An all-zero vector of length 150
   *Explanation:* If all words in the input are filtered out as stop words, zero tokens are recognized from the vocabulary, resulting in a sparse vector containing all zeros.


## Module 04: Multinomial Naive Bayes and Training
**q4-01.** What classifier does main.py use inside its scikit-learn Pipeline?
   **Correct Answer:** b. MultinomialNB
   *Explanation:* In main.py line 47, the classifier step of the pipeline is `('classifier', MultinomialNB())`.

**q4-02.** What is the 'naive' assumption made by Naive Bayes classifiers?
   **Correct Answer:** b. It assumes that all features (words) are conditionally independent of each other given the class label
   *Explanation:* The algorithm assumes that the presence of one word is conditionally independent of any other word given the class label. Even though language violates this assumption in practice, the model performs remarkably well.

**q4-03.** In scikit-learn, what is the key advantage of encapsulating CountVectorizer and MultinomialNB inside a `Pipeline`?
   **Correct Answer:** b. It chains transformers and estimators together, preventing data leakage and allowing direct prediction on raw text strings
   *Explanation:* A `Pipeline` combines preprocessing (`CountVectorizer`) and modeling (`MultinomialNB`). You can pass raw review strings directly into `model.predict()` without manually vectorizing them first.

**q4-04.** Why does main.py specify `stratify=df['label']` in `train_test_split()`?
   **Correct Answer:** b. To ensure both training and testing sets maintain the exact same proportion of fake and real reviews as the original dataset
   *Explanation:* Stratification ensures that both the 60-sample training set and 20-sample test set contain an exact 50/50 balance (30 fake / 30 real in train, 10 fake / 10 real in test).

**q4-05.** In a fitted MultinomialNB model, what does the attribute `feature_log_prob_` represent?
   **Correct Answer:** b. The log probability of each feature (word) given each class: log P(word | class)
   *Explanation:* `classifier.feature_log_prob_[c, i]` stores the empirical log probability $\log P(w_i | c)$ of word $i$ appearing in class $c$, estimated with Laplace smoothing.

**q4-06.** In main.py's `top_words` function, how are word clue scores calculated?
   **Correct Answer:** b. By subtracting the other class's log probability from the target class's log probability: feature_log_prob_[c] - feature_log_prob_[1-c]
   *Explanation:* Subtracting log probabilities computes the log-likelihood ratio: $\log \frac{P(w|c)}{P(w|\text{other})}$. Words with the highest positive difference are the strongest indicators for that class.

**q4-07.** With a dataset of 80 reviews and `test_size=0.25`, how many reviews are in the training set and testing set respectively?
   **Correct Answer:** b. 60 train, 20 test
   *Explanation:* 25% of 80 is 20 reviews allocated for testing ($80 \times 0.25 = 20$). The remaining 75% ($80 - 20 = 60$) forms the training set.

**q4-08.** Why do Naive Bayes implementations compute probabilities using logarithms (log probabilities) rather than multiplying raw probabilities directly?
   **Correct Answer:** a. To prevent floating-point underflow when multiplying many small probabilities together
   *Explanation:* Multiplying dozens of fractional probabilities ($0.01 \times 0.005 \times ...$) rapidly causes arithmetic underflow to zero. In log-space, multiplication becomes stable addition: $\log(a \cdot b) = \log a + \log b$.

**q4-09.** What is Laplace smoothing (additive smoothing, alpha=1.0) in MultinomialNB, and why is it essential?
   **Correct Answer:** b. Adding a small pseudo-count to each word so no word has a zero conditional probability
   *Explanation:* Without smoothing, if a test review contains a word never seen in the training data for class $c$, $P(w|c) = 0$, multiplying the total class probability to zero. Laplace smoothing ($lpha=1$) ensures all probabilities remain positive.

**q4-10.** Mathematically, why does `scores = feature_log_prob_[c] - feature_log_prob_[1-c]` accurately isolate the most distinguishing words for class c?
   **Correct Answer:** a. Because subtraction in log-space is equivalent to the log of the likelihood ratio: log(P(w|c) / P(w|other))
   *Explanation:* By logarithm laws, $\log A - \log B = \log(A / B)$. When $P(w|c) \gg P(w|\text{other})$, the ratio $A/B$ is large and positive, identifying words that appear predominantly in class $c$.


## Module 05: Evaluation and Visualizing Top Clue Words
**q5-01.** What accuracy does the Fake Review Spotter model achieve on the 20-sample test set in main.py?
   **Correct Answer:** c. 100.0%
   *Explanation:* When running main.py with the seeded split (`random_state=42`), the model predicts all 10 fake reviews and all 10 real reviews correctly, achieving 100.0% accuracy.

**q5-02.** Why does main.py call `matplotlib.use('Agg')` before importing pyplot?
   **Correct Answer:** b. To select a non-interactive backend that renders images to disk without requiring a graphical display or desktop window manager
   *Explanation:* The 'Agg' backend renders directly to file buffers without attempting to connect to an X11, Wayland, or Windows desktop server, making it essential for headless servers and automation.

**q5-03.** Which scikit-learn function generates a comprehensive text table showing precision, recall, and f1-score for each class?
   **Correct Answer:** b. classification_report()
   *Explanation:* `classification_report(y_test, predictions, zero_division=0)` outputs a formatted table containing precision, recall, f1-score, and support for all evaluated classes.

**q5-04.** In fake review detection, what is a 'False Positive' if 'fake' is defined as the positive class?
   **Correct Answer:** b. A genuine review that the model incorrectly flagged as fake
   *Explanation:* A False Positive occurs when the model predicts the positive condition ('fake') for a sample that is actually negative ('genuine'). This harms honest customers whose genuine praise is wrongly flagged.

**q5-05.** What is the key difference between Precision and Recall for the 'fake' class?
   **Correct Answer:** a. Precision measures what fraction of flagged reviews were truly fake; Recall measures what fraction of all actual fake reviews were caught
   *Explanation:* Precision = TP / (TP + FP) answers 'When the model calls a review fake, how often is it right?'. Recall = TP / (TP + FN) answers 'Of all actual fake reviews, how many did the model catch?'.

**q5-06.** In main.py, what colors are used for the 'Words that suggest a fake review' and 'Words that suggest a real review' bar charts?
   **Correct Answer:** b. #c0392b (red) for fake clues and #2471a3 (blue) for real clues
   *Explanation:* In main.py line 83-84, the script assigns `#c0392b` (a muted red) for words suggesting a fake review and `#2471a3` (a muted blue) for words suggesting a real review.

**q5-07.** Why does main.py pass `words[::-1]` to `ax.barh()` when rendering the horizontal bar charts?
   **Correct Answer:** b. To ensure the top-ranked word appears at the top of the chart rather than at the bottom
   *Explanation:* Matplotlib's `barh` plots items from bottom to top along the y-axis. Slicing with `[::-1]` reverses the list order so the highest-scoring clue appears at the very top of the chart.

**q5-08.** What two image files does main.py generate and save into the outputs/ directory?
   **Correct Answer:** b. outputs/top_words.png and outputs/confusion_matrix.png
   *Explanation:* In lines 91 and 101, main.py saves `outputs/top_words.png` (the two horizontal bar charts) and `outputs/confusion_matrix.png` (the 2x2 confusion matrix display).

**q5-09.** If an e-commerce platform automatically suspends merchant accounts whenever their reviews are classified as fake, which metric must platform operators maximize to avoid unfairly banning innocent sellers?
   **Correct Answer:** a. Precision (minimize False Positives)
   *Explanation:* When false accusations cause catastrophic real-world harm (banning innocent sellers), operators must prioritize high Precision. High precision ensures that when a merchant is flagged, the flag is virtually guaranteed to be accurate.

**q5-10.** Why should a data scientist view 100% test accuracy on this 20-sample test set with healthy scientific skepticism rather than declaring the problem permanently solved?
   **Correct Answer:** a. Small curated test sets (20 samples) have wide confidence intervals and do not reflect the messy, adversarial diversity of real-world internet spam
   *Explanation:* With only 20 test samples, the standard error is large (~5-10%). Furthermore, synthetic or starter datasets have stark lexical separation; real web text has subtle phrasing, sarcasm, and deliberate evasion.


## Module 06: Predictions, Limitations, and Extensions
**q6-01.** Which method on the fitted pipeline returns predicted class labels ('fake' or 'real') for new review strings?
   **Correct Answer:** a. model.predict()
   *Explanation:* Calling `model.predict(new_reviews)` passes raw strings through CountVectorizer and MultinomialNB, returning an array of predicted class labels.

**q6-02.** Which method on the pipeline returns the probability distribution over all classes for each input review?
   **Correct Answer:** a. model.predict_proba()
   *Explanation:* `model.predict_proba(new_reviews)` returns an array of shape `(n_samples, n_classes)` containing calibrated class probabilities summing to 1.0 for each review.

**q6-03.** What text file does main.py write to summarize its evaluation results and sample predictions?
   **Correct Answer:** b. outputs/predictions.txt
   *Explanation:* In lines 104-110, main.py writes accuracy, classification report, and new review predictions to `outputs/predictions.txt`.

**q6-04.** For the review 'AMAZING!!! Best product ever. Buy it now, you will not regret it!', what prediction and confidence does main.py produce?
   **Correct Answer:** b. fake (100%)
   *Explanation:* The review contains multiple strong fake clue words ('amazing', 'best', 'buy', 'product') and zero real clue words, yielding a 'fake' prediction with 100% confidence.

**q6-05.** For the review 'The item arrived on time. The battery is fine, but the cable is short.', what did the model predict and with what confidence?
   **Correct Answer:** b. real (100%)
   *Explanation:* The review contains nuanced, balanced descriptors of physical attributes, leading the model to predict 'real' with 100% confidence.

**q6-06.** Why does the review 'It works as described. Shipping took a week longer than expected.' get classified as real with 99% confidence?
   **Correct Answer:** a. Because it contains the word 'works' and discusses a realistic shipping delay trade-off
   *Explanation:* 'works' is one of the top clues for genuine reviews in the model, and the balanced critique of shipping delays aligns closely with training patterns in genuine reviews.

**q6-07.** How can a motivated fraudster easily fool this CountVectorizer + Naive Bayes model?
   **Correct Answer:** a. By intentionally including words that suggest real reviews (like 'support', 'works', 'mixed') while giving a fake 5-star rating
   *Explanation:* Because the model relies entirely on word frequency cues, an adversary who reads the top clues can easily write: 'Works well, customer support helped, highly recommend' to evade detection.

**q6-08.** What is the primary operational risk of using Naive Bayes word counts as an automated censor that deletes customer reviews without human oversight?
   **Correct Answer:** a. Authentic, enthusiastic customer reviews will be censored (False Positives), alienating genuine brand advocates
   *Explanation:* Excited genuine customers frequently use words like 'best' and 'amazing'. Silently deleting their reviews harms customer relations and distorts truthful feedback.

**q6-09.** How can a data scientist extend the Fake Review Spotter to incorporate numerical metadata (like star rating and review character length) alongside text?
   **Correct Answer:** a. Using scikit-learn's `ColumnTransformer` or `FeatureUnion` to combine CountVectorizer on text with StandardScaler on numeric features
   *Explanation:* `ColumnTransformer` applies different transformers to different columns—e.g., `CountVectorizer` on the `review` text column and scaling on `rating` and `length`—then concatenates them into a unified feature matrix.

**q6-10.** In a state-of-the-art enterprise anti-fraud platform, why is deceptive review detection treated as an adversarial graph and temporal tracking problem rather than simple standalone NLP?
   **Correct Answer:** a. Because coordinated fraud rings use clusters of sockpuppet accounts posting coordinated reviews over short time windows to boost product rankings
   *Explanation:* Modern review fraud is conducted by syndicates. Detecting the syndicate requires analyzing graph connections (shared IP, credit card, or device fingerprints) and sudden temporal bursts of 5-star ratings.

