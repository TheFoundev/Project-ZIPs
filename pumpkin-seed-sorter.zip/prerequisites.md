# Prerequisites

## Required Technical Background
- **Python Fundamentals**:
  - Variable assignments, loops, dictionary unpacking, functions, and file I/O.
  - Familiarity with object-oriented syntax (`model.fit()`, `model.predict()`).
- **Data Manipulation (pandas)**:
  - Loading CSV files into DataFrames (`pd.read_csv`).
  - Extracting feature subsets (`df[FEATURES]`) and single series target columns (`df['variety']`).
  - Creating one-row DataFrames for prediction inference.
- **Introductory Machine Learning Concepts**:
  - Supervised learning vs unsupervised learning.
  - Distinction between regression (continuous target) and classification (discrete categories).
  - Train-test split rationale and the concept of testing on unseen evaluation data.
- **Basic Geometry & Coordinate Concepts**:
  - Geometric notions of 2D area, perimeter, ellipse major/minor axes, and eccentricity.

## Software & Environment Setup
- Python 3.8+ (compatible with Python 3.9, 3.10, 3.11, 3.12+)
- Python packages:
  - `pandas` (>= 1.3.0)
  - `numpy` (>= 1.20.0)
  - `matplotlib` (>= 3.4.0)
  - `scikit-learn` (>= 1.0.0)

## Recommended Setup Commands
```bash
python3 -m venv venv
source venv/bin/activate
pip install pandas matplotlib scikit-learn
```
