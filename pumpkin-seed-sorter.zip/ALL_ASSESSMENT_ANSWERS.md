# All Correct Answers for Assessments
Project: The Pumpkin Seed Sorter (pumpkin-seed-sorter)
---

## Module 01
**q1-01.** What primary agricultural problem does the Pumpkin Seed Sorter project address?
   **Correct Answer:** b. Automating the classification and sorting of pumpkin seeds into distinct cultivars based on shape
   *Explanation:* The Pumpkin Seed Sorter automates the sorting of pumpkin seeds into distinct biological cultivars (Cercevelik, Karacabey, Urgup_Sivrisi) using geometric dimensions extracted from seed silhouettes.

**q1-02.** Which three pumpkin seed cultivars are classified in this project?
   **Correct Answer:** a. Cercevelik, Karacabey, and Urgup_Sivrisi
   *Explanation:* The dataset contains samples from three specific Turkish commercial pumpkin seed cultivars: Cercevelik, Karacabey, and Urgup_Sivrisi.

**q1-03.** Which of the following is NOT one of the five morphological features in FEATURES?
   **Correct Answer:** c. chlorophyll_content
   *Explanation:* Chlorophyll content is a biochemical pigment metric not present in the dataset. FEATURES contains area, perimeter, major_axis, minor_axis, and eccentricity.

**q1-04.** How is eccentricity mathematically interpreted when analyzing seed silhouettes?
   **Correct Answer:** b. A dimensionless index measuring elongation, where 0 is circular and values closer to 1 are elongated
   *Explanation:* Eccentricity is a mathematical ratio from 0 to 1 characterizing the elongation of an ellipse, where 0 represents a circle and values approaching 1 denote highly elongated, slender shapes.

**q1-05.** Why is the Pumpkin Seed Sorter categorized as a multi-class classification problem rather than binary classification?
   **Correct Answer:** b. Because the target variable contains three discrete varieties rather than two
   *Explanation:* Multi-class classification is defined by having three or more mutually exclusive target classes (here: Cercevelik, Karacabey, and Urgup_Sivrisi). Binary classification only has two classes.

**q1-06.** What type of target variable does `df['variety']` represent in supervised learning?
   **Correct Answer:** b. Categorical (nominal) qualitative variable
   *Explanation:* The variety column contains discrete text strings naming cultivars (Cercevelik, Karacabey, Urgup_Sivrisi), which are categorical nominal labels.

**q1-07.** Why are decision trees considered 'white-box' models in automated agricultural inspection?
   **Correct Answer:** a. Because their internal decisions consist of transparent, human-readable IF-THEN rules
   *Explanation:* Decision trees are called white-box models because their internal mathematical logic can be inspected as a sequence of clear, human-understandable boolean IF-THEN rules.

**q1-08.** Which tree depths are compared in `main.py`?
   **Correct Answer:** c. depths 2, 4, and None (unlimited)
   *Explanation:* main.py loops over depths (2, 4, None), testing a shallow tree (depth 2), a moderately deep tree (depth 4), and an unconstrained tree (depth None).

**q1-09.** Why is assigning arbitrary integers (e.g. Cercevelik=1, Karacabey=2, Urgup_Sivrisi=3) and running linear regression inappropriate for this problem?
   **Correct Answer:** b. It imposes an artificial numerical ordering and distance metric on unordered nominal cultivars
   *Explanation:* Nominal categories have no inherent order. Assigning 1, 2, 3 implies that Karacabey (2) is mathematically midway between Cercevelik (1) and Urgup_Sivrisi (3), distorting model loss functions and predictions.

**q1-10.** In high-speed pneumatic optical sorting, why is a shallow decision tree preferred over a deep neural network?
   **Correct Answer:** a. Shallow trees require only a few simple conditional comparisons, executing in microseconds on low-cost microcontrollers
   *Explanation:* Shallow trees require only 2 to 4 simple numerical threshold comparisons, which can be evaluated in microseconds on low-power industrial microcontrollers connected directly to air ejection valves.


## Module 02
**q2-01.** How many total rows and columns are in data/pumpkin_seeds.csv?
   **Correct Answer:** b. 180 rows and 6 columns
   *Explanation:* The dataset data/pumpkin_seeds.csv contains 180 seed observations (rows) across 6 columns (variety, area, perimeter, major_axis, minor_axis, eccentricity).

**q2-02.** Which pandas function is used in main.py to load the dataset?
   **Correct Answer:** b. pd.read_csv()
   *Explanation:* main.py line 30 loads the data using pd.read_csv(DATA / 'pumpkin_seeds.csv'), which parses comma-separated tabular files into a pandas DataFrame.

**q2-03.** What does the minor_axis feature represent geometrically?
   **Correct Answer:** b. The shortest diameter perpendicular to the major axis passing through the center
   *Explanation:* The minor axis is the shortest diameter of the fitted bounding ellipse, perpendicular to the major axis, measuring the width across the seed silhouette.

**q2-04.** What is the mathematical formula for eccentricity e in terms of semi-major axis a and semi-minor axis b?
   **Correct Answer:** b. e = sqrt(1 - (b / a)^2)
   *Explanation:* The mathematical formula for eccentricity of an ellipse is e = sqrt(1 - (b / a)^2), where a is the semi-major axis and b is the semi-minor axis.

**q2-05.** How many samples belong to each pumpkin seed variety in pumpkin_seeds.csv?
   **Correct Answer:** a. Exactly 60 samples each (60 Cercevelik, 60 Karacabey, 60 Urgup_Sivrisi)
   *Explanation:* The dataset is perfectly balanced: each of the three cultivars (Cercevelik, Karacabey, Urgup_Sivrisi) contains exactly 60 sample rows in pumpkin_seeds.csv.

**q2-06.** What is the baseline classification accuracy of a zero-rule classifier on this balanced dataset?
   **Correct Answer:** b. 33.3% (1 in 3)
   *Explanation:* Because there are 3 equally balanced classes (60 each out of 180), a naive baseline classifier that always predicts the majority class achieves 60 / 180 = 33.33% accuracy.

**q2-07.** In train_test_split, what does test_size=0.25 specify?
   **Correct Answer:** b. Reserve 25% of the data (45 rows) for testing and 75% (135 rows) for training
   *Explanation:* test_size=0.25 reserves 25% of the 180 total observations (45 rows) for the evaluation test set and 75% (135 rows) for model training.

**q2-08.** What is the primary purpose of passing stratify=y to train_test_split?
   **Correct Answer:** a. To ensure both training and testing sets maintain the same 1:1:1 cultivar ratio as the original dataset
   *Explanation:* stratify=y forces train_test_split to sample proportionally from each class in y, guaranteeing identical 1:1:1 class representation in both training and testing sets.

**q2-09.** If a seed silhouette has major_axis = 14.0 mm and minor_axis = 7.0 mm, what is its eccentricity?
   **Correct Answer:** b. Approximately 0.866
   *Explanation:* Using e = sqrt(1 - (b / a)^2), with b/a = 7.0 / 14.0 = 0.5: e = sqrt(1 - 0.25) = sqrt(0.75) ≈ 0.8660.

**q2-10.** With 180 total samples, test_size=0.25, and stratify=y, exactly how many test samples are allocated to each cultivar?
   **Correct Answer:** b. 15 Cercevelik, 15 Karacabey, 15 Urgup_Sivrisi
   *Explanation:* With 180 total seeds and test_size=0.25, the test set has 45 seeds. With stratify=y across 3 balanced classes, each class gets exactly 45 / 3 = 15 test samples.


## Module 03
**q3-01.** What type of node in a decision tree contains the final predicted class label and performs no further splits?
   **Correct Answer:** b. Leaf (terminal) node
   *Explanation:* A leaf (or terminal) node sits at the very bottom of a decision tree branch; it performs no further threshold splits and assigns the final predicted class label to all samples reaching it.

**q3-02.** Why are decision tree decision boundaries in feature space described as orthogonal?
   **Correct Answer:** b. Because each split evaluates a single feature against a threshold, creating perpendicular axis-aligned boundaries
   *Explanation:* Standard CART decision trees evaluate one feature at a time against a scalar threshold (e.g. minor_axis <= 6.04), which creates flat partition boundaries strictly perpendicular (orthogonal) to the feature axis.

**q3-03.** What is the Gini impurity of a perfectly pure node containing 30 Cercevelik seeds and 0 seeds of other varieties?
   **Correct Answer:** b. 0.0
   *Explanation:* When a node contains samples from only a single class, p_1 = 1.0 and all other p_i = 0. The Gini impurity is G = 1 - (1.0)^2 = 0.0, representing complete purity.

**q3-04.** What is the theoretical maximum Gini impurity for a node containing an equal distribution of 3 classes?
   **Correct Answer:** b. 0.667 (2/3)
   *Explanation:* For 3 balanced classes, p_1 = p_2 = p_3 = 1/3. Gini impurity is G = 1 - [ (1/3)^2 + (1/3)^2 + (1/3)^2 ] = 1 - 3*(1/9) = 1 - 1/3 = 2/3 ≈ 0.667.

**q3-05.** What test accuracy did the max_depth=2 model achieve in main.py?
   **Correct Answer:** a. 86.7% (39 / 45)
   *Explanation:* main.py reports max_depth=2 achieves 86.7% test accuracy, correctly classifying 39 out of the 45 test seeds.

**q3-06.** What test accuracy did both the max_depth=4 and max_depth=unlimited models achieve?
   **Correct Answer:** a. 84.4% (38 / 45)
   *Explanation:* Both max_depth=4 and max_depth=unlimited achieve an identical test accuracy of 84.4% (38 out of 45 test seeds correct).

**q3-07.** How does main.py select the best depth from the models dictionary?
   **Correct Answer:** a. best_depth = max(models, key=lambda depth: models[depth][2])
   *Explanation:* main.py line 52 uses best_depth = max(models, key=lambda depth: models[depth][2]), where models[depth][2] accesses the accuracy float stored in the tuple.

**q3-08.** What classic machine learning problem occurs when an unconstrained tree achieves 100% training accuracy but drops to 84.4% test accuracy?
   **Correct Answer:** a. Overfitting (high variance)
   *Explanation:* Overfitting (high variance) occurs when a model memorizes the training data perfectly (100% train accuracy) by creating overly complex boundaries that fail to generalize to unseen test data (84.4% test accuracy).

**q3-09.** A candidate split divides 20 samples into two pure leaf nodes (10 Cercevelik in left, 10 Karacabey in right). What is the weighted child Gini impurity G_split?
   **Correct Answer:** a. 0.0
   *Explanation:* Because both child nodes are 100% pure, G_L = 0.0 and G_R = 0.0. The weighted child impurity is G_split = (10/20)(0.0) + (10/20)(0.0) = 0.0.

**q3-10.** How does the principle of Occam's razor justify choosing max_depth=2 over deeper trees in this project?
   **Correct Answer:** a. Because max_depth=2 is the simplest model that explains the data while achieving the highest test accuracy (86.7%)
   *Explanation:* Occam's razor favors the simplest hypothesis that explains the data. A depth 2 tree uses only 4 plain-English rules and achieves higher test accuracy (86.7%) than complex 12-rule or unlimited trees (84.4%).


## Module 04
**q4-01.** Which scikit-learn function exports trained decision tree logic as an ASCII text hierarchy?
   **Correct Answer:** b. export_text()
   *Explanation:* sklearn.tree.export_text() converts the internal decision tree model into a plain-English hierarchical ASCII text format showing features and split thresholds.

**q4-02.** What is the primary root split condition in the best tree found in main.py?
   **Correct Answer:** b. minor_axis <= 6.04
   *Explanation:* The learned decision tree begins at the root with minor_axis <= 6.04, which provides the single largest Gini impurity reduction across all candidate splits.

**q4-03.** Which variety is predicted for a seed with minor_axis <= 6.04 and area <= 1019.50?
   **Correct Answer:** a. Karacabey
   *Explanation:* Tracing the left branch: minor_axis <= 6.04 and area <= 1019.50 leads directly to the leaf node predicting Karacabey.

**q4-04.** Why does Urgup_Sivrisi appear in two distinct leaf nodes in the best tree?
   **Correct Answer:** a. Because Urgup_Sivrisi seeds occupy two distinct morphological regions: standard slender seeds and wider seeds with shorter lengths
   *Explanation:* Urgup_Sivrisi exhibits natural biological variance: most seeds are slender (minor_axis <= 6.04 and area > 1019.50), but plumper seeds (minor_axis > 6.04) are also captured if their major axis is shorter than Cercevelik (major_axis <= 12.58).

**q4-05.** What does the filled=True parameter do in plot_tree?
   **Correct Answer:** b. Colors each node box according to its majority class, with saturation reflecting purity
   *Explanation:* filled=True paints each node box with a distinct color representing its dominant class, with the color saturation directly reflecting the purity (low Gini) of that node.

**q4-06.** Why must plt.close(fig) be called after fig.savefig() in main.py?
   **Correct Answer:** a. To release internal canvas memory and prevent resource leaks in headless environments
   *Explanation:* plt.close(fig) deallocates the figure's memory buffer in matplotlib. In automated scripts or web servers, omitting close() causes memory leaks as figures accumulate in RAM.

**q4-07.** What cultivar does main.py predict for the new physical seed sample (area=1180, perimeter=55.0, major_axis=12.2, minor_axis=5.7, eccentricity=0.86)?
   **Correct Answer:** a. Urgup_Sivrisi
   *Explanation:* With minor_axis=5.7 (<= 6.04) and area=1180 (> 1019.50), new_seed follows the left-right branch directly into class: Urgup_Sivrisi.

**q4-08.** Why is new_seed defined as a pandas DataFrame rather than a 1D Python dictionary when calling model.predict()?
   **Correct Answer:** a. scikit-learn estimators expect a 2D tabular structure (n_samples, n_features) with matching column names
   *Explanation:* scikit-learn estimators mandate 2D inputs of shape (n_samples, n_features). A pandas DataFrame with column names guarantees 2D shape and matches feature names.

**q4-09.** A new seed arrives with minor_axis = 6.50 mm and major_axis = 14.10 mm. What does the tree predict?
   **Correct Answer:** a. Cercevelik
   *Explanation:* Tracing the seed: minor_axis is 6.50 (> 6.04) -> branches right. major_axis is 14.10 (> 12.58) -> branches right to class: Cercevelik. Notice that area is not evaluated in this branch!

**q4-10.** If a seed arrives with minor_axis = 6.20 mm and major_axis = 12.00 mm, what does the tree predict, and which branch path did it take?
   **Correct Answer:** a. Urgup_Sivrisi via the right branch (minor_axis > 6.04 and major_axis <= 12.58)
   *Explanation:* minor_axis is 6.20 (> 6.04), so it branches right. major_axis is 12.00 (<= 12.58), so it routes to Urgup_Sivrisi via the right branch.


## Module 05
**q5-01.** What is the overall test set accuracy achieved by the best decision tree model (max_depth=2) on the 45 test pumpkin seeds?
   **Correct Answer:** a. 86.7% (39 correct out of 45 test seeds)
   *Explanation:* The depth-2 decision tree correctly predicted 39 out of 45 test seeds (12 Cercevelik, 12 Karacabey, 15 Urgup_Sivrisi), giving exactly 39/45 = 86.67% (86.7%).

**q5-02.** In classification metrics, what does Precision measure for a specific pumpkin seed variety?
   **Correct Answer:** a. The proportion of seeds predicted as Variety X that actually belonged to Variety X (purity)
   *Explanation:* Precision is defined as TP / (TP + FP). It measures purity: out of all seeds predicted to belong to a specific variety, what fraction truly belonged to that variety.

**q5-03.** What is the purpose of setting `zero_division=0` in scikit-learn's `classification_report`?
   **Correct Answer:** a. To prevent runtime warnings and assign 0.0 when a class has no predicted samples (denominator is zero)
   *Explanation:* Setting zero_division=0 instructs scikit-learn to output 0.0 without printing UndefinedMetricWarning when a class receives 0 predictions, ensuring clean automated logs.

**q5-04.** In the project's classification report, why do Cercevelik and Karacabey have a Precision of 1.00 while Urgup_Sivrisi has a Precision of 0.71?
   **Correct Answer:** a. Because no foreign seeds were falsely labeled Cercevelik or Karacabey, whereas 6 non-Urgup seeds were falsely predicted as Urgup_Sivrisi
   *Explanation:* Zero false positives occurred for Cercevelik and Karacabey (giving precision 12/12 = 1.00), while Urgup_Sivrisi received 6 false positives (giving precision 15/(15+6) = 15/21 = 0.71).

**q5-05.** Why are the `macro avg` and `weighted avg` identical (both 0.90 for precision and 0.87 for recall) in this project's classification report?
   **Correct Answer:** a. Because the stratified test split yielded identical support (15 samples) for every cultivar
   *Explanation:* Because stratify=y ensured equal support of 15 samples per cultivar (equal weights of 1/3), the unweighted macro average is mathematically identical to the sample-weighted average.

**q5-06.** In scikit-learn's confusion matrix, how are the axes arranged by convention?
   **Correct Answer:** a. Rows represent true (ground truth) labels; columns represent predicted labels
   *Explanation:* By scikit-learn standard, rows represent true ground-truth classes and columns represent model predictions. ConfusionMatrixDisplay labels the vertical axis as 'True label' and horizontal as 'Predicted label'.

**q5-07.** In the project's confusion matrix, what do the diagonal values (12, 12, 15) represent?
   **Correct Answer:** a. The number of correctly classified True Positive seeds for Cercevelik, Karacabey, and Urgup_Sivrisi
   *Explanation:* The diagonal cells (0,0), (1,1), and (2,2) represent True Positives: 12 Cercevelik, 12 Karacabey, and 15 Urgup_Sivrisi seeds where predicted label matched true label.

**q5-08.** What colormap parameter is passed to `ConfusionMatrixDisplay.plot` in `main.py` to match the warm pumpkin theme?
   **Correct Answer:** a. cmap="YlOrBr"
   *Explanation:* main.py specifies cmap='YlOrBr' (Yellow-Orange-Brown) inside ConfusionMatrixDisplay.plot, providing an autumnal pumpkin color palette.

**q5-09.** Why were 3 true Karacabey seeds misclassified as Urgup_Sivrisi by the depth-2 decision tree?
   **Correct Answer:** a. Because their area exceeded 1019.50 mm² while their minor axis was <= 6.04 mm, routing them into the Urgup_Sivrisi leaf
   *Explanation:* The tree's left branch tests minor_axis <= 6.04 followed by area <= 1019.50. Exceptionally large Karacabey seeds with area > 1019.50 fail the area check and fall directly into the Urgup_Sivrisi leaf.

**q5-10.** Why did increasing `max_depth` from 2 to 4 decrease test set accuracy from 86.7% to 84.4% in this project?
   **Correct Answer:** a. The deeper tree overfit idiosyncratic training set boundary noise, degrading its ability to generalize to unseen test seeds
   *Explanation:* Increasing max_depth allows the tree to create complex partitions that memorize noisy training set anomalies (overfitting). This harms generalization on unseen test data, lowering accuracy from 86.7% to 84.4%.


## Module 06
**q6-01.** What is the primary operational reason for saving `outputs/rules.txt` as a plain UTF-8 text file instead of a binary pickle file?
   **Correct Answer:** a. It provides a human-readable, transparent audit trail that can be inspected without specialized machine learning software
   *Explanation:* Plain UTF-8 text provides a universal, human-readable format that agricultural technicians, plant managers, and regulatory auditors can inspect on any computer without requiring Python or machine learning libraries.

**q6-02.** In `main.py`, which sections are written into `outputs/rules.txt`?
   **Correct Answer:** a. Tree depth accuracy benchmarks, best depth, export_text rules, new seed prediction, and classification report
   *Explanation:* main.py writes the depth benchmark comparisons, best depth selection, plain-text export_text rules, sample inference result, and the classification report table into outputs/rules.txt.

**q6-03.** In an industrial optical seed sorter, which hardware component physically diverts rejected or classified seeds into different collection chutes?
   **Correct Answer:** a. High-speed pneumatic solenoid air ejector nozzles
   *Explanation:* Optical seed sorters utilize high-speed pneumatic solenoid air ejector nozzles that release short bursts of compressed air (typically 5 ms) to deflect targeted seeds into designated chutes.

**q6-04.** Why are decision trees uniquely well-suited for high-speed industrial conveyor sorting lines handling 100 seeds per second?
   **Correct Answer:** a. Their nested if-then threshold logic can be evaluated in sub-microsecond timescales on lightweight microprocessors
   *Explanation:* A shallow decision tree evaluates only a few boolean threshold checks (e.g., minor_axis <= 6.04), executing in under a microsecond on low-cost embedded processors without GPU hardware.

**q6-05.** If a seed travels at 3.0 m/s and the distance from the optical line-scan camera to the air ejector nozzle is 150 mm, what is the travel time?
   **Correct Answer:** a. 50 milliseconds (0.050 seconds)
   *Explanation:* Travel time is calculated as distance divided by speed: 0.150 m / 3.0 m/s = 0.050 seconds, which equals exactly 50 milliseconds.

**q6-06.** How is the domain-specific morphological feature `aspect_ratio` calculated from geometric seed measurements?
   **Correct Answer:** a. major_axis divided by minor_axis
   *Explanation:* Aspect ratio is universally defined as major_axis divided by minor_axis, quantifying how elongated versus circular the seed silhouette is.

**q6-07.** Why are dimensionless shape ratios like `aspect_ratio` and `compactness` advantageous when evaluating agricultural harvests subjected to seasonal drought?
   **Correct Answer:** a. Because relative shape proportions remain stable even when overall seed dimensions shrink due to moisture loss
   *Explanation:* When seeds shrink due to dehydration, both major and minor dimensions decrease proportionally, leaving the ratio (major_axis / minor_axis) relatively constant compared to raw absolute area.

**q6-08.** What phenomenon occurs when seasonal climate variations or soil differences alter the morphological dimensions of crops over successive harvest years?
   **Correct Answer:** a. Concept drift / covariate drift
   *Explanation:* Concept drift or covariate drift describes changes in the statistical distribution of input features or target relationships over time, necessitating model retraining.

**q6-09.** Why does `main.py` dynamically determine `class_names=list(model.classes_)` and `labels=sorted(df['variety'].unique())` instead of hardcoding class lists?
   **Correct Answer:** a. To enable seamless pipeline retraining when new cultivars are added to the CSV without modifying code
   *Explanation:* Extracting classes dynamically from model.classes_ and unique dataset labels ensures that when a new cultivar is added to the CSV, the pipeline automatically adapts without requiring code edits.

**q6-10.** If a fourth cultivar is added to `pumpkin_seeds.csv`, what is the theoretical minimum tree depth needed to produce 4 distinct leaf partitions?
   **Correct Answer:** a. max_depth = 2 (since 2^2 = 4 leaves)
   *Explanation:* In a binary decision tree, depth d yields at most 2^d leaf nodes. To produce 4 distinct leaf nodes for 4 cultivars, a minimum theoretical depth of 2 (2^2 = 4) is required.
