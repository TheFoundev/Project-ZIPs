# Setup Guide

Follow these step-by-step instructions to configure, run, and verify the Pumpkin Seed Sorter project.

## Step 1: Navigate to the Project Root
Open your terminal and change directory to the project folder:
```bash
cd "/home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/15_pumpkin_seed_sorter"
```

## Step 2: Set Up Virtual Environment (Recommended)
Create and activate an isolated virtual environment:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

## Step 3: Install Required Dependencies
Install the required packages using pip:
```bash
pip install pandas matplotlib scikit-learn
```

Verify your installation:
```bash
python3 -c "import pandas, matplotlib, sklearn; print('Dependencies installed successfully!')"
```

## Step 4: Verify Directory Structure and Data
Ensure the data file exists and contains the expected records:
```bash
ls -la data/
head -n 5 data/pumpkin_seeds.csv
```
You should observe 6 columns: `variety,area,perimeter,major_axis,minor_axis,eccentricity`.

## Step 5: Execute the Pipeline
Run the main script:
```bash
python3 main.py
```

## Step 6: Verify Console Output
The execution will produce the following benchmark report:
```
============================================================
THE PUMPKIN SEED SORTER
============================================================
Comparing tree depths:

  max_depth=2         accuracy=86.7%
  max_depth=4         accuracy=84.4%
  max_depth=unlimited accuracy=84.4%

Best tree: max_depth=2

Learned rules for the best tree:

|--- minor_axis <= 6.04
|   |--- area <= 1019.50
|   |   |--- class: Karacabey
|   |--- area >  1019.50
|   |   |--- class: Urgup_Sivrisi
|--- minor_axis >  6.04
|   |--- major_axis <= 12.58
|   |   |--- class: Urgup_Sivrisi
|   |--- major_axis >  12.58
|   |   |--- class: Cercevelik
...
New seed -> Urgup_Sivrisi
Saved: outputs/pumpkin_tree.png, outputs/confusion_matrix.png, outputs/rules.txt
```

## Step 7: Inspect Generated Artifacts
Check that all three files were generated in `outputs/`:
- `outputs/pumpkin_tree.png`: High-resolution visual decision tree flowchart.
- `outputs/confusion_matrix.png`: Heatmap showing cultivar classification performance.
- `outputs/rules.txt`: Full text log containing accuracy benchmarks, rules, and classification metrics.
