# Mentor Solution Guide: The Pumpkin Seed Sorter

## Architectural Walkthrough & Code Checkpoints

This guide equips mentors to evaluate student submissions against the canonical `main.py` implementation.

### Checkpoint 1: Headless Configuration and Imports
```python
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, export_text, plot_tree
```
**Mentor Verification**:
- Verify that `matplotlib.use("Agg")` occurs **before** `import matplotlib.pyplot as plt`. If imported in reverse order, graphical backends may attempt to initialize an interactive X11 or Wayland window, causing runtime crashes on headless virtual machines or CI runners.
- Confirm standard imports from `sklearn.tree`, `sklearn.metrics`, `sklearn.model_selection`, and `pathlib`.

### Checkpoint 2: Directory & Path Setup
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)
FEATURES = ["area", "perimeter", "major_axis", "minor_axis", "eccentricity"]
```
**Mentor Verification**:
- Confirm `Path(__file__).resolve().parent` is used rather than relative string literals like `"./data"`, ensuring resilience regardless of the current working directory.
- Verify `OUT.mkdir(exist_ok=True)` avoids raising `FileExistsError`.
- Ensure all 5 geometric features are specified in `FEATURES`.

### Checkpoint 3: Ingestion and Stratified Splitting
```python
df = pd.read_csv(DATA / "pumpkin_seeds.csv")
X = df[FEATURES]
y = df["variety"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)
```
**Mentor Verification**:
- Confirm `stratify=y` is included. Without stratification, random sampling with a small dataset (180 rows) could distort the 1:1:1 class ratio in test set, creating evaluation variance.
- Check dimensions: `X_train.shape` must be `(135, 5)`, `X_test.shape` must be `(45, 5)`.

### Checkpoint 4: Depth Comparison Loop
```python
models = {}
for depth in (2, 4, None):
    model = DecisionTreeClassifier(max_depth=depth, random_state=42)
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)
    models[depth] = (model, predictions, accuracy)
```
**Mentor Verification**:
- Confirm `DecisionTreeClassifier` is initialized with `random_state=42`. Decision trees have stochastic tie-breaking behavior when features yield identical Gini reductions; setting the seed guarantees deterministic splits.
- Verify that `depth=None` represents the unconstrained tree.
- Expected accuracies:
  - Depth 2: 0.8667 (86.7%)
  - Depth 4: 0.8444 (84.4%)
  - Depth None: 0.8444 (84.4%)

### Checkpoint 5: Model Selection and Plain-English Rules
```python
best_depth = max(models, key=lambda depth: models[depth][2])
model, predictions, accuracy = models[best_depth]
print(export_text(model, feature_names=FEATURES))
```
**Mentor Verification**:
- Confirm `best_depth` dynamically identifies `2`.
- Verify the exported rules match:
  - Branch 1: `minor_axis <= 6.04`
    - Sub-branch 1.1: `area <= 1019.50` -> `Karacabey`
    - Sub-branch 1.2: `area > 1019.50` -> `Urgup_Sivrisi`
  - Branch 2: `minor_axis > 6.04`
    - Sub-branch 2.1: `major_axis <= 12.58` -> `Urgup_Sivrisi`
    - Sub-branch 2.2: `major_axis > 12.58` -> `Cercevelik`

### Checkpoint 6: Inference on New Seed Sample
```python
new_seed = pd.DataFrame(
    [{"area": 1180, "perimeter": 55.0, "major_axis": 12.2, "minor_axis": 5.7, "eccentricity": 0.86}]
)
new_variety = model.predict(new_seed)[0]
```
**Mentor Verification**:
- Ensure `new_seed` is passed as a DataFrame with column headers matching `FEATURES`.
- Trace the logic: `minor_axis = 5.7 <= 6.04` -> `area = 1180 > 1019.50` -> predicts `Urgup_Sivrisi`.

### Checkpoint 7: Tree Visualization
```python
fig, ax = plt.subplots(figsize=(16, 8))
plot_tree(
    model,
    feature_names=FEATURES,
    class_names=list(model.classes_),
    filled=True,
    rounded=True,
    fontsize=8,
    ax=ax,
)
ax.set_title("Pumpkin seed decision tree")
fig.tight_layout()
fig.savefig(OUT / "pumpkin_tree.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```
**Mentor Verification**:
- `filled=True` colors nodes according to dominant class purity.
- `plt.close(fig)` is executed.

### Checkpoint 8: Confusion Matrix Visualization
```python
labels = sorted(df["variety"].unique())
cm = confusion_matrix(y_test, predictions, labels=labels)
fig, ax = plt.subplots(figsize=(6, 4.6))
ConfusionMatrixDisplay(cm, display_labels=labels).plot(ax=ax, cmap="YlOrBr", colorbar=False)
ax.set_title("Pumpkin seed classification")
fig.tight_layout()
fig.savefig(OUT / "confusion_matrix.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```
**Mentor Verification**:
- Confusion matrix values:
  - Row 0 (Cercevelik): 12 Cercevelik, 0 Karacabey, 3 Urgup_Sivrisi
  - Row 1 (Karacabey): 0 Cercevelik, 12 Karacabey, 3 Urgup_Sivrisi
  - Row 2 (Urgup_Sivrisi): 0 Cercevelik, 0 Karacabey, 15 Urgup_Sivrisi
- Total diagonal correct = 12 + 12 + 15 = 39.

### Checkpoint 9: Diagnostic Log File Persistence
```python
with open(OUT / "rules.txt", "w", encoding="utf-8") as handle:
    for depth, (_, _, acc) in models.items():
        handle.write(f"depth={depth}: accuracy={acc:.4f}\n")
    handle.write(f"\nbest depth: {best_depth}\n\n")
    handle.write(export_text(model, feature_names=FEATURES))
    handle.write(f"\nnew seed prediction: {new_variety}\n")
    handle.write("\n" + classification_report(y_test, predictions, zero_division=0))
```
**Mentor Verification**:
- Ensure `outputs/rules.txt` contains all five sections formatted cleanly.

## Common Student Pitfalls & Debugging Guidance
1. **Unstratified Split**: Forgetting `stratify=y` changes test set balance and alters test accuracy percentages.
2. **Missing Backend Flag**: Forgetting `matplotlib.use("Agg")` leads to GUI backend crashes in headless environments.
3. **Passing 1D Array to predict()**: Passing a dictionary or 1D array instead of a 2D DataFrame raises `ValueError: Expected 2D array, got 1D array instead`.
4. **Incorrect Feature Names in plot_tree**: Supplying raw arrays without specifying `feature_names` produces generic labels like `x[0]` and `x[1]`.
