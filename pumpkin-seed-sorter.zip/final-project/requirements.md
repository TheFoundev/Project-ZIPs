# Final Project Requirements: The Pumpkin Seed Sorter

## Project Objective
Implement the complete, end-to-end **Pumpkin Seed Sorter** multi-class machine learning classification pipeline from scratch. Your implementation must follow the architecture of `main.py`, ingesting morphological features from `data/pumpkin_seeds.csv`, performing stratified dataset splitting, training and evaluating decision tree classifiers at varying depths, generating plain-English decision rules, performing single-sample physical seed inference, and saving graphical visualizations and diagnostic log artifacts.

## Functional Requirements

1. **Environment & Headless Configuration**
   - Ensure `matplotlib.use("Agg")` is called prior to importing `matplotlib.pyplot` to guarantee headless server execution without graphical display errors.
   - Use `pathlib.Path` to construct robust, cross-platform paths for `BASE`, `DATA`, and `OUT`.
   - Ensure the output directory `outputs/` is created automatically using `OUT.mkdir(exist_ok=True)`.

2. **Data Ingestion & Verification**
   - Read `data/pumpkin_seeds.csv` using `pd.read_csv()`.
   - Confirm that the dataset contains exactly 180 rows and 6 columns (`variety,area,perimeter,major_axis,minor_axis,eccentricity`).
   - Define `FEATURES = ["area", "perimeter", "major_axis", "minor_axis", "eccentricity"]`.
   - Isolate the feature matrix `X = df[FEATURES]` (shape: `180 x 5`).
   - Isolate the target label vector `y = df["variety"]` (shape: `180`).

3. **Stratified Train-Test Splitting**
   - Use `train_test_split` with `test_size=0.25`, `random_state=42`, and `stratify=y`.
   - Ensure the split yields:
     - `X_train`: 135 rows (45 Cercevelik, 45 Karacabey, 45 Urgup_Sivrisi)
     - `X_test`: 45 rows (15 Cercevelik, 15 Karacabey, 15 Urgup_Sivrisi)
     - `y_train`: 135 labels
     - `y_test`: 45 labels

4. **Multi-Depth Model Training & Evaluation**
   - Train `DecisionTreeClassifier(max_depth=depth, random_state=42)` across `depth in (2, 4, None)`.
   - Compute test set predictions using `model.predict(X_test)`.
   - Calculate test accuracy using `accuracy_score(y_test, predictions)`.
   - Store model objects, predictions, and accuracies in a dictionary.
   - Print depth comparison table to console with formatted accuracy percentages.
   - Select `best_depth` dynamically as the depth maximizing test accuracy.

5. **Rule Extraction & Classification Reporting**
   - Export the decision logic of the best model as human-readable text rules using `export_text(model, feature_names=FEATURES)`.
   - Print the complete multi-class `classification_report(y_test, predictions, zero_division=0)`.

6. **New Physical Seed Prediction**
   - Construct a DataFrame `new_seed` representing an unknown physical seed with:
     - `area = 1180`
     - `perimeter = 55.0`
     - `major_axis = 12.2`
     - `minor_axis = 5.7`
     - `eccentricity = 0.86`
   - Run `model.predict(new_seed)` and extract the predicted variety label string.
   - Verify the prediction outputs `Urgup_Sivrisi`.

7. **Visualization Deliverables**
   - **Decision Tree Diagram**:
     - Render figure with `fig, ax = plt.subplots(figsize=(16, 8))`.
     - Call `plot_tree(model, feature_names=FEATURES, class_names=list(model.classes_), filled=True, rounded=True, fontsize=8, ax=ax)`.
     - Save as `outputs/pumpkin_tree.png` with `dpi=150, bbox_inches="tight"`.
     - Call `plt.close(fig)`.
   - **Confusion Matrix Heatmap**:
     - Compute confusion matrix with `confusion_matrix(y_test, predictions, labels=sorted(df["variety"].unique()))`.
     - Plot using `ConfusionMatrixDisplay` with `cmap="YlOrBr"` and `colorbar=False`.
     - Save as `outputs/confusion_matrix.png` with `dpi=150, bbox_inches="tight"`.
     - Call `plt.close(fig)`.

8. **Diagnostic Text Logging**
   - Write `outputs/rules.txt` containing:
     - Accuracies for all evaluated tree depths.
     - The selected best depth.
     - Full plain-English rules from `export_text`.
     - The prediction result for `new_seed`.
     - Complete `classification_report`.

## Non-Functional Requirements
- **Reproducibility**: `random_state=42` must be explicitly supplied to `train_test_split` and `DecisionTreeClassifier`.
- **Determinism**: Results across runs must match expected benchmark numbers exactly (depth 2: 86.7%, depth 4: 84.4%, unlimited: 84.4%).
- **Code Cleanliness**: Follow PEP 8 conventions, include explanatory docstrings, and modularize logical steps.
- **Resource Management**: Always invoke `plt.close(fig)` after saving figures to avoid memory leaks.

## Implementation Milestones

| Milestone | Deliverable | Verification Check |
|---|---|---|
| Milestone 1 | Environment & Imports | Script runs without missing module errors; Agg backend active |
| Milestone 2 | Data Ingestion | `df.shape == (180, 6)` and columns match specification |
| Milestone 3 | Data Partitioning | `X_train.shape == (135, 5)` and `X_test.shape == (45, 5)` with balanced classes |
| Milestone 4 | Tree Induction & Depth Comparison | Console prints depth 2 (86.7%), depth 4 (84.4%), unlimited (84.4%) |
| Milestone 5 | Rule Extraction | `export_text` outputs clear nested boolean tree structure |
| Milestone 6 | Single Seed Inference | Prediction on `new_seed` evaluates to `Urgup_Sivrisi` |
| Milestone 7 | Tree Plotting | `outputs/pumpkin_tree.png` exists and is a valid image |
| Milestone 8 | Confusion Matrix | `outputs/confusion_matrix.png` exists and displays 3x3 matrix |
| Milestone 9 | Rules Logging | `outputs/rules.txt` exists and matches console metrics |
| Milestone 10 | Final Verification | End-to-end execution completes cleanly in under 5 seconds |

## Expected Output Values Benchmark

| Metric | Target Value | Verification Note |
|---|---|---|
| `max_depth=2` Accuracy | 86.7% (39 / 45) | Optimal model balance |
| `max_depth=4` Accuracy | 84.4% (38 / 45) | Slight overfitting on boundary samples |
| `max_depth=None` Accuracy | 84.4% (38 / 45) | Unpruned tree overfits training noise |
| Best Depth Selection | 2 | Selected dynamically by max accuracy |
| Cercevelik Precision / Recall | 1.00 / 0.80 | High purity, 3 missed seeds |
| Karacabey Precision / Recall | 1.00 / 0.80 | High purity, 3 missed seeds |
| Urgup_Sivrisi Precision / Recall | 0.71 / 1.00 | Captures all 15 seeds + 6 false positives |
| New Seed Prediction | Urgup_Sivrisi | Path: minor_axis <= 6.04 -> area > 1019.50 |
