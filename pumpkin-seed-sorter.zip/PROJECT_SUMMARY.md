# The Pumpkin Seed Sorter

## Overview
The **Pumpkin Seed Sorter** is a practical supervised machine learning project designed to automate agricultural seed classification. Utilizing morphological features (shape, size, elongation), the project trains and compares multiple **Decision Tree Classifiers** to accurately identify three commercial pumpkin seed cultivars:
- **Cercevelik**
- **Karacabey**
- **Urgup_Sivrisi**

The system compares shallow (`max_depth=2`), deeper (`max_depth=4`), and unconstrained (`max_depth=None`) trees, demonstrates the principle of Occam's razor (where the simplest model achieves the highest test accuracy of 86.7%), prints plain-English decision rules, renders graphical tree diagrams, and generates confusion matrices.

## Real-World Agricultural Context
Commercial seed producers need high cultivar purity for certified seed distribution and food processing. Manual inspection by human seed analysts is labor-intensive, slow, and prone to fatigue. Machine vision combined with decision tree classification enables automated optical sorting machines to inspect and divert seeds on high-speed conveyor belts at rates exceeding 50 seeds per second.

## Key Features
- **Morphological Analysis**: Leverages 5 physical features (`area`, `perimeter`, `major_axis`, `minor_axis`, `eccentricity`).
- **Stratified Partitioning**: Ensures 75/25 train-test split maintains exact 1:1:1 variety representation.
- **Depth Benchmark**: Rigorously tests depth limits to counter overfitting.
- **Transparent Rule Extraction**: Generates clear, auditable nested if-else statements via `export_text`.
- **Graphical Visualizations**: Produces publication-quality decision tree flowcharts and confusion matrix heatmaps.
- **Single-Sample Inference**: Evaluates incoming real-time sensor measurements.

## Technology Stack
- **Language**: Python 3
- **Data Manipulation**: `pandas`
- **Machine Learning**: `scikit-learn` (`DecisionTreeClassifier`, `export_text`, `plot_tree`, metrics)
- **Visualization**: `matplotlib` (using the headless `Agg` backend)

## Project Structure
```
15_pumpkin_seed_sorter/
├── main.py                     # Complete end-to-end classification pipeline
├── data/
│   └── pumpkin_seeds.csv       # Morphological measurements (180 seed samples)
└── outputs/
    ├── pumpkin_tree.png        # Graphical decision tree visualization
    ├── confusion_matrix.png    # Multi-class confusion matrix heatmap
    └── rules.txt               # Plain-text decision rules and evaluation metrics
```

## Getting Started
Navigate to the project directory and run:
```bash
python3 main.py
```

## Expected Performance Metrics
- **Best Depth**: `max_depth=2`
- **Test Accuracy**: **86.7%** (39 correct out of 45 test seeds)
- **Cercevelik**: Precision 1.00, Recall 0.80, F1 0.89
- **Karacabey**: Precision 1.00, Recall 0.80, F1 0.89
- **Urgup_Sivrisi**: Precision 0.71, Recall 1.00, F1 0.83
- **Sample Inference**: Novel seed (`area=1180, perimeter=55.0, major_axis=12.2, minor_axis=5.7, eccentricity=0.86`) correctly sorted as **Urgup_Sivrisi**.
