# Lesson 04: Predicting Unseen Physical Samples (The New Seed Inference)

**Lesson ID:** lesson-04  
**Module:** module-04  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Construct single-sample input DataFrames for real-time model inference.
- Explain why scikit-learn requires 2D tabular formats for `predict()`.
- Trace the inference of the `new_seed` test case in `main.py`.
- Implement end-to-end inference pipelines for real-time sensor streams.

## Prerequisites
- Lesson 03: Visualizing the Decision Tree with plot_tree.
- Familiarity with passing dictionaries to pandas DataFrames.

## Concept Explanation

### The Operational Goal: Real-Time Inference
Training a model on historical data is merely the preparation phase. The ultimate operational goal of the Pumpkin Seed Sorter is **live inference**: when a newly harvested, unknown seed passes beneath the camera, the system must ingest its measurements, query the trained decision tree, and issue a sorting command in real time.

```
[ Physical Seed on Conveyor ]
              │
              ▼
    [ Optical Camera ] ── Extracts geometric features
              │
              ▼
    [ Feature Vector ]: {"area": 1180, "perimeter": 55.0, ...}
              │
              ▼
    [ model.predict(new_seed) ] ── Traverses learned decision tree
              │
              ▼
    [ Predicted Cultivar ]: "Urgup_Sivrisi"
              │
              ▼
    [ Pneumatic Air Valve ] ── Fires burst to route to Urgup Hopper
```

### The 2D Shape Requirement in scikit-learn
Beginners often make the mistake of passing a 1D Python dictionary or list directly to `model.predict()`:
```python
# THIS RAISES A ValueError!
model.predict([1180, 55.0, 12.2, 5.7, 0.86])
```
Why does this fail? Because scikit-learn estimators are designed for batch processing. They expect a **2-dimensional feature matrix** with shape `(n_samples, n_features)`:
- Even when predicting a **single seed**, $n_{\text{samples}} = 1$. The shape must be `(1, 5)`.
- Passing a pandas DataFrame with explicit column names matching `FEATURES` guarantees that features align with the exact columns used during `model.fit()`.

### The Canonical Test Seed in `main.py`
In lines 59-63, `main.py` tests a realistic unknown seed:
```python
new_seed = pd.DataFrame(
    [{"area": 1180, "perimeter": 55.0, "major_axis": 12.2, "minor_axis": 5.7, "eccentricity": 0.86}]
)
new_variety = model.predict(new_seed)[0]
print(f"New seed -> {new_variety}")
```

Let us trace this sample through the learned tree:
1. `minor_axis` is $5.7$. Is $5.7 \le 6.04$? -> **YES** (Branch Left).
2. `area` is $1180$. Is $1180 \le 1019.50$? -> **NO** (Branch Right).
3. The right branch terminates at: `class: Urgup_Sivrisi`!
4. `model.predict(new_seed)` returns `array(['Urgup_Sivrisi'], dtype=object)`.
5. Extracting index `[0]` yields the clean string: `'Urgup_Sivrisi'`.

## Relevant Code (from main.py, lines 59-63)
```python
    new_seed = pd.DataFrame(
        [{"area": 1180, "perimeter": 55.0, "major_axis": 12.2, "minor_axis": 5.7, "eccentricity": 0.86}]
    )
    new_variety = model.predict(new_seed)[0]
    print(f"New seed -> {new_variety}")
```

## Code Deep-Dive Breakdown
- `[{"area": 1180, ...}]`: A list containing a single dictionary. When passed to `pd.DataFrame()`, this creates a DataFrame with 1 row and 5 columns.
- `model.predict(new_seed)`: Evaluates the decision tree in under 50 microseconds. It returns a 1D NumPy array of predictions.
- `[0]`: Extracts the scalar prediction string from the array.
- `print(f"New seed -> {new_variety}")`: Formats and outputs the result cleanly to standard output.

## Worked Example: Predicting a Batch of Incoming Seeds
In production, conveyor cameras often buffer a burst of 5 seeds at once:

```python
incoming_batch = pd.DataFrame([
    {"area": 920,  "perimeter": 48.0, "major_axis": 11.0, "minor_axis": 5.1, "eccentricity": 0.81},
    {"area": 1540, "perimeter": 66.0, "major_axis": 14.2, "minor_axis": 6.8, "eccentricity": 0.92},
    {"area": 1210, "perimeter": 56.0, "major_axis": 12.4, "minor_axis": 5.8, "eccentricity": 0.87},
    {"area": 860,  "perimeter": 45.0, "major_axis": 10.5, "minor_axis": 4.9, "eccentricity": 0.80},
    {"area": 1600, "perimeter": 68.0, "major_axis": 14.8, "minor_axis": 6.7, "eccentricity": 0.91},
])

batch_predictions = model.predict(incoming_batch)
for i, pred in enumerate(batch_predictions):
    print(f"Seed {i+1} -> {pred}")
```

**Output**:
```
Seed 1 -> Karacabey
Seed 2 -> Cercevelik
Seed 3 -> Urgup_Sivrisi
Seed 4 -> Karacabey
Seed 5 -> Cercevelik
```
The decision tree classifies all five seeds in a single vectorized pass!

## Step-by-Step Student Instructions
1. Inspect lines 59-63 of `main.py`.
2. Locate the definition of `new_seed`.
3. Run `main.py` and verify that the console outputs: `New seed -> Urgup_Sivrisi`.
4. Try modifying the values of `new_seed` (e.g., set `area=900, minor_axis=4.8`) and verify that the prediction changes to `Karacabey`.
5. Try setting `minor_axis=6.8, major_axis=14.0` and verify that the prediction changes to `Cercevelik`.

## Expected Output or Observable Behaviour
Console outputs:
```
New seed -> Urgup_Sivrisi
```
This confirms that the trained model successfully evaluates incoming physical measurements and produces valid cultivar predictions.

## Practical Exercises
- **Exercise 4.4a**: What error does scikit-learn raise if `new_seed` is missing the `major_axis` column? Test it in Python.
- **Exercise 4.4b**: Write a function `predict_seed(area, perimeter, major, minor, ecc)` that accepts five numbers and returns the predicted variety string.

## Common Mistakes and Debugging
| Mistake | Root Cause | Remediation |
|---|---|---|
| `ValueError: The feature names should match...` | Column names in `new_seed` don't match `FEATURES` | Use a dictionary with keys matching `FEATURES` exactly |
| Forgetting `[0]` index | Printing `['Urgup_Sivrisi']` as an array | Extract the string using `model.predict(new_seed)[0]` |
| Passing 1D list | `model.predict([1180, 55.0, ...])` | Wrap in DataFrame: `pd.DataFrame([{...}])` or 2D array `[[1180, ...]]` |

## Best Practices and Security Considerations
- **Input Validation**: Before passing sensor data to `model.predict()`, assert that feature values are physically plausible (e.g., `area > 0` and `minor_axis <= major_axis`).
- **Feature Alignment**: Always verify that the DataFrame columns passed to `predict()` match the exact ordering of `model.feature_names_in_`.

## Real-World Context and Agricultural Impact
In commercial seed sorting elevators, machine vision software writes predictions directly to a shared memory buffer polled by a PLC. If the prediction is `Urgup_Sivrisi`, Air Valve #3 fires 12 milliseconds later when the seed reaches the drop chute, sorting the seed at high speed.

## Summary
Single-sample inference allows trained decision trees to classify newly scanned physical seeds in real time. Passing a 1-row pandas DataFrame with column headers matching `FEATURES` satisfies scikit-learn's 2D input requirements. In `main.py`, the sample seed (`area=1180, minor_axis=5.7`) cleanly evaluates to `Urgup_Sivrisi`.

## Knowledge-check Questions
1. Why does `model.predict()` require a 2D array or DataFrame rather than a 1D list?
2. What cultivar is predicted for `new_seed` in `main.py`?
3. Which two features determine the classification of `new_seed`?
4. What index operation is used to extract the prediction string from the NumPy array?

## References
- scikit-learn Model Persistence and Inference: https://scikit-learn.org/stable/modules/model_persistence.html
- pandas DataFrame from Dict: https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.from_dict.html
- Project Source Code: `main.py` lines 59-63.
