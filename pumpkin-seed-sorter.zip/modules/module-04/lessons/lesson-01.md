# Lesson 01: Interpreting Decision Rules with export_text

**Lesson ID:** lesson-01  
**Module:** module-04  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain what `export_text` does and why text representations are vital for auditing.
- Parse the indentation syntax of scikit-learn's `export_text` output.
- Identify the feature names and numeric cutoffs used in the best tree.
- Extract boolean decision logic from ASCII tree representations.

## Prerequisites
- Module 03: Decision Trees on Shape Data.
- Familiarity with conditional statements (if, else) in programming.

## Concept Explanation

### Why Text Rules Matter
In high-stakes industrial applications—such as certified seed production, pharmaceutical manufacturing, or aerospace quality control—a graphical flowchart alone is often insufficient for formal compliance documentation. Regulators, software engineers, and plant operators require unambiguous, machine-readable, and version-controllable text rules.

Scikit-learn provides the `export_text` function in `sklearn.tree`. It traverses the internal binary tree data structure and formats every split as an indented ASCII text hierarchy.

### Reading `export_text` Syntax
The text output uses standard ASCII pipe and hyphen characters to denote tree hierarchy:
- `|---`: Represents a decision branch at the current depth level.
- `|   |---`: Represents a nested child decision branch one level deeper.
- `<= [value]`: Condition where the sample traverses to the left child branch.
- `>  [value]`: Condition where the sample traverses to the right child branch.
- `class: [ClassName]`: The majority class label assigned at that leaf node.

Here is the exact text exported from our optimal `max_depth=2` model in `main.py`:
```
|--- minor_axis <= 6.04
|   |--- area <= 1019.50
|   |   |--- class: Karacabey
|   |--- area >  1019.50
|   |   |--- class: Urgup_Sivrisi
|--- minor_axis >  6.04
|   |--- major_axis <= 12.58
|   |   |--- class: Urgup_Sivrisi
|   |--- major_axis >  12.58
|   |   |--- class: Cercevelik
```

### Agronomic Interpretation of the Rules
Notice something remarkable about this tree:
1. **Feature Reduction**: Out of the five available features (`area`, `perimeter`, `major_axis`, `minor_axis`, `eccentricity`), the decision tree selected only **three** features (`minor_axis`, `area`, `major_axis`). It completely ignored `perimeter` and `eccentricity`! Why? Because once width (`minor_axis`) and surface area (`area`) are known, perimeter and eccentricity provide redundant information.
2. **Dominant Split (Root Node)**: The very first question asked by the tree is: *"Is minor_axis <= 6.04 mm?"* This single geometric criterion cleanly separates broad, chunky seeds from slender, compact seeds.
3. **Left Subtree (Narrow Seeds, <= 6.04 mm)**:
   - If the seed is also small (`area <= 1019.50 mm²`), it is classified as **Karacabey**.
   - If the seed is larger (`area > 1019.50 mm²`), it is classified as **Urgup_Sivrisi**.
4. **Right Subtree (Wide Seeds, > 6.04 mm)**:
   - If the seed is exceptionally long (`major_axis > 12.58 mm`), it is classified as **Cercevelik**.
   - If the seed is shorter (`major_axis <= 12.58 mm`), it is classified as **Urgup_Sivrisi**.

## Relevant Code (from main.py, lines 55-56)
```python
    print("
Learned rules for the best tree:
")
    print(export_text(model, feature_names=FEATURES))
```

## Code Deep-Dive Breakdown
- `export_text(model, feature_names=FEATURES)`: Takes two primary arguments:
  - `model`: The trained `DecisionTreeClassifier` instance.
  - `feature_names=FEATURES`: Supplies the human-readable list of feature names (`["area", "perimeter", "major_axis", "minor_axis", "eccentricity"]`). If this argument were omitted, scikit-learn would print unhelpful generic labels like `feature_3 <= 6.04` and `feature_0 <= 1019.50`!
- The function returns a single formatted string that can be printed to the console or written to a text file.

## Worked Example
Let us write a tiny script to test `export_text` options:

```python
from sklearn.tree import export_text

# Standard export
rules = export_text(model, feature_names=FEATURES, show_weights=True)
print(rules)
```

With `show_weights=True`, scikit-learn appends the exact training sample counts reaching each leaf:
```
|--- minor_axis <= 6.04
|   |--- area <= 1019.50
|   |   |--- class: Karacabey  weights: [0, 42, 2]
|   |--- area >  1019.50
|   |   |--- class: Urgup_Sivrisi  weights: [0, 3, 38]
|--- minor_axis >  6.04
|   |--- major_axis <= 12.58
|   |   |--- class: Urgup_Sivrisi  weights: [3, 0, 5]
|   |--- major_axis >  12.58
|   |   |--- class: Cercevelik  weights: [42, 0, 0]
```
Look at the leaf `weights: [42, 0, 0]`: among wide and long seeds, all 42 training samples are Cercevelik with 0 Karacabey and 0 Urgup_Sivrisi! That is a 100% pure leaf!

## Step-by-Step Student Instructions
1. Inspect lines 55-56 of `main.py`.
2. Notice the call to `export_text`.
3. Verify that the output printed matches the four nested branches above.
4. Try omitting `feature_names=FEATURES` to see why providing explicit feature names is essential for readability.

## Expected Output or Observable Behaviour
Console outputs show the complete plain-text rule hierarchy. Plant engineers can read and verify these rules without knowing Python or scikit-learn.

## Practical Exercises
- **Exercise 4.1a**: What feature names would be printed if `feature_names` was not passed to `export_text`?
- **Exercise 4.1b**: Write a brief paragraph explaining the difference between the root threshold (6.04) and the two second-level thresholds (1019.50 and 12.58).

## Common Mistakes and Debugging
| Mistake | Root Cause | Remediation |
|---|---|---|
| Printing `feature_0`, `feature_1` | Omitting `feature_names=FEATURES` | Always pass `feature_names=FEATURES` to `export_text` to display meaningful variable names |
| Passing feature names in wrong order | Mismatched list order | Ensure `feature_names` matches the exact column order of `X` |

## Best Practices and Security Considerations
- **Audit Trails**: Save the output of `export_text` alongside trained model binaries so production teams have an immutable record of the model's exact rules.
- **Rule Verification**: Before deploying to hardware, verify that the thresholds make physical sense (e.g. area thresholds should be positive numbers within natural seed bounds).

## Real-World Context and Agricultural Impact
In agricultural sorting facilities, plant managers often set up threshold alerts based on exported rules. If an optical sensor drifts due to dust accumulation on the camera lens, the measured minor axis might shift by 0.5 mm, throwing off sorting accuracy. Having explicit numerical rules allows maintenance crews to quickly calibrate sensors.

## Summary
The `export_text` utility translates complex decision tree topologies into clean, readable ASCII if-then rules. In `main.py`, the depth 2 model produces four concise rules utilizing only three features (`minor_axis`, `area`, and `major_axis`), providing complete transparency into the sorting mechanism.

## Knowledge-check Questions
1. What does the `|---` prefix represent in `export_text`?
2. What happens if you call `export_text` without passing `feature_names`?
3. Which three features were chosen by the best decision tree model?
4. What does the class label at the end of a branch indicate?

## References
- scikit-learn `export_text` Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.tree.export_text.html
- Interpretability in Machine Learning: Christoph Molnar, Interpretable Machine Learning (2022).
- Project Source Code: `main.py` lines 55-56.
