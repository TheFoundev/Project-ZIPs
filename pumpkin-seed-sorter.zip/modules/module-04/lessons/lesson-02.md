# Lesson 02: Tracing Seed Varieties Through Geometric Thresholds

**Lesson ID:** lesson-02  
**Module:** module-04  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Manually trace physical seed measurements through the decision tree logic.
- Predict the cultivar of unknown seeds by following boolean branch conditions.
- Understand how boundary conditions and edge cases are resolved at decision nodes.
- Explain why Urgup_Sivrisi appears in two distinct leaf nodes of the tree.

## Prerequisites
- Lesson 01: Interpreting Decision Rules with export_text.
- Understanding basic comparison operators (`<=` and `>`).

## Concept Explanation

### The Tracing Algorithm
To trace an individual seed through a decision tree:
1. **Start at Root**: Begin at the top-level test (`minor_axis <= 6.04`).
2. **Evaluate Condition**: Compare the seed's `minor_axis` against `6.04`.
   - If `True` ($\le 6.04$), branch to the Left Subtree.
   - If `False` ($> 6.04$), branch to the Right Subtree.
3. **Evaluate Second-Level Condition**:
   - In the Left Subtree, test: `area <= 1019.50`.
     - If `True`, output **Karacabey**.
     - If `False`, output **Urgup_Sivrisi**.
   - In the Right Subtree, test: `major_axis <= 12.58`.
     - If `True`, output **Urgup_Sivrisi**.
     - If `False`, output **Cercevelik**.
4. **Reach Terminal Leaf**: The leaf's class label is the model's final prediction!

```
                    Seed Arrives
                         │
              Is minor_axis <= 6.04?
                     /                      Yes   /          \   No
                   /                      Is area <= 1019.5?    Is major_axis <= 12.58?
              /        \            /                  Yes  /          \ No   Yes /            \ No
            /            \        /                    [ Karacabey ]  [ Urgup ] [ Urgup ]   [ Cercevelik ]
```

### Why Does Urgup_Sivrisi Appear in Two Leaves?
Notice a fascinating biological nuance: **Urgup_Sivrisi is predicted in two different leaf nodes!**
- **Leaf 2 (Left Branch)**: `minor_axis <= 6.04` AND `area > 1019.50`.
  These are standard, slender Urgup_Sivrisi seeds that have narrow bellies but moderate-to-large overall area.
- **Leaf 3 (Right Branch)**: `minor_axis > 6.04` AND `major_axis <= 12.58`.
  These are slightly plumper Urgup_Sivrisi seeds (belly width $> 6.04$), but they are distinguishable from Cercevelik because their length (`major_axis`) is shorter than Cercevelik's massive $> 12.58$ mm threshold.

Because a decision tree partitions feature space into hyper-rectangles, a single non-convex biological class can easily occupy multiple disjoint regions across the tree!

## Relevant Code (from main.py, lines 55-56, 95)
```python
# The four canonical rules in outputs/rules.txt:
|--- minor_axis <= 6.04
|   |--- area <= 1019.50
|   |   |--- class: Karacabey
|   |--- area >  1019.50
|   |   |--- class: Urgup_Sivrisi
|--- minor_axis >  6.04
|   |--- major_axis <= 12.58
|   |   |--- class: Urgup_Sivrisi
|   |--- major_axis >  12.58
|   |   |--- class: Cercevelik
```

## Code Deep-Dive Breakdown
- Every seed specimen is guaranteed to fall into exactly one of these four mutually exclusive terminal leaves.
- The decision logic requires at most **two comparisons** per seed, making inference deterministic and blazingly fast.

## Worked Example: Tracing Three Real Seeds
Let us manually trace three actual seeds from `pumpkin_seeds.csv`:

### Seed 1: Compact Seed
- Measurements: `area = 937`, `minor_axis = 4.86`, `major_axis = 10.46`
- **Step 1**: Is `minor_axis (4.86) <= 6.04`? -> **YES** (Branch Left).
- **Step 2**: Is `area (937) <= 1019.50`? -> **YES** (Branch Left).
- **Result**: **Karacabey**. (Matches true ground-truth label!)

### Seed 2: Massive Seed
- Measurements: `area = 1560`, `minor_axis = 6.66`, `major_axis = 14.31`
- **Step 1**: Is `minor_axis (6.66) <= 6.04`? -> **NO** (Branch Right).
- **Step 2**: Is `major_axis (14.31) <= 12.58`? -> **NO** (Branch Right).
- **Result**: **Cercevelik**. (Matches true ground-truth label!)

### Seed 3: Elongated Confectionery Seed
- Measurements: `area = 1198`, `minor_axis = 5.25`, `major_axis = 11.85`
- **Step 1**: Is `minor_axis (5.25) <= 6.04`? -> **YES** (Branch Left).
- **Step 2**: Is `area (1198) <= 1019.50`? -> **NO** (Branch Right).
- **Result**: **Urgup_Sivrisi**. (Matches true ground-truth label!)

Every single prediction is derived through transparent, verifiable arithmetic.

## Step-by-Step Student Instructions
1. Take a clean sheet of paper or text editor.
2. Given a seed with `area=1350`, `minor_axis=6.4`, `major_axis=12.2`:
   - Check condition 1: `6.4 <= 6.04`? (False).
   - Check condition 2: `12.2 <= 12.58`? (True).
   - Determine the prediction: `Urgup_Sivrisi`.
3. Given a seed with `area=880`, `minor_axis=4.9`, `major_axis=10.8`:
   - Check condition 1: `4.9 <= 6.04`? (True).
   - Check condition 2: `880 <= 1019.50`? (True).
   - Determine the prediction: `Karacabey`.
4. Verify your manual conclusions by running them through `model.predict()`.

## Expected Output or Observable Behaviour
Following the rules manually yields identical results to running `model.predict()` in scikit-learn, proving that machine learning inference is simply the execution of mathematical logic.

## Practical Exercises
- **Exercise 4.2a**: What cultivar would be predicted for a seed with `minor_axis = 6.04` exactly? (Look closely at the comparison operator: is it `<` or `<=`).
- **Exercise 4.2b**: If an off-type melon seed with `area = 500, minor_axis = 3.0` entered the sorter, what would the tree predict? Why?

## Common Mistakes and Debugging
| Mistake | Root Cause | Remediation |
|---|---|---|
| Misreading `<=` as `<` | Overlooking boundary equality | If a measurement is exactly equal to the threshold (e.g., 6.040), `<=` evaluates to True and branches left |
| Confusing major and minor axis | Swapping axis values during manual trace | Major axis is the long length; minor axis is the narrow belly width |

## Best Practices and Security Considerations
- **Boundary Precision**: Ensure that sensor measurements use the same floating-point precision as the learned model thresholds (typically float32 or float64).
- **Outlier Handling**: The decision tree will assign every input to one of the three known cultivars, even if the input is an outlier pebble or weed seed. In industrial systems, add a pre-filter gating check (`area > 500`) to reject non-seed debris before applying cultivar rules.

## Real-World Context and Agricultural Impact
In certified seed auditing, if an import authority challenges the purity of an Urgup_Sivrisi container, the exporter can provide the exact tracing report showing that 99.4% of inspected seeds cleared the `minor_axis <= 6.04` and `area > 1019.50` threshold gates.

## Summary
Tracing seed varieties through the decision tree involves evaluating at most two scalar threshold conditions. Each seed routes through the tree into one of four leaves. The cultivar Urgup_Sivrisi appears in two distinct leaves, successfully capturing both standard slender seeds and slightly wider seeds with shorter lengths.

## Knowledge-check Questions
1. How many sequential comparisons are required to classify any seed in this tree?
2. Why is Urgup_Sivrisi represented by two separate leaf nodes in the tree?
3. If a seed has `minor_axis = 5.5` and `area = 1100`, which leaf node does it reach?
4. What happens if a non-seed object (like a pebble) is fed into the tree?

## References
- scikit-learn Tree Traversal Reference: https://scikit-learn.org/stable/auto_examples/tree/plot_unveil_tree_structure.html
- Project Source Code: `main.py` lines 54-56.
