# Lesson 03: Visualizing the Decision Tree with plot_tree

**Lesson ID:** lesson-03  
**Module:** module-04  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Generate high-resolution graphical decision trees using `plot_tree`.
- Understand and customize key `plot_tree` parameters (`filled`, `rounded`, `class_names`, `fontsize`).
- Interpret visual node color saturation and class purity.
- Save publication-quality figures using `matplotlib` and `savefig`.

## Prerequisites
- Lesson 02: Tracing Seed Varieties Through Geometric Thresholds.
- Familiarity with `matplotlib` figures and axes.

## Concept Explanation

### The Power of Visual Trees
While `export_text` provides a clean text hierarchy, humans process visual spatial patterns much faster than text. Visual decision tree flowcharts allow engineers, agronomists, and executives to grasp the entire model architecture at a single glance.

Scikit-learn provides `plot_tree` in `sklearn.tree`. It integrates directly with `matplotlib` to render rectangular nodes, directional arrows, threshold labels, sample counts, and class colors.

```
+--------------------------------------------------------------+
|                    minor_axis <= 6.04                        |
|                       gini = 0.667                           |
|                      samples = 135                           |
|                  value = [45, 45, 45]                        |
|                   class = Cercevelik                         |
+------------------------------+-------------------------------+
                               |
              +----------------+----------------+
              |                                 |
              v                                 v
+-----------------------------+   +----------------------------+
|      area <= 1019.50        |   |    major_axis <= 12.58     |
|        gini = 0.499         |   |        gini = 0.281        |
|        samples = 83         |   |        samples = 52        |
|     value = [0, 45, 38]     |   |     value = [45, 0, 7]     |
|      class = Karacabey      |   |     class = Cercevelik     |
+-----------------------------+   +----------------------------+
```

### Deconstructing the Node Box Contents
Inside every node rendered by `plot_tree`, five key lines of information are displayed:
1. **Splitting Condition**: (e.g., `minor_axis <= 6.04`). The boolean threshold test. (Leaf nodes omit this line).
2. **`gini`**: The Gini impurity of the samples currently in this node.
3. **`samples`**: The total count of training samples that reached this node.
4. **`value`**: The vector of sample counts per class: `[n_Cercevelik, n_Karacabey, n_Urgup_Sivrisi]`.
5. **`class`**: The majority class label among the samples in `value`.

### Color Coding with `filled=True`
When `filled=True` is enabled, `plot_tree` paints each node with a color corresponding to its predicted class:
- In our project, Cercevelik is typically tinted orange/red, Karacabey is tinted green, and Urgup_Sivrisi is tinted purple/blue.
- **Color Saturation**: The intensity of the color represents node purity (Gini score).
  - A node with high impurity (e.g. root node with `gini = 0.667`) is tinted a pale, washed-out pastel color.
  - A completely pure leaf node (`gini = 0.0`) is painted in deep, vibrant, 100% saturated color!

## Relevant Code (from main.py, lines 65-79)
```python
    # ---- Draw the tree -------------------------------------------------
    fig, ax = plt.subplots(figsize=(16, 8))
    plot_tree(
        model,
        feature_names=FEATURES,
        class_names=list(model.classes_),
        filled=True,
        rounded=True,
        fontsize=8,
        ax=ax,
    )
    ax.set_title("Pumpkin seed decision tree")
    fig.tight_layout()
    fig.savefig(OUT / "pumpkin_tree.png", dpi=150, bbox_inches="tight")
    plt.close(fig)
```

## Code Deep-Dive Breakdown
- `fig, ax = plt.subplots(figsize=(16, 8))`: Creates a wide canvas (16 inches wide by 8 inches tall) ensuring sufficient horizontal space so node boxes do not overlap.
- `feature_names=FEATURES`: Labels splits with feature names like `minor_axis` rather than `x[3]`.
- `class_names=list(model.classes_)`: Labels predicted classes with actual names (`Cercevelik`, `Karacabey`, `Urgup_Sivrisi`) rather than class indices `0, 1, 2`.
- `filled=True`: Fills node boxes with class-specific colors saturated by purity.
- `rounded=True`: Draws aesthetically pleasing rounded rectangular corners on node boxes.
- `fontsize=8`: Sets text size small enough to fit within boxes without truncating words.
- `fig.savefig(..., dpi=150, bbox_inches="tight")`: Saves a sharp, high-resolution image (150 dots per inch) with tight bounding margins.
- `plt.close(fig)`: Crucial memory cleanup! Destroys the figure canvas in memory to prevent memory leaks during batch execution.

## Worked Example
Suppose you run `main.py` and inspect `outputs/pumpkin_tree.png`. Look at the bottom-right leaf:
- Condition: *(None - it is a leaf)*
- `gini = 0.0`
- `samples = 42`
- `value = [42, 0, 0]`
- `class = Cercevelik`

This leaf is rendered as a deep, fully saturated orange box. It tells you instantly: *"42 training seeds landed here, every single one was Cercevelik, and Gini impurity is zero."*

## Step-by-Step Student Instructions
1. Run `python main.py`.
2. Verify that `outputs/pumpkin_tree.png` has been created.
3. Open `outputs/pumpkin_tree.png` in an image viewer or VS Code preview.
4. Locate the root node and observe `samples = 135` and `gini = 0.667`.
5. Trace down to the four leaf nodes at the bottom.
6. Verify that the two leaves corresponding to Karacabey and Cercevelik have high purity.

## Expected Output or Observable Behaviour
An image file `outputs/pumpkin_tree.png` of size ~150KB to ~300KB is generated. It shows a crisp, publication-quality tree with 7 total nodes (3 decision nodes and 4 leaf nodes).

## Practical Exercises
- **Exercise 4.3a**: Change `figsize=(8, 4)` and rerun the script. What happens to the readability of the text in the node boxes?
- **Exercise 4.3b**: What error occurs if `class_names` is provided in an order different from `model.classes_`?

## Common Mistakes and Debugging
| Mistake | Root Cause | Remediation |
|---|---|---|
| Overlapping, unreadable text in tree nodes | Figure size too small for tree depth | Increase figure width: `figsize=(16, 8)` or decrease `fontsize=8` |
| Labels say `y[0]`, `y[1]` instead of cultivar names | Omitting `class_names=list(model.classes_)` | Pass `class_names=list(model.classes_)` to map integers to cultivar strings |
| Memory leaks in batch scripts | Forgetting `plt.close(fig)` | Always call `plt.close(fig)` immediately after `savefig` |

## Best Practices and Security Considerations
- **Headless Agg Backend**: Always configure `matplotlib.use("Agg")` at the very start of the script to avoid GUI initialization errors on servers.
- **High-DPI Export**: Use `dpi=150` or `dpi=300` when saving figures for engineering reports or scientific publications.

## Real-World Context and Agricultural Impact
In agricultural equipment manufacturing, engineers include printed copies of `pumpkin_tree.png` inside the operational user manual for commercial optical seed sorters. Field technicians can reference the flowchart during seasonal calibration.

## Summary
`plot_tree` renders trained decision trees into rich, publication-ready diagrams. Parameters such as `filled=True`, `rounded=True`, `feature_names`, and `class_names` create an intuitive visual model where node color and saturation reflect class purity. Saving with `fig.savefig(..., dpi=150)` and closing with `plt.close(fig)` ensures clean file generation.

## Knowledge-check Questions
1. What does the color saturation of a node box indicate when `filled=True`?
2. What five pieces of information are displayed inside each decision node box?
3. Why is `plt.close(fig)` essential after saving a plot?
4. What happens if `feature_names` is omitted from `plot_tree`?

## References
- scikit-learn `plot_tree` Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.tree.plot_tree.html
- Matplotlib Figure and Axes API: https://matplotlib.org/stable/api/figure_api.html
- Project Source Code: `main.py` lines 65-79.
