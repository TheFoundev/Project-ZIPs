# Module 4 Exercises: Rules, Visualization, and Inference

## Exercise 4.1: Exporting and Parsing Tree Rules (15 min)
**Objective:** Use `export_text` and write a custom parser for decision tree rules.  
**Problem Statement:** Replicate the training of the best model (`max_depth=2`) and capture the output of `export_text(model, feature_names=FEATURES)` into a Python string variable. Write code to count how many leaf nodes exist in the exported rule string.

**Requirements:**
1. Train the depth 2 model on `X_train` and `y_train`.
2. Generate the rule text using `export_text`.
3. Count the occurrences of `"class:"` in the text string to verify there are exactly 4 leaf nodes.
4. Save the exported rules to a text file `outputs/my_rules.txt`.

**Constraints:** Use standard Python string methods (`count()`).

**Expected Behaviour:** The script prints the rules and asserts that the leaf count equals 4.

**Acceptance Criteria:**
- [ ] Successfully calls `export_text` with `feature_names=FEATURES`.
- [ ] Correctly identifies 4 leaf classes in the rule text.
- [ ] Writes the formatted text file to disk.

**Hints:**
- Each terminal leaf in `export_text` contains the keyword `"class:"`.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 4.2: Manual Seed Tracing Function (15 min)
**Objective:** Implement a manual decision tree simulator in Python.  
**Problem Statement:** Without using scikit-learn, implement a Python function `trace_seed(minor_axis: float, area: float, major_axis: float) -> str` that mimics the four rules of the best tree. Test it against 10 random samples from `X_test` and compare against `model.predict()`.

**Requirements:**
1. Implement the nested if-else logic:
   - If `minor_axis <= 6.04`:
     - If `area <= 1019.50` -> `"Karacabey"`
     - Else -> `"Urgup_Sivrisi"`
   - Else:
     - If `major_axis <= 12.58` -> `"Urgup_Sivrisi"`
     - Else -> `"Cercevelik"`
2. Iterate through 10 rows of `X_test`.
3. Assert that `trace_seed()` outputs match `model.predict()` for all 10 rows.

**Constraints:** Pure Python control flow.

**Expected Behaviour:** Complete agreement between manual simulation and scikit-learn predictions.

**Acceptance Criteria:**
- [ ] Correctly implements all four threshold comparisons.
- [ ] Verifies 100% agreement with `model.predict()` on the test subset.
- [ ] Demonstrates understanding of how decision trees execute conditional logic.

**Hints:**
- Review the tracing flowchart in Lesson 02.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 4.3: Customizing plot_tree Visualizations (15 min)
**Objective:** Customize decision tree diagrams using matplotlib and plot_tree.  
**Problem Statement:** Write a script that trains the `max_depth=2` model and creates an alternative visualization of the decision tree with custom styling.

**Requirements:**
1. Initialize figure with `figsize=(14, 7)`.
2. Call `plot_tree()` with `feature_names=FEATURES`, `class_names=list(model.classes_)`, `filled=True`, and `rounded=True`.
3. Add a descriptive subtitle detailing the test accuracy (86.7%) and sample size (135 train, 45 test).
4. Save the figure to `outputs/custom_tree.png` with `dpi=300`.
5. Call `plt.close(fig)` to clean up memory.

**Constraints:** Must use `matplotlib.use("Agg")` for headless safety.

**Expected Behaviour:** A high-resolution PNG image with custom title and styling saved to the outputs folder.

**Acceptance Criteria:**
- [ ] Custom tree diagram renders cleanly without clipped labels.
- [ ] Image saved at 300 DPI resolution.
- [ ] Matplotlib resources properly released with `plt.close()`.

**Hints:**
- Use `ax.set_title("...", fontsize=14, fontweight="bold")`.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 4.4: Batch Inference and Throughput Benchmarking (15 min)
**Objective:** Benchmark inference latency on incoming physical seed batches.  
**Problem Statement:** Industrial seed sorting requires microsecond-level latency. Write a Python script to measure how long `model.predict()` takes to evaluate 1,000 simulated seed measurements.

**Requirements:**
1. Generate a synthetic DataFrame of 1,000 seeds using random distributions matching real seed ranges:
   - `area` between 850 and 1650
   - `minor_axis` between 4.5 and 7.0
   - `major_axis` between 10.0 and 15.5
2. Measure the elapsed time of `model.predict(batch)` using Python's `time.perf_counter()`.
3. Compute the average prediction latency per seed in microseconds.
4. Verify that per-seed latency is under 100 microseconds.

**Constraints:** Use `time.perf_counter()` for precision timing.

**Expected Behaviour:** Console output showing total batch time and per-seed latency in microseconds.

**Acceptance Criteria:**
- [ ] Successfully runs batch prediction on 1,000 synthetic seeds.
- [ ] Computes per-seed inference latency in microseconds.
- [ ] Confirms decision trees easily meet industrial sorting speed requirements.

**Hints:**
- `latency_microseconds = (elapsed_seconds / 1000) * 1_000_000`.

**Difficulty:** Advanced  
**Estimated Completion Time:** 15 minutes  
