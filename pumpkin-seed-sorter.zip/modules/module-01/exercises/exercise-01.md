# Module 1 Exercises: Agricultural Sorting & Problem Framing

## Exercise 1.1: Agricultural Problem Formulation (15 min)
**Objective:** Define the business and operational requirements of automated seed sorting.  
**Problem Statement:** You are the lead machine learning engineer at an agricultural processing facility. A seed cooperative has provided raw harvest bags containing mixed pumpkin seed cultivars. You must formulate an automated machine learning problem to separate these cultivars.

**Requirements:**
1. Define the input features available from conveyor vision cameras.
2. Identify the target prediction output and state whether this is regression, binary classification, or multi-class classification.
3. List the three pumpkin cultivars handled by the system (Cercevelik, Karacabey, Urgup_Sivrisi).
4. Explain why manual human sorting cannot keep pace with commercial harvest volumes.

**Constraints:** Base your answers on the actual project architecture and dataset description in `main.py`.

**Expected Behaviour:** A written technical specification (4-6 sentences) clearly establishing the problem type, input-output variables, and operational rationale.

**Acceptance Criteria:**
- [ ] Correctly identifies the task as supervised multi-class classification.
- [ ] Explicitly lists all three pumpkin seed cultivars.
- [ ] Identifies geometric silhouette measurements as the input features.
- [ ] Articulates throughput, fatigue, and economic reasons for automated sorting.

**Hints:**
- Look at the target column `variety` in `data/pumpkin_seeds.csv`.
- Notice that there are 3 distinct classes, meaning it cannot be binary classification.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 1.2: Morphological Feature Analysis (15 min)
**Objective:** Understand and compare physical seed dimensions.  
**Problem Statement:** An optical camera captures two seeds on a conveyor belt:
- **Seed Alpha**: Area = 1580, Perimeter = 65.5, Major Axis = 14.5, Minor Axis = 6.8, Eccentricity = 0.90
- **Seed Beta**: Area = 890, Perimeter = 48.0, Major Axis = 11.0, Minor Axis = 5.0, Eccentricity = 0.81

Analyze their geometric dimensions to formulate an intuitive sorting hypothesis.

**Requirements:**
1. Compare the surface area and minor axis of Seed Alpha versus Seed Beta.
2. Hypothesize which cultivar corresponds to Seed Alpha and which to Seed Beta based on the descriptions in Lesson 02.
3. Explain the geometric meaning of eccentricity and compare the elongation of the two seeds.

**Constraints:** Use the physical characteristics described in the project lessons.

**Expected Behaviour:** A structured comparative analysis table and short explanatory paragraph.

**Acceptance Criteria:**
- [ ] Identifies Seed Alpha as Cercevelik due to large area (> 1500) and wide minor axis (> 6.5).
- [ ] Identifies Seed Beta as Karacabey due to small area (< 1000) and narrow minor axis.
- [ ] Explains that higher eccentricity (0.90 vs 0.81) indicates a more elongated silhouette.

**Hints:**
- Cercevelik seeds are the largest and widest of the three cultivars.
- Karacabey seeds are the smallest and most compact.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 1.3: Supervised Multi-Class vs Regression Comparison (15 min)
**Objective:** Compare mathematical differences between regression and multi-class classification.  
**Problem Statement:** A student suggests replacing the decision tree classifier with a linear regression model that predicts a number from 1 to 3 for the varieties. Evaluate this suggestion.

**Requirements:**
1. Explain why assigning arbitrary numbers (e.g., Cercevelik=1, Karacabey=2, Urgup_Sivrisi=3) creates a false mathematical ordering.
2. Explain what would happen if a regression model predicted 2.4.
3. Contrast evaluation metrics: explain why MAE and R² cannot properly evaluate categorical accuracy.
4. State why `DecisionTreeClassifier` is mathematically appropriate.

**Constraints:** Use formal machine learning definitions of continuous vs categorical targets.

**Expected Behaviour:** A clear technical argument explaining the dangers of treating categorical targets as numeric regression variables.

**Acceptance Criteria:**
- [ ] Explains that nominal categories have no intrinsic mathematical distance or ordering.
- [ ] Identifies that fractional predictions (e.g. 2.4) have no physical meaning in cultivar identity.
- [ ] Concludes that multi-class classification via decision trees is the principled approach.

**Hints:**
- Does Karacabey (2) lie "halfway between" Cercevelik (1) and Urgup_Sivrisi (3)?
- Nominal classes have no order; they are discrete labels.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 1.4: Decision Tree White-Box Logic Translation (15 min)
**Objective:** Translate learned decision tree rules into executable Python control flow.  
**Problem Statement:** Take the canonical rules printed by `export_text` in `main.py` and implement a pure Python function `manual_sort(minor_axis, area, major_axis) -> str`.

**Requirements:**
1. Implement the nested logic:
   - If `minor_axis <= 6.04`:
     - If `area <= 1019.50` return `"Karacabey"`
     - Else return `"Urgup_Sivrisi"`
   - If `minor_axis > 6.04`:
     - If `major_axis <= 12.58` return `"Urgup_Sivrisi"`
     - Else return `"Cercevelik"`
2. Test the function on the project's new seed sample (`area=1180, minor_axis=5.7, major_axis=12.2`).
3. Verify that the return value matches `main.py`'s output (`"Urgup_Sivrisi"`).

**Constraints:** Write clean Python code without importing scikit-learn.

**Expected Behaviour:** A working standalone Python function demonstrating the white-box interpretability of decision trees.

**Acceptance Criteria:**
- [ ] Function correctly implements all four branch outcomes.
- [ ] Test call with the new seed sample returns `"Urgup_Sivrisi"`.
- [ ] Demonstrates how decision tree logic translates directly into simple if-else code.

**Hints:**
- Follow the indentation levels shown in the `export_text` output in Lesson 04.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  
