# Lesson 03: Multi-Class Classification vs Binary & Regression

**Lesson ID:** lesson-03  
**Module:** module-01  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Distinguish multi-class classification from binary classification and regression.
- Identify the categorical target variable in `pumpkin_seeds.csv` (`variety`).
- Understand how decision trees naturally handle multi-class targets without one-vs-rest transformations.
- Contrast output representations across regression, binary classification, and multi-class tasks.

## Prerequisites
- Lesson 02: Morphological Features & Geometric Classification.
- Familiarity with supervised machine learning fundamentals.

## Concept Explanation

### The Supervised Learning Spectrum
Supervised learning tasks are categorized by the mathematical structure of their target variable ($y$):

```
                       Supervised Learning
                                │
        ┌───────────────────────┴───────────────────────┐
        ▼                                               ▼
   Regression                                    Classification
(Continuous target)                            (Categorical target)
 e.g., Predict seed weight                       │
       y ∈ [0.15g, 0.45g]               ┌────────┴────────┐
                                        ▼                 ▼
                                     Binary          Multi-Class
                                (2 categories)      (3+ categories)
                                e.g., Seed vs Dirt   e.g., Cercevelik vs
                                      y ∈ {0, 1}           Karacabey vs
                                                           Urgup_Sivrisi
```

1. **Regression**:
   - The target $y$ is a continuous numeric value on the real number line (e.g., predicting the exact oil content percentage or sales volume).
   - Metrics include Mean Squared Error (MSE), Mean Absolute Error (MAE), and $R^2$.
2. **Binary Classification**:
   - The target $y$ belongs to one of exactly two discrete states (e.g., diseased vs healthy, defective seed vs viable seed).
   - Often mapped to binary integers $\{0, 1\}$.
3. **Multi-Class Classification**:
   - The target $y$ belongs to one of $C$ mutually exclusive discrete categories ($C \ge 3$).
   - In our pumpkin seed project, $C = 3$:
     $$y \in \{ \text{Cercevelik}, \text{Karacabey}, \text{Urgup_Sivrisi} \}$$

### Why Multi-Class Requires Distinct Evaluation
In regression, a prediction of $44.6$ when the true value is $40.0$ has an error of $+4.6$. In classification, errors are qualitative misclassifications: predicting `Karacabey` when the true seed is `Urgup_Sivrisi`. There is no concept of being "slightly off" between qualitative categories.

Furthermore, multi-class problems introduce complex cross-class confusion. A model could be 100% accurate on Cercevelik, but continuously confuse Karacabey and Urgup_Sivrisi. Specialized metrics like multi-class confusion matrices, per-class precision, recall, and macro-averaged F1-scores are essential to detect such imbalances.

### Decision Trees in Multi-Class Environments
Certain algorithms (such as standard Support Vector Machines or Logistic Regression) are inherently binary classifiers requiring one-vs-rest (OvR) or one-vs-one (OvO) multi-model ensembles to handle multi-class tasks. 

In contrast, **Decision Trees** natively support multi-class classification. A leaf node in a decision tree maintains a probability distribution or sample count vector across all $C$ classes simultaneously (e.g., `[values: 12 Cercevelik, 0 Karacabey, 3 Urgup_Sivrisi]`), selecting the majority class label without requiring multi-model wrappers.

## Relevant Code (from main.py, lines 31-32)
```python
    X = df[FEATURES]
    y = df["variety"]
```

## Code Deep-Dive Breakdown
- `X = df[FEATURES]`: Extracts a two-dimensional DataFrame containing the 5 morphological features for all 180 rows.
- `y = df["variety"]`: Extracts a one-dimensional pandas Series containing string class labels (`"Cercevelik"`, `"Karacabey"`, `"Urgup_Sivrisi"`).
- `scikit-learn` automatically detects that `y` contains string values and treats the task as multi-class classification, tracking the distinct classes via `model.classes_`.

## Worked Example
Suppose an agricultural sorting sensor provides measurements for an unknown seed.
- If this were a regression task, the output would be: `Estimated Seed Weight: 0.284 grams`.
- If this were a binary sorting task, the output would be: `Defective: False`.
- In our **multi-class classification** system, the output is: `Predicted Cultivar: Urgup_Sivrisi`.

The decision tree outputs the discrete cultivar name directly, allowing the sorting system to switch sorting gates accordingly.

## Step-by-Step Student Instructions
1. Examine line 32 of `main.py`: `y = df["variety"]`.
2. Open Python in your terminal and check the unique values of `df["variety"]`:
   ```python
   import pandas as pd
   df = pd.read_csv("data/pumpkin_seeds.csv")
   print(df["variety"].unique())
   ```
3. Confirm there are exactly 3 unique strings: `['Urgup_Sivrisi', 'Karacabey', 'Cercevelik']`.
4. Conclude that since $C = 3 > 2$, this task is strictly multi-class classification.

## Expected Output or Observable Behaviour
Inspecting `df["variety"].value_counts()` outputs:
```
Urgup_Sivrisi    60
Karacabey        60
Cercevelik       60
Name: count, dtype: int64
```
Three discrete classes with equal frequencies of 60 samples each.

## Practical Exercises
- **Exercise 1.3a**: Why can you not compute Mean Absolute Error (MAE) on `y_test` and `predictions` in this project?
- **Exercise 1.3b**: Give an example of an agricultural problem that would be framed as regression instead of classification.

## Common Mistakes and Debugging
| Mistake | Root Cause | Remediation |
|---|---|---|
| Attempting to use regression metrics like R² on variety | Confusing regression with classification | Multi-class targets are non-continuous categories; evaluate with accuracy, precision, recall, and confusion matrices |
| Manually one-hot encoding y for a decision tree | Assuming tree models require numeric 0/1 columns | Scikit-learn's DecisionTreeClassifier handles string categorical targets directly |

## Best Practices and Security Considerations
- **Consistent Target Typing**: Always ensure categorical target columns have clean string labels without trailing whitespace (e.g., `"Karacabey "` vs `"Karacabey"`).
- **Label Encoding Tracking**: Store `model.classes_` alongside model weights so external systems know which index maps to which cultivar name.

## Real-World Context and Agricultural Impact
In seed distribution packaging plants, packaging lines must separate seeds into multiple distinct bin hoppers (e.g., Export Grade A, Domestic Snack Grade, Oil Processing Grade). Multi-class models enable a single conveyor camera station to route seeds to multiple hoppers simultaneously.

## Summary
The Pumpkin Seed Sorter solves a supervised multi-class classification problem with three mutually exclusive target varieties: Cercevelik, Karacabey, and Urgup_Sivrisi. Unlike regression (which predicts numbers) or binary classification (which has 2 classes), multi-class classification requires categorical evaluation metrics like accuracy and confusion matrices. Decision trees naturally support multi-class targets natively.

## Knowledge-check Questions
1. What defines a machine learning task as multi-class classification?
2. What are the three target classes in `df["variety"]`?
3. Why are regression metrics like MAE invalid for evaluating the pumpkin seed sorter?
4. How do decision trees natively handle multi-class predictions compared to linear SVMs?

## References
- scikit-learn Multi-class and Multi-label Algorithms: https://scikit-learn.org/stable/modules/multiclass.html
- Project Source Code: `main.py` lines 31-36.
