# Lesson 02: Morphological Features & Geometric Classification

**Lesson ID:** lesson-02  
**Module:** module-01  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define morphological features in the context of computer vision and biology.
- Identify the five primary geometric features extracted from seed silhouettes.
- Understand the physical meaning of area, perimeter, axes, and eccentricity.
- Explain why geometric dimensions vary systematically across pumpkin seed varieties.

## Prerequisites
- Lesson 01: Agricultural Sorting Automation & The Seed Industry.
- Basic high school geometry (ellipse dimensions, perimeter, surface area).

## Concept Explanation

### What Are Morphological Features?
Morphology is the branch of biology dealing with the study of the form and structure of organisms and their specific structural features. In automated computer vision, **morphological features** are quantitative numerical measurements extracted from an object's 2D digital image silhouette:

```
                  Major Axis (2a)
             ◄───────────────────────►
         ╭───────────────────────────────╮  ▲
         │               • Center        │  │ Minor Axis (2b)
         ╰───────────────────────────────╯  ▼
```

When an overhead camera captures a pumpkin seed resting flat on a conveyor belt, image segmentation algorithms threshold the image into a binary mask (white seed silhouette against a dark background). From this silhouette, five fundamental geometric features are computed:

1. **Area ($A$)**: The count of pixels inside the seed boundary, proportional to the physical 2D surface area (measured in $\text{mm}^2$).
2. **Perimeter ($P$)**: The total length of the continuous boundary line surrounding the seed silhouette (measured in $\text{mm}$).
3. **Major Axis Length ($2a$)**: The length of the longest line segment that can be drawn across the equivalent bounding ellipse passing through the seed's center.
4. **Minor Axis Length ($2b$)**: The length of the shortest line segment perpendicular to the major axis passing through the center.
5. **Eccentricity ($e$)**: A normalized ratio describing the elongation of the seed's bounding ellipse:
   $$e = \sqrt{1 - \left(\frac{b}{a}\right)^2}$$
   - When $a = b$, the ellipse is a circle and $e = 0$.
   - As the seed becomes more elongated and pointed, $b \ll a$, causing $e$ to approach $1.0$.

### Why Geometry Distinguishes Cultivars
Genetics dictates physical seed development:
- **Cercevelik** seeds are broad and massive, exhibiting large `area` (typically > 1300) and substantial `minor_axis` width (> 6.0 mm).
- **Karacabey** seeds are petite and compact, exhibiting smaller `area` (typically < 1000) and moderate eccentricity.
- **Urgup_Sivrisi** seeds are long and slender, with moderate area but distinctive elongation reflected in high `eccentricity` (> 0.84) and narrow `minor_axis` (< 6.0 mm).

## Relevant Code (from main.py, line 26)
```python
FEATURES = ["area", "perimeter", "major_axis", "minor_axis", "eccentricity"]
```

## Code Deep-Dive Breakdown
- `FEATURES`: A clean Python list of strings specifying the exact column names used by the machine learning model.
- Notice that no color or texture features are included in this baseline. Pure geometric silhouettes alone provide enough discriminatory power to separate these three varieties.
- By defining `FEATURES` once at the top of the file, the pipeline maintains strict consistency across feature extraction, rule generation (`export_text`), tree visualization (`plot_tree`), and live sample inference.

## Worked Example
Let us compare two actual seeds from `pumpkin_seeds.csv`:

| Cultivar | Area | Perimeter | Major Axis | Minor Axis | Eccentricity |
|---|---|---|---|---|---|
| **Cercevelik** | 1560 | 66.49 | 14.31 | 6.66 | 0.939 |
| **Karacabey** | 854 | 46.60 | 10.99 | 4.99 | 0.813 |

Comparing these values directly reveals clear geometric separation:
- The Cercevelik seed has nearly double the area ($1560$ vs $854$).
- The Cercevelik seed's minor axis is significantly wider ($6.66$ vs $4.99$).
- Even a simple rule like "Is minor axis > 6.0?" separates these two specimens cleanly!

## Step-by-Step Student Instructions
1. Inspect line 26 of `main.py` and verify all five feature names.
2. Confirm that each feature represents a geometric or morphological dimension.
3. Observe how units are structured: area represents 2D surface, perimeter and axes represent 1D lengths, and eccentricity is dimensionless.
4. Reflect on why silhouette features are robust against ambient lighting variations compared to color features.

## Expected Output or Observable Behaviour
When inspecting the dataset schema in pandas:
```
Index(['variety', 'area', 'perimeter', 'major_axis', 'minor_axis', 'eccentricity'], dtype='object')
```
All five features in `FEATURES` appear as numeric float/integer columns ready for machine learning processing.

## Practical Exercises
- **Exercise 1.2a**: Calculate the aspect ratio (Major Axis / Minor Axis) for a seed with major axis 12.0 mm and minor axis 6.0 mm.
- **Exercise 1.2b**: If an eccentricity value is 0.0, what geometric shape does the seed silhouette resemble?

## Common Mistakes and Debugging
| Mistake | Root Cause | Remediation |
|---|---|---|
| Confusing minor axis with perimeter | Misinterpreting feature definitions | Minor axis is the narrowest diameter; perimeter is the entire outer perimeter contour |
| Thinking eccentricity is measured in millimeters | Misunderstanding mathematical ratios | Eccentricity is a dimensionless index between 0.0 and 1.0 quantifying elongation |

## Best Practices and Security Considerations
- **Scale Invariance**: When collecting morphological data via cameras, always calibrate pixels-to-millimeters using a known calibration grid so camera distance does not distort measurements.
- **Dimensional Verification**: Ensure feature vectors contain clean numeric values with no negative lengths or infinite ratios.

## Real-World Context and Agricultural Impact
Morphological sorting is widely adopted in grain silos, coffee bean processing, and almond grading. By extracting morphological features rather than storing raw high-resolution images, sorters compress megabytes of video data into 5 floating-point numbers, accelerating processing speeds.

## Summary
Morphological features describe the geometric size and contour of biological objects. The Pumpkin Seed Sorter utilizes five key features: area, perimeter, major axis, minor axis, and eccentricity. Because pumpkin cultivars possess distinct physical growth profiles, these five geometric metrics allow decision trees to delineate clear boundaries between Cercevelik, Karacabey, and Urgup_Sivrisi.

## Knowledge-check Questions
1. What are the five geometric features defined in `FEATURES`?
2. How is eccentricity calculated mathematically, and what does a high value indicate?
3. Which feature distinguishes broad, massive Cercevelik seeds from smaller Karacabey seeds?
4. Why are morphological features computationally advantageous over raw image pixels?

## References
- Digital Image Processing: Gonzalez & Woods, Morphological Image Analysis.
- scikit-learn Feature Representation Guide: https://scikit-learn.org/stable/modules/feature_extraction.html
- Project Source Code: `main.py` line 26.
