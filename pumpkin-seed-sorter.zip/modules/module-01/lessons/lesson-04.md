# Lesson 04: Why Decision Trees for Morphological Inspection

**Lesson ID:** lesson-04  
**Module:** module-01  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why decision trees are ideal for agricultural morphological sorting.
- Contrast interpretable "white-box" models against complex "black-box" models.
- Describe how decision trees translate directly into programmable logic for industrial hardware.
- Explain the role of tree depth constraints in maintaining simplicity and speed.

## Prerequisites
- Lesson 03: Multi-Class Classification vs Binary & Regression.
- Understanding the operational need for fast, transparent decision rules.

## Concept Explanation

### The Need for Explainability in Food & Agriculture
In industrial agricultural sorting, machine learning models do not operate in a vacuum. They must satisfy regulatory standards, quality assurance audits, and operational constraints set by plant engineers:
- **Auditing & Certification**: When an agricultural export shipment is certified as 99% pure Urgup_Sivrisi, seed inspectors must verify the scientific criteria used to reject non-compliant seeds.
- **Operator Trust**: If a sorting machine starts ejecting 40% of incoming seeds, technicians need immediate diagnostic insight into which threshold triggered the rejection.
- **Hardware Integration**: High-speed sorting ejector valves run on microcontrollers or Programmable Logic Controllers (PLCs) written in C or ladder logic, which cannot execute heavyweight neural network inference engines.

### White-Box vs Black-Box Models

| Model Architecture | Explainability | Compute Cost | Hardware Portability |
|---|---|---|---|
| **Deep Neural Networks** | Black-box (millions of matrix weights) | High (requires GPU/TPU) | Complex runtime dependencies |
| **Random Forests / Ensembles**| Grey-box (average of 100+ trees) | Moderate | Requires running dozens of passes |
| **Single Decision Tree** | **White-box** (pure IF-THEN rules) | **Extremely Low** (microseconds) | **Directly translatable to C / PLC logic** |

A single decision tree represents a "white-box" model. Every decision path from the root node to a leaf is a transparent sequence of human-readable conditional statements:
```
IF minor_axis <= 6.04 mm THEN:
    IF area <= 1019.5 mm² THEN:
        Result = Karacabey
    ELSE:
        Result = Urgup_Sivrisi
ELSE:
    ...
```

### Hardware Deployment Simplicity
Because decision tree rules consist solely of numeric comparisons (`<=` and `>`), a trained scikit-learn decision tree can be converted into five lines of basic C code and compiled directly into an embedded microcontroller controlling an optical sorting camera. There are no matrix multiplications, transcendental activation functions, or floating-point tensor graphs required.

Furthermore, decision trees evaluate features non-linearly and are invariant to monotonic feature scaling. We do not even need to normalize or standardize `area` (which ranges in the thousands) versus `eccentricity` (which ranges from 0 to 1). The decision tree evaluates each feature independently.

## Relevant Code (from main.py, lines 6-7, 43-45)
```python
# From docstring:
# The script compares a shallow tree, a deeper tree, and an unlimited tree,
# then prints the rules in plain English.

    for depth in (2, 4, None):
        model = DecisionTreeClassifier(max_depth=depth, random_state=42)
        model.fit(X_train, y_train)
```

## Code Deep-Dive Breakdown
- `for depth in (2, 4, None)`: The script systematically tests different levels of tree complexity.
  - `depth=2`: A shallow tree with at most 4 leaf nodes.
  - `depth=4`: A moderate tree capable of capturing more nuanced sub-boundaries.
  - `depth=None`: An unconstrained tree that continues splitting until every training leaf is 100% pure.
- `random_state=42`: Guarantees deterministic splitting and reproducibility.

## Worked Example
Imagine you are an agricultural engineer programming a pneumatic air nozzle on a seed conveyor belt.
Using the learned decision tree:
```
Seed arrives: [area=950, minor_axis=5.2]
Check 1: Is minor_axis (5.2) <= 6.04? -> TRUE.
Check 2: Is area (950) <= 1019.50? -> TRUE.
Conclusion: Karacabey.
Action: Keep pneumatic valve closed; seed falls into Karacabey hopper.
```
Two arithmetic comparisons and less than 1 microsecond of compute time are all that is needed to make a verified sorting decision!

## Step-by-Step Student Instructions
1. Inspect lines 43-45 of `main.py`.
2. Notice that `DecisionTreeClassifier` is imported directly from `sklearn.tree`.
3. Reflect on why `max_depth` is the primary hyperparameter tested in this project.
4. Consider how a shallow tree protects against overfitting while providing minimal rules that human operators can easily understand.

## Expected Output or Observable Behaviour
When running `main.py`, the plain English rules are printed directly to the console:
```
Learned rules for the best tree:

|--- minor_axis <= 6.04
|   |--- area <= 1019.50
|   |   |--- class: Karacabey
|   |--- area >  1019.50
|   |   |--- class: Urgup_Sivrisi
|--- minor_axis >  6.04
|   |--- major_axis <= 12.58
|   |   |--- class: Urgup_Sivrisi
|   |--- major_axis >  12.58
|   |   |--- class: Cercevelik
```
Notice how intuitive these four rules are: they use only `minor_axis`, `area`, and `major_axis`!

## Practical Exercises
- **Exercise 1.4a**: Convert the 4 rules printed above into standard Python `if-elif-else` code.
- **Exercise 1.4b**: Why is a model with 4 rules easier to audit in a food packing plant than a neural network with 50,000 parameters?

## Common Mistakes and Debugging
| Mistake | Root Cause | Remediation |
|---|---|---|
| Assuming deeper trees are always better | Believing more complexity equals higher accuracy | As shown in main.py, max_depth=2 achieves 86.7% accuracy while deeper trees overfit to 84.4% |
| Normalizing features unnecessarily | Treating decision trees like neural networks or KNN | Decision trees only look at one feature at a time; feature scaling (MinMaxScaler, StandardScaler) does not affect tree splits |

## Best Practices and Security Considerations
- **Rule Auditing**: Always print and inspect decision tree rules using `export_text` before deploying to physical hardware to verify that the thresholds match agronomic realities.
- **Complexity Budgets**: Set strict `max_depth` limits on edge devices to prevent runaway branch traversal times and excessive memory usage.

## Real-World Context and Agricultural Impact
In commercial seed processing plants handling multi-ton grain shipments, decision tree rules are frequently hardcoded into FPGA (Field Programmable Gate Array) chips connected directly to line-scan camera sensors. This allows seeds traveling at 3 meters per second to be classified in real-time without needing an external operating system or cloud connectivity.

## Summary
Decision trees are uniquely suited for agricultural morphological inspection because they are transparent "white-box" models. Their nested IF-THEN rules are interpretable by human seed analysts, robust against unscaled features, and easily translated into embedded C code for high-speed pneumatic sorting machinery. Restricting tree depth ensures low latency and guards against overfitting.

## Knowledge-check Questions
1. Why is a decision tree considered a "white-box" model?
2. What are the advantages of decision trees over deep neural networks in high-speed hardware sorting?
3. Does a decision tree require feature normalization (like standardizing area and eccentricity)? Why or why not?
4. What three depth configurations does `main.py` compare?

## References
- scikit-learn Decision Trees Documentation: https://scikit-learn.org/stable/modules/tree.html
- Explainable AI in Agriculture: Journal of Agricultural Informatics.
- Project Source Code: `main.py` lines 41-56.
