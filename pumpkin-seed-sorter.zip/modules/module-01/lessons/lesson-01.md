# Lesson 01: Agricultural Sorting Automation & The Seed Industry

**Lesson ID:** lesson-01  
**Module:** module-01  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Articulate the operational problem solved by automated agricultural sorting.
- Explain why seed cultivar purity is vital for commercial agriculture and food processing.
- Identify the three pumpkin seed cultivars categorized in this project: Cercevelik, Karacabey, and Urgup_Sivrisi.
- Describe the high-level workflow of optical seed sorting machinery.

## Prerequisites
- Basic familiarity with agricultural products and food processing pipelines.
- An understanding that physical products have measurable geometric attributes.

## Concept Explanation

### The Problem of Seed Cultivar Purity
In commercial agriculture, seed quality and cultivar purity dictate crop yield, harvesting uniformity, and market valuation. Pumpkin seeds (*Cucurbita pepo*) are harvested globally both as certified planting seeds for farmers and as high-value confectionery snack products. However, different pumpkin cultivars possess distinct culinary, oil, and planting characteristics:
- **Cercevelik**: Typically larger, robust seeds with thick hulls, prized for traditional roasting and snacking.
- **Karacabey**: Compact, oval seeds cultivated extensively in specialized regional microclimates with distinct seed coat textures.
- **Urgup_Sivrisi**: A premium Anatolian confectionery pumpkin cultivar characterized by elongated, pointed silhouettes ("sivri" meaning pointed/sharp).

When harvesting and processing crops, seeds from adjacent fields or processing batches frequently become mixed. If a farmer purchases certified Urgup_Sivrisi planting seed that contains Karacabey contamination, the resulting crop will exhibit uneven maturation, inconsistent seed sizes that jam planting machinery, and variable oil yields during industrial extraction.

### Manual Inspection vs Industrial Automation
Historically, seed purity verification required manual visual inspection. Certified seed analysts manually inspected sample trays under magnifying lamps, counting individual seeds and identifying contaminants. This human workflow suffered from several severe limitations:
1. **Low Throughput**: A trained technician can inspect only 2 to 5 kilograms per hour.
2. **Subjective Fatigue**: Error rates increase sharply after 30 minutes of continuous optical inspection.
3. **High Labor Costs**: Hand-sorting massive commercial harvests is economically unviable.

Modern industrial seed processing facilities solve this bottleneck using **automated optical sorting systems**. In these systems, thousands of seeds cascade down vibrating chutes past high-speed digital cameras. Machine vision software captures the physical silhouette of each seed, extracts geometric features, and sends them to a trained classification algorithm. If the classifier detects an off-type seed, ultra-fast pneumatic air nozzles fire timed bursts of compressed air (lasting 2 to 5 milliseconds) to deflect the contaminant into a discard bin while pure seeds drop into the primary hopper.

## Relevant Code (from main.py, lines 1-8)
```python
"""Project 15: The Pumpkin Seed Sorter (decision tree).

Run:
    python main.py

A multi-class decision tree.  The script compares a shallow tree, a deeper
tree, and an unlimited tree, then prints the rules in plain English.
"""
```

## Code Deep-Dive Breakdown
- **Project Identity**: The header docstring defines the project as an automated multi-class decision tree classifier designed to distinguish between multiple seed categories.
- **Model Hierarchy**: The project explicitly tests three tree architectures: a shallow tree (`max_depth=2`), a deeper tree (`max_depth=4`), and an unconstrained tree (`max_depth=None`).
- **Interpretability Goal**: The docstring highlights the generation of "rules in plain English". In industrial agricultural auditing, operators must understand exactly why a batch of seeds was accepted or rejected.

## Worked Example
Suppose an optical conveyor belt processes 300 pumpkin seeds per minute. An optical camera measures each seed. If a seed has:
- Area = 937
- Minor Axis = 4.86 mm
- Major Axis = 10.46 mm

A human inspector might take 3 seconds to measure and categorize it. The automated decision tree classifier evaluates these geometric boundaries in less than 0.1 milliseconds, instantly identifying the seed as **Karacabey** and allowing the conveyor stream to proceed uninterrupted.

## Step-by-Step Student Instructions
1. Open terminal and verify access to the project directory: `projects/AI-ML/Pumpkin Seed Sorter/pumpkin-seed-sorter/`.
2. Open `main.py` and inspect lines 1 through 8 to confirm project objectives.
3. Identify the three target cultivars mentioned in the dataset: `Cercevelik`, `Karacabey`, and `Urgup_Sivrisi`.
4. Note how high-speed processing requires millisecond-level inference latencies that decision trees naturally provide.

## Expected Output or Observable Behaviour
When running `main.py`, the initial banner outputs:
```
============================================================
THE PUMPKIN SEED SORTER
============================================================
Comparing tree depths:
```
This confirms that the automated sorting simulation is initialized and ready to benchmark tree performance across cultivars.

## Practical Exercises
- **Exercise 1.1**: Research why certified seed certification agencies require cultivar purity above 98% for commercial distribution.
- **Exercise 1.2**: Write down the operational trade-offs between manual seed inspection and computer vision sorting systems.

## Common Mistakes and Debugging
| Mistake | Root Cause | Remediation |
|---|---|---|
| Assuming agricultural sorting is purely binary | Treating sorting as just good vs bad | Agriculture requires multi-class sorting to separate distinct commercial cultivars into separate market grades |
| Overlooking physical conveyor speeds | Assuming algorithms have unlimited latency | Industrial sorters inspect 50+ seeds per second; inference algorithms must be computationally lightweight |

## Best Practices and Security Considerations
- **Deterministic Pipeline**: Always fix random seeds (`random_state=42`) when training sorting models to ensure reproducible sorting decisions across agricultural audit batches.
- **Fail-Safe Operation**: In production sorters, ambiguous or edge-case seeds should be routed to a secondary re-inspection stream rather than dumped into premium export bins.

## Real-World Context and Agricultural Impact
Optical seed sorters powered by machine learning save millions of dollars annually in post-harvest losses. For instance, in Turkey and the Mediterranean basin, pumpkin seeds represent a major export commodity where seed uniform size and shape directly dictate export wholesale prices.

## Summary
Cultivar purity in pumpkin seeds is vital for uniform farming and food quality. Automated optical sorting machines replace slow, error-prone manual labor by combining high-speed cameras with machine learning models. The Pumpkin Seed Sorter project implements a Decision Tree classifier to sort three commercial cultivars: Cercevelik, Karacabey, and Urgup_Sivrisi.

## Knowledge-check Questions
1. Why is seed cultivar purity critical for commercial agricultural producers?
2. What are the three pumpkin seed cultivars classified by the project?
3. How do industrial optical sorters mechanically separate contaminated seeds?
4. Why is millisecond inference latency necessary in automated seed sorting?

## References
- scikit-learn Decision Trees User Guide: https://scikit-learn.org/stable/modules/tree.html
- Seed Morphological Analysis Research: International Seed Testing Association (ISTA) Standards.
- Project Source Code: `main.py` lines 1-8.
