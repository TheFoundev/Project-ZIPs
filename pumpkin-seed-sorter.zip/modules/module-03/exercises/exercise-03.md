# Module 3 Exercises: Decision Tree Splits, Gini, and Depth

## Exercise 3.1: Geometric Partitioning Visualization (15 min)
**Objective:** Sketch and interpret 2D decision tree boundaries.  
**Problem Statement:** Using the learned rules from `main.py`, construct a 2D bounding diagram for the feature subspace defined by `minor_axis` (horizontal axis, range 4.0 to 8.0) and `area` (vertical axis, range 800 to 1800).

**Requirements:**
1. Draw the vertical boundary line at `minor_axis = 6.04`.
2. For the region `minor_axis <= 6.04`, draw the horizontal boundary line at `area = 1019.50`.
3. Label the resulting three regions:
   - `minor_axis <= 6.04` and `area <= 1019.50`: **Karacabey**
   - `minor_axis <= 6.04` and `area > 1019.50`: **Urgup_Sivrisi**
   - `minor_axis > 6.04`: **Cercevelik / Urgup_Sivrisi** (further split by major_axis)
4. Explain why the boundaries meet at right angles (orthogonal splits).

**Constraints:** Base boundaries on the exact values from `main.py`.

**Expected Behaviour:** A clear diagram and written description explaining orthogonal space partitioning.

**Acceptance Criteria:**
- [ ] Correctly places the vertical threshold at 6.04.
- [ ] Correctly places the horizontal threshold at 1019.50.
- [ ] Correctly identifies the cultivar regions.
- [ ] Articulates why single-feature decision trees create rectangular partitions.

**Hints:**
- Review Lesson 01 for the relationship between tree nodes and geometric boxes.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 3.2: Manual Gini Impurity Calculation (15 min)
**Objective:** Calculate Gini impurity and weighted child reduction by hand.  
**Problem Statement:** A candidate split in a seed dataset partitions 40 seeds:
- **Parent Node**: 15 Cercevelik, 15 Karacabey, 10 Urgup_Sivrisi ($N=40$).
- **Left Child ($N_L = 20$)**: 0 Cercevelik, 15 Karacabey, 5 Urgup_Sivrisi.
- **Right Child ($N_R = 20$)**: 15 Cercevelik, 0 Karacabey, 5 Urgup_Sivrisi.

Compute the Gini impurity for the parent node, both child nodes, and the resulting impurity reduction.

**Requirements:**
1. Compute $G_{\text{parent}} = 1 - \sum p_i^2$.
2. Compute $G_L$ and $G_R$.
3. Compute the weighted split impurity $G_{\text{split}} = 0.5 G_L + 0.5 G_R$.
4. Compute the information gain $\Delta G = G_{\text{parent}} - G_{\text{split}}$.

**Constraints:** Show all intermediate fractions and decimal steps rounded to 3 decimal places.

**Expected Behaviour:** Step-by-step arithmetic proving that the split reduces impurity.

**Acceptance Criteria:**
- [ ] Correctly computes parent Gini: $1 - [(15/40)^2 + (15/40)^2 + (10/40)^2] = 1 - [0.141 + 0.141 + 0.0625] = 0.656$.
- [ ] Correctly computes $G_L = 1 - [(0)^2 + (15/20)^2 + (5/20)^2] = 1 - [0.5625 + 0.0625] = 0.375$.
- [ ] Correctly computes $G_R = 1 - [(15/20)^2 + (0)^2 + (5/20)^2] = 0.375$.
- [ ] Computes $G_{\text{split}} = 0.375$ and $\Delta G = 0.656 - 0.375 = 0.281$.

**Hints:**
- Since both children have equal sample counts ($N_L = N_R = 20$), the weighted average is simply $(G_L + G_R) / 2$.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 3.3: Extended Depth Comparison Experiment (15 min)
**Objective:** Expand the depth search loop in `main.py` and log results.  
**Problem Statement:** Write a script that trains `DecisionTreeClassifier(max_depth=d, random_state=42)` across depths $d \in [1, 2, 3, 4, 5, 6, 7, 8, \text{None}]$. Compute both training accuracy and testing accuracy for each depth.

**Requirements:**
1. Replicate the train-test split from `main.py`.
2. Loop through all 9 depth values.
3. Record training accuracy (`accuracy_score(y_train, model.predict(X_train))`) and test accuracy (`accuracy_score(y_test, model.predict(X_test))`).
4. Print a clean markdown comparison table.
5. Identify the exact depth where training accuracy reaches 100%.

**Constraints:** Must use `random_state=42` and `stratify=y`.

**Expected Behaviour:** A formatted table illustrating training accuracy climbing to 100% while test accuracy plateaus and drops.

**Acceptance Criteria:**
- [ ] Accurately computes train and test accuracies across all 9 depths.
- [ ] Demonstrates that training accuracy reaches 100% at deeper levels.
- [ ] Confirms that test accuracy peaks at depth 2 (86.7%).
- [ ] Discusses the bias-variance trade-off observed in the table.

**Hints:**
- Use `f"{acc:.1%}"` for clean percentage formatting.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 3.4: Hyperparameter Regularization Analysis (15 min)
**Objective:** Explore alternative pruning hyperparameters (`min_samples_leaf`, `min_samples_split`).  
**Problem Statement:** When `max_depth=None`, the tree overfits to 84.4% test accuracy. Test whether constraining `min_samples_leaf` can rescue the unconstrained tree from overfitting.

**Requirements:**
1. Train an unconstrained tree: `DecisionTreeClassifier(max_depth=None, random_state=42)`.
2. Train a regularized tree with `min_samples_leaf=5`: `DecisionTreeClassifier(max_depth=None, min_samples_leaf=5, random_state=42)`.
3. Compare the test accuracies of both models.
4. Explain how setting a minimum leaf sample threshold prevents the creation of single-sample outlier leaves.

**Constraints:** Evaluate on `X_test` and `y_test`.

**Expected Behaviour:** A written comparative analysis with code execution outputs.

**Acceptance Criteria:**
- [ ] Successfully trains both models.
- [ ] Compares test accuracies and leaf counts.
- [ ] Articulates why `min_samples_leaf` serves as an effective regularizer.

**Hints:**
- `min_samples_leaf=5` requires every terminal leaf to contain at least 5 training samples.

**Difficulty:** Advanced  
**Estimated Completion Time:** 15 minutes  
