# Lesson 02: Splitting Criteria and Gini Impurity Calculations

**Lesson ID:** lesson-02  
**Module:** module-03  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define Gini impurity and state its mathematical formula.
- Calculate Gini impurity for arbitrary node class distributions by hand.
- Explain how CART evaluates candidate thresholds using weighted Gini reduction (information gain).
- Understand what a Gini impurity of 0.0 represents (a pure leaf).

## Prerequisites
- Lesson 01: Decision Tree Architecture & Recursive Geometric Partitioning.
- Basic arithmetic and fractions.

## Concept Explanation

### Measuring Node Purity
To choose the best split, a decision tree needs a mathematical metric to evaluate how "pure" or "mixed" a node's samples are. In a node with $C$ classes, let $p_i$ be the fraction of samples belonging to class $i$.

Scikit-learn's default splitting criterion is **Gini Impurity** ($G$):
$$G = 1 - \sum_{i=1}^{C} p_i^2$$

### Interpreting Gini Values
- **Minimum Impurity ($G = 0.0$)**: The node is **100% pure**. All samples in the node belong to a single class (e.g., 20 Cercevelik, 0 Karacabey, 0 Urgup_Sivrisi). No further splitting is needed.
- **Maximum Impurity ($G \approx 0.667$ for 3 balanced classes)**: The node is completely mixed. Samples are equally divided among all 3 classes ($p_1 = \frac{1}{3}, p_2 = \frac{1}{3}, p_3 = \frac{1}{3}$):
  $$G = 1 - \left[ \left(\frac{1}{3}\right)^2 + \left(\frac{1}{3}\right)^2 + \left(\frac{1}{3}\right)^2 \right] = 1 - 3 \left(\frac{1}{9}\right) = 1 - \frac{1}{3} = \frac{2}{3} \approx 0.667$$

At the root node of our training set (135 samples: 45 Cercevelik, 45 Karacabey, 45 Urgup_Sivrisi), the Gini impurity is exactly $0.667$!

### Weighted Impurity Reduction (The Split Criterion)
When evaluating a candidate split that divides $N$ parent samples into a left child ($N_L$ samples, impurity $G_L$) and right child ($N_R$ samples, impurity $G_R$), the algorithm calculates the **weighted child impurity**:
$$G_{\text{split}} = \frac{N_L}{N} G_L + \frac{N_R}{N} G_R$$

The **Impurity Reduction** (Information Gain) is:
$$\Delta G = G_{\text{parent}} - G_{\text{split}}$$

The algorithm computes $\Delta G$ for every candidate threshold across all 5 features and selects the threshold that **maximizes** $\Delta G$ (or equivalently, minimizes $G_{\text{split}}$).

## Relevant Code (from main.py, line 44)
```python
model = DecisionTreeClassifier(max_depth=depth, random_state=42)
```

## Code Deep-Dive Breakdown
- By default, `criterion="gini"` in `DecisionTreeClassifier`. (The alternative is `criterion="entropy"`, which uses logarithmic information theory, but Gini is computationally faster and yields virtually identical trees).
- Scikit-learn evaluates all 135 training samples at each step, sorting features and computing weighted Gini reductions in compiled Cython for maximum execution speed.

## Worked Example: Calculating Gini by Hand
Suppose a candidate split divides 30 pumpkin seeds into two candidate children:

**Parent Node**: 10 Cercevelik, 10 Karacabey, 10 Urgup_Sivrisi ($N=30$).
$$G_{\text{parent}} = 1 - \left[ \left(\frac{10}{30}\right)^2 + \left(\frac{10}{30}\right)^2 + \left(\frac{10}{30}\right)^2 \right] = 1 - 3\left(\frac{1}{9}\right) = \frac{2}{3} \approx 0.667$$

**Left Child ($N_L = 12$)**: 0 Cercevelik, 10 Karacabey, 2 Urgup_Sivrisi.
$$G_L = 1 - \left[ \left(\frac{0}{12}\right)^2 + \left(\frac{10}{12}\right)^2 + \left(\frac{2}{12}\right)^2 \right] = 1 - \left( 0 + \frac{100}{144} + \frac{4}{144} \right) = 1 - \frac{104}{144} = \frac{40}{144} \approx 0.278$$

**Right Child ($N_R = 18$)**: 10 Cercevelik, 0 Karacabey, 8 Urgup_Sivrisi.
$$G_R = 1 - \left[ \left(\frac{10}{18}\right)^2 + \left(\frac{0}{18}\right)^2 + \left(\frac{8}{18}\right)^2 \right] = 1 - \left( \frac{100}{324} + 0 + \frac{64}{324} \right) = 1 - \frac{164}{324} = \frac{160}{324} \approx 0.494$$

**Weighted Split Impurity**:
$$G_{\text{split}} = \left(\frac{12}{30}\right)(0.278) + \left(\frac{18}{30}\right)(0.494) = 0.4(0.278) + 0.6(0.494) = 0.111 + 0.296 = 0.407$$

**Impurity Reduction**:
$$\Delta G = 0.667 - 0.407 = 0.260$$

Because $\Delta G > 0$, this split significantly purifies the data! The algorithm compares this $0.260$ reduction against all other candidate feature thresholds to find the highest score.

## Step-by-Step Student Instructions
1. Memorize the Gini formula: $G = 1 - \sum p_i^2$.
2. Calculate the Gini impurity for a node containing 25 Cercevelik and 0 Karacabey/Urgup_Sivrisi: verify that $G = 1 - (1.0)^2 = 0.0$.
3. Understand why a pure leaf has Gini = 0.0.
4. Appreciate that scikit-learn computes these calculations thousands of times per second to find the optimal split.

## Expected Output or Observable Behaviour
When generating tree visualizations via `plot_tree`, each box explicitly displays its `gini` score:
- Root node: `gini = 0.667`
- Deeper nodes: `gini = 0.42`, `gini = 0.18`, etc.
- Pure leaf nodes: `gini = 0.0`

## Practical Exercises
- **Exercise 3.2a**: Calculate the Gini impurity for a node with 20 Cercevelik, 20 Karacabey, and 0 Urgup_Sivrisi.
- **Exercise 3.2b**: Why is Gini impurity computationally faster to calculate than Shannon Entropy (which uses $\sum -p_i \log_2 p_i$)?

## Common Mistakes and Debugging
| Mistake | Root Cause | Remediation |
|---|---|---|
| Forgetting to square the probabilities | Writing $1 - \sum p_i$ | The probabilities must be squared: $1 - \sum p_i^2$; since $\sum p_i = 1$, $1 - \sum p_i$ would always equal 0! |
| Forgetting sample weighting | Averaging child Gini values directly: $(G_L + G_R)/2$ | Child impurities must be weighted by sample proportions: $\frac{N_L}{N} G_L + \frac{N_R}{N} G_R$ |

## Best Practices and Security Considerations
- **Criterion Selection**: Stick with `criterion="gini"` unless domain specifications explicitly mandate `entropy`. Gini avoids expensive logarithmic calls and yields virtually identical trees.
- **Purity Stopping**: Do not require Gini to reach 0.0 on training data, as forcing 100% purity leads directly to overfitting on noisy outliers.

## Real-World Context and Agricultural Impact
In agricultural sorting machines, Gini-based split selection ensures that the algorithm focuses on separating cultivars with the highest confidence first (such as isolating broad Cercevelik seeds), leaving subtle boundary distinctions for deeper levels.

## Summary
Gini Impurity measures the statistical heterogeneity of class labels within a node. It ranges from 0.0 (pure node) to approximately 0.667 (equally mixed 3-class distribution). Scikit-learn's CART algorithm evaluates candidate thresholds across all 5 morphological features, selecting the split that maximizes the weighted impurity reduction.

## Knowledge-check Questions
1. What is the Gini impurity of a node where all samples belong to Urgup_Sivrisi?
2. What is the Gini impurity of the root node in our 3-class balanced training dataset?
3. How is the weighted child impurity calculated from left and right child nodes?
4. Why does scikit-learn use Gini impurity as its default criterion rather than entropy?

## References
- Breiman et al., Classification and Regression Trees (1984).
- scikit-learn Decision Tree Criteria: https://scikit-learn.org/stable/modules/tree.html#mathematical-formulation
- Project Source Code: `main.py` lines 43-46.
