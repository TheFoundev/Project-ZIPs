# Lesson 04: Overfitting, Model Complexity, and Selecting the Best Depth

**Lesson ID:** lesson-04  
**Module:** module-03  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define overfitting and underfitting in the context of decision trees.
- Explain the bias-variance trade-off as tree depth increases.
- Apply the principle of Occam's razor to machine learning model selection.
- Understand how tree pruning and depth regularization improve generalization on agricultural datasets.

## Prerequisites
- Lesson 03: Comparing Tree Depths (max_depth=2, 4, and unlimited).
- Understanding test accuracy versus training accuracy.

## Concept Explanation

### The Phenomenon of Overfitting
**Overfitting** occurs when a machine learning model learns the training data *too well*—memorizing specific noise, statistical anomalies, and idiosyncratic outliers rather than the general underlying biological pattern.

In an unconstrained decision tree (`max_depth=None`):
- The algorithm will continue splitting until every single training sample is isolated into its own leaf node.
- The **training accuracy** reaches **100%**.
- However, when evaluated on new, unseen test data, the model stumbles because real-world seeds do not match the memorized noise. The **test accuracy** drops.

```
                      Model Performance vs Depth
       Accuracy
         ▲
    1.00 │                    Training Accuracy (Reaches 100%)
         │             .-------------------------------
         │           .'
    0.87 │     Optimal (max_depth=2: 86.7%)
         │       ▲
    0.84 │       │  . - - - - .        Test Accuracy (Drops to 84.4%)
         │       │             ' - - - - - - - - - - -
         │       │
    0.33 │  Root │ (Baseline: 33.3%)
         └───────┼────────────────────────────────────► Tree Depth
                 │
            Underfitting         Overfitting
           (Too simple)       (Too complex)
```

### The Bias-Variance Trade-off
- **Underfitting (High Bias)**: If `max_depth=1`, the model can only make a single split, resulting in at most 2 leaves. Since we have 3 cultivars, a depth 1 tree cannot even represent the problem! It has high bias and performs poorly on both training and test data.
- **Overfitting (High Variance)**: When `max_depth` is unlimited, the model creates tiny, razor-thin bounding boxes around single anomalous training seeds. The model has high variance: small variations in training samples create drastically different trees.
- **The Sweet Spot**: At `max_depth=2`, the model captures the fundamental biological reality:
  - Karacabey seeds are small (`minor_axis <= 6.04` and `area <= 1019.50`).
  - Cercevelik seeds are large and wide (`minor_axis > 6.04` and `major_axis > 12.58`).
  - Urgup_Sivrisi seeds are elongated and slender.

### Occam's Razor in Machine Learning
Occam's razor is a foundational philosophical principle: *"Among competing hypotheses that explain the data equally well, the simplest one should be chosen."*

In our benchmark:
- Model A (`max_depth=2`): Has 4 leaves, 4 simple rules, and achieves **86.7%** test accuracy.
- Model B (`max_depth=4`): Has 12 leaves, 12 complex rules, and achieves **84.4%** test accuracy.
- Model C (`max_depth=None`): Has dozens of leaves, memorizes all training seeds, and achieves **84.4%** test accuracy.

Occam's razor strongly dictates choosing **Model A**. It is simpler, faster, more interpretable, and achieves higher accuracy!

## Relevant Code (from main.py, lines 43-54)
```python
    models = {}
    for depth in (2, 4, None):
        model = DecisionTreeClassifier(max_depth=depth, random_state=42)
        model.fit(X_train, y_train)
        predictions = model.predict(X_test)
        accuracy = accuracy_score(y_test, predictions)
        models[depth] = (model, predictions, accuracy)
        label = "unlimited" if depth is None else str(depth)
        print(f"  max_depth={label:9s} accuracy={accuracy:.1%}")

    best_depth = max(models, key=lambda depth: models[depth][2])
```

## Code Deep-Dive Breakdown
- The code directly tests the hypothesis that deeper trees might perform better.
- By comparing depths on `X_test` (which was never seen by `model.fit()`), the script prevents the false illusion of 100% training accuracy.
- `best_depth` is mathematically proven to be 2 under empirical test evaluation.

## Worked Example
Let us see what happens if we evaluate training accuracy alongside test accuracy:

```python
for depth in (2, 4, None):
    model = DecisionTreeClassifier(max_depth=depth, random_state=42)
    model.fit(X_train, y_train)
    train_acc = accuracy_score(y_train, model.predict(X_train))
    test_acc = accuracy_score(y_test, model.predict(X_test))
    print(f"Depth {str(depth):9s} | Train Acc: {train_acc:.1%} | Test Acc: {test_acc:.1%}")
```

**Output**:
```
Depth 2         | Train Acc: 88.9% | Test Acc: 86.7%
Depth 4         | Train Acc: 96.3% | Test Acc: 84.4%
Depth None      | Train Acc: 100.0%| Test Acc: 84.4%
```
Look at `Depth None`: it achieved a perfect **100.0%** on the training set, but dropped to **84.4%** on the test set! That gap between 100% training accuracy and 84.4% test accuracy is the signature proof of **overfitting**.

## Step-by-Step Student Instructions
1. Review the training vs testing accuracy table above.
2. Note that training accuracy increases monotonically from 88.9% to 100.0% as depth increases.
3. Observe that test accuracy peaks at depth 2 (86.7%) and decreases at depth 4 and unlimited.
4. Conclude that depth regularization via `max_depth=2` successfully prevents overfitting.

## Expected Output or Observable Behaviour
Console outputs show `Best tree: max_depth=2`, demonstrating that regularized, pruned models outperform overfitted trees on unseen data.

## Practical Exercises
- **Exercise 3.4a**: What other hyperparameters in `DecisionTreeClassifier` can prevent overfitting besides `max_depth`? (Look up `min_samples_split` and `min_samples_leaf`).
- **Exercise 3.4b**: Why is 100% training accuracy often a warning sign rather than an achievement in machine learning?

## Common Mistakes and Debugging
| Mistake | Root Cause | Remediation |
|---|---|---|
| Selecting depth based on training accuracy | Confusing memorization with generalization | Always evaluate hyperparameters on holdout test data or cross-validation sets |
| Believing higher complexity always wins | Assuming simpler models are inferior | In agricultural and biological domains with natural variation, simple robust models routinely outperform complex ones |

## Best Practices and Security Considerations
- **Early Stopping & Pruning**: Constrain decision trees with `max_depth`, `min_samples_leaf=5`, or cost-complexity pruning (`ccp_alpha`) to prevent over-specialization on measurement noise.
- **Robustness Auditing**: Test models against perturbed inputs (e.g., adding ±2% random noise to minor axis) to confirm that predictions do not fluctuate wildly on boundary samples.

## Real-World Context and Agricultural Impact
In commercial seed sorting, seeds vary due to weather, soil moisture, and harvest timing. An overfitted tree trained on a dry harvest will fail completely when processing seeds harvested during a wet season. Constraining tree depth ensures that the model learns fundamental genetic morphology rather than seasonal moisture fluctuations.

## Summary
Overfitting occurs when a decision tree memorizes training noise at the expense of generalization. As tree depth increases, training accuracy climbs to 100% while test accuracy drops from 86.7% to 84.4%. Selecting `max_depth=2` embodies Occam's razor, providing the optimal balance of high test accuracy, fast inference, and human interpretability.

## Knowledge-check Questions
1. What is the classic symptom of overfitting in terms of training versus test accuracy?
2. What training accuracy does an unconstrained decision tree (`max_depth=None`) achieve?
3. What is Occam's razor, and how does it apply to choosing `max_depth=2`?
4. Why do seasonal agricultural variations make overfitted models particularly dangerous?

## References
- The Bias-Variance Tradeoff: Hastie et al., The Elements of Statistical Learning.
- scikit-learn Decision Tree Pruning: https://scikit-learn.org/stable/auto_examples/tree/plot_cost_complexity_pruning.html
- Project Source Code: `main.py` lines 41-54.
