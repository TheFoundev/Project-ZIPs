# Lesson 01: Decision Tree Architecture & Recursive Geometric Partitioning

**Lesson ID:** lesson-01  
**Module:** module-03  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Describe the topological structure of a decision tree (root, internal decision nodes, branches, leaves).
- Understand how single-feature threshold tests partition multi-dimensional feature space.
- Visualize decision boundaries as axis-aligned orthogonal hyperplanes.
- Explain the recursive partitioning algorithm used during model training (`model.fit()`).

## Prerequisites
- Module 02: Data & Morphological Features.
- Familiarity with coordinate systems and geometric planes.

## Concept Explanation

### Anatomy of a Decision Tree
A decision tree is an inverted flowchart-like directed acyclic graph that classifies instances by sorting them down the tree from the root to a leaf node:
- **Root Node**: The very first node at the top of the tree containing all 135 training instances. It evaluates the single most informative feature threshold across the entire dataset.
- **Internal (Decision) Nodes**: Intermediate nodes that receive subsets of instances from parent nodes, evaluate a specific feature comparison (e.g., `area <= 1019.50`), and split data into two child branches.
- **Branches**: Directed edges corresponding to the boolean outcomes of the node's threshold test (`True` to the left, `False` to the right).
- **Leaf (Terminal) Nodes**: Nodes at the bottom of the tree that perform no further splits. Each leaf contains a final class prediction (e.g., `class: Karacabey`), determined by the majority class among the training samples reaching that leaf.

```
                    [ Root Node ]
               Is minor_axis <= 6.04?
                    /                        Yes  /            \  No
                  /                      [ Decision Node ]    [ Decision Node ]
        Is area <= 1019.5?   Is major_axis <= 12.58?
           /        \            /               Yes  /          \ No   Yes /            \ No
         /            \        /                  ( Leaf )      ( Leaf )  ( Leaf )       ( Leaf )
    Karacabey     Urgup     Urgup          Cercevelik
```

### Orthogonal Geometric Partitioning
Unlike linear models (which draw diagonal hyperplanes $w_1 x_1 + w_2 x_2 + b = 0$) or neural networks (which produce curved, high-dimensional manifolds), standard decision trees perform **axis-aligned orthogonal splits**. 

When the tree evaluates `minor_axis <= 6.04`, it slices the 5-dimensional feature space in half with a flat plane perpendicular to the `minor_axis` axis. At the next level, checking `area <= 1019.50` slices that half into a rectangular bounding region. In geometric terms, a decision tree subdivides multi-dimensional feature space into an arrangement of non-overlapping hyper-rectangles (boxes), assigning a single predicted cultivar to each box.

### The Recursive Greedy Induction Algorithm (CART)
Scikit-learn implements an optimized version of the Classification and Regression Trees (CART) algorithm:
1. **Candidate Search**: For each of the 5 features, sort all unique values observed in the training set.
2. **Threshold Evaluation**: Consider every mid-point between adjacent values as a potential split threshold.
3. **Purity Scoring**: Calculate how much each split reduces label impurity (using Gini impurity).
4. **Best Split Selection**: Choose the feature and threshold that produces the largest impurity reduction.
5. **Recursion**: Divide the dataset into left and right subsets and repeat the process on each subset until a stopping criterion is met (such as `max_depth` or node purity).

## Relevant Code (from main.py, lines 43-46)
```python
    models = {}
    for depth in (2, 4, None):
        model = DecisionTreeClassifier(max_depth=depth, random_state=42)
        model.fit(X_train, y_train)
```

## Code Deep-Dive Breakdown
- `DecisionTreeClassifier`: The core class from `sklearn.tree` implementing CART induction.
- `model.fit(X_train, y_train)`: Executes the recursive greedy partitioning algorithm on the 135 training samples.
- `random_state=42`: Controls the random selection of features in case multiple features yield identical Gini reductions, guaranteeing identical trees on every execution.

## Worked Example
Suppose a 2D space of seeds has two features: `minor_axis` and `area`.
- Point A: `(minor_axis=5.0, area=900)` -> Falls into `minor_axis <= 6.04` and `area <= 1019.50` -> Box 1: **Karacabey**.
- Point B: `(minor_axis=5.5, area=1200)` -> Falls into `minor_axis <= 6.04` and `area > 1019.50` -> Box 2: **Urgup_Sivrisi**.
- Point C: `(minor_axis=6.5, area=1500, major_axis=14.0)` -> Falls into `minor_axis > 6.04` and `major_axis > 12.58` -> Box 3: **Cercevelik**.

Notice how each seed cleanly routes into its designated geometric partition.

## Step-by-Step Student Instructions
1. Inspect lines 43-46 of `main.py`.
2. Trace the path of an arbitrary seed through the flowchart diagram above.
3. Understand that every split reduces the multi-class diversity of the child nodes.
4. Observe how the tree structure maps directly to simple nested if-else statements.

## Expected Output or Observable Behaviour
During `model.fit()`, scikit-learn evaluates hundreds of candidate thresholds in milliseconds, generating an internal binary tree data structure ready for prediction and visualization.

## Practical Exercises
- **Exercise 3.1a**: Why are decision tree boundaries always perpendicular to feature axes rather than diagonal?
- **Exercise 3.1b**: Draw a 2D graph with `minor_axis` on the x-axis and `area` on the y-axis, and sketch the lines `minor_axis = 6.04` and `area = 1019.50`.

## Common Mistakes and Debugging
| Mistake | Root Cause | Remediation |
|---|---|---|
| Expecting diagonal decision boundaries | Misunderstanding CART partitioning | Standard decision trees only make orthogonal, single-feature splits; diagonal boundaries require rotated features or linear combinations |
| Assuming tree building evaluates all future splits simultaneously | Forgetting that CART is a greedy algorithm | CART picks the locally optimal split at each node without backtracking or planning multiple steps ahead |

## Best Practices and Security Considerations
- **Depth Constraints**: Never deploy unconstrained decision trees (`max_depth=None`) to production without verifying whether pruned trees provide equivalent or superior generalization.
- **Deterministic Training**: Always supply `random_state` to ensure reproducible tree topologies.

## Real-World Context and Agricultural Impact
In mechanical conveyor sorters, orthogonal threshold splits directly correspond to optical calibration cutoffs. For example, plant technicians can configure an optical threshold sensor: "If seed width < 6.04 mm, activate Diverter Gate 1."

## Summary
A decision tree is a hierarchical structure of root, internal, and leaf nodes that partitions feature space into orthogonal hyper-rectangles. Scikit-learn's `DecisionTreeClassifier` uses a greedy recursive algorithm (CART) to evaluate candidate thresholds and identify the splits that produce the purest child nodes.

## Knowledge-check Questions
1. What is the difference between an internal decision node and a leaf node?
2. Why are decision tree boundaries in feature space described as "axis-aligned"?
3. What algorithm does scikit-learn use to train decision trees?
4. What role does `random_state=42` play in `DecisionTreeClassifier`?

## References
- Classification and Regression Trees (Breiman, Friedman, Olshen, Stone, 1984).
- scikit-learn Decision Trees Mathematical Formulation: https://scikit-learn.org/stable/modules/tree.html#mathematical-formulation
- Project Source Code: `main.py` lines 43-48.
