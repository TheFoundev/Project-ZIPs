# Lesson 03: Comparing Tree Depths (max_depth=2, 4, and unlimited)

**Lesson ID:** lesson-03  
**Module:** module-03  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain the role of the `max_depth` hyperparameter in controlling tree growth.
- Walk through the depth comparison loop implemented in `main.py`.
- Analyze the test accuracy results for `max_depth=2`, `max_depth=4`, and `max_depth=None`.
- Dynamically identify the optimal tree model using Python's `max()` function.

## Prerequisites
- Lesson 02: Splitting Criteria and Gini Impurity Calculations.
- Basic understanding of Python dictionaries and loops.

## Concept Explanation

### What is Tree Depth?
The **depth** of a node is the number of edges from the root node to that node. The **maximum depth** of a tree (`max_depth`) is the maximum distance from the root to any leaf:
- **Depth 1 (Decision Stump)**: A single split dividing data into 2 leaves. Can only distinguish at most 2 classes.
- **Depth 2**: A two-level tree with at most $2^2 = 4$ leaves. Can distinguish 3 or 4 classes.
- **Depth 4**: A four-level tree with up to $2^4 = 16$ leaves.
- **Unlimited (`None`)**: The tree continues splitting until every leaf is 100% pure (Gini = 0.0) or contains fewer than `min_samples_split` samples.

```
Depth 0 (Root)                [ Root Node ]
                                   │
Depth 1                 ┌──────────┴──────────┐
                        ▼                     ▼
                  [ Node 1 ]              [ Node 2 ]
                        │                     │
Depth 2            ┌────┴────┐           ┌────┴────┐
                   ▼         ▼           ▼         ▼
                (Leaf)    (Leaf)      (Leaf)    (Leaf)
```

### The Depth Comparison Experiment in `main.py`
In lines 43-51 of `main.py`, the pipeline systematically trains and evaluates three distinct models on the exact same training and testing data:
1. `max_depth=2` (A compact, shallow tree)
2. `max_depth=4` (A moderately deep tree)
3. `max_depth=None` (An unconstrained, deep tree)

For each model, the script computes test accuracy on the 45 unseen test seeds:
$$\text{Accuracy} = \frac{\text{Number of Correct Predictions}}{45}$$

### Empirical Results from the Project Run

```
Comparing tree depths:

  max_depth=2         accuracy=86.7%
  max_depth=4         accuracy=84.4%
  max_depth=unlimited accuracy=84.4%

Best tree: max_depth=2
```

Let us examine these results closely:
- `max_depth=2`: Correctly classifies **39 out of 45 test seeds** ($39 / 45 = 86.67\% \approx 86.7\%$).
- `max_depth=4`: Correctly classifies **38 out of 45 test seeds** ($38 / 45 = 84.44\% \approx 84.4\%$).
- `max_depth=unlimited`: Correctly classifies **38 out of 45 test seeds** ($38 / 45 = 84.44\% \approx 84.4\%$).

**The shallow tree wins!** Allowing the tree to grow deeper actually *reduced* test accuracy by 1 sample (2.3 percentage points).

## Relevant Code (from main.py, lines 42-54)
```python
    models = {}
    for depth in (2, 4, None):
        model = DecisionTreeClassifier(max_depth=depth, random_state=42)
        model.fit(X_train, y_train)
        predictions = model.predict(X_test)
        accuracy = accuracy_score(y_test, predictions)
        models[depth] = (model, predictions, accuracy)
        label = "unlimited" if depth is None else str(depth)
        print(f"  max_depth={label:9s} accuracy={accuracy:.1%}")

    best_depth = max(models, key=lambda depth: models[depth][2])
    model, predictions, accuracy = models[best_depth]
    print(f"
Best tree: max_depth={best_depth}")
```

## Code Deep-Dive Breakdown
- `models[depth] = (model, predictions, accuracy)`: Stores a 3-element tuple for each depth, caching the trained model object, test predictions array, and scalar accuracy score.
- `label = "unlimited" if depth is None else str(depth)`: Elegant string formatting handling the Python `None` value for clean console printing.
- `accuracy:.1%`: Formats floating-point accuracy as a percentage with 1 decimal place (e.g., `86.7%`).
- `max(models, key=lambda depth: models[depth][2])`: Uses Python's built-in `max()` with a lambda key targeting index 2 of the tuple (`accuracy`), automatically selecting the depth with highest test accuracy.

## Worked Example
Let us trace how `best_depth` is selected:
- `models[2][2]` = 0.8667
- `models[4][2]` = 0.8444
- `models[None][2]` = 0.8444

The lambda function compares:
```python
max([2, 4, None], key=lambda d: models[d][2])
```
Since `0.8667 > 0.8444`, `best_depth` evaluates to `2`. The script unpacks `models[2]` and proceeds with the optimal shallow model.

## Step-by-Step Student Instructions
1. Run `python main.py` in your terminal.
2. Observe the depth comparison table printed to the console.
3. Confirm that `max_depth=2` achieves 86.7% accuracy.
4. Confirm that both `max_depth=4` and `max_depth=unlimited` achieve 84.4%.
5. Verify that `best_depth` is selected as 2.

## Expected Output or Observable Behaviour
```
Comparing tree depths:

  max_depth=2         accuracy=86.7%
  max_depth=4         accuracy=84.4%
  max_depth=unlimited accuracy=84.4%

Best tree: max_depth=2
```
The output clearly proves that more complex models do not necessarily perform better on test data.

## Practical Exercises
- **Exercise 3.3a**: Modify `for depth in (2, 4, None)` to test `for depth in (1, 2, 3, 4, 5, None)`. What accuracy does a depth 1 tree achieve? Why?
- **Exercise 3.3b**: Why can a depth 1 decision tree never achieve high accuracy on a 3-class problem?

## Common Mistakes and Debugging
| Mistake | Root Cause | Remediation |
|---|---|---|
| Printing `depth=None` as "None" | Missing label ternary statement | Format `None` as "unlimited" to make logs intuitive for non-technical stakeholders |
| Hardcoding `best_depth = 2` | Not selecting dynamically | Use `max(models, key=lambda depth: models[depth][2])` to guarantee dynamic selection if data changes |

## Best Practices and Security Considerations
- **Systematic Hyperparameter Search**: Always benchmark multiple depth candidates rather than blindly choosing an arbitrary depth.
- **Holdout Validation**: Never select the best depth based on training accuracy; always evaluate against unseen holdout validation or test accuracy.

## Real-World Context and Agricultural Impact
In commercial optical sorters, a shallow tree (depth 2) requires only 2 sequential memory reads to route a seed. A depth 10 tree requires up to 10 sequential comparisons. Choosing depth 2 not only improves classification accuracy but also quadruples hardware processing throughput!

## Summary
In `main.py`, tree depths of 2, 4, and unlimited are trained and compared. The shallow tree (`max_depth=2`) achieves the highest test accuracy at 86.7%, whereas deeper trees drop to 84.4%. Python's `max()` function dynamically selects depth 2 as the winning model architecture.

## Knowledge-check Questions
1. What accuracy does `max_depth=2` achieve on the test set?
2. How many test samples did the depth 2 tree classify correctly out of 45?
3. Why did `max_depth=4` and `max_depth=unlimited` achieve lower test accuracy than `max_depth=2`?
4. How does `main.py` dynamically determine `best_depth`?

## References
- scikit-learn DecisionTreeClassifier Hyperparameters: https://scikit-learn.org/stable/modules/generated/sklearn.tree.DecisionTreeClassifier.html
- Model Complexity and Overfitting: Elements of Statistical Learning (Hastie, Tibshirani, Friedman).
- Project Source Code: `main.py` lines 41-54.
