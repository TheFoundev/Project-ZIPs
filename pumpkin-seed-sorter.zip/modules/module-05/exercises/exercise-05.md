# Exercises: Module 05 — Model Evaluation & Error Diagnostics

These practical exercises will test your ability to compute evaluation metrics, interpret classification reports, generate confusion matrices, and diagnose classification errors on the pumpkin seed dataset.

---

## Exercise 1: Manual Calculation of Multi-Class Metrics (Basic)
### Objective
Calculate Precision, Recall, and F1-score by hand from raw True Positive, False Positive, and False Negative counts.

### Task
Given the following test results for a class labeled `Karacabey`:
- Total true Karacabey seeds in test set = 15
- True Positives (TP) = 12
- False Positives (FP) = 0
- False Negatives (FN) = 3

1. Write a Python function `calc_metrics(tp, fp, fn)` that returns `(precision, recall, f1)`.
2. Compute the three metrics and print them rounded to two decimal places.
3. Explain why the precision is 1.00 even though recall is only 0.80.

---

## Exercise 2: Programmatic Classification Report to Dictionary (Intermediate)
### Objective
Extract per-class evaluation metrics into a structured Python dictionary for automated auditing.

### Task
1. Modify `main.py` or write a standalone script that executes:
   ```python
   report_dict = classification_report(y_test, predictions, output_dict=True, zero_division=0)
   ```
2. Extract and print the F1-score for each of the three cultivars:
   - `report_dict["Cercevelik"]["f1-score"]`
   - `report_dict["Karacabey"]["f1-score"]`
   - `report_dict["Urgup_Sivrisi"]["f1-score"]`
3. Add an automated assertion that fails if any variety's F1-score drops below 0.80.

---

## Exercise 3: Customizing the Confusion Matrix Heatmap (Intermediate)
### Objective
Generate a customized confusion matrix plot with alternative colormaps and normalized percentages.

### Task
1. In `main.py`, locate the `ConfusionMatrixDisplay` code block.
2. Create a normalized confusion matrix using `confusion_matrix(y_test, predictions, labels=labels, normalize='true')`.
3. Plot the normalized matrix using `cmap="Blues"` and save it to `outputs/confusion_matrix_normalized.png`.
4. Verify that each row sums to exactly 1.00 (100%).

---

## Exercise 4: Boundary Sample Isolation & Inspection (Advanced)
### Objective
Identify, extract, and inspect the feature vectors of all misclassified samples.

### Task
1. Load `pumpkin_seeds.csv` and split into train and test sets using `test_size=0.25`, `random_state=42`, and `stratify=y`.
2. Train the `DecisionTreeClassifier(max_depth=2, random_state=42)`.
3. Filter the test set to isolate rows where `y_test != predictions`.
4. Print the `area`, `major_axis`, and `minor_axis` of these 6 error samples.
5. Identify the exact threshold in `rules.txt` that caused each of the 6 errors.
