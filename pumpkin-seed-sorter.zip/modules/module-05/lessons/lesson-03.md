# Lesson 03: The Confusion Matrix & ConfusionMatrixDisplay

**Lesson ID:** lesson-03  
**Module:** module-05  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain what a confusion matrix is and how its rows and columns represent true vs predicted classes.
- Use `sklearn.metrics.confusion_matrix` with an explicit `labels` parameter.
- Visualize and save a color-mapped heatmap using `ConfusionMatrixDisplay`.
- Interpret the numerical values inside the $3 \times 3$ grid for pumpkin seed classification.

## Prerequisites
Completion of Lessons 01 and 02; familiarity with matplotlib figure creation.

## Concept Explanation
A confusion matrix is an $N \times N$ square grid where $N$ is the number of target classes (in our project, $N=3$). It maps ground-truth class labels along the rows and predicted class labels along the columns:
- **Rows**: Represent the actual (true) cultivar of the seeds.
- **Columns**: Represent the model's predicted cultivar.
- **Diagonal Elements $(i, i)$**: Represent seeds where the prediction matches the truth (True Positives).
- **Off-Diagonal Elements $(i, j)$ with $i \neq j$**: Represent misclassifications (confusions).

For our pumpkin seed model, sorting labels alphabetically gives:
`['Cercevelik', 'Karacabey', 'Urgup_Sivrisi']`.

The resulting $3 \times 3$ confusion matrix is:
```text
                 Predicted:
                 Cercevelik  Karacabey  Urgup_Sivrisi
True:
Cercevelik          12           0            3
Karacabey            0          12            3
Urgup_Sivrisi        0           0           15
```

Let us read this matrix systematically:
1. **Row 0 (`Cercevelik`)**:
   - Out of 15 true Cercevelik seeds, 12 were correctly predicted as Cercevelik.
   - 0 were predicted as Karacabey.
   - 3 were incorrectly predicted as Urgup_Sivrisi.
2. **Row 1 (`Karacabey`)**:
   - Out of 15 true Karacabey seeds, 0 were predicted as Cercevelik.
   - 12 were correctly predicted as Karacabey.
   - 3 were incorrectly predicted as Urgup_Sivrisi.
3. **Row 2 (`Urgup_Sivrisi`)**:
   - Out of 15 true Urgup_Sivrisi seeds, 0 were predicted as Cercevelik.
   - 0 were predicted as Karacabey.
   - All 15 were correctly predicted as Urgup_Sivrisi.

Notice the strong visual story: every single error made by our model was a prediction of `Urgup_Sivrisi`! The model never confuses Cercevelik with Karacabey, nor does it ever confuse Urgup_Sivrisi with anything else.

## Relevant Code (from main.py, lines 17, 81-89)
```python
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay, confusion_matrix

labels = sorted(df["variety"].unique())
cm = confusion_matrix(y_test, predictions, labels=labels)
fig, ax = plt.subplots(figsize=(6, 4.6))
ConfusionMatrixDisplay(cm, display_labels=labels).plot(ax=ax, cmap="YlOrBr", colorbar=False)
ax.set_title("Pumpkin seed classification")
fig.tight_layout()
fig.savefig(OUT / "confusion_matrix.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```

## Code Deep-Dive Breakdown
- `labels = sorted(df["variety"].unique())`: Extracts unique cultivar strings and sorts them alphabetically: `['Cercevelik', 'Karacabey', 'Urgup_Sivrisi']`. Passing an explicit sorted list ensures that rows and columns follow a deterministic, known ordering regardless of dataset shuffling.
- `cm = confusion_matrix(y_test, predictions, labels=labels)`: Calculates the raw 2D integer NumPy array counting pairwise classifications.
- `ConfusionMatrixDisplay(cm, display_labels=labels)`: Wraps the array and label strings in scikit-learn's visualization helper object.
- `.plot(ax=ax, cmap="YlOrBr", colorbar=False)`:
  - `ax=ax`: Draws the matrix on our custom matplotlib Axes.
  - `cmap="YlOrBr"`: Selects a Yellow-Orange-Brown color gradient, matching the warm autumnal pumpkin theme!
  - `colorbar=False`: Suppresses the vertical color scale bar for a clean presentation.
- `fig.savefig(OUT / "confusion_matrix.png", dpi=150, bbox_inches="tight")`: Saves a crisp PNG at 150 DPI with tight bounding box margins.
- `plt.close(fig)`: Closes the figure immediately, releasing GUI and raster memory.

## Worked Example
Suppose you want to compute the number of false positives for `Urgup_Sivrisi` directly from the matrix:
- Look at the column for `Urgup_Sivrisi` (column index 2).
- The column values are:
  - Row 0 (Cercevelik): 3
  - Row 1 (Karacabey): 3
  - Row 2 (Urgup_Sivrisi): 15
- The True Positives are on the diagonal: 15.
- The False Positives are all off-diagonal entries in that column: $3 + 3 = 6$.
- Now calculate precision:
  $$\text{Precision} = \frac{\text{TP}}{\text{TP} + \text{FP}} = \frac{15}{15 + 6} = \frac{15}{21} \approx 0.7143$$
This is the exact precision figure (0.71) reported by scikit-learn!

## Step-by-Step Student Instructions
1. Run `python main.py` to regenerate the plot artifacts.
2. Verify that `outputs/confusion_matrix.png` exists:
   `ls -l outputs/confusion_matrix.png`
3. View the image in your desktop viewer or image viewing tool.
4. Observe the warm yellow-to-brown shading: the diagonal cells $(0,0), (1,1)$ with 12 seeds and $(2,2)$ with 15 seeds are dark brown, while the off-diagonal cells with 0 are pale yellow/white, and the two cells with 3 are light orange.

## Expected Output or Observable Behaviour
An image `outputs/confusion_matrix.png` displaying a $3 \times 3$ grid:
- Vertical y-axis labeled "True label" with tick labels `Cercevelik`, `Karacabey`, `Urgup_Sivrisi`.
- Horizontal x-axis labeled "Predicted label" with tick labels `Cercevelik`, `Karacabey`, `Urgup_Sivrisi`.
- Text annotations inside the grid cells showing `12`, `0`, `3`, `0`, `12`, `3`, `0`, `0`, `15`.

## Practical Exercises
1. Modify the `cmap` argument in `main.py` from `"YlOrBr"` to `"Blues"` or `"Greens"`, run the script, and observe the new visual appearance.
2. Add `colorbar=True` to `.plot()` and examine the side-bar scale.
3. Compute Karacabey's False Negatives from Row 1 of the matrix.

## Common Mistakes and Debugging
- **Omitting `labels=labels`**: If labels are omitted, scikit-learn sorts labels according to their order of appearance in `y_test`. If `y_test` ordering changes, the rows and columns will be silently swapped, leading to misinterpretations of the diagonal!
- **Mixing up rows and columns**: In scikit-learn, rows are always Ground Truth, and columns are always Predictions. In some other software (e.g., medical R packages), this convention can be reversed. Always check the axis labels!

## Best Practices and Security Considerations
- Always explicitly define and sort the `labels` parameter when creating confusion matrices.
- Use readable colormaps with clear contrast against white or black text annotations.
- Include confusion matrices in model cards and deployment documentation for transparency.

## Real-World Context and Agricultural Impact
In commercial seed sorting facilities handling tons of product per hour, confusion matrices allow plant managers to calculate the exact dollar cost of sorting errors. If Urgup_Sivrisi sells for $2/kg, Karacabey for $3.50/kg, and Cercevelik for $5/kg, multiplying the confusion matrix counts by unit commodity prices reveals the exact financial yield of the sorting run.

## Summary
- A confusion matrix maps true classes (rows) against predicted classes (columns).
- Diagonal cells are correct classifications; off-diagonal cells are errors.
- Explicit `labels` sorting prevents row/column flipping.
- `ConfusionMatrixDisplay` renders formatted heatmaps using matplotlib and colormaps like `YlOrBr`.

## Knowledge-check Questions
1. In scikit-learn's confusion matrix, do the rows represent true labels or predicted labels? (Answer: Rows represent true labels; columns represent predicted labels).
2. What do the off-diagonal entries represent? (Answer: Misclassified samples where the true class does not match the predicted class).
3. Why is `labels=sorted(df["variety"].unique())` passed to `confusion_matrix`? (Answer: To guarantee deterministic and consistent ordering of rows and columns across runs).

## References
- scikit-learn ConfusionMatrixDisplay docs: https://scikit-learn.org/stable/modules/generated/sklearn.metrics.ConfusionMatrixDisplay.html
- Matplotlib Colormaps reference: https://matplotlib.org/stable/users/explain/colors/colormaps.html
