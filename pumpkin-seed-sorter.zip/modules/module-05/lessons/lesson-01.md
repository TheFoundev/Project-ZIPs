# Lesson 01: Multi-Class Evaluation Metrics (Accuracy, Precision, Recall, F1)

**Lesson ID:** lesson-01  
**Module:** module-05  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why simple accuracy alone is insufficient for multi-class agricultural sorting.
- Calculate True Positives (TP), False Positives (FP), and False Negatives (FN) for individual classes.
- Define precision, recall, and F1-score mathematically and explain their agricultural meanings.
- Analyze the operational consequences of false positives versus false negatives in seed packaging.

## Prerequisites
Familiarity with test set predictions from Module 03 and basic fraction division.

## Concept Explanation
When evaluating a machine learning model, the most intuitive metric is overall classification accuracy:
$$\text{Accuracy} = \frac{\text{Number of Correct Predictions}}{\text{Total Number of Predictions}}$$
In our test set of 45 pumpkin seeds (15 Cercevelik, 15 Karacabey, and 15 Urgup_Sivrisi), our depth-2 decision tree correctly predicts 39 out of 45 seeds, yielding an accuracy of:
$$\text{Accuracy} = \frac{39}{45} \approx 86.67\%$$

While 86.7% provides a good overall benchmark, accuracy masks per-class discrepancies. Imagine a seed distribution company packaging premium Cercevelik roasting seeds. If the model accidentally labels low-value Karacabey seeds as Cercevelik, customer satisfaction plummets. Conversely, if Cercevelik seeds are falsely discarded or routed to lower-tier livestock feed bins, the farmer loses revenue.

To capture these distinct failure modes, machine learning defines three per-class metrics:

1. **Precision (Purity / Quality Assurance)**:
   $$\text{Precision} = \frac{\text{True Positives (TP)}}{\text{True Positives (TP)} + \text{False Positives (FP)}}$$
   Precision answers: *Of all seeds the model declared as Variety X, what fraction actually was Variety X?* High precision means when the machine places a seed in the Cercevelik bin, you can be extremely confident that it is truly Cercevelik.

2. **Recall (Sensitivity / Recovery Rate)**:
   $$\text{Recall} = \frac{\text{True Positives (TP)}}{\text{True Positives (TP)} + \text{False Negatives (FN)}}$$
   Recall answers: *Of all actual Variety X seeds in the harvest, what fraction did the model successfully identify?* High recall means very few actual Cercevelik seeds were missed or sent to the wrong bin.

3. **F1-Score (Harmonic Mean)**:
   $$\text{F1-Score} = 2 \times \frac{\text{Precision} \times \text{Recall}}{\text{Precision} + \text{Recall}}$$
   The F1-score balances precision and recall into a single metric using the harmonic mean. Unlike an arithmetic mean, the harmonic mean severely penalizes extreme disparities; a model with 100% precision but 10% recall receives an F1-score of only 18.2%, rather than 55%.

## Relevant Code (from main.py, lines 17, 44-46)
```python
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay, confusion_matrix

# Inside training loop:
predictions = model.predict(X_test)
accuracy = accuracy_score(y_test, predictions)
models[depth] = (model, predictions, accuracy)
```

## Code Deep-Dive Breakdown
- `from sklearn.metrics import accuracy_score`: Imports scikit-learn's standard utility for evaluating 0-1 classification loss.
- `accuracy_score(y_test, predictions)`: Compares ground truth labels in Series `y_test` against NumPy array `predictions` element by element. It returns the exact ratio of identical pairs over total samples.
- `models[depth] = (model, predictions, accuracy)`: Stores the trained estimator, the predicted label array, and the scalar accuracy score in a dictionary keyed by tree depth, enabling immediate comparative auditing.

## Worked Example
Let us compute the metrics for the `Cercevelik` class in our 45-sample test set:
- Ground truth Cercevelik seeds: 15
- Correctly classified as Cercevelik (TP): 12
- Falsely predicted as Cercevelik when they were something else (FP): 0
- Actual Cercevelik misclassified as Urgup_Sivrisi (FN): 3

Now compute the metrics:
1. $\text{Precision} = \frac{12}{12 + 0} = \frac{12}{12} = 1.00$ (100% pure! Every seed routed into the Cercevelik bin was authentic Cercevelik).
2. $\text{Recall} = \frac{12}{12 + 3} = \frac{12}{15} = 0.80$ (80% recovery. We captured 12 out of 15 actual Cercevelik seeds; 3 escaped into another bin).
3. $\text{F1-score} = 2 \times \frac{1.00 \times 0.80}{1.00 + 0.80} = 2 \times \frac{0.80}{1.80} = \frac{1.60}{1.80} \approx 0.8889$ (rounded to 0.89).

This mathematical breakdown precisely matches the first line of the output from `classification_report()`!

## Step-by-Step Student Instructions
1. Open your terminal and activate your virtual environment: `source .venv/bin/activate`.
2. Launch Python interactive shell: `python`.
3. Recreate the calculations above:
   ```python
   tp, fp, fn = 12, 0, 3
   precision = tp / (tp + fp)
   recall = tp / (tp + fn)
   f1 = 2 * (precision * recall) / (precision + recall)
   print(f"Precision: {precision:.2f}")
   print(f"Recall:    {recall:.2f}")
   print(f"F1-score:  {f1:.2f}")
   ```
4. Verify that `precision` outputs `1.00`, `recall` outputs `0.80`, and `f1` outputs `0.89`.
5. Now calculate the same metrics for a hypothetical scenario where `tp = 10`, `fp = 5`, and `fn = 5`. Compare the arithmetic average `(0.667 + 0.667) / 2 = 0.667` against the harmonic mean.

## Expected Output or Observable Behaviour
```text
Precision: 1.00
Recall:    0.80
F1-score:  0.89
```
Notice how precision is 1.00 because no foreign seeds contaminated the Cercevelik bin, but recall is 0.80 because 3 true seeds were routed elsewhere.

## Practical Exercises
1. Compute the recall for Karacabey given TP=12, FP=0, FN=3.
2. If an industrial packaging facility prioritizes zero contamination in organic seed packets, explain whether they should optimize for Precision or Recall.
3. If an endangered plant conservation bank wants to collect every single viable Karacabey seed without leaving any behind in the field, explain whether they should prioritize Precision or Recall.

## Common Mistakes and Debugging
- **Confusing False Positives with False Negatives**: Remember:
  - *False Positive*: An intruder falsely labeled as a member of the class (type I error).
  - *False Negative*: A genuine member falsely rejected or labeled as another class (type II error).
- **Using simple accuracy on imbalanced datasets**: If 98% of seeds were Cercevelik and only 2% were rare Karacabey, a lazy model predicting "Cercevelik" for every seed achieves 98% accuracy while failing 100% of the Karacabey seeds!

## Best Practices and Security Considerations
- Always evaluate multi-class systems on a per-class basis before signing off on deployment.
- Never report raw accuracy without also reporting class balance and per-class recall.
- Maintain transparent audit tables so stakeholders can determine whether downstream errors cause food safety, labeling compliance, or economic losses.

## Real-World Context and Agricultural Impact
In certified organic grain elevators, mixing conventional seeds into organic-labeled bags constitutes federal fraud with heavy fines. Facilities enforce strict Precision thresholds (> 99.5%) on organic seed classification lines, accepting that lower recall (sending some organic seeds to conventional processing) is vastly preferable to contamination lawsuits.

## Summary
- Accuracy is overall percentage correct ($39/45 = 86.7\%$), but masks per-class weaknesses.
- Precision measures purity (absence of false positives).
- Recall measures recovery (absence of false negatives).
- F1-score computes the harmonic mean between precision and recall.
- For Cercevelik, precision is 1.00, recall is 0.80, and F1-score is 0.89.

## Knowledge-check Questions
1. If a sorter identifies 15 seeds as Karacabey, but 3 of them are actually Urgup_Sivrisi, what is the Precision for Karacabey? (Answer: $12 / 15 = 0.80$).
2. Why is the harmonic mean used for F1-score instead of the standard arithmetic average? (Answer: To penalize models with extreme imbalance between precision and recall).
3. If a classifier achieves 100% precision on a variety, does that guarantee it detected all seeds of that variety? (Answer: No; precision measures purity, not completeness. Recall measures completeness).

## References
- scikit-learn metrics user guide: https://scikit-learn.org/stable/modules/model_evaluation.html#classification-metrics
- Fawcett, T. (2006). An introduction to ROC analysis. Pattern Recognition Letters, 27(8), 861-874.
