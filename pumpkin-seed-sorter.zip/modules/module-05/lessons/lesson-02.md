# Lesson 02: Computing and Interpreting the Classification Report

**Lesson ID:** lesson-02  
**Module:** module-05  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Generate comprehensive multi-class evaluation reports using `sklearn.metrics.classification_report`.
- Explain the role and safety necessity of the `zero_division=0` parameter.
- Interpret support counts, per-class rows, macro average, and weighted average.
- Connect the terminal text report to the project's canonical pumpkin seed results.

## Prerequisites
Completion of Lesson 01 (precision, recall, and F1-score definitions).

## Concept Explanation
Evaluating a multi-class model manually for every class becomes tedious and error-prone as the number of classes increases. Scikit-learn provides `classification_report`, a formatting utility that computes precision, recall, F1-score, and support for every target class simultaneously.

Here is the exact output produced by `main.py` for our pumpkin seed test set:
```text
               precision    recall  f1-score   support

   Cercevelik       1.00      0.80      0.89        15
    Karacabey       1.00      0.80      0.89        15
Urgup_Sivrisi       0.71      1.00      0.83        15

     accuracy                           0.87        45
    macro avg       0.90      0.87      0.87        45
 weighted avg       0.90      0.87      0.87        45
```

Let us unpack each column and summary row:

1. **Class Rows (`Cercevelik`, `Karacabey`, `Urgup_Sivrisi`)**:
   - `support`: The number of actual ground-truth occurrences of each class in `y_test`. Because our train/test split utilized `stratify=y`, each of the three cultivars has exactly 15 test samples ($15 \times 3 = 45$).
   - `Cercevelik`: Precision is 1.00 (no non-Cercevelik seeds were called Cercevelik). Recall is 0.80 ($12/15$).
   - `Karacabey`: Precision is 1.00 (no non-Karacabey seeds were called Karacabey). Recall is 0.80 ($12/15$).
   - `Urgup_Sivrisi`: Recall is 1.00 ($15/15$ actual Urgup seeds detected). Precision is 0.71 ($15 / (15 + 3 + 3) = 15/21 \approx 0.714$).

2. **Accuracy Row**:
   - Reports the overall percentage of correct predictions ($39/45 = 0.8667$, printed as 0.87) across the entire 45-sample test set.

3. **Macro Average (`macro avg`)**:
   - The unweighted arithmetic average of precision, recall, and F1 across all classes:
     $$\text{Macro Precision} = \frac{1.00 + 1.00 + 0.714}{3} \approx 0.9048 \rightarrow 0.90$$
     $$\text{Macro Recall} = \frac{0.80 + 0.80 + 1.00}{3} \approx 0.8667 \rightarrow 0.87$$
     $$\text{Macro F1} = \frac{0.8889 + 0.8889 + 0.8333}{3} \approx 0.8703 \rightarrow 0.87$$
   - Macro averaging treats every class equally, making it sensitive to poor performance on small minority classes.

4. **Weighted Average (`weighted avg`)**:
   - The average of metrics weighted by the support of each class:
     $$\text{Weighted Metric} = \sum_{c} \left( \text{Metric}_c \times \frac{\text{Support}_c}{\text{Total Support}} \right)$$
   - In our dataset, each class has equal support (15 samples, or 33.3% of the test set). Consequently, the macro average and weighted average are identical!

## Relevant Code (from main.py, lines 17, 57, 98)
```python
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay, confusion_matrix

# Print formatted report to console:
print(classification_report(y_test, predictions, zero_division=0))

# Persist to disk inside outputs/rules.txt:
with open(OUT / "rules.txt", "w", encoding="utf-8") as handle:
    ...
    handle.write("
" + classification_report(y_test, predictions, zero_division=0))
```

## Code Deep-Dive Breakdown
- `classification_report(y_test, predictions, zero_division=0)`:
  - `y_test`: 1D array-like containing true cultivar strings.
  - `predictions`: 1D array-like containing predicted cultivar strings from `model.predict(X_test)`.
  - `zero_division=0`: Controls what value to return when a denominator is zero (such as $0 / 0$ when a class has 0 predictions or 0 true instances). Without `zero_division=0`, scikit-learn prints an ugly `UndefinedMetricWarning` to stderr and defaults to `0.0` or `1.0` depending on version. Explicitly setting `zero_division=0` ensures quiet, predictable pipeline runs.

## Worked Example
Suppose a model never predicted `Cercevelik` for any sample in the test set.
Then for Cercevelik:
- $\text{TP} = 0$
- $\text{FP} = 0$
- Denominator $\text{TP} + \text{FP} = 0$
Attempting to calculate $\frac{0}{0}$ triggers a zero division error in mathematics. By passing `zero_division=0`, `classification_report` safely assigns `0.00` to Precision without halting Python execution or crashing production batch jobs.

## Step-by-Step Student Instructions
1. Navigate to the project directory:
   `cd "/home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/15_pumpkin_seed_sorter"`
2. Execute `main.py` and inspect the terminal output:
   `python main.py`
3. Locate the classification report block in the printed output.
4. Verify each row against the canonical table shown above.
5. Check `outputs/rules.txt` to confirm that the identical text was appended to the audit file.

## Expected Output or Observable Behaviour
```text
               precision    recall  f1-score   support

   Cercevelik       1.00      0.80      0.89        15
    Karacabey       1.00      0.80      0.89        15
Urgup_Sivrisi       0.71      1.00      0.83        15

     accuracy                           0.87        45
    macro avg       0.90      0.87      0.87        45
 weighted avg       0.90      0.87      0.87        45
```

## Practical Exercises
1. Calculate the weighted average precision if class supports were Cercevelik: 10, Karacabey: 10, Urgup_Sivrisi: 80, keeping individual precisions at 1.00, 1.00, and 0.71.
2. In Python, call `classification_report` with `output_dict=True` and print the resulting dictionary keys.
3. Explain why `Urgup_Sivrisi` has a lower precision (0.71) even though its recall is a perfect 1.00.

## Common Mistakes and Debugging
- **Omitting `zero_division=0`**: In small test splits or rare categories, if an unpredicted class occurs, omitting this flag floods your log files with scikit-learn warnings: `UndefinedMetricWarning: Precision and F-score are ill-defined and being set to 0.0 in labels with no predicted samples.`
- **Passing parameters in reverse order**: Always pass `(y_true, y_pred)`. If you mistakenly pass `(predictions, y_test)`, precision and recall will be swapped, completely corrupting your analysis!

## Best Practices and Security Considerations
- Keep `classification_report` evaluations reproducible by always fixing `random_state` in the upstream train/test split.
- Use `output_dict=True` when building automated CI/CD quality gates (e.g., verifying that no class drops below 0.75 F1-score before pushing a model artifact to production).

## Real-World Context and Agricultural Impact
Seed regulatory bodies (such as ISTA, the International Seed Testing Association) establish statutory purity levels. Packaging lines must provide certified inspection reports detailing both variety purity (precision) and germination counts. The output of `classification_report` serves as the direct technical basis for lot certification.

## Summary
- `classification_report` produces a clean tabular overview of multi-class metrics.
- Support represents the true count of samples per class in the evaluation set.
- `zero_division=0` prevents runtime warnings and crashes on unpredicted classes.
- Equal class support makes macro average equal to weighted average.

## Knowledge-check Questions
1. What does the `support` column indicate for each variety? (Answer: The actual number of true instances of that variety in the test set).
2. What happens if a model makes 0 predictions for class A and `zero_division=0` is set? (Answer: Precision is assigned 0.0 without triggering an UndefinedMetricWarning).
3. If support is identical across all classes, how will the macro average and weighted average compare? (Answer: They will be exactly identical).

## References
- scikit-learn classification_report docs: https://scikit-learn.org/stable/modules/generated/sklearn.metrics.classification_report.html
- International Seed Testing Association (ISTA) Rules: https://www.seedtest.org
