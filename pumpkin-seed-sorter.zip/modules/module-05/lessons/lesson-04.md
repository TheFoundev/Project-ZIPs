# Lesson 04: Error Diagnostics & Seed Misclassification Patterns

**Lesson ID:** lesson-04  
**Module:** module-05  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Trace the specific 6 misclassified test samples down the decision tree branches.
- Explain why Cercevelik and Karacabey seeds can be mistaken for Urgup_Sivrisi.
- Analyze morphological overlaps in seed area, perimeter, and axis measurements.
- Propose mitigation strategies (feature engineering, deeper trees, ensembles) to resolve cultivar overlap.

## Prerequisites
Completion of Lessons 01, 02, and 03; understanding of decision tree splitting rules from Module 04.

## Concept Explanation
In Lesson 03, we observed that out of 45 test seeds, exactly 6 were misclassified, and all 6 were misclassified as `Urgup_Sivrisi`:
- 3 true `Cercevelik` seeds predicted as `Urgup_Sivrisi`.
- 3 true `Karacabey` seeds predicted as `Urgup_Sivrisi`.
- 0 true `Urgup_Sivrisi` seeds misclassified.

Why does this asymmetrical error pattern occur? To understand this, we must inspect the physical biology of pumpkin seeds and how our tree's mathematical decision boundaries divide feature space.

Recall the learned decision rules from Module 04:
```text
|--- minor_axis <= 6.04
|   |--- area <= 1019.50 -> [Karacabey]
|   |--- area >  1019.50 -> [Urgup_Sivrisi]
|--- minor_axis >  6.04
|   |--- major_axis <= 12.58 -> [Urgup_Sivrisi]
|   |--- major_axis >  12.58 -> [Cercevelik]
```

Notice that `Urgup_Sivrisi` occupies TWO leaf nodes:
1. One leaf under the **left branch** (`minor_axis <= 6.04` and `area > 1019.50`).
2. One leaf under the **right branch** (`minor_axis > 6.04` and `major_axis <= 12.58`).

Because `Urgup_Sivrisi` spans both branches, any seed that deviates slightly from the typical morphology of its own cultivar falls into one of these two Urgup leaves!

Let us analyze the biological causes:

1. **The 3 Misclassified Karacabey Seeds**:
   - Karacabey seeds are generally plumper and smaller in area ($< 1019.50\,\text{mm}^2$).
   - However, in any biological harvest, some individual Karacabey seeds grow unusually large due to favorable localized watering or nutrient distribution on the vine.
   - When an exceptionally large Karacabey seed has an area of $1050\,\text{mm}^2$ while retaining a narrow minor axis ($\le 6.04$), the tree's left branch tests `area <= 1019.50`, finds it false, and immediately routes it to `Urgup_Sivrisi`!

2. **The 3 Misclassified Cercevelik Seeds**:
   - Cercevelik seeds are typically elongated, characterized by a large major axis ($> 12.58\,\text{mm}$).
   - However, stunted or slightly immature Cercevelik seeds may have a major axis of $12.30\,\text{mm}$.
   - Because its minor axis is wide ($> 6.04$), it routes to the right branch. The tree tests `major_axis <= 12.58`. Finding this true, it classifies the stunted Cercevelik seed as `Urgup_Sivrisi`!

## Relevant Code (from main.py, lines 40-56)
```python
# Comparing tree depths
models = {}
for depth in (2, 4, None):
    model = DecisionTreeClassifier(max_depth=depth, random_state=42)
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)
    models[depth] = (model, predictions, accuracy)
```

## Code Deep-Dive Breakdown
- At `max_depth=2`, the model is constrained to 4 leaf nodes. It cannot create additional sub-splits to carve out isolated pockets of unusually large Karacabey or stunted Cercevelik seeds.
- When we increased `max_depth` to 4 or unconstrained (`None`), training accuracy increased, but test accuracy actually *dropped* from 86.7% to 84.4% (38/45 correct)!
- Why? Because creating deeper splits on those 6 borderline seeds caused the tree to overfit noisy training anomalies, misclassifying different test seeds!

## Worked Example
Let us write a short pandas snippet to filter and isolate the misclassified test seeds:
```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier

df = pd.read_csv("data/pumpkin_seeds.csv")
X = df[["area", "perimeter", "major_axis", "minor_axis", "eccentricity"]]
y = df["variety"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)

tree = DecisionTreeClassifier(max_depth=2, random_state=42).fit(X_train, y_train)
test_results = X_test.copy()
test_results["actual"] = y_test
test_results["predicted"] = tree.predict(X_test)

errors = test_results[test_results["actual"] != test_results["predicted"]]
print(errors[["actual", "predicted", "area", "major_axis", "minor_axis"]])
```
Running this code reveals the exact feature values of the 6 misclassified seeds, verifying that every single one sits right on the boundary of $1019.50$ or $12.58$!

## Step-by-Step Student Instructions
1. Open a terminal and navigate to the project directory.
2. Create a test script `check_errors.py` using the snippet above.
3. Run the script: `python check_errors.py`.
4. Inspect the area values of the misclassified Karacabey seeds: observe that they are all $> 1019.50$.
5. Inspect the major axis values of the misclassified Cercevelik seeds: observe that they are all $\le 12.58$.

## Expected Output or Observable Behaviour
```text
           actual      predicted     area  major_axis  minor_axis
76      Karacabey  Urgup_Sivrisi  1042.20       11.85        5.92
88      Karacabey  Urgup_Sivrisi  1031.50       11.90        6.01
94      Karacabey  Urgup_Sivrisi  1065.10       12.10        5.88
12     Cercevelik  Urgup_Sivrisi  1110.40       12.35        6.22
29     Cercevelik  Urgup_Sivrisi  1145.80       12.48        6.15
41     Cercevelik  Urgup_Sivrisi  1098.20       12.20        6.11
```

## Practical Exercises
1. Calculate the average `area` of the misclassified Karacabey seeds compared to the overall Karacabey average area.
2. Calculate the average `major_axis` of the misclassified Cercevelik seeds compared to the overall Cercevelik average major axis.
3. Propose two new engineered features (e.g., `aspect_ratio = major_axis / minor_axis` or `compactness = (perimeter ** 2) / area`) that could help distinguish elongated Urgup seeds from rounder Karacabey seeds.

## Common Mistakes and Debugging
- **Assuming misclassifications are random noise**: In machine learning, misclassifications almost always cluster along specific decision boundaries. Diagnosing which features cause boundary errors is the key to effective feature engineering.
- **Increasing tree depth impulsively**: Trying to force 100% accuracy on training data by allowing unlimited tree depth degrades generalization on test data due to overfitting.

## Best Practices and Security Considerations
- In real-world agricultural packaging, add a "Reject / Secondary Inspection" chute for seeds whose measurements fall within a $\pm 3\%$ margin of the decision thresholds ($1019.50 \pm 30$, $12.58 \pm 0.38$).
- Re-run error analysis whenever new harvests or varieties are introduced to guard against seasonal distribution drift.

## Real-World Context and Agricultural Impact
In mechanical seed processing, no physical classifier achieves 100% precision due to natural biological variation. Commercial sorters often combine morphological imaging with weight sensors or multi-spectral NIR (near-infrared) cameras to separate chemically distinct seeds that share overlapping geometric boundaries.

## Summary
- All 6 misclassified test seeds were predicted as `Urgup_Sivrisi` due to its position spanning both branches.
- Misclassified Karacabey seeds were unusually large ($area > 1019.50$).
- Misclassified Cercevelik seeds were unusually short ($major\_axis \le 12.58$).
- Boundary analysis guides feature engineering and prevents misguided attempts to overfit with deeper trees.

## Knowledge-check Questions
1. Why did increasing tree depth from 2 to 4 decrease test set accuracy from 86.7% to 84.4%? (Answer: Because the deeper tree overfit training set boundary noise, failing to generalize to unseen test samples).
2. What physical trait causes an oversized Karacabey seed to be misclassified as Urgup_Sivrisi? (Answer: Its area exceeds 1019.50 mm², crossing the left branch threshold).
3. What engineering technique can resolve geometric boundary overlaps without overfitting? (Answer: Introducing engineered ratios such as aspect ratio or adding complementary sensors like weight or spectral reflectance).

## References
- Hastie, T., Tibshirani, R., & Friedman, J. (2009). The Elements of Statistical Learning: Data Mining, Inference, and Prediction. Springer.
- Koklu, M., Sarigil, S., & Ozbek, O. (2021). The use of machine learning methods in classification of pumpkin seeds. Genetic Resources and Crop Evolution, 68(7), 2713-2726.
