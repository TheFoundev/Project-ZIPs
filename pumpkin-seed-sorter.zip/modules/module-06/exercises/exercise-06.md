# Exercises: Module 06 — Industrial Pipeline, Retraining & Agricultural Applications

These practical exercises will test your ability to build production audit trails, calculate real-time hardware sorting latencies, engineer domain-specific morphological ratios, and retrain pipelines on expanded datasets.

---

## Exercise 1: Enhancing the Production Audit Trail (Basic)
### Objective
Extend `outputs/rules.txt` with metadata including timestamp, dataset row counts, and class support distributions.

### Task
1. Modify the file writing block in `main.py` lines 91-98.
2. At the top of `outputs/rules.txt`, write:
   - Current UTC date and time in ISO format (using `datetime.utcnow().isoformat()`).
   - Total rows in `pumpkin_seeds.csv`.
   - Feature list used for training (`FEATURES`).
3. Re-run `main.py` and verify that `outputs/rules.txt` contains the new header metadata.

---

## Exercise 2: Real-Time Conveyor Latency Simulation (Intermediate)
### Objective
Compute exact pneumatic valve firing schedules for variable conveyor belt speeds.

### Task
1. Write a Python script `simulate_conveyor.py`.
2. Define a function `calculate_firing_delay(distance_mm, belt_speed_m_per_s, processing_time_ms)`:
   - Compute travel time from camera to nozzle: $t = (distance\_mm / 1000) / belt\_speed$.
   - Subtract software processing time.
   - Return firing delay in milliseconds.
3. Compute the firing delay for:
   - Distance = $180\,	ext{mm}$
   - Belt speed = $3.2\,	ext{m/s}$
   - Processing time = $1.5\,	ext{ms}$
4. Add a safety assertion ensuring that firing delay is strictly positive ($> 0$).

---

## Exercise 3: Evaluating Engineered Features (Intermediate)
### Objective
Quantify whether adding `aspect_ratio` and `compactness` improves or alters decision tree performance.

### Task
1. In a standalone script, load `data/pumpkin_seeds.csv`.
2. Add columns:
   - `df["aspect_ratio"] = df["major_axis"] / df["minor_axis"]`
   - `df["compactness"] = (4 * 3.14159 * df["area"]) / (df["perimeter"] ** 2)`
3. Split the data using `test_size=0.25`, `random_state=42`, and `stratify=y`.
4. Train `DecisionTreeClassifier(max_depth=2, random_state=42)` on:
   - Baseline: 5 original features.
   - Enhanced: 5 original + 2 engineered features.
5. Print the comparative accuracies and feature importances for both models.

---

## Exercise 4: Automated 4-Cultivar Retraining Pipeline (Advanced)
### Objective
Simulate adding a new pumpkin seed variety and executing an automated retraining workflow.

### Task
1. Write a script `retrain_pipeline.py`.
2. Generate 60 synthetic samples for cultivar `Styrian_Hulless` with:
   - `area` ~ Normal(920, 30)
   - `perimeter` ~ Normal(49, 1.5)
   - `major_axis` ~ Normal(10.8, 0.4)
   - `minor_axis` ~ Normal(5.3, 0.2)
   - `eccentricity` ~ Normal(0.81, 0.02)
3. Concatenate these rows to `pumpkin_seeds.csv`.
4. Run the full training loop across depths (2, 3, 4, None).
5. Identify the best tree depth for the 4-class problem and save the updated confusion matrix as `outputs/confusion_matrix_4class.png`.
