# Lesson 03: Feature Engineering & Morphological Extensions

**Lesson ID:** lesson-03  
**Module:** module-06  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Define domain-specific geometric ratios: aspect ratio, compactness, roundness, and convexity.
- Explain how engineered features transform nonlinear physical boundaries into linear splits.
- Implement feature engineering transformations in pandas on the pumpkin seed dataset.
- Evaluate the impact of engineered features on decision tree classification accuracy.

## Prerequisites
Completion of Module 02 (pandas feature exploration) and Module 05 (error boundary diagnostics).

## Concept Explanation
In Module 05, we diagnosed that the 6 misclassifications in our test set occurred because `area`, `major_axis`, and `minor_axis` alone leave small overlap regions between cultivars:
- Exceptionally large Karacabey seeds had area $> 1019.50\,\text{mm}^2$, crossing into the Urgup_Sivrisi zone.
- Exceptionally short Cercevelik seeds had major axis $\le 12.58\,\text{mm}$, crossing into the Urgup_Sivrisi zone.

In raw physical dimensions, a large Karacabey seed and a small Urgup seed may share similar area or length. However, **their shape ratios remain distinct!** A Karacabey seed is plump and rounded, whereas an Urgup seed is characteristically slender and pointed.

By creating **engineered morphological features**, we give our decision tree direct access to dimensionless shape indicators that do not depend on absolute seed size:

1. **Aspect Ratio**:
   $$\text{Aspect Ratio} = \frac{\text{major\_axis}}{\text{minor\_axis}}$$
   - Round seeds (Karacabey) have aspect ratios close to $1.5 - 1.8$.
   - Elongated seeds (Urgup_Sivrisi) have aspect ratios exceeding $2.1 - 2.5$.
   - Even if an Urgup seed is stunted and small, its aspect ratio remains high!

2. **Compactness (Isoperimetric Quotient)**:
   $$\text{Compactness} = \frac{4 \pi \times \text{area}}{\text{perimeter}^2}$$
   - A perfect circle has a compactness of $1.0$.
   - Highly elongated, irregular, or pointed seeds have lower compactness values ($0.4 - 0.6$).

3. **Equivalent Diameter**:
   $$\text{Equivalent Diameter} = \sqrt{\frac{4 \times \text{area}}{\pi}}$$
   - Represents the diameter of a circle having the same area as the seed.

4. **Estimated Hull Convexity**:
   $$\text{Convexity} = \frac{\text{Convex Perimeter}}{\text{Perimeter}}$$
   - Measures boundary smoothness; indented or broken seeds exhibit lower convexity.

## Relevant Code (from main.py, line 24)
```python
FEATURES = ["area", "perimeter", "major_axis", "minor_axis", "eccentricity"]
```

## Code Deep-Dive Breakdown
- In `main.py`, the pipeline uses the 5 raw features extracted by the image acquisition system.
- To introduce engineered features, we can construct new columns directly in pandas before executing `train_test_split`:
  ```python
  import numpy as np

  # Compute Aspect Ratio:
  df["aspect_ratio"] = df["major_axis"] / df["minor_axis"]

  # Compute Compactness:
  df["compactness"] = (4 * np.pi * df["area"]) / (df["perimeter"] ** 2)

  # Expand feature list:
  EXTENDED_FEATURES = FEATURES + ["aspect_ratio", "compactness"]
  ```
- Because decision trees test axis-aligned orthogonal splits, providing `major_axis / minor_axis` as an explicit feature allows the tree to split on diagonal boundaries in $(major, minor)$ space with a single threshold!

## Worked Example
Let us compute `aspect_ratio` for a typical Karacabey seed versus a misclassified Karacabey seed:
- Normal Karacabey: $major = 11.20$, $minor = 6.40 \rightarrow \text{Aspect Ratio} = 11.20 / 6.40 = 1.75$.
- Misclassified Karacabey (Sample 76): $major = 11.85$, $minor = 5.92 \rightarrow \text{Aspect Ratio} = 11.85 / 5.92 = 2.00$.
- Urgup_Sivrisi average: $major = 12.80$, $minor = 5.60 \rightarrow \text{Aspect Ratio} = 12.80 / 5.60 = 2.29$.

Notice that while Sample 76's area ($1042.20$) overlapped with Urgup, its aspect ratio ($2.00$) sits between Karacabey ($1.75$) and Urgup ($2.29$), offering an additional dimension to tease apart difficult edge cases.

## Step-by-Step Student Instructions
1. Open Python in the project root: `python`.
2. Load the dataset and create the engineered features:
   ```python
   import pandas as pd
   import numpy as np
   from sklearn.model_selection import train_test_split
   from sklearn.tree import DecisionTreeClassifier
   from sklearn.metrics import accuracy_score

   df = pd.read_csv("data/pumpkin_seeds.csv")
   df["aspect_ratio"] = df["major_axis"] / df["minor_axis"]
   df["compactness"] = (4 * np.pi * df["area"]) / (df["perimeter"] ** 2)

   features = ["area", "perimeter", "major_axis", "minor_axis", "eccentricity", "aspect_ratio", "compactness"]
   X = df[features]
   y = df["variety"]

   X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)
   tree = DecisionTreeClassifier(max_depth=2, random_state=42).fit(X_train, y_train)
   acc = accuracy_score(y_test, tree.predict(X_test))
   print(f"Accuracy with engineered features: {acc:.1%}")
   ```
3. Inspect `tree.feature_importances_` to see which features the tree selected as primary splits:
   ```python
   for name, imp in zip(features, tree.feature_importances_):
       if imp > 0:
           print(f"  {name}: {imp:.3f}")
   ```

## Expected Output or Observable Behaviour
```text
Accuracy with engineered features: 86.7%
  minor_axis: 0.587
  area: 0.281
  major_axis: 0.132
```
At `max_depth=2`, the tree retains its primary morphological anchors (`minor_axis`, `area`, `major_axis`). At `max_depth=3`, the model can utilize `aspect_ratio` to resolve secondary boundary ambiguities.

## Practical Exercises
1. Calculate the correlation between `eccentricity` and `aspect_ratio` across all 180 seeds in the CSV.
2. Engineer an estimated volume feature assuming pumpkin seeds are flattened ellipsoids: $\text{Volume} \approx \frac{4}{3} \pi \times \frac{\text{major}}{2} \times \frac{\text{minor}}{2} \times \text{thickness}$ (assuming constant thickness $2\,\text{mm}$).
3. Explain why dimensionless shape features are more robust against overall seed shrinkage during post-harvest oven drying than raw area or perimeter.

## Common Mistakes and Debugging
- **Dividing by zero in ratio features**: If an image segmentation artifact yields `minor_axis = 0`, calculating `major_axis / minor_axis` generates `inf` or `NaN`, which crashes scikit-learn estimators. Always add a small safety epsilon or validate that min value $> 0$.
- **Feature explosion with correlated collinear variables**: Adding dozens of ratio variations without pruning can dilute decision tree splitting criteria and increase overfitting risk on small training sets.

## Best Practices and Security Considerations
- Validate all input features against domain physiological sanity bounds (e.g., $1.0 \le \text{aspect\_ratio} \le 5.0$) before feeding to the model.
- Document feature engineering definitions in a shared data dictionary so hardware firmware engineers compute identical mathematical formulas.

## Real-World Context and Agricultural Impact
Agricultural crops naturally vary in size depending on seasonal rainfall, but genetic morphology ratios remain stable. Crop breeders rely heavily on dimensionless shape ratios to distinguish true-to-type seed stocks from accidental cross-pollinated hybrids.

## Summary
- Dimensionless shape features (aspect ratio, compactness) capture seed geometry independent of absolute size.
- Aspect ratio (`major_axis / minor_axis`) separates slender Urgup seeds from plumper Karacabey seeds.
- Decision trees can utilize engineered ratios to create diagonal decision boundaries in a single axis-aligned split.
- Input validation safeguards against division-by-zero errors in automated production pipelines.

## Knowledge-check Questions
1. How is aspect ratio calculated from seed measurements? (Answer: Major axis length divided by minor axis length).
2. Why are dimensionless shape ratios useful when seeds dry and shrink during storage? (Answer: Because both major and minor dimensions shrink proportionally, leaving the aspect ratio relatively stable compared to raw area).
3. What error occurs if `minor_axis` is zero when computing aspect ratio? (Answer: ZeroDivisionError or floating point infinity/NaN, causing estimator failure).

## References
- Koklu, M., Sarigil, S., & Ozbek, O. (2021). The use of machine learning methods in classification of pumpkin seeds. Genetic Resources and Crop Evolution, 68(7), 2713-2726.
- scikit-learn preprocessing and feature engineering: https://scikit-learn.org/stable/modules/preprocessing.html
