# Lesson 04: Retraining, Concept Drift, & Adding Cultivars

**Lesson ID:** lesson-04  
**Module:** module-06  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Identify agricultural concept drift caused by seasonal weather variations and seed aging.
- Follow the prompt at the conclusion of `main.py`: *"add a new seed variety to the CSV and retrain"*.
- Implement an automated retraining pipeline that updates rules, plots, and metrics.
- Evaluate the impact of adding a 4th pumpkin cultivar on tree depth and class separability.

## Prerequisites
Completion of Lessons 01, 02, and 03; understanding of end-to-end execution of `main.py`.

## Concept Explanation
At the end of `main.py`, line 101 prints an invitation:
```text
Try this: add a new seed variety to the CSV and retrain.
```
Machine learning models are not static artifacts carved in stone. In agricultural environments, models face continuous changes known as **data drift** and **concept drift**:

1. **Covariate Drift (Seasonal Climate Variations)**:
   - In a severe drought year, all pumpkin seeds across all varieties may grow 15% smaller on average.
   - The decision boundary for Karacabey area ($1019.50\,\text{mm}^2$) may no longer align with the new harvest's size distribution, causing Karacabey seeds to be systematically misclassified!
2. **Concept Drift (Biological & Mechanical Shifts)**:
   - A farm might adopt a new seed cleaning centrifuge that polishes off outer seed hairs, altering optical perimeter measurements.
3. **Class Addition (Novel Cultivars)**:
   - Commercial demand shifts, and the farm introduces a 4th pumpkin variety, such as **Lady Godiva** (a hull-less Austrian Styrian oilseed variety characterized by dark olive-green seeds and distinct geometric properties).

When conditions change or new varieties are introduced, the machine learning engineer must execute an **automated retraining workflow**:
1. Ingest newly labeled ground truth samples.
2. Validate data schema integrity and morphological bounds.
3. Re-split with stratification across all active classes.
4. Benchmark tree depths to find the new optimal bias-variance trade-off.
5. Export updated `rules.txt`, `pumpkin_tree.png`, and `confusion_matrix.png`.
6. Deploy the updated model artifact to the sorting hardware.

## Relevant Code (from main.py, line 101)
```python
print("\nSaved: outputs/pumpkin_tree.png, outputs/confusion_matrix.png, outputs/rules.txt")
print("Try this: add a new seed variety to the CSV and retrain.")
```

## Code Deep-Dive Breakdown
- Adding a 4th variety to `pumpkin_seeds.csv` expands the target vector $y$ from 3 unique values to 4.
- Because `main.py` uses dynamic code:
  - `labels = sorted(df["variety"].unique())` dynamically detects all unique classes.
  - `class_names=list(model.classes_)` automatically extracts the new class names for `plot_tree`.
  - `classification_report(..., zero_division=0)` automatically generates a 4-class evaluation table.
  - `ConfusionMatrixDisplay` automatically expands from a $3 \times 3$ grid to a $4 \times 4$ grid!
- The entire script is fully parameterized and generic; no hardcoded cultivar strings exist in the core evaluation loop!

## Worked Example
Let us simulate adding 60 samples of a 4th variety, `Lady_Godiva`, characterized by smaller, narrower dimensions:
- Area: $850 - 950\,\text{mm}^2$
- Perimeter: $45 - 50\,\text{mm}$
- Major axis: $10.0 - 11.2\,\text{mm}$
- Minor axis: $4.8 - 5.5\,\text{mm}$
- Eccentricity: $0.80 - 0.85$

When we append these rows to `pumpkin_seeds.csv` and re-run `python main.py`:
- Total dataset expands from 180 to 240 samples.
- Test split (25%) expands from 45 to 60 samples (15 per variety).
- Depth 2 tree accuracy may no longer suffice because 4 classes require at least $\log_2(4) = 2$ splits under ideal conditions, and often depth 3 or 4 when overlaps exist.
- The script automatically compares `max_depth=(2, 4, None)`, selects the new best depth, updates `rules.txt`, and generates a $4 \times 4$ confusion matrix!

## Step-by-Step Student Instructions
1. Make a backup copy of your data file:
   `cp data/pumpkin_seeds.csv data/pumpkin_seeds_backup.csv`
2. Create a Python script `add_variety.py` to append synthetic `Lady_Godiva` seeds:
   ```python
   import pandas as pd
   import numpy as np

   np.random.seed(42)
   n_new = 60
   new_data = pd.DataFrame({
       "variety": ["Lady_Godiva"] * n_new,
       "area": np.random.normal(900, 40, n_new).round(2),
       "perimeter": np.random.normal(48, 2, n_new).round(2),
       "major_axis": np.random.normal(10.5, 0.4, n_new).round(2),
       "minor_axis": np.random.normal(5.1, 0.3, n_new).round(2),
       "eccentricity": np.random.normal(0.82, 0.02, n_new).round(4)
   })
   df = pd.read_csv("data/pumpkin_seeds.csv")
   combined = pd.concat([df, new_data], ignore_index=True)
   combined.to_csv("data/pumpkin_seeds.csv", index=False)
   print(f"Dataset updated: {len(combined)} rows, classes: {combined['variety'].unique()}")
   ```
3. Run the script: `python add_variety.py`.
4. Re-run the main pipeline: `python main.py`.
5. Open `outputs/rules.txt` and observe how the decision tree incorporated `Lady_Godiva` into the decision rules.
6. Restore original data when finished:
   `mv data/pumpkin_seeds_backup.csv data/pumpkin_seeds.csv`

## Expected Output or Observable Behaviour
When re-running `main.py` with 4 varieties:
- Terminal prints comparisons for all tree depths.
- Confusion matrix displays a $4 \times 4$ grid labeled `Cercevelik`, `Karacabey`, `Lady_Godiva`, `Urgup_Sivrisi`.
- `outputs/rules.txt` documents the updated multi-class decision boundaries.

## Practical Exercises
1. Compare the best `max_depth` between the 3-class model and the 4-class model. Did the best depth increase from 2 to 4?
2. Inspect the confusion matrix: does `Lady_Godiva` confuse with `Karacabey` due to their overlapping small areas?
3. What governance step should precede deploying a retrained model to physical sorting conveyor hardware?

## Common Mistakes and Debugging
- **Hardcoding class names**: If you write `class_names=["Cercevelik", "Karacabey", "Urgup_Sivrisi"]` in your plotting code instead of `list(model.classes_)`, adding a fourth class causes an `IndexError` or crashes `plot_tree`. Always infer classes dynamically from the estimator!
- **Data leakage during retraining**: Ensure that newly collected batches undergo the same stratified splitting protocol before evaluating performance.

## Best Practices and Security Considerations
- Implement a model registry (e.g., MLflow or versioned directory structures) to store past models and audit logs alongside current ones.
- Require automated shadow deployment (running the new model in parallel without actuating air valves) to verify real-world predictions before switching active sorting lines.

## Real-World Context and Agricultural Impact
Crop genetics and market demands evolve rapidly. Seed packaging enterprises that maintain modular, automated retraining pipelines can introduce new regional hybrids to their optical sorting machines in hours, rather than waiting months for hardware vendors to deliver expensive proprietary updates.

## Summary
- Agricultural models experience covariate drift (seasonal weather) and concept drift (equipment or harvest changes).
- Adding new cultivars is seamlessly supported by `main.py` due to generic dynamic class extraction.
- Retraining updates all production artifacts: `rules.txt`, `pumpkin_tree.png`, and `confusion_matrix.png`.
- Automated pipelines empower growers to rapidly adapt to evolving agricultural markets.

## Knowledge-check Questions
1. What is concept drift in an agricultural seed sorting context? (Answer: Changes in physical seed morphology or environmental conditions over time that degrade model accuracy).
2. Why does `main.py` use `list(model.classes_)` and `sorted(df["variety"].unique())` instead of hardcoded lists? (Answer: To dynamically handle any number of cultivars without requiring code modifications when retraining).
3. If a 4th cultivar is added, what minimum theoretical tree depth is required to separate 4 classes? (Answer: Depth 2, since 2^2 = 4 leaf nodes).

## References
- Gama, J., et al. (2014). A survey on concept drift adaptation. ACM Computing Surveys, 46(4), 1-37.
- scikit-learn model persistence: https://scikit-learn.org/stable/modules/model_persistence.html
