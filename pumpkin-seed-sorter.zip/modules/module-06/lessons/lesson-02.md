# Lesson 02: Real-World Optical & Conveyor Sorting Integration

**Lesson ID:** lesson-02  
**Module:** module-06  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Describe the hardware components of an industrial high-speed optical seed sorter.
- Explain the physical data collection pipeline from vibrating feeder to line-scan camera.
- Calculate the latency budget required for real-time decision tree inference on a conveyor belt.
- Design the physical pneumatic ejection mechanism that diverts pumpkin seeds into 3 cultivar chutes.

## Prerequisites
Completion of Module 04 (inference on novel seeds) and Lesson 01.

## Concept Explanation
In software, we execute `model.predict(new_seed)` on a stationary laptop. In an industrial agricultural packaging facility, this decision tree executes inside an embedded computer controlling a high-speed optical sorter handling up to **100 seeds per second**!

Let us trace the physical journey of a pumpkin seed through an optical sorting machine:

```
[Hopper] ──► [Vibrating Feeder] ──► [High-Speed Chute / Belt (3 m/s)]
                                              │
                                     [Optical Inspection Zone]
                                     ├─ High-Intensity LED Arrays
                                     └─ High-Speed Line-Scan Camera (20 kHz)
                                              │
                                     [Edge AI Microcontroller / IPC]
                                     ├─ Image Segmentation & Contour Extraction
                                     ├─ Calculate: area, major_axis, minor_axis
                                     └─ Decision Tree Evaluation (< 0.1 ms)
                                              │
                                     [Pneumatic Ejector Manifold]
                                     ├─ Chute 1: Cercevelik (Gravity default)
                                     ├─ Chute 2: Karacabey (Nozzle Bank A fired)
                                     └─ Chute 3: Urgup_Sivrisi (Nozzle Bank B fired)
```

1. **Feeding & Singulation**:
   Raw harvested pumpkin seeds enter an intake hopper. A vibrating electromagnetic feeder spreads the seeds into a single monolayer so they do not overlap.

2. **Optical Imaging & Feature Extraction**:
   Seeds slide down an inclined ceramic chute or high-speed conveyor belt travelling at $3.0\,\text{m/s}$. As each seed passes through the optical inspection zone, backlit high-intensity LED strobe lights illuminate the seed against a contrasting background. A linear CMOS line-scan camera operating at $20\,\text{kHz}$ captures the seed silhouette.
   An FPGA or embedded microprocessor performs connected-component analysis in OpenCV to extract the seed contour and compute:
   - `area` (pixel count converted to $\text{mm}^2$)
   - `major_axis` and `minor_axis` (fitted ellipse axes)

3. **Inference & Latency Budget**:
   The computed features are passed to our decision tree. Because our tree has a depth of only 2, computing the classification requires at most **two boolean comparisons**:
   - Comparison 1: `minor_axis <= 6.04`
   - Comparison 2: `area <= 1019.50` (if left) OR `major_axis <= 12.58` (if right)
   In compiled C or Python, these two comparisons execute in less than **1 microsecond** ($0.001\,\text{ms}$), well within any industrial latency requirement!

4. **Pneumatic Rejection**:
   Downstream from the camera (typically $150\,\text{mm}$ further along the trajectory), high-speed pneumatic solenoid valves are mounted above collection chutes.
   - If the seed is `Cercevelik`, it falls cleanly into the primary collection hopper.
   - If the seed is `Karacabey`, valve bank A fires an ultra-short blast of compressed air ($5\,\text{ms}$ pulse at $6\,\text{bar}$ pressure), deflecting the seed into Bin 2.
   - If the seed is `Urgup_Sivrisi`, valve bank B fires, deflecting the seed into Bin 3.

## Relevant Code (from main.py, lines 59-63)
```python
new_seed = pd.DataFrame(
    [{"area": 1180, "perimeter": 55.0, "major_axis": 12.2, "minor_axis": 5.7, "eccentricity": 0.86}]
)
new_variety = model.predict(new_seed)[0]
print(f"New seed -> {new_variety}")
```

## Code Deep-Dive Breakdown
- In production, instead of constructing a single-row pandas DataFrame for every seed (which incurs Python object overhead), industrial sorting engines export the learned tree thresholds directly into low-level C code or Cython:
  ```c
  const char* classify_seed(float area, float major_axis, float minor_axis) {
      if (minor_axis <= 6.04f) {
          if (area <= 1019.50f) return "Karacabey";
          else return "Urgup_Sivrisi";
      } else {
          if (major_axis <= 12.58f) return "Urgup_Sivrisi";
          else return "Cercevelik";
      }
  }
  ```
- This C function executes in less than 5 nanoseconds, enabling sorting speeds exceeding **50,000 seeds per minute** across multi-channel industrial chutes!

## Worked Example
Let us compute the exact firing delay required for a pneumatic solenoid:
- Distance from camera focal plane to ejector nozzle: $d = 150\,\text{mm} = 0.15\,\text{m}$.
- Belt velocity: $v = 3.0\,\text{m/s}$.
- Travel time from camera to nozzle:
  $$t_{\text{travel}} = \frac{d}{v} = \frac{0.15\,\text{m}}{3.0\,\text{m/s}} = 0.050\,\text{s} = 50\,\text{ms}$$
- If feature extraction and tree inference take $2\,\text{ms}$, the controller sets an electronic timer to trigger the air solenoid valve exactly:
  $$t_{\text{fire}} = 50\,\text{ms} - 2\,\text{ms} = 48\,\text{ms}$$
after the camera detects the seed!

## Step-by-Step Student Instructions
1. Open Python interactive terminal: `python`.
2. Write a pure-Python compiled function representing our tree rules:
   ```python
   def fast_classify(area, major, minor):
       if minor <= 6.04:
           return "Karacabey" if area <= 1019.50 else "Urgup_Sivrisi"
       else:
           return "Cercevelik" if major > 12.58 else "Urgup_Sivrisi"
   ```
3. Test the function on our canonical seed:
   ```python
   print(fast_classify(1180, 12.2, 5.7))
   ```
4. Benchmark execution speed across 1,000,000 iterations using the `timeit` module:
   ```python
   import timeit
   elapsed = timeit.timeit("fast_classify(1180, 12.2, 5.7)", globals=globals(), number=1_000_000)
   print(f"Time per decision: {elapsed / 1_000_000 * 1e6:.2f} microseconds")
   ```

## Expected Output or Observable Behaviour
```text
Urgup_Sivrisi
Time per decision: 0.12 microseconds
```
The decision rule executes in a fraction of a microsecond, demonstrating why decision trees are the gold standard for high-speed industrial robotics.

## Practical Exercises
1. Calculate the travel time if conveyor belt speed is increased to $4.5\,\text{m/s}$ while keeping distance at $150\,\text{mm}$.
2. If an optical sorting machine processes 20 parallel chutes simultaneously at 50 seeds per second per chute, calculate total throughput in seeds per hour.
3. Explain why deep neural networks (like CNNs running on GPUs) might be harder to deploy in high-speed pneumatic sorting compared to decision trees.

## Common Mistakes and Debugging
- **DataFrame construction latency in real-time loops**: Calling `pd.DataFrame([row])` in a loop running at 100 Hz causes massive CPU thrashing and garbage collection spikes. In production, pass raw NumPy arrays or C structs.
- **Ignoring belt slip and air resistance**: Seeds do not always travel at perfect constant velocity; vibration and rolling create minor timing jitters. Pneumatic air pulses must be wide enough ($5-10\,\text{ms}$) to engulf the target seed safely.

## Best Practices and Security Considerations
- Isolate the sorting machine's Industrial PC (IPC) on an internal OT (Operational Technology) network with no direct internet access to protect against industrial malware.
- Implement optical self-cleaning air wipers to keep dust from coating the camera lens during continuous operation.

## Real-World Context and Agricultural Impact
Industrial optical sorters from manufacturers such as Bühler, Tomra, and Satake process millions of tons of grains, nuts, and seeds annually. By automating cultivar sorting, processors upgrade bulk harvest commodities into premium export-grade seeds, increasing farmgate profitability by 30% to 50%.

## Summary
- Optical seed sorters integrate vibrating feeders, line-scan cameras, edge controllers, and pneumatic air valves.
- Decision trees evaluate in sub-microsecond timescales, easily meeting 100 seeds/second sorting budgets.
- Pneumatic valve timing depends on conveyor speed and physical distance from camera to nozzles.
- Compiling decision tree thresholds to C or Cython avoids high-level runtime overhead.

## Knowledge-check Questions
1. Why are decision trees ideal for embedded sorting systems compared to deep convolutional neural networks? (Answer: Because decision trees evaluate in sub-microsecond time with trivial CPU requirements and zero GPU power draw).
2. What physical actuator is commonly used to deflect seeds into different collection bins? (Answer: High-speed pneumatic air ejector nozzles).
3. If a seed travels at 3 m/s over a 150 mm distance, how much time elapses between image capture and pneumatic ejection? (Answer: 50 milliseconds).

## References
- Satake Optical Sorting Technology Overview: https://www.satake-group.com
- Tomra Food Optical Sorters: https://www.tomra.com/en/food
