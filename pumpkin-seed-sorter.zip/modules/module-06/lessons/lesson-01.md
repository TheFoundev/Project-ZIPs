# Lesson 01: Persisting Rules and Audit Logs (rules.txt)

**Lesson ID:** lesson-01  
**Module:** module-06  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain why text-based audit trails are legally and operationally critical in food processing.
- Analyze the structure and content written to `outputs/rules.txt`.
- Implement automated file persistence combining training comparisons, rules, inference, and classification metrics.
- Contrast human-readable text logs with binary model serialization formats (such as pickle and ONNX).

## Prerequisites
Completion of Modules 04 and 05; understanding of basic Python file context managers (`with open(...)`).

## Concept Explanation
In modern industrial automation, deploying a machine learning model is not just about computing predictions in memory; it requires continuous traceability and compliance auditing. In agricultural seed production, seed lots must comply with strict national and international seed certification standards (such as the Federal Seed Act in the United States and ISTA standards internationally).

If a commercial grain elevator sorts 50 metric tons of pumpkin seeds, agricultural inspectors need to know:
1. What exact decision thresholds were active during processing?
2. What accuracy benchmark did the model achieve on benchmark validation data?
3. What were the specific per-cultivar purity and recovery levels?

To provide this traceability without requiring proprietary desktop software, `main.py` generates `outputs/rules.txt`. This single human-readable text document records:
- The depth comparison benchmarks (depth 2 vs depth 4 vs unlimited).
- The selected best model depth.
- The full plain-text boolean decision logic exported by `export_text`.
- The sample inference verification for the reference seed.
- The complete multi-class `classification_report`.

Because it is plain UTF-8 text, `rules.txt` can be archived into enterprise databases, emailed to compliance auditors, or displayed directly on simple monochrome industrial operator terminals on the processing plant floor.

## Relevant Code (from main.py, lines 91-98)
```python
with open(OUT / "rules.txt", "w", encoding="utf-8") as handle:
    for depth, (_, _, acc) in models.items():
        handle.write(f"depth={depth}: accuracy={acc:.4f}\n")
    handle.write(f"\nbest depth: {best_depth}\n\n")
    handle.write(export_text(model, feature_names=FEATURES))
    handle.write(f"\nnew seed prediction: {new_variety}\n")
    handle.write("\n" + classification_report(y_test, predictions, zero_division=0))
```

## Code Deep-Dive Breakdown
- `with open(OUT / "rules.txt", "w", encoding="utf-8") as handle:`:
  - Uses Python's context manager to guarantee proper file handle closure even if exceptions occur during writing.
  - Explicitly specifies `encoding="utf-8"` to prevent platform-dependent encoding mismatches across Windows, Linux, and embedded microcontrollers.
- `for depth, (_, _, acc) in models.items():`: Iterates through the stored model configurations, writing formatted floating-point accuracies (`{acc:.4f}`) to four decimal places.
- `handle.write(export_text(model, feature_names=FEATURES))`: Writes the full ASCII decision hierarchy directly into the audit trail.
- `handle.write(f"\nnew seed prediction: {new_variety}\n")`: Documents that the canonical verification seed was evaluated and yielded `Urgup_Sivrisi`.
- `handle.write("\n" + classification_report(y_test, predictions, zero_division=0))`: Appends the full tabular evaluation matrix for per-variety inspection.

## Worked Example
Let us examine the exact generated content of `outputs/rules.txt`:
```text
depth=2: accuracy=0.8667
depth=4: accuracy=0.8444
depth=None: accuracy=0.8444

best depth: 2

|--- minor_axis <= 6.04
|   |--- area <= 1019.50
|   |   |--- class: Karacabey
|   |--- area >  1019.50
|   |   |--- class: Urgup_Sivrisi
|--- minor_axis >  6.04
|   |--- major_axis <= 12.58
|   |   |--- class: Urgup_Sivrisi
|   |--- major_axis >  12.58
|   |   |--- class: Cercevelik

new seed prediction: Urgup_Sivrisi

               precision    recall  f1-score   support

   Cercevelik       1.00      0.80      0.89        15
    Karacabey       1.00      0.80      0.89        15
Urgup_Sivrisi       0.71      1.00      0.83        15

     accuracy                           0.87        45
    macro avg       0.90      0.87      0.87        45
 weighted avg       0.90      0.87      0.87        45
```
An agricultural technician can review this single document in under 60 seconds and certify that the sorting batch meets production specifications.

## Step-by-Step Student Instructions
1. Run the sorting script:
   `python main.py`
2. Display the contents of `rules.txt` using your terminal pager:
   `cat outputs/rules.txt`
3. Verify that all 5 sections are present: depth comparisons, best depth, decision rules, sample inference, and classification report.
4. Check the file size and permissions:
   `ls -lh outputs/rules.txt`

## Expected Output or Observable Behaviour
A UTF-8 text file `outputs/rules.txt` approximately 850–950 bytes in size containing clean ASCII indentation and tabular metrics without errors or missing headers.

## Practical Exercises
1. Modify `main.py` to prepend an ISO-8601 UTC timestamp and the current git commit hash (or script version string `"v1.0.0"`) to the very top of `outputs/rules.txt`.
2. Add a line to `rules.txt` recording the total number of training and test samples used during model training.
3. Write a small Python script that parses `outputs/rules.txt`, extracts the accuracy for `depth=2`, and raises an error if it falls below 0.85.

## Common Mistakes and Debugging
- **Omitting `encoding="utf-8"`**: On default Windows environments, omitting the encoding argument defaults to `cp1252`, which can corrupt non-ASCII characters or break cross-platform log ingestion tools.
- **Overwriting without timestamps in continuous deployment**: In real production environments, overwriting `rules.txt` on every run erases historical records. A common industry enhancement is appending the lot number or timestamp: `rules_LOT_20261027_01.txt`.

## Best Practices and Security Considerations
- Keep audit logs immutable once written; apply filesystem permissions (`chmod 444`) or send cryptographic SHA-256 hashes of `rules.txt` to an immutable ledger or central logging service.
- Never write raw credentials, database connection strings, or internal network IPs into audit log files.

## Real-World Context and Agricultural Impact
In certified organic seed elevators, food regulatory inspectors conduct unannounced audits. Having deterministic, human-readable text logs like `rules.txt` allows immediate verification that no undocumented software alterations or untested models were deployed to sorting machinery.

## Summary
- `outputs/rules.txt` consolidates tree comparison benchmarks, best depth, decision rules, test inference, and classification metrics.
- Plain UTF-8 text guarantees readability across embedded hardware, cloud servers, and human audits.
- Python context managers (`with open(...)`) ensure safe file closure even during runtime errors.

## Knowledge-check Questions
1. What sections are consolidated into `outputs/rules.txt` by `main.py`? (Answer: Depth accuracies, best depth, plain-text rules, sample prediction, and classification report).
2. Why is UTF-8 explicitly specified when opening `rules.txt`? (Answer: To guarantee cross-platform encoding compatibility across Windows, Linux, and embedded microcontrollers).
3. How does plain-text rule logging benefit agricultural quality compliance? (Answer: It provides a transparent, human-auditable record of exact sorting cutoffs that can be inspected without specialized machine learning software).

## References
- Python Context Managers: https://docs.python.org/3/reference/datamodel.html#context-managers
- ISO 22000 Food Safety Management Systems: https://www.iso.org/iso-22000-food-safety-management.html
