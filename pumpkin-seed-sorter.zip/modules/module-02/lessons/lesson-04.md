# Lesson 04: Preparing Features and Target (X and y) with Stratified Splitting

**Lesson ID:** lesson-04  
**Module:** module-02  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Construct the 2D feature matrix `X` and 1D target vector `y` from a DataFrame.
- Explain the importance of `train_test_split` in evaluating model generalization.
- Understand the role of `test_size=0.25` and `random_state=42`.
- Explain how `stratify=y` preserves class proportions across training and test partitions.

## Prerequisites
- Lesson 03: Variety Distribution and Class Balance in Agricultural Datasets.
- Familiarity with the `sklearn.model_selection` module.

## Concept Explanation

### The Supervised Data Matrix Split
In scikit-learn, supervised classification requires separating tabular data into two distinct structures:
1. **Feature Matrix ($X$)**: A two-dimensional array or DataFrame of shape `(n_samples, n_features)` containing numeric predictor variables.
2. **Target Vector ($y$)**: A one-dimensional array or Series of shape `(n_samples,)` containing the ground-truth class labels.

In our project:
```python
X = df[FEATURES]    # Shape: (180, 5)
y = df["variety"]   # Shape: (180,)
```

### Why We Split Data
If a model is trained and evaluated on the exact same data points, it could simply memorize individual seeds (overfitting), achieving 100% training accuracy while failing completely on new seeds from tomorrow's harvest. 

To obtain an honest, unbiased assessment of model generalization, we divide the data into:
- **Training Set**: Used exclusively by `model.fit()` to learn geometric rules.
- **Testing Set**: Held out completely during training, used exclusively to evaluate predictive accuracy.

### The Critical Role of Stratification (`stratify=y`)
Consider what happens during standard random splitting on small datasets. With 180 seeds and a 25% test split (45 test seeds):
- **Without Stratification**: A pure random draw could accidentally place 25 Cercevelik seeds in the test set, but only 8 Karacabey seeds and 12 Urgup_Sivrisi seeds! The test set would become severely imbalanced, distorting performance metrics.
- **With Stratification (`stratify=y`)**: The splitting algorithm enforces the exact original $1:1:1$ ratio within both the training and test subsets:
  - Training Set (75% of 180 = 135 seeds): Exactly 45 Cercevelik, 45 Karacabey, 45 Urgup_Sivrisi.
  - Testing Set (25% of 180 = 45 seeds): Exactly 15 Cercevelik, 15 Karacabey, 15 Urgup_Sivrisi.

```
Total: 180 seeds (60 per variety)
         │
         ├─── train_test_split(test_size=0.25, stratify=y)
         │
         ├──► Training Set (135 seeds):  45 Cercevelik, 45 Karacabey, 45 Urgup_Sivrisi
         │
         └──► Testing Set (45 seeds):   15 Cercevelik, 15 Karacabey, 15 Urgup_Sivrisi
```

## Relevant Code (from main.py, lines 31-36)
```python
    X = df[FEATURES]
    y = df["variety"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
```

## Code Deep-Dive Breakdown
- `test_size=0.25`: Allocates 25% of the data (45 rows) to testing and the remaining 75% (135 rows) to training.
- `random_state=42`: Fixes the pseudo-random number generator seed. This ensures that every student, researcher, or automated test script generates the exact same train-test partition.
- `stratify=y`: Directs `train_test_split` to sample proportionally from each cultivar group defined in `y`.

## Worked Example
Let us verify the shapes and class distributions of the split subsets in Python:

```python
import pandas as pd
from sklearn.model_selection import train_test_split

df = pd.read_csv("data/pumpkin_seeds.csv")
FEATURES = ["area", "perimeter", "major_axis", "minor_axis", "eccentricity"]
X = df[FEATURES]
y = df["variety"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

print(f"X_train shape: {X_train.shape}")
print(f"X_test shape:  {X_test.shape}")
print("
Test Set Variety Distribution:")
print(y_test.value_counts())
```

**Output**:
```
X_train shape: (135, 5)
X_test shape:  (45, 5)

Test Set Variety Distribution:
variety
Urgup_Sivrisi    15
Karacabey        15
Cercevelik       15
Name: count, dtype: int64
```
Because of `stratify=y`, the test set contains exactly 15 samples of each variety!

## Step-by-Step Student Instructions
1. Inspect lines 31-36 of `main.py`.
2. Verify that `FEATURES` contains all 5 geometric columns.
3. Run the code snippet above to inspect `X_train.shape` and `X_test.shape`.
4. Check `y_test.value_counts()` and confirm that each variety has exactly 15 test samples.
5. Try removing `stratify=y` temporarily to observe how the class distribution fluctuates without stratification.

## Expected Output or Observable Behaviour
`X_train` has shape `(135, 5)`, `X_test` has shape `(45, 5)`, `y_train` has 135 labels (45 per class), and `y_test` has 45 labels (15 per class).

## Practical Exercises
- **Exercise 2.4a**: What would be the sizes of the training and test sets if `test_size=0.20` was used on this 180-sample dataset?
- **Exercise 2.4b**: Why is `random_state=42` crucial when writing automated tests for machine learning pipelines?

## Common Mistakes and Debugging
| Mistake | Root Cause | Remediation |
|---|---|---|
| Omitting `stratify=y` | Forgetting to preserve class proportions | Always include `stratify=y` in classification tasks to prevent sampling bias |
| Unpacking split variables in wrong order | Writing `X_train, y_train, X_test, y_test` | The function returns `X_train, X_test, y_train, y_test`; reversing them causes shape mismatch errors |
| Passing 1D Series for X | Writing `X = df['area']` | `X` must be a 2D structure with double brackets `df[['area']]` or list of features `df[FEATURES]` |

## Best Practices and Security Considerations
- **Data Leakage Prevention**: Never fit preprocessing transformers (like scalers or encoders) on the full dataset before splitting. Always fit on `X_train` and transform `X_test`.
- **Reproducibility Standard**: In production agricultural audits, record the exact `random_state` and software library versions in compliance documentation.

## Real-World Context and Agricultural Impact
In certified seed laboratories, validation test sets must reflect the true distribution of incoming seed lots. Using stratified sampling ensures that evaluation metrics accurately reflect the machine's performance across all seed varieties equally.

## Summary
The Pumpkin Seed Sorter partitions data into a feature matrix `X` of shape `(180, 5)` and target vector `y` of length 180. Using `train_test_split` with `test_size=0.25`, `random_state=42`, and `stratify=y` produces an unbiased training set of 135 seeds (45 per variety) and a testing set of 45 seeds (15 per variety).

## Knowledge-check Questions
1. What are the dimensions of `X_train` and `X_test` after splitting?
2. What does `stratify=y` guarantee about the test set?
3. How many test samples are allocated to each cultivar?
4. What error occurs if `train_test_split` outputs are unpacked in the wrong order?

## References
- scikit-learn `train_test_split` Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html
- Cross-Validation and Data Partitioning Guide: https://scikit-learn.org/stable/modules/cross_validation.html
- Project Source Code: `main.py` lines 31-36.
