# Lesson 02: Geometric & Morphological Features Explained (Area, Perimeter, Axes, Eccentricity)

**Lesson ID:** lesson-02  
**Module:** module-02  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain the physical and geometric significance of each feature in `FEATURES`.
- Understand the mathematical formula for ellipse eccentricity.
- Calculate and interpret descriptive statistics (mean, min, max, standard deviation) for each feature.
- Explain how morphological feature correlations help differentiate cultivars.

## Prerequisites
- Lesson 01: Inspecting and Loading the Pumpkin Seed Dataset.
- Basic familiarity with summary statistics (mean, range, quartiles).

## Concept Explanation

### The Geometry of Seed Morphology
When botanists and computer vision engineers evaluate seeds, they treat the 2D silhouette as a planar geometric figure. Let us analyze the five features defined in `FEATURES`:

```
                 Major Axis (2a)
             ◄──────────────────────►
         ╭──────────────────────────────╮  ▲
         │                              │  │ Minor Axis (2b)
         │           Contour            │  │
         │           Perimeter (P)      │  │
         │           Area (A)           │  │
         ╰──────────────────────────────╯  ▼
```

1. **Area ($A$)**:
   - Represents the total 2D planar projection of the seed hull.
   - Larger varieties like Cercevelik have substantial meat and large hulls, resulting in high area values ($1300 - 1600$).
   - Smaller varieties like Karacabey have compact, small hulls ($800 - 1050$).

2. **Perimeter ($P$)**:
   - The circumference or perimeter length along the outer contour boundary.
   - Highly correlated with area, but also sensitive to edge roughness or elongation.

3. **Major Axis Length ($2a$)**:
   - The length of the longest chord of the fitted ellipse passing through the center.
   - Measures seed length from tip to base.

4. **Minor Axis Length ($2b$)**:
   - The length of the shortest chord perpendicular to the major axis.
   - Measures seed width across its belly. Cercevelik seeds are wide (> 6.0 mm), while Karacabey seeds are narrow (< 5.5 mm).

5. **Eccentricity ($e$)**:
   - Quantifies the degree of flattening or elongation:
     $$e = \sqrt{1 - \left(\frac{b}{a}\right)^2} = \sqrt{1 - \left(\frac{\text{minor\_axis}}{\text{major\_axis}}\right)^2}$$
   - If a seed were perfectly circular ($a = b$), $\frac{b}{a} = 1$, giving $e = \sqrt{1 - 1} = 0$.
   - If a seed is very slender and pointed (such as Urgup_Sivrisi, where $a \gg b$), $\frac{b}{a}$ is small, making $e$ close to $1.0$ (typically $0.85 - 0.94$).

### Descriptive Statistics of the Dataset
Examining `df[FEATURES].describe()` reveals key baseline parameters:

| Feature | Mean | Std Dev | Min | 25% | 50% (Median) | 75% | Max |
|---|---|---|---|---|---|---|---|
| **area** | 1266.9 | 243.6 | 854.0 | 1102.5 | 1208.5 | 1513.5 | 1680.0 |
| **perimeter** | 58.2 | 7.1 | 44.9 | 52.8 | 56.4 | 64.6 | 72.1 |
| **major_axis** | 12.5 | 1.4 | 10.1 | 11.5 | 12.2 | 13.6 | 15.5 |
| **minor_axis** | 5.8 | 0.6 | 4.6 | 5.3 | 5.7 | 6.4 | 7.1 |
| **eccentricity**| 0.864 | 0.043 | 0.771 | 0.829 | 0.866 | 0.901 | 0.942 |

Notice that the median `minor_axis` is $5.7$, which is very close to the decision tree's optimal root split threshold ($6.04$)!

## Relevant Code (from main.py, lines 26, 31)
```python
FEATURES = ["area", "perimeter", "major_axis", "minor_axis", "eccentricity"]

def main() -> None:
    df = pd.read_csv(DATA / "pumpkin_seeds.csv")
    X = df[FEATURES]
```

## Code Deep-Dive Breakdown
- `FEATURES` is a list defining the feature subspace.
- `X = df[FEATURES]` selects only these 5 numeric columns, creating the 2D feature matrix required by scikit-learn.
- Notice that the column `variety` is omitted from `FEATURES` because `variety` is the target output ($y$), not an input feature.

## Worked Example
Let us compute the theoretical eccentricity for a seed with:
- $\text{major\_axis} = 14.0$ mm ($a = 7.0$ mm)
- $\text{minor\_axis} = 6.0$ mm ($b = 3.0$ mm)

**Step 1**: Compute the ratio $\frac{b}{a}$:
$$\frac{b}{a} = \frac{3.0}{7.0} \approx 0.4286$$

**Step 2**: Square the ratio:
$$\left(\frac{b}{a}\right)^2 = (0.4286)^2 \approx 0.1837$$

**Step 3**: Calculate eccentricity:
$$e = \sqrt{1 - 0.1837} = \sqrt{0.8163} \approx 0.9035$$

An eccentricity of $0.9035$ indicates a distinctly elongated seed silhouette, characteristic of Urgup_Sivrisi or Cercevelik.

## Step-by-Step Student Instructions
1. In your Python environment, load the dataset:
   ```python
   import pandas as pd
   df = pd.read_csv("data/pumpkin_seeds.csv")
   ```
2. Print summary statistics using `df.describe().round(2)`.
3. Check the minimum and maximum values of `area`: observe that area ranges from 854 to 1680.
4. Verify that `eccentricity` values all lie between 0.77 and 0.95.

## Expected Output or Observable Behaviour
Calling `df[FEATURES].describe()` prints a clean summary table showing count=180 for all columns, with realistic biological variations across the five dimensions.

## Practical Exercises
- **Exercise 2.2a**: Write a Python function `calc_eccentricity(major, minor)` that implements the mathematical formula above and verify it on `major=12.2, minor=5.7`.
- **Exercise 2.2b**: Calculate the correlation between `area` and `perimeter` using `df[["area", "perimeter"]].corr()`. What does the high correlation imply?

## Common Mistakes and Debugging
| Mistake | Root Cause | Remediation |
|---|---|---|
| Inverting major and minor axis in eccentricity formula | Dividing major by minor instead of minor by major | Major axis is longer ($a > b$), so $b/a < 1$; dividing $a/b$ results in square root of negative numbers |
| Including target in features | Writing `FEATURES = list(df.columns)` | `variety` must be separated as target $y$; including it in $X$ results in 100% trivial cheating |

## Best Practices and Security Considerations
- **Mathematical Bound Checks**: Always assert that $0 \le \text{eccentricity} < 1$ on incoming sensor streams to catch optical distortion or invalid boundary contours.
- **Physical Plausibility**: Assert that $\text{minor\_axis} \le \text{major\_axis}$. Any measurement where minor axis exceeds major axis indicates a segmentation error.

## Real-World Context and Agricultural Impact
Plant phenotyping platforms rely on automated morphology extraction to evaluate new crop hybrids. Measuring eccentricity and axis dimensions allows plant breeders to quantify grain fullness and seed maturity without destroying the seed embryos.

## Summary
The five features in `FEATURES` represent intuitive geometric properties of seed silhouettes: area (2D surface), perimeter (boundary length), major axis (length), minor axis (width), and eccentricity (elongation). Descriptive statistics show clear variation across the 180 samples, with area ranging from 854 to 1680 and eccentricity ranging from 0.77 to 0.94.

## Knowledge-check Questions
1. What does an eccentricity value close to 1 indicate about a seed's shape?
2. What are the units of area versus perimeter?
3. Which feature measures the widest point across the seed's belly?
4. Why is the `variety` column excluded from `FEATURES`?

## References
- Image Processing, Analysis, and Machine Vision: Sonka, Hlavac, Boyle.
- scikit-learn Input Data Shapes: https://scikit-learn.org/stable/glossary.html#term-2d-array
- Project Source Code: `main.py` lines 26-31.
