# Lesson 01: Inspecting and Loading the Pumpkin Seed Dataset

**Lesson ID:** lesson-01  
**Module:** module-02  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Locate and load `data/pumpkin_seeds.csv` using `pathlib` and `pandas`.
- Inspect dataset dimensions, column names, and data types.
- Check for missing values and data integrity issues.
- Understand how image processing pipelines generate tabular morphological datasets.

## Prerequisites
- Module 01: Project Overview.
- Basic understanding of CSV files and pandas DataFrames.

## Concept Explanation

### From Physical Seeds to Tabular Data
How does a physical pumpkin seed turn into a row of CSV numbers? In modern agricultural imaging laboratories, high-resolution flatbed scanners or industrial line-scan cameras photograph seed lots under controlled, shadow-free backlighting. Computer vision algorithms (such as threshold segmentation and contour extraction) process each seed silhouette:
1. The seed boundary is detected as an isolated polygon contour.
2. Moments of the polygon are computed to determine the center of mass.
3. An equivalent bounding ellipse is fitted to the contour.
4. Mathematical geometric properties (area, perimeter, axis lengths, eccentricity) are extracted.
5. The sample is labeled with its certified botanical cultivar.

The result is saved in tabular comma-separated values (CSV) format. In this project, the dataset resides at `data/pumpkin_seeds.csv`.

### Inspecting the File Structure
Before training machine learning models, you must always inspect your data file to verify:
- **Header Structure**: What are the exact column names?
- **Row Count**: How many observations exist?
- **Missing Data**: Are there null values or corrupted rows?
- **Data Types**: Are numeric measurements parsed as floats/integers rather than strings?

Opening `data/pumpkin_seeds.csv` reveals 180 data rows and 6 columns:
- `variety`: String name of cultivar (`Urgup_Sivrisi`, `Karacabey`, `Cercevelik`)
- `area`: Integer representing silhouette pixel area (ranging from ~800 to ~1600)
- `perimeter`: Floating-point boundary contour length (ranging from ~44 to ~69 mm)
- `major_axis`: Longest diameter (ranging from ~10 to ~16 mm)
- `minor_axis`: Shortest diameter (ranging from ~4.5 to ~7.0 mm)
- `eccentricity`: Dimensionless elongation index (ranging from ~0.75 to ~0.95)

## Relevant Code (from main.py, lines 21-22, 30)
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"

def main() -> None:
    df = pd.read_csv(DATA / "pumpkin_seeds.csv")
```

## Code Deep-Dive Breakdown
- `BASE = Path(__file__).resolve().parent`: Obtains the absolute directory containing `main.py`, guaranteeing that path resolution works regardless of where the script is invoked from.
- `DATA = BASE / "data"`: Uses `pathlib`'s division operator `/` to construct the platform-agnostic subpath `.../data`.
- `pd.read_csv(DATA / "pumpkin_seeds.csv")`: Reads the CSV into a pandas `DataFrame` object named `df`.

## Worked Example
Let us load the dataset in an interactive Python session and run basic diagnostics:

```python
import pandas as pd
from pathlib import Path

DATA = Path("data")
df = pd.read_csv(DATA / "pumpkin_seeds.csv")

print("Dataset Shape:", df.shape)
print("
Column Information:")
print(df.info())
print("
Missing Values Count:")
print(df.isnull().sum())
```

**Output**:
```
Dataset Shape: (180, 6)

Column Information:
 #   Column        Non-Null Count  Dtype  
---  ------        --------------  -----  
 0   variety       180 non-null    object 
 1   area          180 non-null    int64  
 2   perimeter     180 non-null    float64
 3   major_axis    180 non-null    float64
 4   minor_axis    180 non-null    float64
 5   eccentricity  180 non-null    float64

Missing Values Count:
variety         0
area            0
perimeter       0
major_axis      0
minor_axis      0
eccentricity    0
dtype: int64
```
This confirms that the dataset contains 180 complete rows, exactly 0 missing values, and clean numeric types.

## Step-by-Step Student Instructions
1. Open a terminal and navigate to the project directory.
2. View the first 5 rows of the raw CSV file using `head -n 5 data/pumpkin_seeds.csv`.
3. Launch Python and run `import pandas as pd; df = pd.read_csv("data/pumpkin_seeds.csv")`.
4. Run `df.shape` and verify that the output is `(180, 6)`.
5. Run `df.dtypes` to confirm that `variety` is `object` (string) and the remaining five columns are numeric.

## Expected Output or Observable Behaviour
When loading the dataset, no warnings or parsing errors should occur. The DataFrame contains 180 rows, where each row represents one physically scanned pumpkin seed.

## Practical Exercises
- **Exercise 2.1a**: What command in pandas displays the first 10 rows of a DataFrame?
- **Exercise 2.1b**: What would happen if `pumpkin_seeds.csv` were moved to an outer folder? How does `pathlib` help locate it?

## Common Mistakes and Debugging
| Mistake | Root Cause | Remediation |
|---|---|---|
| `FileNotFoundError` | Running python from a different working directory without resolving paths | Always use `Path(__file__).resolve().parent` to anchor paths to the script location |
| Column names misspelled | Looking for `minoraxis` without underscore | The exact column name in CSV is `minor_axis`; always check `df.columns` |

## Best Practices and Security Considerations
- **Path Portability**: Never hardcode Windows-style backslashes (`data\seeds.csv`) or Linux slashes (`data/seeds.csv`) as string concatenations; use `pathlib.Path`.
- **Integrity Validation**: Always check `df.isnull().sum()` prior to feeding data into scikit-learn models, as missing values will raise an immediate `ValueError`.

## Real-World Context and Agricultural Impact
In agricultural research labs, image acquisition stations automatically output CSV logs after scanning sample batches. Standardizing column names and validating data shapes ensures that machine learning training pipelines run automatically without human intervention.

## Summary
The dataset `pumpkin_seeds.csv` contains 180 observations and 6 columns. Five columns represent morphological dimensions (area, perimeter, major axis, minor axis, eccentricity), and one column represents the cultivar variety. The dataset has no missing values and is loaded cleanly using `pathlib` and `pandas.read_csv`.

## Knowledge-check Questions
1. How many total seed samples are present in `pumpkin_seeds.csv`?
2. What are the names of the 6 columns in the CSV?
3. Which library is used to handle file paths in `main.py`?
4. Are there any missing or null values in this dataset?

## References
- pandas `read_csv` Reference: https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html
- Python `pathlib` Module Documentation: https://docs.python.org/3/library/pathlib.html
- Project Source Code: `main.py` lines 21-30.
