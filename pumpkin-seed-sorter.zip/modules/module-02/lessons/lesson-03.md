# Lesson 03: Variety Distribution and Class Balance in Agricultural Datasets

**Lesson ID:** lesson-03  
**Module:** module-02  
**Duration:** 15 minutes  

## Purpose and Learning Objectives
By the end of this lesson, you will be able to:
- Explain the concept of class balance in classification datasets.
- Verify the class distribution of `pumpkin_seeds.csv` using pandas.
- Understand the risks of class imbalance in automated inspection systems.
- Explain baseline accuracy and the zero-rule classifier for balanced vs imbalanced datasets.

## Prerequisites
- Lesson 02: Geometric & Morphological Features Explained.
- Basic understanding of class frequencies and probability.

## Concept Explanation

### What is Class Balance?
In machine learning, **class balance** describes the distribution of target categories across dataset samples. A dataset is:
- **Balanced**: When all classes have approximately equal representation.
- **Imbalanced**: When one or more classes significantly outnumber others (e.g., 95% Class A and 5% Class B).

In our pumpkin seed dataset:
```python
df["variety"].value_counts()
```
Produces:
```
Urgup_Sivrisi    60
Karacabey        60
Cercevelik       60
Name: count, dtype: int64
```
Each cultivar has exactly 60 samples. The dataset is **perfectly balanced** ($1:1:1$ ratio), with each class accounting for exactly $\frac{60}{180} = 33.33\%$ of the dataset.

### Why Class Balance Matters
Class balance provides significant advantages during model training and evaluation:
1. **Unbiased Tree Splitting**: Decision tree splitting criteria (such as Gini impurity) are sensitive to prior class frequencies. In balanced datasets, the tree is not artificially pressured to favor a dominant majority class.
2. **Clear Accuracy Baseline**: The "Zero-Rule" baseline (the accuracy achieved by always guessing the most frequent class) is exactly:
   $$\text{Baseline Accuracy} = \frac{60}{180} = 33.33\%$$
   Any model that achieves $86.7\%$ accuracy is vastly superior to random guessing ($33.3\%$). In contrast, on a 95% imbalanced dataset, a model could achieve 95% accuracy simply by always predicting the majority class without learning anything!
3. **Equal Optimization Focus**: The learning algorithm treats misclassifying Karacabey with the exact same weight as misclassifying Cercevelik or Urgup_Sivrisi.

### Risks of Class Imbalance in Agriculture
In real-world agricultural sorting, harvests are rarely balanced. If an orchard suffers an accidental 2% contamination of weed seeds in a 98% pure wheat harvest, an uncalibrated classifier might ignore the 2% contamination completely to maximize overall accuracy. That is why seed engineers must monitor per-class recall and precision rather than relying on overall accuracy alone.

## Relevant Code (from main.py, lines 32, 82)
```python
    y = df["variety"]
    ...
    labels = sorted(df["variety"].unique())
```

## Code Deep-Dive Breakdown
- `y = df["variety"]`: Captures all 180 class labels.
- `labels = sorted(df["variety"].unique())`: Extracts the three unique string names in alphabetical order: `['Cercevelik', 'Karacabey', 'Urgup_Sivrisi']`.
- Sorting the labels alphabetically ensures that the confusion matrix axes and classification report rows align predictably across all runs.

## Worked Example
Let us compute the class distribution and proportions using pandas:

```python
import pandas as pd

df = pd.read_csv("data/pumpkin_seeds.csv")
counts = df["variety"].value_counts()
proportions = df["variety"].value_counts(normalize=True)

for cultivar in counts.index:
    print(f"Cultivar: {cultivar:<15} Count: {counts[cultivar]} ({proportions[cultivar]:.1%})")
```

**Output**:
```
Cultivar: Urgup_Sivrisi   Count: 60 (33.3%)
Cultivar: Karacabey       Count: 60 (33.3%)
Cultivar: Cercevelik      Count: 60 (33.3%)
```
This confirms that each class is equally weighted in the source data.

## Step-by-Step Student Instructions
1. Load `pumpkin_seeds.csv` in Python.
2. Run `df["variety"].value_counts()` to view the sample counts per cultivar.
3. Verify that each of the three cultivars has 60 rows.
4. Calculate the total rows: $60 + 60 + 60 = 180$.
5. Determine the random-guess baseline accuracy: $\frac{1}{3} \approx 33.33\%$.

## Expected Output or Observable Behaviour
The value counts command returns 60 for all three categories. There are no rare minority classes or dominant majority classes.

## Practical Exercises
- **Exercise 2.3a**: If a dataset had 90 Cercevelik, 10 Karacabey, and 10 Urgup_Sivrisi seeds, what would be the zero-rule majority accuracy?
- **Exercise 2.3b**: Why is overall accuracy a misleading metric when class imbalance is severe?

## Common Mistakes and Debugging
| Mistake | Root Cause | Remediation |
|---|---|---|
| Assuming accuracy is always meaningful | Evaluating models on imbalanced data without checking baselines | Always compare model accuracy against the majority class frequency baseline |
| Unsorted confusion matrix labels | Passing un-sorted lists to confusion_matrix | Always use `labels=sorted(df["variety"].unique())` to ensure consistent axis ordering |

## Best Practices and Security Considerations
- **Stratified Partitioning**: Even when the overall dataset is balanced, random splitting can accidentally introduce imbalance into the test set. Always use stratified splitting.
- **Audit Target Labels**: Verify that string labels do not contain casing inconsistencies (e.g., `"cercevelik"` vs `"Cercevelik"`).

## Real-World Context and Agricultural Impact
When seed testing laboratories validate sorting machines, ISTA (International Seed Testing Association) protocols mandate testing with balanced reference seed sets. This guarantees that the machine's optical sensors are tested equally on all seed types.

## Summary
The pumpkin seed dataset is perfectly balanced, with 60 samples for Cercevelik, 60 for Karacabey, and 60 for Urgup_Sivrisi. Balanced datasets ensure that decision tree splitting criteria do not favor a majority class and provide a straightforward random-guess baseline accuracy of 33.33%.

## Knowledge-check Questions
1. How many samples exist for each variety in `pumpkin_seeds.csv`?
2. What is the baseline accuracy of a model that randomly guesses among the three balanced classes?
3. What is the danger of relying solely on accuracy for an imbalanced dataset?
4. Why does `main.py` sort unique labels alphabetically before plotting the confusion matrix?

## References
- scikit-learn Model Evaluation Guide: https://scikit-learn.org/stable/modules/model_evaluation.html
- Imbalanced Learning: Foundations, Algorithms, and Applications (He & Ma).
- Project Source Code: `main.py` lines 32-36, 82-84.
