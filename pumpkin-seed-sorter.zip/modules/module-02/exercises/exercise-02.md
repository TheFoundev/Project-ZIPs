# Module 2 Exercises: Data, Features, and Stratification

## Exercise 2.1: Dataset Ingestion and Validation (15 min)
**Objective:** Load and validate the integrity of `pumpkin_seeds.csv`.  
**Problem Statement:** Write a Python verification script that loads `data/pumpkin_seeds.csv`, checks that the shape is exactly `(180, 6)`, and confirms that there are zero missing or null values.

**Requirements:**
1. Use `pathlib.Path` to construct the path to `data/pumpkin_seeds.csv`.
2. Load the dataset with `pandas.read_csv()`.
3. Assert that `df.shape == (180, 6)`.
4. Assert that `df.isnull().sum().sum() == 0`.
5. Print a success confirmation message.

**Constraints:** Do not hardcode absolute paths; use `Path(__file__).resolve().parent` or relative paths.

**Expected Behaviour:** The script runs cleanly without assertion errors, printing validation statistics.

**Acceptance Criteria:**
- [ ] Script successfully locates and loads `pumpkin_seeds.csv`.
- [ ] Verifies total rows equal 180 and total columns equal 6.
- [ ] Confirms zero null values across all columns.
- [ ] Uses `pathlib` for file system paths.

**Hints:**
- Review Lesson 01 worked example for DataFrame inspection methods.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 2.2: Eccentricity Verification and Implementation (15 min)
**Objective:** Implement and verify the mathematical formula for seed eccentricity.  
**Problem Statement:** Write a standalone Python function `compute_eccentricity(major_axis, minor_axis) -> float` that calculates eccentricity $e = \sqrt{1 - (b/a)^2}$. Validate your function against five random rows from `pumpkin_seeds.csv`.

**Requirements:**
1. Implement the mathematical formula using Python's `math.sqrt`.
2. Include a check to ensure `major_axis >= minor_axis > 0`.
3. Load `pumpkin_seeds.csv` and compare your calculated eccentricity against the CSV's `eccentricity` column for 5 rows.
4. Verify that discrepancies are less than 0.005 (accounting for floating-point rounding).

**Constraints:** Pure Python with `math` and `pandas`.

**Expected Behaviour:** Function outputs matching eccentricity values within standard rounding tolerance.

**Acceptance Criteria:**
- [ ] Mathematical formula correctly implements $e = \sqrt{1 - (\text{minor}/\text{major})^2}$.
- [ ] Includes validation guarding against division by zero.
- [ ] Validates calculations against actual CSV rows.

**Hints:**
- Remember that `major_axis` is $2a$ and `minor_axis` is $2b$; the factor of 2 cancels out in the ratio $b/a$.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 2.3: Cultivar Distribution Audit (15 min)
**Objective:** Audit class frequencies and calculate baseline zero-rule performance.  
**Problem Statement:** Write a Python script to compute the frequency, percentage share, and zero-rule baseline accuracy for `pumpkin_seeds.csv`.

**Requirements:**
1. Compute the count of each variety using `value_counts()`.
2. Verify that each variety has exactly 60 samples.
3. Compute the baseline classification accuracy of a naive model that always predicts the majority class.
4. Explain why a balanced dataset makes accuracy an intuitive and reliable metric.

**Constraints:** Base analysis directly on `data/pumpkin_seeds.csv`.

**Expected Behaviour:** A formatted console report showing sample counts, percentages, and baseline accuracy (33.33%).

**Acceptance Criteria:**
- [ ] Accurately counts 60 Cercevelik, 60 Karacabey, and 60 Urgup_Sivrisi.
- [ ] Computes baseline accuracy as $60 / 180 = 33.33\%$.
- [ ] Explains how class balance prevents the model from developing bias toward any single cultivar.

**Hints:**
- Use `df["variety"].value_counts(normalize=True)` to get percentage shares.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 2.4: Stratified Splitting Verification (15 min)
**Objective:** Implement and verify the stratified train-test split.  
**Problem Statement:** Replicate the dataset splitting logic from lines 34-36 of `main.py` and write verification assertions confirming subset sizes and class balances.

**Requirements:**
1. Define `FEATURES` and isolate `X = df[FEATURES]` and `y = df["variety"]`.
2. Call `train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)`.
3. Assert that `len(X_train) == 135` and `len(X_test) == 45`.
4. Assert that `y_test.value_counts().to_dict()` equals `{'Cercevelik': 15, 'Karacabey': 15, 'Urgup_Sivrisi': 15}`.
5. Print a report verifying that both partitions maintain exact 1:1:1 class parity.

**Constraints:** Must use `random_state=42` and `stratify=y`.

**Expected Behaviour:** All assertions pass and the console confirms exact stratified distribution.

**Acceptance Criteria:**
- [ ] Uses correct parameter values: `test_size=0.25`, `random_state=42`, `stratify=y`.
- [ ] Verifies 135 training samples (45 per cultivar).
- [ ] Verifies 45 testing samples (15 per cultivar).
- [ ] Explains why unstratified random splitting could cause testing bias.

**Hints:**
- Check lines 34-36 of `main.py` for exact syntax.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  
