# Glossary

| Term | Definition |
|---|---|
| **Multi-Class Classification** | A supervised learning task where instances are categorized into one of three or more discrete classes (e.g., Cercevelik, Karacabey, Urgup_Sivrisi). |
| **Decision Tree** | A non-parametric supervised learning algorithm that partitions data into subsets based on recursive feature threshold splits, represented as an inverted tree. |
| **Morphological Features** | Geometric and structural measurements representing the physical size, shape, and boundary contour of biological specimens (area, perimeter, axes, eccentricity). |
| **Area** | The total surface area of the seed projection, measured in square pixels or square millimeters. |
| **Perimeter** | The total boundary length along the outer perimeter edge of the seed silhouette. |
| **Major Axis** | The longest diameter passing through the center of the best-fitting bounding ellipse around the seed. |
| **Minor Axis** | The shortest diameter perpendicular to the major axis passing through the center of the bounding ellipse. |
| **Eccentricity** | A dimensionless ratio quantifying how much an ellipse deviates from a perfect circle ($0 \le e < 1$), where 0 is circular and values near 1 are highly elongated. |
| **Gini Impurity** | A metric measuring the probability of misclassifying a randomly chosen element from a set if it were randomly labeled according to the class distribution. |
| **max_depth** | The maximum allowable distance from the root node to the furthest leaf node, controlling model complexity and preventing overfitting. |
| **Overfitting** | A condition where a model learns specific noise and idiosyncrasies of training data, harming generalization on unseen test data (seen here when depth > 2). |
| **Stratified Sampling** | A partitioning method ensuring that each class is represented in the exact same proportion in training and testing subsets as in the original dataset. |
| **Confusion Matrix** | A square matrix showing counts of actual vs predicted class labels, highlighting true positives, false positives, and false negatives for each cultivar. |
| **Precision** | The fraction of correct positive predictions among all predictions of that class: $\text{TP} / (\text{TP} + \text{FP})$. |
| **Recall** | The fraction of actual instances of a class that were correctly identified: $\text{TP} / (\text{TP} + \text{FN})$. |
| **F1-Score** | The harmonic mean of precision and recall: $2 \times (\text{Precision} \times \text{Recall}) / (\text{Precision} + \text{Recall})$. |
| **export_text** | A scikit-learn utility that outputs trained decision tree nodes as a hierarchical text tree of IF-THEN boolean rules. |
| **plot_tree** | A scikit-learn utility that renders a graphical flowchart of decision nodes, leaf nodes, thresholds, and class distributions. |
| **Optical Seed Sorter** | An industrial machine that uses high-speed digital cameras, computer vision, and pneumatic air ejectors to sort passing seeds in real time. |
