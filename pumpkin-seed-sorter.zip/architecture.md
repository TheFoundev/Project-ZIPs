# Architecture & System Design

## End-to-End Pipeline Overview

The Pumpkin Seed Sorter pipeline automates agricultural cultivar classification through morphological feature analysis. The architecture follows a modular machine learning pipeline:

```
[data/pumpkin_seeds.csv] (180 samples: 3 cultivars x 60)
         │
         ▼
[Data Loading & Extraction] ── pd.read_csv()
         │
         ├─► Feature Matrix X: ['area', 'perimeter', 'major_axis', 'minor_axis', 'eccentricity'] (180, 5)
         └─► Target Vector y:   'variety' (180,)
         │
         ▼
[Stratified Train/Test Split] ── test_size=0.25, random_state=42, stratify=y
         │
         ├─► Training Set: 135 samples (45 Cercevelik, 45 Karacabey, 45 Urgup_Sivrisi)
         └─► Test Set:      45 samples (15 Cercevelik, 15 Karacabey, 15 Urgup_Sivrisi)
         │
         ▼
[Multi-Depth Decision Tree Training]
         │
         ├─► max_depth=2:         Train & Evaluate ── Accuracy: 86.7% (Best)
         ├─► max_depth=4:         Train & Evaluate ── Accuracy: 84.4%
         └─► max_depth=unlimited: Train & Evaluate ── Accuracy: 84.4%
         │
         ▼
[Model Selection & Rule Extraction]
         │
         ├─► Select Best Estimator: max_depth=2
         ├─► export_text() ── Plain-text nested IF-THEN rules
         ├─► predict() on new seed sample (area=1180, etc.) ── Output: Urgup_Sivrisi
         └─► classification_report() ── Precision, Recall, F1-scores
         │
         ▼
[Visualization & Artifact Persistence]
         │
         ├─► plot_tree() ──────────────────► outputs/pumpkin_tree.png
         ├─► ConfusionMatrixDisplay() ─────► outputs/confusion_matrix.png
         └─► Comprehensive Rules Log ──────► outputs/rules.txt
```

## Component Architecture

1. **Environment & Backend Configuration**:
   - `matplotlib.use("Agg")` ensures non-blocking, headless execution suitable for production servers and automated test runners.
   - Filesystem management uses `pathlib.Path` with automatic output directory creation (`OUT.mkdir(exist_ok=True)`).

2. **Data Ingestion & Feature Engineering**:
   - Tabular ingestion via `pandas.read_csv`.
   - Feature space $X \in \mathbb{R}^{n \times 5}$ isolated from categorical target label $y \in \{ \text{Cercevelik}, \text{Karacabey}, \text{Urgup_Sivrisi} \}$.

3. **Stratification Engine**:
   - Splitting with `test_size=0.25`, fixed seed `random_state=42`, and explicit `stratify=y` guarantees identical class representation (15 samples per cultivar in test) preventing sampling bias.

4. **Recursive Partitioning & Tree Induction**:
   - `DecisionTreeClassifier` executes top-down greedy search optimizing Gini impurity:
     $$G = 1 - \sum_{i=1}^C p_i^2$$
   - Model depth experimentation benchmarks depth 2 vs depth 4 vs unconstrained tree growth, identifying optimal bias-variance equilibrium.

5. **Diagnostic & Visual Reporting**:
   - Flowchart rendering via `plot_tree` detailing samples, thresholds, Gini scores, and majority classes.
   - Error distribution mapping via `confusion_matrix` and `ConfusionMatrixDisplay` highlighting inter-class morphological boundaries.
