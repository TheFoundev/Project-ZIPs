# Setup & Execution Guide

Follow these sequential instructions to prepare your environment and execute **The Sleep vs Screen Time Analyzer**.

---

## Step 1: Locate Project Workspace
Navigate to the project directory in your terminal:

```bash
cd "/home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/10_sleep_screen_time"
```

Confirm that the folder contains `main.py` and the `data/` subdirectory:
```bash
ls -la
```

---

## Step 2: Set Up Virtual Environment (Recommended)
Creating an isolated virtual environment prevents library conflicts:

```bash
# Create a virtual environment named .venv
python3 -m venv .venv

# Activate the virtual environment
# On Linux / macOS:
source .venv/bin/activate
# On Windows (cmd):
# .venv\Scripts\activate
```

---

## Step 3: Install Required Dependencies
Install the scientific libraries needed by the pipeline:

```bash
pip install pandas numpy matplotlib scikit-learn
```

Verify successful installation:
```bash
python -c "import pandas, numpy, matplotlib, sklearn; print('Dependencies successfully verified!')"
```

---

## Step 4: Examine Dataset
Inspect the raw observational data before executing the code:

```bash
head -n 10 data/sleep_screen.csv
```

Notice the columns: `screen_time_hours` and `sleep_hours`.

---

## Step 5: Run the Project
Execute the main script:

```bash
python main.py
```

---

## Step 6: Review Generated Artifacts
Confirm that the `outputs/` directory was created and inspect the generated files:

1. **`outputs/sleep_regression.png`**: Open this image to observe the negative regression line passing through the training and testing points.
2. **`outputs/metrics.txt`**: View the saved mathematical metrics:
   ```bash
   cat outputs/metrics.txt
   ```
