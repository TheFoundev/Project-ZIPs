# Project Summary: The Sleep vs Screen Time Analyzer

## Executive Overview
The Sleep vs Screen Time Analyzer demonstrates how supervised machine learning models quantify and predict real-world inverse relationships. While many introductory tutorials focus solely on positive correlations, real-world data science frequently involves trade-offs and negative correlations. This project analyzes the statistical association between evening screen time (smartphones, laptops, televisions) and subsequent sleep duration using linear regression.

---

## Technical Specifications
- **Project Slug:** `sleep-screen-time`
- **Machine Learning Category:** Supervised Learning
- **Task Type:** Single-Variable Linear Regression
- **Programming Language:** Python 3.8+
- **Primary Libraries:**
  - `pandas`: Data loading and tabular manipulation
  - `numpy`: Numerical calculations and grid generation
  - `scikit-learn`: Model training (`LinearRegression`), data splitting (`train_test_split`), and evaluation metrics (`mean_absolute_error`, `r2_score`)
  - `matplotlib`: Non-interactive visualization (`Agg` backend) and figure generation
- **Dataset Source:** `data/sleep_screen.csv` (35 observations)

---

## Key Mathematical & Statistical Outcomes
| Metric / Parameter | Value | Interpretation |
|---|---|---|
| **Slope ($m$ / `coef_[0]`)** | `-0.57` | Each extra hour of screen time is associated with 0.57 fewer hours (34.2 minutes) of sleep. |
| **Intercept ($c$ / `intercept_`)** | `9.25` | The estimated baseline sleep duration with 0 screen hours is 9.25 hours. |
| **Pearson Correlation ($r$)** | `-0.85` | Strong negative linear association between screen time and sleep. |
| **Mean Absolute Error (MAE)** | `0.52` hours | Model predictions deviate from actual test sleep by an average of ~31.2 minutes. |
| **Coefficient of Determination ($R^2$)** | `0.44` | Screen time explains 44% of the variance in test sleep duration. |
| **Test Case (3.0 screen hours)** | `7.5` hours | The model predicts 7.5 hours of sleep for an individual with 3 hours of pre-bed screen time. |

---

## System Architecture Pipeline
1. **Environment Initialization:** Set `matplotlib.use('Agg')` for headless execution and create `outputs/`.
2. **Data Loading:** Ingest `data/sleep_screen.csv` into a pandas DataFrame.
3. **Feature-Target Separation:** Format $X$ as a 2D DataFrame (`df[['screen_time_hours']]`) and $y$ as a 1D Series (`df['sleep_hours']`).
4. **Data Partitioning:** Split data using `train_test_split(X, y, test_size=0.25, random_state=42)`.
5. **Model Estimation:** Fit `LinearRegression()` on the training set.
6. **Evaluation & Inference:** Compute test MAE, $R^2$, and evaluate target test cases.
7. **Visualization & Reporting:** Render `outputs/sleep_regression.png` and record parameters in `outputs/metrics.txt`.

---

## Methodological Disclaimer
A critical pedagogical outcome of this project is understanding that **correlation does not equal causation**. Although the correlation coefficient is $-0.85$, observational data cannot confirm whether screens physically curtail sleep, or whether confounding factors (e.g., academic anxiety, late-night shift work, caffeine consumption) independently cause both prolonged screen usage and reduced sleep.
