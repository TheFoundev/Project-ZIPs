# Glossary of AI/ML & Statistical Terms

| Term | Category | Definition |
|---|---|---|
| **Linear Regression** | Machine Learning | A supervised modeling approach that models the relationship between a scalar response and one or more explanatory variables using a linear equation. |
| **Negative Slope ($m < 0$)** | Mathematics / ML | A regression slope indicating an inverse relationship; as the independent variable increases, the expected value of the dependent variable decreases. |
| **Negative Correlation** | Statistics | An association between two variables such that higher values of one variable tend to co-occur with lower values of the other variable ($-1.0 \le r < 0$). |
| **Pearson Correlation ($r$)** | Statistics | A standardized measure of the linear relationship between two continuous variables, ranging from $-1.0$ (perfect negative) to $+1.0$ (perfect positive). |
| **Y-Intercept ($c$ / $\beta_0$)** | Mathematics / ML | The expected value of the target variable when the input feature is zero. In this project, estimated baseline sleep at 0 screen hours ($9.25$ hours). |
| **Feature ($X$)** | Machine Learning | The independent input variable fed into the model (here, `screen_time_hours`). |
| **Target ($y$)** | Machine Learning | The dependent output variable that the model aims to predict (here, `sleep_hours`). |
| **Train/Test Split** | ML Methodology | The practice of dividing a dataset into distinct training and testing subsets to evaluate model generalization on unseen data. |
| **Mean Absolute Error (MAE)** | Evaluation Metric | The average absolute magnitude of prediction errors: $\frac{1}{N}\sum |y_i - \hat{y}_i|$. Measured in target units (hours). |
| **Coefficient of Determination ($R^2$)**| Evaluation Metric | The proportion of variance in the dependent variable that is predictable from the independent variable ($1 - \frac{SS_{res}}{SS_{tot}}$). |
| **Ordinary Least Squares (OLS)** | Optimization | The analytical method used by linear regression to find optimal parameters by minimizing the sum of squared vertical residuals. |
| **Confounding Variable** | Causal Inference | An unmeasured or external factor that influences both the independent and dependent variables, potentially creating a spurious correlation. |
| **Correlation vs Causation** | Epistemology / Ethics | The fundamental principle that statistical association between two variables does not guarantee that one causes the other. |
| **Agg Backend** | Visualization | A Matplotlib non-interactive raster rendering backend used for saving figures directly to disk without requiring a graphical display server. |
