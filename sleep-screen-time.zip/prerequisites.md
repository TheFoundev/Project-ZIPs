# Prerequisites & Readiness Checklist

Before beginning this educational module, ensure that your development environment and background knowledge meet the following criteria.

---

## 1. Technical Knowledge Prerequisites
- **Basic Python Syntax:** Familiarity with functions, variable assignments, imports, f-strings, and basic file I/O.
- **Algebraic Foundations:** Understanding the Cartesian coordinate system, the slope-intercept formula for a line ($y = mx + c$), and the concept of negative slope.
- **Basic Statistics:** Intuition for averages, scatter plots, and the concept of correlation.
- **Terminal Basics:** Running commands in a shell environment, changing directories (`cd`), and activating Python virtual environments.

---

## 2. Software & Tooling Requirements
- **Python Version:** Python 3.8, 3.9, 3.10, 3.11, or 3.12.
- **Package Manager:** `pip` (Python package installer).
- **Recommended IDE:** Visual Studio Code, Cursor, PyCharm, or JupyterLab.
- **Operating System:** Linux, macOS, or Windows (WSL recommended for Windows).

---

## 3. Required Python Libraries
Verify that you have installed the following packages:

```bash
pip install pandas numpy matplotlib scikit-learn
```

| Package | Minimum Version | Purpose |
|---|---|---|
| `pandas` | 1.3.0+ | Reading CSV datasets, Series/DataFrame operations |
| `numpy` | 1.20.0+ | Numerical arrays, linspace grid generation |
| `scikit-learn` | 1.0.0+ | Linear regression estimator, train/test split, metrics |
| `matplotlib` | 3.4.0+ | Scatter plotting, trendline rendering, headless export |
