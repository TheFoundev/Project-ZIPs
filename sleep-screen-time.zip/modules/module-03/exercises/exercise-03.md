# Module 03 Exercises: Linear Regression with Negative Slope

---

## Exercise 3.1: Manual Calculation and Unit Conversion
**Objective:** Calculate predicted sleep duration manually using the linear regression formula and convert slope coefficients into minutes.

### Problem Statement
You are required to verify the internal mathematical calculations of the linear regression model without relying on scikit-learn's automated predict method.

### Requirements
1. Using the learned parameters $m = -0.57$ and $c = 9.25$, write the mathematical equation for predicted sleep $\hat{y}$.
2. Manually compute predicted sleep for:
   - $x = 0.0$ hours (baseline)
   - $x = 2.0$ hours
   - $x = 3.5$ hours
   - $x = 5.0$ hours
3. Convert the slope $m = -0.57$ hours into minutes per hour.
4. Calculate how many minutes of sleep are lost when screen time increases by 1.5 hours.

### Acceptance Criteria
- [ ] Equation correctly written: $\hat{y} = -0.57x + 9.25$.
- [ ] Calculations verified:
  - $x=0.0 \implies 9.25$ hours
  - $x=2.0 \implies 8.11$ hours
  - $x=3.5 \implies 7.255$ hours
  - $x=5.0 \implies 6.40$ hours
- [ ] Slope conversion verified as $-34.2$ minutes per screen hour.
- [ ] 1.5 hours of screen time confirmed to cost $51.3$ minutes of sleep ($1.5 	imes 34.2$).

---

## Exercise 3.2: Residual Calculation and OLS Understanding
**Objective:** Calculate individual residuals and verify the properties of Ordinary Least Squares.

### Problem Statement
An observational study recorded a participant with $x = 4.0$ hours of screen time who actually slept $y = 6.8$ hours. You need to calculate the model's prediction and the resulting residual error.

### Requirements
1. Compute the model's predicted sleep $\hat{y}$ for $x = 4.0$ hours using the fitted model equation.
2. Calculate the residual error $e = y - \hat{y}$.
3. State whether the participant slept more or less than predicted by the model.
4. Calculate the squared residual $e^2$.

### Acceptance Criteria
- [ ] Predicted sleep computed as $\hat{y} = -0.57(4.0) + 9.25 = 6.97$ hours.
- [ ] Residual computed as $e = 6.8 - 6.97 = -0.17$ hours (approximately $-10.2$ minutes).
- [ ] Correctly concluded that the participant slept slightly less than predicted.
- [ ] Squared residual computed as $(-0.17)^2 = 0.0289$ hours$^2$.
