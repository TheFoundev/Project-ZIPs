# Lesson 02: Deconstructing the Intercept: Baseline Sleep (9.25 Hours)

**Lesson ID:** lesson-02  
**Module:** module-03  
**Estimated Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives
The purpose of this lesson is to thoroughly analyze the theoretical and practical meaning of the **y-intercept ($c$ / $\beta_0$)** in regression modeling. By the end of this lesson, you will be able to:
- Define the mathematical definition of the y-intercept.
- Interpret the value $9.25$ hours in the context of human sleep hygiene.
- Evaluate whether an intercept represents a physically meaningful state or a mathematical anchor.
- Compare models where intercepts have biological meaning vs models where intercepts are hypothetical abstractions.

---

## 2. Prerequisites and Required Tools
Understanding Cartesian graphs ($y$-axis intercept at $x = 0$) and the linear model equation.

---

## 3. Core Concept Explanation
In linear regression, the **y-intercept** ($c$ or $\beta_0$) is the expected value of the target variable $y$ when the feature $x$ is equal to zero:
$$\hat{y}\Big|_{x=0} = m(0) + c = c$$
In our sleep model, the learned intercept is:
$$c \approx 9.25 \text{ hours}$$

This means that for a person who engages in **zero** evening screen time ($x = 0$), the model forecasts an expected sleep duration of approximately **9 hours and 15 minutes** (0.25 hours = 15 minutes).

---

## 4. Real-World Relevance and Sleep Science Context
In many regression problems, $x = 0$ is physically impossible or meaningless. For instance, in the Lemonade Stand project, the intercept was $-10.66$ cups at $0^\circ\text{C}$—a negative number of cups that cannot physically exist in reality.

In stark contrast, for the Sleep vs Screen Time Analyzer, **$x = 0$ is completely realistic and biologically meaningful**! An individual can easily choose to turn off all screens before bedtime (reading a paper book, meditating, or listening to music). According to sleep medicine literature, young adults and teenagers who abstain from evening screens naturally sleep between 8.5 and 9.5 hours. Thus, the learned baseline intercept of $9.25$ hours aligns remarkably well with real-world physiological benchmarks.

---

## 5. Mathematical and Theoretical Foundations
In Ordinary Least Squares regression, the fitted line is mathematically constrained to pass directly through the centroid of the training data $(\bar{x}, \bar{y})$:
$$\bar{y} = \beta_1 \bar{x} + \beta_0 \implies \beta_0 = \bar{y} - \beta_1 \bar{x}$$

Using our training set means:
- Mean training screen time: $\bar{x} \approx 3.32$ hours.
- Mean training sleep: $\bar{y} \approx 7.36$ hours.
- Slope: $\beta_1 \approx -0.57$.

Calculating $\beta_0$:
$$\beta_0 = 7.36 - (-0.57 \times 3.32) = 7.36 + 1.89 = 9.25 \text{ hours}$$
Because $\beta_1$ is negative, the product $\beta_1 \bar{x}$ is negative. Subtracting a negative number **adds** to the mean, pulling the intercept higher than the average sleep duration!

---

## 6. Relevant Code Implementation
In `main.py`, line 42 extracts the intercept:

```python
intercept = float(model.intercept_)
print(f"Intercept: {intercept:.2f} hours")
```

---

## 7. Line-by-Line Code Breakdown
- `model.intercept_`: The trained scikit-learn LinearRegression instance stores the learned intercept in this public attribute (ending with a trailing underscore by scikit-learn convention).
- `float(...)`: Converts the NumPy 64-bit float into a Python floating-point scalar.
- `:.2f`: Formats to two decimal places, rendering `9.25`.

---

## 8. Worked Examples and Calculations
Let us convert the decimal hours of the intercept into hours and minutes:
- Integer part: $9$ hours.
- Fractional part: $0.25 \text{ hours} \times 60 \frac{\text{minutes}}{\text{hour}} = 15.0 \text{ minutes}$.
- Exact baseline prediction: **9 hours and 15 minutes**.

In the actual dataset, participant 18 recorded $0.8$ hours of screen time (the lowest in the cohort) and logged $9.6$ hours of sleep. This empirical observation directly supports the model's estimate of $\sim 9.25$ hours for zero screen time.

---

## 9. Step-by-Step Student Implementation Instructions
1. Inspect `model.intercept_` in Python.
2. Verify that its value is positive ($9.248...$).
3. Multiply the fractional decimal ($0.248...$) by 60 to compute baseline sleep in minutes.
4. Reflect on why the intercept must be higher than the sample mean sleep duration when the slope is negative.

---

## 10. Expected Output and Observable Behavior
Printing the intercept and its converted form shows:
```text
Baseline Sleep at 0 Screen Time: 9 hours and 15 minutes (9.25 hours)
```
This confirms that the intercept acts as the upper ceiling of predicted sleep within the normal feature domain.

---

## 11. Practical Exercises and Mini-Tasks
- **Task 1:** If the slope were positive ($+0.57$) instead of negative, would the intercept be higher or lower than the mean sleep duration?
- **Task 2:** Why is an intercept of $9.25$ hours considered biologically plausible, whereas an intercept of $-10.66$ cups of lemonade is considered a mathematical abstraction?

---

## 12. Common Mistakes, Pitfalls, and Debugging
- **Misinterpreting the Intercept as the Average:** Believing $9.25$ is the average sleep of all participants. $9.25$ is the baseline sleep specifically for zero screen time. The overall cohort average is $\sim 7.34$ hours.
- **Ignoring scikit-learn's Underscore Convention:** Attempting to access `model.intercept` instead of `model.intercept_`. In scikit-learn, learned attributes always end with a trailing underscore (`_`).

---

## 13. Best Practices and Responsible Data Science Considerations
Always assess whether the intercept corresponds to a physically reachable state. If $x = 0$ is outside the range of possible inputs (e.g., human height = 0), explicitly clarify to stakeholders that the intercept serves solely as a mathematical anchor for the line.

---

## 14. Summary and Key Takeaways
- The intercept $\beta_0 \approx 9.25$ represents expected nightly sleep at zero pre-bed screen hours.
- In hours and minutes, $9.25$ hours equals 9 hours and 15 minutes.
- Because the slope is negative, the intercept is higher than the cohort mean sleep duration.

---

## 15. Knowledge Check Questions and References
1. What does the y-intercept represent in this model?
2. What is the value of the intercept in hours and minutes?
3. Why does scikit-learn append a trailing underscore to `model.intercept_`?

*References:*
- Gelman, A., & Hill, J. (2006). *Data Analysis Using Regression and Multilevel/Hierarchical Models*. Cambridge University Press.
- Scikit-learn API Design Conventions: *Estimated Attributes*.
