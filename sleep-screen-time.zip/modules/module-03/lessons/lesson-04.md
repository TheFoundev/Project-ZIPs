# Lesson 04: The Ordinary Least Squares (OLS) Criterion

**Lesson ID:** lesson-04  
**Module:** module-03  
**Estimated Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives
The purpose of this lesson is to understand the mathematical optimization engine that powers linear regression: **Ordinary Least Squares (OLS)**. By the end of this lesson, you will be able to:
- Define a residual ($e_i = y_i - \hat{y}_i$) as the vertical prediction error.
- Explain why OLS minimizes the sum of squared residuals rather than absolute residuals.
- Derive the closed-form analytical equations for optimal slope ($\beta_1$) and intercept ($\beta_0$).
- Understand why extreme outliers exert strong leverage on least-squares solutions.

---

## 2. Prerequisites and Required Tools
Basic differential calculus concepts (finding the minimum of a parabola by setting the derivative to zero) and summation notation ($\sum$).

---

## 3. Core Concept Explanation
How does scikit-learn's `LinearRegression()` find the exact slope ($-0.57$) and intercept ($9.25$) out of infinite possible lines?

It uses **Ordinary Least Squares (OLS)**. For each data point $(x_i, y_i)$, the model makes a prediction $\hat{y}_i = \beta_1 x_i + \beta_0$. The vertical distance between the actual observed sleep and the predicted sleep is the **residual** ($e_i$):
$$e_i = y_i - \hat{y}_i = y_i - (\beta_1 x_i + \beta_0)$$

OLS searches for the unique pair of parameters $(\beta_0, \beta_1)$ that minimizes the **Sum of Squared Residuals (SSR)** (also called Residual Sum of Squares, RSS):
$$\text{SSR}(\beta_0, \beta_1) = \sum_{i=1}^{N_{train}} e_i^2 = \sum_{i=1}^{N_{train}} \left( y_i - (\beta_1 x_i + \beta_0) \right)^2$$

---

## 4. Real-World Relevance and Sleep Science Context
In sleep studies, individual biological variability exists: some people naturally need 9 hours of sleep, while others feel refreshed on 7 hours. Because data points do not lie on a perfect single file line, residuals are inevitable. OLS provides a mathematically principled, objective criterion to find the single line that minimizes total squared error across all participants.

---

## 5. Mathematical and Theoretical Foundations
Why do we square the residuals before summing them?
1. **Preventing Cancellation:** If we simply summed $e_i$, positive errors ($+1.0$ hour) and negative errors ($-1.0$ hour) would cancel out to $0.0$, making a terrible model appear perfect!
2. **Differentiability:** Squaring produces a smooth, convex quadratic bowl with a single global minimum.

By taking partial derivatives with respect to $\beta_0$ and $\beta_1$ and setting them to zero:
$$\frac{\partial \text{SSR}}{\partial \beta_0} = 0, \quad \frac{\partial \text{SSR}}{\partial \beta_1} = 0$$

We obtain the closed-form **Normal Equations**:
$$\beta_1 = \frac{\sum (x_i - \bar{x})(y_i - \bar{y})}{\sum (x_i - \bar{x})^2} = \frac{\text{Cov}(X, Y)}{\text{Var}(X)}$$
$$\beta_0 = \bar{y} - \beta_1 \bar{x}$$

Notice that the numerator of $\beta_1$ is the covariance between $X$ and $Y$. Because evening screen time and sleep duration covary negatively, the numerator is negative, making $\beta_1$ strictly negative!

---

## 6. Relevant Code Implementation
In `main.py`, line 37-38 executes this exact OLS mathematical solution:

```python
model = LinearRegression()
model.fit(X_train, y_train)
```

---

## 7. Line-by-Line Code Breakdown
- `model = LinearRegression()`: Creates an instance of the estimator configured to use the analytical OLS algorithm.
- `model.fit(X_train, y_train)`: Solves the normal equations via linear algebra (LAPACK/BLAS matrix factorization), computing `model.coef_` and `model.intercept_` almost instantaneously.

---

## 8. Worked Examples and Calculations
Let us evaluate a residual for an actual test point:
- Observed test point: $x = 1.5$ hours of screen time, actual sleep $y = 8.4$ hours.
- Model prediction:
  $$\hat{y} = -0.5694(1.5) + 9.2486 = -0.8541 + 9.2486 = 8.3945 \text{ hours}$$
- Residual ($e_i$):
  $$e_i = y_i - \hat{y}_i = 8.4 - 8.3945 = +0.0055 \text{ hours} \approx 19.8 \text{ seconds}!$$
The squared error for this point is $(0.0055)^2 \approx 0.000030$.

---

## 9. Step-by-Step Student Implementation Instructions
1. Train the model on the training set.
2. Generate predictions for the training set: `y_train_pred = model.predict(X_train)`.
3. Compute residuals: `residuals = y_train - y_train_pred`.
4. Compute SSR: `ssr = np.sum(residuals ** 2)`.
5. Print `ssr` and observe the minimized total squared loss.

---

## 10. Expected Output and Observable Behavior
Printing `np.mean(residuals)` yields approximately `0.000000000000001` ($10^{-15}$). A fundamental mathematical property of OLS with an intercept is that the **sum of residuals is always exactly zero**!

---

## 11. Practical Exercises and Mini-Tasks
- **Task 1:** Explain why taking the absolute value $|e_i|$ (Mean Absolute Error) is less sensitive to extreme outliers than squaring $e_i^2$.
- **Task 2:** Verify that the sum of residuals on the training set equals zero.

---

## 12. Common Mistakes, Pitfalls, and Debugging
- **Thinking OLS Uses Gradient Descent by Default:** In scikit-learn, `LinearRegression()` uses an exact closed-form matrix solution (Singular Value Decomposition / LAPACK), not iterative gradient descent. (Iterative descent is implemented in `SGDRegressor`).
- **Assuming Residuals Must Be Positive:** Residuals can be positive or negative. A positive residual means the participant slept longer than predicted; a negative residual means they slept less.

---

## 13. Best Practices and Responsible Data Science Considerations
Because OLS squares errors, a single extreme outlier (e.g., someone reporting 15 hours of screen time and 10 hours of sleep) exerts disproportionate leverage, pulling the entire line toward itself. Always screen for outliers before trusting OLS parameters.

---

## 14. Summary and Key Takeaways
- Ordinary Least Squares (OLS) minimizes the sum of squared vertical residuals: $\sum (y_i - \hat{y}_i)^2$.
- The analytical formula for slope is $\beta_1 = \frac{\text{Cov}(X, Y)}{\text{Var}(X)}$.
- The negative covariance between screen time and sleep mathematically guarantees a negative slope.

---

## 15. Knowledge Check Questions and References
1. What mathematical quantity does Ordinary Least Squares minimize?
2. What is the definition of a residual?
3. What is the theoretical sum of all residuals on the training set in an OLS model with an intercept?

*References:*
- Legendre, A. M. (1805). *Nouvelles méthodes pour la détermination des orbites des comètes*.
- Hastie, T., Tibshirani, R., & Friedman, J. (2009). *The Elements of Statistical Learning*. Springer.
