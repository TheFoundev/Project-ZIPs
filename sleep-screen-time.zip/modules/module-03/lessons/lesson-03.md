# Lesson 03: Interpreting the Slope: The Cost of an Extra Screen Hour

**Lesson ID:** lesson-03  
**Module:** module-03  
**Estimated Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives
The purpose of this lesson is to master the real-world behavioral interpretation of the regression **slope ($m$ / $\beta_1$)**. By the end of this lesson, you will be able to:
- State the learned slope parameter: $m \approx -0.57$ hours of sleep per hour of screen time.
- Convert decimal slope hours into minutes ($-0.57 \times 60 = -34.2$ minutes).
- Formulate executive statements translating statistical coefficients into actionable lifestyle advice.
- Contrast unit rates of change with overall correlation coefficients.

---

## 2. Prerequisites and Required Tools
Understanding the slope formula $m = \frac{\Delta y}{\Delta x}$ and basic unit conversion (hours to minutes).

---

## 3. Core Concept Explanation
The slope of a linear regression line quantifies the **rate of change**: for each one-unit increase in the independent feature $X$, the dependent target $y$ changes by $m$ units:
$$m = \frac{\Delta y}{\Delta x}$$

In our model:
$$m = -0.57 \frac{\text{hours of sleep}}{\text{hour of screen time}}$$

This means that according to the statistical pattern, **each additional hour of pre-bed screen time is associated with a decrease of 0.57 hours of sleep**.

---

## 4. Real-World Relevance and Sleep Science Context
Telling a patient or app user that "each screen hour costs 0.57 hours of sleep" can be abstract, as humans rarely think of time in tenths of an hour. Translating this rate into everyday time units makes data science impactful:
$$0.57 \text{ hours} \times 60 \frac{\text{minutes}}{\text{hour}} = 34.2 \text{ minutes}$$

**Actionable Insight:** Every extra hour spent watching television or scrolling on a phone before bed corresponds to approximately **34 minutes of lost sleep**.

---

## 5. Mathematical and Theoretical Foundations
Let us analyze incremental changes using the model equation $\hat{y} = mx + c$:
$$\hat{y}_1 = m x_1 + c$$
$$\hat{y}_2 = m (x_1 + \Delta x) + c = m x_1 + m \Delta x + c$$
Subtracting the two equations:
$$\Delta \hat{y} = \hat{y}_2 - \hat{y}_1 = m \Delta x$$

Notice that the intercept $c$ cancels out completely! The change in sleep depends solely on the slope $m$ and the change in screen time $\Delta x$:
$$\Delta \hat{y} = -0.57 \times \Delta x$$

---

## 6. Relevant Code Implementation
In `main.py`, lines 41 and 51 extract and display the slope:

```python
slope = float(model.coef_[0])
print(f"Model: sleep = {slope:.2f} x screen time + {intercept:.2f}")
```

---

## 7. Line-by-Line Code Breakdown
- `model.coef_`: In scikit-learn, the coefficients for features are stored in the array `model.coef_`. For univariate regression, this is a 1-element array: `array([-0.5694...])`.
- `model.coef_[0]`: Indexes the first (and only) coefficient.
- `float(...)`: Unpacks the scalar float, yielding approximately `-0.57`.

---

## 8. Worked Examples and Calculations
Let us evaluate different changes in screen time:
1. **Adding 30 minutes of screen time ($\Delta x = +0.5$ hours):**
   $$\Delta \hat{y} = -0.57 	imes 0.5 = -0.285 	ext{ hours} = -17.1 	ext{ minutes}$$
2. **Adding 2 hours of screen time ($\Delta x = +2.0$ hours):**
   $$\Delta \hat{y} = -0.57 	imes 2.0 = -1.14 	ext{ hours} = -68.4 	ext{ minutes}$$
   (Over an hour of sleep lost!)
3. **Reducing screen time by 1 hour ($\Delta x = -1.0$ hour):**
   $$\Delta \hat{y} = -0.57 	imes (-1.0) = +0.57 	ext{ hours} = +34.2 	ext{ minutes (sleep gained)}$$

---

## 9. Step-by-Step Student Implementation Instructions
1. In your Python console, assign: `slope = -0.5694`.
2. Compute lost minutes per hour: `lost_minutes = abs(slope) * 60`.
3. Print: `print(f"Each screen hour costs {lost_minutes:.1f} minutes of sleep")`.
4. Verify that the output states approximately `34.2 minutes`.

---

## 10. Expected Output and Observable Behavior
Running the calculation outputs:
```text
Each screen hour costs 34.2 minutes of sleep
```
This translation allows clear, intuitive communication with non-technical stakeholders.

---

## 11. Practical Exercises and Mini-Tasks
- **Task 1:** If a student decreases their evening screen exposure from 4 hours to 1 hour ($\Delta x = -3$), how many total minutes of sleep does the model predict they will regain?
- **Task 2:** Why does the unit of slope have both dependent and independent units (hours of sleep per hour of screen time)?

---

## 12. Common Mistakes, Pitfalls, and Debugging
- **Reporting Slope Without Units:** Saying "the slope is -0.57" without specifying "hours of sleep per hour of screen time". Pure numbers are meaningless without dimensional context.
- **Accessing `model.coef_` as a Scalar:** Calling `float(model.coef_)` will raise `TypeError: only size-1 arrays can be converted to Python scalars` if multi-feature arrays are used. Always index `model.coef_[0]`.

---

## 13. Best Practices and Responsible Data Science Considerations
Always convert abstract decimal coefficients into the natural time units of your users (hours and minutes). When communicating with the public, emphasize that these figures represent average statistical associations across a group, not an absolute guarantee for any single person.

---

## 14. Summary and Key Takeaways
- The learned slope $m pprox -0.57$ quantifies the rate of sleep loss per unit of screen exposure.
- Multiplying by 60 reveals that each screen hour costs approximately 34.2 minutes of sleep.
- Changes in the prediction depends entirely on $m \Delta x$, independent of the intercept.

---

## 15. Knowledge Check Questions and References
1. What is the value of the slope in our trained model?
2. How many minutes of sleep are lost per additional hour of screen time?
3. In scikit-learn, what attribute name stores the feature slopes?

*References:*
- Scikit-learn User Guide: *LinearRegression attributes*.
- American Academy of Sleep Medicine: *Healthy Sleep Habits and Digital Device Usage*.
