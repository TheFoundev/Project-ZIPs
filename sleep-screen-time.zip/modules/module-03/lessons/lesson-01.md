# Lesson 01: The Equation of a Line with Negative Slope

**Lesson ID:** lesson-01  
**Module:** module-03  
**Estimated Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives
The purpose of this lesson is to master the mathematical and geometric foundation of the linear regression equation when the slope is strictly negative. By the end of this lesson, you will be able to:
- State the classic slope-intercept form $y = mx + c$ and its statistical notation $\hat{y} = \beta_0 + \beta_1 x$.
- Explain how a negative slope ($m < 0$) alters the geometric trajectory of the regression line.
- Calculate predicted values along the line for given inputs.
- Differentiate between positive growth models and negative trade-off models.

---

## 2. Prerequisites and Required Tools
Basic high school algebra: understanding coordinates $(x, y)$, straight lines, and solving simple linear equations.

---

## 3. Core Concept Explanation
In elementary algebra, a straight line is defined by the equation:
$$y = mx + c$$
where:
- $x$ is the input variable (independent).
- $y$ is the output variable (dependent).
- $m$ is the **slope** (gradient), representing the change in $y$ for each unit increase in $x$: $m = \frac{\Delta y}{\Delta x}$.
- $c$ is the **y-intercept**, representing the point where the line crosses the vertical y-axis ($x = 0$).

When $m > 0$, the line rises from left to right. However, when $m < 0$, the line falls from left to right. In our sleep model, $m \approx -0.57$ and $c \approx 9.25$:
$$\text{sleep} = -0.57 \times \text{screen\_time} + 9.25$$

---

## 4. Real-World Relevance and Sleep Science Context
Many introductory ML courses use positive examples: more study hours $\rightarrow$ higher test scores; higher temperature $\rightarrow$ more lemonade sold. But nature and economics are full of inverse relationships:
- Increased vehicle weight $\rightarrow$ decreased fuel efficiency.
- Increased price $\rightarrow$ decreased consumer demand.
- Increased bedtime screen exposure $\rightarrow$ decreased nightly sleep duration.

Mastering negative slopes ensures you can model systems where resources, time, or energy are finite.

---

## 5. Mathematical and Theoretical Foundations
In machine learning literature, statisticians often write the equation with betas:
$$\hat{y} = \beta_1 x + \beta_0 \quad \text{or} \quad \hat{y} = \beta_0 + \beta_1 x$$
Here:
- $\beta_0 = 9.25$ is the intercept parameter.
- $\beta_1 = -0.57$ is the slope parameter (coefficient).
- The "hat" over $y$ ($\hat{y}$) denotes an **estimated or predicted** value, distinguishing it from an actual observed measurement $y_i$.

Because $\beta_1 < 0$:
$$\frac{d\hat{y}}{dx} = \beta_1 = -0.57 < 0$$
The derivative is constant and negative throughout the entire domain.

---

## 6. Relevant Code Implementation
In `main.py`, lines 51 prints the parameterized equation:

```python
slope = float(model.coef_[0])
intercept = float(model.intercept_)
print(f"Model: sleep = {slope:.2f} x screen time + {intercept:.2f}")
```

---

## 7. Line-by-Line Code Breakdown
- `model.coef_[0]`: Retrieves the slope parameter $\beta_1$ calculated by scikit-learn.
- `model.intercept_`: Retrieves the intercept parameter $\beta_0$.
- `float(...)`: Extracts pure scalar numbers from NumPy arrays.
- `print(...)`: Uses Python f-strings to display the equation formatted to two decimal places: `sleep = -0.57 x screen time + 9.25`.

---

## 8. Worked Examples and Calculations
Let us manually compute predicted sleep $\hat{y}$ for three distinct screen time scenarios:
- **Scenario 1 ($x = 1.0$ hour):**
  $$\hat{y} = -0.57(1.0) + 9.25 = -0.57 + 9.25 = 8.68 \text{ hours}$$
- **Scenario 2 ($x = 3.0$ hours):**
  $$\hat{y} = -0.57(3.0) + 9.25 = -1.71 + 9.25 = 7.54 \text{ hours}$$
- **Scenario 3 ($x = 5.0$ hours):**
  $$\hat{y} = -0.57(5.0) + 9.25 = -2.85 + 9.25 = 6.40 \text{ hours}$$

Notice that moving from 1.0 to 5.0 hours of screen time causes predicted sleep to drop steadily from 8.68 down to 6.40 hours.

---

## 9. Step-by-Step Student Implementation Instructions
1. Open a Python terminal or scratch file.
2. Define variables: `slope = -0.5694` and `intercept = 9.2486`.
3. Create a function:
   ```python
   def predict_sleep(screen_hours):
       return slope * screen_hours + intercept
   ```
4. Test the function with inputs `0.0`, `2.0`, `4.0`.
5. Observe how the output decreases monotonically as the input increases.

---

## 10. Expected Output and Observable Behavior
Calling `predict_sleep(2.0)` returns approximately `8.11`, while `predict_sleep(4.0)` returns approximately `6.97`. The mathematical ordering $\hat{y}(x_1) > \hat{y}(x_2)$ whenever $x_1 < x_2$ confirms an inverse function.

---

## 11. Practical Exercises and Mini-Tasks
- **Task 1:** Using the formula $\hat{y} = -0.57x + 9.25$, calculate predicted sleep for someone with 2.5 hours of screen time.
- **Task 2:** At what theoretical amount of screen time would this linear model predict zero hours of sleep? (Solve $0 = -0.57x + 9.25$).

---

## 12. Common Mistakes, Pitfalls, and Debugging
- **Dropping the Minus Sign:** Accidentally calculating $0.57x + 9.25$, which yields 10.96 hours at 3 hours of screen time—contradicting biological reality!
- **Extrapolating Beyond Domain Limits:** Using the linear equation for extreme values like $x = 20$ hours of screen time, which predicts negative sleep: $-0.57(20) + 9.25 = -2.15$ hours. Linear models are valid only within the observed domain of inputs.

---

## 13. Best Practices and Responsible Data Science Considerations
Always document the domain of validity for linear regression models. Never apply linear equations to inputs far outside the range of training data without explicitly noting the risks of extrapolation.

---

## 14. Summary and Key Takeaways
- The linear equation for our model is $\hat{y} = -0.57x + 9.25$.
- A negative slope means the line decreases as $x$ increases.
- Manual calculation enables immediate sanity-checking of machine learning predictions.

---

## 15. Knowledge Check Questions and References
1. What does the variable $m$ represent in the equation $y = mx + c$?
2. What is the value of the slope in our trained sleep model?
3. What is predicted sleep when screen time is 3.0 hours?

*References:*
- Strang, G. (2016). *Introduction to Linear Algebra*. Wellesley-Cambridge Press.
- Khan Academy: *Linear Equations and Slope-Intercept Form*.
