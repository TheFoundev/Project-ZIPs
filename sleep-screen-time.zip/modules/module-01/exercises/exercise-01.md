# Module 01 Exercises: Problem Framing and System Architecture

---

## Exercise 1.1: Supervised Regression vs Classification Analysis
**Objective:** Correctly categorize machine learning problem types and justify your reasoning using the sleep vs screen time dataset.

### Problem Statement
In health data science, teams must choose whether to formulate an outcome as a continuous regression target or a discrete classification category. You are tasked with analyzing the sleep study problem and documenting the optimal modeling paradigm.

### Requirements
1. Define supervised learning in the context of the `sleep_screen.csv` dataset.
2. Define regression and state the exact continuous target variable used in this project.
3. Contrast regression with classification: describe what data loss occurs if sleep is binned into "Sufficient" vs "Insufficient" categories.
4. Formulate the mathematical hypothesis: state the expected direction of the relationship between `screen_time_hours` ($X$) and `sleep_hours` ($y$).

### Acceptance Criteria
- [ ] Supervised learning is correctly explained using input-output pairs ($X, y$).
- [ ] Regression is clearly identified as continuous real-valued prediction.
- [ ] The feature is identified as `screen_time_hours` and the target as `sleep_hours`.
- [ ] The inverse/negative direction is clearly stated (as $X$ increases, $y$ decreases).

---

## Exercise 1.2: Path Resolution and Pipeline Verification
**Objective:** Inspect and verify the directory structure and path handling in `main.py`.

### Problem Statement
Robust AI/ML pipelines must run seamlessly across development, testing, and production servers without path errors. You need to inspect how `main.py` handles paths and directory creation.

### Requirements
1. Inspect lines 22-26 in `main.py` and explain how `BASE`, `DATA`, and `OUT` are constructed.
2. Explain the purpose of `OUT.mkdir(exist_ok=True)`.
3. Check the contents of `data/sleep_screen.csv` using terminal commands (`head`, `wc -l`).
4. Record the total number of lines in `data/sleep_screen.csv` (including header).

### Acceptance Criteria
- [ ] Accurately describe the function of `Path(__file__).resolve().parent`.
- [ ] Explain why `exist_ok=True` prevents `FileExistsError`.
- [ ] Verify that `data/sleep_screen.csv` has 36 total lines (1 header + 35 observational rows).
