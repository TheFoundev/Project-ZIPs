# Lesson 03: The Concept of Negative Correlation and Inverse Relationships

**Lesson ID:** lesson-03  
**Module:** module-01  
**Estimated Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives
The purpose of this lesson is to establish a rigorous intuitive and mathematical understanding of **negative correlation** and **inverse relationships**. By the end of this lesson, you will be able to:
- Define positive, negative, and zero correlation.
- Explain why the sleep vs screen time problem exhibits an inverse relationship.
- Contrast positive regression slopes with negative regression slopes.
- Interpret the real-world trade-off implied when two variables move in opposite directions.

---

## 2. Prerequisites and Required Tools
Basic familiarity with directional slopes on Cartesian graphs (lines sloping upward vs lines sloping downward).

---

## 3. Core Concept Explanation
In data science, **correlation** describes the degree to which two variables move in coordination with one another:
- **Positive Correlation:** As variable $X$ increases, variable $Y$ also increases. (Example: Ambient temperature and ice cream sales).
- **Negative (Inverse) Correlation:** As variable $X$ increases, variable $Y$ decreases. (Example: Pre-bed screen time and sleep duration).
- **Zero Correlation:** Changes in variable $X$ exhibit no linear pattern relative to variable $Y$.

In our project, screen exposure and sleep duration are **negatively correlated**. The more time an individual spends looking at screens before sleeping, the fewer hours of sleep they typically obtain.

---

## 4. Real-World Relevance and Sleep Science Context
Inverse relationships represent trade-offs. In behavioral economics and health, time is a finite resource: there are only 24 hours in a day. Hours allocated to evening digital entertainment or late-night web browsing often directly displace the sleep opportunity window. Furthermore, physiological arousal delays the onset of sleep, truncating total sleep duration even further.

---

## 5. Mathematical and Theoretical Foundations
A linear relationship between $X$ and $Y$ is expressed as:
$$y = mx + c$$
where:
- $m$ is the **slope** (rate of change): $m = \frac{\Delta y}{\Delta x}$.
- $c$ is the **intercept**: the value of $y$ when $x = 0$.

When two variables are negatively correlated, the slope is strictly negative:
$$m < 0 \implies \Delta y < 0 \text{ whenever } \Delta x > 0$$
Graphically, this produces a regression line that slopes downwards from left to right.

---

## 6. Relevant Code Implementation
In `main.py`, lines 51-52 display the model's equation and correlation:

```python
print(f"Model: sleep = {slope:.2f} x screen time + {intercept:.2f}")
print(f"Correlation: {correlation:.2f} (negative means they move in opposite directions)")
```

---

## 7. Line-by-Line Code Breakdown
- `slope:.2f`: Formats the learned slope to 2 decimal places (outputs `-0.57`).
- `intercept:.2f`: Formats the baseline intercept to 2 decimal places (outputs `9.25`).
- `correlation:.2f`: Formats the Pearson correlation coefficient (outputs `-0.85`).
- The explanatory text explicitly reminds students: *"negative means they move in opposite directions"*.

---

## 8. Worked Examples and Calculations
Let us evaluate what the negative slope $m = -0.57$ means for changes in screen habits:
- If a student increases screen time by $\Delta x = +1.0$ hour:
  $$\Delta y = -0.57 \times 1.0 = -0.57 \text{ hours}$$
  Converting to minutes: $-0.57 \times 60 = -34.2$ minutes.
- If a student increases screen time by $\Delta x = +2.0$ hours:
  $$\Delta y = -0.57 \times 2.0 = -1.14 \text{ hours} \approx -68.4 \text{ minutes}.$$
Every increase in the input creates a predictable drop in the output.

---

## 9. Step-by-Step Student Implementation Instructions
1. Review the sign of the slope in the equation: `sleep = -0.57 * screen + 9.25`.
2. Notice the minus sign preceding $0.57$.
3. Compute the expected change in sleep if screen time decreases by 1 hour ($\Delta x = -1$).
   $$\Delta y = -0.57 	imes (-1) = +0.57 	ext{ hours (gain)}.$$

---

## 10. Expected Output and Observable Behavior
When running the script, observe the console output:
```text
Correlation: -0.85 (negative means they move in opposite directions)
```
A correlation of $-0.85$ indicates a strong negative linear association.

---

## 11. Practical Exercises and Mini-Tasks
- **Task 1:** Give an example of two real-world variables that share a positive correlation.
- **Task 2:** Give an example of two real-world variables that share a negative correlation.
- **Task 3:** Explain what a correlation of $0.0$ would signify regarding screen time and sleep.

---

## 12. Common Mistakes, Pitfalls, and Debugging
- **Interpreting Negative Correlation as "Weak":** Confusing a negative sign with lack of correlation. A correlation of $-0.85$ is just as strong as $+0.85$; the sign indicates direction, while the magnitude indicates strength.
- **Dropping the Negative Sign:** Writing `0.57 * screen_time` instead of `-0.57 * screen_time`, which would incorrectly imply screens increase sleep!

---

## 13. Best Practices and Responsible Data Science Considerations
Always visually inspect a scatter plot before assuming linearity. While correlation measures linear association, it can be sensitive to extreme outliers or non-linear patterns.

---

## 14. Summary and Key Takeaways
- Negative correlation indicates that variables move in opposite directions.
- A negative slope ($m < 0$) causes the regression line to angle downward from left to right.
- In our project, $r = -0.85$ demonstrates a strong inverse relationship between screen time and sleep.

---

## 15. Knowledge Check Questions and References
1. What does the negative sign in a correlation coefficient signify?
2. Which correlation represents a stronger relationship: $-0.85$ or $+0.40$?
3. If $m = -0.57$, how many minutes of sleep are lost per additional hour of screen time?

*References:*
- Freedman, D., Pisani, R., & Purves, R. (2007). *Statistics*. W. W. Norton & Company.
- OpenIntro Statistics: *Linear Regression and Correlation*.
