# Lesson 02: Framing Continuous Prediction: Supervised Regression vs Classification

**Lesson ID:** lesson-02  
**Module:** module-01  
**Estimated Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives
The purpose of this lesson is to master the taxonomy of machine learning tasks, focusing specifically on why predicting sleep duration requires **supervised regression**. By the end of this lesson, you will be able to:
- Distinguish between supervised learning, unsupervised learning, and reinforcement learning.
- Differentiate continuous numeric regression from categorical classification.
- Identify the exact data types and shapes required for regression features and targets in Python.
- Explain why labeling sleep as "7.4 hours" conveys more predictive fidelity than labeling it "good sleep".

---

## 2. Prerequisites and Required Tools
Understanding the difference between numbers with decimals (floats) and textual categories (strings). Basic Python knowledge of pandas Series and DataFrames.

---

## 3. Core Concept Explanation
Machine learning algorithms are categorized based on their learning paradigm:
1. **Supervised Learning:** The algorithm is provided with pairs of inputs ($X$) and ground-truth outputs ($y$). It learns a general rule that maps inputs to outputs.
2. **Unsupervised Learning:** The algorithm receives only input data ($X$) without labeled responses and discovers latent clusters or structures.
3. **Reinforcement Learning:** An agent interacts with an environment, learning optimal behaviors via trial, error, and cumulative reward signals.

Because our sleep dataset provides paired observations containing both screen time and the actual recorded sleep duration, our analysis operates entirely within the **supervised learning** paradigm.

---

## 4. Real-World Relevance and Sleep Science Context
In clinical sleep medicine, sleep duration is quantified on a continuous timeline (hours and minutes). If a clinic only recorded whether a patient had "sufficient" or "insufficient" sleep (a classification approach), they would discard subtle, meaningful shifts—such as a 30-minute reduction in restorative rest. Regression preserves the full fidelity of continuous physiological measurements.

---

## 5. Mathematical and Theoretical Foundations
Within supervised learning, tasks diverge based on the nature of the target space $\mathcal{Y}$:
- **Classification:** $\mathcal{Y}$ is a discrete, finite set of categorical classes: $\mathcal{Y} \in \{C_1, C_2, \dots, C_k\}$.
- **Regression:** $\mathcal{Y}$ is a continuous subset of the real numbers: $\mathcal{Y} \subseteq \mathbb{R}$.

For our sleep analyzer:
$$y \in [0.0, 24.0] \subset \mathbb{R}$$
Thus, estimating sleep duration is strictly a regression problem.

---

## 6. Relevant Code Implementation
In `main.py`, lines 30-31 show the feature and target extraction:

```python
df = pd.read_csv(DATA / "sleep_screen.csv")
X = df[["screen_time_hours"]]
y = df["sleep_hours"]
```

---

## 7. Line-by-Line Code Breakdown
- `df = pd.read_csv(...)`: Ingests the tabular CSV containing paired feature and target observations.
- `X = df[["screen_time_hours"]]`: Selects the independent feature column as a 2D pandas DataFrame.
- `y = df["sleep_hours"]`: Selects the continuous target column as a 1D pandas Series.

---

## 8. Worked Examples and Calculations
Consider two different modeling approaches for a patient who sleeps 6.7 hours:
- **Classification Approach:** Assigns the label "Suboptimal" (loses exact quantity).
- **Regression Approach:** Predicts $\hat{y} = 6.64$ hours. Error is $|6.7 - 6.64| = 0.06$ hours (3.6 minutes).
Regression provides fine-grained, quantitative feedback that enables precise lifestyle adjustments.

---

## 9. Step-by-Step Student Implementation Instructions
1. Inspect the columns in `data/sleep_screen.csv`.
2. Check the data type of `df['sleep_hours']` using `df['sleep_hours'].dtype`. Confirm it is `float64`.
3. Verify that `y` represents continuous numeric values rather than string labels.

---

## 10. Expected Output and Observable Behavior
Printing `y.head()` reveals floating-point numbers:
```text
0    8.4
1    6.8
2    6.7
3    7.9
4    6.9
Name: sleep_hours, dtype: float64
```
This confirms that the target variable is continuous.

---

## 11. Practical Exercises and Mini-Tasks
- **Task 1:** Identify whether predicting "Sleep Quality: Poor, Fair, Excellent" is regression or classification.
- **Task 2:** Identify whether predicting "Minutes to Fall Asleep" is regression or classification.

---

## 12. Common Mistakes, Pitfalls, and Debugging
- **Misidentifying Regression as Classification:** Assuming that because sleep is often rounded to integers or half-hours, it is a classification problem. It remains a continuous metric.
- **Shape Errors:** Passing a 1D Series for $X$ when fitting a scikit-learn estimator. $X$ must be 2D, while $y$ can be 1D.

---

## 13. Best Practices and Responsible Data Science Considerations
When selecting between regression and classification, evaluate how decision-makers will use the output. Continuous numerical predictions can always be discretized later into clinical categories if required, but discrete labels cannot be converted back into exact hours.

---

## 14. Summary and Key Takeaways
- Supervised learning uses labeled training pairs $(X, y)$.
- Regression predicts continuous real-valued outputs ($y \in \mathbb{R}$).
- Sleep duration is measured in continuous hours, making linear regression the appropriate tool.

---

## 15. Knowledge Check Questions and References
1. What defines a machine learning task as "supervised"?
2. What distinguishes regression from classification?
3. What is the pandas data type of `sleep_hours` in our dataset?

*References:*
- Bishop, C. M. (2006). *Pattern Recognition and Machine Learning*. Springer.
- Scikit-learn User Guide: *Supervised Learning: Linear Models*.
