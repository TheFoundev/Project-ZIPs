# Lesson 04: Project Anatomy and System Pipeline: Understanding main.py

**Lesson ID:** lesson-04  
**Module:** module-01  
**Estimated Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives
The purpose of this lesson is to dissect the file architecture, execution flow, and script anatomy of `main.py`. By the end of this lesson, you will be able to:
- Navigate the project directory structure and locate input and output files.
- Explain the role of `Path(__file__).resolve().parent` for robust path resolution.
- Describe why `matplotlib.use("Agg")` is specified for headless script execution.
- Trace the lifecycle of data from CSV ingestion through model fitting to artifact generation.

---

## 2. Prerequisites and Required Tools
Basic Python file execution knowledge, terminal navigation commands (`cd`, `ls`), and basic familiarity with the `pathlib` module.

---

## 3. Core Concept Explanation
A production-grade machine learning script follows a systematic pipeline:
1. **Configuration & Environment Setup:** Importing libraries and setting non-interactive rendering backends.
2. **Directory & Path Resolution:** Guaranteeing that file paths resolve relative to the script's physical location rather than the user's current shell working directory.
3. **Data Loading & Preprocessing:** Ingesting raw CSV tables and preparing feature matrices.
4. **Model Training & Evaluation:** Calibrating weights and evaluating on unseen test sets.
5. **Artifact Persistence:** Storing trained model outputs, plots, and text summaries for external review.

---

## 4. Real-World Relevance and Sleep Science Context
In health data pipelines, reproducibility is paramount. Researchers running analyses across diverse server environments or automated test runners require headless execution and unambiguous path resolution so scripts execute without manual GUI intervention.

---

## 5. Mathematical and Theoretical Foundations
Linear regression software pipelines map raw observational tuples:
$$\mathcal{D} = \{(x_1, y_1), (x_2, y_2), \dots, (x_N, y_N)\}$$
into mathematical objects: a feature matrix $\mathbf{X} \in \mathbb{R}^{N \times 1}$ and a target vector $\mathbf{y} \in \mathbb{R}^N$. The pipeline then partitions these into:
$$\mathcal{D}_{train} \cup \mathcal{D}_{test} = \mathcal{D}, \quad \mathcal{D}_{train} \cap \mathcal{D}_{test} = \emptyset$$
ensuring unbiased performance validation.

---

## 6. Relevant Code Implementation
Examine lines 10-26 in `main.py`:

```python
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)
```

---

## 7. Line-by-Line Code Breakdown
- `matplotlib.use("Agg")`: Configures Matplotlib to use the Anti-Grain Geometry (Agg) engine, rendering raster PNGs without attempting to launch an X11/Wayland display window.
- `BASE = Path(__file__).resolve().parent`: Resolves the absolute directory containing `main.py`, making the script independent of the caller's working directory.
- `DATA = BASE / "data"`: Points cleanly to the data folder containing `sleep_screen.csv`.
- `OUT = BASE / "outputs"`: Defines the destination for generated plots and metrics.
- `OUT.mkdir(exist_ok=True)`: Safely creates the outputs directory if it does not already exist.

---

## 8. Worked Examples and Calculations
Suppose a user executes the script from their home directory:
```bash
cd ~
python /home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML\ Beginners/projects/10_sleep_screen_time/main.py
```
If relative string paths like `"data/sleep_screen.csv"` were used, Python would look in `~/data/` and raise `FileNotFoundError`. By utilizing `Path(__file__).resolve().parent`, `BASE / "data"` reliably locates the file regardless of where the command was initiated.

---

## 9. Step-by-Step Student Implementation Instructions
1. Open `main.py` and inspect the imports at lines 10-20.
2. Verify where `BASE`, `DATA`, and `OUT` are declared.
3. Locate the `main()` function definition and observe where `OUT.mkdir(exist_ok=True)` is called.
4. Run `python main.py` and check the contents of `outputs/`.

---

## 10. Expected Output and Observable Behavior
Running the script should terminate cleanly with code 0 and display:
```text
Saved: outputs/sleep_regression.png, outputs/metrics.txt
```
Listing the `outputs/` folder confirms both artifacts exist.

---

## 11. Practical Exercises and Mini-Tasks
- **Task 1:** Explain what happens if `matplotlib.use("Agg")` is omitted in an environment without a desktop graphical server (such as Docker or a cloud VM).
- **Task 2:** Why is `exist_ok=True` passed to `OUT.mkdir()`?

---

## 12. Common Mistakes, Pitfalls, and Debugging
- **Importing `pyplot` Before Setting the Backend:** Calling `import matplotlib.pyplot as plt` before `matplotlib.use("Agg")` can cause Matplotlib to bind to a GUI backend prematurely, triggering runtime errors on headless systems.
- **Hardcoding Absolute OS Paths:** Writing `/home/user/...` which breaks when the project is cloned onto a different computer. Always use `Path(__file__)`.

---

## 13. Best Practices and Responsible Data Science Considerations
Always separate raw immutable data (`data/`) from generated analytical artifacts (`outputs/`). Keep pipeline scripts modular, deterministic, and self-contained.

---

## 14. Summary and Key Takeaways
- `main.py` encapsulates an automated, reproducible machine learning pipeline.
- `pathlib.Path` ensures platform-agnostic file system resolution.
- `matplotlib.use("Agg")` guarantees reliable image rendering across all environments.
- The pipeline systematically ingests data, fits a regression line, logs metrics, and exports charts.

---

## 15. Knowledge Check Questions and References
1. What error does `matplotlib.use("Agg")` prevent in headless servers?
2. How does `Path(__file__).resolve().parent` ensure portability?
3. What two files are saved in the `outputs/` directory?

*References:*
- Python Standard Library: `pathlib` documentation.
- Matplotlib User Guide: *What is a backend?*.
