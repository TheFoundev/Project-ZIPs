# Lesson 01: The Sleep & Screen Time Mystery: Problem Overview

**Lesson ID:** lesson-01  
**Module:** module-01  
**Estimated Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives
The primary purpose of this lesson is to introduce the real-world behavioral and biological problem modeled in **The Sleep vs Screen Time Analyzer**. By the end of this lesson, you will be able to:
- State the core research question: How does evening screen exposure correlate with nightly sleep duration?
- Explain why predicting sleep hours is framed as a supervised regression task rather than a classification task.
- Identify the feature (screen time in hours) and target variable (sleep in hours).
- Describe the expected behavioral trend between evening screen time and total sleep.

---

## 2. Prerequisites and Required Tools
To succeed in this lesson, you should be familiar with basic arithmetic and high school Cartesian graphs ($x$ and $y$ axes). You will need Python 3.8+ installed on your workstation, along with a code editor or terminal.

---

## 3. Core Concept Explanation
In modern society, digital devices such as smartphones, tablets, laptops, and televisions have become ubiquitous bedside companions. Sleep researchers, psychologists, and clinicians have long observed that individuals who spend extensive hours looking at luminous screens before retiring to bed frequently report fewer total hours of restful sleep.

In machine learning, we formalize this everyday observation into a **supervised prediction problem**. Rather than guessing arbitrarily, we collect empirical measurements from individuals and train an algorithm to discover the underlying mathematical relationship between evening screen exposure and sleep duration.

---

## 4. Real-World Relevance and Sleep Science Context
Sleep is a biological necessity directly regulated by circadian rhythms and neurochemical signaling. Exposure to short-wavelength blue light emitted by LED screens suppresses the natural secretion of **melatonin**, the hormone that signals to the brain that it is time to sleep. Furthermore, interactive screen activities—such as browsing social media, gaming, or answering work emails—induce psychological arousal and delay bedtime.

Understanding this relationship with data science provides valuable tools for digital wellness apps, sleep trackers, and public health educators seeking to promote healthy sleep habits.

---

## 5. Mathematical and Theoretical Foundations
We frame our problem within the supervised learning paradigm:
- **Feature ($X$):** The independent or explanatory variable, denoted as $x$. Here, $x = \text{screen\_time\_hours}$.
- **Target ($y$):** The dependent or response variable, denoted as $y$. Here, $y = \text{sleep\_hours}$.
- **Mapping Function ($f$):** We seek a function $f$ such that:
  $$\hat{y} = f(x)$$
  where $\hat{y}$ represents the predicted hours of sleep.

Because sleep hours can take any continuous decimal value (e.g., 7.2 hours, 6.5 hours, 8.4 hours), this task is categorized as **regression**.

---

## 6. Relevant Code Implementation
The project header in `main.py` introduces this core theme:

```python
"""Project 10: The Sleep vs. Screen Time Detective (linear regression).

Run:
    python main.py

A correlation project: the model finds a trend, but the script also reminds
you that a trend is not proof of cause and effect.
"""
```

---

## 7. Line-by-Line Code Breakdown
- **Docstring line 1:** Explicitly states the project title and algorithm: "linear regression".
- **Docstring lines 3-4:** Shows the command-line entry point (`python main.py`).
- **Docstring lines 6-7:** Establishes the foundational scientific perspective: the model detects statistical trends, but statistical association does not equal clinical proof of cause and effect.

---

## 8. Worked Examples and Calculations
Imagine a participant records the following data over three nights:
- Night 1: 1.0 hour of screen time $\rightarrow$ 8.8 hours of sleep.
- Night 2: 3.0 hours of screen time $\rightarrow$ 7.5 hours of sleep.
- Night 3: 5.0 hours of screen time $\rightarrow$ 6.4 hours of sleep.

Notice the numerical pattern: as screen hours increase from 1.0 to 5.0, sleep hours decrease from 8.8 to 6.4. The algorithm will formalize this pattern into a line of best fit.

---

## 9. Step-by-Step Student Implementation Instructions
1. Open your terminal and navigate to the project directory.
2. Open `main.py` in your code editor and read the top-level docstring.
3. Identify the input feature variable ($X$) and the output target variable ($y$).
4. Note the research question: "Given $X$ hours of pre-bed screen time, how many hours of sleep ($y$) can we expect?"

---

## 10. Expected Output and Observable Behavior
When observing this project, you should expect to see an inverse relationship. Unlike sales models where higher inputs yield higher outputs, here higher screen time is associated with lower sleep duration.

---

## 11. Practical Exercises and Mini-Tasks
- **Task 1:** Write down the definition of an independent feature ($X$) and a dependent target ($y$).
- **Task 2:** If an individual logs 0 hours of screen time, do you expect their sleep duration to be higher or lower than someone who logs 5 hours? Why?

---

## 12. Common Mistakes, Pitfalls, and Debugging
- **Confusing Feature and Target:** Reversing $X$ and $y$ (e.g., trying to predict screen time from sleep hours). While mathematically possible, the causal and behavioral inquiry asks how screen habits affect sleep.
- **Treating Sleep as Discrete:** Assuming sleep duration is a category (e.g., "Good" vs "Bad") rather than a continuous numeric measurement.

---

## 13. Best Practices and Responsible Data Science Considerations
Always define the research hypothesis before looking at the data. In health-related data science, be mindful of user privacy and avoid claiming absolute certainty when dealing with observational human data.

---

## 14. Summary and Key Takeaways
- The Sleep vs Screen Time Analyzer models the relationship between pre-bed screen exposure and sleep hours.
- The task is a supervised regression problem with continuous numeric variables.
- We expect an inverse (negative) relationship: increased screen time corresponds to decreased sleep.

---

## 15. Knowledge Check Questions and References
1. What is the dependent target variable in this project?
2. Why is this problem formulated as regression rather than classification?
3. What biological factor links screen exposure to sleep onset?

*References:*
- Harvard Medical School, Division of Sleep Medicine: *External Factors Influencing Sleep Quality* (2022).
- Scikit-learn Documentation: *Supervised Learning Overview*.
