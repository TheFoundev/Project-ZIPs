# Lesson 02: Visualizing the Inverse Relationship with Scatter Plots

**Lesson ID:** lesson-02  
**Module:** module-02  
**Estimated Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives
The purpose of this lesson is to learn how to visualize bivariate relationships using Cartesian scatter plots with `matplotlib`. By the end of this lesson, you will be able to:
- Create a scatter plot placing `screen_time_hours` on the x-axis and `sleep_hours` on the y-axis.
- Identify the visual hallmarks of an inverse (downward) relationship.
- Customize scatter plot aesthetics (markers, colors, opacity, labels, and grid).
- Recognize why visual inspection is essential before fitting linear models.

---

## 2. Prerequisites and Required Tools
Understanding Cartesian coordinate plotting ($x, y$ coordinates) and basic Matplotlib syntax (`plt.subplots()`, `ax.scatter()`).

---

## 3. Core Concept Explanation
A **scatter plot** represents individual data points as markers in a 2-dimensional space. The horizontal position corresponds to the independent variable ($X$), and the vertical position corresponds to the dependent variable ($y$).

When viewing a scatter plot of negatively correlated data:
- Points on the left side (low $X$) are positioned high up on the y-axis.
- Points on the right side (high $X$) are positioned low down on the y-axis.
- The overall cloud of points forms an elongated oval or band that angles downward from the top-left to the bottom-right.

---

## 4. Real-World Relevance and Sleep Science Context
Visualizing sleep data allows clinicians and researchers to detect whether the relationship is strictly linear, non-linear (e.g., sleep drops off sharply after 2 hours and plateaus), or clustered into distinct subpopulations. In our observational dataset, the points show a clear, steady downward progression.

---

## 5. Mathematical and Theoretical Foundations
Let each participant $i$ be an ordered pair $(x_i, y_i)$. In a scatter plot:
- The domain spans $[\min(x), \max(x)] = [0.8, 5.5]$.
- The range spans $[\min(y), \max(y)] = [5.4, 9.6]$.

Visual inspection helps verify the primary assumption of linear regression: that the conditional expectation $\mathbb{E}[Y|X=x]$ can be approximated by a linear function $\beta_0 + \beta_1 x$.

---

## 6. Relevant Code Implementation
In `main.py`, lines 61-70 construct the figure and plot the scatter points:

```python
fig, ax = plt.subplots(figsize=(7, 5))
ax.scatter(X_train, y_train, color="#2c3e50", s=55, label="training data")
ax.scatter(X_test, y_test, color="#e67e22", s=65, marker="s", label="test data")
ax.set_xlabel("Screen time before bed (hours)")
ax.set_ylabel("Sleep (hours)")
ax.set_title("Screen time vs. sleep duration")
ax.legend()
ax.grid(alpha=0.25)
```

---

## 7. Line-by-Line Code Breakdown
- `fig, ax = plt.subplots(figsize=(7, 5))`: Instantiates a figure canvas of width 7 inches and height 5 inches, returning the figure and axis handles.
- `ax.scatter(X_train, y_train, color="#2c3e50", s=55, ...)`: Plots the 26 training data points as navy blue circular markers with size 55.
- `ax.scatter(X_test, y_test, color="#e67e22", s=65, marker="s", ...)`: Plots the 9 test data points as orange square markers (`marker="s"`).
- `ax.set_xlabel(...)` and `ax.set_ylabel(...)`: Assigns meaningful human-readable labels with measurement units (hours).
- `ax.grid(alpha=0.25)`: Adds a subtle background coordinate grid with 25% opacity to aid visual estimation.

---

## 8. Worked Examples and Calculations
Look at two contrasting data points on the plot:
- Participant A: $(0.8, 9.6)$ $\rightarrow$ Placed at far left ($x=0.8$), near the very top ($y=9.6$).
- Participant B: $(5.5, 5.9)$ $\rightarrow$ Placed at far right ($x=5.5$), near the very bottom ($y=5.9$).
Connecting these points with a mental line immediately demonstrates a steep downward angle.

---

## 9. Step-by-Step Student Implementation Instructions
1. In your Python environment, import `matplotlib.pyplot as plt`.
2. Extract the features: `x = df['screen_time_hours']` and `y = df['sleep_hours']`.
3. Call `plt.figure(figsize=(7, 5))`.
4. Call `plt.scatter(x, y, color="blue", alpha=0.7)`.
5. Add axis labels: `plt.xlabel("Screen Time (Hours)")` and `plt.ylabel("Sleep Duration (Hours)")`.
6. Save the plot to verify the downward pattern: `plt.savefig("my_scatter.png")`.

---

## 10. Expected Output and Observable Behavior
The saved image displays a clear downward diagonal distribution of points. There are no sudden curved clusters or quadratic turns, confirming that a linear model is an appropriate first-order approximation.

---

## 11. Practical Exercises and Mini-Tasks
- **Task 1:** Change the marker shape of the scatter plot from circles to triangles using `marker="^"`.
- **Task 2:** Why is it helpful to display training data and test data with different colors and shapes?

---

## 12. Common Mistakes, Pitfalls, and Debugging
- **Swapping Axes:** Putting `sleep_hours` on the x-axis and `screen_time_hours` on the y-axis. While the math would still produce a negative slope, convention dictates that the independent feature belongs on the horizontal x-axis and the predicted target on the vertical y-axis.
- **Missing Units in Labels:** Writing simply "Screen" and "Sleep" instead of "Screen time before bed (hours)" and "Sleep (hours)". Units are critical in scientific communication.

---

## 13. Best Practices and Responsible Data Science Considerations
Always plot raw data before fitting models. Statistical metrics like correlation or mean can obscure patterns like Anscombe's Quartet, where wildly different data distributions yield identical summary numbers.

---

## 14. Summary and Key Takeaways
- A scatter plot visually confirms the relationship between two continuous variables.
- The sleep vs screen time scatter plot exhibits a downward trend from upper-left to lower-right.
- Matplotlib allows distinguishing train and test partitions through distinct colors and marker shapes.

---

## 15. Knowledge Check Questions and References
1. What does a downward-sloping cloud of points in a scatter plot indicate?
2. Which variable is placed on the horizontal x-axis by convention?
3. What parameter in `ax.scatter()` controls marker size?

*References:*
- Hunter, J. D. (2007). *Matplotlib: A 2D graphics environment*. Computing in Science & Engineering.
- Anscombe, F. J. (1973). *Graphs in Statistical Analysis*. The American Statistician.
