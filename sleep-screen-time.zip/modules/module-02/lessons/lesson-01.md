# Lesson 01: Ingesting and Auditing Observational Data with Pandas

**Lesson ID:** lesson-01  
**Module:** module-02  
**Estimated Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives
The purpose of this lesson is to learn how to import, inspect, and mathematically audit tabular observational data using the `pandas` library. By the end of this lesson, you will be able to:
- Use `pd.read_csv()` with `pathlib.Path` to load `data/sleep_screen.csv`.
- Inspect DataFrame shape, data types, and index characteristics.
- Generate descriptive summary statistics with `.describe()`.
- Identify the exact range, mean, and dispersion of `screen_time_hours` and `sleep_hours`.

---

## 2. Prerequisites and Required Tools
Basic familiarity with Python data structures and virtual environment setup. You will need `pandas` installed and a terminal environment.

---

## 3. Core Concept Explanation
In any data science workflow, the raw data file is the foundation of all subsequent inferences. Before executing machine learning algorithms, a data scientist must verify the integrity of the data:
- Are there missing (null) values?
- Are the column names formatted cleanly?
- Are the numerical types continuous floats rather than strings?
- Are the values physically plausible within human biological bounds?

The pandas `DataFrame` provides powerful tabular methods to audit these properties efficiently.

---

## 4. Real-World Relevance and Sleep Science Context
In clinical sleep research, self-reported screen time typically ranges from 0 to 6 hours before bed, while healthy adult sleep spans 6 to 9 hours. An audit of observational records ensures that outliers—such as impossible entries like 35 hours of sleep in one night—are identified before training a model.

---

## 5. Mathematical and Theoretical Foundations
For a dataset with $N$ rows and $P$ columns, the DataFrame is an $N \times P$ matrix. Here:
$$N = 35 \quad \text{(observational records)}, \quad P = 2 \quad \text{(variables)}$$
Descriptive statistics summarize the central tendency and spread of each variable:
- **Sample Mean:** $\bar{x} = \frac{1}{N}\sum_{i=1}^N x_i$
- **Sample Standard Deviation:** $s = \sqrt{\frac{1}{N-1}\sum_{i=1}^N (x_i - \bar{x})^2}$
- **Extrema:** $\min(x)$ and $\max(x)$.

---

## 6. Relevant Code Implementation
In `main.py`, lines 29-31 initialize data ingestion:

```python
df = pd.read_csv(DATA / "sleep_screen.csv")
print(df.info())
print(df.describe())
```

---

## 7. Line-by-Line Code Breakdown
- `pd.read_csv(DATA / "sleep_screen.csv")`: Reads the comma-separated file into a pandas DataFrame object named `df`.
- `DATA / "sleep_screen.csv"`: Resolves the exact path using `pathlib.Path`.
- `df.info()`: Confirms that there are 35 non-null rows and that both columns are of type `float64`.
- `df.describe()`: Computes count, mean, std, min, 25%, 50% (median), 75%, and max.

---

## 8. Worked Examples and Calculations
Let us examine the descriptive statistics of our dataset:
- `screen_time_hours`:
  - Minimum: $0.8$ hours
  - Maximum: $5.5$ hours
  - Mean: $\approx 3.32$ hours
- `sleep_hours`:
  - Minimum: $5.4$ hours
  - Maximum: $9.6$ hours
  - Mean: $\approx 7.34$ hours

Notice that all recorded sleep durations are strictly between 5.4 and 9.6 hours—plausible biological figures for human sleep.

---

## 9. Step-by-Step Student Implementation Instructions
1. Launch an interactive Python REPL or script.
2. Import pandas: `import pandas as pd`.
3. Load the dataset: `df = pd.read_csv("data/sleep_screen.csv")`.
4. Run `df.head(5)` to see the first 5 records.
5. Verify the shape of the DataFrame using `df.shape`. Confirm it outputs `(35, 2)`.

---

## 10. Expected Output and Observable Behavior
Running `df.head()` produces:
```text
   screen_time_hours  sleep_hours
0                1.9          8.4
1                5.1          6.8
2                4.6          6.7
3                2.0          7.9
4                4.7          6.9
```
Notice that record 0 (1.9 hours screen time) has 8.4 hours of sleep, whereas record 1 (5.1 hours screen time) has only 6.8 hours of sleep.

---

## 11. Practical Exercises and Mini-Tasks
- **Task 1:** Write a one-line pandas expression to check if any null values exist in `df`.
- **Task 2:** Calculate the median sleep duration using `df['sleep_hours'].median()`.

---

## 12. Common Mistakes, Pitfalls, and Debugging
- **Passing a String Path Without Directory Verification:** Writing `pd.read_csv("sleep_screen.csv")` instead of `DATA / "sleep_screen.csv"`. If the current shell working directory is not the project root, this throws `FileNotFoundError`.
- **Ignoring Data Types:** Assuming CSV columns are automatically numeric. If a single string (like "N/A" or "?") is present, pandas imports the whole column as `object`, which breaks mathematical operations.

---

## 13. Best Practices and Responsible Data Science Considerations
Always perform an exploratory data audit (`.info()`, `.describe()`, `.isna().sum()`) before passing data into machine learning estimators. Data quality directly limits model quality ("garbage in, garbage out").

---

## 14. Summary and Key Takeaways
- The dataset `sleep_screen.csv` contains 35 paired records of `screen_time_hours` and `sleep_hours`.
- `pd.read_csv()` loads tabular data into a 2D DataFrame.
- Both columns contain continuous floating-point measurements spanning biologically plausible ranges.

---

## 15. Knowledge Check Questions and References
1. How many total observational rows are in `sleep_screen.csv`?
2. What are the two column names in the dataset?
3. What pandas method provides summary statistics (mean, std, min, max)?

*References:*
- McKinney, W. (2017). *Python for Data Analysis*. O'Reilly Media.
- Pandas API Documentation: `pandas.read_csv`.
