# Lesson 04: Preparing Feature Matrices (X) and Target Vectors (y)

**Lesson ID:** lesson-04  
**Module:** module-02  
**Estimated Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives
The purpose of this lesson is to master the data preparation and matrix dimensionality conventions required by scikit-learn. By the end of this lesson, you will be able to:
- Explain why scikit-learn requires features ($X$) as a 2D matrix and targets ($y$) as a 1D vector.
- Differentiate single bracket `df["column"]` from double bracket `df[["column"]]` syntax in pandas.
- Verify array shapes using `.shape` before model training.
- Prevent and debug the common `ValueError: Expected 2D array, got 1D array instead`.

---

## 2. Prerequisites and Required Tools
Understanding pandas Series vs DataFrame distinctions and NumPy dimensional shapes.

---

## 3. Core Concept Explanation
Scikit-learn is architected with a strict, consistent API design:
- **Feature Matrix ($X$):** Must be a 2-dimensional structure of shape `(n_samples, n_features)`. Even when there is only a single feature (univariate regression), scikit-learn requires the shape to be `(N, 1)`.
- **Target Vector ($y$):** For single-output regression, scikit-learn expects a 1-dimensional structure of shape `(n_samples,)`.

In pandas:
- `df["col"]` returns a **pandas Series** (1D, shape `(N,)`).
- `df[["col"]]` returns a **pandas DataFrame** (2D, shape `(N, 1)`).

---

## 4. Real-World Relevance and Sleep Science Context
In professional ML workflows, models often start with a single feature (such as `screen_time_hours`) and later expand to include additional features (such as `caffeine_mg`, `bedtime_hour`, or `age`). By requiring $X$ to always be 2-dimensional, scikit-learn's interface remains completely identical whether you have 1 feature or 1,000 features.

---

## 5. Mathematical and Theoretical Foundations
Linear algebra defines regression in matrix notation:
$$\mathbf{y} = \mathbf{X} \boldsymbol{\beta} + \boldsymbol{\varepsilon}$$
where:
- $\mathbf{X} \in \mathbb{R}^{N \times P}$ is the design matrix.
- $\boldsymbol{\beta} \in \mathbb{R}^{P \times 1}$ is the parameter vector.
- $\mathbf{y} \in \mathbb{R}^{N \times 1}$ (or $\mathbb{R}^N$) is the target vector.

If $\mathbf{X}$ were a 1D vector of shape $(N,)$, matrix multiplication $\mathbf{X}\boldsymbol{\beta}$ would fail due to dimension mismatch. Maintaining 2D shape preserves matrix compatibility.

---

## 6. Relevant Code Implementation
In `main.py`, lines 30-31 define $X$ and $y$:

```python
X = df[["screen_time_hours"]]
y = df["sleep_hours"]
```

---

## 7. Line-by-Line Code Breakdown
- `df[["screen_time_hours"]]`: Notice the outer and inner brackets `[[ ... ]]`. The inner list `["screen_time_hours"]` tells pandas to return a subset DataFrame with shape `(35, 1)`.
- `df["sleep_hours"]`: Uses single brackets `[ ... ]`, returning a pandas Series with shape `(35,)`.

---

## 8. Worked Examples and Calculations
Let us examine the shapes produced by each indexing approach:

```python
series_x = df["screen_time_hours"]
dataframe_x = df[["screen_time_hours"]]

print("Single brackets shape:", series_x.shape)      # Output: (35,)
print("Double brackets shape:", dataframe_x.shape)  # Output: (35, 1)
```

Passing `series_x` into `LinearRegression().fit(series_x, y)` immediately triggers:
`ValueError: Expected 2D array, got 1D array instead: array=[1.9 5.1 4.6 ...]. Reshape your data either using array.reshape(-1, 1) if your data has a single feature or array.reshape(1, -1) if it contains a single sample.`

Using double brackets avoids this error entirely!

---

## 9. Step-by-Step Student Implementation Instructions
1. Load `df = pd.read_csv("data/sleep_screen.csv")`.
2. Extract $X$ using double brackets: `X = df[["screen_time_hours"]]`.
3. Check shape: `print("X shape:", X.shape)`. Confirm it is `(35, 1)`.
4. Extract $y$ using single brackets: `y = df["sleep_hours"]`.
5. Check shape: `print("y shape:", y.shape)`. Confirm it is `(35,)`.

---

## 10. Expected Output and Observable Behavior
Verifying the extracted variables reveals:
```text
X shape: (35, 1)
y shape: (35,)
type(X): <class 'pandas.core.frame.DataFrame'>
type(y): <class 'pandas.core.series.Series'>
```
Both variables are now perfectly formatted for scikit-learn.

---

## 11. Practical Exercises and Mini-Tasks
- **Task 1:** If you had two features, `screen_time_hours` and `caffeine_cups`, write the pandas syntax to extract them into $X$.
- **Task 2:** Use NumPy's `.values.reshape(-1, 1)` on a 1D Series and verify that it matches the shape of a double-bracketed DataFrame.

---

## 12. Common Mistakes, Pitfalls, and Debugging
- **Accidental Single Brackets for Features:** Typing `X = df["screen_time_hours"]` is the most common beginner error in scikit-learn. Remember: **Features need 2D (double brackets), Target needs 1D (single bracket)**.
- **Double Brackets for Target:** Writing `y = df[["sleep_hours"]]`. While some algorithms tolerate a 2D column vector for $y$, scikit-learn issues a `DataConversionWarning` advising that a 1D array was expected.

---

## 13. Best Practices and Responsible Data Science Considerations
Always print the `.shape` attribute of $X$ and $y$ immediately after extraction. Catching shape discrepancies before splitting and model fitting saves significant debugging time.

---

## 14. Summary and Key Takeaways
- Scikit-learn estimators mandate that the feature matrix $X$ is 2-dimensional: `(n_samples, n_features)`.
- In pandas, double brackets `df[["col"]]` produce a 2D DataFrame `(N, 1)`.
- Target $y$ is a 1D Series `(N,)` extracted with single brackets `df["col"]`.

---

## 15. Knowledge Check Questions and References
1. What is the shape of `df[["screen_time_hours"]]`?
2. What error occurs if you pass a 1D array as $X$ to `LinearRegression().fit()`?
3. Why does scikit-learn enforce a 2D structure even for single-feature models?

*References:*
- Buitinck, L., et al. (2013). *API design for machine learning software: experiences from the scikit-learn project*.
- Scikit-learn Common Pitfalls and Shape Conventions.
