# Lesson 03: The Pearson Correlation Coefficient in Depth

**Lesson ID:** lesson-03  
**Module:** module-02  
**Estimated Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives
The purpose of this lesson is to master the mathematical definition, calculation, and interpretation of the **Pearson correlation coefficient ($r$)**. By the end of this lesson, you will be able to:
- State the mathematical formula for Pearson's $r$.
- Explain why correlation values are bounded between $-1.0$ and $+1.0$.
- Interpret the magnitude and sign of $r = -0.85$ calculated from the sleep dataset.
- Distinguish between correlation (standardized association) and regression slope (unstandardized rate of change).

---

## 2. Prerequisites and Required Tools
Understanding of mean, variance, covariance, and standard deviation. Python knowledge of pandas `.corr()`.

---

## 3. Core Concept Explanation
While a scatter plot provides a qualitative visual impression of an association, data scientists require a standardized quantitative metric. The **Pearson correlation coefficient** ($r$) measures the strength and direction of the linear relationship between two continuous variables.

Key properties of Pearson's $r$:
- **Range:** $-1.0 \le r \le +1.0$.
- **$r = +1.0$:** Perfect positive linear relationship (all points lie exactly on an upward line).
- **$r = 0.0$:** No linear association between the variables.
- **$r = -1.0$:** Perfect negative linear relationship (all points lie exactly on a downward line).
- **Sign:** Dictates direction ($+$ is direct, $-$ is inverse).
- **Magnitude ($|r|$):** Dictates strength ($0.1$ to $0.3$ is weak, $0.3$ to $0.5$ is moderate, $> 0.7$ is strong).

---

## 4. Real-World Relevance and Sleep Science Context
In our study, the Pearson correlation coefficient between evening screen time and sleep duration is:
$$r = -0.85$$
In behavioral and psychological science, $|r| = 0.85$ is considered a remarkably **strong** relationship. It indicates that individuals with above-average screen time consistently experience below-average sleep duration.

---

## 5. Mathematical and Theoretical Foundations
For paired observations $(x_1, y_1), \dots, (x_N, y_N)$, Pearson's $r$ is defined as the covariance of $X$ and $Y$ divided by the product of their standard deviations:
$$r = \frac{\sum_{i=1}^N (x_i - \bar{x})(y_i - \bar{y})}{\sqrt{\sum_{i=1}^N (x_i - \bar{x})^2} \sqrt{\sum_{i=1}^N (y_i - \bar{y})^2}}$$

Equivalently, it is the average product of the standardized $z$-scores:
$$r = \frac{1}{N-1} \sum_{i=1}^N \left( \frac{x_i - \bar{x}}{s_x} \right) \left( \frac{y_i - \bar{y}}{s_y} \right)$$

Because $r$ is standardized by the standard deviations $s_x$ and $s_y$, it is unitless. Whether screen time is measured in hours or seconds, $r$ remains exactly $-0.85$.

---

## 6. Relevant Code Implementation
In `main.py`, line 45 computes the correlation:

```python
correlation = float(df["screen_time_hours"].corr(df["sleep_hours"]))
print(f"Correlation: {correlation:.2f} (negative means they move in opposite directions)")
```

---

## 7. Line-by-Line Code Breakdown
- `df["screen_time_hours"].corr(df["sleep_hours"])`: Calls the pandas Series `.corr()` method, which calculates the sample Pearson correlation coefficient between the two columns.
- `float(...)`: Converts the resulting numpy/pandas float scalar into a native Python float for formatting.
- `f"Correlation: {correlation:.2f}"`: Formats the value to two decimal places, producing `-0.85`.

---

## 8. Worked Examples and Calculations
Consider how the signs in the formula create a negative sum:
- When a student has high screen time ($x_i > \bar{x}$), their term $(x_i - \bar{x})$ is **positive** ($+$).
- That same student has low sleep ($y_i < \bar{y}$), so their term $(y_i - \bar{y})$ is **negative** ($-$).
- The product $(+) \times (-) = (-)$ is **negative**!
- When a student has low screen time ($x_i < \bar{x}$), their term is **negative** ($-$).
- Their sleep is high ($y_i > \bar{y}$), so their term is **positive** ($+$).
- The product $(-) \times (+) = (-)$ is also **negative**!
Summing these negative products across all 35 participants results in a negative numerator, yielding $r = -0.85$.

---

## 9. Step-by-Step Student Implementation Instructions
1. Load the dataset in pandas: `df = pd.read_csv("data/sleep_screen.csv")`.
2. Compute correlation: `r = df['screen_time_hours'].corr(df['sleep_hours'])`.
3. Print the result: `print("Calculated r:", r)`.
4. Verify that the output is approximately `-0.8504`.

---

## 10. Expected Output and Observable Behavior
Printing the calculation yields:
```text
Calculated r: -0.8504037578846358
```
This confirms a strong inverse linear relationship.

---

## 11. Practical Exercises and Mini-Tasks
- **Task 1:** What would $r = -1.0$ look like on a scatter plot?
- **Task 2:** If you converted `screen_time_hours` into minutes by multiplying by 60, would the Pearson correlation coefficient change? Why or why not?

---

## 12. Common Mistakes, Pitfalls, and Debugging
- **Confusing Correlation with Slope:** Slope has measurement units (hours of sleep per hour of screen time) and depends on the scale. Correlation is dimensionless and scale-invariant. A slope could be $-0.01$ or $-100.0$, but correlation is always strictly between $-1$ and $+1$.
- **Believing Correlation Proves Linearity:** A high correlation indicates a strong linear tendency, but extreme outliers can artificially inflate or deflate $r$. Always check the scatter plot.

---

## 13. Best Practices and Responsible Data Science Considerations
Report both the magnitude and sign when discussing correlation. Clearly state whether the correlation is statistically significant and avoid using causal language like "screen time caused an 85% drop in sleep."

---

## 14. Summary and Key Takeaways
- Pearson correlation coefficient ($r$) measures the strength and direction of linear association.
- $r$ ranges from $-1.0$ (perfect negative) to $+1.0$ (perfect positive).
- In our dataset, $r = -0.85$, demonstrating a strong negative correlation between screen time and sleep.

---

## 15. Knowledge Check Questions and References
1. What is the theoretical minimum and maximum value for Pearson's $r$?
2. What does $r = -0.85$ indicate about the strength of the association?
3. Why is Pearson's $r$ invariant to linear unit conversions (e.g., hours to minutes)?

*References:*
- Pearson, K. (1895). *Notes on regression and inheritance in the case of two parents*. Proceedings of the Royal Society of London.
- Rodgers, J. L., & Nicewander, W. A. (1988). *Thirteen ways to look at the correlation coefficient*. The American Statistician.
