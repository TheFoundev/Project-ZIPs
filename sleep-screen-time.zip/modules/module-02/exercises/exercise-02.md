# Module 02 Exercises: Data Exploration and Negative Correlation

---

## Exercise 2.1: Dataset Auditing and Summary Statistics
**Objective:** Load `data/sleep_screen.csv`, audit data integrity, and calculate descriptive summary statistics.

### Problem Statement
Before training models, a data scientist must verify that the raw data contains no missing records and falls within plausible ranges. You will audit the sleep dataset using pandas.

### Requirements
1. Ingest `data/sleep_screen.csv` into a pandas DataFrame.
2. Confirm the number of rows and columns using `.shape`.
3. Check for any missing (null) values in either column.
4. Compute and record the minimum, maximum, mean, and standard deviation for both `screen_time_hours` and `sleep_hours`.

### Acceptance Criteria
- [ ] DataFrame successfully loaded without errors.
- [ ] Shape confirmed as exactly 35 rows and 2 columns.
- [ ] Confirmed that null values count is 0 for both columns.
- [ ] Statistics accurately recorded: screen time range [0.8, 5.5], sleep range [5.4, 9.6].

---

## Exercise 2.2: Pearson Correlation and Feature Formatting
**Objective:** Calculate Pearson correlation coefficient and prepare $X$ and $y$ with verified dimensions.

### Problem Statement
You need to mathematically quantify the linear association between evening screen time and sleep duration, and prepare the feature and target variables adhering strictly to scikit-learn's shape rules.

### Requirements
1. Calculate the Pearson correlation coefficient between `screen_time_hours` and `sleep_hours` using pandas `.corr()`.
2. Round the correlation coefficient to 4 decimal places and interpret its magnitude and sign.
3. Extract feature matrix $X$ using double brackets `df[['screen_time_hours']]` and print its shape.
4. Extract target vector $y$ using single brackets `df['sleep_hours']` and print its shape.

### Acceptance Criteria
- [ ] Pearson correlation computed as approximately -0.8504.
- [ ] Written interpretation correctly identifies the negative sign as an inverse relationship and the magnitude as a strong association.
- [ ] Feature matrix $X$ verified to have shape `(35, 1)`.
- [ ] Target vector $y$ verified to have shape `(35,)`.
