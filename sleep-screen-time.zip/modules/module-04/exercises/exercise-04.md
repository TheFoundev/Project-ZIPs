# Module 04 Exercises: Model Training and Inference

---

## Exercise 4.1: Model Training and Coefficient Verification
**Objective:** Partition data into train/test sets, train the linear regression model, and verify parameters.

### Problem Statement
You need to implement the model training stage of the pipeline using scikit-learn, ensuring reproducible partitioning and parameter extraction.

### Requirements
1. Import `train_test_split` and `LinearRegression` from scikit-learn.
2. Partition $X$ and $y$ using `test_size=0.25` and `random_state=42`.
3. Verify that `X_train` contains 26 rows and `X_test` contains 9 rows.
4. Fit `LinearRegression()` on `X_train` and `y_train`.
5. Extract the slope and intercept and verify that they round to -0.57 and 9.25.

### Acceptance Criteria
- [ ] Correct partition shapes verified: 26 train rows and 9 test rows.
- [ ] Model successfully fitted without warnings or errors.
- [ ] Slope extracted as `model.coef_[0]` and confirmed as approximately -0.5694.
- [ ] Intercept extracted as `model.intercept_` and confirmed as approximately 9.2486.

---

## Exercise 4.2: Scenario Inference and Prediction Generation
**Objective:** Generate single and batch sleep duration forecasts using `model.predict()`.

### Problem Statement
A wellness clinic wants to provide automated sleep estimates for four different screen time scenarios. You need to construct the input DataFrames and generate predictions.

### Requirements
1. Create a DataFrame for a single 3.0-hour scenario: `pd.DataFrame({"screen_time_hours": [3.0]})`.
2. Generate the prediction and verify that it rounds to 7.5 hours.
3. Create a batch DataFrame containing screen times of 1.0, 2.0, 4.0, and 5.5 hours.
4. Generate batch predictions and format each prediction into an easy-to-read summary table.

### Acceptance Criteria
- [ ] 3.0-hour scenario prediction verified as approximately 7.54 hours (~7.5 hours).
- [ ] Batch predictions generated in a single vectorized `model.predict()` call.
- [ ] Correct inverse progression observed across all scenarios.
