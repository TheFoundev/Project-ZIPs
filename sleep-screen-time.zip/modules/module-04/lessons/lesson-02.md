# Lesson 02: Training the Scikit-Learn LinearRegression Model

**Lesson ID:** lesson-02  
**Module:** module-04  
**Estimated Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives
The purpose of this lesson is to master the mechanics of instantiating and fitting a linear regression estimator using `scikit-learn`. By the end of this lesson, you will be able to:
- Import and instantiate `sklearn.linear_model.LinearRegression`.
- Execute the `.fit()` method on training data (`X_train, y_train`).
- Understand what happens internally during the fitting process.
- Verify that the model instance has successfully transitioned from an uncalibrated to a calibrated state.

---

## 2. Prerequisites and Required Tools
Understanding of train/test partitions from Lesson 01 and the Ordinary Least Squares objective from Module 03.

---

## 3. Core Concept Explanation
In scikit-learn, all machine learning algorithms adhere to a unified, object-oriented API called the **Estimator interface**:
1. **Instantiation:** Create an instance of the model class, configuring hyperparameters:
   `model = LinearRegression()`
2. **Fitting:** Train the model on observational data by calling `.fit(X, y)`:
   `model.fit(X_train, y_train)`

During `.fit()`, the estimator reads the 26 training rows, computes the means, variances, and covariances, and solves the linear algebra equations to determine the optimal slope and intercept.

---

## 4. Real-World Relevance and Sleep Science Context
In health informatics, software simplicity is vital. Scikit-learn abstracts complex matrix factorizations (such as Singular Value Decomposition and QR decomposition) into a single, clean `.fit()` call. This allows developers and clinical researchers to focus on feature engineering, model validation, and ethical deployment.

---

## 5. Mathematical and Theoretical Foundations
When `.fit(X_train, y_train)` is executed, the estimator internally constructs the design matrix with an added column of ones for the intercept:
$$\tilde{\mathbf{X}} = \begin{bmatrix} 1 & x_1 \\ 1 & x_2 \\ \vdots & \vdots \\ 1 & x_{26} \end{bmatrix} \in \mathbb{R}^{26 \times 2}$$

It then computes the parameter vector $\boldsymbol{\beta} = \begin{bmatrix} \beta_0 \\ \beta_1 \end{bmatrix}$ using the normal equations via SVD:
$$\boldsymbol{\beta} = (\tilde{\mathbf{X}}^T \tilde{\mathbf{X}})^{-1} \tilde{\mathbf{X}}^T \mathbf{y}_{train}$$
This guarantees that the resulting parameters minimize the sum of squared training residuals.

---

## 6. Relevant Code Implementation
In `main.py`, lines 37-38 perform instantiation and fitting:

```python
model = LinearRegression()
model.fit(X_train, y_train)
```

---

## 7. Line-by-Line Code Breakdown
- `model = LinearRegression()`: Initializes the linear regression estimator with default settings (including `fit_intercept=True` and `copy_X=True`).
- `model.fit(X_train, y_train)`: Fits the model specifically on the 26 training examples, computing the optimal coefficients.

---

## 8. Worked Examples and Calculations
Prior to calling `.fit()`, if you attempt to check `model.coef_`, Python raises:
`AttributeError: 'LinearRegression' object has no attribute 'coef_'`

Only after calling `.fit(X_train, y_train)` does scikit-learn create the estimated attributes `model.coef_` and `model.intercept_`. Calling `.fit()` mutates the model object from an empty estimator into a calibrated predictive model.

---

## 9. Step-by-Step Student Implementation Instructions
1. Import the class: `from sklearn.linear_model import LinearRegression`.
2. Instantiate the estimator: `model = LinearRegression()`.
3. Call the fit method: `model.fit(X_train, y_train)`.
4. Check that `hasattr(model, "coef_")` is now `True`.

---

## 10. Expected Output and Observable Behavior
The `.fit()` method returns `self` (the fitted model instance):
```text
LinearRegression()
```
The model is now trained and ready for parameter inspection and prediction.

---

## 11. Practical Exercises and Mini-Tasks
- **Task 1:** Verify that `model.fit(X_train, y_train)` runs without throwing any warnings or errors.
- **Task 2:** What parameter in `LinearRegression()` can be set to `False` if you wanted to force the intercept to be zero?

---

## 12. Common Mistakes, Pitfalls, and Debugging
- **Fitting on Test Data:** Accidentally calling `model.fit(X_test, y_test)`. This constitutes catastrophic data leakage, destroying the validity of the test set.
- **Fitting on All Data Before Evaluation:** Calling `model.fit(X, y)` before testing generalization. Always fit strictly on `X_train`.

---

## 13. Best Practices and Responsible Data Science Considerations
Ensure that input features fed into `.fit()` do not contain `NaN` or infinite values. Scikit-learn estimators expect clean, preprocessed numeric matrices.

---

## 14. Summary and Key Takeaways
- Scikit-learn uses the Estimator interface: instantiate, then `.fit()`.
- Fitting solves the least-squares normal equations on `(X_train, y_train)`.
- Successful fitting populates `model.coef_` and `model.intercept_`.

---

## 15. Knowledge Check Questions and References
1. What method is invoked to train a scikit-learn estimator?
2. Which dataset partition must be passed to `.fit()`?
3. What happens if you try to inspect `model.coef_` before calling `.fit()`?

*References:*
- Pedregosa, F., et al. (2011). *Scikit-learn: Machine Learning in Python*. JMLR.
- Scikit-learn Documentation: *sklearn.linear_model.LinearRegression*.
