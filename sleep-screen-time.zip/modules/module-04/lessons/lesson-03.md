# Lesson 03: Extracting Model Parameters: coef_ and intercept_

**Lesson ID:** lesson-03  
**Module:** module-04  
**Estimated Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives
The purpose of this lesson is to master how to inspect, unpack, and validate the learned mathematical weights of a trained regression model. By the end of this lesson, you will be able to:
- Locate and access the public attributes `model.coef_` and `model.intercept_`.
- Unpack NumPy array structures into native Python scalar floats.
- Verify that the extracted slope is approximately $-0.57$ and the intercept is approximately $9.25$.
- Format the parameters cleanly into readable strings and reports.

---

## 2. Prerequisites and Required Tools
Understanding NumPy 1D array indexing and basic string formatting using Python f-strings.

---

## 3. Core Concept Explanation
In software engineering and data science, transparency is critical. A linear regression model is not an opaque "black box"; every decision it makes is governed by explicit mathematical coefficients:
- **`model.coef_`:** A NumPy array containing the feature weights. For univariate models, it contains one value: `array([-0.5694...])`.
- **`model.intercept_`:** A NumPy float scalar containing the y-intercept: `9.2486...`.

Scikit-learn uses a trailing underscore (`_`) convention to indicate attributes that were estimated from training data, distinguishing them from user-defined hyperparameters like `fit_intercept`.

---

## 4. Real-World Relevance and Sleep Science Context
In healthcare and medicine, "explainable AI" (XAI) is mandatory. Doctors and health regulators will not accept predictions from an opaque neural network without understanding the underlying mechanism. Linear regression coefficients provide immediate explainability: clinicians can see that the model operates on a baseline of 9.25 hours and subtracts 34.2 minutes per hour of screen exposure.

---

## 5. Mathematical and Theoretical Foundations
When $X$ has $P = 1$ feature, `model.coef_` is a 1D NumPy array with shape `(1,)`:
$$\text{model.coef\_} = [\beta_1]$$
To retrieve the scalar number $\beta_1$, we index the first element:
$$\beta_1 = \text{float}(\text{model.coef\_}[0])$$
Similarly, `model.intercept_` is a scalar float:
$$\beta_0 = \text{float}(\text{model.intercept\_})$$

---

## 6. Relevant Code Implementation
In `main.py`, lines 41-42 extract these parameters:

```python
slope = float(model.coef_[0])
intercept = float(model.intercept_)
```

---

## 7. Line-by-Line Code Breakdown
- `model.coef_[0]`: Accesses the 0th index of the coefficient array, retrieving `-0.569403...`.
- `float(...)`: Converts the NumPy 64-bit float into a standard Python float.
- `model.intercept_`: Accesses the learned intercept scalar `9.2486...`.
- `float(...)`: Converts the intercept to a standard Python float.

---

## 8. Worked Examples and Calculations
Let us examine the types and representations in Python:

```python
print("Raw coef_:", model.coef_, type(model.coef_))
# Raw coef_: [-0.56940327] <class 'numpy.ndarray'>

print("Raw intercept_:", model.intercept_, type(model.intercept_))
# Raw intercept_: 9.24862417531776 <class 'numpy.float64'>

slope = float(model.coef_[0])
intercept = float(model.intercept_)
print(f"sleep = {slope:.2f} * screen + {intercept:.2f}")
# sleep = -0.57 * screen + 9.25
```

---

## 9. Step-by-Step Student Implementation Instructions
1. After calling `model.fit(X_train, y_train)`, check the type of `model.coef_`.
2. Extract the slope: `slope = float(model.coef_[0])`.
3. Extract the intercept: `intercept = float(model.intercept_)`.
4. Print the extracted values with `print(f"Slope: {slope:.4f}, Intercept: {intercept:.4f}")`.
5. Confirm that `slope < 0` and `intercept > 0`.

---

## 10. Expected Output and Observable Behavior
The printed values match the project specifications:
```text
Slope: -0.5694, Intercept: 9.2486
```
This confirms that the model has successfully identified the negative relationship.

---

## 11. Practical Exercises and Mini-Tasks
- **Task 1:** What error happens if you try to index `model.intercept_[0]`? (Hint: `intercept_` is a scalar, not an array, in single-output regression).
- **Task 2:** Write an assertion statement to test that `slope` is between `-0.60` and `-0.50`.

---

## 12. Common Mistakes, Pitfalls, and Debugging
- **Missing the Trailing Underscore:** Typing `model.coef` or `model.intercept` triggers `AttributeError`. Remember that all fitted parameters end with `_`.
- **Forgetting Index `[0]` on `coef_`:** Passing `model.coef_` directly into string formatting functions can print array brackets: `[-0.57]`. Indexing `[0]` yields the clean scalar `-0.57`.

---

## 13. Best Practices and Responsible Data Science Considerations
Always convert NumPy data types to native Python floats when serializing to JSON, writing to text logs, or communicating with web APIs, as standard JSON libraries do not natively support `numpy.float64`.

---

## 14. Summary and Key Takeaways
- Learned weights are stored in `model.coef_` and `model.intercept_`.
- Scikit-learn denotes learned attributes with a trailing underscore.
- Unpacking elements with `float(model.coef_[0])` ensures clean scalar values for logging and formatting.

---

## 15. Knowledge Check Questions and References
1. What is the trailing underscore convention in scikit-learn?
2. What is the shape of `model.coef_` for a single-feature regression model?
3. What is the value of `slope` rounded to two decimal places?

*References:*
- Scikit-learn Developer Guide: *Naming Conventions and Estimator Attributes*.
- NumPy Documentation: *Array Indexing and Scalar Conversion*.
