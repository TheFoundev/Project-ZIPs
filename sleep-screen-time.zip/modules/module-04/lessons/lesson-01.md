# Lesson 01: Splitting Data for Generalization: Train/Test Partitions

**Lesson ID:** lesson-01  
**Module:** module-04  
**Estimated Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives
The purpose of this lesson is to learn the foundational machine learning principle of **train/test splitting**. By the end of this lesson, you will be able to:
- Explain why models must be evaluated on unseen test data rather than training data.
- Use `train_test_split()` from `sklearn.model_selection`.
- Configure `test_size=0.25` and `random_state=42`.
- Verify the exact sample counts: 26 training records and 9 testing records.

---

## 2. Prerequisites and Required Tools
Understanding the 2D feature matrix $X$ and 1D target vector $y$ prepared in Module 02.

---

## 3. Core Concept Explanation
If a teacher gives students an exam with the exact same questions they practiced yesterday, the test measures **memorization**, not genuine understanding. Similarly, evaluating a machine learning model on the data it was trained on measures how well it memorized past points, not how well it **generalizes** to new, unseen people.

To prevent self-deception and detect overfitting, we partition our 35 dataset records into two disjoint sets:
1. **Training Set ($75\%$):** The model is allowed to study these 26 records to calculate slope and intercept.
2. **Testing Set ($25\%$):** Kept in a vault until training is complete, then used to evaluate realistic predictive performance.

---

## 4. Real-World Relevance and Sleep Science Context
In clinical digital wellness apps, the model will be deployed to new users who were never part of the original study. Splitting data simulates real-world deployment: if the model predicts sleep accurately on the 9 held-out test participants, we have confidence it will generalize to future app users.

---

## 5. Mathematical and Theoretical Foundations
Formally, we divide index set $\mathcal{I} = \{1, \dots, 35\}$ into subsets $\mathcal{I}_{train}$ and $\mathcal{I}_{test}$ such that:
$$\mathcal{I}_{train} \cap \mathcal{I}_{test} = \emptyset, \quad \mathcal{I}_{train} \cup \mathcal{I}_{test} = \mathcal{I}$$
With $N = 35$ and $\text{test\_size} = 0.25$:
$$N_{test} = \text{round}(35 \times 0.25) = 9 \text{ samples}$$
$$N_{train} = 35 - 9 = 26 \text{ samples}$$

The parameter `random_state=42` initializes the pseudo-random number generator seed, guaranteeing that every student and automated grader receives the exact same 26 training rows and 9 test rows.

---

## 6. Relevant Code Implementation
In `main.py`, lines 33-35 perform this partition:

```python
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)
```

---

## 7. Line-by-Line Code Breakdown
- `X_train, X_test, y_train, y_test`: Unpacks four variables in exact order: train features, test features, train targets, test targets.
- `train_test_split(X, y, ...)`: Scikit-learn's standard splitting utility.
- `test_size=0.25`: Designates 25% of the data for testing.
- `random_state=42`: Fixes the pseudo-random seed for deterministic reproducibility.

---

## 8. Worked Examples and Calculations
Let us verify the shapes of the four returned objects:
- `X_train.shape` $\rightarrow$ `(26, 1)`
- `y_train.shape` $\rightarrow$ `(26,)`
- `X_test.shape` $\rightarrow$ `(9, 1)`
- `y_test.shape` $\rightarrow$ `(9,)`

Summing the samples: $26 + 9 = 35$, exactly matching the full dataset.

---

## 9. Step-by-Step Student Implementation Instructions
1. Import the utility: `from sklearn.model_selection import train_test_split`.
2. Ensure $X$ and $y$ are defined from `sleep_screen.csv`.
3. Execute the function call with `test_size=0.25` and `random_state=42`.
4. Print the length of each partition:
   ```python
   print(len(X_train), len(X_test))
   ```
5. Confirm the output is `26 9`.

---

## 10. Expected Output and Observable Behavior
Inspecting `X_test.head(3)` displays test screen times:
```text
    screen_time_hours
26                2.4
13                4.9
24                2.0
```
These 9 specific participants will serve as the final test benchmark.

---

## 11. Practical Exercises and Mini-Tasks
- **Task 1:** What would happen if `random_state` was omitted or set to `None`?
- **Task 2:** If `test_size` was changed to `0.20`, how many samples would be in train and test?

---

## 12. Common Mistakes, Pitfalls, and Debugging
- **Unpacking in the Wrong Order:** Writing `X_train, y_train, X_test, y_test = train_test_split(...)`. Scikit-learn always returns $(X_{train}, X_{test}, y_{train}, y_{test})$. Swapping the middle two variables corrupts the data pipeline.
- **Data Leakage:** Fitting a model on the entire dataset ($X$) before splitting, or evaluating on $X_{train}$. Always fit on $X_{train}$ and evaluate on $X_{test}$.

---

## 13. Best Practices and Responsible Data Science Considerations
Always set a deterministic `random_state` during development and educational benchmarking to ensure experiments are reproducible across different machines and collaborators.

---

## 14. Summary and Key Takeaways
- Train/test splitting evaluates how a model generalizes to unseen real-world data.
- `test_size=0.25` partitions our 35 samples into 26 training rows and 9 test rows.
- Setting `random_state=42` guarantees reproducibility.

---

## 15. Knowledge Check Questions and References
1. Why do we avoid evaluating models solely on their training data?
2. How many samples are in the training set and test set in our project?
3. What is the purpose of the `random_state` argument?

*References:*
- Scikit-learn User Guide: *Cross-validation and dataset splitting*.
- Kohavi, R. (1995). *A study of cross-validation and bootstrap for accuracy estimation and model selection*.
