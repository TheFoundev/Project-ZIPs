# Module 05 Exercises: Evaluation and Visualization

---

## Exercise 5.1: Evaluation Metrics Calculation and Interpretation
**Objective:** Calculate MAE and R² on test data and interpret the results in a scientific summary.

### Problem Statement
You need to verify the performance of the trained linear regression model on the 9 held-out test participants and document the findings.

### Requirements
1. Generate predictions for `X_test` using `model.predict(X_test)`.
2. Compute Mean Absolute Error (`mean_absolute_error`) and round to 2 decimal places.
3. Compute the Coefficient of Determination (`r2_score`) and round to 2 decimal places.
4. Translate the MAE into minutes and explain what 44% explained variance means for sleep modeling.

### Acceptance Criteria
- [ ] Test MAE verified as 0.52 hours.
- [ ] MAE correctly converted to 31.2 minutes.
- [ ] Test R² verified as 0.44.
- [ ] Summary clearly explains that 44% of sleep variation is captured by evening screen time.

---

## Exercise 5.2: Matplotlib Visualization and Artifact Verification
**Objective:** Render the regression visualization plot and verify exported artifacts.

### Problem Statement
A data presentation requires a high-quality visualization and structured metric log. You will implement the plotting and file-writing stages of the pipeline.

### Requirements
1. Generate 100 linspace coordinates across the feature domain using `np.linspace()`.
2. Render training points (circles), test points (squares), trend line (crimson), and the 3.0-hour prediction (star).
3. Save the figure to `outputs/sleep_regression.png` with 150 DPI and `bbox_inches="tight"`.
4. Write `outputs/metrics.txt` containing the equation, correlation, MAE, R², and 3-hour prediction.

### Acceptance Criteria
- [ ] `outputs/sleep_regression.png` exists and visually displays the downward trend.
- [ ] Four distinct plotting layers confirmed on the figure.
- [ ] `outputs/metrics.txt` exists and contains all required metrics formatted to 4 decimal places.
