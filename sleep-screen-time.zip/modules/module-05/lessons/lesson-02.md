# Lesson 02: Evaluating Explained Variance with R-Squared (R² = 0.44)

**Lesson ID:** lesson-02  
**Module:** module-05  
**Estimated Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives
The purpose of this lesson is to master the concept and calculation of the **Coefficient of Determination ($R^2$)**. By the end of this lesson, you will be able to:
- Define $R^2$ as the proportion of variance explained by the model.
- Compute $R^2$ using `sklearn.metrics.r2_score`.
- Understand the baseline benchmark: predicting the mean $\bar{y}$.
- Interpret what $R^2 = 0.44$ indicates about human sleep habits and unmeasured factors.

---

## 2. Prerequisites and Required Tools
Understanding variance, residuals, and basic fraction arithmetic.

---

## 3. Core Concept Explanation
While MAE tells us *how far off* predictions are in hours, it does not tell us *how much of the overall variability* in sleep is captured by screen time alone.

The **Coefficient of Determination ($R^2$)** measures the proportion of variance in the dependent variable that is predictable from the independent variable.
- **$R^2 = 1.0$:** Perfect prediction; the model explains 100% of the variance.
- **$R^2 = 0.0$:** The model performs no better than simply guessing the average sleep duration $\bar{y}$ for every single person.
- **$R^2 < 0.0$:** The model performs worse than predicting the mean (possible on unseen test sets if a model is poorly fitted).

In our project, the test set $R^2$ is:
$$R^2 = 0.44$$

---

## 4. Real-World Relevance and Sleep Science Context
What does $R^2 = 0.44$ mean in clinical science?
It means that **44% of the variation in test sleep duration is accounted for by evening screen time**.

What about the remaining **56%**?
Human sleep is influenced by many other biological and environmental factors:
- Did the participant consume espresso at 4:00 PM?
- Were they experiencing acute psychological stress or exam anxiety?
- Did they engage in intense physical exercise?
- What was the bedroom temperature and ambient noise level?

Explaining 44% of sleep duration variance with a single, simple lifestyle measurement is a meaningful behavioral finding.

---

## 5. Mathematical and Theoretical Foundations
$R^2$ is defined by comparing the model's Residual Sum of Squares ($SS_{res}$) to the Total Sum of Squares ($SS_{tot}$):
$$R^2 = 1 - \frac{SS_{res}}{SS_{tot}}$$
where:
- $SS_{res} = \sum_{i=1}^{N_{test}} (y_i - \hat{y}_i)^2$: Total squared error of our regression model.
- $SS_{tot} = \sum_{i=1}^{N_{test}} (y_i - \bar{y}_{test})^2$: Total squared error of a "naive" model that predicts the test mean for everyone.

If $SS_{res}$ is small relative to $SS_{tot}$, the ratio $\frac{SS_{res}}{SS_{tot}}$ approaches 0, and $R^2$ approaches 1.0. Here, $\frac{SS_{res}}{SS_{tot}} \approx 0.56$, so $R^2 = 1 - 0.56 = 0.44$.

---

## 6. Relevant Code Implementation
In `main.py`, lines 44 and 54 compute and print $R^2$:

```python
r2 = r2_score(y_test, predictions)
print(f"R-squared: {r2:.2f}")
```

---

## 7. Line-by-Line Code Breakdown
- `r2_score(y_test, predictions)`: Computes the coefficient of determination comparing ground-truth test labels with model predictions.
- `f"R-squared: {r2:.2f}"`: Formats the score to two decimal places, outputting `0.44`.

---

## 8. Worked Examples and Calculations
Let us compare our regression model to a naive mean baseline on the test set:
- Naive model predicts $\bar{y}_{test} \approx 7.07$ hours for all 9 test participants.
- Naive sum of squared errors ($SS_{tot}$): $\approx 5.58$.
- Our regression model's sum of squared errors ($SS_{res}$): $\approx 3.12$.
- Ratio: $\frac{3.12}{5.58} \approx 0.56$.
- $R^2 = 1 - 0.56 = 0.44$.

The linear model reduces error by 44% compared to guessing the average!

---

## 9. Step-by-Step Student Implementation Instructions
1. Import the function: `from sklearn.metrics import r2_score`.
2. Compute $R^2$: `score = r2_score(y_test, model.predict(X_test))`.
3. Print: `print(f"Test R²: {score:.2f}")`.
4. Verify the value is `0.44`.

---

## 10. Expected Output and Observable Behavior
The console output displays:
```text
R-squared: 0.44
```
This confirms that the model explains 44% of the variance in test sleep hours.

---

## 11. Practical Exercises and Mini-Tasks
- **Task 1:** Can $R^2$ be negative on a test set? Explain how that could occur.
- **Task 2:** If you added more relevant features (like caffeine intake and bedroom noise), would you expect $R^2$ to increase or decrease?

---

## 12. Common Mistakes, Pitfalls, and Debugging
- **Equating $R^2$ to $r^2$ on Test Sets:** In simple linear regression on the training set, $R^2 = r^2$. However, on an out-of-sample test set, $R^2$ evaluates generalizability and does not necessarily equal the square of the test correlation coefficient.
- **Demanding $R^2 > 0.95$ in Human Behavioral Studies:** In physics or factory calibrations, $R^2 > 0.95$ is expected. In behavioral human sciences, $R^2$ values between $0.30$ and $0.60$ are typical and valuable due to high natural biological variance.

---

## 13. Best Practices and Responsible Data Science Considerations
Do not judge a model's utility solely by $R^2$. Always evaluate $R^2$ in conjunction with MAE and domain expectations. A model with moderate $R^2$ can still provide vital public health insights.

---

## 14. Summary and Key Takeaways
- $R^2$ quantifies the proportion of target variance explained by features.
- $R^2 = 1 - \frac{SS_{res}}{SS_{tot}}$.
- Our model achieves $R^2 = 0.44$, explaining 44% of test sleep duration variance.

---

## 15. Knowledge Check Questions and References
1. What does an $R^2$ of 0.44 signify about our sleep model?
2. What naive baseline model does $R^2$ compare against?
3. What percentage of variance in sleep duration remains unexplained by screen time alone?

*References:*
- Wright, S. (1921). *Correlation and causation*. Journal of Agricultural Research.
- Scikit-learn Documentation: *r2_score*.
