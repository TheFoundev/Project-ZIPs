# Lesson 03: Plotting Downward Trend Lines and Sample Predictions

**Lesson ID:** lesson-03  
**Module:** module-05  
**Estimated Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives
The purpose of this lesson is to learn how to construct publication-quality regression plots with `matplotlib`. By the end of this lesson, you will be able to:
- Generate a dense synthetic feature grid using `np.linspace()` for smooth line plotting.
- Plot distinct visual markers for training data, test data, and sample prediction points.
- Style visual elements: colors, line widths, markers, labels, legends, and grid transparency.
- Save high-resolution raster graphics without graphical window dependencies.

---

## 2. Prerequisites and Required Tools
Understanding of Cartesian plotting from Module 02 and NumPy array operations.

---

## 3. Core Concept Explanation
A clear visualization communicates machine learning findings far more effectively than raw numbers.
An effective regression chart contains four essential visual layers:
1. **Training Points:** Show the historical data used to calibrate the parameters.
2. **Testing Points:** Show the held-out validation points to visually assess generalization.
3. **Fitted Regression Line:** A continuous downward line representing the learned equation $y = mx + c$.
4. **Key Prediction Highlight:** A prominent marker (such as a star) showing a specific scenario prediction (e.g., 3.0 screen hours $\rightarrow$ 7.5 sleep hours).

---

## 4. Real-World Relevance and Sleep Science Context
In health presentations and clinical journals, visual plots allow stakeholders to quickly verify that the trend line accurately bisects the data points, identify visual outliers, and observe where typical patients fall along the sleep spectrum.

---

## 5. Mathematical and Theoretical Foundations
To plot a smooth mathematical line across the domain $[x_{min}, x_{max}]$, we generate 100 uniformly spaced synthetic query points:
$$x_k = x_{min} + k \left(\frac{x_{max} - x_{min}}{99}\right), \quad k = 0, 1, \dots, 99$$
We then evaluate the model on these synthetic inputs:
$$\hat{y}_k = \text{model.predict}(x_k)$$
Plotting $(x_k, \hat{y}_k)$ with `ax.plot()` creates a crisp, continuous line across the entire plot domain.

---

## 6. Relevant Code Implementation
In `main.py`, lines 58-73 generate this plot:

```python
line_x = np.linspace(df["screen_time_hours"].min(), df["screen_time_hours"].max(), 100)
line_y = model.predict(pd.DataFrame({"screen_time_hours": line_x}))

fig, ax = plt.subplots(figsize=(7, 5))
ax.scatter(X_train, y_train, color="#2c3e50", s=55, label="training data")
ax.scatter(X_test, y_test, color="#e67e22", s=65, marker="s", label="test data")
ax.plot(line_x, line_y, color="#c0392b", linewidth=2.5, label="trend line")
ax.scatter([3], [example], color="#111111", marker="*", s=220, zorder=5, label="3-hour example")
ax.set_xlabel("Screen time before bed (hours)")
ax.set_ylabel("Sleep (hours)")
ax.set_title("Screen time vs. sleep duration")
ax.legend()
ax.grid(alpha=0.25)
fig.tight_layout()
fig.savefig(OUT / "sleep_regression.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```

---

## 7. Line-by-Line Code Breakdown
- `np.linspace(min, max, 100)`: Generates 100 evenly spaced points from 0.8 to 5.5 hours.
- `model.predict(pd.DataFrame(...))`: Evaluates the regression line at each grid coordinate.
- `ax.scatter(X_train, y_train, ...)`: Plots training circles in dark slate navy (`#2c3e50`).
- `ax.scatter(X_test, y_test, ...)`: Plots testing squares in vibrant orange (`#e67e22`).
- `ax.plot(line_x, line_y, color="#c0392b", linewidth=2.5)`: Draws the crimson downward regression trendline.
- `ax.scatter([3], [example], marker="*", s=220, zorder=5)`: Places a large black star (`#111111`) at $(3.0, 7.5)$, with `zorder=5` ensuring it renders above the line and points.
- `fig.savefig(..., dpi=150, bbox_inches="tight")`: Exports a sharp PNG image at 150 dots-per-inch.
- `plt.close(fig)`: Releases graphics memory to prevent memory leaks.

---

## 8. Worked Examples and Calculations
Notice the downward visual progression:
- At $x = 1.0$, the red line passes through $\approx 8.68$ hours.
- At $x = 3.0$, the red line intersects the black star at $7.54$ hours.
- At $x = 5.0$, the red line passes through $\approx 6.40$ hours.
The downward slope of the red line visually verifies the negative coefficient $-0.57$.

---

## 9. Step-by-Step Student Implementation Instructions
1. Configure Matplotlib: `matplotlib.use("Agg")`.
2. Generate synthetic grid with `np.linspace()`.
3. Construct the figure with `plt.subplots(figsize=(7, 5))`.
4. Add all four plotting layers (training scatter, test scatter, trend line, star marker).
5. Add labels, title, legend, and grid.
6. Save to `outputs/sleep_regression.png`.

---

## 10. Expected Output and Observable Behavior
Inspecting `outputs/sleep_regression.png` reveals a balanced, aesthetically styled chart showing the downward trend, distinct test points, and the 3-hour scenario marker.

---

## 11. Practical Exercises and Mini-Tasks
- **Task 1:** What does `zorder=5` do when plotting the star marker?
- **Task 2:** Why is `bbox_inches="tight"` recommended when saving Matplotlib figures?

---

## 12. Common Mistakes, Pitfalls, and Debugging
- **Plotting Raw Unsorted Points with `ax.plot(X_train, y_train_pred)`:** If points in $X$ are not sorted in ascending order, `ax.plot()` draws a jagged, zig-zagging mess across the screen. Generating a sorted `np.linspace` grid guarantees a clean, straight line.
- **Forgetting `plt.close(fig)`:** In batch jobs or loops, omitting `plt.close()` leaves open figure objects in memory, generating `RuntimeWarning: More than 20 figures have been opened`.

---

## 13. Best Practices and Responsible Data Science Considerations
Use colorblind-friendly palettes and high-contrast marker shapes (e.g., circles vs squares) so visualizations remain accessible to all readers.

---

## 14. Summary and Key Takeaways
- Effective regression visualization layers training points, test points, the fitted line, and scenario markers.
- `np.linspace()` produces clean, ordered inputs for smooth line plotting.
- Headless export with `dpi=150` and `bbox_inches="tight"` creates publication-quality artifacts.

---

## 15. Knowledge Check Questions and References
1. Why is `np.linspace` used instead of plotting raw training points with `ax.plot`?
2. What visual marker is used to highlight the 3.0-hour scenario prediction?
3. What is the role of `plt.close(fig)` after saving?

*References:*
- Tufte, E. R. (2001). *The Visual Display of Quantitative Information*. Graphics Press.
- Matplotlib Documentation: *matplotlib.pyplot.savefig*.
