# Lesson 04: Exporting Artifacts and Reading the Output Files

**Lesson ID:** lesson-04  
**Module:** module-05  
**Estimated Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives
The purpose of this lesson is to master artifact persistence, automated metric logging, and structured output file reading. By the end of this lesson, you will be able to:
- Write programmatic file exporters that log model parameters to plaintext files (`metrics.txt`).
- Format floating-point numbers with precision specifiers for clean logging.
- Read and verify exported artifacts programmatically.
- Understand how automated grading harnesses evaluate machine learning pipelines.

---

## 2. Prerequisites and Required Tools
Python standard file I/O operations (`with open(...) as handle:`) and f-string formatting.

---

## 3. Core Concept Explanation
In production data science systems, models run on automated schedules or remote worker nodes. A script cannot simply print output to a temporary terminal window; it must persist its results into permanent **artifacts**:
1. **Visual Artifacts (`sleep_regression.png`):** Graphical files for human visual audit and reporting.
2. **Metric Artifacts (`metrics.txt`):** Plaintext or structured files containing exact numerical coefficients and evaluation scores for downstream monitoring and automated testing.

---

## 4. Real-World Relevance and Sleep Science Context
In clinical trials, every model execution must generate an immutable audit trail. Regulators require permanent records detailing the exact regression equation, sample errors, and prediction values to verify compliance and scientific integrity.

---

## 5. Mathematical and Theoretical Foundations
When logging scientific results, numerical precision must be controlled:
- **Slope and Intercept:** Recorded to 4 decimal places (`:.4f`) to prevent truncation errors during downstream recalculation.
- **Metrics (MAE, R²):** Recorded to 4 decimal places for precise automated comparison against acceptance thresholds.
- **Scenario Predictions:** Recorded to 2 decimal places (`:.2f`).

---

## 6. Relevant Code Implementation
In `main.py`, lines 75-81 execute artifact logging:

```python
with open(OUT / "metrics.txt", "w", encoding="utf-8") as handle:
    handle.write(f"equation: sleep = {slope:.4f} * screen_time + {intercept:.4f}
")
    handle.write(f"correlation: {correlation:.4f}
")
    handle.write(f"MAE: {mae:.4f}
R2: {r2:.4f}
")
    handle.write(f"prediction at 3 hours: {example:.2f}
")

print("
Saved: outputs/sleep_regression.png, outputs/metrics.txt")
```

---

## 7. Line-by-Line Code Breakdown
- `with open(OUT / "metrics.txt", "w", encoding="utf-8") as handle:`: Opens a write-mode file stream using UTF-8 encoding within a context manager that automatically closes the file upon block exit.
- `handle.write(...)`: Writes the exact linear equation with 4-decimal precision: `sleep = -0.5694 * screen_time + 9.2486`.
- `correlation: {correlation:.4f}`: Logs Pearson's $r$ (`-0.8504`).
- `MAE: {mae:.4f}
R2: {r2:.4f}`: Logs test evaluation metrics ($0.5190$ and $0.4410$).
- `prediction at 3 hours: {example:.2f}`: Logs the candidate prediction ($7.54$).

---

## 8. Worked Examples and Calculations
Let us examine the exact contents of `outputs/metrics.txt`:
```text
equation: sleep = -0.5694 * screen_time + 9.2486
correlation: -0.8504
MAE: 0.5190
R2: 0.4410
prediction at 3 hours: 7.54
```
Each line begins with a standardized key (`equation:`, `correlation:`, `MAE:`, etc.) that can be easily parsed by automated verification scripts.

---

## 9. Step-by-Step Student Implementation Instructions
1. Run `python main.py` in your terminal.
2. Confirm the console reports `Saved: outputs/sleep_regression.png, outputs/metrics.txt`.
3. Read the metrics file: `cat outputs/metrics.txt`.
4. Inspect the image: open `outputs/sleep_regression.png` in your image viewer.

---

## 10. Expected Output and Observable Behavior
Both files exist in the `outputs/` directory and match the required schema.

---

## 11. Practical Exercises and Mini-Tasks
- **Task 1:** Write a Python function that opens `outputs/metrics.txt` and parses the MAE value into a float.
- **Task 2:** Why is `encoding="utf-8"` explicitly specified in `open()`?

---

## 12. Common Mistakes, Pitfalls, and Debugging
- **Relative Path Assumptions:** Using `open("outputs/metrics.txt", "w")` without ensuring the directory exists. Calling `OUT.mkdir(exist_ok=True)` first prevents `FileNotFoundError`.
- **Forgetting Newline Characters (`
`):** Calling `handle.write()` without `
`, which concatenates all metrics into a single unreadable run-on line.

---

## 13. Best Practices and Responsible Data Science Considerations
Always use context managers (`with open(...)`) for file I/O to guarantee that file handles are flushed and closed even if runtime exceptions occur.

---

## 14. Summary and Key Takeaways
- Artifact persistence ensures reproducible auditability.
- `outputs/metrics.txt` records equation weights, correlation, MAE, R², and scenario predictions.
- Context managers ensure safe, reliable file operations.

---

## 15. Knowledge Check Questions and References
1. What two files are saved in the `outputs/` folder?
2. What precision format (`:.4f`) is used for the equation parameters in `metrics.txt`?
3. Why are context managers (`with open(...)`) preferred for writing files?

*References:*
- Python Documentation: *Reading and Writing Files*.
- Good Laboratory Practice (GLP) for Data Integrity in Health Informatics.
