# Lesson 01: Quantifying Accuracy with Mean Absolute Error (MAE)

**Lesson ID:** lesson-01  
**Module:** module-05  
**Estimated Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives
The purpose of this lesson is to learn how to quantify model prediction accuracy using **Mean Absolute Error (MAE)**. By the end of this lesson, you will be able to:
- Define Mean Absolute Error mathematically.
- Calculate MAE using `sklearn.metrics.mean_absolute_error`.
- Interpret the project's test MAE of $0.52$ hours in everyday units ($\approx 31.2$ minutes).
- Compare MAE with Mean Squared Error (MSE) and Root Mean Squared Error (RMSE).

---

## 2. Prerequisites and Required Tools
Understanding residuals ($e_i = y_i - \hat{y}_i$) from Module 03 and test set predictions from Module 04.

---

## 3. Core Concept Explanation
After generating test predictions $\hat{y}_{test}$ using `model.predict(X_test)`, we must ask: **How accurate are these predictions compared to actual sleep hours $y_{test}$?**

The most intuitive regression evaluation metric is **Mean Absolute Error (MAE)**. MAE measures the average absolute difference between the model's predictions and actual observations:
$$\text{MAE} = \frac{1}{N_{test}} \sum_{i=1}^{N_{test}} |y_i - \hat{y}_i|$$

In our project, the test set MAE is:
$$\text{MAE} = 0.52 \text{ hours}$$

---

## 4. Real-World Relevance and Sleep Science Context
In clinical sleep tracking, knowing the typical margin of error allows users to interpret forecasts with appropriate caution. An MAE of $0.52$ hours means that on average, our model's sleep prediction is off by approximately:
$$0.52 \times 60 = 31.2 \text{ minutes}$$

For a simple single-variable behavioral model analyzing complex human sleep, an average error of approximately 31 minutes is a remarkably solid baseline.

---

## 5. Mathematical and Theoretical Foundations
MAE possesses several critical mathematical properties:
1. **Direct Physical Units:** Unlike Mean Squared Error (which has units of $\text{hours}^2$), MAE is expressed in the exact same measurement units as the target variable (hours).
2. **Robustness to Extreme Outliers:** Because errors are not squared, a single participant with an unusual sleep anomaly does not disproportionately skew MAE.
3. **Linear Penalty Scale:** An error of $1.0$ hour is penalized exactly twice as much as an error of $0.5$ hours.

---

## 6. Relevant Code Implementation
In `main.py`, lines 43 and 53 compute and report MAE:

```python
predictions = model.predict(X_test)
mae = mean_absolute_error(y_test, predictions)
print(f"Mean absolute error: {mae:.2f} hours")
```

---

## 7. Line-by-Line Code Breakdown
- `predictions = model.predict(X_test)`: Generates predictions for the 9 held-out test participants.
- `mean_absolute_error(y_test, predictions)`: Computes the average absolute error across all 9 test points.
- `f"Mean absolute error: {mae:.2f} hours"`: Prints formatted error to two decimal places (`0.52 hours`).

---

## 8. Worked Examples and Calculations
Let us look at three test observations:
- Test Point 1: Actual $y = 7.3$, Predicted $\hat{y} = 7.88$, Absolute Error: $|7.3 - 7.88| = 0.58$ hrs.
- Test Point 2: Actual $y = 5.4$, Predicted $\hat{y} = 6.46$, Absolute Error: $|5.4 - 6.46| = 1.06$ hrs.
- Test Point 3: Actual $y = 7.9$, Predicted $\hat{y} = 8.11$, Absolute Error: $|7.9 - 8.11| = 0.21$ hrs.

Averaging the errors across all 9 test cases produces the final test MAE of $0.52$ hours.

---

## 9. Step-by-Step Student Implementation Instructions
1. Import the metric: `from sklearn.metrics import mean_absolute_error`.
2. Generate test predictions: `preds = model.predict(X_test)`.
3. Compute MAE: `error = mean_absolute_error(y_test, preds)`.
4. Convert to minutes: `minutes = error * 60`.
5. Print: `print(f"Test MAE: {error:.2f} hours ({minutes:.1f} minutes)")`.

---

## 10. Expected Output and Observable Behavior
Running the calculation displays:
```text
Mean absolute error: 0.52 hours
```
This confirms that the test error is approximately 31 minutes.

---

## 11. Practical Exercises and Mini-Tasks
- **Task 1:** Compute the training set MAE using `mean_absolute_error(y_train, model.predict(X_train))`. Is training MAE higher or lower than test MAE? Why?
- **Task 2:** Why would a clinic prefer MAE over Mean Squared Error when explaining results to patients?

---

## 12. Common Mistakes, Pitfalls, and Debugging
- **Evaluating on Training Data:** Passing `y_train` and training predictions to calculate MAE. While training MAE is informative, reporting it as the model's true performance is misleading.
- **Forgetting Absolute Value:** Summing raw $(y_i - \hat{y}_i)$ instead of absolute values $|y_i - \hat{y}_i|$. Raw errors cancel out and yield near-zero, masking actual prediction errors.

---

## 13. Best Practices and Responsible Data Science Considerations
Always communicate error margins alongside point predictions. When telling a user "You will sleep 7.5 hours," responsible systems add: "± 31 minutes average error."

---

## 14. Summary and Key Takeaways
- Mean Absolute Error (MAE) measures average prediction error magnitude in target units.
- In our test set, $\text{MAE} = 0.52$ hours (approximately 31 minutes).
- MAE is robust, intuitive, and readily interpretable by clinicians and users.

---

## 15. Knowledge Check Questions and References
1. What is the mathematical definition of Mean Absolute Error?
2. What are the measurement units of MAE in this project?
3. What is the test MAE value in minutes?

*References:*
- Willmott, C. J., & Matsuura, K. (2005). *Advantages of the mean absolute error (MAE) over the root mean squared error (RMSE) in assessing average model performance*. Climate Research.
- Scikit-learn Documentation: *mean_absolute_error*.
