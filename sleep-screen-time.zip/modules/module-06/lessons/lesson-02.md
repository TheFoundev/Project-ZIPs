# Lesson 02: Uncovering Confounding Variables in Sleep Science

**Lesson ID:** lesson-02  
**Module:** module-06  
**Estimated Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives
The purpose of this lesson is to examine the role of **confounding variables** in machine learning and epidemiological research. By the end of this lesson, you will be able to:
- Define what a confounding variable is and how it introduces omitted variable bias.
- Identify specific biological, environmental, and behavioral confounders in sleep research.
- Construct a Directed Acyclic Graph (DAG) visualizing confounding pathways.
- Explain why single-feature models are especially vulnerable to confounding effects.

---

## 2. Prerequisites and Required Tools
Understanding of the correlation vs causation principle from Lesson 01.

---

## 3. Core Concept Explanation
A **confounding variable** (or confounder) is an unmeasured third factor that is simultaneously associated with both the independent feature ($X$) and the dependent target ($y$).

```text
              +----------------------------+
              |    Confounder (Z)          |
              |  (e.g., Academic Stress)   |
              +--------------+-------------+
                             |
              +--------------+--------------+
              |                             |
              v                             v
+----------------------------+  Correlation +----------------------------+
|  Feature: Screen Time (X)  | <----------> |   Target: Sleep Hours (y)  |
+----------------------------+              +----------------------------+
```

When a confounder is omitted from a model, the algorithm attributes the shared variance entirely to the feature $X$. This creates **omitted variable bias**, making the relationship appear stronger or more direct than it truly is.

---

## 4. Real-World Relevance and Sleep Science Context
In sleep research, multiple powerful confounders exist:
1. **Academic or Career Stress:** High stress leads people to work late into the night on laptops ($X \uparrow$) while psychological worry prevents deep restorative sleep ($y \downarrow$).
2. **Caffeine and Stimulants:** Drinking coffee or energy drinks late in the afternoon keeps individuals awake, prompting late-night device browsing while directly blocking adenosine receptors and shortening sleep.
3. **Shift Work and Irregular Schedules:** Night-shift workers have altered circadian rhythms and high screen exposure during odd hours.
4. **Age and Chronotype:** Adolescents naturally have delayed circadian rhythms ("night owls"), leading to late-night social media use combined with early school wake times.

---

## 5. Mathematical and Theoretical Foundations
Suppose the true data-generating process involves two variables:
$$y = \beta_1 x_1 + \beta_2 z + \varepsilon$$
where $x_1$ is screen time and $z$ is stress.

If we omit $z$ and fit a simple univariate regression on $x_1$ alone:
$$\hat{y} = b_1 x_1 + b_0$$

The expected value of our estimated slope $b_1$ is:
$$\mathbb{E}[b_1] = \beta_1 + \beta_2 \frac{\text{Cov}(x_1, z)}{\text{Var}(x_1)}$$

The second term $\beta_2 \frac{\text{Cov}(x_1, z)}{\text{Var}(x_1)}$ is the **omitted variable bias**! Even if screen time has zero direct causal effect on sleep ($\beta_1 = 0$), the estimated slope $b_1$ will be negative simply because stress is positively correlated with screen time and negatively correlated with sleep!

---

## 6. Relevant Code Implementation
In `main.py`, line 82 hints at the need for additional features:

```python
print("Try this: add 'weekend' as a second feature and see whether it helps.")
```

---

## 7. Line-by-Line Code Breakdown
- The script author recognizes the limitation of a univariate model and challenges students to expand the dataset to account for multi-variable behavioral patterns (such as weekday vs weekend sleep).

---

## 8. Worked Examples and Calculations
Imagine two students:
- **Student A (Low Stress):** Logs 2 hours of evening screen time, has no upcoming exams, falls asleep easily, sleeps 8.5 hours.
- **Student B (High Stress):** Cramming for medical board exams, stares at a laptop for 5 hours, experiences severe anxiety, sleeps only 5.5 hours.

Is the laptop solely responsible for the 3-hour sleep deficit? Or did the impending medical exam cause both the prolonged screen time and the sleep disruption? Without measuring stress, a machine learning model cannot tell!

---

## 9. Step-by-Step Student Implementation Instructions
1. List three potential confounding variables that could influence both screen time and sleep.
2. Sketch a causal diagram connecting your three variables to `screen_time_hours` and `sleep_hours`.
3. Explain how omitted variable bias might distort the estimated slope of -0.57.

---

## 10. Expected Output and Observable Behavior
Students understand that the slope $-0.57$ represents the combined, confounded association rather than an isolated, pure effect of screens alone.

---

## 11. Practical Exercises and Mini-Tasks
- **Task 1:** If you could add one physiological sensor measurement to this dataset, what would you measure? (e.g., salivary melatonin, cortisol, heart-rate variability).
- **Task 2:** Why cannot statistical formulas alone detect whether a confounder is missing?

---

## 12. Common Mistakes, Pitfalls, and Debugging
- **Believing Bigger Datasets Eliminate Confounding:** Increasing sample size from 35 to 35,000 observations reduces random sampling noise, but does **not** eliminate confounding bias. A biased model on 1,000,000 rows will simply estimate the wrong answer with higher precision!
- **Ignoring Non-Digital Factors:** Blaming modern technology for sleep deficits while overlooking fundamental factors like noise, diet, room lighting, and work culture.

---

## 13. Best Practices and Responsible Data Science Considerations
Always perform domain-specific causal modeling before training regression algorithms. Consult with domain experts (such as physicians or psychologists) to map potential confounding pathways.

---

## 14. Summary and Key Takeaways
- Confounding variables correlate with both feature and target, introducing omitted variable bias.
- Stress, caffeine, work schedules, and age can explain both high screen usage and low sleep.
- Adding samples cannot fix confounding; only measuring and controlling for confounders can.

---

## 15. Knowledge Check Questions and References
1. What is a confounding variable?
2. What mathematical term describes the error introduced by omitting relevant variables from a regression model?
3. Why does increasing sample size fail to eliminate confounding bias?

*References:*
- Angrist, J. D., & Pischke, J. S. (2009). *Mostly Harmless Econometrics: An Empiricist's Companion*. Princeton University Press.
- Rohrer, J. M. (2018). *Thinking clearly about correlation and causation: Graphical causal models for observational data*. Advances in Methods and Practices in Psychological Science.
