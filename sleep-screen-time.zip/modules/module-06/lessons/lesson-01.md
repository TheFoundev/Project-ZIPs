# Lesson 01: Correlation Does Not Imply Causation: The Fundamental Caveat

**Lesson ID:** lesson-01  
**Module:** module-06  
**Estimated Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives
The purpose of this lesson is to master the most important philosophical and scientific principle in data analysis: **correlation does not imply causation**. By the end of this lesson, you will be able to:
- Explain why a strong statistical correlation ($r = -0.85$) does not constitute proof that screen time directly reduces sleep.
- Define causal inference and contrast observational studies with Randomized Controlled Trials (RCTs).
- Identify the explicit disclaimer built into `main.py`.
- Prevent false causal claims when communicating machine learning results.

---

## 2. Prerequisites and Required Tools
Understanding of the Pearson correlation coefficient ($r = -0.85$) and the fitted regression equation from previous modules.

---

## 3. Core Concept Explanation
In data science, when two variables exhibit a strong statistical correlation, it is tempting to leap to a causal conclusion: *"Looking at screens makes you sleep less."*

However, correlation merely indicates **co-occurrence**: when one variable is observed to be high, the other is observed to be low. It does **not** explain *why* this relationship exists. Two variables may be correlated due to:
1. **Direct Causation ($X \rightarrow Y$):** Screen light and notifications directly reduce sleep.
2. **Reverse Causation ($Y \rightarrow X$):** An individual suffering from insomnia lies awake and uses their phone to pass the time.
3. **Common Cause / Confounder ($Z \rightarrow X$ and $Z \rightarrow Y$):** High work stress independently causes both extended late-night screen work and fitful, truncated sleep.

---

## 4. Real-World Relevance and Sleep Science Context
Media headlines routinely misinterpret observational machine learning models:
- *Sensational Headline:* "AI Algorithm Proves Smartphones Destroy 34 Minutes of Sleep Every Night!"
- *Scientific Reality:* "Observational Model Finds Statistical Association Between Evening Screen Use and Reduced Sleep, Subject to Uncontrolled Confounders."

Responsible data scientists have an ethical duty to correct sensationalism and present findings with rigorous scientific humility.

---

## 5. Mathematical and Theoretical Foundations
In causal inference, a statistical association between $X$ and $Y$ can be expressed as:
$$P(Y|X) \neq P(Y)$$
However, a causal effect requires demonstrating the interventional distribution:
$$P(Y | \text{do}(X = x))$$
Observational data collected without randomized intervention measures only the observational conditional distribution $P(Y|X)$. We cannot mathematically equate $P(Y|X)$ with $P(Y|\text{do}(X))$ without controlling for all possible confounding pathways.

---

## 6. Relevant Code Implementation
In `main.py`, line 56 explicitly emphasizes this principle in console output:

```python
print("
Important: this does not prove that screen time causes less sleep.")
```

---

## 7. Line-by-Line Code Breakdown
- `
Important: ...`: Placed prominently immediately after the numerical prediction output.
- The author intentionally inserts this caveat to ensure anyone running the script confronts the ethical limitations of observational regression before drawing policy or lifestyle conclusions.

---

## 8. Worked Examples and Calculations
Consider a classic spurious correlation:
- In summer, ice cream sales and drowning incidents are strongly positively correlated ($r > 0.8$).
- Does eating ice cream cause drowning? Obviously not!
- A confounding variable—**hot summer weather** ($Z$)—causes both increased swimming (leading to drowning risks) and increased ice cream consumption.

In our sleep study, could stress, caffeine, or school exams be the "hot summer weather"? Absolutely.

---

## 9. Step-by-Step Student Implementation Instructions
1. Run `main.py` and observe where the disclaimer appears in the terminal.
2. Notice that the script prints the disclaimer right below the 3-hour prediction.
3. Reflect on how health apps should display predictive outputs to patients without misleading them.

---

## 10. Expected Output and Observable Behavior
The console output explicitly reads:
```text
Prediction for 3 hours of screen time: 7.5 hours of sleep

Important: this does not prove that screen time causes less sleep.
```
This demonstrates ethical algorithmic communication.

---

## 11. Practical Exercises and Mini-Tasks
- **Task 1:** Explain the concept of reverse causality in the context of an insomnia patient.
- **Task 2:** What type of scientific study would be required to prove that screen exposure directly causes sleep reduction?

---

## 12. Common Mistakes, Pitfalls, and Debugging
- **Using Causal Verbs:** Using words like "causes", "leads to", "produces", or "determines" when describing regression coefficients. Use associative phrases: "is associated with", "correlates with", or "is accompanied by".
- **Assuming High $R^2$ Implies Causality:** Believing that an $R^2$ of 0.44 or 0.90 proves a causal link. Even a model with $R^2 = 0.99$ can be completely confounded.

---

## 13. Best Practices and Responsible Data Science Considerations
Always append clear contextual disclaimers to predictive models in healthcare, education, and social policy. Never present observational correlations as causal truths.

---

## 14. Summary and Key Takeaways
- Correlation measures statistical association, not cause and effect.
- Observational data cannot distinguish between direct causation, reverse causation, and confounding.
- Responsible models explicitly state their limitations to prevent public misinformation.

---

## 15. Knowledge Check Questions and References
1. Why does $r = -0.85$ fail to prove that screen time causes reduced sleep?
2. What is reverse causality?
3. What explicit disclaimer does `main.py` print after making predictions?

*References:*
- Pearl, J. (2009). *Causality: Models, Reasoning, and Inference*. Cambridge University Press.
- Bradford Hill, A. (1965). *The Environment and Disease: Association or Causation?*. Proceedings of the Royal Society of Medicine.
