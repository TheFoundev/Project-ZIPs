# Lesson 04: Extending the Model: Multivariate Regression and Future Directions

**Lesson ID:** lesson-04  
**Module:** module-06  
**Estimated Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives
The purpose of this lesson is to explore the natural evolution of machine learning modeling: transitioning from single-variable regression to **multiple linear regression**. By the end of this lesson, you will be able to:
- Formulate the multiple linear regression equation with multiple input features.
- Understand how adding a binary `is_weekend` feature can capture behavioral schedule shifts.
- Explain how adding features impacts model complexity, $R^2$, and degrees of freedom.
- Outline next steps for your ongoing journey in data science and machine learning.

---

## 2. Prerequisites and Required Tools
Understanding of the univariate regression pipeline and feature matrix formatting from Modules 01-05.

---

## 3. Core Concept Explanation
In our current project, we modeled sleep using a single explanatory variable:
$$\text{sleep} = \beta_1 \times \text{screen\_time} + \beta_0$$

While effective as an educational foundation, human biology is multi-dimensional. In **Multiple Linear Regression**, we extend the feature matrix $X$ to include $P > 1$ features:
$$\hat{y} = \beta_0 + \beta_1 x_1 + \beta_2 x_2 + \dots + \beta_P x_P$$

---

## 4. Real-World Relevance and Sleep Science Context
Consider how human habits change between Tuesday night and Saturday night:
- On Tuesday night, an individual might watch 3 hours of television and must wake up early for school/work at 6:30 AM (sleep is cut short).
- On Saturday night, an individual might watch 3 hours of television but can sleep in until 10:00 AM on Sunday morning!

By introducing a binary feature `is_weekend` ($0 = \text{weekday}, 1 = \text{weekend}$), the model can learn different baseline intercepts for workdays versus rest days.

---

## 5. Mathematical and Theoretical Foundations
Let us define the expanded feature space:
- $x_1$: `screen_time_hours` (continuous float $\ge 0$).
- $x_2$: `is_weekend` (binary integer $\in \{0, 1\}$).

The regression equation becomes:
$$\hat{y} = \beta_0 + \beta_1 x_1 + \beta_2 x_2$$

Geometrically:
- For weekdays ($x_2 = 0$): $\hat{y} = \beta_0 + \beta_1 x_1$.
- For weekends ($x_2 = 1$): $\hat{y} = (\beta_0 + \beta_2) + \beta_1 x_1$.

Here, $\beta_2$ represents the "weekend sleep bonus" (e.g., $+1.2$ hours). The model now fits two parallel downward-sloping lines—one for weekdays and one for weekends!

---

## 6. Relevant Code Implementation
In `main.py`, line 82 suggests this exact architectural extension:

```python
print("Try this: add 'weekend' as a second feature and see whether it helps.")
```

In Python with scikit-learn, implementing this requires only modifying feature extraction:
```python
# Expanded 2D Feature Matrix with 2 columns
X_multi = df[["screen_time_hours", "is_weekend"]]
model_multi = LinearRegression()
model_multi.fit(X_train_multi, y_train)
```

---

## 7. Line-by-Line Code Breakdown
- `df[["screen_time_hours", "is_weekend"]]`: Extracts a 2D DataFrame with shape `(N, 2)`.
- Scikit-learn's `LinearRegression` seamlessly handles the extra dimension, optimizing both slopes ($\beta_1, \beta_2$) and the intercept ($\beta_0$) without changing any other line of code!

---

## 8. Worked Examples and Calculations
Suppose a multivariate model learns:
$$\text{sleep} = -0.55 \times \text{screen} + 1.20 \times \text{is\_weekend} + 8.90$$

Let us predict sleep for 3 hours of screen time on different days:
- **Weekday ($x_1 = 3.0, x_2 = 0$):**
  $$\hat{y} = -0.55(3.0) + 1.20(0) + 8.90 = -1.65 + 8.90 = 7.25 \text{ hours}$$
- **Weekend ($x_1 = 3.0, x_2 = 1$):**
  $$\hat{y} = -0.55(3.0) + 1.20(1) + 8.90 = -1.65 + 1.20 + 8.90 = 8.45 \text{ hours}$$

The multivariate model captures the real-world weekend sleep-in effect with elegance.

---

## 9. Step-by-Step Student Implementation Instructions
1. Inspect the source dataset or synthesize an `is_weekend` column.
2. Select both columns into `X`: `X = df[['screen_time_hours', 'is_weekend']]`.
3. Split into train and test sets using `train_test_split`.
4. Fit `model.fit(X_train, y_train)`.
5. Inspect `model.coef_`. Notice that `model.coef_` now contains two slopes: `[beta_1, beta_2]`.

---

## 10. Expected Output and Observable Behavior
Printing `model.coef_` outputs two weights:
```text
Weights: [-0.55, 1.20]
```
The model now simultaneously accounts for screen penalty and weekend recovery.

---

## 11. Practical Exercises and Mini-Tasks
- **Task 1:** What other lifestyle feature would you like to incorporate into a sleep prediction model?
- **Task 2:** Why must data scientists guard against **multicollinearity** when adding multiple correlated features?

---

## 12. Common Mistakes, Pitfalls, and Debugging
- **Overfitting with Too Many Features:** In small datasets ($N = 35$), adding 15 features will artificially inflate $R^2$ on the training set while severely degrading test generalization. Keep models parsimonious.
- **Dummy Variable Trap:** Including redundant binary categories (e.g., including both `is_weekend` and `is_weekday`), causing perfect multicollinearity and matrix inversion errors.

---

## 13. Best Practices and Responsible Data Science Considerations
When evaluating multiple regression models, use **Adjusted $R^2$** or cross-validation rather than standard $R^2$, as standard $R^2$ mechanically increases whenever any feature is added, even if that feature is completely random noise.

---

## 14. Summary and Key Takeaways
- Multiple linear regression extends the feature matrix to $P > 1$ dimensions: $\hat{y} = eta_0 + \sum eta_j x_j$.
- Adding binary indicators like `is_weekend` allows models to capture baseline shifts across categories.
- Always balance model complexity against sample size to prevent overfitting.

---

## 15. Knowledge Check Questions and References
1. What is the mathematical form of multiple linear regression with two features?
2. How does a binary feature like `is_weekend` alter the geometry of the regression line?
3. Why does standard $R^2$ always increase when new features are added?

*References:*
- James, G., Witten, D., Hastie, T., & Tibshirani, R. (2013). *An Introduction to Statistical Learning*. Springer.
- Scikit-learn Documentation: *Multiple Linear Regression*.
