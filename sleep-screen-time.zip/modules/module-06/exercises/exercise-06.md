# Module 06 Exercises: Correlation vs Causation & Ethics

---

## Exercise 6.1: Confounder Analysis and Causal Diagram
**Objective:** Map causal and non-causal associations between screen time and sleep duration using a Directed Acyclic Graph (DAG).

### Problem Statement
You are preparing a presentation for a public health panel. You need to formally explain why a strong negative correlation ($r = -0.85$) cannot be interpreted as proof that screens cause sleep deprivation.

### Requirements
1. Identify at least three plausible confounding variables that could influence both pre-bed screen time and sleep duration.
2. For each confounder, explain the dual association: how does it affect screen time ($X$), and how does it affect sleep ($y$)?
3. Explain the concept of reverse causality: how might poor sleep cause increased evening screen time?
4. Sketch or write out a text-based DAG showing the relationships between Confounders, Screen Time, and Sleep.

### Acceptance Criteria
- [ ] Three valid confounders identified (e.g., job/exam stress, afternoon caffeine, late-shift work).
- [ ] Dual association clearly articulated for all three confounders.
- [ ] Reverse causality explained logically.
- [ ] Text diagram clearly depicts the paths between variables.

---

## Exercise 6.2: Drafting an Ethical Model Disclaimer
**Objective:** Write a user-facing clinical and ethical disclaimer for a consumer wellness application.

### Problem Statement
A mobile sleep-tracking app uses our trained linear regression model to predict users' expected sleep from their logged screen hours. You need to write the user-facing disclaimer that accompanies every prediction.

### Requirements
1. State clearly that the prediction is based on statistical correlation from observational data, not medical diagnosis or proven causation.
2. Include the model's typical margin of error ($\pm 0.52$ hours / $pprox 31$ minutes).
3. Warn against orthosomnia (unhealthy anxiety over sleep tracking).
4. Provide advice for users experiencing chronic sleep issues to consult a medical professional.

### Acceptance Criteria
- [ ] Professional, compassionate, and scientifically accurate language.
- [ ] Explicitly states correlation vs causation limitation.
- [ ] Includes error margin of $pprox 31$ minutes.
- [ ] Recommends clinical medical consultation for persistent sleep disorders.
