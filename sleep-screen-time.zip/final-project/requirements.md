# Final Capstone Project: Sleep Screen Time Analyzer

## Project Objective
As your final capstone project, you will build, calibrate, evaluate, and critically review a complete end-to-end Machine Learning pipeline that models the inverse relationship between evening screen exposure and sleep duration.

---

## 1. Technical Requirements & Deliverables

### A. Python Pipeline Script (`main.py` or `sleep_analyzer.py`)
Your script must implement the complete data science lifecycle:
1. **Headless Visualization Backend:** Set `matplotlib.use("Agg")` prior to importing pyplot.
2. **Automated Directory Handling:** Programmatically verify and create the `outputs/` folder.
3. **Data Loading & Validation:**
   - Ingest `data/sleep_screen.csv`.
   - Validate that columns `screen_time_hours` and `sleep_hours` exist and contain no null values.
4. **Feature & Target Extraction:**
   - Construct a 2-dimensional feature matrix $X$ using double brackets: `df[['screen_time_hours']]`.
   - Construct a 1-dimensional target vector $y$: `df['sleep_hours']`.
5. **Reproducible Partitioning:**
   - Partition data using `train_test_split` with `test_size=0.25` and `random_state=42`.
   - Verify that 26 training rows and 9 testing rows are generated.
6. **Model Calibration:**
   - Fit `LinearRegression` on the training data.
   - Extract slope (`coef_[0]`) and intercept (`intercept_`) as standard Python `float` values.
7. **Inference & Metrics Calculation:**
   - Generate test set predictions and calculate Mean Absolute Error (`mean_absolute_error`).
   - Calculate the coefficient of determination ($R^2$) using `r2_score`.
   - Calculate Pearson correlation coefficient across the whole dataset using pandas `.corr()`.
   - Predict expected sleep for a candidate who uses 3.0 hours of evening screen time.
8. **Visualization Generation:**
   - Generate a high-resolution scatter plot ($7 \times 5$ inches, 150 DPI).
   - Display training points as navy circles (`#2c3e50`) and test points as orange squares (`#e67e22`).
   - Plot a crimson downward regression trendline (`#c0392b`, linewidth 2.5).
   - Plot the 3.0-hour test prediction using a large black star (`#111111`, marker `*`, size 220, `zorder=5`).
   - Include axis labels with units, clear plot title, grid with transparency 0.25, and a descriptive legend.
   - Save to `outputs/sleep_regression.png` with `bbox_inches="tight"`.
9. **Metric Logging:**
   - Write equation parameters, correlation, MAE, R², and candidate prediction to `outputs/metrics.txt`.

---

## 2. Analytical & Ethical Report (`report.md`)
Along with your code, you must submit a brief technical report addressing:
- **Rate-of-Change Interpretation:** Translate the slope ($-0.57$) into everyday units (minutes per hour of screen time).
- **Baseline Plausibility:** Discuss the intercept ($9.25$ hours) and whether 9.25 hours of baseline sleep makes sense for young adults.
- **Goodness-of-Fit Interpretation:** Interpret what $R^2 = 0.44$ indicates about unmeasured factors affecting human sleep.
- **Correlation vs. Causation Disclaimer:** Formulate a formal medical/scientific disclaimer explaining why this model does not prove direct causation, citing at least two potential confounding variables (e.g., job stress, irregular bedtime habits).
