# Capstone Solution Guide: Sleep Screen Time Analyzer

This document provides a comprehensive reference implementation and detailed commentary for the Sleep Screen Time Analyzer capstone project.

---

## 1. Complete Reference Implementation

```python
"""Capstone Solution: The Sleep vs. Screen Time Analyzer.

Demonstrates single-variable linear regression with an inverse slope,
proper headless visualization, test evaluation, and ethical reporting.
"""

from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)


def run_pipeline() -> None:
    # 1. Ingest Data
    csv_path = DATA / "sleep_screen.csv"
    if not csv_path.exists():
        raise FileNotFoundError(f"Missing dataset at {csv_path}")
    
    df = pd.read_csv(csv_path)
    
    # 2. Extract 2D Feature Matrix and 1D Target Vector
    X = df[["screen_time_hours"]]
    y = df["sleep_hours"]
    
    # 3. Partition Data (75% Train, 25% Test)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42
    )
    
    # 4. Train Linear Regression Model
    model = LinearRegression()
    model.fit(X_train, y_train)
    
    # 5. Extract Coefficients and Predict on Test Set
    slope = float(model.coef_[0])
    intercept = float(model.intercept_)
    predictions = model.predict(X_test)
    
    # 6. Calculate Statistical Metrics
    mae = float(mean_absolute_error(y_test, predictions))
    r2 = float(r2_score(y_test, predictions))
    correlation = float(df["screen_time_hours"].corr(df["sleep_hours"]))
    
    # 7. Evaluate 3.0-hour Candidate Scenario
    query_df = pd.DataFrame({"screen_time_hours": [3.0]})
    example_pred = float(model.predict(query_df)[0])
    
    # 8. Print Console Report
    print("=" * 60)
    print("THE SLEEP VS. SCREEN TIME DETECTIVE")
    print("=" * 60)
    print(f"Model: sleep = {slope:.2f} x screen time + {intercept:.2f}")
    print(f"Correlation: {correlation:.2f} (negative means they move in opposite directions)")
    print(f"Mean absolute error: {mae:.2f} hours")
    print(f"R-squared: {r2:.2f}")
    print(f"Prediction for 3 hours of screen time: {example_pred:.1f} hours of sleep")
    print("\nImportant: this does not prove that screen time causes less sleep.")
    
    # 9. Render Regression Plot
    line_x = np.linspace(df["screen_time_hours"].min(), df["screen_time_hours"].max(), 100)
    line_y = model.predict(pd.DataFrame({"screen_time_hours": line_x}))
    
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.scatter(X_train, y_train, color="#2c3e50", s=55, label="training data")
    ax.scatter(X_test, y_test, color="#e67e22", s=65, marker="s", label="test data")
    ax.plot(line_x, line_y, color="#c0392b", linewidth=2.5, label="trend line")
    ax.scatter([3.0], [example_pred], color="#111111", marker="*", s=220, zorder=5, label="3-hour example")
    
    ax.set_xlabel("Screen time before bed (hours)")
    ax.set_ylabel("Sleep (hours)")
    ax.set_title("Screen time vs. sleep duration")
    ax.legend()
    ax.grid(alpha=0.25)
    fig.tight_layout()
    
    plot_path = OUT / "sleep_regression.png"
    fig.savefig(plot_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    
    # 10. Persist Metrics File
    metrics_path = OUT / "metrics.txt"
    with open(metrics_path, "w", encoding="utf-8") as handle:
        handle.write(f"equation: sleep = {slope:.4f} * screen_time + {intercept:.4f}\n")
        handle.write(f"correlation: {correlation:.4f}\n")
        handle.write(f"MAE: {mae:.4f}\nR2: {r2:.4f}\n")
        handle.write(f"prediction at 3 hours: {example_pred:.2f}\n")
        
    print(f"\nSaved: {plot_path.name}, {metrics_path.name}")


if __name__ == "__main__":
    run_pipeline()
```

---

## 2. Key Implementation Details & Verification Checklist

- **Double Brackets vs Single Bracket:**
  `X = df[["screen_time_hours"]]` produces a 2D DataFrame of shape `(35, 1)`. If single brackets were used (`df["screen_time_hours"]`), scikit-learn would throw: `ValueError: Expected 2D array, got 1D array instead`.
- **Target Extraction:**
  `y = df["sleep_hours"]` yields a 1D Series of shape `(35,)`, which matches scikit-learn's target expectation.
- **Conversion to Standard Floats:**
  `model.coef_` is a NumPy ndarray (`array([-0.5694...])`). Accessing `float(model.coef_[0])` ensures clean scalar formatting for string interpolation and file output.
- **Synthetic Linspace Grid:**
  `np.linspace(df["screen_time_hours"].min(), df["screen_time_hours"].max(), 100)` generates evenly spaced points across the feature domain to draw a crisp, continuous regression line without relying on ordered dataset points.
