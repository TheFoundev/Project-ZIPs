# Architecture & Pipeline Design

This document details the architectural blueprint, data flow, and module boundaries of **The Sleep vs Screen Time Analyzer**.

---

## 1. High-Level System Architecture

```text
+-----------------------+
|  data/sleep_screen.csv|
+-----------+-----------+
            |
            v  (pandas.read_csv)
+-----------------------+
|    Raw DataFrame      |  Shape: (35, 2)
+-----------+-----------+
            |
            +---------------------------------+
            |                                 |
            v (2D DataFrame Extraction)       v (1D Series Extraction)
+-----------------------+         +-----------------------+
|   Feature Matrix (X)  |         |   Target Vector (y)   |
|   screen_time_hours   |         |      sleep_hours      |
|     Shape: (35, 1)    |         |     Shape: (35,)      |
+-----------+-----------+         +-----------+-----------+
            |                                 |
            +----------------+----------------+
                             |
                             v  (train_test_split: 75% Train, 25% Test, random_state=42)
+-------------------------------------------------------------+
| Partitioned Datasets:                                        |
|   X_train (26, 1)    y_train (26,)                          |
|   X_test  (9, 1)     y_test  (9,)                           |
+------------------------------+------------------------------+
                               |
                               v  (LinearRegression.fit)
+-------------------------------------------------------------+
| Trained Scikit-Learn Model                                  |
|   Learned Parameters: slope = -0.57, intercept = 9.25        |
+------------------------------+------------------------------+
                               |
            +------------------+------------------+
            |                                     |
            v (predict on X_test)                 v (predict on X=3.0)
+-----------------------+             +-----------------------+
| Evaluation Metrics    |             | Example Prediction    |
|   MAE = 0.52 hours    |             |   Input: 3.0 hours    |
|   R² = 0.44           |             |   Output: 7.5 hours   |
+-----------+-----------+             +-----------+-----------+
            |                                     |
            +------------------+------------------+
                               |
                               v
+-------------------------------------------------------------+
| Output Generation & Artifact Persistence                    |
|   1. outputs/sleep_regression.png (matplotlib scatter + line)|
|   2. outputs/metrics.txt (equation, MAE, R², prediction)    |
|   3. Console Summary Output                                 |
+-------------------------------------------------------------+
```

---

## 2. Component Directory Layout

```text
10_sleep_screen_time/
├── main.py                      # Main executable training & evaluation script
├── data/
│   └── sleep_screen.csv         # 35 records of screen time vs sleep hours
└── outputs/
    ├── sleep_regression.png     # Rendered downward regression plot
    └── metrics.txt              # Plaintext evaluation summary and coefficients
```

---

## 3. Data Transformation Stages

1. **Ingestion & Integrity Check:** Data is read using `pd.read_csv()`. The two numerical columns are verified to be continuous floating-point numbers.
2. **Feature Matrix Formulation ($X$):** Scikit-learn requires feature inputs to be 2-dimensional ($N \times P$). We select `df[['screen_time_hours']]` with double brackets to create a DataFrame of shape `(35, 1)`.
3. **Target Vector Formulation ($y$):** The single dependent variable is extracted as a 1D pandas Series of shape `(35,)`.
4. **Deterministic Partitioning:** `train_test_split` partitions the 35 records into 26 training rows and 9 testing rows, fixing `random_state=42` for exact reproducibility.
5. **Optimization (Ordinary Least Squares):** The model minimizes the residual sum of squares:
   $$\min_{\beta_0, \beta_1} \sum_{i=1}^{N_{train}} \left( y_i - (\beta_0 + \beta_1 x_i) \right)^2$$
6. **Inference & Visualization:** A 100-point synthetic grid across the observed range of screen hours generates a smooth downward regression line overlaid across training and testing points.
