# All Correct Answers for Assessments
Project: The Sleep vs Screen Time Analyzer
---

## Module 01: Project Overview — Sleep Science and the Regression Problem

**q1-01.** What is the primary target variable that the Sleep vs Screen Time Analyzer aims to predict?
   **Correct Answer:** b. Nightly sleep duration in hours
   *Explanation:* The project's objective is to estimate nightly sleep duration (sleep_hours) based on evening screen exposure. In supervised regression, the variable we wish to estimate is the dependent target variable y.

**q1-02.** Which independent feature column is used as input (X) to the model?
   **Correct Answer:** b. screen_time_hours
   *Explanation:* screen_time_hours is the independent feature (X) passed into the model to predict sleep duration. In main.py, X is extracted as df[['screen_time_hours']].

**q1-03.** Why is this task classified as a regression problem rather than a classification problem?
   **Correct Answer:** c. Because the target variable (sleep_hours) is a continuous numeric measurement
   *Explanation:* Regression algorithms predict continuous real-valued numbers (such as 6.8 hours, 7.5 hours, 8.4 hours). When the target is continuous rather than discrete categories, regression must be used.

**q1-04.** What does a negative correlation between screen time and sleep duration imply?
   **Correct Answer:** c. As screen time increases, sleep duration tends to decrease
   *Explanation:* A negative correlation signifies an inverse relationship: as the value of one variable increases, the expected value of the other variable decreases.

**q1-05.** In main.py, why is `matplotlib.use('Agg')` invoked before importing `matplotlib.pyplot`?
   **Correct Answer:** b. To select a headless non-GUI backend that renders plots directly to files without a display server
   *Explanation:* The 'Agg' backend renders figures directly to image files (raster PNGs) in memory without attempting to connect to a desktop display server, allowing scripts to run headlessly on servers or CI/CD pipelines.

**q1-06.** Why does `main.py` construct directory paths using `Path(__file__).resolve().parent`?
   **Correct Answer:** a. To guarantee paths resolve relative to the script's directory rather than the current working directory
   *Explanation:* Path(__file__).resolve().parent determines the absolute path of the directory containing main.py. This ensures that relative path joins (like BASE / 'data') always point to the correct files regardless of the directory from which the command was invoked.

**q1-07.** Which of the following best characterizes supervised learning in this project?
   **Correct Answer:** b. Learning a mapping function from labeled historical pairs of (screen_time_hours, sleep_hours)
   *Explanation:* Supervised learning algorithms are trained on labeled datasets containing both input features (X) and known target values (y) to learn a general mapping function f(X) -> y.

**q1-08.** What physiological mechanism connects pre-bedtime screen exposure to delayed sleep onset?
   **Correct Answer:** b. Blue light exposure suppresses melatonin production and interactive content increases cognitive arousal
   *Explanation:* Clinical sleep research shows that short-wavelength blue light from screens suppresses melatonin release from the pineal gland, while interactive media increases psychological arousal, disrupting natural circadian rhythms.

**q1-09.** If a regression model yields the equation y = -0.57x + 9.25, what is the geometric interpretation of the slope -0.57?
   **Correct Answer:** c. The line slopes downward from left to right, falling 0.57 units vertically for every 1 unit increase in x
   *Explanation:* A negative slope m = -0.57 means that for every 1-unit increase along the horizontal x-axis, the line drops vertically by 0.57 units along the y-axis, resulting in a downward-sloping linear trajectory.

**q1-10.** Why does the project docstring caution that 'a trend is not proof of cause and effect'?
   **Correct Answer:** b. Because observational correlation cannot rule out confounding variables such as stress, workload, or caffeine
   *Explanation:* Correlation indicates that two variables change together, but cannot determine whether screen time directly causes reduced sleep, or whether external confounding factors (like intense academic stress or caffeine intake) drive both behaviors.


## Module 02: Data & Negative Correlation — Ingestion, Scatter Plots, and Pearson's r

**q2-01.** How many observational rows are present in the sleep_screen.csv dataset?
   **Correct Answer:** b. 35
   *Explanation:* The sleep_screen.csv file contains 36 lines in total: 1 header line and exactly 35 observational rows of data.

**q2-02.** What visual pattern indicates an inverse relationship in a scatter plot?
   **Correct Answer:** c. Points sloping downward from the top-left to bottom-right
   *Explanation:* In a Cartesian scatter plot, an inverse relationship causes points with low x-values to have high y-values and points with high x-values to have low y-values, producing a downward slope from top-left to bottom-right.

**q2-03.** What is the theoretical range of values that the Pearson correlation coefficient (r) can assume?
   **Correct Answer:** b. -1.0 to +1.0
   *Explanation:* By Cauchy-Schwarz inequality and standardization by standard deviations, Pearson's r is strictly bounded within the closed interval [-1.0, +1.0].

**q2-04.** In main.py, how is the feature matrix X extracted from the pandas DataFrame df?
   **Correct Answer:** b. X = df[['screen_time_hours']]
   *Explanation:* In main.py line 30, double brackets df[['screen_time_hours']] are used to extract a 2D pandas DataFrame, which satisfies scikit-learn's requirement for a 2-dimensional feature matrix.

**q2-05.** What shape does scikit-learn mandate for the feature matrix X in linear regression?
   **Correct Answer:** b. 2-dimensional: (n_samples, n_features)
   *Explanation:* Scikit-learn design specifications require all feature matrices (X) to have 2 dimensions: (n_samples, n_features). For 1 feature, the shape must be (n_samples, 1).

**q2-06.** What does a calculated Pearson correlation coefficient of r = -0.85 indicate about the data?
   **Correct Answer:** c. A strong negative linear association between screen time and sleep duration
   *Explanation:* The minus sign confirms an inverse relationship (variables move in opposite directions), and the absolute value |0.85| exceeds 0.70, denoting a strong linear association.

**q2-07.** What error is raised by scikit-learn if a 1D pandas Series is passed to LinearRegression().fit() as X?
   **Correct Answer:** c. ValueError: Expected 2D array, got 1D array instead
   *Explanation:* When scikit-learn's validation utility check_array receives a 1D array where a 2D matrix was expected, it explicitly raises 'ValueError: Expected 2D array, got 1D array instead'.

**q2-08.** How is the Pearson correlation coefficient between the two columns calculated in pandas in main.py?
   **Correct Answer:** b. df['screen_time_hours'].corr(df['sleep_hours'])
   *Explanation:* In pandas, calling df['colA'].corr(df['colB']) computes the Pearson correlation coefficient between the two Series. This is the exact syntax used in line 45 of main.py.

**q2-09.** What is the crucial difference between the Pearson correlation coefficient (r) and the regression slope (m)?
   **Correct Answer:** b. Correlation is unitless and standardized between -1 and +1, whereas slope has physical units (hours/screen hour) and depends on scale
   *Explanation:* Correlation (r) is dimensionless and standardized (always between -1 and +1), whereas slope (m = r * (s_y / s_x)) represents the unstandardized physical rate of change in target units per unit feature.

**q2-10.** If all screen time measurements were multiplied by 60 (converting hours to minutes), how would the Pearson correlation coefficient (r) and regression slope (m) change?
   **Correct Answer:** b. r would remain exactly -0.85 (scale-invariant), while m would be divided by 60
   *Explanation:* Pearson's r is invariant to positive linear scale transformations because the scaling factor cancels out in the numerator and denominator. However, the slope m = Δy / Δx has minutes in the denominator, so m is divided by 60 (-0.57 / 60 ≈ -0.0095 hours of sleep lost per minute of screen time).


## Module 03: Linear Regression with Negative Slope — Mathematical Interpretation & OLS

**q3-01.** In the linear regression equation sleep = -0.57 * screen_time + 9.25, what does the number 9.25 represent?
   **Correct Answer:** b. The y-intercept: the predicted baseline sleep duration when screen time is zero hours
   *Explanation:* In linear regression y = mx + c, the constant term c represents the y-intercept: the estimated value of the target (sleep) when the input feature (screen time) is exactly 0.

**q3-02.** What is the learned slope (coefficient) of the linear regression model in this project?
   **Correct Answer:** b. -0.57
   *Explanation:* The trained model's slope is approximately -0.57 (specifically -0.5694...), indicating that sleep drops by 0.57 hours for each additional hour of screen time.

**q3-03.** When converting the slope -0.57 hours into minutes, how much sleep is lost for every additional hour of evening screen time?
   **Correct Answer:** b. Approximately 34.2 minutes
   *Explanation:* To convert decimal hours to minutes, multiply by 60: 0.57 hours * 60 minutes/hour = 34.2 minutes of lost sleep per additional hour of screen time.

**q3-04.** What does a residual (e_i) represent in linear regression?
   **Correct Answer:** b. The vertical difference between the actual observed value (y_i) and the model's predicted value (y_hat_i)
   *Explanation:* A residual is defined as the difference between the observed truth and the model's estimate: e_i = y_i - y_hat_i. Geometrically, it is the vertical distance from a point to the regression line.

**q3-05.** Why does Ordinary Least Squares minimize the SUM OF SQUARED residuals rather than the simple sum of raw residuals?
   **Correct Answer:** d. All of the above
   *Explanation:* All three reasons are fundamental mathematical justifications for least-squares optimization: avoiding cancellation of opposing signs, penalizing large outliers, and ensuring a differentiable convex loss function.

**q3-06.** Using the equation sleep = -0.57 * screen_time + 9.25, what is the predicted sleep duration for an individual with 2.0 hours of screen time?
   **Correct Answer:** b. 8.11 hours
   *Explanation:* Plugging x = 2.0 into the equation: sleep = -0.57(2.0) + 9.25 = -1.14 + 9.25 = 8.11 hours of sleep.

**q3-07.** In scikit-learn, what public attributes store the learned slope and intercept on a fitted LinearRegression model?
   **Correct Answer:** b. model.coef_ and model.intercept_
   *Explanation:* In scikit-learn's standard API, fitted model parameters are stored in public attributes ending with an underscore: coef_ for coefficients/slopes and intercept_ for the intercept.

**q3-08.** Why is the baseline intercept of 9.25 hours considered realistic in this project, unlike the negative sales intercept in the Lemonade Stand project?
   **Correct Answer:** a. Because screen time = 0 is a plausible and healthy human behavior that yields restorative sleep
   *Explanation:* Zero evening screen time is a realistic, achievable habit, and 9.25 hours represents healthy restorative sleep duration for adolescents and young adults. In contrast, negative cups of lemonade at 0°C is physically impossible.

**q3-09.** If an individual decreases their screen time by 2.0 hours (Delta x = -2.0), what is the predicted change in their sleep duration?
   **Correct Answer:** b. They gain approximately 1.14 hours (about 68.4 minutes) of sleep
   *Explanation:* Using Delta y = m * Delta x: Delta y = -0.57 * (-2.0) = +1.14 hours. Since screen time decreased, sleep duration increases by 1.14 hours (1.14 * 60 ≈ 68.4 minutes).

**q3-10.** Mathematically, why does the Ordinary Least Squares slope formula beta_1 = Cov(X, Y) / Var(X) produce a negative value in this project?
   **Correct Answer:** b. Because the covariance Cov(X, Y) is negative due to high screen times pairing with low sleep durations
   *Explanation:* The variance Var(X) is always strictly positive (sum of squares > 0). The covariance Cov(X, Y) = Sum[(x_i - x_bar)(y_i - y_bar)] is negative because above-average screen times pair with below-average sleep hours. A negative numerator divided by a positive denominator yields a negative slope.


## Module 04: Model Training & Prediction — Fitting, Parameter Extraction, and Inference

**q4-01.** What does train_test_split(X, y, test_size=0.25, random_state=42) do in main.py?
   **Correct Answer:** b. Partitions data into 75% for training (26 rows) and 25% for testing (9 rows)
   *Explanation:* train_test_split partitions the 35 records into a training set of 26 samples (75%) and an independent test set of 9 samples (25%) using pseudo-random sampling.

**q4-02.** Which scikit-learn method is called to train the LinearRegression model on training data?
   **Correct Answer:** c. model.fit()
   *Explanation:* In scikit-learn's standard API, the model training method is universally named .fit().

**q4-03.** What is the model's predicted sleep duration for a candidate with 3.0 hours of evening screen time?
   **Correct Answer:** b. 7.5 hours
   *Explanation:* For 3.0 hours of screen time, the model computes: -0.57(3.0) + 9.25 = -1.71 + 9.25 = 7.54 hours, which formats to 7.5 hours.

**q4-04.** Why is the random_state parameter set to 42 in train_test_split?
   **Correct Answer:** b. It sets a fixed seed for the pseudo-random generator to ensure reproducible dataset splits
   *Explanation:* Setting random_state initializes the seed for the pseudo-random shuffling algorithm, ensuring that every run produces the exact same train/test split.

**q4-05.** In scikit-learn, what data structure does model.predict() return?
   **Correct Answer:** b. A 1-dimensional NumPy ndarray of predicted values
   *Explanation:* model.predict() computes predictions for all rows in the input matrix and returns a 1D NumPy ndarray containing the continuous numeric predictions.

**q4-06.** Why does main.py use float(model.coef_[0]) instead of float(model.coef_)?
   **Correct Answer:** a. Because model.coef_ is a NumPy array, and indexing [0] extracts the scalar slope value
   *Explanation:* In scikit-learn, model.coef_ is an ndarray of shape (n_features,). Indexing [0] accesses the scalar element (-0.5694), which can then be cleanly cast to a Python float.

**q4-07.** Why is it best practice to pass query features to model.predict() as a DataFrame with matching column names rather than a raw NumPy array [[3.0]]?
   **Correct Answer:** a. It prevents UserWarning: X does not have valid feature names and guarantees schema alignment
   *Explanation:* When a model is trained on a pandas DataFrame, scikit-learn records feature names in feature_names_in_. Passing an unnamed array triggers a UserWarning advising that feature names were missing. Using a matching DataFrame ensures schema fidelity and eliminates warnings.

**q4-08.** What happens if an engineer fits a model on the entire dataset (model.fit(X, y)) before splitting into train and test sets?
   **Correct Answer:** b. Data leakage occurs, artificially inflating test evaluation scores and masking true generalization performance
   *Explanation:* Fitting on the entire dataset allows test information to influence model parameters (data leakage). Consequently, test metrics evaluate memorized data rather than genuine out-of-sample generalization.

**q4-09.** If a student attempts to access model.coef_ immediately after executing model = LinearRegression() without calling .fit(), what occurs?
   **Correct Answer:** c. An AttributeError is raised because estimated attributes are created only upon calling .fit()
   *Explanation:* Estimated attributes with trailing underscores (like coef_ and intercept_) are instantiated dynamically inside the .fit() method. Accessing them before calling .fit() raises an AttributeError.

**q4-10.** In a batch prediction where screen times are [1.0, 3.0, 5.0], how will the predicted sleep hours behave?
   **Correct Answer:** c. They will decrease monotonically (e.g., 8.7, 7.5, 6.4)
   *Explanation:* Because the slope is strictly negative (m = -0.57), any monotonic increase in input screen time produces a strictly monotonic decrease in predicted sleep hours.


## Module 05: Evaluation & Visualization — MAE, R², Trendlines, and Output Logging

**q5-01.** What is the Mean Absolute Error (MAE) of the model on the test dataset in this project?
   **Correct Answer:** b. 0.52 hours
   *Explanation:* The Mean Absolute Error (MAE) computed on the 9 test samples in main.py is approximately 0.52 hours (specifically ~0.5190 hours).

**q5-02.** What is the test R-squared (R²) score achieved by the linear regression model?
   **Correct Answer:** b. 0.44
   *Explanation:* The test set R-squared score is 0.44 (specifically ~0.4410), indicating that 44% of test sleep duration variance is explained by screen time.

**q5-03.** What two artifact files are saved to the outputs/ directory by main.py?
   **Correct Answer:** b. sleep_regression.png and metrics.txt
   *Explanation:* main.py explicitly creates and saves outputs/sleep_regression.png (the regression figure) and outputs/metrics.txt (the textual report).

**q5-04.** In everyday units, what does a Mean Absolute Error of 0.52 hours represent?
   **Correct Answer:** b. An average error of approximately 31.2 minutes
   *Explanation:* Multiplying 0.52 hours by 60 minutes/hour yields 31.2 minutes: 0.52 * 60 = 31.2 minutes average absolute error.

**q5-05.** What does the R² score of 0.44 tell a data scientist about the relationship between screen time and sleep?
   **Correct Answer:** b. Pre-bed screen time accounts for 44% of the variance in nightly sleep duration within the test cohort
   *Explanation:* R-squared represents the proportion of variance in the dependent variable explained by the regression model. 0.44 means screen time accounts for 44% of the variance in test sleep duration.

**q5-06.** Why does main.py use np.linspace() to generate points for plotting the trend line instead of plotting predictions directly on X_train?
   **Correct Answer:** a. Because X_train points are unordered, which would cause ax.plot() to draw a jagged zig-zag line
   *Explanation:* ax.plot() connects consecutive coordinates with straight line segments in the order they appear. If features are not strictly sorted, the line jumps back and forth, creating a jagged zig-zag. np.linspace generates monotonic, evenly spaced points to draw a smooth line.

**q5-07.** In the visualization generated by main.py, how are the training and test data points visually differentiated?
   **Correct Answer:** a. Training points are navy circles (#2c3e50), while test points are orange squares (#e67e22)
   *Explanation:* In main.py lines 62-63, training points are plotted as navy circles (color='#2c3e50', marker='o') and test points as orange squares (color='#e67e22', marker='s').

**q5-08.** What visual element is placed on the plot to highlight the model's prediction for 3 hours of screen time?
   **Correct Answer:** b. A large black star marker (marker='*', s=220) at (3.0, 7.5)
   *Explanation:* In main.py line 65, the 3-hour example prediction is highlighted using a large black star: ax.scatter([3], [example], color='#111111', marker='*', s=220, zorder=5).

**q5-09.** How does Mean Absolute Error (MAE) differ mathematically from Root Mean Squared Error (RMSE)?
   **Correct Answer:** b. MAE treats all error magnitudes linearly, whereas RMSE squares errors before averaging, penalizing large outliers much more heavily
   *Explanation:* MAE computes the simple average of absolute errors |y - y_hat|, scaling linearly. RMSE squares each error before taking the root, giving exponentially greater weight to larger errors.

**q5-10.** Under what circumstance can the Coefficient of Determination (R²) become negative on an out-of-sample test set?
   **Correct Answer:** b. When the model's test predictions perform worse than a horizontal line predicting the test mean (SS_res > SS_tot)
   *Explanation:* R² = 1 - (SS_res / SS_tot). If the model's test predictions are worse than simply predicting the mean of the test set, SS_res exceeds SS_tot, making the fraction > 1, resulting in a negative R² score.


## Module 06: Correlation vs Causation & Ethics — Confounding Variables and Responsible AI

**q6-01.** What fundamental principle in statistics warns against interpreting correlation as direct cause and effect?
   **Correct Answer:** b. Correlation does not imply causation
   *Explanation:* 'Correlation does not imply causation' is the foundational axiom reminding researchers that statistical co-movement does not prove that one variable causally drives the other.

**q6-02.** What explicit cautionary message does main.py print immediately after outputting the prediction?
   **Correct Answer:** b. Important: this does not prove that screen time causes less sleep.
   *Explanation:* In main.py line 56, the script explicitly prints: 'Important: this does not prove that screen time causes less sleep.'

**q6-03.** What is an example of reverse causality in the context of the sleep vs screen time study?
   **Correct Answer:** b. An individual who cannot fall asleep due to insomnia picking up their smartphone to pass the time
   *Explanation:* Reverse causality occurs when the outcome causes the predictor. In sleep medicine, someone who is already suffering from insomnia and unable to sleep often turns to their phone or television out of boredom, making poor sleep the cause of screen time.

**q6-04.** What is a confounding variable?
   **Correct Answer:** b. An unmeasured external factor that influences both the independent feature and the dependent target
   *Explanation:* A confounding variable is an extraneous unmeasured variable that correlates with both the independent feature (X) and the dependent target (y), creating a spurious or distorted statistical association.

**q6-05.** Which of the following is a plausible confounding variable that could explain BOTH high screen time and reduced sleep?
   **Correct Answer:** d. All of the above
   *Explanation:* All three factors—stress, caffeine, and shift work—are classic epidemiological confounders that independently increase screen exposure while disrupting sleep duration.

**q6-06.** Why does collecting a larger sample size (e.g., 50,000 participants instead of 35) fail to resolve confounding bias in observational studies?
   **Correct Answer:** b. Because increasing sample size reduces random sampling variance, but does not alter systemic confounding pathways between unmeasured variables
   *Explanation:* Increasing sample size tightens confidence intervals and reduces random sampling noise, but leaves systemic confounding bias completely intact. A biased study on a massive cohort simply measures the confounded correlation with higher statistical precision.

**q6-07.** What is 'orthosomnia' in the context of digital sleep trackers?
   **Correct Answer:** b. An unhealthy, anxiety-inducing obsession with tracking and optimizing sleep metrics generated by consumer wearables and AI apps
   *Explanation:* Orthosomnia is a recognized clinical phenomenon where patients develop insomnia and anxiety driven by an obsessive fixation on achieving 'perfect' sleep scores on smartwatches and wellness apps.

**q6-08.** What feature does the final print line of main.py suggest adding to extend the model?
   **Correct Answer:** b. 'weekend'
   *Explanation:* In line 82 of main.py, the script explicitly suggests: 'Try this: add "weekend" as a second feature and see whether it helps.'

**q6-09.** How does adding a binary 'is_weekend' indicator variable affect the geometry of a multiple linear regression model?
   **Correct Answer:** b. It fits two parallel downward regression lines: one for weekdays and an offset baseline line for weekends
   *Explanation:* In multiple linear regression with one continuous and one binary feature (y = b1*x1 + b2*x2 + b0), the model fits two parallel lines: one with intercept b0 (for weekdays, x2=0) and one with intercept b0 + b2 (for weekends, x2=1), both sharing the same slope b1.

**q6-10.** What experimental design is required in clinical science to prove that screen exposure directly causes a reduction in sleep duration?
   **Correct Answer:** b. A Randomized Controlled Trial (RCT) where participants are randomly assigned to strict screen-exposure vs screen-free protocols with controlled confounding factors
   *Explanation:* To establish medical causation, researchers must conduct a Randomized Controlled Trial (RCT) where participants are randomly allocated to experimental and control conditions, balancing all known and unknown confounders across groups.
