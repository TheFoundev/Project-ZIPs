# The Sleep vs Screen Time Analyzer

Welcome to **The Sleep vs Screen Time Analyzer** educational package! This project teaches foundational machine learning concepts through an intuitive, real-world health question: **How does evening screen time affect our nightly sleep?**

Unlike introductory regression examples that feature positive slopes (such as temperature increasing lemonade sales), this project explores an **inverse relationship** characterized by a **negative slope** and **negative correlation**.

---

## 🎯 Educational Overview

- **Core Algorithm:** Supervised Linear Regression (`sklearn.linear_model.LinearRegression`)
- **Key Phenomenon:** Negative Correlation ($r = -0.85$) and Negative Slope ($m pprox -0.57$)
- **Domain Context:** Sleep hygiene, digital wellness, and the physiology of pre-bedtime screen exposure
- **Critical Data Science Lesson:** **Correlation is not causation** — recognizing confounding variables like work stress, late schedules, and caffeine consumption

---

## 📊 Dataset & Model Highlights

The model is trained on observational records containing pre-bed screen exposure and resulting sleep hours:
- **Feature ($X$):** `screen_time_hours` (daily screen time before bed in hours)
- **Target ($y$):** `sleep_hours` (total sleep duration in hours)
- **Learned Formula:**
  $$\text{sleep\_hours} = -0.57 \times \text{screen\_time\_hours} + 9.25$$
- **Baseline Intercept ($9.25$ hours):** Theoretical sleep duration with zero evening screen time.
- **Negative Slope ($-0.57$ hours):** Each additional hour of screen time is associated with approximately $34.2$ fewer minutes of sleep.
- **Prediction Scenario (3.0 hours):** Predicting sleep for a 3-hour evening screen time yields $\approx 7.5$ hours of sleep.
- **Evaluation:** Mean Absolute Error (MAE) of $0.52$ hours ($pprox 31$ minutes) and $R^2 = 0.44$.

---

## 🗂️ Curriculum Modules

1. **Module 01: Project Overview & Problem Framing** — Sleep science context, regression vs classification, and supervised learning paradigms.
2. **Module 02: Data Exploration & Negative Correlation** — Data ingestion with pandas, scatter visualization, and Pearson correlation coefficient ($r = -0.85$).
3. **Module 03: Linear Regression with Negative Slope** — Mathematical deep dive into $y = mx + c$, interpreting negative rates of change, and baseline intercepts.
4. **Module 04: Model Training & Prediction** — Train/test splitting (75/25), fitting scikit-learn's estimator, extracting parameters, and forecasting sleep duration.
5. **Module 05: Evaluation & Visualization** — Computing MAE and $R^2$, plotting downward trendlines, and saving artifacts (`sleep_regression.png` and `metrics.txt`).
6. **Module 06: Correlation vs Causation & Ethics** — Confounding variables, ethical reporting in health AI, and multivariate modeling extensions.

---

## 🚀 Quickstart Guide

To execute the reference model code:

```bash
# Navigate to the source project
cd "beginner-projects-main/AI-ML Beginners/projects/10_sleep_screen_time"

# Install required dependencies
pip install pandas numpy matplotlib scikit-learn

# Run the analyzer
python main.py
```

### Expected Output
```text
============================================================
THE SLEEP VS. SCREEN TIME DETECTIVE
============================================================
Model: sleep = -0.57 x screen time + 9.25
Correlation: -0.85 (negative means they move in opposite directions)
Mean absolute error: 0.52 hours
R-squared: 0.44
Prediction for 3 hours of screen time: 7.5 hours of sleep

Important: this does not prove that screen time causes less sleep.

Saved: outputs/sleep_regression.png, outputs/metrics.txt
Try this: add 'weekend' as a second feature and see whether it helps.
```
