# Module 01 Exercises: Problem Understanding, Features & Pipelines

---

## Exercise 1.1: Classification vs. Regression Analysis

**Objective:** Understand the fundamental difference between classification and regression and categorize The Snack Sorter appropriately.

**Problem Statement:**
A junior developer on your team suggests modifying The Snack Sorter to predict a continuous number representing "fruit ripeness percentage" instead of the fruit category (`apple`, `banana`, `orange`). You need to explain why the current project is a multi-class classification problem and distinguish it from regression.

**Requirements:**
1. Define supervised classification and supervised regression in your own words.
2. State the target variable ($y$) in The Snack Sorter and list its possible values.
3. Classify The Snack Sorter as binary classification, multi-class classification, or regression, providing a clear justification.
4. Give one example of a regression task that could be performed on the same fruit photos.

**Constraints:**
- Rely strictly on the concepts introduced in Module 01 and lines 1–9 of `main.py`.

**Expected Behaviour:**
A written response (3–5 paragraphs) clearly articulating the theoretical and practical distinctions between classification and regression as applied to the snack dataset.

**Acceptance Criteria:**
- [ ] Correctly defines classification as predicting discrete categories.
- [ ] Correctly defines regression as predicting continuous numerical values.
- [ ] Identifies the target variable as `label` with values `apple`, `banana`, and `orange`.
- [ ] Accurately categorizes The Snack Sorter as multi-class classification (3 classes).
- [ ] Proposes a valid continuous regression scenario (e.g., fruit weight in grams, volume in cm³).

**Hints:**
- Think about what kind of value is returned by `model.predict()` in `main.py`.
- Notice that there are 3 distinct fruit options, which rules out binary classification.

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 1.2: Feature Role and Color Separation

**Objective:** Explain how the 5 visual features in `main.py` capture differences between apples, bananas, and oranges.

**Problem Statement:**
Inspect the 5 features in `FEATURES = ["mean_r", "mean_g", "mean_b", "color_fraction", "aspect_ratio"]`. You must explain how the RGB color channels distinguish between red apples and yellow bananas using the principles of additive color mixing.

**Requirements:**
1. List all 5 visual features extracted from each image.
2. Explain why yellow bananas have a high value in the Green channel (`mean_g`), despite yellow not being in the acronym RGB.
3. Compare the typical values of `mean_g` across apples, bananas, and oranges.
4. Explain what `aspect_ratio` and `color_fraction` measure in terms of the snack's silhouette.

**Constraints:**
- Base your explanation on actual dataset values explored in Lesson 02.

**Expected Behaviour:**
A structured table or written analysis detailing the role of each feature in separating the three fruit classes.

**Acceptance Criteria:**
- [ ] Lists all 5 features: `mean_r`, `mean_g`, `mean_b`, `color_fraction`, and `aspect_ratio`.
- [ ] Explains that Red + Green light mixes additively to form Yellow in digital images.
- [ ] Notes that bananas have high `mean_g` (~186), oranges medium (~124), and apples low (~45).
- [ ] Accurately defines `aspect_ratio` (width/height) and `color_fraction` (foreground coverage).

**Hints:**
- Look at the RGB pixel values: an apple has low green (~45), an orange has medium green (~124), and a banana has high green (~186).
- Think about the shape of a banana versus a round apple or orange.

**Difficulty:** Intermediate
**Estimated Completion Time:** 20 minutes

---

## Exercise 1.3: KNN Distance Calculation and Voting Simulation

**Objective:** Trace the K-Nearest Neighbors voting mechanism step-by-step for a mystery test sample.

**Problem Statement:**
You are given a mystery snack sample $T$ and the distance calculations to its 5 nearest training neighbors in scaled feature space:
- Neighbor 1: distance = 0.21, label = `banana`
- Neighbor 2: distance = 0.35, label = `banana`
- Neighbor 3: distance = 0.42, label = `apple`
- Neighbor 4: distance = 0.48, label = `banana`
- Neighbor 5: distance = 0.61, label = `orange`

Simulate the decision process of `KNeighborsClassifier(n_neighbors=5)`.

**Requirements:**
1. Identify the hyperparameter $k$ used in this scenario.
2. Tally the votes for each candidate fruit class.
3. State the final predicted class output by the algorithm.
4. Explain what would happen if $k=1$ had been used instead.

**Constraints:**
- Assume standard unweighted majority voting as used in `main.py`.

**Expected Behaviour:**
A clear vote tally leading to the correct majority-winner prediction.

**Acceptance Criteria:**
- [ ] States $k=5$.
- [ ] Shows exact vote counts: 3 for `banana`, 1 for `apple`, 1 for `orange`.
- [ ] Identifies `banana` as the winning predicted class.
- [ ] Explains that if $k=1$, the prediction would still be `banana` because Neighbor 1 is closest (distance 0.21).

**Hints:**
- In standard KNN, each of the $k$ neighbors gets exactly one vote.
- The class with the highest vote count wins.

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 1.4: Pipeline Architecture and Data Leakage Prevention

**Objective:** Analyze the structure of the scikit-learn Pipeline used in `main.py` and explain why manual scaling risks data leakage.

**Problem Statement:**
In `main.py` (lines 43–48), the model is defined as:
```python
model = Pipeline(
    [
        ("scale", StandardScaler()),
        ("knn", KNeighborsClassifier(n_neighbors=5)),
    ]
)
```
A student asks why they cannot simply call `StandardScaler().fit_transform(X)` on the whole dataset before calling `train_test_split()`. You must explain what data leakage is and how the pipeline prevents it.

**Requirements:**
1. Define data leakage in the context of feature scaling.
2. Explain what statistical parameters `StandardScaler` calculates during `fit()`.
3. Describe step-by-step how `model.fit(X_train, y_train)` and `model.predict(X_test)` work inside a `Pipeline`.
4. Explain why fitting a scaler on the combined dataset prior to splitting leads to overly optimistic evaluation results.

**Constraints:**
- Reference the specific components of the `main.py` pipeline.

**Expected Behaviour:**
A concise technical explanation demonstrating clear mastery of pipelines and train/test boundaries.

**Acceptance Criteria:**
- [ ] Identifies the two steps in the pipeline: `"scale"` (`StandardScaler`) and `"knn"` (`KNeighborsClassifier`).
- [ ] Explains that `StandardScaler` learns mean ($\mu$) and standard deviation ($\sigma$).
- [ ] Clearly demonstrates how `Pipeline.fit()` only sees `X_train`.
- [ ] Explains that `Pipeline.predict()` uses training $\mu$ and $\sigma$ to transform `X_test`.
- [ ] Accurately defines data leakage and its impact on performance evaluation.

**Hints:**
- Think about what would happen if test outliers shifted the overall mean before training.
- Remember: the test set must simulate unseen future data!

**Difficulty:** Intermediate
**Estimated Completion Time:** 20 minutes
