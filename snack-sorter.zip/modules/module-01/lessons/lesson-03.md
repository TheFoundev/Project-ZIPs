# Lesson 03: The K-Nearest Neighbors (KNN) Algorithm: Intuition & Voting

**Lesson ID:** lesson-03
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain the core principle of the K-Nearest Neighbors (KNN) classification algorithm.
- Describe how distance (Euclidean distance) is used to find "similar" data points.
- Explain the role of the hyperparameter $k$ (the number of voting neighbors).
- Walk through a majority voting scenario to determine an unknown sample's class label.
- Understand why KNN is called a "lazy learner" or instance-based algorithm.

## Prerequisites

- Lesson 01: Introduction to Image Classification & The Snack Sorter Problem.
- Lesson 02: What Are Features & Why These 5 Visual Features?
- Basic arithmetic and the Pythagorean theorem / Euclidean distance concept.

## Concept Explanation

### The Intuition Behind K-Nearest Neighbors
Imagine you walk into a fruit market in a foreign country and see an unfamiliar fruit. You do not know its name, but you notice:
- Its color is bright yellow.
- Its shape is long and curved.

You look around the stalls and spot 5 fruits with almost identical color and shape. All 5 are labeled "Banana". You would naturally conclude: *"This mystery fruit is almost certainly a banana!"*

This is precisely how the **K-Nearest Neighbors (KNN)** algorithm works. It is one of the simplest, most intuitive, and most elegant algorithms in machine learning. Its philosophy is captured by the old adage: **"Birds of a feather flock together."**

### How KNN Classifies a New Point
When given an unlabelled test sample $x$, the KNN algorithm performs three steps:
1. **Compute Distances**: It measures the mathematical distance between the test sample $x$ and *every single training sample* stored in its memory.
2. **Find the $k$ Closest Neighbors**: It ranks all training samples by distance and identifies the $k$ nearest data points.
3. **Majority Vote**: It tallies the labels of those $k$ nearest neighbors. The category with the most votes becomes the predicted label for $x$.

### The Hyperparameter $k$
The letter **$k$** represents the number of neighbors that get a vote:
- If $k=1$, the model simply copies the label of the single closest neighbor. (This is sensitive to noisy outliers).
- In **The Snack Sorter**, line 46 configures:
  ```python
  KNeighborsClassifier(n_neighbors=5)
  ```
- Choosing $k=5$ means the algorithm consults the **5 closest training examples**. Having an odd number ($k=5$) helps prevent two-way ties when evaluating classes.

### How Distance Is Measured: Euclidean Distance
To determine which neighbors are "closest", KNN calculates the straight-line distance across all feature dimensions. In 2D space, this is simply the Pythagorean theorem:
$$d(p, q) = \sqrt{(p_1 - q_1)^2 + (p_2 - q_2)^2}$$

In our 5-dimensional feature space (`mean_r`, `mean_g`, `mean_b`, `color_fraction`, `aspect_ratio`), the Euclidean distance formula generalizes to:
$$d(p, q) = \sqrt{\sum_{i=1}^5 (p_i - q_i)^2}$$

The smaller the distance value $d$, the more visually similar the two snack photos are.

### Why KNN Is Called an "Instance-Based" or "Lazy" Learner
Unlike algorithms like Linear Regression or Neural Networks that learn mathematical weights and equations during training and discard the raw data, KNN does not learn a fixed formula. Instead, it literally **stores all training instances** in memory.
- **During training (`fit`)**: KNN simply stores the training feature vectors and labels.
- **During prediction (`predict`)**: All the computational heavy lifting occurs when new points arrive and distances must be computed.

## Relevant Code (from main.py, lines 22, 43-49)

```python
22: from sklearn.neighbors import KNeighborsClassifier
...
43:     model = Pipeline(
44:         [
45:             ("scale", StandardScaler()),
46:             ("knn", KNeighborsClassifier(n_neighbors=5)),
47:         ]
48:     )
49:     model.fit(X_train, y_train)
```

### Code Explanation
- **Line 22**: Imports `KNeighborsClassifier` from scikit-learn's `neighbors` module.
- **Line 46**: Instantiates the classifier with `n_neighbors=5`, setting $k=5$.
- **Line 49**: `model.fit(X_train, y_train)` fits the model using the 67 training images. For KNN, this indexes the 67 points in 5-dimensional space so that nearest neighbors can be queried rapidly.

## Worked Example

**Scenario:** Suppose we have a mystery test fruit $T$. We calculate the distance between $T$ and all 67 training examples. The 5 closest neighbors are:

| Neighbor Rank | Training Sample ID | True Label | Distance to $T$ |
|---|---|---|---|
| 1 | `orange_14.png` | `orange` | 0.18 |
| 2 | `orange_03.png` | `orange` | 0.22 |
| 3 | `orange_22.png` | `orange` | 0.29 |
| 4 | `apple_08.png` | `apple` | 0.45 |
| 5 | `orange_19.png` | `orange` | 0.48 |

**Tallying the Votes:**
- Votes for `orange`: 4
- Votes for `apple`: 1
- Votes for `banana`: 0

**Decision:**
Because `orange` received 4 out of 5 votes, the majority vote wins! The model outputs `prediction = "orange"`.

## Step-by-Step Student Instructions

1. **Open a terminal** and launch Python: `python3`.
2. **Import the classifier**:
   ```python
   from sklearn.neighbors import KNeighborsClassifier
   import numpy as np
   ```
3. **Create a tiny toy dataset** with 4 points in 1D space:
   ```python
   X_train = [[1.0], [2.0], [10.0], [11.0]]
   y_train = ["apple", "apple", "banana", "banana"]
   ```
4. **Fit the KNN model with $k=3$**:
   ```python
   knn = KNeighborsClassifier(n_neighbors=3)
   knn.fit(X_train, y_train)
   ```
5. **Predict a new test point close to the apples**:
   ```python
   print(knn.predict([[1.5]]))  # Output: ['apple']
   ```
6. **Predict a new test point close to the bananas**:
   ```python
   print(knn.predict([[9.5]]))  # Output: ['banana']
   ```

## Expected Output or Observable Behaviour

When you run the toy script, Python outputs:
```text
['apple']
['banana']
```
This demonstrates how proximity in feature space dictates the resulting classification label.

## Practical Exercises

- **Exercise 3.1**: In The Snack Sorter, what is the value of $k$ passed to `KNeighborsClassifier`?
- **Exercise 3.2**: If a test sample has 5 nearest neighbors consisting of 2 apples, 2 bananas, and 1 orange, how would KNN break the tie? (Research scikit-learn's default tie-breaking behavior).
- **Exercise 3.3**: Why is $k=1$ generally more prone to errors and noisy outliers than $k=5$?
- **Exercise 3.4**: Why is KNN referred to as a "lazy" learner compared to linear regression?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Setting $k$ to an even number when there are two classes | Even values of $k$ (e.g., $k=2$ or $k=4$) can easily produce deadlocks and ties. | Use odd values of $k$ (e.g., $k=3, 5, 7$) to prevent voting ties. |
| Thinking KNN calculates an equation like $y = mx + b$ | KNN is non-parametric and does not calculate mathematical slope or intercept equations. | Understand that KNN relies strictly on geometric distance and voting. |
| Forgetting that distance depends on feature scales | If one feature has huge values, it completely dominates Euclidean distance calculations. | Always scale features before passing them to KNN. |

## Best Practices and Security Considerations

- **Choose $k$ Thoughtfully**: A very small $k$ ($k=1$) overfits to noise; an excessively large $k$ ($k=60$) smooths over real class distinctions and simply predicts the overall majority class.
- **Computational Scaling**: Because KNN compares every query point against all stored training points, prediction time scales with dataset size $\mathcal{O}(N)$. For millions of images, approximate nearest neighbors (ANN) or deep learning is preferred.
- **Deterministic Runs**: KNN itself is deterministic when distances are distinct; however, handling ties can depend on dataset order.

## Summary

The K-Nearest Neighbors (KNN) algorithm is an intuitive, instance-based supervised classification technique. When presented with an unseen photo, KNN measures the Euclidean distance between that photo's visual features and all training photos. It identifies the $k$ closest training examples (in our project, $k=5$) and assigns the majority vote label. KNN does not compute complex equations; it makes decisions by evaluating geometric proximity in feature space.

## Knowledge-check Questions

1. How does the K-Nearest Neighbors algorithm decide which label to assign to a new test image?
2. What does the parameter `n_neighbors=5` specify in `main.py`?
3. What mathematical formula does KNN use by default to determine how close two points are?
4. What happens during the `fit()` stage of a KNN model compared to algorithms like linear regression?
5. Why is choosing an odd number like $k=5$ often advantageous in classification tasks?

## References

- Scikit-learn KNN Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.KNeighborsClassifier.html
- Understanding Instance-Based Learning: https://scikit-learn.org/stable/modules/neighbors.html
- The Snack Sorter source code: `main.py` lines 43–49.
