# Lesson 02: What Are Features & Why These 5 Visual Features?

**Lesson ID:** lesson-02
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Define what a "feature" is in machine learning.
- Contrast raw pixel representations with hand-crafted feature engineering.
- Identify the 5 specific visual features used in The Snack Sorter: `mean_r`, `mean_g`, `mean_b`, `color_fraction`, and `aspect_ratio`.
- Explain how RGB color channels distinguish between red apples, yellow bananas, and orange oranges.
- Explain the role of geometric features (`color_fraction` and `aspect_ratio`) in characterizing object shape.

## Prerequisites

- Lesson 01: Introduction to Image Classification & The Snack Sorter Problem.
- Basic familiarity with RGB color mixing (Red, Green, Blue).

## Concept Explanation

### What Is a Feature?
In machine learning, an algorithm cannot directly "look" at an apple the way human eyes do. An algorithm requires numerical inputs. A **feature** is an individual measurable property or numerical characteristic extracted from the raw data.
- In tabular problems (like predicting house prices), features might be square footage, number of bedrooms, and year built.
- In computer vision, a feature represents a numerical summary of an image's visual content.

### Raw Pixels vs. Hand-Crafted Features
A standard digital image is composed of a grid of pixels. Even a small $64 \times 64$ color image consists of $64 \times 64 \times 3 = 12,288$ individual numbers (one red, one green, and one blue intensity value per pixel).
If we feed 12,288 raw numbers into a simple classifier with only 90 sample photos:
1. The model encounters the **Curse of Dimensionality**: too many variables and too few examples.
2. A tiny shift in the camera position or lighting drastically changes thousands of individual pixel numbers, confusing the classifier.

Instead, we use **feature extraction** (also called hand-crafted feature engineering). We distill thousands of raw pixels into **5 meaningful summary numbers** that remain stable across different camera angles and small shifts.

### The 5 Visual Features Explained

In `main.py`, line 31 defines the feature list:
```python
FEATURES = ["mean_r", "mean_g", "mean_b", "color_fraction", "aspect_ratio"]
```

Let's break down each feature:

1. **`mean_r` (Mean Red Intensity)**:
   - Measures the average brightness of the Red color channel across foreground pixels (values range from 0 to 255).
   - In our dataset, apples average $\approx 175.3$, bananas $\approx 222.0$, and oranges $\approx 236.4$.

2. **`mean_g` (Mean Green Intensity)**:
   - Measures the average brightness of the Green color channel.
   - In RGB digital color mixing, **Red + Green = Yellow**. Thus, yellow bananas have very high green intensity ($\approx 185.9$), orange fruit has moderate green ($\approx 123.6$), and red apples have very low green ($\approx 45.5$).
   - This makes `mean_g` an extraordinarily powerful discriminator!

3. **`mean_b` (Mean Blue Intensity)**:
   - Measures the average brightness of the Blue color channel.
   - For all three fruits, blue is relatively low ($\approx 27$ to $45$), but slight differences reflect background reflection and skin pigment.

4. **`color_fraction` (Foreground Pixel Coverage)**:
   - The ratio of non-background (fruit) pixels to the total number of pixels in the image canvas.
   - Values range from $0.0$ (empty) to $1.0$ (canvas completely filled).
   - In our dataset, fruits occupy between $20\%$ and $40\%$ ($0.20$ to $0.40$) of the image area.

5. **`aspect_ratio` (Width-to-Height Ratio)**:
   - Calculated as $\frac{\text{Bounding Box Width}}{\text{Bounding Box Height}}$.
   - A perfectly square or circular object has an aspect ratio of $1.0$.
   - Apples in our dataset have an aspect ratio averaging $\approx 0.83$ (slightly taller than wide).
   - Bananas average $\approx 0.98$, and oranges average $\approx 1.00$.

## Relevant Code (from main.py, lines 31-37)

```python
31: FEATURES = ["mean_r", "mean_g", "mean_b", "color_fraction", "aspect_ratio"]
32: 
33: 
34: def main() -> None:
35:     df = pd.read_csv(DATA / "snacks.csv")
36:     X = df[FEATURES]
37:     y = df["label"]
```

### Code Explanation
- **Line 31**: A constant list `FEATURES` specifies the exact 5 column names to be extracted from the dataset.
- **Line 35**: `pd.read_csv()` loads `snacks.csv` into a pandas DataFrame `df`.
- **Line 36**: `X = df[FEATURES]` creates a 2-dimensional feature matrix `X` containing only these 5 columns across all 90 rows (shape: `(90, 5)`).
- **Line 37**: `y = df["label"]` extracts the 1-dimensional target Series containing the true fruit class names (`apple`, `banana`, `orange`).

## Worked Example

**Comparing the Average Profiles of the Three Fruits:**

| Feature | Apple Mean | Banana Mean | Orange Mean | Why It Differentiates |
|---|---|---|---|---|
| `mean_r` | 175.34 | 221.96 | 236.40 | Apples have noticeably lower red intensity than oranges. |
| `mean_g` | **45.46** | **185.90** | **123.58** | **Massive separation**: Low (apple) vs High (banana) vs Medium (orange). |
| `mean_b` | 44.86 | 40.63 | 27.68 | Oranges have the lowest blue intensity. |
| `color_fraction` | 0.31 | 0.22 | 0.34 | Bananas are slender, filling less canvas area ($22\%$) than oranges ($34\%$). |
| `aspect_ratio` | 0.83 | 0.98 | 1.00 | Apples are taller/narrower ($0.83$) than circular oranges ($1.00$). |

Notice how `mean_g` alone creates three distinct non-overlapping bands:
- Apple: $42 - 49$
- Orange: $120 - 128$
- Banana: $184 - 188$

Even without the other features, `mean_g` provides tremendous predictive power!

## Step-by-Step Student Instructions

1. **Open your Python interactive shell** or create a scratch script.
2. **Import pandas and load `data/snacks.csv`**:
   ```python
   import pandas as pd
   df = pd.read_csv("data/snacks.csv")
   ```
3. **Inspect the features list**:
   ```python
   features = ["mean_r", "mean_g", "mean_b", "color_fraction", "aspect_ratio"]
   print(df[features].head())
   ```
4. **Compute class-level averages**:
   ```python
   print(df.groupby("label")[features].mean().round(2))
   ```
5. **Observe the green channel (`mean_g`)**: Notice that bananas have more than triple the green value of apples.

## Expected Output or Observable Behaviour

Running the group statistics in Python outputs:

```text
        mean_r  mean_g  mean_b  color_fraction  aspect_ratio
label                                                       
apple   175.34   45.46   44.86            0.31          0.83
banana  221.96  185.90   40.63            0.22          0.98
orange  236.40  123.58   27.68            0.34          1.00
```

This clearly confirms why these 5 features make it straightforward for a classifier to differentiate the three classes.

## Practical Exercises

- **Exercise 2.1**: Why is the green color channel (`mean_g`) so high for yellow bananas? (Hint: Think about RGB additive color mixing).
- **Exercise 2.2**: If a new fruit photo has `aspect_ratio = 1.01`, `mean_r = 235.0`, and `mean_g = 124.0`, which fruit is it most likely to be?
- **Exercise 2.3**: Explain why using 5 summary features is advantageous over feeding thousands of raw pixel numbers into a model trained on only 90 photos.
- **Exercise 2.4**: What is the difference between `df[FEATURES]` and `df["label"]` in terms of data structure and dimensionality?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Thinking bananas only have yellow color channels | Digital displays use RGB (Red, Green, Blue); there is no separate "Yellow" channel. Yellow is made of Red + Green. | Recognize that yellow fruits exhibit high values in both Red and Green channels. |
| Passing `FEATURES` as a single string: `df["FEATURES"]` | `FEATURES` is a Python variable holding a list of strings. Quotes make pandas look for a literal column named `"FEATURES"`. | Use `df[FEATURES]` (without quotes around the variable name). |
| Assuming `color_fraction` is measured in pixels | Fractions are normalized ratios between $0.0$ and $1.0$. | Remember that `color_fraction` is the percentage of the image covered by the fruit. |

## Best Practices and Security Considerations

- **Domain Knowledge in Feature Engineering**: Choosing features aligned with natural object properties (like color and shape for fruit) makes models simpler and more reliable.
- **Dimensionality Control**: Keep the number of features significantly smaller than the number of training examples to avoid overfitting on small datasets.
- **Data Integrity**: Ensure numerical feature columns do not contain missing (`NaN`) or infinite (`inf`) values before modeling.

## Summary

In machine learning, a feature is an informative numerical measurement extracted from raw data. Rather than processing thousands of raw pixels, The Snack Sorter distills each fruit photo into 5 hand-crafted features: three color statistics (`mean_r`, `mean_g`, `mean_b`), one coverage metric (`color_fraction`), and one geometric metric (`aspect_ratio`). Because fruits possess distinct natural colors—especially in the green channel where apples are low, oranges are medium, and bananas are high—these 5 features cleanly separate the snack classes.

## Knowledge-check Questions

1. What are the 5 visual features defined in `main.py`?
2. In RGB color mixing, why do bananas have high values in both the red and green channels?
3. How is `aspect_ratio` calculated, and what does an aspect ratio close to 1.0 indicate?
4. What is `color_fraction`, and why is it smaller for bananas than for oranges in our dataset?
5. What problem might occur if we used 12,000 raw pixel values instead of these 5 features on a dataset of only 90 images?

## References

- Scikit-learn Feature Extraction: https://scikit-learn.org/stable/modules/feature_extraction.html
- Digital Color & RGB Color Model: https://en.wikipedia.org/wiki/RGB_color_model
- The Snack Sorter source code: `main.py` lines 31–37.
