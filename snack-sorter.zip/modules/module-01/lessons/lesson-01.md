# Lesson 01: Introduction to Image Classification & The Snack Sorter Problem

**Lesson ID:** lesson-01
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- State the computer vision problem that **The Snack Sorter** solves.
- Distinguish between classification (predicting discrete labels) and regression (predicting continuous numbers).
- Define multi-class classification and identify the 3 snack classes in this project (`apple`, `banana`, `orange`).
- Explain why supervised machine learning is suitable for sorting snack photos.
- Articulate the role of training data versus test data in evaluating computer vision models.

## Prerequisites

- Basic familiarity with Python syntax (variables, functions, imports).
- High-level understanding of what a dataset is (rows and columns).

## Concept Explanation

### The Problem: How Can a Machine Recognize Fruits?
Imagine an automated cafeteria checkout or a fruit packing facility. When a customer places a snack under a camera, how does the cash register know whether it is an apple, a banana, or an orange?

For humans, this task is instantaneous. Our visual cortex effortlessly combines color, shape, curvature, and texture. But to a computer, an image is merely a two-dimensional grid of numbers representing pixel intensities. The goal of **image classification** is to assign a discrete category label to an input image based on patterns discovered in those numerical pixels.

### Classification vs. Regression
In machine learning, supervised learning tasks fall broadly into two primary families:
1. **Regression**: The target variable is a continuous numerical quantity. For example, predicting the price of a house ($350,000), tomorrow's temperature (28.4°C), or how many cups of lemonade a stand will sell (44.6 cups).
2. **Classification**: The target variable is a discrete category or class label. For example, predicting whether an email is "spam" or "inbox", whether a medical test is "positive" or "negative", or which of 3 fruits is depicted in a photograph.

Because our target is a fruit name chosen from a fixed set of three choices—`apple`, `banana`, or `orange`—**The Snack Sorter** is a **multi-class classification** problem.

### Why Supervised Learning?
Supervised learning means we learn from **labeled examples**. We provide the computer with training examples where both the input image features ($X$) and the true categorical answers ($y$) are known. The algorithm analyzes the relationship between the visual clues and the fruit labels. Once trained, the model can predict the correct fruit label for completely new, unseen photos.

### The Snack Sorter Strategy
Modern deep learning models (like Convolutional Neural Networks) often require thousands of images and specialized graphics hardware (GPUs) to train. In contrast, **The Snack Sorter** uses an elegant classical machine learning approach:
- We start with 90 photos (30 apples, 30 bananas, 30 oranges).
- We extract 5 simple, hand-crafted numerical features from each photo (color averages, color coverage, and aspect ratio).
- We train a **K-Nearest Neighbors (KNN)** classifier to recognize each fruit by comparing these 5 numbers against known training examples.

This demonstrates that powerful AI solutions do not always require massive supercomputers; thoughtful feature engineering combined with classic algorithms can achieve 100% accuracy on structured problems.

## Relevant Code (from main.py, lines 1-9)

```python
1: """Project 01: The Snack Sorter (image classification with KNN).
2: 
3: Run:
4:     python main.py
5: 
6: The script loads 90 tiny snack photos, turns each photo into five simple
7: numbers (average colour, colour coverage, and shape), trains a K-Nearest
8: Neighbours classifier, and saves visual results in outputs/.
9: """
```

### Code Explanation
- **Line 1**: The module docstring introduces the project title and specifies the machine learning algorithm: K-Nearest Neighbours (KNN) applied to image classification.
- **Lines 3-4**: Specifies the command to execute the entire end-to-end pipeline (`python main.py`).
- **Lines 6-8**: Summarizes the entire architecture: loading 90 snack photos, extracting five numerical measurements (average colour, colour coverage, shape), fitting a KNN model, and persisting visual diagnostic results into the `outputs/` folder.

## Worked Example

**Scenario:** Suppose we feed the trained model a new photo of a fruit with the following 5 measurements:
- Average Red channel: $174.5$
- Average Green channel: $46.0$
- Average Blue channel: $44.8$
- Foreground color fraction: $0.32$
- Aspect ratio: $0.82$

**Analysis:**
- Look at the color channels: The Red channel is high ($174.5$), while Green ($46.0$) and Blue ($44.8$) are low. This indicates a predominantly deep red object.
- Look at the shape: The aspect ratio is $0.82$ (width is about 82% of height), representing a roughly round or slightly vertical fruit.
- Compare with our known snack profiles:
  - Bananas are bright yellow (high red AND high green $\approx 186$).
  - Oranges are vibrant orange (high red $\approx 236$, medium green $\approx 124$).
  - Apples are deep red (high red $\approx 175$, low green $\approx 45$).
- **Conclusion**: The measurements closely match an **apple**. The model will classify this sample as `"apple"`.

## Step-by-Step Student Instructions

1. **Locate the project folder**: Open your terminal and change into `beginner-projects-main/AI-ML Beginners/projects/01_snack_sorter`.
2. **Inspect `main.py`**: Open `main.py` in your code editor and read lines 1 through 9.
3. **Verify the classification task**: Identify the target labels by checking line 64: `sorted(df["label"].unique())`. Confirm there are three classes: `apple`, `banana`, and `orange`.
4. **Identify the inputs and outputs**:
   - What are the inputs ($X$)? The 5 visual features representing the photos.
   - What is the output ($y$)? The fruit category name.
5. **Run the script**: In your terminal, run `python3 main.py` and observe the printed terminal banner:
   ```text
   THE SNACK SORTER
   Training photos: 67
   Test photos:     23
   Accuracy:        100.0%
   ```

## Expected Output or Observable Behaviour

Executing `python3 main.py` displays the project banner and demonstrates that a model was successfully trained on 67 photos and tested on 23 photos:

```text
============================================================
THE SNACK SORTER
============================================================
Training photos: 67
Test photos:     23
Accuracy:        100.0%
```

This confirms the classifier ran end-to-end and categorized all 23 test photos without error.

## Practical Exercises

- **Exercise 1.1**: Is predicting whether an image contains an apple, banana, or orange a regression or classification problem? Why?
- **Exercise 1.2**: If our model was asked to predict the weight of an apple in grams (e.g., 182.4 grams), would that be classification or regression?
- **Exercise 1.3**: How many total snack images are used in this project, and how many belong to each fruit category?
- **Exercise 1.4**: Why is having labeled data essential for supervised learning?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Calling this project a "regression" problem | Regression predicts continuous real numbers; here the model outputs categorical text labels (`apple`, `banana`, `orange`). | Identify it as multi-class classification because the output is one of three discrete categories. |
| Assuming the model takes raw pixels directly into KNN | Raw pixel grids have thousands of values that are noisy and high-dimensional. | The project uses 5 hand-crafted summary features extracted from the images. |
| Confusing binary classification with multi-class classification | Binary classification handles only 2 classes (e.g., apple vs not-apple). | Recognize that having 3 fruit classes makes this a multi-class task. |

## Best Practices and Security Considerations

- **Problem Framing**: Always determine whether your target variable is continuous (regression) or categorical (classification) before choosing algorithms and loss functions.
- **Interpretability First**: For small, well-bounded datasets, simple interpretable models often outperform complex black-box architectures.
- **Local Safe Execution**: The code reads strictly local image files and CSV data without connecting to external networks or requiring remote API credentials.

## Summary

The Snack Sorter addresses an image classification problem: sorting photos into three fruit classes (`apple`, `banana`, `orange`). Because the target is categorical rather than continuous, this is a supervised multi-class classification task. Rather than training heavy deep learning networks on raw pixels, the system extracts 5 concise visual features from 90 labeled snack photos and trains a K-Nearest Neighbors classifier to achieve robust, interpretable predictions.

## Knowledge-check Questions

1. What are the three fruit classes that The Snack Sorter classifies?
2. Why is sorting snack photos into fruit categories considered a classification task rather than regression?
3. What is the difference between supervised learning and unsupervised learning?
4. How many total photos are included in the dataset, and how are they divided between training and testing?
5. Why are hand-crafted visual features used instead of feeding raw image pixels directly into the classifier?

## References

- Scikit-learn Supervised Learning Overview: https://scikit-learn.org/stable/supervised_learning.html
- Machine Learning Classification Guide: https://scikit-learn.org/stable/modules/neighbors.html#nearest-neighbors-classification
- The Snack Sorter source code: `main.py` lines 1–9.
