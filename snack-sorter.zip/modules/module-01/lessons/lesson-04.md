# Lesson 04: The Machine Learning Pipeline Concept

**Lesson ID:** lesson-04
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Define what a machine learning pipeline is and why it is used in professional workflows.
- Identify the components of the pipeline in `main.py` (`StandardScaler` and `KNeighborsClassifier`).
- Explain the concept of **data leakage** and how pipelines prevent it.
- Understand how a pipeline coordinates the `fit()` and `predict()` methods across multiple transformers and estimators.
- Describe the architectural advantages of treating data preprocessing and modeling as a unified object.

## Prerequisites

- Lesson 01: Introduction to Image Classification & The Snack Sorter Problem.
- Lesson 02: What Are Features & Why These 5 Visual Features?
- Lesson 03: The K-Nearest Neighbors (KNN) Algorithm: Intuition & Voting.

## Concept Explanation

### The Problem: Multi-Step Machine Learning
In real-world machine learning, building a model is rarely a single function call. Typically, raw data must undergo several stages:
1. Cleaning and imputation (handling missing values).
2. Feature scaling (normalizing ranges).
3. Dimensionality reduction or feature selection.
4. Model training and inference.

Without an automated structure, beginners often write code that scales data separately:
```python
# Bad practice: manual scaling without a pipeline
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)
knn = KNeighborsClassifier()
knn.fit(X_train_scaled, y_train)
predictions = knn.predict(X_test_scaled)
```
While this works for simple scripts, it introduces severe risks:
- You must manually remember to transform every new test sample or production input before predicting.
- If you accidentally call `scaler.fit_transform(X_test)` on the test set, you introduce **data leakage** (allowing test information to contaminate the scaler's statistics).
- Code becomes brittle, messy, and prone to copy-paste bugs.

### The Solution: Scikit-Learn `Pipeline`
Scikit-learn provides an elegant, industrial-grade abstraction called **`Pipeline`**. A pipeline bundles a sequence of data transformers together with a final estimator into a single, unified Python object.

In **The Snack Sorter**, line 43 constructs our pipeline:
```python
model = Pipeline(
    [
        ("scale", StandardScaler()),
        ("knn", KNeighborsClassifier(n_neighbors=5)),
    ]
)
```

### How the Pipeline Works: An Assembly Line
Think of a pipeline as an automated factory conveyor belt:
- **During `model.fit(X_train, y_train)`**:
  1. The raw `X_train` data enters Step 1 (`"scale"`). `StandardScaler` calculates the mean ($\mu$) and standard deviation ($\sigma$) for each of the 5 features from `X_train`, and transforms `X_train` into standard z-scores.
  2. The scaled training data automatically flows into Step 2 (`"knn"`). `KNeighborsClassifier` indexes the scaled points in memory.
- **During `model.predict(X_test)`**:
  1. Raw `X_test` data is passed directly to `model.predict()`.
  2. The pipeline automatically runs `X_test` through Step 1 (`"scale"`), applying the exact $\mu$ and $\sigma$ learned during training!
  3. The scaled test features are seamlessly handed to Step 2 (`"knn"`) to compute nearest neighbors and return predictions.

### Key Architectural Benefits
1. **Prevents Data Leakage**: Test data is never used to calculate scaling parameters ($\mu, \sigma$).
2. **Unified Interface**: The entire pipeline behaves just like a regular estimator; you only ever interact with `model.fit()` and `model.predict()`.
3. **Reproducibility & Deployment**: When shipping the model to production, you export a single pipeline artifact. The production server doesn't need custom preprocessing code—it simply calls `model.predict(new_photo_features)`.

## Relevant Code (from main.py, lines 23-24, 43-50)

```python
23: from sklearn.pipeline import Pipeline
24: from sklearn.preprocessing import StandardScaler
...
43:     model = Pipeline(
44:         [
45:             ("scale", StandardScaler()),
46:             ("knn", KNeighborsClassifier(n_neighbors=5)),
47:         ]
48:     )
49:     model.fit(X_train, y_train)
50:     predictions = model.predict(X_test)
```

### Code Explanation
- **Lines 23-24**: Imports `Pipeline` from `sklearn.pipeline` and `StandardScaler` from `sklearn.preprocessing`.
- **Lines 43-48**: Creates the `Pipeline` named `model`. The list contains tuples of `(name, transform_object)`. Here:
  - Step 1 is `"scale"`: an instance of `StandardScaler`.
  - Step 2 is `"knn"`: an instance of `KNeighborsClassifier(n_neighbors=5)`.
- **Line 49**: Calling `model.fit(X_train, y_train)` fits the scaler and then fits the classifier sequentially on the training split.
- **Line 50**: Calling `model.predict(X_test)` transforms `X_test` using the fitted scaler and immediately returns predicted fruit classes.

## Worked Example

**Tracing What Happens Behind the Scenes:**

Suppose we have two features for an apple:
- Raw training feature: `mean_r = 175.0`
- Scaler learns: $\mu = 211.23$, $\sigma = 26.25$
- Standardized value:
  $$z = \frac{175.0 - 211.23}{26.25} = \frac{-36.23}{26.25} \approx -1.38$$
- When a test image with `mean_r = 172.0` arrives, the pipeline computes:
  $$z_{\text{test}} = \frac{172.0 - 211.23}{26.25} \approx -1.49$$
Notice that the pipeline uses the **training mean (211.23)**, NOT the test sample's mean! This guarantees zero leakage.

## Step-by-Step Student Instructions

1. **Open a Python terminal**.
2. **Import the pipeline and components**:
   ```python
   from sklearn.pipeline import Pipeline
   from sklearn.preprocessing import StandardScaler
   from sklearn.neighbors import KNeighborsClassifier
   import numpy as np
   ```
3. **Build the Snack Sorter pipeline**:
   ```python
   pipe = Pipeline([
       ("scaler", StandardScaler()),
       ("classifier", KNeighborsClassifier(n_neighbors=5))
   ])
   ```
4. **Inspect the steps in the pipeline**:
   ```python
   print(pipe.named_steps.keys())
   # Output: dict_keys(['scaler', 'classifier'])
   ```
5. **Verify that the pipeline handles fitting and prediction as one unit**.

## Expected Output or Observable Behaviour

Inspecting the pipeline in Python confirms the two sequential stages:
```text
dict_keys(['scaler', 'classifier'])
```
And running `main.py` executes this pipeline seamlessly, calculating test predictions on line 50 without needing manual scaling steps.

## Practical Exercises

- **Exercise 4.1**: What are the names of the two steps in the `main.py` pipeline?
- **Exercise 4.2**: What would happen if you scaled the test set using `scaler.fit_transform(X_test)` instead of using a pipeline?
- **Exercise 4.3**: Can a scikit-learn pipeline have more than two steps? Give an example of a third step that could be added.
- **Exercise 4.4**: In a pipeline, can the final step be a transformer, or must it be an estimator/classifier?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Putting an estimator before a transformer in a pipeline | Transformers must implement `transform()` or `fit_transform()`. Estimators like KNN only implement `predict()`. | Intermediate steps must be transformers; only the final step can be an estimator. |
| Fitting the scaler on the entire dataset `X` before splitting | Leaks statistical distribution information from the test set into the model. | Always split first, then fit the pipeline strictly on `X_train`. |
| Passing tuples without string names to `Pipeline` | `Pipeline` requires a list of `(name_str, estimator_object)` tuples. | Use `("scale", StandardScaler())` format. |

## Best Practices and Security Considerations

- **Always Encapsulate with Pipelines**: Whenever preprocessing is required (imputation, scaling, encoding), wrap it in a pipeline to prevent data leakage and deployment errors.
- **Save the Full Pipeline**: When persisting trained models using `joblib` or `pickle`, serialize the entire pipeline object rather than individual steps.
- **Safe Pipeline Execution**: Ensure all steps originate from verified libraries like `scikit-learn` to avoid deserialization vulnerabilities.

## Summary

A machine learning pipeline bundles data preprocessing transformers and final estimators into a single, cohesive workflow. In The Snack Sorter, the pipeline chains `StandardScaler` with `KNeighborsClassifier(n_neighbors=5)`. This structure guarantees that features are scaled accurately using training statistics, prevents subtle data leakage from contaminating test evaluation, and simplifies both training and test prediction into clean `fit()` and `predict()` calls.

## Knowledge-check Questions

1. What is the primary purpose of a scikit-learn `Pipeline`?
2. What are the two specific steps included in the pipeline in `main.py`?
3. What is "data leakage", and how does using a pipeline prevent it during feature scaling?
4. What happens when `model.predict(X_test)` is called on a fitted pipeline?
5. Why must all intermediate steps in a pipeline be transformers rather than classifiers?

## References

- Scikit-learn Pipeline Guide: https://scikit-learn.org/stable/modules/compose.html#pipeline
- Scikit-learn StandardScaler Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.StandardScaler.html
- The Snack Sorter source code: `main.py` lines 43–50.
