# Lesson 04: Stratified Splitting with `train_test_split`

**Lesson ID:** lesson-04
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain why datasets must be split into independent training and test sets.
- Define **stratified splitting** and explain how `stratify=y` preserves class proportions.
- Understand the role of `test_size=0.25` in producing 67 training and 23 test samples.
- Explain why `random_state=42` is used for reproducible partitioning.
- Explain why `df.index` is passed into `train_test_split` to track sample indices for image visualization.

## Prerequisites

- Module 02, Lesson 03: Label Distribution and Class Balance.
- Basic understanding of random sampling and reproducibility.

## Concept Explanation

### Why Split Data?
If you evaluate a machine learning model on the same data it was trained on, you are testing **memorization**, not **learning**. An overfitted model might score 100% on training images simply because it remembers them, but fail completely when shown a photo from a different camera.
To obtain an honest, objective measure of performance, we partition our data into two distinct subsets:
1. **Training Set ($75\%$)**: Used by the algorithm to learn visual patterns.
2. **Testing Set ($25\%$)**: Kept hidden until evaluation. It acts as an unseen "final exam".

### The Danger of Random Splitting in Small Datasets
In a small dataset like ours (90 images total, with 30 per fruit):
- A standard unstratified random split might accidentally draw 14 apples, 5 bananas, and 4 oranges for the test set.
- Such a skewed test set would unfairly penalize bananas and oranges while over-representing apples.
- Worse, some classes might end up with too few training examples to learn robust boundaries!

### The Solution: Stratification (`stratify=y`)
**Stratification** ensures that the training set and testing set retain the exact same percentage breakdown of each class as the original dataset.
- In `main.py`, line 40 passes `stratify=y` to `train_test_split`.
- Total photos = 90.
- With `test_size=0.25`, $90 \times 0.25 = 22.5$ photos $\rightarrow$ rounded to **23 test photos**.
- Remaining photos: $90 - 23 = \mathbf{67\text{ training photos}}$.
- Thanks to stratification, the 23 test photos are divided as evenly as possible:
  - Apples: 7 test photos (23 in training).
  - Bananas: 8 test photos (22 in training).
  - Oranges: 8 test photos (22 in training).
  - Total test: $7 + 8 + 8 = 23$. Total train: $23 + 22 + 22 = 67$.

### Tracking Original Indices (`df.index`)
Notice line 39 in `main.py`:
```python
X_train, X_test, y_train, y_test, idx_train, idx_test = train_test_split(
    X, y, df.index, test_size=0.25, random_state=42, stratify=y
)
```
Why does `train_test_split` accept `df.index` as a third argument?
Because later in the script (lines 77–81), we want to plot photos of test predictions! The feature matrix `X` only contains numbers, not image files. By passing `df.index`, we obtain `idx_test`, which stores the original DataFrame row numbers for the test set. We can then slice `df.loc[idx_test]` to look up the exact `image_path` for each test photo!

### Why `random_state=42`?
A pseudo-random number generator shuffles the rows before splitting. Setting `random_state=42` fixes the random seed so that every time you, a teacher, or a grading system runs `main.py`, the exact same photos end up in the training and testing sets.

## Relevant Code (from main.py, lines 39-41, 77)

```python
39:     X_train, X_test, y_train, y_test, idx_train, idx_test = train_test_split(
40:         X, y, df.index, test_size=0.25, random_state=42, stratify=y
41:     )
...
77:     test_df = df.loc[idx_test].head(9)
```

### Code Explanation
- **Line 39**: Unpacks the 6 returned items: feature splits (`X_train, X_test`), label splits (`y_train, y_test`), and index splits (`idx_train, idx_test`).
- **Line 40**: Configures the split:
  - `test_size=0.25`: Allocates 25% of photos to the test set.
  - `random_state=42`: Seeds the shuffle for exact reproducibility.
  - `stratify=y`: Preserves class proportions in train and test splits.
- **Line 77**: Uses `idx_test` with `df.loc` to retrieve the original image metadata for the first 9 test samples.

## Worked Example

**Verifying the Stratified Split in Python:**

Let's run the exact split from `main.py` and inspect the class distributions:

```python
import pandas as pd
from sklearn.model_selection import train_test_split

df = pd.read_csv("data/snacks.csv")
X = df[["mean_r", "mean_g", "mean_b", "color_fraction", "aspect_ratio"]]
y = df["label"]

X_train, X_test, y_train, y_test, idx_train, idx_test = train_test_split(
    X, y, df.index, test_size=0.25, random_state=42, stratify=y
)

print(f"Total dataset: {len(df)}")
print(f"Train size:    {len(X_train)} photos")
print(f"Test size:     {len(X_test)} photos")
print("\nTraining class breakdown:")
print(y_train.value_counts())
print("\nTest class breakdown:")
print(y_test.value_counts())
```

**Output:**
```text
Total dataset: 90
Train size:    67 photos
Test size:     23 photos

Training class breakdown:
label
apple     23
banana    22
orange    22
Name: count, dtype: int64

Test class breakdown:
label
banana    8
orange    8
apple     7
Name: count, dtype: int64
```

**Interpretation:**
- Each class has approximately $22$ or $23$ training images and $7$ or $8$ test images.
- The balance is preserved almost perfectly despite 90 not being divisible by 4.

## Step-by-Step Student Instructions

1. **Open your terminal** and start Python.
2. **Import `train_test_split`**:
   ```python
   from sklearn.model_selection import train_test_split
   import pandas as pd
   ```
3. **Load the data and set up $X$ and $y$**:
   ```python
   df = pd.read_csv("data/snacks.csv")
   X = df[["mean_r", "mean_g", "mean_b", "color_fraction", "aspect_ratio"]]
   y = df["label"]
   ```
4. **Execute the 6-variable train-test split**:
   ```python
   X_train, X_test, y_train, y_test, idx_train, idx_test = train_test_split(
       X, y, df.index, test_size=0.25, random_state=42, stratify=y
   )
   ```
5. **Inspect the lengths and shapes**:
   ```python
   print("X_train shape:", X_train.shape)
   print("X_test shape:", X_test.shape)
   print("idx_test length:", len(idx_test))
   ```
6. **Check index lookup**:
   ```python
   print(df.loc[idx_test].head(3)[["image_path", "label"]])
   ```

## Expected Output or Observable Behaviour

The script confirms:
```text
X_train shape: (67, 5)
X_test shape: (23, 5)
idx_test length: 23
```
And slicing with `df.loc[idx_test]` successfully retrieves the filenames corresponding to those test samples.

## Practical Exercises

- **Exercise 4.1**: What happens to `len(X_train)` and `len(X_test)` if `test_size=0.20` is used instead of `0.25`?
- **Exercise 4.2**: What would happen if `stratify=y` were omitted from `train_test_split`?
- **Exercise 4.3**: Why is setting `random_state=42` critical when collaborating on machine learning code or submitting student assignments?
- **Exercise 4.4**: Why does `main.py` pass `df.index` as a third positional argument to `train_test_split`?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Omitting `stratify=y` on small datasets | Random sampling can create severely imbalanced train/test splits by pure chance. | Always pass `stratify=y` for classification tasks. |
| Forgetting `idx_train, idx_test` when unpacking 3 inputs | Passing 3 inputs (`X, y, df.index`) returns 6 items. Unpacking only 4 variables raises `ValueError: too many values to unpack`. | Unpack all 6 variables: `X_train, X_test, y_train, y_test, idx_train, idx_test`. |
| Passing `stratify=X` instead of `stratify=y` | Stratification is based on categorical class labels, not multi-dimensional continuous features. | Use `stratify=y`. |

## Best Practices and Security Considerations

- **Reproducibility**: Always provide a fixed `random_state` in experimental code to ensure team members get identical results.
- **Stratified Partitioning**: Always stratify classification splits unless testing temporal or grouped structures (e.g., time series or patient cohorts).
- **Index Preservation**: When working with external artifacts (such as images, audio, or sensor logs), retain original dataframe indices to easily join predictions back to raw media.

## Summary

Stratified train/test splitting partitions a dataset while strictly preserving the percentage representation of each class across both training and testing subsets. In The Snack Sorter, `train_test_split` partitions the 90 samples into 67 training photos and 23 testing photos using `test_size=0.25`, `random_state=42`, and `stratify=y`. By passing `df.index` into the split, the script retains index pointers to map numerical test predictions back to source image files for visual inspection.

## Knowledge-check Questions

1. Why do machine learning practitioners split datasets into separate training and test sets?
2. What does the parameter `stratify=y` ensure during a train/test split?
3. How many photos are in the training set and test set in The Snack Sorter?
4. Why does `main.py` pass `df.index` to `train_test_split` in addition to `X` and `y`?
5. What is the role of `random_state=42` in data splitting?

## References

- Scikit-learn train_test_split Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html
- Scikit-learn Guide on Cross-Validation and Data Splitting: https://scikit-learn.org/stable/modules/cross_validation.html#stratification
- The Snack Sorter source code: `main.py` lines 39–41.
