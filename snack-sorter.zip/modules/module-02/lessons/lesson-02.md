# Lesson 02: Inspecting Image Paths and Visual Feature Columns

**Lesson ID:** lesson-02
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain how the `image_path` column links tabular metadata in `snacks.csv` to raster image files on disk.
- Use `matplotlib.image.imread` to load and inspect raw PNG image arrays.
- Distinguish the metadata columns (`image_path`, `label`) from the predictive feature matrix ($X$).
- Inspect the statistical distributions of the 5 visual features (`mean_r`, `mean_g`, `mean_b`, `color_fraction`, `aspect_ratio`).
- Understand why feature selection isolates the 5 numerical columns before model training.

## Prerequisites

- Module 02, Lesson 01: Reading `snacks.csv` & Navigating Project File Paths.
- Basic understanding of 2D grids and image pixels.

## Concept Explanation

### Bridging Tabular Data and Image Files
In many production computer vision pipelines, image files are stored on disk (or in cloud object storage like Amazon S3 or Google Cloud Storage), while a relational database or CSV metadata file records their filenames, annotations, and extracted attributes.

In **The Snack Sorter**, this design is reflected cleanly:
- `snacks.csv` contains an `image_path` column with relative strings like `"images/apple_00.png"`.
- When joined with `DATA`, the full path becomes:
  `DATA / sample["image_path"]` $\rightarrow$ `.../01_snack_sorter/data/images/apple_00.png`.

This allows the project to combine lightweight tabular machine learning with rich image visualization.

### Loading Images with `matplotlib.image` (`mpimg`)
Line 16 in `main.py` imports matplotlib's image processing utility:
```python
import matplotlib.image as mpimg
```
The function `mpimg.imread()` reads a PNG file from disk and decodes it into a NumPy array with pixel intensities. For example, in lines 68 and 81:
```python
ax.imshow(mpimg.imread(DATA / sample["image_path"]))
```
`ax.imshow()` renders the numerical pixel array as a color photo inside a matplotlib subplot!

### Separating Features ($X$) from Metadata and Target ($y$)
Not every column in `snacks.csv` should be handed to the machine learning model:
- `image_path`: A string path. Handing file paths to a math model makes no sense.
- `label`: The true fruit name. Handing the true label to $X$ would be cheating!
- `FEATURES`: The 5 continuous numerical measurements that describe visual appearance.

Lines 36–37 perform this critical separation:
```python
X = df[FEATURES]
y = df["label"]
```
Here, `X` is a 2D pandas DataFrame of shape `(90, 5)` containing only numeric columns, while `y` is a 1D pandas Series of shape `(90,)` containing the fruit categories.

### Statistical Overview of the 5 Features
Examining the dataset's summary statistics provides immediate insight into feature behaviors:

```text
       mean_r  mean_g  mean_b  color_fraction  aspect_ratio
count   90.00   90.00   90.00           90.00         90.00
mean   211.23  118.31   37.72            0.29          0.93
std     26.25   57.79    7.36            0.07          0.09
min    171.90   42.91   26.76            0.20          0.79
max    237.02  187.80   45.50            0.40          1.12
```

Notice the huge difference in scale:
- `mean_r` and `mean_g` have averages exceeding $100$ and $200$.
- `color_fraction` and `aspect_ratio` are decimals below $1.2$.
This scale disparity is a vital clue that will motivate feature scaling in Module 03.

## Relevant Code (from main.py, lines 16, 31, 36-37, 68)

```python
16: import matplotlib.image as mpimg
...
31: FEATURES = ["mean_r", "mean_g", "mean_b", "color_fraction", "aspect_ratio"]
...
36:     X = df[FEATURES]
37:     y = df["label"]
...
68:             ax.imshow(mpimg.imread(DATA / sample["image_path"]))
```

### Code Explanation
- **Line 16**: Imports `matplotlib.image as mpimg` to read raster image files.
- **Line 31**: Declares the subset of column names used as input features.
- **Line 36**: Slices the DataFrame `df` using the `FEATURES` list to construct feature matrix `X`.
- **Line 37**: Isolates the ground-truth target column `label` into `y`.
- **Line 68**: Joins `DATA` with the `image_path` string from the DataFrame and decodes the image with `mpimg.imread()`.

## Worked Example

**Inspecting a Specific Row and Loading its Companion Image:**

Let's inspect row index 0 in `snacks.csv`:
```python
from pathlib import Path
import pandas as pd
import matplotlib.image as mpimg

BASE = Path(".").resolve()
df = pd.read_csv(BASE / "data" / "snacks.csv")

row_0 = df.iloc[0]
print("Row 0 metadata and features:")
print(row_0)

# Check image file on disk
img_path = BASE / "data" / row_0["image_path"]
img = mpimg.imread(img_path)
print(f"Image array shape: {img.shape}")
print(f"Pixel value range: min={img.min():.2f}, max={img.max():.2f}")
```

**Output:**
```text
Row 0 metadata and features:
image_path        images/apple_00.png
label                           apple
mean_r                         178.57
mean_g                           43.5
mean_b                          44.97
color_fraction                 0.3691
aspect_ratio                     0.84
Name: 0, dtype: object

Image array shape: (64, 64, 4)
Pixel value range: min=0.00, max=1.00
```
**Interpretation:**
- The image is a $64 \times 64$ RGBA PNG image (4 channels: Red, Green, Blue, Alpha).
- The summarized features in the CSV capture the foreground statistics directly: `mean_r = 178.57`, `mean_g = 43.5`, `aspect_ratio = 0.84`.

## Step-by-Step Student Instructions

1. **Start an interactive Python session** in your terminal.
2. **Load the dataset**:
   ```python
   from pathlib import Path
   import pandas as pd
   BASE = Path(".").resolve()
   df = pd.read_csv(BASE / "data" / "snacks.csv")
   ```
3. **Verify `X` and `y` shapes**:
   ```python
   features = ["mean_r", "mean_g", "mean_b", "color_fraction", "aspect_ratio"]
   X = df[features]
   y = df["label"]
   print("X shape:", X.shape)
   print("y shape:", y.shape)
   ```
4. **Inspect min and max of each feature**:
   ```python
   print(X.agg(["min", "max"]))
   ```
5. **Check that an image exists on disk**:
   ```python
   import matplotlib.image as mpimg
   first_image = mpimg.imread(BASE / "data" / df.iloc[0]["image_path"])
   print("First image loaded successfully with shape:", first_image.shape)
   ```

## Expected Output or Observable Behaviour

The terminal confirms the dimensionalities and successful image decoding:
```text
X shape: (90, 5)
y shape: (90,)
First image loaded successfully with shape: (64, 64, 4)
```

This confirms that the tabular DataFrame and the filesystem images align perfectly.

## Practical Exercises

- **Exercise 2.1**: What would happen if `image_path` were included inside the `FEATURES` list passed to `X`?
- **Exercise 2.2**: Use `df.loc[df["label"] == "banana", "mean_g"].mean()` to compute the average green value for bananas.
- **Exercise 2.3**: What is the minimum and maximum `color_fraction` across all 90 images?
- **Exercise 2.4**: What is the shape and data type of `y`? Why is `y` a 1D Series rather than a 2D DataFrame?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Including `image_path` in `X` | `image_path` is a string filename; numeric models like KNN and StandardScaler will throw a `TypeError: could not convert string to float`. | Only include numerical feature columns in `FEATURES`. |
| Including `label` in `X` | Including the target label in features causes 100% artificial accuracy because the model simply reads the answer. | Keep `X = df[FEATURES]` and `y = df["label"]` strictly separated. |
| Forgetting `DATA /` when loading images | `sample["image_path"]` is relative to `data/` (`images/apple_00.png`). Without `DATA /`, Python looks in the current working directory. | Always use `DATA / sample["image_path"]`. |

## Best Practices and Security Considerations

- **Strict Separation of Concerns**: Keep metadata (IDs, image paths, timestamps) separated from modeling features ($X$) and ground truth ($y$).
- **Verify File Existence**: Before batch processing images, ensure file paths exist using `.exists()` to prevent unexpected runtime crashes.
- **Memory Efficiency**: Don't load all 90 image pixel matrices into memory simultaneously if you only need them for plotting sample grids.

## Summary

The `snacks.csv` file acts as a structured index, pairing relative image filenames (`image_path`) and ground truth classes (`label`) with 5 hand-crafted visual features. In `main.py`, features are extracted into a clean 2-dimensional matrix `X = df[FEATURES]` of shape `(90, 5)`, while the target is isolated into a 1-dimensional Series `y = df["label"]`. Using `matplotlib.image.imread`, individual image files can be loaded dynamically for inspection and visualization.

## Knowledge-check Questions

1. How does `main.py` link a row in `snacks.csv` to an image file on disk?
2. What are the dimensions and shapes of `X` and `y` after executing lines 36–37 of `main.py`?
3. What error would occur if `df[["image_path", "mean_r"]]` were passed to `StandardScaler`?
4. What matplotlib function is used to decode PNG files into NumPy pixel arrays?
5. Why are `mean_r` values in the hundreds while `aspect_ratio` values are around 1.0?

## References

- Matplotlib Image Tutorial: https://matplotlib.org/stable/tutorials/introductory/images.html
- Pandas Indexing and Selecting Data: https://pandas.pydata.org/docs/user_guide/indexing.html
- The Snack Sorter source code: `main.py` lines 31–37 and line 68.
