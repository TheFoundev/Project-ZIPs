# Lesson 03: Label Distribution and Class Balance

**Lesson ID:** lesson-03
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Define class balance and explain what a balanced versus imbalanced dataset is.
- Use pandas `value_counts()` and `unique()` to inspect label distributions in `snacks.csv`.
- Confirm that the Snack Sorter dataset is perfectly balanced with exactly 30 samples per class.
- Explain why balanced datasets simplify machine learning evaluation metrics like accuracy.
- Describe the pitfalls and misleading behaviors that occur when evaluating models on imbalanced datasets.

## Prerequisites

- Module 02, Lesson 01: Reading `snacks.csv` & Navigating Project File Paths.
- Basic understanding of percentages and fractions.

## Concept Explanation

### What Is Class Balance?
In classification problems, **class distribution** refers to the number of instances belonging to each target category in the dataset.
- **Balanced Dataset**: Each class has an approximately equal number of observations. For example, in a 90-sample dataset with 3 classes, having 30 apples, 30 bananas, and 30 oranges represents **perfect balance** (each class constitutes exactly $33.3\%$ of the data).
- **Imbalanced Dataset**: One or more classes heavily dominate while others are rare. For instance, in fraud detection, $99.8\%$ of credit card transactions may be legitimate, while only $0.2\%$ are fraudulent. In medical imaging, $98\%$ of scans might be healthy tissue, while $2\%$ contain malignant tumors.

### Why Does Class Balance Matter?
Class balance drastically affects both model training and evaluation:

1. **The "Accuracy Paradox" on Imbalanced Data**:
   - Imagine a dataset of 100 images: 95 apples and 5 bananas.
   - A lazy, "dumb" classifier that predicts "apple" for *every single image* would achieve $95\%$ accuracy!
   - On the surface, $95\%$ sounds wonderful. But the model is completely useless because it has never learned to detect a banana.
2. **Simplified Evaluation on Balanced Data**:
   - In **The Snack Sorter**, our 90 images are split evenly:
     - Apple: 30 photos ($33.3\%$)
     - Banana: 30 photos ($33.3\%$)
     - Orange: 30 photos ($33.3\%$)
   - A random guess or naive single-class predictor would only achieve $33.3\%$ accuracy.
   - Because our dataset is balanced, standard overall **accuracy** is an honest, meaningful benchmark of model competence.

### Inspecting Class Distribution with pandas
Pandas provides two essential methods for checking labels:
1. `df["label"].unique()`: Returns an array of distinct category names.
2. `df["label"].value_counts()`: Counts the exact number of occurrences for each category.

In `main.py`, lines 64 and 90 use `sorted(df["label"].unique())` to ensure that labels are processed in consistent alphabetical order: `["apple", "banana", "orange"]`.

## Relevant Code (from main.py, lines 64, 90)

```python
64:     for row, label in enumerate(sorted(df["label"].unique())):
...
90:     labels = sorted(df["label"].unique())
91:     cm = confusion_matrix(y_test, predictions, labels=labels)
```

### Code Explanation
- **Line 64**: Extracts the unique classes from `df["label"]` and sorts them alphabetically (`['apple', 'banana', 'orange']`). It iterates through them row-by-row to construct the training photo contact sheet.
- **Line 90**: Sorts the labels again to define the explicit order of rows and columns in the confusion matrix.
- **Line 91**: Computes the confusion matrix using `labels=labels` so that the matrix rows correspond predictably to `apple` (index 0), `banana` (index 1), and `orange` (index 2).

## Worked Example

**Analyzing Label Frequencies and Proportions:**

Let's compute the class counts and percentages in Python:
```python
from pathlib import Path
import pandas as pd

BASE = Path(".").resolve()
df = pd.read_csv(BASE / "data" / "snacks.csv")

# Compute raw counts
counts = df["label"].value_counts()

# Compute percentages
percentages = df["label"].value_counts(normalize=True) * 100

summary = pd.DataFrame({"Count": counts, "Percentage (%)": percentages})
print(summary)
```

**Output:**
```text
        Count  Percentage (%)
label                        
apple      30       33.333333
banana     30       33.333333
orange     30       33.333333
```

**Interpretation:**
- Every category contains exactly 30 images.
- Total samples: $30 + 30 + 30 = 90$.
- Each category represents exactly one-third ($1/3$) of the dataset. The dataset is pristine and balanced.

## Step-by-Step Student Instructions

1. **Open your terminal** and start Python.
2. **Load `snacks.csv`**:
   ```python
   import pandas as pd
   df = pd.read_csv("data/snacks.csv")
   ```
3. **Check the unique labels**:
   ```python
   labels = sorted(df["label"].unique())
   print("Unique labels:", labels)
   ```
4. **Display class counts**:
   ```python
   print(df["label"].value_counts())
   ```
5. **Check normalized proportions**:
   ```python
   print(df["label"].value_counts(normalize=True))
   ```
6. Verify that each fruit class yields `0.333333` (33.33%).

## Expected Output or Observable Behaviour

Executing these commands in Python yields:
```text
Unique labels: ['apple', 'banana', 'orange']
label
apple     30
banana    30
orange    30
Name: count, dtype: int64
```
This proves that the dataset is completely uniform across all three fruit classes.

## Practical Exercises

- **Exercise 3.1**: What would the accuracy of a naive classifier be if it always predicted `"apple"` on this 90-image dataset?
- **Exercise 3.2**: If a new dataset had 80 apples, 10 bananas, and 10 oranges, what would the baseline accuracy of always guessing "apple" be? Why is high accuracy misleading in that case?
- **Exercise 3.3**: Why does `main.py` use `sorted(df["label"].unique())` rather than unsorted `df["label"].unique()`?
- **Exercise 3.4**: Write a one-line pandas expression to verify that all classes have identical sample counts.

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Assuming accuracy is always a trustworthy metric | In imbalanced datasets, accuracy can be 99% while completely failing to detect the minority class. | Check class distributions with `value_counts()` and examine precision/recall alongside accuracy. |
| Forgetting to sort labels before building a confusion matrix | Different runs or Python versions might order categories differently, misaligning axes. | Always use `sorted(df["label"].unique())` to ensure deterministic class ordering. |
| Relying on `df.count()` instead of `df["label"].value_counts()` | `df.count()` returns total non-null values per column, not per-class breakdowns. | Use `df["label"].value_counts()` to see per-category frequencies. |

## Best Practices and Security Considerations

- **Always Inspect Class Balance First**: Before training any classifier, run `value_counts()` to identify potential class skew early.
- **Consistent Ordering**: Sort target class labels alphabetically so that confusion matrices, reports, and legends maintain consistent indexing across experiments.
- **Fair Representation**: Ensure all target classes have sufficient training examples; 30 samples per class is sufficient for this simple 5-feature problem, but complex tasks require more.

## Summary

Class distribution refers to the relative frequency of each category in a dataset. The Snack Sorter features a perfectly balanced dataset: exactly 30 apples, 30 bananas, and 30 oranges, totaling 90 samples. Because each class represents exactly $33.3\%$ of the dataset, overall accuracy provides an honest, reliable metric of classification capability without the distortions typical of imbalanced datasets.

## Knowledge-check Questions

1. How many total samples are present in `snacks.csv`, and how many belong to each fruit category?
2. What pandas method counts the number of occurrences of each unique value in a column?
3. What is the "accuracy paradox" that occurs in heavily imbalanced datasets?
4. What baseline accuracy would a random guesser or single-class guesser achieve on The Snack Sorter dataset?
5. Why does `main.py` sort the unique labels with `sorted(df["label"].unique())`?

## References

- Pandas value_counts Documentation: https://pandas.pydata.org/docs/reference/api/pandas.Series.value_counts.html
- Scikit-learn Guide on Imbalanced Data: https://scikit-learn.org/stable/modules/model_evaluation.html#classification-metrics
- The Snack Sorter source code: `main.py` lines 64 and 90.
