# Lesson 01: Reading `snacks.csv` & Navigating Project File Paths

**Lesson ID:** lesson-01
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Use Python's standard `pathlib.Path` to construct robust, cross-platform filesystem paths.
- Load `data/snacks.csv` into a pandas DataFrame using `pd.read_csv()`.
- Identify the 7 columns present in `snacks.csv` and verify the shape of the DataFrame (`90` rows, `7` columns).
- Explain why constructing paths relative to `__file__` is superior to hardcoding relative string paths.
- Safely create output directories using `Path.mkdir(exist_ok=True)`.

## Prerequisites

- Module 01: Project Overview & Problem Understanding.
- Familiarity with basic Python imports and directory structures.

## Concept Explanation

### The Fragility of Hardcoded Paths
When beginners write file loading code, they often write:
```python
# Fragile code
df = pd.read_csv("data/snacks.csv")
```
This code works *only* if the terminal's current working directory happens to be the exact folder where the script lives. If a user runs the script from a parent folder (e.g., `python projects/01_snack_sorter/main.py`), Python will look for `data/snacks.csv` in the root folder and immediately crash with:
`FileNotFoundError: [Errno 2] No such file or directory: 'data/snacks.csv'`.

### The Modern Python Solution: `pathlib.Path`
Python's built-in `pathlib` module provides an object-oriented, cross-platform approach to managing filesystem paths.
In `main.py`, lines 26–29 establish the path architecture:
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)
```
- `__file__` is a special variable containing the path to `main.py`.
- `.resolve()` expands symbolic links and makes the path absolute (e.g., `/home/aziz/.../01_snack_sorter/main.py`).
- `.parent` navigates up one level to the directory containing `main.py` (`BASE`).
- The `/` operator is overloaded by `Path` objects to join directory names safely across operating systems (using `/` on Linux/macOS and `\` on Windows).
- `OUT.mkdir(exist_ok=True)` creates the `outputs` directory if it does not already exist, without throwing an error if it already exists.

### Loading Tabular Data with pandas
Once `DATA` is defined, loading the dataset is a single expressive line:
```python
df = pd.read_csv(DATA / "snacks.csv")
```
Pandas reads the comma-separated text file, infers data types, and populates a 2-dimensional tabular structure called a `DataFrame`.

### Inspecting the Columns
The dataset contains 7 distinct columns:
1. `image_path`: Relative path to the original image file (e.g., `images/apple_00.png`).
2. `label`: Categorical target fruit string (`apple`, `banana`, or `orange`).
3. `mean_r`: Average red channel intensity (float).
4. `mean_g`: Average green channel intensity (float).
5. `mean_b`: Average blue channel intensity (float).
6. `color_fraction`: Fraction of non-background fruit pixels (float).
7. `aspect_ratio`: Bounding box width divided by height (float).

## Relevant Code (from main.py, lines 26-29, 34-35)

```python
26: BASE = Path(__file__).resolve().parent
27: DATA = BASE / "data"
28: OUT = BASE / "outputs"
29: OUT.mkdir(exist_ok=True)
...
34: def main() -> None:
35:     df = pd.read_csv(DATA / "snacks.csv")
```

### Code Explanation
- **Line 26**: Finds the absolute directory path of `main.py` and assigns it to `BASE`.
- **Line 27**: Constructs the path to the `data/` subdirectory: `DATA = BASE / "data"`.
- **Line 28**: Constructs the path to the `outputs/` subdirectory: `OUT = BASE / "outputs"`.
- **Line 29**: Creates `outputs/` if it doesn't already exist.
- **Line 35**: Ingests `snacks.csv` directly into the variable `df` via `pd.read_csv(DATA / "snacks.csv")`.

## Worked Example

**Verifying the Loaded DataFrame:**

Suppose we run a short verification script in the project directory:
```python
from pathlib import Path
import pandas as pd

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
df = pd.read_csv(DATA / "snacks.csv")

print(f"Dataset shape: {df.shape}")
print(f"Columns: {list(df.columns)}")
print(f"Missing values:\n{df.isnull().sum()}")
```

**Output:**
```text
Dataset shape: (90, 7)
Columns: ['image_path', 'label', 'mean_r', 'mean_g', 'mean_b', 'color_fraction', 'aspect_ratio']
Missing values:
image_path        0
label             0
mean_r            0
mean_g            0
mean_b            0
color_fraction    0
aspect_ratio      0
dtype: int64
```
**Interpretation:**
- `df.shape` is `(90, 7)`: exactly 90 rows (photos) and 7 columns.
- `isnull().sum()` confirms there are zero missing or null entries, ensuring clean downstream training.

## Step-by-Step Student Instructions

1. **Open a terminal** and navigate to `beginner-projects-main/AI-ML Beginners/projects/01_snack_sorter`.
2. **Launch Python**:
   ```bash
   python3
   ```
3. **Run the following commands interactively**:
   ```python
   from pathlib import Path
   import pandas as pd

   BASE = Path(".").resolve()
   df = pd.read_csv(BASE / "data" / "snacks.csv")
   print("Shape:", df.shape)
   print("First 3 rows:\n", df.head(3))
   ```
4. **Inspect column data types**:
   ```python
   print(df.dtypes)
   ```
5. Confirm that `image_path` and `label` are `object` (string) types, while the remaining 5 columns are `float64`.

## Expected Output or Observable Behaviour

The interactive terminal displays the first 3 rows:
```text
Shape: (90, 7)
First 3 rows:
            image_path  label  mean_r  mean_g  mean_b  color_fraction  aspect_ratio
0  images/apple_00.png  apple  178.57   43.50   44.97          0.3691         0.840
1  images/apple_01.png  apple  172.50   47.60   45.27          0.2461         0.810
2  images/apple_02.png  apple  175.47   45.38   44.15          0.3008         0.826
```

All 7 columns are correctly recognized and loaded.

## Practical Exercises

- **Exercise 1.1**: What is the result of running `print(df.columns.tolist())` on the loaded dataset?
- **Exercise 1.2**: Why does `OUT.mkdir(exist_ok=True)` use `exist_ok=True` instead of just `OUT.mkdir()`?
- **Exercise 1.3**: How many total rows of data are present in `snacks.csv`, excluding the header line?
- **Exercise 1.4**: If you execute `main.py` from your home directory (`python3 foundev/.../main.py`), why does `Path(__file__).resolve().parent` still find `data/snacks.csv` successfully?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Hardcoding string paths: `"data/snacks.csv"` | Fails if the script is executed from any directory other than the project directory. | Use `Path(__file__).resolve().parent` and `/` operators. |
| Forgetting `exist_ok=True` when making directories | If `outputs/` already exists, Python raises `FileExistsError`. | Always include `exist_ok=True` in `Path.mkdir()`. |
| Modifying the CSV directly in Excel | Spreadsheet editors can alter floating point precision or add formatting characters. | Inspect and edit CSVs using text editors or pandas code. |

## Best Practices and Security Considerations

- **Pathlib Over OS Module**: Prefer `pathlib.Path` over older `os.path` functions for cleaner, object-oriented syntax.
- **Verification on Ingestion**: Always check `df.shape` and `df.isnull().sum()` immediately after reading any CSV.
- **Sanitized Paths**: Never construct file paths by concatenating unvalidated user strings, which could lead to directory traversal vulnerabilities.

## Summary

In The Snack Sorter, data loading begins with robust path resolution using Python's `pathlib.Path`. By deriving paths relative to `__file__`, the script runs reliably regardless of the working directory. The dataset `data/snacks.csv` is loaded into a pandas DataFrame, providing 90 sample rows and 7 columns: image path references, target fruit labels, and 5 continuous numerical visual features.

## Knowledge-check Questions

1. What does `Path(__file__).resolve().parent` do in `main.py`?
2. What are the names of the 7 columns in `snacks.csv`?
3. What is the shape of the DataFrame resulting from `pd.read_csv(DATA / "snacks.csv")`?
4. What happens if `OUT.mkdir(exist_ok=True)` is called when the `outputs/` directory already exists?
5. Which two columns in `snacks.csv` have string (`object`) data types?

## References

- Python pathlib Documentation: https://docs.python.org/3/library/pathlib.html
- Pandas read_csv Documentation: https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html
- The Snack Sorter source code: `main.py` lines 26–35.
