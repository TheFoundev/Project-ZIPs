# Module 02 Exercises: Data Loading, Exploration & Splitting

---

## Exercise 2.1: Robust Path Resolution with `pathlib`

**Objective:** Understand and implement cross-platform filesystem path resolution using `pathlib.Path`.

**Problem Statement:**
In `main.py`, lines 26–29 set up directory paths:
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)
```
You need to explain how this code operates and why it is more robust than string-based paths like `DATA = "data"`.

**Requirements:**
1. Explain what `__file__`, `.resolve()`, and `.parent` do in sequence.
2. Explain what the `/` operator accomplishes when used with `Path` objects.
3. Explain the function of `exist_ok=True` in `mkdir()`.
4. Demonstrate how to construct a path to `data/images/banana_05.png` using the `DATA` variable.

**Constraints:**
- Use standard Python `pathlib` syntax without third-party path libraries.

**Expected Behaviour:**
A clear technical explanation and code snippet demonstrating robust path management.

**Acceptance Criteria:**
- [ ] Correctly details the role of `__file__`, `resolve()`, and `parent`.
- [ ] Explains that `/` joins filesystem paths cross-platform (handling `/` vs `\`).
- [ ] Explains that `exist_ok=True` prevents a crash if `outputs/` exists.
- [ ] Accurately constructs `DATA / "images" / "banana_05.png"`.

**Hints:**
- Think about running a script from `/home/user` versus running it from the project directory.
- `resolve()` turns relative paths into absolute canonical paths.

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 2.2: Image Loading and Metadata Inspection

**Objective:** Load and inspect a fruit image using `matplotlib.image` and verify its correspondence to metadata in `snacks.csv`.

**Problem Statement:**
Write a Python script that loads `data/snacks.csv`, selects the 15th row (index 14), prints its 5 feature values, loads the corresponding image file from disk using `mpimg.imread()`, and prints the image's dimensions and channel depth.

**Requirements:**
1. Load `snacks.csv` using pandas.
2. Extract row index 14 using `.iloc[14]`.
3. Print the `label` and the 5 feature values for this sample.
4. Construct the path `DATA / row["image_path"]` and load the image using `mpimg.imread()`.
5. Print the shape and data type of the resulting NumPy array.

**Constraints:**
- Must load the actual file `data/snacks.csv` and an actual image file from `data/images/`.

**Expected Behaviour:**
Console output displaying row 14's metadata and image array shape `(64, 64, 4)`.

**Acceptance Criteria:**
- [ ] Successfully reads `data/snacks.csv`.
- [ ] Extracts row index 14 correctly.
- [ ] Identifies the fruit class of row 14.
- [ ] Loads the image using `mpimg.imread()`.
- [ ] Reports the image shape as `(64, 64, 4)`.

**Hints:**
- Remember that `sample["image_path"]` already contains `"images/..."`, so join it directly with `DATA`.
- `mpimg.imread()` returns a NumPy array with pixel values between 0.0 and 1.0 (for PNGs).

**Difficulty:** Intermediate
**Estimated Completion Time:** 20 minutes

---

## Exercise 2.3: Class Balance and Distribution Verification

**Objective:** Perform a rigorous check of class balance across all rows in `snacks.csv`.

**Problem Statement:**
Before training any classification model, a data scientist must verify that target classes are represented fairly. You must write pandas code to analyze the label distribution of `snacks.csv`.

**Requirements:**
1. Compute the count of each fruit label using `.value_counts()`.
2. Compute the normalized proportion of each label using `.value_counts(normalize=True)`.
3. Check whether the counts are strictly identical for all classes.
4. Calculate what the baseline accuracy would be for a naive model that always predicts `"apple"`.

**Constraints:**
- Perform calculations dynamically using pandas methods rather than hardcoding numbers.

**Expected Behaviour:**
A short script and written report verifying that all 3 classes have 30 samples ($33.3\%$) and explaining the implications for evaluation.

**Acceptance Criteria:**
- [ ] Reports exactly 30 samples for `apple`, `banana`, and `orange`.
- [ ] Reports proportions of 0.333333 (33.33%) for each class.
- [ ] Correctly identifies naive guessing baseline accuracy as 33.3%.
- [ ] Concludes that the dataset is perfectly balanced.

**Hints:**
- Use `df["label"].value_counts()` and `df["label"].value_counts(normalize=True)`.
- If there are 3 equal classes, guessing any one class always yields $1/3$ accuracy.

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 2.4: Implementing and Verifying a Stratified Split

**Objective:** Implement a 6-variable train/test split with stratification and verify the preservation of class ratios.

**Problem Statement:**
In `main.py`, line 39 executes:
```python
X_train, X_test, y_train, y_test, idx_train, idx_test = train_test_split(
    X, y, df.index, test_size=0.25, random_state=42, stratify=y
)
```
Write a script that executes this split, verifies the sample counts of `X_train` and `X_test`, and proves that `stratify=y` preserves the class distribution.

**Requirements:**
1. Separate `X = df[FEATURES]` and `y = df["label"]`.
2. Call `train_test_split()` with `df.index`, `test_size=0.25`, `random_state=42`, and `stratify=y`.
3. Verify that `len(X_train) == 67` and `len(X_test) == 23`.
4. Print the `value_counts()` of `y_train` and `y_test`.
5. Show how `idx_test` can be used with `df.loc[idx_test]` to print the filenames of the first 3 test images.

**Constraints:**
- Must use the exact parameter values from `main.py` (`test_size=0.25`, `random_state=42`, `stratify=y`).

**Expected Behaviour:**
A complete Python script producing verified counts of 67 training and 23 testing instances with class breakdowns matching `main.py`.

**Acceptance Criteria:**
- [ ] Unpacks all 6 returned variables correctly.
- [ ] Confirms 67 train photos and 23 test photos.
- [ ] Confirms `y_train` has 23 apples, 22 bananas, and 22 oranges.
- [ ] Confirms `y_test` has 7 apples, 8 bananas, and 8 oranges.
- [ ] Demonstrates lookup using `df.loc[idx_test]`.

**Hints:**
- 90 * 0.25 = 22.5, which rounds to 23 test images.
- 90 - 23 = 67 training images.

**Difficulty:** Intermediate
**Estimated Completion Time:** 25 minutes
