# Lesson 03: The Multi-Class Confusion Matrix

**Lesson ID:** lesson-03
**Module:** module-05
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Define a **confusion matrix** and explain its layout for a multi-class problem.
- Read and interpret the rows (True Labels) and columns (Predicted Labels) of a 3x3 confusion matrix.
- Distinguish between **diagonal elements** (correct classifications) and **off-diagonal elements** (misclassifications).
- Use `confusion_matrix()` and `ConfusionMatrixDisplay` in scikit-learn to calculate and plot a confusion matrix.
- Customize color maps (`cmap="Greens"`), suppress color bars, and save the resulting visualization to `outputs/confusion_matrix.png`.

## Prerequisites

- Module 05, Lesson 01: Multi-Class Accuracy Score and Its Nuances.
- Module 05, Lesson 02: Classification Report: Precision, Recall, and F1-Score.

## Concept Explanation

### What Is a Confusion Matrix?
A **confusion matrix** is a table layout that visualizes the performance of a supervised classification algorithm. Each row of the matrix represents instances in an actual true class, while each column represents instances in a predicted class (or vice versa, depending on convention).

Its name comes from its purpose: it reveals whether the system is "confusing" two classes (e.g., mislabeling an orange as an apple).

### Reading a 3x3 Confusion Matrix
For our three snack classes ordered alphabetically (`apple`, `banana`, `orange`):

```text
                  Predicted
             apple   banana   orange
True apple  [  7       0        0   ]
     banana [  0       8        0   ]
     orange [  0       0        8   ]
```

Let's dissect what each cell means:
- **The Main Diagonal (Top-Left to Bottom-Right)**:
  - Row 0, Col 0: True Apple predicted as Apple = **7** (Correct!)
  - Row 1, Col 1: True Banana predicted as Banana = **8** (Correct!)
  - Row 2, Col 2: True Orange predicted as Orange = **8** (Correct!)
  - In an ideal, 100% accurate classifier, **all non-zero numbers lie along the main diagonal**.
- **The Off-Diagonal Elements**:
  - Any number outside the main diagonal represents an error (a misclassification).
  - For example, if Row 2, Col 0 had a value of $2$, it would mean 2 real oranges were mistakenly predicted as apples.
  - In our matrix, **every off-diagonal cell is exactly 0**, proving zero confusion!

### Computing the Matrix with `confusion_matrix()`
In `main.py`, lines 90–91 calculate the matrix:
```python
labels = sorted(df["label"].unique())
cm = confusion_matrix(y_test, predictions, labels=labels)
```
- Passing `labels=labels` explicitly fixes the row and column ordering: index 0 is `"apple"`, index 1 is `"banana"`, and index 2 is `"orange"`.
- This returns a $3 \times 3$ NumPy integer array:
  ```python
  array([[7, 0, 0],
         [0, 8, 0],
         [0, 0, 8]])
  ```

### Plotting with `ConfusionMatrixDisplay`
Rather than reading raw numbers in a terminal, scikit-learn provides `ConfusionMatrixDisplay` to render a clean visual heatmap.
In `main.py`, lines 92–97 render and save the plot:
```python
fig, ax = plt.subplots(figsize=(5.5, 4.5))
ConfusionMatrixDisplay(cm, display_labels=labels).plot(ax=ax, cmap="Greens", colorbar=False)
ax.set_title("Which snacks did the AI confuse?")
fig.tight_layout()
fig.savefig(OUT / "confusion_matrix.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```
- `ConfusionMatrixDisplay(cm, display_labels=labels)`: Binds the matrix values to class labels.
- `.plot(ax=ax, cmap="Greens", colorbar=False)`:
  - `cmap="Greens"`: Applies a soothing green color palette where darker shades indicate higher sample counts.
  - `colorbar=False`: Suppresses the side colorbar for a cleaner presentation.
- `ax.set_title("Which snacks did the AI confuse?")`: Adds a friendly diagnostic title.
- Saves to `outputs/confusion_matrix.png`.

## Relevant Code (from main.py, lines 20, 90-97)

```python
20: from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay, confusion_matrix
...
90:     labels = sorted(df["label"].unique())
91:     cm = confusion_matrix(y_test, predictions, labels=labels)
92:     fig, ax = plt.subplots(figsize=(5.5, 4.5))
93:     ConfusionMatrixDisplay(cm, display_labels=labels).plot(ax=ax, cmap="Greens", colorbar=False)
94:     ax.set_title("Which snacks did the AI confuse?")
95:     fig.tight_layout()
96:     fig.savefig(OUT / "confusion_matrix.png", dpi=150, bbox_inches="tight")
97:     plt.close(fig)
```

### Code Explanation
- **Line 20**: Imports `confusion_matrix` and `ConfusionMatrixDisplay`.
- **Line 90**: Obtains the sorted label list `['apple', 'banana', 'orange']`.
- **Line 91**: Calculates the $3 \times 3$ numerical matrix.
- **Lines 92-93**: Plots the matrix on a $5.5 \times 4.5$ inch canvas using the green colormap.
- **Line 94**: Titles the plot.
- **Lines 95-97**: Adjusts layout, exports `outputs/confusion_matrix.png`, and frees memory.

## Worked Example

**Simulating an Imperfect Confusion Matrix:**

Suppose a classifier tested on 23 fruits made 2 errors: it confused 1 orange for an apple, and 1 banana for an apple.
```python
import numpy as np
from sklearn.metrics import confusion_matrix

labels = ["apple", "banana", "orange"]
y_true = ["apple"]*7 + ["banana"]*8 + ["orange"]*8
# Inject 2 errors
y_pred = ["apple"]*7 + ["banana"]*7 + ["apple"] + ["orange"]*7 + ["apple"]

cm = confusion_matrix(y_true, y_pred, labels=labels)
print("Simulated Imperfect Confusion Matrix:")
print(cm)
```

**Output:**
```text
Simulated Imperfect Confusion Matrix:
[[7 0 0]
 [1 7 0]
 [1 0 7]]
```

**Interpretation:**
- Row 0 (Apple): 7 true apples, all 7 predicted as apple.
- Row 1 (Banana): 7 predicted as banana, but 1 predicted as apple (Column 0).
- Row 2 (Orange): 7 predicted as orange, but 1 predicted as apple (Column 0).
- Total correct = $7 + 7 + 7 = 21$.
- Total errors = $1 + 1 = 2$.
- Accuracy = $\frac{21}{23} = 91.3\%$.
The confusion matrix immediately shows that errors were not random: the model is biased toward predicting apples!

## Step-by-Step Student Instructions

1. **Open your terminal** and launch Python.
2. **Import metric and plotting utilities**:
   ```python
   from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
   import matplotlib.pyplot as plt
   ```
3. **Execute lines 35–50 of `main.py`** to obtain `y_test` and `predictions`.
4. **Compute the matrix**:
   ```python
   labels = ["apple", "banana", "orange"]
   cm = confusion_matrix(y_test, predictions, labels=labels)
   print("Confusion Matrix:\n", cm)
   ```
5. **Verify that the sum of the diagonal equals 23**:
   ```python
   print("Diagonal sum (correct):", cm.diagonal().sum())
   ```
6. **Check `outputs/confusion_matrix.png`** on disk to view the visual heatmap.

## Expected Output or Observable Behaviour

Executing this in Python outputs:
```text
Confusion Matrix:
 [[7 0 0]
  [0 8 0]
  [0 0 8]]
Diagonal sum (correct): 23
```
And viewing `outputs/confusion_matrix.png` shows three dark green diagonal squares with white text `7`, `8`, `8`, and light/empty off-diagonal squares with `0`.

## Practical Exercises

- **Exercise 3.1**: In a confusion matrix, what do numbers on the main diagonal represent?
- **Exercise 3.2**: If cell `cm[1, 2] == 3`, what does that mean in terms of true class and predicted class? (Assuming index 1 is banana and index 2 is orange).
- **Exercise 3.3**: Why is it important to pass `labels=sorted(df["label"].unique())` to `confusion_matrix()`?
- **Exercise 3.4**: How can you calculate overall accuracy directly from the numbers inside a confusion matrix?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Confusing rows with columns | By standard convention in scikit-learn, rows are True labels and columns are Predicted labels. | Remember: "Row = Real, Column = Call/Prediction". |
| Omitting `labels=labels` | If test data accidentally omits a class, scikit-learn will produce a smaller matrix (e.g., $2 \times 2$), misaligning indices. | Always specify `labels=labels` explicitly. |
| Forgetting `colorbar=False` | A colorbar takes up significant horizontal space, squeezing the matrix cells on small figure sizes. | Use `colorbar=False` when matrix values are clear from cell annotations. |

## Best Practices and Security Considerations

- **Always Plot Confusion Matrices for Multi-Class Tasks**: It is impossible to diagnose multi-class failure modes without seeing which specific classes are being confused.
- **Normalize for Imbalanced Data**: When classes have drastically different sample sizes, plot a normalized confusion matrix using `normalize="true"` to display percentages rather than raw counts.
- **Accessible Colormaps**: Choose colormaps with distinct contrast (like `Blues` or `Greens`) to ensure readability across print and screen media.

## Summary

A confusion matrix maps ground-truth classes (rows) against predicted classes (columns). Correct predictions populate the main diagonal, while off-diagonal cells highlight misclassifications. In The Snack Sorter, lines 90–97 of `main.py` compute a $3 \times 3$ confusion matrix and visualize it as a green heatmap using `ConfusionMatrixDisplay`. With diagonal counts of 7 apples, 8 bananas, and 8 oranges, and zeros in all off-diagonal cells, the plot proves that the AI experienced zero confusion.

## Knowledge-check Questions

1. In a scikit-learn confusion matrix, do rows represent the true labels or predicted labels?
2. What does it mean when all off-diagonal values in a confusion matrix are zero?
3. What are the values along the main diagonal of the confusion matrix in The Snack Sorter?
4. What scikit-learn class is used to plot the matrix as a visual heatmap?
5. Why does `main.py` explicitly specify `labels=labels` when calling `confusion_matrix()`?

## References

- Scikit-learn confusion_matrix Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.metrics.confusion_matrix.html
- Scikit-learn ConfusionMatrixDisplay Reference: https://scikit-learn.org/stable/modules/generated/sklearn.metrics.ConfusionMatrixDisplay.html
- The Snack Sorter source code: `main.py` lines 90–97.
