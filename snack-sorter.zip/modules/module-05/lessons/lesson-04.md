# Lesson 04: Reading, Interpreting, and Saving `metrics.txt`

**Lesson ID:** lesson-04
**Module:** module-05
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain why persisting evaluation metrics to a text file is a best practice in machine learning engineering.
- Inspect and interpret each line of `outputs/metrics.txt`.
- Understand file handling with context managers (`with open(...) as handle:`) and explicit `encoding="utf-8"`.
- Use automated scripts or CI/CD pipelines to parse `metrics.txt` for regression testing.
- Connect the numerical values in `metrics.txt` back to the visual artifacts (`confusion_matrix.png` and `predictions.png`).

## Prerequisites

- Module 05, Lesson 01: Multi-Class Accuracy Score and Its Nuances.
- Module 05, Lesson 02: Classification Report: Precision, Recall, and F1-Score.
- Basic understanding of Python file I/O.

## Concept Explanation

### Why Save Metrics to Disk?
When running machine learning experiments, printing results to the terminal console is ephemeral: once the terminal window closes or the screen scrolls, the information is gone.
Writing metrics to an artifact file like `outputs/metrics.txt` provides:
1. **Experiment Tracking**: You can commit `metrics.txt` to Git or compare it against future model iterations.
2. **Automated CI/CD Verification**: Continuous Integration test suites can automatically open `metrics.txt` and assert: `assert float(accuracy) >= 0.95`.
3. **Reproducibility**: Mentors, clients, and automated grading systems can verify results without having to re-run the entire pipeline.

### Safe File Handling in Python
In `main.py`, lines 100–102 write the metrics file:
```python
with open(OUT / "metrics.txt", "w", encoding="utf-8") as handle:
    handle.write(f"accuracy: {accuracy:.4f}\n\n")
    handle.write(classification_report(y_test, predictions, zero_division=0))
```

Let's dissect the components:
- `OUT / "metrics.txt"`: Resolves to the absolute path `<project_root>/outputs/metrics.txt`.
- `"w"`: Open mode for writing (creates the file if it does not exist, overwrites if it does).
- `encoding="utf-8"`: Explicitly specifies UTF-8 character encoding, preventing encoding bugs across different operating systems (especially Windows).
- `with ... as handle`: Python's **context manager** pattern guarantees that the file handle is automatically flushed and closed when the block exits, even if an exception occurs.

### Structure of `metrics.txt`
Opening `outputs/metrics.txt` reveals the full summary:
```text
accuracy: 1.0000

              precision    recall  f1-score   support

       apple       1.00      1.00      1.00         7
      banana       1.00      1.00      1.00         8
      orange       1.00      1.00      1.00         8

    accuracy                           1.00        23
   macro avg       1.00      1.00      1.00        23
weighted avg       1.00      1.00      1.00        23
```

- **Line 1 (`accuracy: 1.0000`)**: Exact test accuracy formatted to 4 decimal places ($100.00\%$).
- **Line 2**: Blank line for visual separation.
- **Lines 3–11**: The full scikit-learn classification report displaying precision, recall, f1-score, and support for all three fruit categories, alongside the macro and weighted averages.

### Connecting Metrics to Visual Artifacts
Every number in `metrics.txt` corresponds to a physical feature in the visual output artifacts:
- The support numbers ($7, 8, 8$) correspond to the row totals in `outputs/confusion_matrix.png` and the true class counts in `outputs/predictions.png`.
- The recall of $1.00$ reflects the fact that every single true apple, banana, and orange has zero off-diagonal misclassifications in `outputs/confusion_matrix.png`.
- The precision of $1.00$ reflects the fact that every photo titled `predicted: apple` in `outputs/predictions.png` is indeed an apple.

## Relevant Code (from main.py, lines 100-103)

```python
100:     with open(OUT / "metrics.txt", "w", encoding="utf-8") as handle:
101:         handle.write(f"accuracy: {accuracy:.4f}\n\n")
102:         handle.write(classification_report(y_test, predictions, zero_division=0))
```

### Code Explanation
- **Line 100**: Safely opens `outputs/metrics.txt` with UTF-8 encoding.
- **Line 101**: Formats and writes the overall test accuracy with two newline characters.
- **Line 102**: Generates and writes the complete text classification report.
- Upon exiting line 102, the context manager automatically closes the file.

## Worked Example

**Parsing `metrics.txt` with an Automated Python Test:**

In professional production systems, automated tests verify that models meet performance criteria. Here is how a test script reads and verifies `metrics.txt`:

```python
from pathlib import Path

metrics_file = Path("outputs/metrics.txt")

# Read file
with open(metrics_file, "r", encoding="utf-8") as f:
    content = f.read()

# Extract accuracy line
first_line = content.splitlines()[0]
metric_name, metric_val = first_line.split(":")
accuracy = float(metric_val.strip())

print(f"Extracted Metric: {metric_name} = {accuracy}")

# Automated quality assertion
threshold = 0.95
if accuracy >= threshold:
    print(f"PASS: Accuracy {accuracy:.4f} exceeds target threshold ({threshold:.2f})")
else:
    print(f"FAIL: Accuracy {accuracy:.4f} is below target threshold ({threshold:.2f})")
```

**Output:**
```text
Extracted Metric: accuracy = 1.0
PASS: Accuracy 1.0000 exceeds target threshold (0.95)
```

**Interpretation:**
- Demonstrates how simple text-based metrics files enable automated validation in continuous integration (CI) workflows.

## Step-by-Step Student Instructions

1. **Open your terminal** in the project directory.
2. **Display `metrics.txt`**:
   ```bash
   cat outputs/metrics.txt
   ```
3. **Verify the file size and line count**:
   ```bash
   wc -l outputs/metrics.txt
   # Output: 11 lines
   ```
4. **Search for class-level metrics using `grep`**:
   ```bash
   grep "apple" outputs/metrics.txt
   grep "accuracy" outputs/metrics.txt
   ```
5. Confirm that the numbers match the console output printed when you executed `python3 main.py`.

## Expected Output or Observable Behaviour

Running `cat outputs/metrics.txt` displays:
```text
accuracy: 1.0000

              precision    recall  f1-score   support

       apple       1.00      1.00      1.00         7
      banana       1.00      1.00      1.00         8
      orange       1.00      1.00      1.00         8

    accuracy                           1.00        23
   macro avg       1.00      1.00      1.00        23
weighted avg       1.00      1.00      1.00        23
```
This confirms that the evaluation summary is cleanly persisted to disk.

## Practical Exercises

- **Exercise 4.1**: What encoding is specified when `outputs/metrics.txt` is opened in `main.py`? Why is this important?
- **Exercise 4.2**: Write a short Python function that reads `outputs/metrics.txt` and returns the support for the `banana` class as an integer.
- **Exercise 4.3**: Why is using a `with` context manager safer than calling `handle = open(...)` and `handle.close()` manually?
- **Exercise 4.4**: If the model was retrained on a new split and achieved 95.65% accuracy, how would that line appear in `metrics.txt`?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Omitting `encoding="utf-8"` | On Windows, Python defaults to system codepages (like cp1252), which can corrupt special characters or cause cross-platform read failures. | Always specify `encoding="utf-8"` in `open()`. |
| Forgetting `exist_ok=True` when creating `OUT` | If the `outputs/` folder doesn't exist, `open(OUT / "metrics.txt")` throws `FileNotFoundError`. | Always call `OUT.mkdir(exist_ok=True)` before opening files in that directory. |
| Overwriting without formatting | Writing raw floats without `: .4f` creates variable precision text (e.g., `1.0` vs `0.9565217391304348`). | Use fixed format specifiers like `:.4f`. |

## Best Practices and Security Considerations

- **Atomic File Writing**: In mission-critical pipelines, write metrics to a temporary file first and atomically rename it to prevent partially written files during power or process interruptions.
- **Structured Artifacts**: For complex production systems, consider exporting structured formats (such as JSON or YAML) alongside plain text logs for easy automated ingestion.
- **Immutability of Evaluation Logs**: Store evaluation metrics alongside the Git commit hash and timestamp to ensure complete traceability.

## Summary

Persisting evaluation results to `outputs/metrics.txt` ensures that model performance metrics are archived for experiment tracking and automated verification. In The Snack Sorter, lines 100–103 use a Python context manager with `encoding="utf-8"` to write test accuracy (1.0000) and the full scikit-learn classification report to disk. This plain text file bridges human interpretation and automated validation, corroborating the visual findings in `confusion_matrix.png`.

## Knowledge-check Questions

1. Why is it advantageous to save model metrics to a file rather than only printing them to the console?
2. What Python statement is used in `main.py` to ensure files are safely closed after writing?
3. How is the accuracy value formatted in line 101 of `main.py`?
4. What encoding is specified when opening `outputs/metrics.txt`?
5. How does the support value of 23 in `metrics.txt` relate to the test set size?

## References

- Python File I/O Documentation: https://docs.python.org/3/tutorial/inputoutput.html#reading-and-writing-files
- Python Context Managers: https://docs.python.org/3/reference/compound_stmts.html#with
- The Snack Sorter source code: `main.py` lines 100–103.
