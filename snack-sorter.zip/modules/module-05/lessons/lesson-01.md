# Lesson 01: Multi-Class Accuracy Score and Its Nuances

**Lesson ID:** lesson-01
**Module:** module-05
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Define the mathematical formula for classification **accuracy**.
- Calculate multi-class accuracy manually from true and predicted label vectors.
- Use scikit-learn's `accuracy_score()` to evaluate test predictions.
- Format accuracy as a percentage string (e.g., `100.0%`) using Python format specifiers.
- Explain the strengths and limitations of accuracy as an evaluation metric in multi-class classification.

## Prerequisites

- Module 04, Lesson 02: Generating Test Predictions with `model.predict()`.
- Basic understanding of fractions and percentages.

## Concept Explanation

### What Is Accuracy?
In machine learning, **accuracy** is the most intuitive and widely used classification evaluation metric. It answers the fundamental question:
> *"Out of all the test examples shown to the model, what fraction did it classify correctly?"*

Mathematically, for a test set of size $N$:
$$\text{Accuracy} = \frac{\text{Number of Correct Predictions}}{N} = \frac{1}{N} \sum_{i=1}^N \mathbb{I}(y_i = \hat{y}_i)$$
where $\mathbb{I}(y_i = \hat{y}_i)$ equals $1$ when the true label $y_i$ matches the predicted label $\hat{y}_i$, and $0$ otherwise.

### Accuracy in The Snack Sorter
In our test split:
- Total test images: $N = 23$ (7 apples, 8 bananas, 8 oranges).
- When `predictions = model.predict(X_test)` is executed, the model correctly predicts all 7 apples, all 8 bananas, and all 8 oranges.
- Total correct predictions: $7 + 8 + 8 = 23$.
- Mathematical accuracy:
  $$\text{Accuracy} = \frac{23}{23} = \mathbf{1.0000} = \mathbf{100.0\%}$$

### Scikit-Learn's `accuracy_score()`
Scikit-learn provides `accuracy_score` in `sklearn.metrics`.
In `main.py`, line 52 computes this metric:
```python
accuracy = accuracy_score(y_test, predictions)
```
- By default, `accuracy_score` returns a floating-point number between $0.0$ and $1.0$.
- In line 58, `print(f"Accuracy: {accuracy:.1%}")` formats `1.0` as `"100.0%"`.
- In line 101, `handle.write(f"accuracy: {accuracy:.4f}\n\n")` formats it to 4 decimal places: `"accuracy: 1.0000"`.

### The Nuances of Multi-Class Accuracy
While a 100% accuracy score on our balanced test set is a genuine indicator of model success, accuracy has important limitations in other contexts:
1. **Masking Per-Class Deficiencies**:
   - In a 3-class problem, an overall accuracy of $67\%$ might mean the model gets 100% on apples and 100% on bananas, but fails completely (0%) on oranges! Accuracy alone does not reveal which specific class is failing.
2. **Vulnerability to Imbalance**:
   - If a test set has 90 apples and only 5 bananas and 5 oranges, predicting "apple" every time yields 90% accuracy despite being totally blind to bananas and oranges.
   - Fortunately, because The Snack Sorter's test set is stratified and balanced, accuracy is an honest and representative benchmark.

## Relevant Code (from main.py, lines 20, 52, 58, 101)

```python
20: from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay, confusion_matrix
...
52:     accuracy = accuracy_score(y_test, predictions)
...
58:     print(f"Accuracy:        {accuracy:.1%}")
...
101:         handle.write(f"accuracy: {accuracy:.4f}\n\n")
```

### Code Explanation
- **Line 20**: Imports `accuracy_score` from `sklearn.metrics`.
- **Line 52**: Computes the test accuracy by comparing ground-truth `y_test` against `predictions`.
- **Line 58**: Prints the formatted percentage string `Accuracy: 100.0%` to the terminal console.
- **Line 101**: Writes `accuracy: 1.0000` to `outputs/metrics.txt`.

## Worked Example

**Manual vs. Automated Accuracy Calculation in Python:**

```python
import numpy as np
from sklearn.metrics import accuracy_score

# Sample true labels and predictions
y_true = np.array(["apple", "banana", "orange", "apple", "banana", "orange"])
y_pred = np.array(["apple", "banana", "orange", "apple", "banana", "banana"])

# Manual calculation
matches = (y_true == y_pred)
print("Boolean matches:", matches)
correct_count = matches.sum()
total_count = len(y_true)
manual_accuracy = correct_count / total_count
print(f"Manual accuracy: {correct_count} / {total_count} = {manual_accuracy:.4f} ({manual_accuracy:.1%})")

# Scikit-learn calculation
sklearn_accuracy = accuracy_score(y_true, y_pred)
print(f"Scikit-learn accuracy: {sklearn_accuracy:.4f}")
```

**Output:**
```text
Boolean matches: [ True  True  True  True  True False]
Manual accuracy: 5 / 6 = 0.8333 (83.3%)
Scikit-learn accuracy: 0.8333
```

**Interpretation:**
- 5 out of 6 predictions match, producing an accuracy of $83.3\%$.
- `accuracy_score()` reproduces the exact manual formula: total correct divided by total samples.

## Step-by-Step Student Instructions

1. **Open your terminal** and start Python.
2. **Import `accuracy_score` and pandas**:
   ```python
   from sklearn.metrics import accuracy_score
   import pandas as pd
   ```
3. **Execute lines 35–52 of `main.py`** to obtain `y_test` and `predictions`.
4. **Compute and inspect accuracy**:
   ```python
   acc = accuracy_score(y_test, predictions)
   print("Raw accuracy float:", acc)
   print("Formatted percentage:", f"{acc:.1%}")
   print("Formatted 4-decimal:", f"{acc:.4f}")
   ```
5. **Verify that `(y_test == predictions).sum()` equals 23**.

## Expected Output or Observable Behaviour

Executing these commands outputs:
```text
Raw accuracy float: 1.0
Formatted percentage: 100.0%
Formatted 4-decimal: 1.0000
```
This confirms that all 23 test images were classified with zero errors.

## Practical Exercises

- **Exercise 1.1**: If a test set has 23 photos and the model misclassifies 2 photos, what is the resulting accuracy score?
- **Exercise 1.2**: In Python f-string formatting, what is the difference between `{acc:.1%}` and `{acc:.4f}`?
- **Exercise 1.3**: Can classification accuracy ever exceed 1.0 or fall below 0.0? Why or why not?
- **Exercise 1.4**: Why does `accuracy_score(y_test, predictions)` require `y_test` and `predictions` to have the exact same length?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Reversing the order of arguments: `accuracy_score(predictions, y_test)` | While symmetric for simple accuracy, other metrics (like precision/recall) depend strictly on `(y_true, y_pred)`. | Always follow scikit-learn standard order: `accuracy_score(y_true, y_pred)`. |
| Comparing predictions against training labels: `accuracy_score(y_train, predictions)` | Evaluating test predictions against training labels raises a length mismatch error or yields nonsensical results. | Compare `predictions` strictly against `y_test`. |
| Relying exclusively on accuracy for imbalanced datasets | High accuracy can mask total failure on minority classes. | Complement accuracy with precision, recall, and confusion matrices. |

## Best Practices and Security Considerations

- **Pair Accuracy with Per-Class Metrics**: Always report accuracy alongside class-level precision and recall to verify that all categories perform well.
- **Independent Evaluation Split**: Compute accuracy strictly on unseen test data, never on the training data used to fit the pipeline.
- **Deterministic Formatting**: Store exact floating-point metrics with explicit decimal formatting (`.4f`) in text logs for automated regression testing.

## Summary

Accuracy is the ratio of correct predictions to total test samples. In The Snack Sorter, scikit-learn's `accuracy_score(y_test, predictions)` compares ground-truth labels with model predictions across 23 unseen test images, producing a perfect score of 1.0000 (100.0%). While accuracy provides an intuitive single-number summary, pairing it with per-class metrics ensures that high performance extends uniformly across all three fruit categories.

## Knowledge-check Questions

1. What is the mathematical definition of classification accuracy?
2. How many test photos were evaluated in `main.py`, and how many were correctly classified?
3. What is the scikit-learn function used to compute accuracy?
4. What output is generated by Python's `{accuracy:.1%}` format specifier when `accuracy = 1.0`?
5. Why can overall accuracy be misleading when evaluated on an imbalanced dataset?

## References

- Scikit-learn accuracy_score Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.metrics.accuracy_score.html
- Scikit-learn Model Evaluation Guide: https://scikit-learn.org/stable/modules/model_evaluation.html#accuracy-score
- The Snack Sorter source code: `main.py` lines 52 and 58.
