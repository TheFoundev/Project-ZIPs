# Lesson 03: Visualizing Training Data: Creating the Example Contact Sheet

**Lesson ID:** lesson-03
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain what a photographic "contact sheet" is and why it is useful in computer vision.
- Use `plt.subplots(3, 4)` to create a multi-row, multi-column grid of axes in matplotlib.
- Iterate over class categories and DataFrame subsets to extract sample image paths.
- Load and display image files on individual subplots using `mpimg.imread()` and `ax.imshow()`.
- Format subplot titles, suppress axis tick marks (`ax.axis("off")`), and save the figure to disk using `fig.savefig()`.

## Prerequisites

- Module 02, Lesson 02: Inspecting Image Paths and Visual Feature Columns.
- Basic familiarity with matplotlib figures and subplots.

## Concept Explanation

### What Is a Contact Sheet?
In traditional analog photography, a **contact sheet** is a print containing thumbnail previews of every frame on a roll of film, allowing photographers to quickly scan and select the best shots.
In computer vision, generating a visual contact sheet of training images serves several crucial engineering purposes:
1. **Data Sanity Check**: Immediately reveals whether image files are corrupted, blank, inverted, or mislabeled.
2. **Visual Intuition**: Allows data scientists and stakeholders to see the visual diversity (lighting variations, angles, shapes) within each target class.
3. **Communication**: Provides an intuitive visual artifact for reports, presentations, and documentation.

### Creating the 3x4 Matplotlib Grid
In `main.py`, lines 63–74 construct the training contact sheet:
```python
fig, axes = plt.subplots(3, 4, figsize=(8, 6))
```
- `3, 4`: Creates a grid with **3 rows** (one row for each fruit: row 0 = apple, row 1 = banana, row 2 = orange) and **4 columns** (displaying 4 distinct image examples per fruit).
- `figsize=(8, 6)`: Specifies the overall figure width (8 inches) and height (6 inches).
- `axes`: A 2D NumPy array of shape `(3, 4)` containing the 12 individual `Axes` subplot objects.

### Nested Loop: Rows by Classes, Columns by Examples
Lines 64–70 populate the grid using nested loops:
```python
for row, label in enumerate(sorted(df["label"].unique())):
    samples = df[df["label"] == label].head(4)
    for col, (_, sample) in enumerate(samples.iterrows()):
        ax = axes[row, col]
        ax.imshow(mpimg.imread(DATA / sample["image_path"]))
        ax.set_title(label, fontsize=9)
        ax.axis("off")
```
- `enumerate(sorted(df["label"].unique()))`: Loops over the 3 sorted classes, assigning `row=0` to `"apple"`, `row=1` to `"banana"`, and `row=2` to `"orange"`.
- `df[df["label"] == label].head(4)`: Filters the DataFrame to retrieve the first 4 photos for that fruit class.
- `samples.iterrows()`: Loops through the 4 samples, assigning each to `col=0, 1, 2, 3`.
- `ax = axes[row, col]`: Selects the specific subplot for that row and column.
- `ax.imshow(...)`: Reads the PNG file via `mpimg.imread()` and displays the pixel array.
- `ax.set_title(label, fontsize=9)`: Adds a clean title indicating the fruit name.
- `ax.axis("off")`: Hides pixel coordinate axes and ticks (since photos look much cleaner without numerical axis rulers).

### Final Polish and Saving to Disk
```python
fig.suptitle("Example snack photos used for training", fontsize=13)
fig.tight_layout()
fig.savefig(OUT / "sample_snacks.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```
- `fig.suptitle()`: Adds an overarching master title across the entire figure.
- `fig.tight_layout()`: Automatically adjusts padding between subplots to prevent titles from overlapping adjacent photos.
- `fig.savefig()`: Saves the figure as a high-resolution PNG (`dpi=150`) with bounding box trimmed (`bbox_inches="tight"`).
- `plt.close(fig)`: Closes the figure to free up memory, which is essential in non-interactive server environments.

## Relevant Code (from main.py, lines 63-74)

```python
63:     fig, axes = plt.subplots(3, 4, figsize=(8, 6))
64:     for row, label in enumerate(sorted(df["label"].unique())):
65:         samples = df[df["label"] == label].head(4)
66:         for col, (_, sample) in enumerate(samples.iterrows()):
67:             ax = axes[row, col]
68:             ax.imshow(mpimg.imread(DATA / sample["image_path"]))
69:             ax.set_title(label, fontsize=9)
70:             ax.axis("off")
71:     fig.suptitle("Example snack photos used for training", fontsize=13)
72:     fig.tight_layout()
73:     fig.savefig(OUT / "sample_snacks.png", dpi=150, bbox_inches="tight")
74:     plt.close(fig)
```

### Code Explanation
- **Line 63**: Sets up the 3-row, 4-column canvas.
- **Lines 64-70**: Renders 4 example images for each of the 3 fruit categories.
- **Line 71**: Adds the figure-level suptitle.
- **Line 72**: Minimizes margin wasted space.
- **Line 73**: Writes the image to `outputs/sample_snacks.png`.
- **Line 74**: Cleans up the matplotlib memory buffer.

## Worked Example

**Creating a Mini 1x3 Contact Sheet Showing One Example per Fruit:**

```python
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import pandas as pd

BASE = Path(".").resolve()
DATA = BASE / "data"
df = pd.read_csv(DATA / "snacks.csv")

fig, axes = plt.subplots(1, 3, figsize=(6, 2))
classes = sorted(df["label"].unique())

for ax, label in zip(axes, classes):
    sample = df[df["label"] == label].iloc[0]
    img = mpimg.imread(DATA / sample["image_path"])
    ax.imshow(img)
    ax.set_title(label, fontsize=10)
    ax.axis("off")

fig.suptitle("One Sample Per Class", fontsize=12)
fig.tight_layout()
fig.savefig("mini_contact_sheet.png", dpi=100, bbox_inches="tight")
plt.close(fig)
print("Mini contact sheet saved successfully!")
```

**Output:**
```text
Mini contact sheet saved successfully!
```
**Interpretation:**
- Produces a single-row image displaying an apple, a banana, and an orange side-by-side.
- This demonstrates the exact same logic as lines 63–74 on a smaller scale.

## Step-by-Step Student Instructions

1. **Open your terminal** and check `outputs/sample_snacks.png`.
2. **If `main.py` has been run**, verify the file exists:
   ```bash
   ls -lh outputs/sample_snacks.png
   ```
3. **Inspect the image**: Open `outputs/sample_snacks.png` in an image viewer or VS Code preview.
4. **Observe the layout**:
   - Row 0 contains 4 apple images (`apple_00.png` through `apple_03.png`).
   - Row 1 contains 4 banana images (`banana_00.png` through `banana_03.png`).
   - Row 2 contains 4 orange images (`orange_00.png` through `orange_03.png`).
5. **Notice the clean presentation**: No coordinate ticks, clean titles, and even margins.

## Expected Output or Observable Behaviour

The generated file `outputs/sample_snacks.png` is an $8 \times 6$ inch image at 150 DPI (approximately $1200 \times 900$ pixels) containing a grid of 12 fruit photos neatly organized by class row.

## Practical Exercises

- **Exercise 3.1**: How would you modify line 63 and line 65 to display 6 examples per fruit instead of 4?
- **Exercise 3.2**: Why is `ax.axis("off")` used when rendering photos, but not when rendering scatter plots?
- **Exercise 3.3**: What happens if you forget to call `plt.close(fig)` in a loop generating hundreds of plots?
- **Exercise 3.4**: Explain what `bbox_inches="tight"` does when saving a matplotlib figure.

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Forgetting `ax.axis("off")` | Default matplotlib axes display pixel coordinate ticks ($0$ to $64$), cluttering the image. | Always call `ax.axis("off")` on photo subplots. |
| Forgetting `plt.close(fig)` | Matplotlib retains open figure objects in memory, eventually triggering memory warnings or crashes. | Always call `plt.close(fig)` after `fig.savefig()`. |
| Hardcoding row indices without sorting | If classes are unsorted, different runs could put bananas on row 0 and apples on row 1. | Use `sorted(df["label"].unique())` for deterministic ordering. |

## Best Practices and Security Considerations

- **Headless Backend**: Always set `matplotlib.use("Agg")` before importing `pyplot` so figures can be generated on remote servers without display monitors.
- **Safe Resolution**: Using `dpi=150` balances sharp image clarity with compact file size (~100–300 KB).
- **Automated Sanity Testing**: Incorporate contact sheet generation into automated data validation pipelines to spot corrupt data before training.

## Summary

Visualizing training examples via a contact sheet is an indispensable quality assurance step in computer vision. In The Snack Sorter, lines 63–74 of `main.py` create a 3x4 subplot grid using matplotlib. By iterating over the sorted classes and selecting 4 samples per fruit, the script loads PNG files with `mpimg.imread()` and displays them on individual axes with `ax.imshow()`. Calling `ax.axis("off")` removes distracting pixel coordinate rulers, and `fig.savefig()` writes `sample_snacks.png` to disk.

## Knowledge-check Questions

1. What is the dimensions (rows and columns) of the grid created by `plt.subplots(3, 4)` in `main.py`?
2. What does `ax.axis("off")` do to a subplot?
3. What is the role of `mpimg.imread()` in line 68?
4. Why is `sorted(df["label"].unique())` used to determine the order of rows?
5. Why is `plt.close(fig)` called immediately after saving the plot?

## References

- Matplotlib subplots Guide: https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.subplots.html
- Matplotlib imshow Reference: https://matplotlib.org/stable/api/_as_gen/matplotlib.axes.Axes.imshow.html
- The Snack Sorter source code: `main.py` lines 63–74.
