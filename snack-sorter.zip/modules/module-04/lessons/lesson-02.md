# Lesson 02: Generating Test Predictions with `model.predict()`

**Lesson ID:** lesson-02
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Generate predictions for unseen test instances using `model.predict()`.
- Explain how `model.predict()` applies the pipeline's learned transformation before executing KNN inference.
- Verify the shape and data type of the returned predictions array.
- Compare predicted labels against true labels (`y_test`) to verify model accuracy.
- Query predicted class probabilities using `model.predict_proba()`.

## Prerequisites

- Module 04, Lesson 01: Fitting the Pipeline: What Happens During Training.
- Familiarity with NumPy arrays and scikit-learn estimator methods.

## Concept Explanation

### The Role of Inference
Once a model is trained, its purpose is **inference**—generating predictions for new, unseen data. In scikit-learn, this is performed by calling `.predict()`.

In `main.py`, line 50 generates predictions for all 23 test images:
```python
predictions = model.predict(X_test)
```

### What Happens During `model.predict(X_test)`?
When `X_test` (shape: `(23, 5)`) enters the pipeline:
1. **Automated Transformation**:
   - The pipeline passes `X_test` into Step 1 (`StandardScaler`).
   - The scaler transforms each test feature using the **training statistics** ($\mu_{\text{train}}$ and $\sigma_{\text{train}}$) learned during `fit()`:
     $$X_{\text{test\_scaled}} = \frac{X_{\text{test}} - \mu_{\text{train}}}{\sigma_{\text{train}}}$$
   - The scaler does **not** recalculate means or variances on the test set.
2. **Nearest Neighbor Search**:
   - The scaled test matrix $X_{\text{test\_scaled}}$ enters Step 2 (`KNeighborsClassifier`).
   - For each of the 23 test points, KNN searches its internal spatial index to find the 5 closest training points.
3. **Majority Voting**:
   - KNN tallies the class labels of those 5 closest neighbors.
   - The most common class label is assigned as the prediction.
4. **Return Output**:
   - A 1D NumPy array of string labels with shape `(23,)` is returned.

### Comparing Predictions to Ground Truth
To see how well the model performed, we can compare the predicted array against the ground-truth array `y_test.values`:
- If sample 0 has true label `"apple"` and prediction `"apple"`, it is a correct prediction.
- If sample 0 has true label `"apple"` and prediction `"orange"`, it is a misclassification.
In `The Snack Sorter`, all 23 predictions match the ground-truth labels perfectly!

### Confidence with `predict_proba()`
In addition to hard categorical predictions (`"apple"`), scikit-learn classifiers can output class probabilities:
```python
probs = model.predict_proba(X_test)
```
For KNN with $k=5$, probabilities represent the fraction of the 5 neighbors voting for each class:
- If all 5 neighbors are apples: probability of apple is $\frac{5}{5} = \mathbf{1.0}$ ($100\%$).
- If 4 neighbors are apples and 1 is orange: probability of apple is $\frac{4}{5} = \mathbf{0.8}$ ($80\%$).

## Relevant Code (from main.py, lines 50, 78)

```python
50:     predictions = model.predict(X_test)
...
78:     test_pred = model.predict(test_df[FEATURES])
```

### Code Explanation
- **Line 50**: Predicts labels for all 23 test images in one vectorized call, storing the results in `predictions`.
- **Line 78**: Predicts labels for the first 9 test images in `test_df` to display above each test image in the visual prediction grid.

## Worked Example

**Inspecting Test Predictions and Comparing with True Labels:**

```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier

df = pd.read_csv("data/snacks.csv")
features = ["mean_r", "mean_g", "mean_b", "color_fraction", "aspect_ratio"]
X = df[features]
y = df["label"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

model = Pipeline([
    ("scale", StandardScaler()),
    ("knn", KNeighborsClassifier(n_neighbors=5))
])
model.fit(X_train, y_train)

# Generate predictions
predictions = model.predict(X_test)

# Compare first 5 predictions against true labels
results = pd.DataFrame({
    "True Label": y_test.head(5).values,
    "Predicted": predictions[:5],
    "Match": y_test.head(5).values == predictions[:5]
})
print(results)
```

**Output:**
```text
  True Label Predicted  Match
0      apple     apple   True
1     banana    banana   True
2     orange    orange   True
3     banana    banana   True
4      apple     apple   True
```

**Interpretation:**
- Every single test sample evaluated matches its true ground-truth label!
- The array returned by `.predict()` is directly indexed and manipulated using standard NumPy/pandas syntax.

## Step-by-Step Student Instructions

1. **Open your terminal** and launch Python.
2. **Execute lines 35–50 from `main.py`** to train the model and generate `predictions`.
3. **Inspect the predictions array**:
   ```python
   print("Predictions array type:", type(predictions))
   print("Predictions shape:", predictions.shape)
   print("First 5 predictions:", predictions[:5])
   ```
4. **Inspect prediction probabilities**:
   ```python
   probabilities = model.predict_proba(X_test.head(3))
   print("Class order:", model.classes_)
   print("Probabilities:\n", probabilities)
   ```
5. Confirm that for all samples, the model is $100\%$ confident (`1.0`) in its predicted class.

## Expected Output or Observable Behaviour

Executing these commands outputs:
```text
Predictions array type: <class 'numpy.ndarray'>
Predictions shape: (23,)
First 5 predictions: ['apple' 'banana' 'orange' 'banana' 'apple']
Class order: ['apple' 'banana' 'orange']
Probabilities:
 [[1. 0. 0.]
  [0. 1. 0.]
  [0. 0. 1.]]
```
All 5 nearest neighbors in each query unanimously agreed on the correct fruit category!

## Practical Exercises

- **Exercise 2.1**: What is the data type and shape of the object returned by `model.predict(X_test)`?
- **Exercise 2.2**: If you pass a single row to `model.predict()`, why must it still be formatted as a 2D structure (e.g., `X_test.iloc[[0]]` or a DataFrame with 1 row)?
- **Exercise 2.3**: What would it mean if `model.predict_proba()` output `[0.6, 0.4, 0.0]` for a test sample? How many neighbors voted for apple and banana?
- **Exercise 2.4**: How can you calculate the total number of correct predictions using `(predictions == y_test).sum()`?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Passing a 1D list to `predict()`: `model.predict([175, 45, 44, 0.3, 0.8])` | Scikit-learn estimators expect 2D inputs of shape `(n_samples, n_features)`. Passing a 1D list raises a `ValueError: Expected 2D array, got 1D array instead`. | Wrap the list in an outer list or DataFrame: `model.predict([[175, 45, 44, 0.3, 0.8]])`. |
| Comparing predictions against `X_test` instead of `y_test` | `X_test` contains feature numbers; `y_test` contains true fruit labels. | Always compare predictions against ground-truth labels `y_test`. |
| Forgetting feature column names | If passing a DataFrame, columns must match the exact order and names used during `fit()`. | Ensure column names match `FEATURES`. |

## Best Practices and Security Considerations

- **Batch Predictions**: Call `.predict()` once on the entire batch `X_test` rather than looping over individual rows; vectorized execution is orders of magnitude faster.
- **Probabilistic Verification**: When deploying computer vision in production, check `predict_proba()`. If confidence is low (e.g., $<0.60$), route the image for human review or reject the prediction.
- **Input Validation**: Ensure production inputs have valid numerical ranges and no missing values before invoking `.predict()`.

## Summary

In scikit-learn, generating predictions on unseen data is performed using `model.predict()`. In The Snack Sorter, passing the 23 test instances `X_test` through the pipeline causes `StandardScaler` to automatically standardize the features using training parameters, after which `KNeighborsClassifier` identifies the 5 nearest neighbors and returns the majority vote. Calling `model.predict_proba()` reveals the neighbor vote breakdown, confirming 100% unanimous confidence across all test photos.

## Knowledge-check Questions

1. What method is called on a trained model to generate class predictions?
2. What are the shape and data type of `predictions` in `main.py`?
3. How does the pipeline ensure that test features are scaled using training statistics during `.predict()`?
4. What information is provided by `model.predict_proba()` that is not present in `.predict()`?
5. Why does scikit-learn require input to `.predict()` to be a 2-dimensional array even when predicting a single sample?

## References

- Scikit-learn KNeighborsClassifier.predict: https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.KNeighborsClassifier.html#sklearn.neighbors.KNeighborsClassifier.predict
- Scikit-learn KNeighborsClassifier.predict_proba: https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.KNeighborsClassifier.html#sklearn.neighbors.KNeighborsClassifier.predict_proba
- The Snack Sorter source code: `main.py` lines 50 and 78.
