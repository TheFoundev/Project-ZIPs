# Lesson 01: Fitting the Pipeline: What Happens During Training

**Lesson ID:** lesson-01
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain what happens under the hood when `model.fit(X_train, y_train)` is called on a Pipeline.
- Contrast the "training" phase of parametric algorithms (like Linear Regression) with instance-based algorithms (like KNN).
- Describe the data structures created by scikit-learn's `KNeighborsClassifier` to accelerate distance queries.
- Understand the scope of `X_train` (67 samples) and verify that test data remains isolated during fitting.
- Inspect the internal state of a fitted pipeline.

## Prerequisites

- Module 03, Lesson 03: Building Scikit-Learn Pipelines with `Pipeline`.
- Familiarity with arrays and vector spaces.

## Concept Explanation

### The Execution of `model.fit(X_train, y_train)`
In `main.py`, line 49 executes the entire training process:
```python
model.fit(X_train, y_train)
```
While this command appears as a single concise line of Python, a carefully choreographed sequence of operations occurs across the two pipeline stages:

#### Stage 1: The Transformer (`StandardScaler`)
1. Receives the raw 2D feature matrix `X_train` of shape `(67, 5)`.
2. Computes the empirical mean ($\mu$) for each of the 5 features across all 67 training photos and stores them in `scaler.mean_`.
3. Computes the empirical standard deviation ($\sigma$) and variance for each feature and stores them in `scaler.scale_` and `scaler.var_`.
4. Transforms `X_train` into standard z-scores:
   $$X_{\text{train\_scaled}} = \frac{X_{\text{train}} - \mu}{\sigma}$$
5. Passes the scaled matrix $X_{\text{train\_scaled}}$ directly into Stage 2.

#### Stage 2: The Classifier (`KNeighborsClassifier`)
1. Receives $X_{\text{train\_scaled}}$ alongside the target class vector `y_train` (67 strings: `apple`, `banana`, `orange`).
2. Stores the 67 scaled feature vectors and their corresponding labels.
3. Builds an efficient spatial indexing tree (such as a Ball Tree or KD Tree) in memory. This spatial data structure partitions the 5-dimensional space so that when a new query point arrives later, scikit-learn can locate its 5 nearest neighbors in logarithmic time $\mathcal{O}(\log N)$ rather than scanning every single point linearly.

### Parametric vs. Non-Parametric (Instance-Based) Training
In parametric models like Linear Regression or Logistic Regression, "training" means finding numerical weights (slopes $w$ and intercept $b$) that minimize an error function. Once those numbers are computed, the training data can be completely discarded from memory.

In contrast, K-Nearest Neighbors is an **instance-based (non-parametric) learner**:
- It does not calculate fixed mathematical equations.
- Training simply means organizing and memorizing the training instances in feature space.
- The training samples *are* the model!

### Verification of Training Isolation
Crucially, notice that `model.fit()` receives **only** `X_train` and `y_train`.
- `X_test` (the 23 test images) is completely absent from line 49.
- This ensures zero data leakage: the scaler knows nothing about test means, and the KNN spatial tree knows nothing about test coordinates.

## Relevant Code (from main.py, lines 43-49)

```python
43:     model = Pipeline(
44:         [
45:             ("scale", StandardScaler()),
46:             ("knn", KNeighborsClassifier(n_neighbors=5)),
47:         ]
48:     )
49:     model.fit(X_train, y_train)
```

### Code Explanation
- **Lines 43-48**: Creates the pipeline object encapsulating the scaler and the classifier.
- **Line 49**: Calls `.fit(X_train, y_train)` on the 67 training instances, fitting the scaling parameters and indexing the training feature vectors in memory.

## Worked Example

**Inspecting the Internal Attributes After Fitting:**

Let's execute `model.fit()` and inspect the learned attributes:

```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier

df = pd.read_csv("data/snacks.csv")
features = ["mean_r", "mean_g", "mean_b", "color_fraction", "aspect_ratio"]
X = df[features]
y = df["label"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

model = Pipeline([
    ("scale", StandardScaler()),
    ("knn", KNeighborsClassifier(n_neighbors=5))
])
model.fit(X_train, y_train)

# Inspect Scaler parameters
scaler = model.named_steps["scale"]
print("Learned Means (mu):", scaler.mean_.round(2))
print("Learned Scales (sigma):", scaler.scale_.round(2))

# Inspect KNN parameters
knn = model.named_steps["knn"]
print("Classes learned:", knn.classes_)
print("Number of samples stored:", knn.n_samples_fit_)
```

**Output:**
```text
Learned Means (mu): [210.84 117.89  37.66   0.29   0.93]
Learned Scales (sigma): [26.49 57.57  7.24   0.07   0.09]
Classes learned: ['apple' 'banana' 'orange']
Number of samples stored: 67
```

**Interpretation:**
- `scaler.mean_` and `scaler.scale_` capture the training statistics across the 5 features.
- `knn.classes_` stores the 3 unique categories in alphabetical order.
- `knn.n_samples_fit_` confirms that exactly 67 training images were memorized.

## Step-by-Step Student Instructions

1. **Open your terminal** and start Python.
2. **Replicate lines 35–49 of `main.py`**:
   ```python
   from pathlib import Path
   import pandas as pd
   from sklearn.model_selection import train_test_split
   from sklearn.pipeline import Pipeline
   from sklearn.preprocessing import StandardScaler
   from sklearn.neighbors import KNeighborsClassifier

   df = pd.read_csv("data/snacks.csv")
   features = ["mean_r", "mean_g", "mean_b", "color_fraction", "aspect_ratio"]
   X = df[features]
   y = df["label"]

   X_train, X_test, y_train, y_test, idx_train, idx_test = train_test_split(
       X, y, df.index, test_size=0.25, random_state=42, stratify=y
   )

   model = Pipeline([
       ("scale", StandardScaler()),
       ("knn", KNeighborsClassifier(n_neighbors=5))
   ])
   model.fit(X_train, y_train)
   ```
3. **Verify the fitted status**:
   ```python
   print("Is model fitted?", hasattr(model.named_steps["knn"], "n_samples_fit_"))
   ```
4. Confirm that `True` is printed, verifying successful fitting.

## Expected Output or Observable Behaviour

Executing this script runs silently and near-instantaneously (<0.05 seconds), creating a fully configured, trained pipeline ready for inference.

## Practical Exercises

- **Exercise 1.1**: What attributes in `StandardScaler` indicate that it has been fitted? (Hint: look for trailing underscores like `mean_`).
- **Exercise 1.2**: Why does training `KNeighborsClassifier` take fractions of a second compared to training a deep neural network?
- **Exercise 1.3**: What would happen if you called `model.fit(X_test, y_test)` instead of `model.fit(X_train, y_train)`?
- **Exercise 1.4**: How many training samples are stored in `knn.n_samples_fit_`?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Calling `fit()` on the entire dataset `X` | Leaks test set statistics into the model, invalidating evaluation integrity. | Only fit on `X_train, y_train`. |
| Trying to access `scaler.mean_` before calling `fit()` | Estimator attributes with trailing underscores (`mean_`, `classes_`) only exist after fitting. Calling them early raises `AttributeError`. | Always call `model.fit()` before inspecting learned parameters. |
| Passing 1D Series to `StandardScaler` directly | `StandardScaler` expects a 2D matrix of shape `(n_samples, n_features)`. | Ensure features are passed as a 2D DataFrame or 2D NumPy array. |

## Best Practices and Security Considerations

- **Strict Training Isolation**: Never expose test data to any `.fit()` call anywhere in your codebase.
- **Inspect Learned Parameters**: Checking `scaler.mean_` and `knn.classes_` is a great sanity check to verify that data ingestion matched expectations.
- **Fast Retraining**: Because KNN fitting is simply in-memory spatial indexing, it is well-suited for interactive environments and edge retraining.

## Summary

Calling `model.fit(X_train, y_train)` on the scikit-learn Pipeline executes a two-stage training workflow: `StandardScaler` computes the mean and standard deviation for each of the 5 features on the 67 training samples and standardizes the feature matrix into z-scores. Next, `KNeighborsClassifier` memorizes the 67 scaled feature vectors and builds a spatial index for rapid neighborhood queries. Test data remains completely isolated, preserving evaluation integrity.

## Knowledge-check Questions

1. What two distinct operations happen during `model.fit()` in the Snack Sorter pipeline?
2. What are the names of the scikit-learn attributes that store the fitted means and scales in `StandardScaler`?
3. How many training samples are memorized by the classifier during `model.fit(X_train, y_train)`?
4. Why is KNN considered a "lazy" or instance-based learner compared to linear regression?
5. What error occurs if you attempt to access `model.named_steps['knn'].classes_` before calling `fit()`?

## References

- Scikit-learn Estimator Fitting: https://scikit-learn.org/stable/developers/develop.html#fitting
- Scikit-learn Pipeline.fit: https://scikit-learn.org/stable/modules/generated/sklearn.pipeline.Pipeline.html#sklearn.pipeline.Pipeline.fit
- The Snack Sorter source code: `main.py` lines 43–49.
