# Lesson 04: Visualizing Predictions: True vs. Predicted Image Grid

**Lesson ID:** lesson-04
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain the importance of visualizing test set predictions alongside ground-truth labels.
- Use `axes.ravel()` and Python's `zip()` function to iterate over multi-dimensional subplots, DataFrame rows, and prediction arrays simultaneously.
- Construct a 3x3 subplot grid in matplotlib to display test image predictions.
- Format subplot titles with two lines: `"true: <label>\npredicted: <label>"`.
- Save the resulting prediction grid to `outputs/predictions.png`.

## Prerequisites

- Module 04, Lesson 02: Generating Test Predictions with `model.predict()`.
- Module 04, Lesson 03: Visualizing Training Data: Creating the Example Contact Sheet.
- Familiarity with Python's built-in `zip()` and NumPy array flattening.

## Concept Explanation

### Why Qualitative Evaluation Matters
While quantitative metrics (like accuracy = 100%) give an overall numerical summary of performance, **qualitative evaluation** (looking at actual test photos and their predicted labels) provides critical human verification. It allows us to:
1. Confirm that the model is genuinely classifying the intended subject (and not an artifact of the background).
2. Inspect borderline or ambiguous samples.
3. Present findings clearly to non-technical stakeholders who understand images far better than confusion matrices.

### Isolating Test Samples with Original Indices
In `main.py`, lines 77–78 isolate 9 test samples:
```python
test_df = df.loc[idx_test].head(9)
test_pred = model.predict(test_df[FEATURES])
```
- Recall from Module 02 that `train_test_split` returned `idx_test`, which stores the original DataFrame row indices of the test partition.
- `df.loc[idx_test]` retrieves the test rows, including their original `image_path` and `label` columns.
- `head(9)` selects the first 9 test photos to fit perfectly into a $3 \times 3$ grid.
- `test_pred` generates predictions for these 9 images by passing their feature values through the trained pipeline.

### The Power of `axes.ravel()` and `zip()`
Line 79 initializes the 3x3 grid:
```python
fig, axes = plt.subplots(3, 3, figsize=(7, 7))
```
Here, `axes` is a 2D NumPy array with shape `(3, 3)`. To loop through all 9 subplots sequentially without writing messy nested loops, line 80 uses `axes.ravel()`:
- `axes.ravel()` flattens the 2D array into a 1D sequence of 9 axes: `[ax0, ax1, ..., ax8]`.
- Then `zip(axes.ravel(), test_df.iterrows(), test_pred)` iterates through three parallel streams:
  1. `ax`: The current matplotlib subplot axis.
  2. `(_, row)`: The pandas DataFrame row containing the true label and `image_path`.
  3. `prediction`: The string predicted by the model for that image.

### Dynamic Annotation
Within the loop:
```python
ax.imshow(mpimg.imread(DATA / row["image_path"]))
ax.set_title(f"true: {row['label']}\npredicted: {prediction}", fontsize=9)
ax.axis("off")
```
Each subplot is labeled with both the ground truth and the prediction. If the model makes an error, the title clearly highlights the mismatch (e.g., `true: apple \n predicted: orange`).
When the model is 100% accurate, both lines show identical fruit names!

## Relevant Code (from main.py, lines 76-88)

```python
76:     # ---- Show a few test predictions ----------------------------------
77:     test_df = df.loc[idx_test].head(9)
78:     test_pred = model.predict(test_df[FEATURES])
79:     fig, axes = plt.subplots(3, 3, figsize=(7, 7))
80:     for ax, (_, row), prediction in zip(axes.ravel(), test_df.iterrows(), test_pred):
81:         ax.imshow(mpimg.imread(DATA / row["image_path"]))
82:         ax.set_title(f"true: {row['label']}\npredicted: {prediction}", fontsize=9)
83:         ax.axis("off")
84:     fig.suptitle("Test photos: true label vs. model prediction", fontsize=13)
85:     fig.tight_layout()
86:     fig.savefig(OUT / "predictions.png", dpi=150, bbox_inches="tight")
87:     plt.close(fig)
```

### Code Explanation
- **Line 77**: Slices the first 9 test rows using `df.loc[idx_test]`.
- **Line 78**: Generates predictions for these 9 samples.
- **Line 79**: Creates a $3 \times 3$ grid of subplots with a square $7 \times 7$ inch figure size.
- **Line 80**: Simultaneously iterates over axes, test samples, and predictions using `zip()` and `axes.ravel()`.
- **Lines 81-83**: Reads the image, displays it, sets the comparison title, and turns off axis ticks.
- **Lines 84-87**: Adds the suptitle, optimizes layout, writes to `outputs/predictions.png`, and frees memory with `plt.close(fig)`.

## Worked Example

**Simulating Prediction Inspection in Python:**

Let's inspect the exact values printed above the 9 test photos:

```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier

df = pd.read_csv("data/snacks.csv")
features = ["mean_r", "mean_g", "mean_b", "color_fraction", "aspect_ratio"]
X = df[features]
y = df["label"]

X_train, X_test, y_train, y_test, idx_train, idx_test = train_test_split(
    X, y, df.index, test_size=0.25, random_state=42, stratify=y
)

model = Pipeline([
    ("scale", StandardScaler()),
    ("knn", KNeighborsClassifier(n_neighbors=5))
])
model.fit(X_train, y_train)

test_df = df.loc[idx_test].head(9)
test_pred = model.predict(test_df[features])

for i, ((_, row), pred) in enumerate(zip(test_df.iterrows(), test_pred), 1):
    status = "CORRECT" if row["label"] == pred else "INCORRECT"
    print(f"Photo {i:2d} ({row['image_path']}): true={row['label']:6s} | pred={pred:6s} [{status}]")
```

**Output:**
```text
Photo  1 (images/banana_18.png): true=banana | pred=banana [CORRECT]
Photo  2 (images/orange_24.png): true=orange | pred=orange [CORRECT]
Photo  3 (images/apple_01.png ): true=apple  | pred=apple  [CORRECT]
Photo  4 (images/banana_02.png): true=banana | pred=banana [CORRECT]
Photo  5 (images/apple_12.png ): true=apple  | pred=apple  [CORRECT]
Photo  6 (images/orange_09.png): true=orange | pred=orange [CORRECT]
Photo  7 (images/banana_06.png): true=banana | pred=banana [CORRECT]
Photo  8 (images/orange_16.png): true=orange | pred=orange [CORRECT]
Photo  9 (images/apple_20.png ): true=apple  | pred=apple  [CORRECT]
```

**Interpretation:**
- Among the first 9 test photos, there are 3 bananas, 3 oranges, and 3 apples.
- Every single prediction is 100% correct, exactly matching the ground truth.

## Step-by-Step Student Instructions

1. **Verify that `outputs/predictions.png` exists** after running `main.py`:
   ```bash
   ls -lh outputs/predictions.png
   ```
2. **Open `outputs/predictions.png`** in your image viewer.
3. **Inspect the titles**:
   - Check the title of each cell: notice `true: ...` on line 1 and `predicted: ...` on line 2.
   - Confirm that the predicted label matches the true label for all 9 cells.
4. **Notice the visual diversity**: The photos in the test set represent different lighting, angles, and fruit positions, yet the classifier identified all of them correctly.

## Expected Output or Observable Behaviour

The file `outputs/predictions.png` is generated as a clean $7 \times 7$ inch image at 150 DPI displaying a 3x3 grid of fruit photos, each annotated with true versus predicted labels.

## Practical Exercises

- **Exercise 4.1**: What is the purpose of `axes.ravel()` in line 80 of `main.py`?
- **Exercise 4.2**: How would you change line 77 to display 16 test predictions in a 4x4 grid?
- **Exercise 4.3**: How could you modify line 82 to make the title text green if the prediction is correct and red if it is incorrect?
- **Exercise 4.4**: Why is qualitative prediction visualization considered an essential complement to numerical metrics like accuracy?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Forgetting `.ravel()` on 2D `axes` | Iterating directly over a 2D array yields 3 arrays of row axes rather than 9 individual axes, causing unpacking errors in `zip()`. | Use `axes.ravel()` or `axes.flatten()` to iterate sequentially. |
| Predicting on `test_df` instead of `test_df[FEATURES]` | `test_df` includes non-numeric metadata columns like `image_path` and `label`, which raises a `TypeError`. | Always pass `test_df[FEATURES]` to `model.predict()`. |
| Slicing `y_test.head(9)` instead of `df.loc[idx_test].head(9)` | `y_test` only contains the fruit names; it does not contain `image_path` needed to load images from disk. | Use `df.loc[idx_test]` to retain both labels and image paths. |

## Best Practices and Security Considerations

- **Error Highlighting**: When building visual diagnostic grids, consider coloring incorrect predictions in red to instantly draw human attention to model failures.
- **Representative Sampling**: Display samples from all classes rather than only the first few rows to ensure balanced qualitative inspection.
- **Resource Management**: In production web servers or notebooks, always call `plt.close(fig)` to avoid memory leaks.

## Summary

Visualizing model predictions against ground-truth labels is an essential practice for human validation of computer vision models. In The Snack Sorter, lines 76–88 extract the first 9 test instances using `df.loc[idx_test].head(9)`, generate predictions, and plot them in a $3 \times 3$ grid using `axes.ravel()` and `zip()`. Each image is displayed with its true and predicted labels, providing an immediate visual confirmation of the classifier's 100% accuracy on unseen test photos.

## Knowledge-check Questions

1. Why does `main.py` use `df.loc[idx_test]` to select test photos for visualization rather than `X_test`?
2. What does `axes.ravel()` do to the $3 \times 3$ `axes` array?
3. How does Python's `zip()` function simplify looping over axes, data rows, and predictions simultaneously?
4. What information is displayed in the title of each test subplot in `predictions.png`?
5. How many total test photos are displayed in the `predictions.png` grid?

## References

- Matplotlib Pyplot Tutorial: https://matplotlib.org/stable/tutorials/introductory/pyplot.html
- NumPy ravel Documentation: https://numpy.org/doc/stable/reference/generated/numpy.ravel.html
- The Snack Sorter source code: `main.py` lines 76–88.
