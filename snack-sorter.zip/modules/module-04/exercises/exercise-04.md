# Module 04 Exercises: Training, Inference & Visualization

---

## Exercise 4.1: Inspecting Fitted Pipeline Attributes

**Objective:** Access and verify internal learned parameters from both stages of a fitted scikit-learn Pipeline.

**Problem Statement:**
In `main.py`, the pipeline is trained via `model.fit(X_train, y_train)`. Write a Python script that trains the pipeline and extracts:
1. The 5 learned means (`mean_`) and 5 learned scales (`scale_`) from the `StandardScaler` step.
2. The classes array (`classes_`) and the number of samples fit (`n_samples_fit_`) from the `KNeighborsClassifier` step.

**Requirements:**
1. Replicate lines 35–49 of `main.py`.
2. Access the scaler via `model.named_steps["scale"]` and print its parameters.
3. Access the classifier via `model.named_steps["knn"]` and print its parameters.
4. Verify that `knn.n_samples_fit_ == 67`.
5. Verify that `knn.classes_` contains `["apple", "banana", "orange"]`.

**Constraints:**
- Must use `main.py`'s split parameters (`test_size=0.25, random_state=42, stratify=y`).

**Expected Behaviour:**
Console output displaying the learned scaling vectors and classifier parameters.

**Acceptance Criteria:**
- [ ] Correctly uses `model.named_steps`.
- [ ] Prints 5 feature means and 5 feature standard deviations.
- [ ] Confirms `n_samples_fit_` equals 67.
- [ ] Confirms 3 target classes in alphabetical order.

**Hints:**
- Attributes with trailing underscores (like `mean_`) are populated only after `.fit()` has executed.

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 4.2: Inference and Confidence Analysis with `predict_proba()`

**Objective:** Compute class prediction probabilities and evaluate model confidence on test instances.

**Problem Statement:**
While `model.predict(X_test)` returns discrete class labels, `model.predict_proba(X_test)` returns the fraction of the 5 nearest neighbors that voted for each class. Write a Python script that analyzes the confidence of the classifier across all 23 test images.

**Requirements:**
1. Generate probabilities for `X_test` using `model.predict_proba(X_test)`.
2. Determine the maximum probability for each test sample (`np.max(probs, axis=1)`).
3. Calculate how many test samples had 100% neighbor consensus (probability = 1.0).
4. Identify if any test sample had a split decision (e.g., probability = 0.8 or 0.6).

**Constraints:**
- Use the fitted model and test set from `main.py`.

**Expected Behaviour:**
A short analysis report displaying the distribution of prediction confidence across the 23 test photos.

**Acceptance Criteria:**
- [ ] Calls `predict_proba(X_test)` successfully.
- [ ] Computes max confidence per sample.
- [ ] Reports how many test photos achieved unanimous (5 out of 5) neighbor votes.
- [ ] Identifies any split votes if present.

**Hints:**
- For $k=5$, possible probabilities are $0.0, 0.2, 0.4, 0.6, 0.8, 1.0$.

**Difficulty:** Intermediate
**Estimated Completion Time:** 20 minutes

---

## Exercise 4.3: Customizing the Training Contact Sheet

**Objective:** Modify the contact sheet generation code to display 6 images per fruit in a 3x6 grid.

**Problem Statement:**
In `main.py`, lines 63–74 create an 8x6 inch figure showing 4 training examples per fruit. Write a script that expands this to display **6 training examples per fruit** across 3 rows and 6 columns.

**Requirements:**
1. Set up `plt.subplots(3, 6, figsize=(12, 6))`.
2. In the loop, slice `head(6)` samples for each fruit class.
3. Display each image with `ax.imshow()`, set the title, and call `ax.axis("off")`.
4. Add an overarching suptitle `"Expanded Training Contact Sheet (6 examples per snack)"`.
5. Save the output to `outputs/expanded_contact_sheet.png` and close the figure.

**Constraints:**
- Must pull photos dynamically from `DATA / sample["image_path"]`.

**Expected Behaviour:**
A newly generated PNG file `outputs/expanded_contact_sheet.png` containing 18 snack photos organized in a 3x6 grid.

**Acceptance Criteria:**
- [ ] Subplot grid has shape (3, 6).
- [ ] Each row contains 6 distinct examples of one fruit class.
- [ ] Subplots have axis ticks suppressed (`ax.axis("off")`).
- [ ] Image file is saved to disk with `dpi=150` and `bbox_inches="tight"`.
- [ ] Matplotlib figure is closed cleanly with `plt.close(fig)`.

**Hints:**
- Check that `outputs/` exists before saving.
- Remember to adjust `figsize` so images remain proportional.

**Difficulty:** Intermediate
**Estimated Completion Time:** 20 minutes

---

## Exercise 4.4: Error-Highlighted Prediction Grid

**Objective:** Build an annotated test prediction grid that dynamically highlights correct predictions in green and any potential misclassifications in red.

**Problem Statement:**
Create an enhanced visual prediction grid. Write a script that iterates through test predictions and colors the title text green if `true == predicted` and red if `true != predicted`.

**Requirements:**
1. Slice the first 9 test images using `test_df = df.loc[idx_test].head(9)`.
2. Generate predictions `test_pred = model.predict(test_df[FEATURES])`.
3. Create a 3x3 subplot grid (`figsize=(7, 7)`).
4. Iterate with `zip(axes.ravel(), test_df.iterrows(), test_pred)`.
5. If `row["label"] == prediction`, set title color to `"forestgreen"`. If not, set title color to `"crimson"`.
6. Save the output to `outputs/highlighted_predictions.png`.

**Constraints:**
- Use `ax.set_title(..., color=...)` to control title color dynamically.

**Expected Behaviour:**
A generated PNG `outputs/highlighted_predictions.png` where every title is rendered in crisp green text (since all 9 test photos are correct).

**Acceptance Criteria:**
- [ ] Loops over 9 test samples using `zip` and `axes.ravel()`.
- [ ] Includes dynamic conditional logic for title text color (`forestgreen` vs `crimson`).
- [ ] Renders photos and hides axis rulers.
- [ ] Saves file to `outputs/highlighted_predictions.png`.
- [ ] Closes figure cleanly.

**Hints:**
- Use `color="forestgreen"` inside `ax.set_title()`.

**Difficulty:** Advanced
**Estimated Completion Time:** 25 minutes
