# Lesson 03: Deep Dive: Why `stratify=y` Matters for Small, Balanced Datasets

**Lesson ID:** lesson-03
**Module:** module-06
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Deeply understand the statistical mechanics of **stratification** in data partitioning.
- Explain what happens when `stratify=y` is omitted from `train_test_split`.
- Simulate multiple random seeds to observe the distribution variance of unstratified splits on a 90-image dataset.
- Explain how class imbalances caused by unstratified splits can distort test accuracy, precision, and recall.
- State best practices for data partitioning across balanced, imbalanced, and multi-class machine learning tasks.

## Prerequisites

- Module 02, Lesson 04: Stratified Splitting with `train_test_split`.
- Basic understanding of probability and random sampling.

## Concept Explanation

### The Principle of Representative Sampling
When we evaluate a machine learning model, our fundamental assumption is that the **test set represents a miniature, unbiased replica of the real world**.
- In The Snack Sorter, the world consists of apples, bananas, and oranges in equal proportions ($1/3$ each).
- Therefore, our test set should contain apples, bananas, and oranges in that exact same $1/3$ proportion.

### How Simple Random Sampling Fails on Small Datasets
When you call `train_test_split(..., stratify=None)`:
- Scikit-learn treats all 90 rows as identical tokens in a lottery hopper.
- It randomly draws 23 rows without paying any attention to their class labels.
- In statistics, this is called **simple random sampling without replacement**.

With large datasets (e.g., 1,000,000 rows), the **Law of Large Numbers** guarantees that simple random sampling naturally reflects class proportions very closely.
However, with a small dataset (like 90 photos):
- Random sampling exhibits **high statistical variance**.
- By pure chance, you might draw 14 apples, 5 bananas, and only 4 oranges into the test set!
- Worse, the training set would now only have 16 apples, while having 25 bananas and 26 oranges!

### What Stratification Does
When you specify `stratify=y`:
1. Scikit-learn separates the dataset into separate "strata" (sub-groups) based on the target column `y`:
   - Strata 1: 30 apples
   - Strata 2: 30 bananas
   - Strata 3: 30 oranges
2. It then performs random sampling **independently within each stratum**:
   - Draws 25% of apples $\rightarrow$ 7 or 8 apples.
   - Draws 25% of bananas $\rightarrow$ 7 or 8 bananas.
   - Draws 25% of oranges $\rightarrow$ 7 or 8 oranges.
3. Finally, it combines the samples into the final `X_train`, `X_test`, `y_train`, and `y_test`.

This mathematical guarantee eliminates sampling luck and ensures both subsets have virtually identical class ratios.

### The Consequences of Omitting `stratify=y`
If an unstratified split leaves only 3 oranges in the test set:
- Each single orange test photo carries an enormous weight ($\frac{1}{3} \approx 33.3\%$ of the orange recall score!).
- A single ambiguous photo or noisy lighting condition can drop orange recall from $100\%$ down to $66.7\%$.
- Model evaluation becomes noisy, unstable, and dependent on the random seed rather than the true quality of the algorithm.

## Relevant Code (from main.py, lines 39-41)

```python
39:     X_train, X_test, y_train, y_test, idx_train, idx_test = train_test_split(
40:         X, y, df.index, test_size=0.25, random_state=42, stratify=y
41:     )
```

### Code Explanation
- **Line 40**: Passing `stratify=y` instructs `train_test_split` to divide the rows based on the class labels in `y`.
- Because $y$ contains equal counts of apples, bananas, and oranges, the test set of 23 photos is partitioned as evenly as integer rounding allows: 7 apples, 8 bananas, and 8 oranges.

## Worked Example

**Simulating Unstratified vs. Stratified Splits Across 5 Random Seeds:**

Let's test what happens if we remove `stratify=y` and run `train_test_split` across 5 different random seeds:

```python
import pandas as pd
from sklearn.model_selection import train_test_split

df = pd.read_csv("data/snacks.csv")
X = df[["mean_r", "mean_g", "mean_b", "color_fraction", "aspect_ratio"]]
y = df["label"]

print("--- UNSTRATIFIED SPLITS (stratify=None) ---")
for seed in [1, 10, 42, 99, 123]:
    _, _, _, y_test = train_test_split(X, y, test_size=0.25, random_state=seed, stratify=None)
    counts = dict(y_test.value_counts())
    print(f"Seed {seed:3d}: Apples={counts.get('apple', 0):2d}, Bananas={counts.get('banana', 0):2d}, Oranges={counts.get('orange', 0):2d}")

print("\n--- STRATIFIED SPLITS (stratify=y) ---")
for seed in [1, 10, 42, 99, 123]:
    _, _, _, y_test = train_test_split(X, y, test_size=0.25, random_state=seed, stratify=y)
    counts = dict(y_test.value_counts())
    print(f"Seed {seed:3d}: Apples={counts.get('apple', 0):2d}, Bananas={counts.get('banana', 0):2d}, Oranges={counts.get('orange', 0):2d}")
```

**Output:**
```text
--- UNSTRATIFIED SPLITS (stratify=None) ---
Seed   1: Apples= 7, Bananas=10, Oranges= 6
Seed  10: Apples= 9, Bananas= 8, Oranges= 6
Seed  42: Apples= 5, Bananas= 9, Oranges= 9
Seed  99: Apples=10, Bananas= 7, Oranges= 6
Seed 123: Apples= 6, Bananas=11, Oranges= 6

--- STRATIFIED SPLITS (stratify=y) ---
Seed   1: Apples= 8, Bananas= 7, Oranges= 8
Seed  10: Apples= 7, Bananas= 8, Oranges= 8
Seed  42: Apples= 7, Bananas= 8, Oranges= 8
Seed  99: Apples= 8, Bananas= 8, Oranges= 7
Seed 123: Apples= 8, Bananas= 7, Oranges= 8
```

**Interpretation:**
- In the unstratified splits, the counts fluctuate wildly: Seed 42 has only 5 apples, while Seed 99 has 10 apples! Seed 123 has 11 bananas and only 6 oranges!
- In the stratified splits, every single seed produces a rock-solid, balanced test set: exactly 7 or 8 samples per fruit, regardless of the random seed!

## Step-by-Step Student Instructions

1. **Open your terminal** and launch Python.
2. **Import necessary modules**:
   ```python
   import pandas as pd
   from sklearn.model_selection import train_test_split
   ```
3. **Run an unstratified split on `snacks.csv`**:
   ```python
   df = pd.read_csv("data/snacks.csv")
   _, _, _, y_test_unstrat = train_test_split(df, df["label"], test_size=0.25, random_state=42)
   print("Unstratified counts:\n", y_test_unstrat.value_counts())
   ```
4. **Run a stratified split**:
   ```python
   _, _, _, y_test_strat = train_test_split(df, df["label"], test_size=0.25, random_state=42, stratify=df["label"])
   print("Stratified counts:\n", y_test_strat.value_counts())
   ```
5. Compare the two outputs and observe how stratification stabilizes the class counts.

## Expected Output or Observable Behaviour

Executing this comparison shows that unstratified sampling produces an uneven split (5 apples, 9 bananas, 9 oranges), whereas stratified sampling produces the stable 7-8-8 distribution.

## Practical Exercises

- **Exercise 3.1**: What happens if you try to pass `stratify=y` when one class has only 1 sample in the entire dataset? (Research scikit-learn's error message for single-sample classes).
- **Exercise 3.2**: Under what circumstances is `stratify` NOT used in train/test splits? (Hint: Think about time series data).
- **Exercise 3.3**: Why does the Law of Large Numbers reduce the need for stratification on datasets with 10,000,000 rows?
- **Exercise 3.4**: In The Snack Sorter, why does `main.py` pass `stratify=y` instead of `stratify=X`?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Omitting `stratify=y` in classification tasks | Creates random variations in class distribution across train and test sets, skewing evaluation. | Always pass `stratify=y` for classification problems. |
| Passing continuous regression targets to `stratify` | Stratification requires discrete categorical bins; continuous floats raise `ValueError: The least populated class in y has only 1 member`. | Only stratify on categorical classification targets. |
| Using stratification on time-series forecasting | Splitting time series data with random stratification leaks future data into the past. | Use `TimeSeriesSplit` or chronological splits for time-series. |

## Best Practices and Security Considerations

- **Default to Stratified Splits for Classification**: Unless working with temporal or grouped data, always set `stratify=y` in classification workflows.
- **Stratified K-Fold Cross-Validation**: When performing cross-validation, use `StratifiedKFold` rather than standard `KFold` for the exact same reason.
- **Check Minimum Class Support**: Verify that every class has at least 2 samples before attempting a stratified split.

## Summary

Stratification ensures that subsets of data created during train/test partitioning retain the exact class proportions of the overall dataset. In small datasets like The Snack Sorter (90 images total), simple random sampling without stratification causes high variance, resulting in test sets where some classes are over-represented and others are scarce. By specifying `stratify=y` in line 40 of `main.py`, the 23 test images are guaranteed to be balanced (7 apples, 8 bananas, 8 oranges), providing stable, reproducible evaluation metrics.

## Knowledge-check Questions

1. What does the parameter `stratify=y` do during a train/test split?
2. What risk occurs when omitting `stratify=y` on small datasets of 90 samples?
3. How many apples, bananas, and oranges are in the test set when `random_state=42` is used with `stratify=y`?
4. How did the unstratified split with `random_state=42` behave in the worked example?
5. Why is stratification generally inappropriate for time-series forecasting?

## References

- Scikit-learn Stratified Splitting Guide: https://scikit-learn.org/stable/modules/cross_validation.html#stratification
- Scikit-learn train_test_split Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html
- The Snack Sorter source code: `main.py` lines 39–41.
