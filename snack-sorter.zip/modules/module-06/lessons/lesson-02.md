# Lesson 02: Inspecting and Correlating All Output Artifacts

**Lesson ID:** lesson-02
**Module:** module-06
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Locate, inspect, and verify all 4 output files generated in `outputs/`.
- Correlate information across the 3 visual images (`sample_snacks.png`, `predictions.png`, `confusion_matrix.png`) and the text record (`metrics.txt`).
- Explain how `main.py` uses looping to announce saved file paths cleanly.
- Verify file sizes, image resolutions, and formats using standard command-line tools.
- Assess the completeness of a machine learning experiment artifact package.

## Prerequisites

- Module 06, Lesson 01: Running `main.py` End-to-End.
- Familiarity with file navigation and image previewers.

## Concept Explanation

### The Artifact Package Philosophy
In professional AI and machine learning engineering, an algorithm's output is not complete until it leaves behind a verifiable, self-documenting trail of **artifacts**. A complete artifact package should provide answers to four core engineering questions:
1. *What did the training data look like?* $\rightarrow$ Answered by `sample_snacks.png`.
2. *How did the model perform on individual test examples?* $\rightarrow$ Answered by `predictions.png`.
3. *What specific mistakes did the model make (and what was the class-by-class confusion)?* $\rightarrow$ Answered by `confusion_matrix.png`.
4. *What are the precise numeric performance scores for automated testing and auditing?* $\rightarrow$ Answered by `metrics.txt`.

### Dissecting the 4 Artifacts in `outputs/`

```text
outputs/
├── sample_snacks.png      (~260 KB, 1200x900 px)
├── predictions.png        (~190 KB, 1050x1050 px)
├── confusion_matrix.png   (~40 KB, 825x675 px)
└── metrics.txt            (~440 bytes, 11 lines)
```

#### 1. `sample_snacks.png` (Training Contact Sheet)
- **Role**: Establishes ground-truth visual context.
- **Layout**: 3 rows $\times$ 4 columns.
- **Content**: 4 sample training photos each for `apple` (row 0), `banana` (row 1), and `orange` (row 2).
- **Inspection Check**: Confirm that all photos are crisp, properly oriented, and correctly labeled with their fruit class.

#### 2. `predictions.png` (Visual Inference Grid)
- **Role**: Qualitative evaluation on unseen test data.
- **Layout**: 3 rows $\times$ 3 columns.
- **Content**: 9 test photos sliced from `df.loc[idx_test].head(9)`.
- **Inspection Check**: Notice the dual-line header above each photo: `true: <label>\npredicted: <label>`. In our project, every single cell displays identical true and predicted labels.

#### 3. `confusion_matrix.png` (Diagnostic Heatmap)
- **Role**: High-level statistical visualization of class confusion.
- **Layout**: 3 rows (True) $\times$ 3 columns (Predicted) with a green colormap (`cmap="Greens"`).
- **Content**: The numbers `7`, `8`, and `8` along the diagonal, with `0` in all 6 off-diagonal cells.
- **Inspection Check**: The dark diagonal confirms zero cross-class confusion.

#### 4. `metrics.txt` (Numerical Audit Log)
- **Role**: Machine-readable and human-readable text record.
- **Content**:
  - `accuracy: 1.0000`
  - Complete classification report with 1.00 precision, recall, and F1-score across all 3 classes, and total support of 23.
- **Inspection Check**: The numbers match the confusion matrix totals ($7 + 8 + 8 = 23$).

### Announcing Saved Files in `main.py`
In lines 104–106:
```python
print("\nSaved:")
for name in ("sample_snacks.png", "predictions.png", "confusion_matrix.png", "metrics.txt"):
    print(f"  outputs/{name}")
```
By iterating over a tuple of filenames, `main.py` provides immediate visual feedback in the terminal confirming that each asset was generated and saved to its expected destination.

## Relevant Code (from main.py, lines 104-106)

```python
104:     print("\nSaved:")
105:     for name in ("sample_snacks.png", "predictions.png", "confusion_matrix.png", "metrics.txt"):
106:         print(f"  outputs/{name}")
```

### Code Explanation
- **Line 104**: Prints the section header `Saved:`.
- **Line 105**: Iterates through the four artifact filenames stored in a Python tuple.
- **Line 106**: Prints each relative file path indented by two spaces (`  outputs/<name>`).

## Worked Example

**Verifying All Output Artifacts via Command Line:**

Let's run a bash command to verify the presence, sizes, and permissions of all 4 artifacts:
```bash
ls -lh outputs/
```

**Output:**
```text
total 496K
-rw-r--r-- 1 aziz aziz  41K Oct 27 19:01 confusion_matrix.png
-rw-r--r-- 1 aziz aziz  438 Oct 27 19:01 metrics.txt
-rw-r--r-- 1 aziz aziz 188K Oct 27 19:01 predictions.png
-rw-r--r-- 1 aziz aziz 262K Oct 27 19:01 sample_snacks.png
```

**Checking Image Properties with ImageMagick (`file` or `identify`):**
```bash
file outputs/*.png
```
**Output:**
```text
outputs/confusion_matrix.png: PNG image data, 825 x 675, 8-bit/color RGBA, non-interlaced
outputs/predictions.png:      PNG image data, 1050 x 1050, 8-bit/color RGBA, non-interlaced
outputs/sample_snacks.png:    PNG image data, 1200 x 900, 8-bit/color RGBA, non-interlaced
```

**Interpretation:**
- All 3 images are valid 8-bit RGBA PNG files rendered at 150 DPI.
- `predictions.png` is perfectly square ($1050 \times 1050$), matching `figsize=(7, 7)`.
- `sample_snacks.png` is $1200 \times 900$, matching `figsize=(8, 6)`.
- `metrics.txt` is cleanly written as 438 bytes.

## Step-by-Step Student Instructions

1. **Open your terminal** in the project root.
2. **List all outputs**:
   ```bash
   ls -la outputs/
   ```
3. **Verify the 4 expected filenames exist**:
   - `sample_snacks.png`
   - `predictions.png`
   - `confusion_matrix.png`
   - `metrics.txt`
4. **Open `sample_snacks.png`** and verify there are 12 fruit photos.
5. **Open `predictions.png`** and verify there are 9 test photos with titles.
6. **Open `confusion_matrix.png`** and observe the green diagonal cells.
7. **Read `metrics.txt`** and verify the 1.0000 accuracy.

## Expected Output or Observable Behaviour

All four files exist with non-zero byte sizes, valid image headers, and matching numerical metrics that corroborate one another.

## Practical Exercises

- **Exercise 2.1**: Which output artifact provides evidence of the model's performance on individual test images?
- **Exercise 2.2**: If you delete the `outputs/` folder and run `main.py`, what happens? Does `main.py` crash or recreate the directory?
- **Exercise 2.3**: What is the aspect ratio of the figure in `sample_snacks.png` compared to `predictions.png`?
- **Exercise 2.4**: Why is having both a confusion matrix plot and a text metrics file better than having only one or the other?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Checking for outputs in the parent directory | Artifacts are saved inside the `outputs/` subdirectory relative to `main.py`. | Look inside `<project_root>/outputs/`. |
| Assuming empty files mean success | If a script crashes midway, an output file may be created with 0 bytes. | Always check file size with `ls -lh` to ensure complete generation. |
| Overlooking the relationship between artifacts | Failing to realize that numbers in `metrics.txt` correspond directly to cells in `confusion_matrix.png`. | Correlate the metrics: 7 apples in `metrics.txt` support is cell (0,0) in `confusion_matrix.png`. |

## Best Practices and Security Considerations

- **Artifact Organization**: Always keep generated artifacts separated from raw source code and raw data by storing them in a dedicated `outputs/` or `artifacts/` folder.
- **Git Ignore Large Artifacts**: If working with large binary outputs (like multi-gigabyte models or thousands of images), add `outputs/*.png` to `.gitignore` while keeping lightweight logs like `metrics.txt`.
- **Consistent File Naming**: Use descriptive, lowercase filenames separated by underscores for maximum cross-platform compatibility.

## Summary

The Snack Sorter produces a cohesive 4-part artifact package in `outputs/`: `sample_snacks.png` (a 3x4 contact sheet of training images), `predictions.png` (a 3x3 grid of annotated test predictions), `confusion_matrix.png` (a green heatmap of classification counts), and `metrics.txt` (a text audit log of accuracy and per-class reports). Each artifact serves a distinct diagnostic role, together confirming the system's 100% test accuracy.

## Knowledge-check Questions

1. What are the four files saved in the `outputs/` directory?
2. How many subplots are contained in `sample_snacks.png` versus `predictions.png`?
3. What information is recorded in `metrics.txt`?
4. How do the numbers in `confusion_matrix.png` correspond to the support column in `metrics.txt`?
5. What line of code in `main.py` guarantees that the `outputs/` directory exists before saving files?

## References

- Matplotlib Figure Saving Documentation: https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.savefig.html
- Linux File Verification Utilities: https://man7.org/linux/man-pages/man1/file.1.html
- The Snack Sorter source code: `main.py` lines 104–106.
