# Lesson 01: Running `main.py` End-to-End

**Lesson ID:** lesson-01
**Module:** module-06
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Execute `main.py` from the command line and monitor its complete execution flow.
- Explain the role of the Python `if __name__ == "__main__":` entrypoint idiom.
- Interpret the sequential terminal output generated during the script run.
- Identify how functions, paths, and external libraries interact during a single command invocation.
- Measure execution speed and resource consumption of the end-to-end pipeline.

## Prerequisites

- Modules 01 through 05.
- Familiarity with the terminal or command line shell.

## Concept Explanation

### The Entrypoint Idiom: `if __name__ == "__main__":`
In Python, every source file has a special built-in variable called `__name__`:
- When a script is executed directly from the terminal (e.g., `python3 main.py`), Python assigns `__name__ = "__main__"`.
- When a file is imported as a module into another script (e.g., `import main`), Python sets `__name__ = "main"`.

In `main.py`, lines 110–111 use this idiom:
```python
if __name__ == "__main__":
    main()
```
This is a software engineering best practice. It ensures that running `python3 main.py` triggers the `main()` function, while simultaneously allowing other programs or automated test suites to import components from `main.py` without accidentally running the entire script!

### The End-to-End Lifecycle of `main.py`
When you execute `python3 main.py`, the following sequence takes place in under 2 seconds:
1. **Module Imports**: Matplotlib sets headless `"Agg"` backend; NumPy, pandas, and scikit-learn modules are loaded into memory.
2. **Filesystem Setup**: `BASE`, `DATA`, and `OUT` directories are resolved; `outputs/` is verified or created.
3. **Data Loading**: `snacks.csv` is read into memory (90 rows, 7 columns).
4. **Feature & Target Slicing**: $X$ (5 columns) and $y$ (fruit labels) are isolated.
5. **Stratified Splitting**: 67 images are assigned to training, 23 to testing (`random_state=42`, `stratify=y`).
6. **Pipeline Training**: `StandardScaler` standardizes features; `KNeighborsClassifier(n_neighbors=5)` memorizes training samples.
7. **Inference & Metrics**: Predictions are generated for $X_{\text{test}}$; accuracy and classification report are computed and printed.
8. **Contact Sheet Creation**: A 3x4 grid of example training photos is saved to `outputs/sample_snacks.png`.
9. **Prediction Grid Creation**: A 3x3 grid of annotated test photos is saved to `outputs/predictions.png`.
10. **Confusion Matrix Generation**: A 3x3 green heatmap is saved to `outputs/confusion_matrix.png`.
11. **Text Summary Logging**: Accuracy and the classification report are written to `outputs/metrics.txt`.
12. **Final Completion Message**: The terminal lists all saved files and presents the extension challenge.

### Reading the Terminal Output Stream
The console output is structured into clear, readable sections:
```text
============================================================
THE SNACK SORTER
============================================================
Training photos: 67
Test photos:     23
Accuracy:        100.0%

Classification report:

              precision    recall  f1-score   support

       apple       1.00      1.00      1.00         7
      banana       1.00      1.00      1.00         8
      orange       1.00      1.00      1.00         8

    accuracy                           1.00        23
   macro avg       1.00      1.00      1.00        23
weighted avg       1.00      1.00      1.00        23


Saved:
  outputs/sample_snacks.png
  outputs/predictions.png
  outputs/confusion_matrix.png
  outputs/metrics.txt

Try this: add a fourth snack photo class and rerun the script.
```

## Relevant Code (from main.py, lines 53-61, 104-111)

```python
53:     print("=" * 60)
54:     print("THE SNACK SORTER")
55:     print("=" * 60)
56:     print(f"Training photos: {len(X_train)}")
57:     print(f"Test photos:     {len(X_test)}")
58:     print(f"Accuracy:        {accuracy:.1%}")
59:     print("\nClassification report:\n")
60:     print(classification_report(y_test, predictions, zero_division=0))
...
104:     print("\nSaved:")
105:     for name in ("sample_snacks.png", "predictions.png", "confusion_matrix.png", "metrics.txt"):
106:         print(f"  outputs/{name}")
107:     print("\nTry this: add a fourth snack photo class and rerun the script.")
...
110: if __name__ == "__main__":
111:     main()
```

### Code Explanation
- **Lines 53-58**: Prints the project header, partition counts, and test accuracy percentage.
- **Lines 59-60**: Prints the scikit-learn classification report.
- **Lines 104-106**: Loops over a tuple of artifact filenames and prints confirmation that each has been saved.
- **Line 107**: Challenges the user to extend the codebase with a 4th snack class.
- **Lines 110-111**: Standard Python script execution entrypoint.

## Worked Example

**Timing the Complete Execution in Bash:**

We can use Linux's built-in `time` command to measure real-world performance:
```bash
time python3 main.py
```

**Output:**
```text
============================================================
THE SNACK SORTER
============================================================
Training photos: 67
Test photos:     23
Accuracy:        100.0%
...
Saved:
  outputs/sample_snacks.png
  outputs/predictions.png
  outputs/confusion_matrix.png
  outputs/metrics.txt

real    0m1.482s
user    0m1.231s
sys     0m0.184s
```

**Interpretation:**
- The entire workflow—including importing massive libraries (pandas, matplotlib, scikit-learn), training the model, decoding 21 PNG images, rendering 3 matplotlib figures, and saving 4 files—executes in approximately **1.48 seconds** on standard hardware!
- This lightning-fast performance highlights the massive efficiency advantage of hand-crafted feature extraction and classical KNN over multi-gigabyte deep neural networks.

## Step-by-Step Student Instructions

1. **Open your terminal** and navigate to the project directory:
   ```bash
   cd "beginner-projects-main/AI-ML Beginners/projects/01_snack_sorter"
   ```
2. **Execute `main.py` directly**:
   ```bash
   python3 main.py
   ```
3. **Follow the printed flow**:
   - Verify the header banner.
   - Note the photo counts: 67 training, 23 testing.
   - Verify that accuracy is 100.0%.
   - Verify that the four saved artifact lines appear at the bottom.
4. **Check the exit code** to ensure clean termination:
   ```bash
   echo $?
   # Output: 0 (indicating success)
   ```

## Expected Output or Observable Behaviour

The script runs smoothly without any errors or deprecation warnings, generating the formatted terminal banner, performance table, and confirmation lines within 1–2 seconds.

## Practical Exercises

- **Exercise 1.1**: What happens if you import `main` in Python (`import main`) without running it directly? Does `main()` execute automatically?
- **Exercise 1.2**: How would you redirect the console output of `main.py` into a log file named `run.log`? (Hint: use terminal redirection `>`).
- **Exercise 1.3**: What is the exit status code of a successfully completed Linux process?
- **Exercise 1.4**: How much total time does `main.py` take to execute on your machine?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Running `main.py` with `python` instead of `python3` on systems where `python` defaults to Python 2 | Causes syntax errors on modern type annotations like `def main() -> None:`. | Always invoke with `python3 main.py`. |
| Modifying code inside `main.py` without saving before running | Terminal executes the file as saved on disk, not unsaved editor buffers. | Save all changes before running in terminal. |
| Running from the wrong directory | If run from another directory, older scripts might fail to find `data/`. In `main.py`, `BASE = Path(__file__).resolve().parent` protects against this. | Always check your current working directory with `pwd`. |

## Best Practices and Security Considerations

- **Always Guard with `if __name__ == "__main__":`**: Enables code modularity and automated testing without unintended execution.
- **Deterministic Script Outputs**: Keep terminal printouts clean, informative, and free of debug statements.
- **Resource Cleanup**: Ensure all figures and files are properly closed so background processes don't consume unnecessary system memory.

## Summary

Executing `main.py` end-to-end runs the complete Snack Sorter computer vision workflow. Guided by the standard `if __name__ == "__main__":` entrypoint, the script loads tabular and image data, partitions 90 photos into stratified training and testing sets, trains a standardized K-Nearest Neighbors pipeline, evaluates performance, and outputs both terminal metrics and persistent file artifacts in less than two seconds.

## Knowledge-check Questions

1. What is the purpose of the `if __name__ == "__main__":` statement in Python scripts?
2. What three numbers are displayed in the initial terminal summary banner of `main.py`?
3. How long does `main.py` typically take to execute from start to finish?
4. What list of four files is printed under the `Saved:` section of the console output?
5. What type annotation is used for the `main()` function header in line 34?

## References

- Python __main__ Special Variable: https://docs.python.org/3/library/__main__.html
- Python PEP 8 Style Guide on Script Structure: https://peps.python.org/pep-0008/
- The Snack Sorter source code: `main.py` lines 53–61, 104–111.
