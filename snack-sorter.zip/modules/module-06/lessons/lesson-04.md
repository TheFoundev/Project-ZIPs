# Lesson 04: Extending the Pipeline: Adding a Fourth Snack Class

## Purpose and Learning Objectives
In the preceding lessons, you analyzed, executed, and evaluated the Snack Sorter pipeline configured for three fruit classes: **apple**, **banana**, and **orange**. In production machine learning, systems rarely remain static. As retail inventories expand or automated sorting facilities introduce new product lines, ML engineers must seamlessly extend existing classification pipelines to accommodate novel categories.

By the end of this lesson, you will be able to:
1. Formulate a structured engineering workflow for introducing a fourth snack class into an established tabular-image pipeline.
2. Evaluate feature separability and potential class collision risks prior to model retraining.
3. Quantify how class additions impact sample balance, stratified splitting, and the multi-class confusion matrix topology.
4. Implement data collection, feature extraction, and retraining procedures to produce an updated 4-class `KNeighborsClassifier` model.
5. Contrast how non-parametric instance-based classifiers (KNN) adapt to multi-class scaling compared to parametric linear classifiers.

---

## Prerequisites
Before starting this lesson, you should be familiar with:
- The 5 handcrafted visual features defined in `snacks.csv` (`mean_r`, `mean_g`, `mean_b`, `color_fraction`, `aspect_ratio`) covered in [Module 03 Lesson 01](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Snack%20Sorter/snack-sorter/modules/module-03/lessons/lesson-01.md).
- Scikit-learn's `Pipeline` combining `StandardScaler` and `KNeighborsClassifier(n_neighbors=3)` from [Module 03 Lesson 03](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Snack%20Sorter/snack-sorter/modules/module-03/lessons/lesson-03.md).
- Evaluating multi-class models using precision, recall, and $K \times K$ confusion matrices from [Module 05 Lesson 02](file:///home/aziz/foundev/Foundev-main/Beginner%20projects%20modules%20and%20assessments/projects/AI-ML/Snack%20Sorter/snack-sorter/modules/module-05/lessons/lesson-02.md).

---

## Concept Explanation

### The Anatomy of Model Extensibility
Adding a new class to an existing machine learning pipeline is not merely a matter of appending rows to a CSV file. It involves verifying whether the current feature representation contains sufficient discriminative signal to separate the new class from all pre-existing classes.

```
Existing Feature Space (3 Classes):
  [Apple: Red dominance, low Green]
  [Banana: Yellow dominance, high Green + Red, elongated]
  [Orange: Orange dominance, moderate Green, spherical]

Introducing Class 4 (e.g., Pear or Blueberry):
  - Will the 5 existing features separate Class 4?
  - Does the color or shape profile overlap with existing clusters?
  - Do we need additional features (e.g., texture, perimeter roughness)?
```

### Case Study: Adding "Pear" as Class 4
Consider introducing green pears into the snack inventory:
1. **Color Profile**: Pears exhibit dominant green pigmentation. In RGB color space:
   - High `mean_g` ($\sim 180 - 205$)
   - Moderate `mean_r` ($\sim 120 - 150$)
   - Low `mean_b` ($\sim 40 - 65$)
2. **Shape Profile**: Pears have a characteristic teardrop silhouette:
   - `aspect_ratio` ($\sim 0.70 - 0.80$, narrower width compared to height)
3. **Collision Analysis**:
   - Contrast with **Banana**: Bananas also have high green values ($\sim 185.9$), but bananas have much higher red values ($\sim 222.0$) and higher aspect ratios ($\sim 0.98$).
   - Contrast with **Apple**: Apples have low green values ($\sim 45.5$) and dominant red ($\sim 175.3$).
   - Contrast with **Orange**: Oranges have lower green values ($\sim 123.6$) and high red values ($\sim 236.4$).

Because `mean_g` and `mean_r` in combination clearly delineate pears from the other three fruits, our 5-dimensional feature space is already expressive enough to support this 4th class without redesigning feature extractors.

```
   mean_r (Red)
       ^
   250 |        [Orange] (236, 124)       [Banana] (222, 186)
   200 |    [Apple] (175, 45)
   150 |                                  [Pear] (135, 195)  <-- New Class 4
   100 |
    50 |
     0 +----------------------------------------------------> mean_g (Green)
       0        50        100       150       200       250
```

### Why KNN Scales Naturally to $K > 3$ Classes
Parametric linear classifiers like Logistic Regression or Linear Support Vector Machines natively solve binary classification. To handle $K$ classes, they require either:
- **One-vs-Rest (OvR)**: Fitting $K$ distinct binary models ($K=4$).
- **One-vs-One (OvO)**: Fitting $\frac{K(K-1)}{2}$ binary models ($\frac{4 \times 3}{2} = 6$).

In contrast, **$K$-Nearest Neighbors is inherently multi-class**. KNN constructs no explicit parametric decision boundary equations during fitting. Instead, it stores all normalized training exemplars:
$$\mathcal{D}_{\text{train}} = \{(\mathbf{x}_i, y_i)\}_{i=1}^{N_{\text{train}}}$$
When a query point $\mathbf{x}_q$ arrives, KNN computes Euclidean distances to all points, finds the $k$ closest neighbors, and tallies class votes regardless of whether there are 2, 3, 4, or 100 candidate classes.

### Preserving Balance: The 30-Sample Standard
In `snacks.csv`, the original dataset maintains balanced classes:
- Apple: 30 images
- Banana: 30 images
- Orange: 30 images
Total: 90 images.

When adding the 4th class, maintaining class balance requires collecting exactly 30 images of the new snack (e.g., `data/pear_01.png` through `data/pear_30.png`). This expands the dataset to $N = 120$ rows.
With a 75/25 stratified split (`test_size=0.25`):
- $120 \times 0.75 = 90$ training samples ($4 \times 22.5 \approx 22$ or $23$ per class)
- $120 \times 0.25 = 30$ test samples ($4 \times 7.5 \approx 7$ or $8$ per class)
- The resulting confusion matrix expands from $3 \times 3$ to $4 \times 4$.

---

## Relevant Code (from main.py, lines 53-61, 104-111)

In `main.py`, the core pipeline and model evaluation logic are defined generically:

```python
# Lines 53-61 of main.py: Generic scikit-learn Pipeline
model = Pipeline([
    ("scaler", StandardScaler()),
    ("knn", KNeighborsClassifier(n_neighbors=3))
])

model.fit(X_train, y_train)
y_pred = model.predict(X_test)
acc = accuracy_score(y_test, y_pred)
```

Because `Pipeline`, `StandardScaler`, and `KNeighborsClassifier` dynamically adapt to the dimensions and unique labels present in `y_train`, **no code changes inside `main.py` lines 53-61 are necessary**. The script automatically handles 4 classes provided `snacks.csv` contains the 4th class rows and the corresponding image files reside in `data/`.

---

## Worked Example

Let us construct an automated script, `add_fourth_class.py`, that programmatically:
1. Synthesizes 30 representative images for a fourth snack: `"pear"`.
2. Extracts the 5 handcrafted features for each new image.
3. Appends the new rows to `snacks.csv` (or an extended dataset `snacks_4class.csv`).
4. Re-executes the pipeline and displays the expanded $4 \times 4$ classification report.

```python
import numpy as np
import pandas as pd
from pathlib import Path
from PIL import Image
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report, confusion_matrix

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"

def extract_features(img_path):
    """Compute the 5 visual features from an image file."""
    img = Image.open(img_path).convert("RGB")
    arr = np.array(img, dtype=float)
    
    # 1-3. Mean color channels
    mean_r = float(np.mean(arr[:, :, 0]))
    mean_g = float(np.mean(arr[:, :, 1]))
    mean_b = float(np.mean(arr[:, :, 2]))
    
    # 4. Color fraction (dominance of primary channel)
    total = mean_r + mean_g + mean_b + 1e-6
    color_fraction = float(np.max([mean_r, mean_g, mean_b]) / total)
    
    # 5. Aspect ratio
    width, height = img.size
    aspect_ratio = float(width / height)
    
    return mean_r, mean_g, mean_b, color_fraction, aspect_ratio

# Synthesize 30 pear images if they don't exist
pear_records = []
for i in range(1, 31):
    img_name = f"pear_{i:02d}.png"
    img_path = DATA / img_name
    
    # Pear color: dominant green (R~135, G~195, B~50), aspect ratio ~0.78 (taller than wide)
    if not img_path.exists():
        # Create an 80x100 canvas (aspect ratio 0.8)
        pear_img = np.zeros((100, 80, 3), dtype=np.uint8)
        # Background light gray
        pear_img[:, :] = [240, 240, 240]
        # Draw pear body with noise
        noise_r = np.random.randint(-10, 10)
        noise_g = np.random.randint(-10, 10)
        noise_b = np.random.randint(-5, 5)
        pear_img[15:85, 15:65] = [
            np.clip(135 + noise_r, 0, 255),
            np.clip(195 + noise_g, 0, 255),
            np.clip(50 + noise_b, 0, 255)
        ]
        Image.fromarray(pear_img).save(img_path)
    
    # Extract features
    r, g, b, cf, ar = extract_features(img_path)
    pear_records.append({
        "image_path": str(img_path.relative_to(BASE)),
        "mean_r": round(r, 2),
        "mean_g": round(g, 2),
        "mean_b": round(b, 2),
        "color_fraction": round(cf, 4),
        "aspect_ratio": round(ar, 4),
        "label": "pear"
    })

# Load original 3-class dataset and append
df_orig = pd.read_csv(DATA / "snacks.csv")
df_pear = pd.DataFrame(pear_records)
df_4class = pd.concat([df_orig, df_pear], ignore_index=True)

print(f"Original dataset rows: {len(df_orig)}")
print(f"Updated 4-class dataset rows: {len(df_4class)}")
print(df_4class['label'].value_counts())
```

---

## Step-by-Step Student Instructions

Follow these steps to experiment with expanding the Snack Sorter pipeline:

1. **Inspect Existing Feature Distributions**:
   Open a terminal and run python to inspect the channel means:
   ```python
   import pandas as pd
   df = pd.read_csv("data/snacks.csv")
   print(df.groupby("label")[["mean_r", "mean_g", "mean_b", "aspect_ratio"]].mean())
   ```
2. **Select Candidate 4th Class**:
   Choose a snack that has distinctive visual characteristics. Excellent choices:
   - **Pear**: High green, low blue, aspect ratio $< 1.0$.
   - **Blueberry**: High blue, low red, circular aspect ratio $\approx 1.0$.
   - **Carrot**: High red, moderate green, elongated aspect ratio $\approx 0.4 - 0.5$.
3. **Check for Multicollinearity or Feature Overlap**:
   Verify that your proposed 4th class does not overlap simultaneously across all 5 features with an existing class. For instance, a green apple would heavily overlap with a red apple on shape, but collide with pear on color!
4. **Prepare Image Files**:
   Gather or synthesize 30 PNG images adhering to the naming convention `data/{snack}_{index:02d}.png`.
5. **Compute Handcrafted Features**:
   Run the feature extraction function across each new image file to obtain precise `mean_r`, `mean_g`, `mean_b`, `color_fraction`, and `aspect_ratio` measurements.
6. **Construct the Augmented Dataset**:
   Append the new rows to `snacks.csv` or save to `snacks_extended.csv`.
7. **Re-run the Scikit-learn Pipeline**:
   Split with `stratify=y`, fit the `Pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=3))`, and evaluate.
8. **Inspect the Expanded Confusion Matrix**:
   Confirm that the resulting confusion matrix has dimensions $4 \times 4$ and that precision and recall are tracked for all 4 classes.

---

## Expected Output or Observable Behaviour

When retraining the pipeline with the 4-class dataset (120 total samples, 90 train, 30 test):

```text
============================================================
              FOUR-CLASS SNACK SORTER PIPELINE
============================================================
Dataset shape: (120, 7)
Class breakdown:
  apple     : 30 (25.0%)
  banana    : 30 (25.0%)
  orange    : 30 (25.0%)
  pear      : 30 (25.0%)

Training set size : 90 samples
Test set size     : 30 samples

Model Accuracy: 1.0000 (100.0%)

Classification Report:
              precision    recall  f1-score   support

       apple       1.00      1.00      1.00         7
      banana       1.00      1.00      1.00         8
      orange       1.00      1.00      1.00         8
        pear       1.00      1.00      1.00         7

    accuracy                           1.00        30
   macro avg       1.00      1.00      1.00        30
weighted avg       1.00      1.00      1.00        30

Confusion Matrix (4x4):
[[7 0 0 0]
 [0 8 0 0]
 [0 0 8 0]
 [0 0 0 7]]
============================================================
```

Notice that the support sums to 30: 7 apples, 8 bananas, 8 oranges, and 7 pears, maintaining strict stratification.

---

## Practical Exercises

### Exercise 4.1: Feature Collision Simulation
Design a hypothetical 4th fruit: `"lemon"`.
1. What would the expected `mean_r`, `mean_g`, and `mean_b` values be for a ripe yellow lemon?
2. Compare these values with the known feature stats for banana (`mean_r` ~ 222, `mean_g` ~ 186, `mean_b` ~ 41).
3. Which single feature would be most critical in preventing KNN from confusing a lemon with a banana? (Hint: Consider `aspect_ratio`).

### Exercise 4.2: Hyperparameter Tuning for $K=4$
With 4 classes and 90 training samples ($\approx 22$ samples per class):
1. What happens if you increase `n_neighbors` to $k=25$?
2. Will a query point near the boundary of a small cluster be overwhelmed by votes from larger neighboring clusters?
3. What is the rule of thumb for choosing $k$ relative to class cluster sizes?

---

## Common Mistakes and Debugging

### Mistake 1: Imbalanced Class Injection
- **Symptom**: Student adds only 5 images of the new snack while existing snacks have 30 images.
- **Consequence**: In KNN with $k=5$ or higher, the minority class points have very few neighbors of their own class in the training set. If a test sample of the new class lies near a boundary, the 5 nearest neighbors will almost certainly be dominated by majority class instances, causing 0% recall for the new snack.
- **Fix**: Maintain balanced class representation ($N \approx 30$ per class) or apply distance-weighted voting (`weights='distance'`).

### Mistake 2: Forgetting to Update `image_path` Relative Paths
- **Symptom**: `FileNotFoundError: [Errno 2] No such file or directory: 'data/pear_01.png'`.
- **Consequence**: The feature extraction or visualization plotting code fails when attempting to open images.
- **Fix**: Use `Path(__file__).resolve().parent / "data"` to generate robust relative or absolute filesystem references.

### Mistake 3: Hardcoded Class Lists in Visualization Functions
- **Symptom**: `plot_confusion_matrix` crashes with `IndexError` or displays only 3 classes while predictions contain 4 classes.
- **Consequence**: In `main.py`, lines 89-98 dynamically derive class labels from `np.unique(y_test)`. However, if a developer hardcodes `labels = ['apple', 'banana', 'orange']`, scikit-learn's `confusion_matrix` will ignore the 4th class or raise a shape mismatch error.
- **Fix**: Always pass `labels=np.unique(y_test)` or `labels=model.classes_` to ensure dynamic scaling.

---

## Best Practices and Security Considerations

1. **Dynamic Class Ingestion**:
   Avoid hardcoding class names anywhere in the modeling pipeline. Use `np.unique(y)` or `model.classes_` to dynamically configure legends, color maps, and reports.
2. **Feature Extensibility Verification**:
   Before collecting hundreds of images, create a 2D scatter plot (e.g., `mean_g` vs `aspect_ratio`) of a small pilot sample. If the new class overlaps completely with an existing class, you must introduce new visual descriptors (such as texture GLCM features or edge density) before proceeding.
3. **Data Integrity & Label Hygiene**:
   Sanitize string labels before saving to CSV: strip trailing whitespace, lowercase all strings, and ensure consistent delimiters.

---

## Summary
- Extending the Snack Sorter pipeline requires maintaining data balance, verifying feature separability, and evaluating multi-class performance.
- Because scikit-learn's `Pipeline` and `KNeighborsClassifier` dynamically infer classes from training labels, no changes to core estimator definitions are required when moving from 3 to 4 classes.
- A 4th class expands the confusion matrix from $3 \times 3$ to $4 \times 4$ and requires consistent stratified splitting to ensure balanced representation across train and test partitions.
- If a candidate snack exhibits feature collision with an existing class (e.g., lemon vs banana on color), geometric features like `aspect_ratio` become vital discriminators.

---

## Knowledge-check Questions

### Question 1
Why does scikit-learn's `KNeighborsClassifier` handle an increase from 3 classes to 4 classes without requiring One-vs-Rest (OvR) decomposition?
- A) KNN trains 4 separate neural networks in parallel.
- B) KNN is a non-parametric instance-based algorithm that determines class membership directly by tallying labels among nearest neighbors in feature space.
- C) KNN converts all classification problems into binary regression before calculating distances.
- D) KNN requires all datasets to have exactly two dimensions, making class count irrelevant.
*Answer: B*
*Explanation: KNN computes Euclidean distances between query points and stored training samples. It tallies votes among the $k$ closest neighbors, natively accommodating any number of distinct class labels without requiring multi-model OvR or OvO wrappers.*

### Question 2
Suppose you add "lemon" as a 4th class. Both lemon and banana have very high red and green values (yellow appearance). What feature in `snacks.csv` is best positioned to separate them?
- A) `mean_b`
- B) `color_fraction`
- C) `aspect_ratio`
- D) `image_path`
*Answer: C*
*Explanation: Bananas are elongated curved fruits with distinct aspect ratios (often close to 1.0 or higher depending on crop orientation, or significantly narrower than wide), whereas lemons have an elliptical, near-spherical cross-section. Geometric shape features like `aspect_ratio` provide the necessary discriminative power when color channels collide.*

### Question 3
If you expand the dataset to 120 total samples (30 per class across 4 classes) and use `train_test_split(..., test_size=0.25, stratify=y)`, what will be the dimensions of the resulting confusion matrix generated on the test set?
- A) $3 \times 3$
- B) $4 \times 4$
- C) $30 \times 30$
- D) $120 \times 4$
*Answer: B*
*Explanation: The confusion matrix for a multi-class problem with $K$ distinct classes has dimensions $K \times K$, where rows represent ground-truth labels and columns represent predicted labels. For 4 classes, the matrix is $4 \times 4$.*

---

## References
1. Pedregosa, F., et al. (2011). Scikit-learn: Machine Learning in Python. *Journal of Machine Learning Research*, 12, 2825-2830.
2. Hastie, T., Tibshirani, R., & Friedman, J. (2009). *The Elements of Statistical Learning: Data Mining, Inference, and Prediction*. Springer, Chapter 13: Prototype Methods and Nearest Neighbors.
3. Bishop, C. M. (2006). *Pattern Recognition and Machine Learning*. Springer, Chapter 2.5: Nonparametric Methods.
