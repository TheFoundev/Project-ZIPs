# Module 06 Exercises: Complete Pipeline, Artifact Inspection & System Extension

---

## Exercise 6.1: End-to-End Pipeline Execution and Output Artifact Verification

**Objective:** Execute the entire `main.py` pipeline, verify console output metrics, and programmatically validate all generated image and text artifacts.

**Problem Statement:**
In automated continuous integration (CI) and ML evaluation workflows, scripts must run end-to-end without interactive intervention and produce verified file artifacts. You must run the complete `main.py` script and write a verification script `test_artifacts.py` that confirms all expected files exist, are non-empty, and contain valid data.

**Requirements:**
1. Execute `main.py` from the project root and confirm clean execution with zero return code.
2. In `test_artifacts.py`, programmatically check for the existence of:
   - `outputs/sample_snacks.png`
   - `outputs/predictions.png`
   - `outputs/confusion_matrix.png`
   - `outputs/metrics.txt`
3. Verify that `outputs/metrics.txt` contains:
   - The phrase `"Accuracy: 1.0000"` (or matches current test accuracy).
   - Non-zero file size greater than 100 bytes.
4. Verify that each image file has dimensions greater than 200x200 pixels using PIL.

**Constraints:**
- Must use standard Python libraries (`pathlib`, `PIL`, `os`, `sys`).
- Must report clear PASS/FAIL statuses for each artifact check.

**Expected Behaviour:**
```text
[PASS] outputs/sample_snacks.png exists (Dimensions: 800x800, Size: 124582 bytes)
[PASS] outputs/predictions.png exists (Dimensions: 800x800, Size: 119840 bytes)
[PASS] outputs/confusion_matrix.png exists (Dimensions: 600x500, Size: 45210 bytes)
[PASS] outputs/metrics.txt exists and contains valid classification report
All 4 artifacts successfully validated!
```

**Acceptance Criteria:**
- [ ] `main.py` executes without errors.
- [ ] `test_artifacts.py` checks all 4 output artifacts in `outputs/`.
- [ ] Each artifact is verified for existence, non-zero file size, and basic structural validity.
- [ ] Console output prints pass/fail diagnostics for all 4 artifacts.

**Hints:**
- Use `from pathlib import Path` and `Path("outputs/metrics.txt").read_text()`.
- Use `from PIL import Image` with `with Image.open(path) as img: width, height = img.size`.

**Difficulty:** Beginner  
**Estimated Time:** 20 minutes

---

## Exercise 6.2: Quantitative Impact of `stratify=y` vs `stratify=None`

**Objective:** Write an experiment script comparing the stability of class distributions across 50 random splits with and without stratification.

**Problem Statement:**
Machine learning practitioners often debate whether stratification is strictly necessary for balanced datasets. You must empirically demonstrate the variance in test-set class proportions between stratified and non-stratified random splitting across 50 Monte Carlo trials.

**Requirements:**
1. Load `data/snacks.csv` using pandas.
2. Define a loop over 50 random states (`random_state=0` to `49`).
3. For each random state, perform two splits with `test_size=0.25`:
   - Split A: `train_test_split(..., stratify=y, random_state=seed)`
   - Split B: `train_test_split(..., stratify=None, random_state=seed)`
4. For both splits, record the count of each class (`apple`, `banana`, `orange`) in `y_test`.
5. Compute the standard deviation of class counts across the 50 runs for both methods.
6. Print a formatted comparison table.

**Constraints:**
- Use `numpy` and `pandas` for calculations.
- Display standard deviation rounded to 4 decimal places.

**Expected Behaviour:**
```text
============================================================
       STRATIFIED VS UNSTRATIFIED SPLIT VARIABILITY
============================================================
Stratified Split Class Count Std Dev:
  Apple : 0.0000 (Consistent count: 7 or 8)
  Banana: 0.0000 (Consistent count: 7 or 8)
  Orange: 0.0000 (Consistent count: 7 or 8)

Unstratified Split Class Count Std Dev:
  Apple : 2.1482 (Counts ranged from 3 to 13)
  Banana: 2.3105 (Counts ranged from 4 to 14)
  Orange: 2.2590 (Counts ranged from 2 to 12)
============================================================
```

**Acceptance Criteria:**
- [ ] Script runs across 50 distinct random seeds.
- [ ] Accurately records class frequencies in `y_test` for both stratified and unstratified splits.
- [ ] Demonstrates that stratified splitting has near-zero variance in class proportion.
- [ ] Explains in comments why stratified splitting prevents sampling bias.

**Hints:**
- Store the counts in dictionaries or lists: `counts_strat.append(y_test_strat.value_counts().to_dict())`.
- Convert the list of dicts to a `pd.DataFrame` and call `.std()`.

**Difficulty:** Intermediate  
**Estimated Time:** 30 minutes

---

## Exercise 6.3: 4th Class Pipeline Extension Design and Evaluation

**Objective:** Design and simulate adding a 4th class ("pear" or "grape") to the Snack Sorter dataset and verify that the scikit-learn pipeline correctly scales.

**Problem Statement:**
A sorting facility needs to classify green pears in addition to apples, bananas, and oranges. You must write an extension script that appends 30 simulated pear records to the dataset, performs a 4-class stratified split, fits the `Pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=3))`, and prints the $4 \times 4$ confusion matrix and classification report.

**Requirements:**
1. Define synthetic feature distributions for 30 pears:
   - `mean_r`: Gaussian distribution around 135 (std = 8)
   - `mean_g`: Gaussian distribution around 195 (std = 6)
   - `mean_b`: Gaussian distribution around 48 (std = 5)
   - `color_fraction`: Calculated as $\max(r, g, b) / (r + g + b)$
   - `aspect_ratio`: Gaussian distribution around 0.78 (std = 0.04)
2. Concatenate these 30 rows with the existing 90 rows from `data/snacks.csv`.
3. Perform a 75/25 stratified split on the combined 120-row dataset (`random_state=42`).
4. Fit the standard Pipeline (`StandardScaler` + `KNeighborsClassifier(n_neighbors=3)`).
5. Generate predictions and print:
   - Total dataset shape (should be `(120, 7)`).
   - Test accuracy score.
   - 4-class classification report.
   - 4x4 confusion matrix.

**Constraints:**
- Must use `np.random.seed(42)` for reproducible synthetic values.
- Must ensure all generated pixel values stay within `[0, 255]`.

**Expected Behaviour:**
```text
Extended Dataset Size: 120 samples (30 apple, 30 banana, 30 orange, 30 pear)
Test Set Size: 30 samples
Test Accuracy: 1.0000

4-Class Classification Report:
              precision    recall  f1-score   support
       apple       1.00      1.00      1.00         7
      banana       1.00      1.00      1.00         8
      orange       1.00      1.00      1.00         8
        pear       1.00      1.00      1.00         7
```

**Acceptance Criteria:**
- [ ] Synthetic pear feature distributions reflect realistic green pear properties.
- [ ] Dataset successfully expands to 120 rows with balanced classes (30 each).
- [ ] Scikit-learn Pipeline fits without errors or manual class mapping.
- [ ] Confusion matrix accurately displays 4 rows and 4 columns.

**Hints:**
- Use `np.random.normal(loc, scale, size)` and `np.clip(..., 0, 255)`.
- Use `pd.concat([df_orig, df_pear], ignore_index=True)`.

**Difficulty:** Advanced  
**Estimated Time:** 35 minutes
