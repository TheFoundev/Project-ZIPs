# Module 03 Exercises: Feature Scaling, Pipelines & Separability

---

## Exercise 3.1: Mathematical Demonstration of Euclidean Distance Domination

**Objective:** Prove mathematically how unscaled feature differences overpower smaller geometric variables in Euclidean distance calculations.

**Problem Statement:**
Consider two hypothetical snack samples $A$ and $B$:
- Sample $A$ (Apple): `mean_g = 45.0`, `aspect_ratio = 0.83`
- Sample $B$ (Orange): `mean_g = 124.0`, `aspect_ratio = 1.00`

You must calculate the Euclidean distance between $A$ and $B$ under two conditions:
1. Using raw unscaled values.
2. Using standardized values where `mean_g` has $\mu = 118.0, \sigma = 58.0$, and `aspect_ratio` has $\mu = 0.93, \sigma = 0.09$.

**Requirements:**
1. Calculate the squared difference and Euclidean distance for raw unscaled values across these two features.
2. Calculate the percentage contribution of `mean_g` versus `aspect_ratio` to the unscaled squared distance.
3. Standardize both samples into z-scores using the provided $\mu$ and $\sigma$.
4. Calculate the squared difference and Euclidean distance in standardized space.
5. Compare the relative contribution of `aspect_ratio` before and after scaling.

**Constraints:**
- Show all intermediate arithmetic steps.

**Expected Behaviour:**
A clear step-by-step mathematical demonstration showing that `aspect_ratio` contributes $<0.01\%$ to raw distance, but $>10\%$ after standardization.

**Acceptance Criteria:**
- [ ] Correctly calculates raw $(\Delta \text{mean\_g})^2 = (124 - 45)^2 = 79^2 = 6241$.
- [ ] Correctly calculates raw $(\Delta \text{aspect\_ratio})^2 = (1.00 - 0.83)^2 = 0.17^2 = 0.0289$.
- [ ] Computes raw distance $\approx \sqrt{6241.0289} \approx 79.0002$.
- [ ] Converts values to z-scores accurately.
- [ ] Concludes that standardization restores geometric voice to `aspect_ratio`.

**Hints:**
- $z = (x - \mu) / \sigma$.
- Notice how adding $0.0289$ to $6241$ changes almost nothing in unscaled Euclidean space.

**Difficulty:** Intermediate
**Estimated Completion Time:** 20 minutes

---

## Exercise 3.2: Building and Testing a Scikit-Learn Pipeline

**Objective:** Construct a 2-step Pipeline containing `StandardScaler` and `KNeighborsClassifier` and verify its behavior.

**Problem Statement:**
Write a Python script that loads `data/snacks.csv`, creates the 2-step Pipeline from `main.py`, fits it on the training split, and prints the learned means of the `StandardScaler` step.

**Requirements:**
1. Import `Pipeline`, `StandardScaler`, and `KNeighborsClassifier`.
2. Construct `model = Pipeline([("scale", StandardScaler()), ("knn", KNeighborsClassifier(n_neighbors=5))])`.
3. Fit the model on `X_train` and `y_train` from the 75/25 stratified split.
4. Access the fitted scaler using `model.named_steps["scale"]`.
5. Print the 5 learned feature means stored in `scaler.mean_`.

**Constraints:**
- Must use `main.py`'s exact pipeline configuration and feature list.

**Expected Behaviour:**
Console output displaying the 5 learned training feature means matching `main.py`'s training set.

**Acceptance Criteria:**
- [ ] Pipeline is constructed with steps `"scale"` and `"knn"`.
- [ ] Pipeline fits successfully on training data.
- [ ] Retrieves scaler via `model.named_steps["scale"]`.
- [ ] Prints learned mean vector corresponding to the 5 features.

**Hints:**
- `model.named_steps` returns a dictionary mapping step names to fitted transformer/estimator instances.

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 3.3: Evaluating Single-Feature Decision Boundaries

**Objective:** Determine the predictive power of individual features by evaluating simple threshold rules.

**Problem Statement:**
In Lesson 04, we observed that `mean_g` has non-overlapping ranges across the three fruit classes. Write a Python function `simple_green_classifier(mean_g_value)` that classifies any sample using only two threshold conditions on `mean_g`.

**Requirements:**
1. Inspect the min and max `mean_g` values for each class in `snacks.csv`.
2. Select two threshold boundaries $T_1$ and $T_2$ that separate apples from oranges, and oranges from bananas.
3. Implement `simple_green_classifier(val)` returning `"apple"` if $val < T_1$, `"orange"` if $T_1 \le val < T_2$, and `"banana"` if $val \ge T_2$.
4. Apply your function across all 90 rows of `snacks.csv` and report its accuracy.

**Constraints:**
- Use strictly the `mean_g` column.

**Expected Behaviour:**
A working Python script showing that thresholding on `mean_g` alone achieves 100% accuracy on this specific dataset, illustrating supreme feature separability.

**Acceptance Criteria:**
- [ ] Selects valid thresholds (e.g., $T_1 = 80$, $T_2 = 150$).
- [ ] Implements the decision logic correctly.
- [ ] Tests all 90 rows against ground-truth labels.
- [ ] Reports accuracy score (1.0 or 100%).
- [ ] Explains why relying solely on one feature in production is risky despite 100% score here.

**Hints:**
- Apples max out at $\sim 48.7$, oranges are around $121-125$, and bananas start above $183$.
- Any threshold around $80$ cleanly separates apples from oranges!

**Difficulty:** Intermediate
**Estimated Completion Time:** 20 minutes

---

## Exercise 3.4: Dimensionality and Feature Redundancy Analysis

**Objective:** Analyze the impact of dropping features on model resilience.

**Problem Statement:**
You are testing the robustness of The Snack Sorter. Modify the feature list to use only the two shape features: `FEATURES_SHAPE = ["color_fraction", "aspect_ratio"]`. Train the pipeline on these 2 features alone and evaluate the test set accuracy.

**Requirements:**
1. Create $X_{\text{shape}} = \text{df}[[\text{"color\_fraction", "aspect\_ratio"}]]$.
2. Split using the same `random_state=42` and `stratify=y`.
3. Train the `StandardScaler` + `KNN(5)` pipeline on $X_{\text{shape}}$.
4. Predict on the test set and compute test accuracy.
5. Compare the accuracy of the 2 shape features against the full 5-feature pipeline.

**Constraints:**
- Use the same split parameters (`test_size=0.25, random_state=42, stratify=y`).

**Expected Behaviour:**
A script output showing the resulting accuracy when relying solely on shape features, accompanied by a brief analysis of which fruits were confused.

**Acceptance Criteria:**
- [ ] Correctly restricts $X$ to 2 shape features.
- [ ] Fits the pipeline and computes test accuracy.
- [ ] Observes the performance difference compared to 100% on the full 5 features.
- [ ] Concludes that combining color and geometry provides essential multi-modal synergy.

**Hints:**
- Bananas and oranges have distinct color fractions, but their aspect ratios might overlap with other fruits.

**Difficulty:** Advanced
**Estimated Completion Time:** 25 minutes
