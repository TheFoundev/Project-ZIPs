# Lesson 03: Building Scikit-Learn Pipelines with `Pipeline`

**Lesson ID:** lesson-03
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain the syntax and structure of scikit-learn's `Pipeline` class.
- Distinguish between **transformers** and **estimators** in scikit-learn.
- Explain the contract of the pipeline: why all intermediate steps must implement `fit()` and `transform()`, while the final step implements `fit()` and `predict()`.
- Access and inspect individual steps within a pipeline using `named_steps`.
- Write Python code to construct, fit, and evaluate a multi-stage machine learning pipeline.

## Prerequisites

- Module 03, Lesson 02: Why Distance Needs Scaling: The `StandardScaler` Mechanism.
- Basic understanding of Python lists and tuples.

## Concept Explanation

### The Scikit-Learn Object Hierarchy
To master scikit-learn pipelines, you must understand the distinction between two core types of objects:
1. **Transformers**: Objects that learn parameters from data and transform the data into a new format.
   - Examples: `StandardScaler`, `MinMaxScaler`, `PCA`, `OneHotEncoder`.
   - Core methods: `fit()` (learn statistics), `transform()` (apply transformation), and `fit_transform()` (do both efficiently).
2. **Estimators / Predictors**: Objects that learn patterns from data and make predictions on new data.
   - Examples: `KNeighborsClassifier`, `LinearRegression`, `RandomForestClassifier`.
   - Core methods: `fit()` (train model), `predict()` (generate predictions), and optionally `predict_proba()`.

### How `Pipeline` Coordinates Transformers and Estimators
A `Pipeline` is an overarching container that chains transformers sequentially, ending with an estimator.
In `main.py`, lines 43–48 construct our pipeline:
```python
model = Pipeline(
    [
        ("scale", StandardScaler()),
        ("knn", KNeighborsClassifier(n_neighbors=5)),
    ]
)
```

The constructor accepts a list of 2-element tuples: `(step_name_str, step_object)`.
- Step 1: `("scale", StandardScaler())` $\rightarrow$ Transformer
- Step 2: `("knn", KNeighborsClassifier(n_neighbors=5))` $\rightarrow$ Estimator

### The Operational Contract of a Pipeline
A pipeline enforces strict mathematical and software rules:
- **Every intermediate step** (all steps except the last) **must be a transformer**. It must implement both `fit()` and `transform()`. The output of step $N$ becomes the input to step $N+1$.
- **The final step** can be an estimator (implementing `predict()`) or a transformer. In classification, the final step is almost always a classifier.
- When `model.fit(X, y)` is called:
  - Step 1 calls `scale.fit_transform(X)`.
  - Step 2 calls `knn.fit(X_scaled, y)`.
- When `model.predict(X_new)` is called:
  - Step 1 calls `scale.transform(X_new)`.
  - Step 2 calls `knn.predict(X_new_scaled)`.

### Inspecting Pipeline Internals with `named_steps`
Once fitted, you can inspect each individual step's attributes using the `named_steps` dictionary attribute:
```python
# Access the fitted StandardScaler
scaler = model.named_steps["scale"]
print("Learned feature means:", scaler.mean_)

# Access the fitted KNeighborsClassifier
knn = model.named_steps["knn"]
print("Effective metric:", knn.effective_metric_)
```

This ensures complete transparency: you have the convenience of an automated pipeline without sacrificing the ability to inspect underlying parameters.

## Relevant Code (from main.py, lines 23-24, 43-49)

```python
23: from sklearn.pipeline import Pipeline
24: from sklearn.preprocessing import StandardScaler
...
43:     model = Pipeline(
44:         [
45:             ("scale", StandardScaler()),
46:             ("knn", KNeighborsClassifier(n_neighbors=5)),
47:         ]
48:     )
49:     model.fit(X_train, y_train)
```

### Code Explanation
- **Line 23**: Imports `Pipeline` from `sklearn.pipeline`.
- **Line 24**: Imports `StandardScaler` from `sklearn.preprocessing`.
- **Lines 43-48**: Creates the pipeline named `model` with step names `"scale"` and `"knn"`.
- **Line 49**: Executes the training workflow across both steps with a single call to `model.fit(X_train, y_train)`.

## Worked Example

**Constructing and Querying a Pipeline Step-by-Step:**

```python
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier

# Load data
df = pd.read_csv("data/snacks.csv")
X = df[["mean_r", "mean_g", "mean_b", "color_fraction", "aspect_ratio"]]
y = df["label"]

# Build pipeline
pipe = Pipeline([
    ("scale", StandardScaler()),
    ("knn", KNeighborsClassifier(n_neighbors=5))
])

# Fit on data
pipe.fit(X, y)

# Inspect the fitted mean of mean_r
r_mean = pipe.named_steps["scale"].mean_[0]
print(f"Learned mean for mean_r: {r_mean:.2f}")

# Make a prediction directly with raw features!
sample = pd.DataFrame([{
    "mean_r": 175.0,
    "mean_g": 45.0,
    "mean_b": 44.0,
    "color_fraction": 0.31,
    "aspect_ratio": 0.83
}])
pred = pipe.predict(sample)
print(f"Prediction for sample: {pred[0]}")
```

**Output:**
```text
Learned mean for mean_r: 211.23
Prediction for sample: apple
```
**Interpretation:**
- Notice that `pipe.predict(sample)` received raw unscaled feature numbers!
- The pipeline automatically scaled `sample` using its internal `StandardScaler` before querying KNN, outputting the correct label `"apple"`.

## Step-by-Step Student Instructions

1. **Open your terminal** and launch Python.
2. **Import Pipeline and components**:
   ```python
   from sklearn.pipeline import Pipeline
   from sklearn.preprocessing import StandardScaler
   from sklearn.neighbors import KNeighborsClassifier
   ```
3. **Build the pipeline**:
   ```python
   model = Pipeline([
       ("scale", StandardScaler()),
       ("knn", KNeighborsClassifier(n_neighbors=5))
   ])
   ```
4. **Inspect the pipeline representation**:
   ```python
   print(model)
   ```
5. **Verify that it has a `fit` and `predict` interface**:
   ```python
   print(hasattr(model, "fit"))      # True
   print(hasattr(model, "predict"))  # True
   ```

## Expected Output or Observable Behaviour

Printing the pipeline object displays scikit-learn's formatted text representation:
```text
Pipeline(steps=[('scale', StandardScaler()),
                ('knn', KNeighborsClassifier(n_neighbors=5))])
True
True
```
This confirms that the pipeline encapsulates both steps and presents standard scikit-learn estimator methods.

## Practical Exercises

- **Exercise 3.1**: What happens if you try to put `KNeighborsClassifier` as Step 1 and `StandardScaler` as Step 2? Why does Python throw an error?
- **Exercise 3.2**: How do you retrieve the fitted scaler from a pipeline named `model`?
- **Exercise 3.3**: What is the shortcut function `make_pipeline` in scikit-learn, and how does it differ from `Pipeline`?
- **Exercise 3.4**: When `model.score(X_test, y_test)` is called on a pipeline, how does the pipeline process `X_test`?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Passing a dictionary instead of a list of tuples to `Pipeline` | `Pipeline` requires an ordered list of `(name, object)` tuples to maintain step sequence. | Use a list of tuples: `[("step1", obj1), ("step2", obj2)]`. |
| Placing an estimator that lacks `transform` in an intermediate step | Intermediate steps must transform data for the next step. | Only the final step can be an estimator without a `transform()` method. |
| Manually transforming test data before passing it to `pipeline.predict()` | The pipeline automatically calls `transform()` on test inputs. Manually transforming causes the data to be scaled twice! | Pass raw unscaled test data directly to `pipeline.predict()`. |

## Best Practices and Security Considerations

- **Single Point of Inference**: Always pass raw unscaled data into `pipeline.predict()`. Never manually scale data outside a pipeline.
- **Cross-Validation Safety**: When running `cross_val_score` or `GridSearchCV`, pass the pipeline rather than the raw model to prevent leakage across CV folds.
- **Model Serialization**: Save the entire fitted pipeline using `joblib.dump(model, "model.joblib")`. This guarantees preprocessing and model logic are stored together.

## Summary

The scikit-learn `Pipeline` class provides an essential architectural abstraction by chaining data preprocessing transformers and final estimators into a single cohesive object. Intermediate steps must implement both `fit` and `transform`, while the final step implements `fit` and `predict`. In The Snack Sorter, the pipeline coordinates `StandardScaler` and `KNeighborsClassifier(n_neighbors=5)`, automating data scaling and preventing data leakage across all training and evaluation stages.

## Knowledge-check Questions

1. What are the two core types of objects in scikit-learn, and how do they differ?
2. What are the names of the two steps configured in the `main.py` pipeline?
3. Why must all intermediate steps in a scikit-learn pipeline be transformers?
4. How do you access the learned mean vector of the `StandardScaler` inside a fitted pipeline?
5. What happens if a user accidentally scales test data manually before passing it to `pipeline.predict()`?

## References

- Scikit-learn Pipeline Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.pipeline.Pipeline.html
- Scikit-learn Pipeline and Composite Estimators: https://scikit-learn.org/stable/modules/compose.html
- The Snack Sorter source code: `main.py` lines 43–49.
