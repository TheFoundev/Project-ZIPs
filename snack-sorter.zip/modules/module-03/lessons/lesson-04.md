# Lesson 04: Feature Separability & Visual Classification Mechanics

**Lesson ID:** lesson-04
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Define **feature separability** and explain what makes a feature discriminative.
- Analyze how individual features and feature pairs create distinct decision boundaries.
- Explain why `mean_g` (green intensity) provides the highest single-feature separability for these three fruits.
- Understand the complementary role of shape features (`aspect_ratio` and `color_fraction`) in resolving color ambiguities.
- Visualize 2D feature projections to see how clusters of apples, bananas, and oranges separate in space.

## Prerequisites

- Module 03, Lesson 01: The Five Hand-Crafted Features in Depth.
- Module 03, Lesson 02: Why Distance Needs Scaling: The `StandardScaler` Mechanism.
- Basic understanding of scatter plots.

## Concept Explanation

### What Is Feature Separability?
In classification, a feature is valuable if it cleanly separates different classes with minimal overlap.
- **High Separability**: The distributions of different classes do not overlap. A single threshold or boundary can separate them.
- **Low Separability**: The distributions heavily overlap, meaning the feature provides little or no discriminating information on its own.

### The Power of `mean_g` (The Green Channel)
In our dataset, `mean_g` is by far the most powerful individual feature:
- Apples: $\text{mean} = 45.46$ (spread: $42.9 - 48.7$)
- Oranges: $\text{mean} = 123.58$ (spread: $121.7 - 125.1$)
- Bananas: $\text{mean} = 185.90$ (spread: $183.8 - 187.8$)

Notice that between the highest apple ($48.7$) and the lowest orange ($121.7$), there is a massive gap of over $70$ units!
Between the highest orange ($125.1$) and the lowest banana ($183.8$), there is another gap of over $58$ units!
In statistical terms, these classes have **zero overlap** along the `mean_g` axis. A simple set of two if-statements on `mean_g` could almost classify the fruits alone!

### Why Do We Need the Other 4 Features?
If `mean_g` is so good, why include `mean_r`, `mean_b`, `color_fraction`, and `aspect_ratio`?
1. **Robustness Against Real-World Lighting**:
   - In realistic conditions, a bright halogen spotlight or shadow can shift green values up or down.
   - Relying on a single feature creates a **single point of failure**. If `mean_g` is distorted by glare, the model would fail completely.
2. **Distinguishing Subtleties**:
   - Consider distinguishing a yellow-green granny smith apple from a banana: both might have high green!
   - In that scenario, `aspect_ratio` ($\approx 0.83$ for apple vs $\approx 0.98$ for banana) and `color_fraction` immediately resolve the ambiguity.
3. **Multi-Dimensional Clustering**:
   - In 5-dimensional feature space, each fruit forms a tight, cohesive "cluster" or neighborhood. By using 5 orthogonal features, the Euclidean distance between clusters becomes large and resilient to individual noisy measurements.

### The Geometric Complement: `aspect_ratio` vs `color_fraction`
Consider plotting the two shape features against each other:
- Bananas have a slender profile: low `color_fraction` ($0.22$) and varied aspect ratio ($0.90 - 1.12$).
- Apples have a compact silhouette: medium `color_fraction` ($0.31$) and low aspect ratio ($0.81 - 0.85$).
- Oranges are broad circular discs: high `color_fraction` ($0.34$) and aspect ratio close to $1.00$.

Even without color, shape alone provides significant clustering power. Combining color and geometry creates an extraordinarily robust classification space.

## Relevant Code (from main.py, lines 31, 36)

```python
31: FEATURES = ["mean_r", "mean_g", "mean_b", "color_fraction", "aspect_ratio"]
...
36:     X = df[FEATURES]
```

### Code Explanation
- **Line 31**: Combines three color descriptors (`mean_r`, `mean_g`, `mean_b`) and two geometric descriptors (`color_fraction`, `aspect_ratio`) into a balanced multi-modal feature vector.
- **Line 36**: Extracts all 5 features simultaneously, allowing the downstream scaler and KNN classifier to construct a robust 5-dimensional decision space.

## Worked Example

**Measuring Class Separation with the Variance Ratio:**

In machine learning, Fisher's criterion measures feature separability by comparing between-class variance to within-class variance:
$$F = \frac{\text{Between-Class Variance}}{\text{Within-Class Variance}}$$
Higher values of $F$ indicate cleaner separation.

Let's compute $F$-values for our 5 features using scikit-learn's `f_classif`:
```python
import pandas as pd
from sklearn.feature_selection import f_classif

df = pd.read_csv("data/snacks.csv")
features = ["mean_r", "mean_g", "mean_b", "color_fraction", "aspect_ratio"]
X = df[features]
y = df["label"]

f_scores, p_values = f_classif(X, y)
ranking = pd.DataFrame({"Feature": features, "F-Score": f_scores}).sort_values("F-Score", ascending=False)
print(ranking.to_string(index=False))
```

**Output:**
```text
       Feature      F-Score
        mean_g 18274.52
        mean_r  1154.21
        mean_b  1028.94
  aspect_ratio   124.60
color_fraction    98.42
```
**Interpretation:**
- `mean_g` achieves an astronomical $F$-score of over $18,000$, confirming its supreme discriminating power.
- However, all 5 features have massive $F$-scores ($>98$) and $p$-values effectively equal to $0.0$, demonstrating that every single feature contributes valuable class-separating information.

## Step-by-Step Student Instructions

1. **Open your terminal** and launch Python.
2. **Load data**:
   ```python
   import pandas as pd
   df = pd.read_csv("data/snacks.csv")
   ```
3. **Check the minimum and maximum `mean_g` for each fruit**:
   ```python
   for fruit in ["apple", "orange", "banana"]:
       sub = df[df["label"] == fruit]["mean_g"]
       print(f"{fruit:6s}: min={sub.min():.2f}, max={sub.max():.2f}")
   ```
4. **Inspect the aspect ratio bounds**:
   ```python
   for fruit in ["apple", "orange", "banana"]:
       sub = df[df["label"] == fruit]["aspect_ratio"]
       print(f"{fruit:6s}: min={sub.min():.2f}, max={sub.max():.2f}")
   ```
5. Confirm that the intervals for `mean_g` do not overlap at all between classes.

## Expected Output or Observable Behaviour

Executing these commands in Python outputs:
```text
apple : min=42.91, max=48.67
orange: min=121.73, max=125.08
banana: min=183.82, max=187.80
```
There is zero overlap between the fruit classes along `mean_g`.

## Practical Exercises

- **Exercise 4.1**: What is the gap between the highest apple `mean_g` and the lowest orange `mean_g`?
- **Exercise 4.2**: If you had to classify these three fruits using only two features on a 2D scatter plot, which two features would you choose and why?
- **Exercise 4.3**: Suppose a camera has a color balance error that halves all Green values. Which feature would help prevent the model from failing completely?
- **Exercise 4.4**: Why does combining complementary feature types (color + shape) improve model resilience compared to relying exclusively on color?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Dropping shape features just because `mean_g` has the highest F-score | Relying solely on color creates fragility against lighting shifts and fails if new fruits share similar colors. | Maintain a diverse set of complementary features (color + geometry). |
| Assuming high correlation between features implies redundancy | Even if two color channels correlate, their combination provides multidimensional distance margins that improve KNN robustness. | Keep features that represent distinct physical channels (R, G, B, shape). |
| Evaluating feature importance without scaling | Raw differences in unscaled variables disguise true statistical separability. | Always standardize features before comparing distances or clustering. |

## Best Practices and Security Considerations

- **Feature Diversity**: Combine multiple sensory modalities (e.g., color, texture, shape, size) when designing classical computer vision systems.
- **Redundancy and Fail-safes**: Multiple informative features provide redundancy, allowing systems to remain functional even if individual sensors experience noise or partial occlusion.
- **Curse of Dimensionality Trade-off**: While adding informative features is good, adding dozens of noisy, uninformative features degrades KNN performance. Keep features curated and relevant.

## Summary

Feature separability measures how cleanly an attribute differentiates distinct classes. In The Snack Sorter, `mean_g` is the most discriminative individual feature because digital RGB color mixing creates non-overlapping green intervals for red apples ($43-49$), orange fruit ($122-125$), and yellow bananas ($184-188$). Combining color channels with geometric metrics (`aspect_ratio` and `color_fraction`) provides geometric redundancy and robustness, forming well-isolated 5-dimensional clusters that K-Nearest Neighbors classifies with 100% test accuracy.

## Knowledge-check Questions

1. What is feature separability in machine learning classification?
2. Why does `mean_g` have non-overlapping ranges for apples, bananas, and oranges?
3. What are the minimum and maximum ranges of `mean_g` for apples versus oranges?
4. What role do shape features (`aspect_ratio` and `color_fraction`) play if lighting or color balance fluctuates?
5. What statistical metric (such as Fisher's criterion or ANOVA F-value) can quantify the separability of continuous features across classes?

## References

- Scikit-learn Feature Selection Guide: https://scikit-learn.org/stable/modules/feature_selection.html
- ANOVA F-value (`f_classif`) Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.feature_selection.f_classif.html
- The Snack Sorter source code: `main.py` line 31.
