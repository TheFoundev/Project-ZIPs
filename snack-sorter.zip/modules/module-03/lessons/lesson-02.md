# Lesson 02: Why Distance Needs Scaling: The `StandardScaler` Mechanism

**Lesson ID:** lesson-02
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain why distance-based algorithms like K-Nearest Neighbors (KNN) are sensitive to feature scales.
- State the mathematical formula for z-score standardization used by `StandardScaler`.
- Demonstrate numerically how unscaled features cause large-magnitude variables (like RGB means) to overpower small-magnitude variables (like aspect ratio).
- Explain how `StandardScaler.fit()` computes the training mean ($\mu$) and standard deviation ($\sigma$).
- Verify that standardizing features gives every dimension equal geometric weight.

## Prerequisites

- Module 03, Lesson 01: The Five Hand-Crafted Features in Depth.
- Basic algebra: mean ($\mu$) and standard deviation ($\sigma$).

## Concept Explanation

### The Scale Disparity in The Snack Sorter
Let's examine the raw numbers in our dataset:
- `mean_r`: values span from $\approx 171.9$ to $237.0$ (a spread of $\sim 65.1$).
- `mean_g`: values span from $\approx 42.9$ to $187.8$ (a spread of $\sim 144.9$).
- `aspect_ratio`: values span from $\approx 0.79$ to $1.12$ (a spread of $\sim 0.33$).
- `color_fraction`: values span from $\approx 0.20$ to $0.40$ (a spread of $\sim 0.20$).

Notice the enormous mismatch: **`mean_g` values are several hundred times larger than `aspect_ratio` and `color_fraction`!**

### What Happens to Euclidean Distance Without Scaling?
Recall that K-Nearest Neighbors measures the similarity between two points using Euclidean distance:
$$d(p, q) = \sqrt{(p_R - q_R)^2 + (p_G - q_G)^2 + (p_B - q_B)^2 + (p_{\text{fraction}} - q_{\text{fraction}})^2 + (p_{\text{ratio}} - q_{\text{ratio}})^2}$$

Now look at the squared differences:
- A small difference in `mean_g` (e.g., $10$ units) results in $(10)^2 = \mathbf{100}$.
- A massive difference in `aspect_ratio` (e.g., $0.20$ units, the entire difference between an apple and an orange) results in $(0.20)^2 = \mathbf{0.04}$.

When added together:
$$100 + 0.04 = 100.04 \approx 100$$
The shape information is completely washed out! The distance calculation is $99.96\%$ dominated by the color channel, and the geometric features are rendered entirely useless.

### The Solution: Standard Normalization (Z-Score)
To prevent features with large scales from drowning out features with small scales, we **standardize** the data using scikit-learn's `StandardScaler`.
For each feature $j$, `StandardScaler` calculates the mean ($\mu_j$) and standard deviation ($\sigma_j$) on the training set:
$$\mu_j = \frac{1}{N} \sum_{i=1}^N x_{ij}, \quad \sigma_j = \sqrt{\frac{1}{N} \sum_{i=1}^N (x_{ij} - \mu_j)^2}$$
Then it transforms each raw value $x$ into a standardized z-score $z$:
$$z = \frac{x - \mu_j}{\sigma_j}$$

### Properties of the Standardized Features
After applying `StandardScaler`:
1. Every feature has a **mean of 0.0** ($\mu = 0$).
2. Every feature has a **standard deviation (variance) of 1.0** ($\sigma = 1$).
3. A difference of 1.0 standard deviation in color channel now carries the exact same mathematical weight as a difference of 1.0 standard deviation in aspect ratio!
4. The playing field is completely leveled, allowing KNN to consider both color and geometry fairly.

## Relevant Code (from main.py, lines 24, 43-48)

```python
24: from sklearn.preprocessing import StandardScaler
...
43:     model = Pipeline(
44:         [
45:             ("scale", StandardScaler()),
46:             ("knn", KNeighborsClassifier(n_neighbors=5)),
47:         ]
48:     )
```

### Code Explanation
- **Line 24**: Imports `StandardScaler` from scikit-learn's `preprocessing` module.
- **Line 45**: Places `("scale", StandardScaler())` as the very first step in the pipeline.
- When `model.fit(X_train, y_train)` runs, the pipeline fits the scaler on `X_train` and transforms the training points before passing them to the KNN classifier.

## Worked Example

**Manual Calculation of Z-Score for an Apple's `aspect_ratio`:**

From the dataset:
- Overall training mean for `aspect_ratio`: $\mu = 0.93$
- Overall training standard deviation: $\sigma = 0.09$
- Consider an apple with raw `aspect_ratio = 0.83`:
  $$z = \frac{0.83 - 0.93}{0.09} = \frac{-0.10}{0.09} \approx -1.11$$
- Consider an orange with raw `aspect_ratio = 1.00`:
  $$z = \frac{1.00 - 0.93}{0.09} = \frac{+0.07}{0.09} \approx +0.78$$

Now calculate the squared difference between the apple and orange in scaled units:
$$\Delta z = (0.78 - (-1.11)) = 1.89$$
$$(\Delta z)^2 = (1.89)^2 \approx \mathbf{3.57}$$

Notice that in standardized units, the geometric difference between apple and orange contributes a substantial $3.57$ to the Euclidean distance—competing on equal terms with the color features!

## Step-by-Step Student Instructions

1. **Open your terminal** and launch Python: `python3`.
2. **Import packages and load data**:
   ```python
   import pandas as pd
   from sklearn.preprocessing import StandardScaler
   df = pd.read_csv("data/snacks.csv")
   features = ["mean_r", "mean_g", "mean_b", "color_fraction", "aspect_ratio"]
   X = df[features]
   ```
3. **Instantiate and fit the scaler**:
   ```python
   scaler = StandardScaler()
   X_scaled = scaler.fit_transform(X)
   ```
4. **Verify the transformed mean and standard deviation**:
   ```python
   import numpy as np
   print("Means after scaling (should be ~0):", np.round(X_scaled.mean(axis=0), 2))
   print("Stds after scaling (should be 1):", np.round(X_scaled.std(axis=0), 2))
   ```
5. Confirm that all means are $0.0$ and all standard deviations are $1.0$.

## Expected Output or Observable Behaviour

Executing these commands outputs:
```text
Means after scaling (should be ~0): [ 0. -0.  0.  0.  0.]
Stds after scaling (should be 1): [1. 1. 1. 1. 1.]
```
This confirms that all 5 features have been successfully transformed onto an identical statistical scale.

## Practical Exercises

- **Exercise 2.1**: Why is scaling critical for distance-based algorithms like KNN, but unnecessary for decision trees?
- **Exercise 2.2**: If a feature has mean $\mu = 100$ and standard deviation $\sigma = 20$, what is the standardized z-score for a raw value of $150$?
- **Exercise 2.3**: What would happen if you used `MinMaxScaler` (scaling to $0-1$) instead of `StandardScaler`? Would KNN still work?
- **Exercise 2.4**: What is the difference between `scaler.fit()` and `scaler.transform()`?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Running KNN without scaling on features with different units | High-magnitude features overpower small-magnitude features, destroying model accuracy. | Always standardize features before training distance-based models like KNN. |
| Fitting the scaler on the test data: `scaler.fit(X_test)` | Violates the fundamental evaluation rule; test data must not be used to compute statistics. | Fit the scaler strictly on `X_train`, then transform `X_test`. |
| Expecting scaled values to stay strictly between 0 and 1 | `StandardScaler` produces z-scores, which typically range from $-3.0$ to $+3.0$ (not $0$ to $1$). | Understand that z-scores measure standard deviations from the mean. |

## Best Practices and Security Considerations

- **Pair Distance Estimators with Scalers**: Whenever using KNN, Support Vector Machines (SVM), Principal Component Analysis (PCA), or Neural Networks, always scale features.
- **Pipeline Integration**: Enclose scalers inside pipelines to prevent accidental omission of scaling during inference.
- **Zero Variance Guard**: If a feature has zero variance ($\sigma = 0$, meaning every sample has the exact same value), standardization involves dividing by zero; remove constant features prior to scaling.

## Summary

Features with large numerical scales (such as RGB color channels ranging up to 255) mathematically dominate Euclidean distance calculations over features with small decimal ranges (such as aspect ratio ~0.9). To ensure all visual clues contribute proportionately, `StandardScaler` standardizes each feature into z-scores by subtracting the mean and dividing by the standard deviation. This sets the mean of each feature to 0 and the variance to 1, providing a balanced geometric space for K-Nearest Neighbors.

## Knowledge-check Questions

1. Why does an unscaled difference of 10 in `mean_g` dominate an unscaled difference of 0.2 in `aspect_ratio`?
2. What is the mathematical formula for z-score standardization used by `StandardScaler`?
3. What are the mean and standard deviation of any feature after being transformed by `StandardScaler`?
4. What role does `scaler.fit()` play versus `scaler.transform()`?
5. Which machine learning algorithms are sensitive to feature scales, and which are generally unaffected?

## References

- Scikit-learn StandardScaler Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.StandardScaler.html
- Scikit-learn Preprocessing Guide: https://scikit-learn.org/stable/modules/preprocessing.html#standardization-or-mean-removal-and-variance-scaling
- The Snack Sorter source code: `main.py` lines 43–48.
