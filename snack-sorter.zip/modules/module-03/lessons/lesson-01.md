# Lesson 01: The Five Hand-Crafted Features in Depth

**Lesson ID:** lesson-01
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain the physical and geometric meaning of each of the 5 visual features in `main.py`.
- Understand how digital color images are represented as 3D arrays of Red, Green, and Blue pixels.
- Explain how background segmentation allows computing `color_fraction` and foreground color means.
- Calculate bounding box dimensions to determine `aspect_ratio`.
- Compare the typical numerical ranges of color channels versus geometric ratios.

## Prerequisites

- Module 02, Lesson 02: Inspecting Image Paths and Visual Feature Columns.
- Basic understanding of fractions, averages, and coordinate geometry.

## Concept Explanation

### The Anatomy of Digital Images
A color digital image is a three-dimensional matrix of numbers with dimensions $(\text{Height}, \text{Width}, \text{Channels})$.
- In standard 24-bit RGB imagery, each pixel has three 8-bit channels: Red ($0-255$), Green ($0-255$), and Blue ($0-255$).
- If an image has an Alpha transparency channel (RGBA), the fourth channel indicates pixel opacity ($0.0$ for fully transparent background, $1.0$ for fully solid fruit).

In **The Snack Sorter**, our 90 snack photos are $64 \times 64$ pixels with transparent backgrounds. Rather than feeding $64 \times 64 \times 4 = 16,384$ raw numbers into our model, we extract 5 intuitive descriptors.

### Feature 1, 2, and 3: The Color Channel Means (`mean_r`, `mean_g`, `mean_b`)
To measure the color of a snack, we isolate all foreground pixels where the fruit is present (ignoring the transparent or white background) and calculate the average intensity for each color channel:
$$\text{mean\_r} = \frac{1}{N_{\text{fruit}}} \sum_{i \in \text{fruit}} R_i, \quad \text{mean\_g} = \frac{1}{N_{\text{fruit}}} \sum_{i \in \text{fruit}} G_i, \quad \text{mean\_b} = \frac{1}{N_{\text{fruit}}} \sum_{i \in \text{fruit}} B_i$$

Why this works across our three fruits:
1. **Apples**: Rich red skin. High Red ($\approx 175$), very low Green ($\approx 45$), low Blue ($\approx 45$).
2. **Bananas**: Bright yellow peel. In additive RGB light, **Red + Green = Yellow**. Bananas have very high Red ($\approx 222$) AND very high Green ($\approx 186$).
3. **Oranges**: Vibrant orange rind. Red + half Green = Orange. Oranges have maximum Red ($\approx 236$), medium Green ($\approx 124$), and very low Blue ($\approx 28$).

### Feature 4: Color Fraction (`color_fraction`)
`color_fraction` represents the percentage of the image canvas occupied by the fruit:
$$\text{color\_fraction} = \frac{N_{\text{fruit pixels}}}{N_{\text{total pixels}}}$$
- If a fruit covers 1,228 pixels in a $64 \times 64$ canvas ($4,096$ pixels), its `color_fraction` is $\frac{1228}{4096} = 0.30$ ($30\%$).
- In our dataset:
  - Bananas are curved and slender, leaving more empty canvas space ($\text{mean} \approx 0.22$).
  - Apples are rounded ($\text{mean} \approx 0.31$).
  - Oranges are broad spherical circles, filling the most canvas area ($\text{mean} \approx 0.34$).

### Feature 5: Aspect Ratio (`aspect_ratio`)
`aspect_ratio` measures the proportion of width to height for the fruit's bounding box:
$$\text{aspect\_ratio} = \frac{\text{Bounding Box Width}}{\text{Bounding Box Height}}$$
- A value of $1.0$ indicates equal width and height (a circle or square).
- In our dataset:
  - Oranges are almost perfectly spherical: `aspect_ratio` averages **$1.00$** (range: $0.98 - 1.03$).
  - Apples are slightly taller than wide: `aspect_ratio` averages **$0.83$** (range: $0.81 - 0.85$).
  - Bananas average **$0.98$** (range: $0.90 - 1.12$).

## Relevant Code (from main.py, line 31)

```python
31: FEATURES = ["mean_r", "mean_g", "mean_b", "color_fraction", "aspect_ratio"]
```

### Code Explanation
- **Line 31**: Explicitly enumerates the 5 hand-crafted visual features extracted from each photo.
- This list is reused across the script: first to select training columns `X = df[FEATURES]` (line 36), and later to slice test instances for prediction `model.predict(test_df[FEATURES])` (line 78).

## Worked Example

**Simulating Feature Extraction on a Single Image Array:**

Suppose we have a $64 \times 64$ image array `img` where pixels have values between 0 and 255.
```python
import numpy as np

# Simulate an apple: foreground pixels where R is high, G is low
# Suppose mask identifies 1,250 foreground pixels out of 4,096 total
n_fruit = 1250
n_total = 64 * 64  # 4096

# Compute color fraction
color_fraction = n_fruit / n_total
print(f"color_fraction: {color_fraction:.4f}")  # 0.3052

# Suppose bounding box has width=45 pixels, height=54 pixels
bbox_w = 45
bbox_h = 54
aspect_ratio = bbox_w / bbox_h
print(f"aspect_ratio: {aspect_ratio:.4f}")      # 0.8333
```
**Interpretation:**
- `color_fraction = 0.3052` matches typical apple coverage (~31%).
- `aspect_ratio = 0.8333` matches typical apple silhouettes (~0.83).
These two shape numbers, combined with the RGB color means, form a unique 5-dimensional fingerprint for each fruit.

## Step-by-Step Student Instructions

1. **Open your terminal** and launch Python.
2. **Inspect feature statistics grouped by fruit**:
   ```python
   import pandas as pd
   df = pd.read_csv("data/snacks.csv")
   features = ["mean_r", "mean_g", "mean_b", "color_fraction", "aspect_ratio"]
   print(df.groupby("label")[features].mean().round(2))
   ```
3. **Inspect the standard deviation to observe consistency within each class**:
   ```python
   print(df.groupby("label")[features].std().round(2))
   ```
4. Notice how small the within-class standard deviations are (e.g., apple aspect ratio std is only $0.01$!), proving these features are highly stable and reliable.

## Expected Output or Observable Behaviour

Running the within-class standard deviation in Python outputs:
```text
        mean_r  mean_g  mean_b  color_fraction  aspect_ratio
label                                                       
apple     2.77    1.59    0.41            0.05          0.01
banana    1.73    1.25    0.42            0.01          0.06
orange    0.43    0.73    0.41            0.04          0.01
```
This shows that within each fruit category, the measurements are remarkably consistent.

## Practical Exercises

- **Exercise 1.1**: Calculate the aspect ratio of a fruit with bounding box width of 50 pixels and height of 50 pixels. Which snack class does this most resemble?
- **Exercise 1.2**: If a snack image has 800 foreground pixels in a $64 \times 64$ canvas, what is its `color_fraction`?
- **Exercise 1.3**: Why is `mean_g` the most informative single color feature for differentiating apples, bananas, and oranges?
- **Exercise 1.4**: Why does `mean_b` have a much smaller range ($27 - 45$) than `mean_r` ($171 - 237$)?

## Common Mistakes and Debugging

| Mistake | Why it's wrong | Correction |
|---|---|---|
| Averaging background pixels into `mean_r/g/b` | Transparent or black background pixels pull color averages towards zero, corrupting the fruit's true color signature. | Foreground color means must only average pixels belonging to the fruit mask. |
| Inverting aspect ratio ($\text{height} / \text{width}$) | Inverting the ratio swaps values (e.g., $0.83$ becomes $1.20$), reversing the geometric interpretation. | Maintain standard convention: $\text{width} / \text{height}$. |
| Treating `color_fraction` as pixel count | Raw pixel counts depend on camera resolution, whereas fractions ($0.0 - 1.0$) are scale-invariant. | Always divide foreground pixels by total canvas pixels. |

## Best Practices and Security Considerations

- **Scale Invariance**: Design geometric features as ratios (like width/height or pixel fractions) so they remain valid even if image resolutions change.
- **Color Space Selection**: While RGB works well here, other color spaces (such as HSV: Hue, Saturation, Value) can provide even stronger robustness against lighting changes.
- **Robust Feature Extraction**: Ensure division by zero is handled safely (e.g., guarding against empty images where height or pixel count is 0).

## Summary

The Snack Sorter distills complex image arrays into 5 hand-crafted features: three foreground color averages (`mean_r`, `mean_g`, `mean_b`), one canvas coverage metric (`color_fraction`), and one geometric silhouette ratio (`aspect_ratio`). RGB additive color mixing allows clean separation between red apples (low green), yellow bananas (high green), and orange oranges (medium green), while aspect ratio and color fraction capture differences in shape and compactness.

## Knowledge-check Questions

1. What are the three color features and two geometric features in `main.py`?
2. How is `color_fraction` calculated from a segmented image?
3. What is the mathematical formula for `aspect_ratio`?
4. Why does an orange have an aspect ratio close to 1.0 while an apple is around 0.83?
5. Why is `mean_g` such a powerful feature for distinguishing between the three fruit classes?

## References

- Digital Image Representation (SciPy): https://scipy-lectures.org/advanced/image_processing/
- RGB Additive Color Model: https://en.wikipedia.org/wiki/RGB_color_model
- The Snack Sorter source code: `main.py` line 31.
