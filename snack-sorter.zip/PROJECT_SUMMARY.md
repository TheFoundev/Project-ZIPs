# Project Summary: The Snack Sorter

A 1-page executive summary of the Snack Sorter AI/ML image classification project.

---

## 1. Problem Definition & Mission
The **Snack Sorter** is a computer vision and supervised machine learning system that automatically classifies snack photos into three fruit categories: **apple**, **banana**, and **orange**. Instead of black-box deep learning, it demonstrates foundational classical computer vision by transforming each photo into **5 interpretable visual features** and applying a **K-Nearest Neighbors (KNN)** classifier.

---

## 2. Dataset At a Glance
- **Source**: `data/snacks.csv` with companion images in `data/images/`.
- **Size**: 90 total samples (exactly 30 apples, 30 bananas, and 30 oranges — perfectly balanced).
- **Inputs ($X$)**: 5 hand-crafted visual features extracted from each image:
  1. `mean_r`: Average red channel pixel intensity ($171.9$ to $237.0$).
  2. `mean_g`: Average green channel pixel intensity ($42.9$ to $187.8$).
  3. `mean_b`: Average blue channel pixel intensity ($26.8$ to $45.5$).
  4. `color_fraction`: Fraction of pixels belonging to the foreground snack ($0.20$ to $0.40$).
  5. `aspect_ratio`: Bounding box width divided by height ($0.79$ to $1.12$).
- **Target ($y$)**: Categorical snack label (`apple`, `banana`, `orange`).

---

## 3. Modeling Workflow & Architecture
1. **Data Partitioning**: Stratified 75/25 train/test split (`random_state=42`) preserving class ratios:
   - Training Set: 67 samples (23 apples, 22 bananas, 22 oranges).
   - Test Set: 23 samples (7 apples, 8 bananas, 8 oranges).
2. **Preprocessing**: `StandardScaler()` normalizes each feature to zero mean ($\mu=0$) and unit variance ($\sigma=1$). This prevents large numerical scales (e.g., RGB channels $\approx 200$) from drowning out small geometric ratios (e.g., aspect ratio $\approx 0.9$).
3. **Classification**: `KNeighborsClassifier(n_neighbors=5)` predicts the fruit label based on majority vote among the 5 nearest training samples in scaled 5-dimensional feature space.
4. **Pipeline Encapsulation**: `Pipeline([("scale", StandardScaler()), ("knn", KNeighborsClassifier(5))])` prevents data leakage and standardizes training and inference into a unified object.

---

## 4. Key Results & Output Artifacts
When executed (`python3 main.py`), the system generates:
- **Test Set Accuracy**: **100.0%** (23 out of 23 test photos correctly classified).
- **Classification Report**: Precision, Recall, and F1-score of **1.00** across all three fruit classes.
- **Generated Artifacts in `outputs/`**:
  1. `sample_snacks.png`: 3x4 contact sheet of training snack examples.
  2. `predictions.png`: 3x3 grid showing 9 test photos with ground truth vs. predicted labels.
  3. `confusion_matrix.png`: Heatmap demonstrating zero off-diagonal misclassifications.
  4. `metrics.txt`: Text record of test accuracy and full scikit-learn classification report.

---

## 5. Technology Stack
- **Python 3**, **pandas**, **numpy**, **matplotlib** (Agg backend), **scikit-learn**.
