# Prerequisites

Before starting **The Snack Sorter** project, ensure you meet the following prerequisites to get the most out of each module.

---

## Skills Required

- **Python Fundamentals**:
  - Variable assignment, data types (`int`, `float`, `str`, `list`, `dict`, `tuple`).
  - Functions, function arguments, and return statements.
  - Basic control flow (`for` loops, list indexing, dictionary lookups).
  - List unpacking and tuple unpacking in loops (`for ax, (_, row), pred in zip(...)`).
- **Data Handling with pandas**:
  - Loading CSV files into pandas DataFrames with `pd.read_csv()`.
  - Selecting columns using single brackets (Series) and list-of-strings (DataFrame subset).
  - Basic filtering (`df[df["label"] == label]`) and inspection (`head()`, `unique()`, `value_counts()`).
- **Foundational Math Intuition**:
  - The Cartesian coordinate plane (2D and multi-dimensional geometry).
  - Euclidean distance formula ($d = \sqrt{\sum (x_i - y_i)^2}$).
  - Averages (mean) and ratios (fractions, aspect ratios).
- **Command Line Navigation**:
  - Changing directories (`cd`), listing directory contents (`ls`), and running Python scripts (`python main.py`).

---

## Tools Required

- **Python 3.8+** (Python 3.9, 3.10, 3.11, or 3.12 recommended).
- **pip** (Python package installer).
- **Code Editor / IDE**: VS Code, PyCharm, or any text editor with Python syntax highlighting.
- **Terminal / Shell**: Bash, Zsh, or Windows PowerShell.

---

## Required Python Packages

The project relies on standard open-source scientific Python packages:

| Package | Minimum Version | Purpose in Snack Sorter |
|---|---|---|
| `pandas` | >= 1.3.0 | Loading `snacks.csv`, indexing features `X` and targets `y`. |
| `numpy` | >= 1.20.0 | Array manipulation and numerical operations. |
| `matplotlib` | >= 3.4.0 | Reading images (`mpimg.imread`), creating grids, rendering confusion matrix. |
| `scikit-learn` | >= 1.0.0 | `StandardScaler`, `KNeighborsClassifier`, `Pipeline`, `train_test_split`, `metrics`. |

---

## Key Conceptual Topics to Review

1. **Classification vs Regression**:
   - Regression predicts continuous quantities (e.g., temperature to cups of lemonade).
   - Classification predicts discrete categories or classes (e.g., apple, banana, orange).
2. **Features vs Target**:
   - Features ($X$): Input measurements extracted from photos (redness, greenness, blueness, coverage, aspect ratio).
   - Target ($y$): The true category or label we want to predict (`apple`, `banana`, `orange`).
3. **RGB Color Model**:
   - Images are composed of pixels with Red, Green, and Blue intensity channels (typically 0–255).
   - Apples are predominantly high in Red and low in Green/Blue.
   - Bananas are high in Red and high in Green (Red + Green = Yellow).
   - Oranges are high in Red with moderate Green (producing orange).
