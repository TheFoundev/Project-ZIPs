# Glossary of Terms: The Snack Sorter

A comprehensive dictionary of artificial intelligence, machine learning, and computer vision concepts used throughout the Snack Sorter project.

---

| Term | Technical Definition | Beginner Explanation |
|---|---|---|
| **Classification** | A supervised learning task where the model predicts a discrete categorical label for an input sample. | Sorting things into distinct buckets or categories (e.g., deciding if a photo is an apple, banana, or orange). |
| **Multi-Class Classification** | Classification involving three or more target categories (as opposed to binary classification with only two categories). | Classifying between more than two options (e.g., 3 snack types: apple, banana, and orange). |
| **K-Nearest Neighbors (KNN)** | A non-parametric, instance-based supervised learning algorithm that classifies new data points based on the majority label of their $k$ closest neighbors in feature space. | The "look around at your neighbors" algorithm. If your 5 closest neighbors in the room are bananas, you are probably a banana too! |
| **Feature ($X$)** | An individual measurable property or characteristic of a phenomenon being observed, represented as a column in a dataset. | The clues or measurements we give to the AI (e.g., redness, greenness, blueness, shape ratio). |
| **Target / Label ($y$)** | The ground-truth answer or category associated with an observation that the model aims to predict. | The correct answer tag attached to each photo (e.g., `"apple"`). |
| **Hand-Crafted Features** | Domain-specific numerical attributes manually extracted from raw data (e.g., images) using explicit mathematical formulas rather than automated deep feature learning. | Custom formulas we design by hand to summarize a picture into 5 simple numbers instead of letting a deep neural net figure it out. |
| **Aspect Ratio** | The ratio of an object's width to its height ($\text{width} / \text{height}$). | How wide an object is compared to how tall it is. A round apple has an aspect ratio close to 0.8–0.9, while an elongated snack would have a different ratio. |
| **Color Fraction** | The proportion of non-background (foreground object) pixels relative to the total number of pixels in an image canvas. | How much of the photo frame is filled by the snack itself versus empty background space. |
| **Euclidean Distance** | The straight-line distance between two points in Euclidean space: $d = \sqrt{\sum (p_i - q_i)^2}$. | Standard ruler distance between points on a graph or in a 5-dimensional feature space. |
| **StandardScaler** | A feature transformation technique that standardizes features by removing the mean and scaling to unit variance ($z = (x - \mu) / \sigma$). | Leveling the playing field so features with large numbers (RGB values 0–255) don't overpower features with tiny numbers (aspect ratio 0.8–1.1). |
| **Data Leakage** | An error where information from outside the training dataset (such as the test set) is used to create or train the model. | Accidental cheating where the AI peeks at the test questions or test statistics before taking the exam. |
| **Pipeline** | A scikit-learn utility that chains multiple data processing steps and estimators into a single cohesive scikit-learn object. | An automated assembly line that guarantees every piece of data gets scaled and then classified in the exact same order. |
| **Stratified Split** | A data splitting technique that partitions a dataset into training and testing subsets while maintaining the exact percentage of each class. | Making sure both the practice test (train set) and final exam (test set) have the exact same recipe: equal proportions of apples, bananas, and oranges. |
| **Accuracy** | The proportion of total predictions that the model got exactly correct: $\frac{\text{Correct Predictions}}{\text{Total Predictions}}$. | The percentage grade on the exam (e.g., 23 out of 23 correct = 100%). |
| **Precision** | The fraction of positive predictions that were actually correct: $\frac{TP}{TP + FP}$. | "When the AI claims a snack is an apple, how often is it actually an apple?" |
| **Recall** | The fraction of actual positive instances that were successfully identified: $\frac{TP}{TP + FN}$. | "Out of all the real apples in the dataset, what fraction did the AI manage to find?" |
| **F1-Score** | The harmonic mean of precision and recall: $2 \times \frac{\text{Precision} \times \text{Recall}}{\text{Precision} + \text{Recall}}$. | A balanced single score that rewards having both high precision and high recall simultaneously. |
| **Support** | The actual number of ground-truth occurrences of each class in the specified evaluation dataset. | The headcount: how many actual apples, bananas, and oranges were in the test set. |
| **Confusion Matrix** | A square matrix table showing the counts of correct and incorrect predictions broken down by true class (rows) versus predicted class (columns). | A diagnostic report card showing not just that the AI made a mistake, but exactly which snack it confused for which other snack. |
| **Matplotlib Agg Backend** | A non-interactive backend for matplotlib that renders graphics to raster image files (PNG/PDF) without opening GUI windows. | Headless mode: lets Python draw and save pictures in the background without needing a computer screen or desktop monitor. |
