# All Correct Answers for Assessments
Project: The Snack Sorter
---

## Module 01: Project Overview & Problem Understanding

**q1-01.** What type of machine learning problem does The Snack Sorter solve?
   **Correct Answer:** b. Supervised multi-class classification
   *Explanation:* The Snack Sorter is a supervised multi-class classification problem because the model learns from labeled image examples (where both features and true fruit names are known) to predict one of three discrete categorical labels: apple, banana, or orange.

**q1-02.** What are the 3 fruit classes that the model is trained to recognize?
   **Correct Answer:** b. Apple, banana, and orange
   *Explanation:* The dataset contains 90 snack photos divided equally across three classes: apple (30 photos), banana (30 photos), and orange (30 photos).

**q1-03.** Which machine learning algorithm is used in main.py to classify the snacks?
   **Correct Answer:** b. KNeighborsClassifier
   *Explanation:* main.py uses scikit-learn's KNeighborsClassifier configured with n_neighbors=5 inside a Pipeline to perform classification based on majority voting among the closest training points.

**q1-04.** How many hand-crafted visual features are defined in the FEATURES list in main.py?
   **Correct Answer:** b. 5 features
   *Explanation:* In main.py line 31, FEATURES is defined as a list of 5 strings: ['mean_r', 'mean_g', 'mean_b', 'color_fraction', 'aspect_ratio'].

**q1-05.** In digital RGB color mixing, why do yellow bananas display high values in both the Red and Green channels?
   **Correct Answer:** b. Because additive combination of red and green light produces yellow perception
   *Explanation:* Digital color monitors and digital cameras operate using the additive RGB color model. Combining red light and green light additively stimulates the eye's cones to perceive yellow. Therefore, yellow bananas produce high values in both mean_r (~222) and mean_g (~186).

**q1-06.** In KNeighborsClassifier(n_neighbors=5), what does the value 5 represent?
   **Correct Answer:** b. The number of closest training examples consulted during majority voting
   *Explanation:* In KNeighborsClassifier, the parameter n_neighbors specifies k, the number of nearest training samples in feature space whose class labels are polled during majority voting to classify an input sample.

**q1-07.** What does the aspect_ratio feature measure in The Snack Sorter?
   **Correct Answer:** c. The ratio of the fruit's bounding box width to its height
   *Explanation:* The aspect_ratio feature is calculated as the bounding width divided by the bounding height of the detected fruit silhouette. Values close to 1.0 indicate roughly circular shapes (like oranges), while values significantly different from 1.0 represent elongated or tall profiles.

**q1-08.** Why does The Snack Sorter extract 5 hand-crafted features instead of passing thousands of raw image pixels directly into KNN?
   **Correct Answer:** b. To avoid the curse of dimensionality and provide stable, interpretable signals on a small 90-image dataset
   *Explanation:* Feeding thousands of raw pixel intensities with only 90 sample photos creates the curse of dimensionality, where models easily overfit to background noise. Distilling images into 5 compact, hand-crafted features provides stable, interpretable signals that allow simple models to generalize cleanly.

**q1-09.** What is the primary architectural purpose of wrapping StandardScaler and KNeighborsClassifier in a scikit-learn Pipeline?
   **Correct Answer:** b. To bundle preprocessing and estimator into a single object, preventing data leakage between train and test sets
   *Explanation:* A scikit-learn Pipeline bundles data transformations (StandardScaler) and the learning model (KNeighborsClassifier) into a unified object. This ensures all transformations are fitted solely on training data and automatically applied to test data without data leakage.

**q1-10.** What critical machine learning error occurs if a StandardScaler is fitted on the entire dataset prior to splitting into train and test sets?
   **Correct Answer:** a. Data leakage, because statistics from the test set contaminate the training process
   *Explanation:* Fitting a scaler on the entire dataset prior to splitting exposes information about the test set's mean and variance to the training environment. This phenomenon is known as data leakage and leads to overly optimistic performance estimates.

## Module 02: Data Loading & Dataset Exploration

**q2-01.** What is the total number of snack photos recorded in data/snacks.csv?
   **Correct Answer:** c. 90 photos
   *Explanation:* The dataset snacks.csv contains 91 total lines in the file (1 header row plus 90 photo data rows).

**q2-02.** How many samples belong to each of the three fruit classes in snacks.csv?
   **Correct Answer:** a. Exactly 30 apples, 30 bananas, and 30 oranges
   *Explanation:* The dataset is perfectly balanced with exactly 30 apples, 30 bananas, and 30 oranges, totaling 90 samples.

**q2-03.** Which pandas function is used in main.py line 35 to load the dataset?
   **Correct Answer:** b. pd.read_csv()
   *Explanation:* In main.py line 35, pandas loads the comma-separated data using pd.read_csv(DATA / 'snacks.csv').

**q2-04.** In main.py line 39, why is df.index passed to train_test_split alongside X and y?
   **Correct Answer:** b. To obtain test index positions so source image files can be loaded for visualization
   *Explanation:* By passing df.index into train_test_split, the split returns idx_train and idx_test, which store the original row indices. This allows test_df = df.loc[idx_test] to retrieve the actual image_path filenames for plotting predictions.

**q2-05.** What does the parameter test_size=0.25 specify in train_test_split?
   **Correct Answer:** b. 25% of the total dataset will be reserved for testing
   *Explanation:* test_size=0.25 reserves 25% of the total dataset samples for the test set, allocating the remaining 75% for training.

**q2-06.** After splitting 90 photos with test_size=0.25, how many photos are allocated to the training and test sets?
   **Correct Answer:** c. 67 training photos and 23 test photos
   *Explanation:* Splitting 90 samples with test_size=0.25 results in 22.5 rounded up to 23 test samples, leaving 67 samples (90 - 23) in the training set.

**q2-07.** What does the parameter stratify=y ensure during data splitting?
   **Correct Answer:** a. It ensures that both train and test sets have the same proportion of each fruit class
   *Explanation:* stratify=y ensures that the train and test subsets maintain the exact same proportion of class labels (approximately 1/3 apple, 1/3 banana, 1/3 orange) as the original dataset.

**q2-08.** What is the purpose of setting random_state=42 in train_test_split?
   **Correct Answer:** b. To ensure reproducible shuffling so the exact same train/test split is generated every run
   *Explanation:* Setting random_state=42 initializes the pseudo-random number generator with a constant seed, ensuring that the shuffling and resulting split are identical every time the code runs.

**q2-09.** If train_test_split is called with three arrays: train_test_split(X, y, df.index, ...), how many variables does it return?
   **Correct Answer:** c. 6 variables
   *Explanation:* Each array passed into train_test_split produces two split arrays (train and test). Passing 3 arrays (X, y, df.index) produces 2 * 3 = 6 returned items: X_train, X_test, y_train, y_test, idx_train, idx_test.

**q2-10.** Why is stratified splitting especially crucial on small datasets like The Snack Sorter?
   **Correct Answer:** a. Because without stratification, random sampling could leave a class severely under-represented in the test set by pure chance
   *Explanation:* With small datasets, pure random sampling has high variance. Without stratification, a class with only 30 samples could easily end up with very few test instances (or even zero), severely distorting evaluation metrics.

## Module 03: Feature Extraction & Preprocessing

**q3-01.** What does scikit-learn's StandardScaler do to input features?
   **Correct Answer:** b. It standardizes features by removing the mean and scaling to unit variance
   *Explanation:* StandardScaler standardizes features by subtracting the mean of each feature and dividing by its standard deviation, resulting in a distribution with zero mean and unit variance.

**q3-02.** After being transformed by StandardScaler, what are the theoretical mean and standard deviation of each feature?
   **Correct Answer:** b. Mean = 0.0, Standard Deviation = 1.0
   *Explanation:* By definition of z-score standardization, subtracting the sample mean shifts the mean to 0.0, and dividing by the standard deviation scales the variance and standard deviation to 1.0.

**q3-03.** Which scikit-learn class is used to chain the preprocessing scaler and the KNN classifier into a single executable object?
   **Correct Answer:** b. sklearn.pipeline.Pipeline
   *Explanation:* In scikit-learn, sklearn.pipeline.Pipeline is used to sequentially chain transformers (like StandardScaler) and estimators (like KNeighborsClassifier) into a unified object.

**q3-04.** Why does unscaled Euclidean distance fail when combining RGB color means (values ~200) with aspect ratios (values ~0.9)?
   **Correct Answer:** b. Because the squared differences of RGB values are thousands of times larger, rendering aspect ratio geometrically negligible
   *Explanation:* Euclidean distance squares the difference between features. A difference of 10 in RGB yields 10^2 = 100, whereas the entire difference across fruits in aspect ratio (0.2) yields only 0.04. The RGB channel difference is thousands of times larger, completely drowning out the shape signal.

**q3-05.** What is the mathematical formula used by StandardScaler to compute the standardized z-score of a value x?
   **Correct Answer:** b. z = (x - mean) / standard_deviation
   *Explanation:* StandardScaler computes z-scores using the formula z = (x - mean) / standard_deviation.

**q3-06.** In a scikit-learn Pipeline, what interface requirement must all intermediate steps satisfy?
   **Correct Answer:** b. They must all be transformers implementing both fit() and transform()
   *Explanation:* All intermediate steps in a scikit-learn Pipeline must be transformers that implement both fit() and transform() (or fit_transform()), because the output of each step must be passed as the input to the next step.

**q3-07.** Which single visual feature exhibits completely non-overlapping value ranges across apples, bananas, and oranges in snacks.csv?
   **Correct Answer:** b. mean_g
   *Explanation:* mean_g (green intensity) exhibits completely distinct, non-overlapping ranges: apples (42.9 - 48.7), oranges (121.7 - 125.1), and bananas (183.8 - 187.8), providing total single-feature separability.

**q3-08.** How do you access the fitted StandardScaler instance inside a fitted pipeline named model?
   **Correct Answer:** b. model.named_steps['scale']
   *Explanation:* In scikit-learn, steps inside a Pipeline are accessible by name through the named_steps attribute, e.g., model.named_steps['scale'].

**q3-09.** When you call model.predict(X_test) on a fitted scikit-learn Pipeline, how does the pipeline process X_test?
   **Correct Answer:** b. It automatically scales X_test using the mean and standard deviation learned during training before querying KNN
   *Explanation:* When model.predict(X_test) is called on a fitted Pipeline, the pipeline automatically calls transform() on each intermediate transformer using the statistics learned during training, and then passes the transformed features to the final estimator.

**q3-10.** Why is it advantageous to retain shape features (aspect_ratio and color_fraction) even though mean_g alone has supreme separability on this dataset?
   **Correct Answer:** b. Because relying on a single color channel creates fragility against lighting shifts and fails if new fruit varieties share similar colors
   *Explanation:* Relying on a single color channel introduces a single point of failure: lighting variations, shadows, camera sensor shifts, or new fruit varieties (like green apples) would cause the model to fail. Multi-modal features (color + geometry) ensure robustness.

## Module 04: Model Training & Prediction

**q4-01.** Which method is called in main.py line 49 to train the Pipeline on the training data?
   **Correct Answer:** b. model.fit(X_train, y_train)
   *Explanation:* In scikit-learn, all models and pipelines are trained by calling the standard .fit() method, e.g., model.fit(X_train, y_train).

**q4-02.** How many photos are passed to model.fit() in main.py?
   **Correct Answer:** b. 67 photos
   *Explanation:* The dataset has 90 photos total. With test_size=0.25, 23 photos go to testing and the remaining 67 photos are passed to model.fit() in X_train.

**q4-03.** Which method generates class predictions for unseen test samples in scikit-learn?
   **Correct Answer:** a. model.predict()
   *Explanation:* In scikit-learn, .predict() is the standard method for generating predictions from a trained model on new, unseen feature matrices.

**q4-04.** What is the return type of matplotlib.image.imread() when decoding a PNG image file?
   **Correct Answer:** b. A NumPy ndarray containing pixel values
   *Explanation:* matplotlib.image.imread() reads image files from disk and returns a NumPy ndarray representing pixel intensity values across image height, width, and color channels.

**q4-05.** Why does main.py call ax.axis('off') when rendering images in subplots?
   **Correct Answer:** b. To hide pixel coordinate tick marks and axis borders for a clean photographic display
   *Explanation:* Calling ax.axis('off') suppresses the outer box border, axis ticks, and numerical pixel coordinates, presenting a clean photographic view of the fruit.

**q4-06.** In main.py line 80, what does axes.ravel() do to the 2D array of subplots created by plt.subplots(3, 3)?
   **Correct Answer:** b. It flattens the 3x3 2D array into a 1D sequence of 9 subplot axes
   *Explanation:* axes.ravel() flattens a multi-dimensional array of axes (like the 3x3 array returned by plt.subplots(3, 3)) into a contiguous 1D array of 9 axes, allowing clean sequential looping.

**q4-07.** In main.py line 80, what is the role of Python's built-in zip() function?
   **Correct Answer:** b. To iterate through axes, test DataFrame rows, and predictions simultaneously in a single loop
   *Explanation:* Python's zip() function aggregates multiple iterables element-by-element, enabling simultaneous iteration over the flattened axes, the DataFrame row records, and the model prediction strings.

**q4-08.** How many test photos are displayed in the outputs/predictions.png grid?
   **Correct Answer:** b. 9 photos
   *Explanation:* In main.py line 77, test_df = df.loc[idx_test].head(9) selects 9 test photos, which are plotted in a 3x3 grid saved as outputs/predictions.png.

**q4-09.** What does model.predict_proba(X_test) return for a KNeighborsClassifier?
   **Correct Answer:** b. An array of class probabilities representing the fraction of the k nearest neighbors voting for each class
   *Explanation:* For KNeighborsClassifier, predict_proba() returns the fraction of the k nearest neighbors voting for each respective class (e.g., if all 5 vote for apple, the probability is 1.0).

**q4-10.** Why does main.py use df.loc[idx_test].head(9) instead of X_test.head(9) when constructing outputs/predictions.png?
   **Correct Answer:** a. Because X_test only contains numerical feature columns, whereas df contains the image_path and true label needed for plotting and titles
   *Explanation:* X_test only contains the 5 numeric feature columns. To display the photo and true label on the plot, the code needs image_path and label, which are stored in the original DataFrame df accessed via df.loc[idx_test].

## Module 05: Evaluation & Metrics

**q5-01.** What test set accuracy does The Snack Sorter achieve on the 23 test photos in main.py?
   **Correct Answer:** d. 100.0%
   *Explanation:* The Snack Sorter achieves 100.0% accuracy on the test set, correctly classifying all 23 test images (7 apples, 8 bananas, 8 oranges).

**q5-02.** Which scikit-learn function prints the table containing precision, recall, f1-score, and support?
   **Correct Answer:** a. classification_report()
   *Explanation:* scikit-learn's classification_report() builds a formatted text report showing precision, recall, f1-score, and support for each class.

**q5-03.** In a confusion matrix, what do numbers on the main diagonal (top-left to bottom-right) represent?
   **Correct Answer:** b. Correct predictions where true class matches predicted class
   *Explanation:* In a confusion matrix, the cells on the main diagonal (where row index equals column index) represent true positives where the model's prediction exactly matches the ground-truth label.

**q5-04.** In a scikit-learn classification report, what does the 'support' column represent?
   **Correct Answer:** b. The number of true ground-truth occurrences of each class in the evaluation set
   *Explanation:* In a classification report, 'support' indicates the actual number of ground-truth occurrences of each class in the target test dataset (here: 7 apples, 8 bananas, 8 oranges).

**q5-05.** What does Precision measure in classification?
   **Correct Answer:** b. The proportion of positive predictions that were actually correct: TP / (TP + FP)
   *Explanation:* Precision measures the proportion of positive predictions that were truly correct: TP / (TP + FP). It answers: 'When the model predicts class C, how often is it right?'

**q5-06.** What does Recall measure in classification?
   **Correct Answer:** b. The fraction of actual positive instances in the data that the model successfully retrieved: TP / (TP + FN)
   *Explanation:* Recall measures the fraction of actual positive instances in the data that the model successfully retrieved: TP / (TP + FN). It answers: 'Out of all real instances of class C, what fraction did the model find?'

**q5-07.** Why is the F1-Score calculated as the harmonic mean of precision and recall rather than their simple arithmetic average?
   **Correct Answer:** b. Because the harmonic mean heavily penalizes models where either precision or recall is very low
   *Explanation:* The harmonic mean 2*(P*R)/(P+R) heavily penalizes extreme imbalances. If either precision or recall is close to 0, the F1-score drops sharply toward 0, unlike the arithmetic mean which could misleadingly stay moderate.

**q5-08.** In main.py line 93, what does the argument cmap='Greens' in ConfusionMatrixDisplay.plot() specify?
   **Correct Answer:** b. It sets the visual color palette of the heatmap to shades of green
   *Explanation:* cmap='Greens' specifies a matplotlib colormap that shades the confusion matrix cells with varying intensities of green based on numerical counts.

**q5-09.** What is the difference between the 'macro avg' and 'weighted avg' rows in a scikit-learn classification report?
   **Correct Answer:** a. Macro average treats all classes equally; weighted average weights each class by its support (sample count)
   *Explanation:* Macro average calculates the unweighted mean of the metric across all classes (treating small and large classes equally), while weighted average weights each class's score by its support.

**q5-10.** Why does main.py pass zero_division=0 to classification_report()?
   **Correct Answer:** b. To suppress runtime ZeroDivisionError warnings and return 0.0 if a class has no positive predictions
   *Explanation:* If a class receives zero positive predictions, the precision denominator (TP + FP) equals zero. Passing zero_division=0 instructs scikit-learn to return 0.0 and suppress runtime warning messages.

## Module 06: Complete Pipeline & Running

**q6-01.** What terminal command executes the complete Snack Sorter pipeline from the project root directory?
   **Correct Answer:** b. python main.py
   *Explanation:* Running `python main.py` from the project root invokes the full end-to-end training, prediction, evaluation, and plotting workflow defined in the script's entrypoint block.

**q6-02.** How many total output artifact files are generated in the outputs/ directory when main.py finishes execution?
   **Correct Answer:** c. 4 files
   *Explanation:* The execution of main.py creates exactly 4 output artifacts in the outputs/ directory: sample_snacks.png, predictions.png, confusion_matrix.png, and metrics.txt.

**q6-03.** Why does main.py wrap its primary workflow execution inside an `if __name__ == '__main__':` block?
   **Correct Answer:** b. To ensure functions and classes can be imported into other scripts or tests without triggering execution of the full pipeline
   *Explanation:* The `if __name__ == '__main__':` pattern allows functions (like load_data or plot_contact_sheet) to be safely imported into other modules or test suites without prematurely triggering the main execution loop.

**q6-04.** In main.py, what specific role does `stratify=y` play during the train/test split of the 90 snack photos?
   **Correct Answer:** c. It preserves the exact class proportion across both training and testing partitions
   *Explanation:* Passing `stratify=y` guarantees that each split partition (train and test) mirrors the exact label frequency distribution of the original dataset (e.g. equal 33.3% representation for apple, banana, and orange).

**q6-05.** If a developer omits `stratify=y` when splitting a small multi-class dataset, what significant risk is introduced?
   **Correct Answer:** b. Random sampling variance could allocate an unrepresentative or zero count of a class to the test partition
   *Explanation:* Without stratification, unconstrained random selection on small sample sets (e.g., 23 test items) can disproportionately under-sample or completely exclude a class from the test set, creating evaluation bias.

**q6-06.** Which output file produced by main.py contains the persistent numerical text record of model performance including accuracy, precision, recall, and support?
   **Correct Answer:** c. outputs/metrics.txt
   *Explanation:* main.py writes the formatted accuracy score and classification report text directly into `outputs/metrics.txt` using Path(OUT / 'metrics.txt').write_text().

**q6-07.** When extending the Snack Sorter pipeline from 3 classes to 4 classes (adding pear), what code modification is required in the `Pipeline([('scaler', StandardScaler()), ('knn', KNeighborsClassifier(n_neighbors=3))])` definition?
   **Correct Answer:** b. Zero code changes are required because Pipeline, StandardScaler, and KNN dynamically infer classes from training labels
   *Explanation:* Scikit-learn's Pipeline, StandardScaler, and KNeighborsClassifier dynamically infer feature counts and unique class labels during the .fit() call, requiring zero changes to estimator instantiation when adding classes.

**q6-08.** What will be the dimensions of the confusion matrix if the Snack Sorter dataset is expanded to include 4 distinct snack classes?
   **Correct Answer:** b. 4 x 4
   *Explanation:* For $K$ classes, a confusion matrix has $K$ true label rows and $K$ predicted label columns, yielding a square $4 \times 4$ matrix when classifying 4 snack types.

**q6-09.** If a fourth fruit class such as lemon is introduced with RGB values nearly identical to banana (yellow color collision), what feature in snacks.csv provides critical discriminative signal to separate them?
   **Correct Answer:** c. Geometric aspect_ratio which captures the difference between elongated banana and elliptical lemon shapes
   *Explanation:* When color features collide (both banana and lemon presenting high red and green values), geometric aspect_ratio provides an independent physical measurement (elongated vs spherical/elliptical) to separate the classes.

**q6-10.** In main.py, what filesystem design pattern ensures that paths like data/snacks.csv and outputs/metrics.txt resolve correctly regardless of the directory from which python is invoked?
   **Correct Answer:** b. Deriving BASE = Path(__file__).resolve().parent and anchoring data and output paths relative to BASE
   *Explanation:* Using `BASE = Path(__file__).resolve().parent` determines the absolute directory containing main.py at runtime, making all subpath operations (`BASE / 'data'` and `BASE / 'outputs'`) resilient against arbitrary terminal execution directories.
