# The Snack Sorter: Visual Fruit Classification with K-Nearest Neighbors

Welcome to **The Snack Sorter**, an introductory artificial intelligence and computer vision project. This project demonstrates how computers can classify real-world objects from images using classical machine learning, hand-crafted feature engineering, and the intuitive **K-Nearest Neighbors (KNN)** algorithm.

---

## 1. Project Title & Overview

**The Snack Sorter** processes a collection of 90 snack photos (apples, bananas, and oranges), extracts 5 numerical descriptors summarizing each photo's color and geometry, and trains a supervised classification pipeline. With 67 training images and 23 unseen test images, the system achieves **100% test accuracy**, saving visual diagnostic plots and performance reports to disk.

---

## 2. Real-World Motivation & Use Case

In modern smart retail, automated grocery self-checkouts, robotic harvesting, and food sorting facilities, cameras continuously capture images of produce. While large deep neural networks (CNNs) are standard in large-scale industry systems, classical feature engineering with lightweight algorithms like KNN offers immense advantages:
- Instant training speed without dedicated GPUs.
- Low memory footprint suitable for embedded microcontrollers or edge sensors.
- High interpretability: engineers know exactly *why* a fruit was classified as an apple (e.g., high red channel, low green, round aspect ratio).

---

## 3. Problem Definition: Multi-Class Image Classification

Unlike regression tasks that predict continuous numerical quantities (e.g., predicting sales from temperature), **classification** sorts observations into discrete categorical labels.
Because our problem involves three distinct categories (`apple`, `banana`, `orange`), it is a **multi-class supervised classification** problem. The model must learn decision boundaries in feature space that cleanly separate all three categories.

---

## 4. Key Machine Learning Concepts

- **Supervised Learning**: Training a model on labeled examples $(X, y)$ where both the visual features and the true fruit labels are known.
- **K-Nearest Neighbors (KNN)**: An instance-based learning algorithm that stores training examples. To classify a new fruit, it measures Euclidean distances in feature space and adopts the majority vote of the $k=5$ closest training neighbors.
- **Feature Scaling**: Standardizing features using `StandardScaler` so that high-magnitude variables (like RGB 0–255) do not overpower low-magnitude variables (like aspect ratio ~0.9).
- **Scikit-Learn Pipeline**: A sequential construct bundling scaling and estimation into an integrated pipeline object, preventing data leakage during training and test evaluation.

---

## 5. Dataset Specification

The dataset resides in `data/` and consists of:
- `data/snacks.csv`: A structured tabular file containing 91 lines (header + 90 sample rows).
- `data/images/`: A folder containing 90 PNG image files (30 apples: `apple_00.png` to `apple_29.png`; 30 bananas: `banana_00.png` to `banana_29.png`; 30 oranges: `orange_00.png` to `orange_29.png`).

The dataset is perfectly balanced, with exactly $33.3\%$ of samples per class.

---

## 6. Feature Dictionary

Each image is distilled into five hand-crafted numerical features:

| Feature Name | Description | Typical Value Range | Intuition / Role |
|---|---|---|---|
| `mean_r` | Average intensity of the red color channel | $171.9$ to $237.0$ | Distinguishes reddish apples and oranges from cooler colors. |
| `mean_g` | Average intensity of the green color channel | $42.9$ to $187.8$ | Separates yellow bananas (high green) and orange fruit (medium green) from red apples (low green). |
| `mean_b` | Average intensity of the blue color channel | $26.8$ to $45.5$ | Captures subtle background and reflection variations. |
| `color_fraction` | Proportion of foreground fruit pixels vs total frame | $0.20$ to $0.40$ | Indicates physical coverage of the snack within the camera frame. |
| `aspect_ratio` | Bounding width divided by bounding height | $0.79$ to $1.12$ | Captures silhouette geometry (apples $\approx 0.83$, bananas $\approx 0.98$, oranges $\approx 1.00$). |

---

## 7. System Architecture & Pipeline Workflow

1. **Path Configuration**: Resolve repository paths using Python's `pathlib.Path`.
2. **Data Loading**: Load `snacks.csv` via `pandas.read_csv`.
3. **Partitioning**: Split into 75% training (67 photos) and 25% test (23 photos) using `train_test_split(stratify=y, random_state=42)`.
4. **Pipeline Fitting**: Fit `Pipeline([("scale", StandardScaler()), ("knn", KNeighborsClassifier(n_neighbors=5))])`.
5. **Prediction**: Pass unseen test features `X_test` through the pipeline.
6. **Visualization**: Generate contact sheets, prediction grids, and confusion matrices using matplotlib.
7. **Artifact Export**: Write image figures and `metrics.txt` to `outputs/`.

---

## 8. Technology Stack & Dependencies

- **Language**: Python 3.8+
- **Data Manipulation**: `pandas`, `numpy`
- **Visualization**: `matplotlib` (with `matplotlib.image` for raster loading)
- **Machine Learning**: `scikit-learn` (`StandardScaler`, `KNeighborsClassifier`, `Pipeline`, `train_test_split`, `metrics`)

---

## 9. Prerequisites & Hardware Requirements

- **Operating System**: Linux, macOS, or Windows.
- **Hardware**: Any modern standard CPU; runs in under 3 seconds with less than 200MB RAM. No GPU required.
- **Prior Knowledge**: Basic Python syntax, introductory pandas usage, and elementary Cartesian coordinate concepts.

---

## 10. Installation & Setup Instructions

Clone the repository and install dependencies in an isolated virtual environment:

```bash
cd "beginner-projects-main/AI-ML Beginners/projects/01_snack_sorter"
python3 -m venv venv
source venv/bin/activate
pip install pandas numpy matplotlib scikit-learn
```

---

## 11. Running the Project Step-by-Step

Execute the complete pipeline with a single command:

```bash
python3 main.py
```

The script will automatically load the data, train the pipeline, generate predictions, output performance metrics in the console, and save all visual artifacts into `outputs/`.

---

## 12. Output Artifacts & File Directory

The project produces four distinct files in the `outputs/` directory:

```text
outputs/
├── sample_snacks.png      # 3x4 grid showing 4 representative photos for apple, banana, and orange
├── predictions.png        # 3x3 grid showing 9 test photos with true vs. predicted annotations
├── confusion_matrix.png   # 3x3 heatmap plot showing classification counts
└── metrics.txt            # Plain-text accuracy score and detailed classification report
```

---

## 13. Evaluation Metrics & Interpreting Results

Console and `metrics.txt` output:
```text
Accuracy: 100.0% (1.0000)

              precision    recall  f1-score   support

       apple       1.00      1.00      1.00         7
      banana       1.00      1.00      1.00         8
      orange       1.00      1.00      1.00         8

    accuracy                           1.00        23
   macro avg       1.00      1.00      1.00        23
weighted avg       1.00      1.00      1.00        23
```

- **Accuracy**: $100\%$ indicates all 23 test images were correctly classified.
- **Precision (1.00)**: When the model predicts a specific fruit, it is correct 100% of the time.
- **Recall (1.00)**: The model successfully found 100% of all apples, bananas, and oranges.
- **Support**: Shows the test class breakdown (7 apples, 8 bananas, 8 oranges).

---

## 14. Troubleshooting & Common Pitfalls

- **Missing Matplotlib Backend**: If running on headless servers or SSH without an X-server, ensure `matplotlib.use("Agg")` is called immediately after importing `matplotlib` and before `pyplot`.
- **Feature Scaling Omission**: Forgetting `StandardScaler` causes KNN distances to be governed almost entirely by RGB values ($0-255$) while ignoring shape and aspect ratios.
- **Data Leakage in Scaling**: Never fit the scaler on the entire dataset. Always use `Pipeline` to ensure `StandardScaler` fits only on `X_train`.

---

## 15. Extensions, Best Practices & Next Steps

1. **Add a Fourth Snack Class**: Introduce images of pears or blueberries into `data/images/`, append extracted features to `data/snacks.csv`, and rerun.
2. **Hyperparameter Tuning**: Experiment with different neighbor counts ($k=1, 3, 7$) or distance weights (`weights='distance'`).
3. **Automate Feature Extraction**: Write a Python script using `mpimg` and `scipy.ndimage` that automatically computes `mean_r`, `mean_g`, `mean_b`, and `aspect_ratio` directly from new raw image files.
