# Setup Guide: The Snack Sorter

This guide walks you through setting up your environment, running the project code, and verifying the expected outputs.

---

## Step 1: Navigate to the Project Directory

Open your terminal and navigate to the project root directory:

```bash
cd "beginner-projects-main/AI-ML Beginners/projects/01_snack_sorter"
```

Verify that you are in the correct directory:

```bash
ls -la
```

You should see:
- `main.py`
- `data/`
  - `snacks.csv`
  - `images/` (containing 90 PNG images: `apple_00.png` through `orange_29.png`)

---

## Step 2: Set Up a Virtual Environment (Recommended)

Creating an isolated Python virtual environment prevents library conflicts:

```bash
# Create virtual environment
python3 -m venv venv

# Activate on Linux/macOS
source venv/bin/activate

# Activate on Windows (Command Prompt)
# venv\Scripts\activate.bat

# Activate on Windows (PowerShell)
# venv\Scripts\Activate.ps1
```

---

## Step 3: Install Required Dependencies

Install the required scientific Python libraries using `pip`:

```bash
pip install pandas numpy matplotlib scikit-learn
```

Or verify existing packages in your environment:

```bash
python3 -c "import pandas, numpy, matplotlib, sklearn; print('All libraries imported successfully!')"
```

---

## Step 4: Inspect the Dataset Files

Before executing the training pipeline, inspect the dataset structure:

```bash
# View the header and first 5 rows of the CSV
head -n 6 data/snacks.csv
```

Expected output:
```text
image_path,label,mean_r,mean_g,mean_b,color_fraction,aspect_ratio
images/apple_00.png,apple,178.57,43.5,44.97,0.3691,0.84
images/apple_01.png,apple,172.5,47.6,45.27,0.2461,0.81
images/apple_02.png,apple,175.47,45.38,44.15,0.3008,0.826
images/apple_03.png,apple,178.2,43.75,44.9,0.3691,0.84
images/apple_04.png,apple,172.13,48.67,44.94,0.2461,0.81
```

Count the total rows:
```bash
wc -l data/snacks.csv
# Output: 91 lines (1 header + 90 photo samples)
```

---

## Step 5: Run the Project

Execute the main pipeline:

```bash
python3 main.py
```

Expected terminal output:
```text
============================================================
THE SNACK SORTER
============================================================
Training photos: 67
Test photos:     23
Accuracy:        100.0%

Classification report:

              precision    recall  f1-score   support

       apple       1.00      1.00      1.00         7
      banana       1.00      1.00      1.00         8
      orange       1.00      1.00      1.00         8

    accuracy                           1.00        23
   macro avg       1.00      1.00      1.00        23
weighted avg       1.00      1.00      1.00        23


Saved:
  outputs/sample_snacks.png
  outputs/predictions.png
  outputs/confusion_matrix.png
  outputs/metrics.txt

Try this: add a fourth snack photo class and rerun the script.
```

---

## Step 6: Verify the Generated Output Artifacts

Check the contents of the newly created `outputs/` folder:

```bash
ls -lh outputs/
```

You should see 4 generated files:
1. `sample_snacks.png` — A 3x4 contact sheet displaying 4 representative training photos for each fruit class.
2. `predictions.png` — A 3x3 test prediction grid displaying 9 unseen test photos annotated with true and predicted labels.
3. `confusion_matrix.png` — A 3x3 heatmap plot illustrating true labels vs predicted labels.
4. `metrics.txt` — Plain text document containing test set accuracy and the complete classification report.

Inspect the metrics text file:
```bash
cat outputs/metrics.txt
```

---

## Step 7: Troubleshooting Common Setup Issues

| Symptom | Cause | Solution |
|---|---|---|
| `ModuleNotFoundError: No module named 'sklearn'` | `scikit-learn` is not installed in the active Python environment. | Run `pip install scikit-learn`. Make sure your virtual environment is active. |
| `UserWarning: Matplotlib is currently using agg...` | Standard non-interactive backend warning when attempting GUI popups. | Normal behavior. `matplotlib.use("Agg")` is intentionally configured for headless artifact generation. |
| `FileNotFoundError: [Errno 2] No such file or directory: 'data/snacks.csv'` | Running the script from a different working directory without resolving paths. | In `main.py`, `BASE = Path(__file__).resolve().parent` ensures robust path resolution. Always run with `python3 main.py`. |
| `KeyError: 'label'` or `KeyError: 'mean_r'` | The CSV file is corrupted or empty. | Check that `data/snacks.csv` contains all 7 columns and 91 lines. |
