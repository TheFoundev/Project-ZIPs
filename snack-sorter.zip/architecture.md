# System Architecture & Design Decisions

This document details the architectural components, data flow, pipeline structure, and design decisions behind **The Snack Sorter**.

---

## 1. High-Level System Architecture

The Snack Sorter implements a classical machine learning computer vision workflow. Instead of training compute-heavy deep convolutional neural networks (CNNs), it extracts **hand-crafted summary statistics** from images and feeds them into a distance-based classifier.

```mermaid
flowchart TD
    subgraph Data Layer
        A1["Raw Images<br/>(90 PNG files)"] --> A2["snacks.csv<br/>(Features + Paths + Labels)"]
    end

    subgraph Data Splitting
        A2 --> B1["Features (X: 5 columns)<br/>Labels (y: apple, banana, orange)"]
        B1 --> B2["train_test_split<br/>(test_size=0.25, stratify=y, random_state=42)"]
        B2 --> C1["Train Set (67 samples)"]
        B2 --> C2["Test Set (23 samples)"]
    end

    subgraph ML Pipeline
        C1 --> D1["scikit-learn Pipeline"]
        D1 --> D2["Step 1: StandardScaler()<br/>(Zero mean, unit variance)"]
        D2 --> D3["Step 2: KNeighborsClassifier(n_neighbors=5)<br/>(Euclidean Distance Voting)"]
    end

    subgraph Inference & Evaluation
        C2 --> E1["model.predict(X_test)"]
        D3 -.-> E1
        E1 --> F1["Evaluation Metrics<br/>(Accuracy, Report, Confusion Matrix)"]
    end

    subgraph Output Generation
        F1 --> G1["metrics.txt"]
        F1 --> G2["confusion_matrix.png"]
        C1 -.-> G3["sample_snacks.png<br/>(3x4 Training Contact Sheet)"]
        C2 -.-> G4["predictions.png<br/>(3x3 True vs Predicted Grid)"]
    end
```

---

## 2. End-to-End Data Flow Pipeline

The end-to-end execution flow in `main.py` proceeds through 8 distinct stages:

1. **Environment & Backend Configuration** (Lines 11–29):
   - Sets `matplotlib.use("Agg")` prior to importing `pyplot` to enable headless rendering without GUI displays.
   - Defines filesystem paths using `pathlib.Path(__file__).resolve().parent`.
   - Creates the `outputs/` folder safely with `OUT.mkdir(exist_ok=True)`.

2. **Feature Definition & Data Ingestion** (Lines 31–38):
   - Defines `FEATURES = ["mean_r", "mean_g", "mean_b", "color_fraction", "aspect_ratio"]`.
   - Reads `data/snacks.csv` into a pandas DataFrame (`90` rows, `7` columns).
   - Isolates the 2D feature matrix `X = df[FEATURES]` and 1D label vector `y = df["label"]`.

3. **Stratified Train/Test Splitting** (Lines 39–41):
   - Partitions data into 75% training (`67` rows) and 25% testing (`23` rows).
   - Passes `df.index` alongside `X` and `y` to preserve original DataFrame index positions (`idx_train`, `idx_test`).
   - Uses `stratify=y` to guarantee equal class proportions across splits (Apples: 23 train / 7 test; Bananas: 22 train / 8 test; Oranges: 22 train / 8 test).
   - Sets `random_state=42` for guaranteed reproducibility.

4. **Pipeline Construction & Model Fitting** (Lines 43–49):
   - Wraps `StandardScaler()` and `KNeighborsClassifier(n_neighbors=5)` inside an `sklearn.pipeline.Pipeline`.
   - Fits the pipeline strictly on `(X_train, y_train)`.
   - `StandardScaler` calculates the training mean ($\mu$) and standard deviation ($\sigma$) for each of the 5 features.
   - `KNeighborsClassifier` stores the scaled training points in an efficient spatial indexing structure.

5. **Inference & Metrics Computation** (Lines 50–60):
   - Passes `X_test` through the pipeline using `model.predict(X_test)`.
   - `Pipeline` automatically scales `X_test` using the saved training parameters ($\mu, \sigma$) before querying KNN.
   - Calculates overall multi-class accuracy via `accuracy_score(y_test, predictions)`.
   - Generates precision, recall, and F1-score via `classification_report(y_test, predictions, zero_division=0)`.

6. **Training Contact Sheet Generation** (Lines 62–74):
   - Iterates through the sorted unique labels (`apple`, `banana`, `orange`).
   - Selects 4 sample images per class from the training pool.
   - Reads raw image arrays using `mpimg.imread()` and plots a 3-row by 4-column figure.
   - Saves to `outputs/sample_snacks.png`.

7. **Test Prediction Visualization** (Lines 76–87):
   - Samples 9 test instances using `df.loc[idx_test].head(9)`.
   - Generates predictions and displays a 3x3 subplot grid showing each image titled with `"true: <label>\npredicted: <label>"`.
   - Saves to `outputs/predictions.png`.

8. **Diagnostic Matrix & Summary Persistence** (Lines 89–107):
   - Computes the $3 \times 3$ confusion matrix with `confusion_matrix(y_test, predictions, labels=labels)`.
   - Renders a heatmap using `ConfusionMatrixDisplay` with `cmap="Greens"`.
   - Saves plot to `outputs/confusion_matrix.png`.
   - Writes test accuracy and classification report to `outputs/metrics.txt`.

---

## 3. Core Architectural Design Decisions

### A. Hand-Crafted Features vs. Deep Convolutional Networks
- **Decision**: Represent each image using 5 summary metrics (`mean_r`, `mean_g`, `mean_b`, `color_fraction`, `aspect_ratio`) rather than raw pixel tensors or deep neural networks (e.g., ResNet, MobileNet).
- **Rationale**:
  - Educational clarity: Beginners can inspect, understand, and plot individual feature numbers.
  - Computational efficiency: Runs in under two seconds on any standard CPU without GPU acceleration or heavy deep learning frameworks (TensorFlow/PyTorch).
  - Data efficiency: Deep networks require thousands of images to generalize without overfitting; KNN with curated features learns reliably on just 90 images.

### B. Standard Scaling Before KNN
- **Decision**: Prepend `StandardScaler()` to `KNeighborsClassifier()` inside a scikit-learn `Pipeline`.
- **Rationale**:
  - KNN determines neighbors using Euclidean distance:
    $$d(p, q) = \sqrt{\sum_{i=1}^n (p_i - q_i)^2}$$
  - In raw form, `mean_r` ranges from `171.9` to `237.0` (span $\approx 65$), whereas `color_fraction` ranges from `0.20` to `0.40` (span $\approx 0.20$).
  - Without scaling, Euclidean distance would be dominated by RGB differences, completely ignoring color coverage and aspect ratio. Scaling normalizes each feature to mean 0 and variance 1, giving equal geometric voice to all 5 features.

### C. Encapsulation via `sklearn.pipeline.Pipeline`
- **Decision**: Chain preprocessing and estimator together using `Pipeline([("scale", StandardScaler()), ("knn", KNeighborsClassifier())])`.
- **Rationale**:
  - Prevents **data leakage**: Scaling parameters ($\mu$ and $\sigma$) are computed exclusively on `X_train`.
  - Simplifies inference: Calling `model.predict(X_test)` automatically applies the exact same transformation learned during training without manual bookkeeping.

### D. Stratified Splitting (`stratify=y`)
- **Decision**: Use `stratify=y` inside `train_test_split`.
- **Rationale**:
  - The dataset contains 90 rows (exactly 30 per fruit).
  - A naive random split could result in an imbalanced test set (e.g., 14 apples, 4 bananas, 5 oranges), distorting metric evaluation.
  - Stratification guarantees that the 25% test set contains proportionally balanced samples (7 apples, 8 bananas, 8 oranges).

### E. Retaining Original Indices (`df.index`)
- **Decision**: Pass `df.index` into `train_test_split` alongside `X` and `y` (`idx_train, idx_test`).
- **Rationale**:
  - Enables downstream visualization scripts to map test samples back to their source image files in `data/images/` via `df.loc[idx_test]`.
