# Mentor Solution Guide: The Snack Sorter

## Overview

This guide walks mentors and instructors through the expected reference implementation of **The Snack Sorter** final project. Students must reproduce the architecture and behavior of `main.py` exactly. Mentors should verify that student code adheres to machine learning best practices (specifically avoiding data leakage during feature standardization and stratified sampling) and generates all four required output artifacts.

---

## Solution Architecture & Checkpoints

The reference solution is structured into modular functions anchored by standard scikit-learn and matplotlib pipelines.

### Checkpoint 1: Backend and Imports (lines 12-25)

```python
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pathlib import Path
from PIL import Image
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
```

**What mentors should verify:**
- `matplotlib.use("Agg")` is invoked **strictly before** `import matplotlib.pyplot as plt`. If imported in reverse order, GUI backend conflicts will occur in headless execution environments.
- PIL's `Image` class is imported for raster image reading.
- Scikit-learn imports include `train_test_split`, `StandardScaler`, `KNeighborsClassifier`, `Pipeline`, and the three metric functions (`accuracy_score`, `classification_report`, `confusion_matrix`).
- No extraneous deep learning packages (TensorFlow, PyTorch) or heavy computer vision suites (OpenCV) are required.

**Common student errors:**
- Forgetting `matplotlib.use("Agg")`, causing display warnings or hangs in headless CI runners.
- Importing `KNeighborsClassifier` from `sklearn.cluster` instead of `sklearn.neighbors`.

---

### Checkpoint 2: Path Architecture Setup (lines 27-30)

```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)
```

**What mentors should verify:**
- `Path(__file__).resolve().parent` is used rather than `Path.cwd()` or `os.getcwd()`. This ensures paths resolve consistently regardless of which directory the command line starts from.
- `OUT.mkdir(exist_ok=True)` creates `outputs/` safely without crashing if the folder already exists.

---

### Checkpoint 3: Data Ingestion (`load_data()`, lines 32-47)

```python
def load_data():
    df = pd.read_csv(DATA / "snacks.csv")
    features = ["mean_r", "mean_g", "mean_b", "color_fraction", "aspect_ratio"]
    X = df[features].values
    y = df["label"].values
    paths = df["image_path"].values
    return X, y, paths, df
```

**What mentors should verify:**
- `snacks.csv` is read using the `DATA` path constant.
- Feature column list matches the 5 expected handcrafted features exactly.
- `X` is extracted as a 2D array of shape `(90, 5)`.
- `y` is extracted as a 1D vector of shape `(90,)`.
- `paths` contains the relative image file paths for contact sheet and prediction visualizations.

---

### Checkpoint 4: Stratified Splitting (lines 49-52)

```python
X, y, paths, df = load_data()

X_train, X_test, y_train, y_test, paths_train, paths_test = train_test_split(
    X, y, paths, test_size=0.25, random_state=42, stratify=y
)
```

**What mentors should verify:**
- `train_test_split` receives `X`, `y`, and `paths` simultaneously in that order.
- `test_size=0.25` produces exactly 67 train and 23 test samples.
- `random_state=42` ensures identical partition splits across all student submissions.
- `stratify=y` is explicitly supplied.

**Common student errors:**
- Splitting `X` and `y` without `paths`, then trying to slice `paths` separately with different random seeds.
- Omitting `stratify=y`, leading to uneven class counts in the test partition.

---

### Checkpoint 5: Pipeline & Model Training (lines 53-56)

```python
model = Pipeline([
    ("scaler", StandardScaler()),
    ("knn", KNeighborsClassifier(n_neighbors=3))
])

model.fit(X_train, y_train)
```

**What mentors should verify:**
- `Pipeline` encapsulates both `StandardScaler` and `KNeighborsClassifier`.
- `n_neighbors` is set to `3`.
- `model.fit(X_train, y_train)` is called **only on the training partition**. The test set must not be seen during training.

---

### Checkpoint 6: Inference & Metrics Calculation (lines 57-61)

```python
predictions = model.predict(X_test)
acc = accuracy_score(y_test, predictions)
report = classification_report(y_test, predictions, zero_division=0)
```

**What mentors should verify:**
- Predictions are generated on `X_test`.
- `accuracy_score` evaluates `(y_test, predictions)` and yields `1.0000`.
- `classification_report` uses `zero_division=0` to prevent division-by-zero warnings.

---

### Checkpoint 7: Visualizing Training Samples (`plot_contact_sheet`, lines 63-74)

```python
def plot_contact_sheet(paths_train, y_train):
    fig, axes = plt.subplots(3, 3, figsize=(8, 8))
    fig.suptitle("Sample Training Snacks", fontsize=14, fontweight="bold")
    classes = np.unique(y_train)
    indices = []
    for c in classes:
        cls_idx = np.where(y_train == c)[0][:3]
        indices.extend(cls_idx)
    for ax, idx in zip(axes.flat, indices):
        img = Image.open(BASE / paths_train[idx])
        ax.imshow(img)
        ax.set_title(y_train[idx], fontsize=11, color="green")
        ax.axis("off")
    plt.tight_layout()
    plt.savefig(OUT / "sample_snacks.png", dpi=150)
    plt.close()
```

**What mentors should verify:**
- A $3 \times 3$ grid is created.
- 3 representative photos are selected per class (total 9 images).
- Titles are displayed in green.
- Image axes are turned off (`axis("off")`).
- Figure is closed with `plt.close()` after saving to prevent memory leaks.

---

### Checkpoint 8: Visualizing Test Predictions (`plot_prediction_grid`, lines 76-87)

```python
def plot_prediction_grid(paths_test, y_test, predictions):
    fig, axes = plt.subplots(3, 3, figsize=(8, 8))
    fig.suptitle("Snack Predictions (Test Set)", fontsize=14, fontweight="bold")
    for i, ax in enumerate(axes.flat):
        if i >= len(y_test) or i >= 9:
            break
        img = Image.open(BASE / paths_test[i])
        ax.imshow(img)
        color = "green" if predictions[i] == y_test[i] else "red"
        ax.set_title(f"Pred: {predictions[i]}\nTrue: {y_test[i]}", fontsize=10, color=color)
        ax.axis("off")
    plt.tight_layout()
    plt.savefig(OUT / "predictions.png", dpi=150)
    plt.close()
```

**What mentors should verify:**
- 9 test samples are displayed in a $3 \times 3$ grid.
- Green text denotes correct classification; red text denotes misclassification.
- Saved to `outputs/predictions.png`.

---

### Checkpoint 9: Confusion Matrix Heatmap (`plot_confusion_matrix`, lines 89-98)

```python
def plot_confusion_matrix(y_test, predictions):
    labels = np.unique(y_test)
    cm = confusion_matrix(y_test, predictions, labels=labels)
    fig, ax = plt.subplots(figsize=(6, 5))
    im = ax.imshow(cm, cmap="Blues")
    plt.colorbar(im)
    ax.set_xticks(range(len(labels)))
    ax.set_yticks(range(len(labels)))
    ax.set_xticklabels(labels)
    ax.set_yticklabels(labels)
    ax.set_xlabel("Predicted label")
    ax.set_ylabel("True label")
    ax.set_title("Confusion Matrix")
    for i in range(len(labels)):
        for j in range(len(labels)):
            ax.text(j, i, str(cm[i, j]), ha="center", va="center",
                    color="white" if cm[i, j] > cm.max() / 2 else "black")
    plt.tight_layout()
    plt.savefig(OUT / "confusion_matrix.png", dpi=150)
    plt.close()
```

**What mentors should verify:**
- `confusion_matrix` calculates the $3 \times 3$ matrix with `labels=labels`.
- Heatmap uses `cmap="Blues"` and includes a colorbar.
- Center cell values are annotated as integers (`7`, `8`, `8`).
- Contrast coloring (`white` if $> \text{max}/2$ else `black`) ensures legibility.

---

### Checkpoint 10: Persistent Logging & Entrypoint (lines 99-111)

```python
    summary = (
        f"=== Snack Sorter Evaluation Metrics ===\n"
        f"Total test samples: {len(y_test)}\n"
        f"Accuracy: {acc:.4f}\n\n"
        f"Classification Report:\n{report}\n"
    )
    (OUT / "metrics.txt").write_text(summary, encoding="utf-8")

if __name__ == "__main__":
    main()
```

**What mentors should verify:**
- `metrics.txt` is written using `write_text(..., encoding="utf-8")`.
- The entrypoint uses `if __name__ == "__main__":` to encapsulate execution.

---

## Complete Reference Implementation (`main.py`)

```python
"""
The Snack Sorter: Classifying Snack Photos Using Hand-Crafted Visual Features.

Pipeline:
  1. Load hand-crafted visual features and photo paths from data/snacks.csv.
  2. Train/test split with stratification.
  3. Feature standardization (StandardScaler) + K-Nearest Neighbors (KNN).
  4. Evaluate accuracy, precision, recall, and confusion matrix.
  5. Produce visual artifacts:
     - outputs/sample_snacks.png   : contact sheet of training images
     - outputs/predictions.png     : test predictions with visual labels
     - outputs/confusion_matrix.png: multi-class confusion matrix heatmap
     - outputs/metrics.txt         : evaluation summary
"""

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pathlib import Path
from PIL import Image
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)


def load_data():
    df = pd.read_csv(DATA / "snacks.csv")
    features = ["mean_r", "mean_g", "mean_b", "color_fraction", "aspect_ratio"]
    X = df[features].values
    y = df["label"].values
    paths = df["image_path"].values
    return X, y, paths, df


def plot_contact_sheet(paths_train, y_train):
    fig, axes = plt.subplots(3, 3, figsize=(8, 8))
    fig.suptitle("Sample Training Snacks", fontsize=14, fontweight="bold")
    classes = np.unique(y_train)
    indices = []
    for c in classes:
        cls_idx = np.where(y_train == c)[0][:3]
        indices.extend(cls_idx)
    for ax, idx in zip(axes.flat, indices):
        img = Image.open(BASE / paths_train[idx])
        ax.imshow(img)
        ax.set_title(y_train[idx], fontsize=11, color="green")
        ax.axis("off")
    plt.tight_layout()
    plt.savefig(OUT / "sample_snacks.png", dpi=150)
    plt.close()


def plot_prediction_grid(paths_test, y_test, predictions):
    fig, axes = plt.subplots(3, 3, figsize=(8, 8))
    fig.suptitle("Snack Predictions (Test Set)", fontsize=14, fontweight="bold")
    for i, ax in enumerate(axes.flat):
        if i >= len(y_test) or i >= 9:
            break
        img = Image.open(BASE / paths_test[i])
        ax.imshow(img)
        color = "green" if predictions[i] == y_test[i] else "red"
        ax.set_title(f"Pred: {predictions[i]}\nTrue: {y_test[i]}", fontsize=10, color=color)
        ax.axis("off")
    plt.tight_layout()
    plt.savefig(OUT / "predictions.png", dpi=150)
    plt.close()


def plot_confusion_matrix(y_test, predictions):
    labels = np.unique(y_test)
    cm = confusion_matrix(y_test, predictions, labels=labels)
    fig, ax = plt.subplots(figsize=(6, 5))
    im = ax.imshow(cm, cmap="Blues")
    plt.colorbar(im)
    ax.set_xticks(range(len(labels)))
    ax.set_yticks(range(len(labels)))
    ax.set_xticklabels(labels)
    ax.set_yticklabels(labels)
    ax.set_xlabel("Predicted label")
    ax.set_ylabel("True label")
    ax.set_title("Confusion Matrix")
    for i in range(len(labels)):
        for j in range(len(labels)):
            ax.text(j, i, str(cm[i, j]), ha="center", va="center",
                    color="white" if cm[i, j] > cm.max() / 2 else "black")
    plt.tight_layout()
    plt.savefig(OUT / "confusion_matrix.png", dpi=150)
    plt.close()


def main():
    X, y, paths, df = load_data()
    print(f"Loaded {len(df)} snack photos (features: {list(df.columns[1:6])})")
    print(f"Classes: {sorted(list(set(y)))}")

    X_train, X_test, y_train, y_test, paths_train, paths_test = train_test_split(
        X, y, paths, test_size=0.25, random_state=42, stratify=y
    )
    print(f"Training set: {len(X_train)} samples, Test set: {len(X_test)} samples")

    model = Pipeline([
        ("scaler", StandardScaler()),
        ("knn", KNeighborsClassifier(n_neighbors=3))
    ])
    print(f"Model: {model}")

    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    acc = accuracy_score(y_test, predictions)
    print(f"Test Accuracy: {acc:.4f}\n")

    report = classification_report(y_test, predictions, zero_division=0)
    print("Classification Report:")
    print(report)

    plot_contact_sheet(paths_train, y_train)
    print(f"Saved {OUT / 'sample_snacks.png'}")

    plot_prediction_grid(paths_test, y_test, predictions)
    print(f"Saved {OUT / 'predictions.png'}")

    plot_confusion_matrix(y_test, predictions)
    print(f"Saved {OUT / 'confusion_matrix.png'}")

    summary = (
        f"=== Snack Sorter Evaluation Metrics ===\n"
        f"Total test samples: {len(y_test)}\n"
        f"Accuracy: {acc:.4f}\n\n"
        f"Classification Report:\n{report}\n"
    )
    (OUT / "metrics.txt").write_text(summary, encoding="utf-8")
    print(f"Saved {OUT / 'metrics.txt'}")
    print("Snack Sorter pipeline complete!")


if __name__ == "__main__":
    main()
```

---

## Grading & Verification Checklist

| Item | Requirement | Points |
| :--- | :--- | :---: |
| 1 | Execution runs clean via `python main.py` with zero exit code | 10 |
| 2 | Features and target arrays loaded with correct dimensions | 15 |
| 3 | Split matches 67 train / 23 test with `stratify=y` and `random_state=42` | 10 |
| 4 | Pipeline properly wraps `StandardScaler` and `KNeighborsClassifier(3)` | 15 |
| 5 | Evaluates test accuracy as 1.0000 with complete classification report | 15 |
| 6 | Generates `sample_snacks.png` ($3 \times 3$ contact sheet) | 10 |
| 7 | Generates `predictions.png` ($3 \times 3$ grid with colored labels) | 10 |
| 8 | Generates `confusion_matrix.png` (annotated heatmap with colorbar) | 15 |
| 9 | Persists `metrics.txt` and formats terminal output correctly | 15 |
| **Total** | | **105** |
