# Final Project Requirements: The Snack Sorter

## Project Objective

Reproduce the complete **Snack Sorter** machine learning pipeline from scratch, adhering strictly to the architecture and implementation in `main.py`. Your implementation must load tabular visual features and associated snack photos from `data/snacks.csv`, perform a stratified train/test split, train a scikit-learn `Pipeline` combining feature standardization and $K$-Nearest Neighbors classification ($k=3$), evaluate model performance, generate three distinct visualization artifacts, and persist full evaluation metrics to disk.

---

## Functional Requirements

### 1. Environment & Path Architecture
- Configure the non-interactive matplotlib backend (`matplotlib.use("Agg")`) prior to importing `matplotlib.pyplot`.
- Use Python's standard `pathlib.Path` to anchor paths dynamically relative to `Path(__file__).resolve().parent`.
- Define path constants:
  - `BASE`: Project root directory.
  - `DATA`: Points to `BASE / "data"`.
  - `OUT`: Points to `BASE / "outputs"`.
- Ensure the `outputs/` directory is automatically created at runtime using `OUT.mkdir(exist_ok=True)`.

### 2. Dataset Loading & Feature Selection
- Implement a dedicated `load_data()` function that:
  - Loads `data/snacks.csv` via `pandas.read_csv()`.
  - Defines the feature columns: `["mean_r", "mean_g", "mean_b", "color_fraction", "aspect_ratio"]`.
  - Extracts the feature matrix `X` as a pandas DataFrame or numpy array with shape `(90, 5)`.
  - Extracts the ground-truth target vector `y` as a pandas Series or 1D numpy array with shape `(90,)`.
  - Extracts image relative paths `paths` as a list or Series of 90 strings.
  - Returns `X`, `y`, `paths`, and `df`.

### 3. Stratified Train/Test Splitting
- Split the dataset using `sklearn.model_selection.train_test_split`:
  - `test_size=0.25` (allocating 67 training samples and 23 test samples).
  - `random_state=42` (ensuring deterministic reproducibility).
  - `stratify=y` (ensuring balanced representation of apple, banana, and orange across both splits).
- Include image file paths in the split (`paths_train`, `paths_test`) so visual inspection plots correspond to the exact split partitions.

### 4. Pipeline Construction & Model Training
- Build a scikit-learn `Pipeline` containing two sequential stages:
  1. `"scaler"`: `sklearn.preprocessing.StandardScaler()` (standardizes features by subtracting sample mean and scaling to unit variance).
  2. `"knn"`: `sklearn.neighbors.KNeighborsClassifier(n_neighbors=3)` (classifies based on majority voting of 3 nearest neighbors using Euclidean distance).
- Fit the pipeline using **training data only**: `model.fit(X_train, y_train)`. Do not expose test data during the fitting step.

### 5. Prediction & Quantitative Evaluation
- Generate categorical predictions on the unseen test set: `predictions = model.predict(X_test)`.
- Compute overall classification accuracy using `sklearn.metrics.accuracy_score(y_test, predictions)`.
- Generate a comprehensive multi-class classification report using `sklearn.metrics.classification_report(y_test, predictions, zero_division=0)`.
- Verify that test accuracy achieves 100% (1.0000) on the reference dataset.

### 6. Visualization 1: Training Contact Sheet (`sample_snacks.png`)
- Implement a function `plot_contact_sheet(paths_train, y_train)`:
  - Randomly or deterministically select 9 photos from the training set (3 samples each of apple, banana, and orange).
  - Create a $3 \times 3$ subplot grid with `figsize=(8, 8)`.
  - Open each image from disk using `PIL.Image.open(BASE / p)`.
  - Display each image without axis ticks (`ax.axis("off")`).
  - Label each subplot with its true class name in green (`color="green"`, `fontsize=11`).
  - Save to `outputs/sample_snacks.png` using `dpi=150` and call `plt.close()`.

### 7. Visualization 2: Prediction Grid (`predictions.png`)
- Implement a function `plot_prediction_grid(paths_test, y_test, predictions)`:
  - Select 9 photos from the test set for visual validation.
  - Create a $3 \times 3$ subplot grid with `figsize=(8, 8)`.
  - Open and display each test image without axis ticks.
  - If predicted label matches true label, format title as `f"Pred: {pred}\nTrue: {true}"` in green (`color="green"`). If incorrect, use red (`color="red"`).
  - Save to `outputs/predictions.png` using `dpi=150` and call `plt.close()`.

### 8. Visualization 3: Confusion Matrix Heatmap (`confusion_matrix.png`)
- Implement a function `plot_confusion_matrix(y_test, predictions)`:
  - Derive unique class labels: `labels = sorted(list(set(y_test)))`.
  - Compute the $3 \times 3$ confusion matrix using `sklearn.metrics.confusion_matrix(y_test, predictions, labels=labels)`.
  - Create a figure with `figsize=(6, 5)`.
  - Plot heatmap using `plt.imshow(cm, cmap="Blues")`.
  - Annotate each cell with its integer count formatted at cell center.
  - Add colorbar, axis labels ("Predicted label" on X, "True label" on Y), and tick labels matching the class names.
  - Save to `outputs/confusion_matrix.png` using `dpi=150` and call `plt.close()`.

### 9. Persistent File Metrics Logging (`metrics.txt`)
- Construct a formatted summary string containing:
  - Header: `"=== Snack Sorter Evaluation Metrics ==="`.
  - Total test samples count: `len(y_test)`.
  - Overall accuracy formatted to 4 decimal places: `f"Accuracy: {acc:.4f}"`.
  - Full classification report text.
- Write this string to `outputs/metrics.txt` using UTF-8 text encoding.

### 10. Console Output Requirements
- Print informative execution logs to stdout matching the following format:
```text
Loaded 90 snack photos (features: ['mean_r', 'mean_g', 'mean_b', 'color_fraction', 'aspect_ratio'])
Classes: ['apple', 'banana', 'orange']
Training set: 67 samples, Test set: 23 samples
Model: Pipeline(steps=[('scaler', StandardScaler()), ('knn', KNeighborsClassifier(n_neighbors=3))])
Test Accuracy: 1.0000

Classification Report:
              precision    recall  f1-score   support

       apple       1.00      1.00      1.00         7
      banana       1.00      1.00      1.00         8
      orange       1.00      1.00      1.00         8

    accuracy                           1.00        23
   macro avg       1.00      1.00      1.00        23
weighted avg       1.00      1.00      1.00        23

Saved outputs/sample_snacks.png
Saved outputs/predictions.png
Saved outputs/confusion_matrix.png
Saved outputs/metrics.txt
Snack Sorter pipeline complete!
```

---

## Deliverables & Acceptance Checklist

To receive full marks, your implementation repository must contain:
- [ ] A functioning `main.py` executable from root via `python main.py`.
- [ ] Correctly populated `outputs/` directory containing all 4 artifacts:
  - [ ] `sample_snacks.png` ($3 \times 3$ grid of labeled training images).
  - [ ] `predictions.png` ($3 \times 3$ grid of test predictions with green/red titles).
  - [ ] `confusion_matrix.png` ($3 \times 3$ annotated confusion heatmap).
  - [ ] `metrics.txt` (text file with accuracy and classification report).
- [ ] Complete adherence to scikit-learn best practices (no data leakage, proper pipeline encapsulation).
