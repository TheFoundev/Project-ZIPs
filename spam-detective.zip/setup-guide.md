# Setup Guide

## Step 1: Navigate to Project
```bash
cd beginner-projects-main/AI-ML\ Beginners/projects/04_spam_detective
```

## Step 2: Install Dependencies
```bash
pip install pandas numpy matplotlib scikit-learn
```

Or create `requirements.txt`:
```txt
pandas
numpy
matplotlib
scikit-learn
```
```bash
pip install -r requirements.txt
```

## Step 3: Understand Data
Look at `data/messages.csv`:
```bash
head data/messages.csv
```
The dataset contains 80 rows with two columns:
- `text`: the body of the message (SMS or email excerpt)
- `label`: binary target category (`spam` or `ham`)

## Step 4: Run the Project
```bash
python main.py
```

## Step 5: Check Outputs
- Console: Accuracy (100.0%), classification report, top spam and normal clue words, new message predictions
- `outputs/top_words.png`: Clue strength horizontal bar charts for spam and ham
- `outputs/confusion_matrix.png`: Confusion matrix heatmap
- `outputs/predictions.txt`: Summary text report with metrics and sample predictions
