# Architecture

## Pipeline (from main.py)
1. **Imports & Setup** - Configure matplotlib headless `'Agg'` backend, import libraries, resolve filesystem paths using `pathlib.Path`, and create `outputs/` directory
2. **Data Ingestion** - Load `data/messages.csv` into a pandas DataFrame (80 messages: 40 ham, 40 spam)
3. **Train/Test Split** - Stratified 75/25 split with `train_test_split(df["text"], df["label"], test_size=0.25, random_state=42, stratify=df["label"])`
4. **Pipeline Construction** - Encapsulate `CountVectorizer(stop_words="english", ngram_range=(1, 2))` and `MultinomialNB()` into a scikit-learn `Pipeline`
5. **Model Training** - Fit pipeline on `X_train` (60 messages) to learn 288 vocabulary features and class conditional probabilities
6. **Evaluation** - Generate predictions on `X_test` (20 messages), compute accuracy, print classification report, and build confusion matrix
7. **Feature Interpretability** - `top_words()` calculates difference in `feature_log_prob_` between classes to identify the top 10 discriminative keywords for spam and ham
8. **Live Inference** - Predict labels and probability distributions for 4 new sample messages using `predict()` and `predict_proba()`
9. **Visualization** - Render dual horizontal bar charts (`outputs/top_words.png`) and confusion matrix display (`outputs/confusion_matrix.png`)
10. **Persistence** - Write test accuracy, classification report, and sample message predictions to `outputs/predictions.txt`

## Key Components
- **Data**: Curated text messages labeled as spam or ham (`messages.csv`)
- **Vectorizer**: CountVectorizer converting text strings into token count matrices using unigrams and bigrams without English stop words
- **Classifier**: Multinomial Naive Bayes estimating posterior class probabilities via Bayes' theorem with Laplace smoothing
- **Metrics**: Accuracy, Precision, Recall, F1-Score, Confusion Matrix
- **Visualizations**: Dual horizontal bar charts and ConfusionMatrixDisplay

## Data Flow
`messages.csv` → pandas DataFrame → stratified split (`X_train`, `X_test`, `y_train`, `y_test`) → `Pipeline(CountVectorizer + MultinomialNB)` → predictions & metrics → `top_words()` log-odds extraction → live sample inference → plots (`top_words.png`, `confusion_matrix.png`) + report (`predictions.txt`)
