# Glossary

| Term | Definition |
|---|---|
| Binary Classification | Supervised learning task predicting one of two mutually exclusive categories (spam vs ham) |
| Ham | Industry standard term for legitimate, authentic, non-spam messages |
| Spam | Unsolicited, bulk, deceptive, or malicious communications |
| Naive Bayes | Probabilistic classifier applying Bayes' theorem with the assumption of conditional feature independence |
| MultinomialNB | Scikit-learn classifier implementing Naive Bayes for discrete counts (e.g., word count frequencies in text) |
| Bayes' Theorem | Mathematical principle stating $P(C \mid X) = \frac{P(X \mid C) \cdot P(C)}{P(X)}$, used to calculate class probability from feature evidence |
| CountVectorizer | Scikit-learn transformer that converts a collection of text documents to a numerical matrix of token counts |
| Bag-of-Words (BoW) | NLP text representation that counts word frequencies while disregarding grammar and word order |
| N-gram | Contiguous sequence of $n$ items from a text; unigram is 1 word, bigram is a 2-word sequence (e.g., 'free shipping') |
| Stop Words | High-frequency function words (e.g., 'the', 'is', 'at') removed during preprocessing because they carry minimal discriminative signal |
| Laplace Smoothing | Technique adding pseudo-counts ($\alpha=1.0$) to prevent zero probability when encountering unseen words |
| Pipeline | Scikit-learn utility that chains transformers and an estimator into a single composite estimator, preventing data leakage |
| Stratified Split | Dataset splitting method (`stratify=y`) preserving the percentage of each target class across train and test sets |
| Log-Odds Ratio | Difference between class log probabilities ($\log P(w \mid \text{spam}) - \log P(w \mid \text{ham})$) indicating keyword clue strength |
| Accuracy | Proportion of total correct predictions out of all samples evaluated |
| Precision | Ratio of true positives to all predicted positives ($TP / (TP + FP)$); measures filter exactness |
| Recall | Ratio of true positives to all actual positives ($TP / (TP + FN)$); measures filter completeness |
| F1-Score | Harmonic mean of precision and recall ($2 \cdot \frac{\text{Precision} \cdot \text{Recall}}{\text{Precision} + \text{Recall}}$) |
| Confusion Matrix | 2x2 matrix tabulating True Negatives, False Positives, False Negatives, and True Positives |
| False Positive (FP) | An authentic message ('ham') mistakenly classified as 'spam' |
| False Negative (FN) | An unwanted message ('spam') mistakenly classified as 'ham' |
| predict_proba | Scikit-learn method returning the posterior probability distribution across all target classes |
