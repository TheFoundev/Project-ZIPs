# Mentor Solution Guide: Spam Detective

## Overview

This guide provides instructors and mentors with the reference implementation architecture, verification checkpoints, rubric grading standards, and troubleshooting procedures for the **Spam Detective** AI-ML curriculum project.

The canonical implementation is located at `beginner-projects-main/AI-ML Beginners/projects/04_spam_detective/main.py`. Mentors should verify that student solutions mirror the architectural design decisions and produce equivalent quantitative results.

---

## Architecture and Execution Flow

```
[data/messages.csv] (80 messages: 40 ham, 40 spam)
         │
         ▼
[Stratified Split] (75% Train / 25% Test, random_state=42)
   ├── Train: 60 messages (30 ham, 30 spam)
   └── Test:  20 messages (10 ham, 10 spam)
         │
         ▼
[Pipeline.fit(X_train, y_train)]
   ├── Step 1: CountVectorizer(stop_words='english', ngram_range=(1,2)) -> 288 features
   └── Step 2: MultinomialNB()
         │
         ├────────────────────────────────────────┬────────────────────────────────────────┐
         ▼                                        ▼                                        ▼
[Quantitative Evaluation]               [Log-Odds Clue Extraction]                [Live Test Inference]
   - Accuracy: 1.0 (100.0%)               - top_words(model, spam_index)            - 4 sample messages
   - Classification Report (1.00 F1)      - top_words(model, ham_index)             - predict & predict_proba
   - Confusion Matrix: [[10,0],[0,10]]    - outputs/top_words.png                   - outputs/predictions.txt
   - outputs/confusion_matrix.png
```

---

## Checkpoint Breakdown and Verification

### Checkpoint 1: Backend and Path Setup (lines 10-27)
```python
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)
```

**Mentor Verification:**
- `matplotlib.use("Agg")` must execute BEFORE `import matplotlib.pyplot as plt`. This ensures the script runs headlessly in server, containerized, or grading environments without crashing on `DISPLAY` variables.
- `BASE` must use `Path(__file__).resolve().parent` to ensure filesystem portability regardless of the terminal's working directory.
- `OUT.mkdir(exist_ok=True)` must be called before saving any visual or text artifacts.

---

### Checkpoint 2: Data Ingestion and Stratified Partitioning (lines 38-42)
```python
df = pd.read_csv(DATA / "messages.csv")
X_train, X_test, y_train, y_test = train_test_split(
    df["text"], df["label"], test_size=0.25, random_state=42, stratify=df["label"]
)
```

**Mentor Verification:**
- Column name must be `"text"` (not `"message"` or `"body"`).
- Target column must be `"label"` (`'spam'` or `'ham'`).
- Total dataset size is 80 rows (40 ham, 40 spam).
- `stratify=df["label"]` is strictly required. Without stratification, small datasets can suffer severe class imbalance in the test partition.
- Split shapes: `len(X_train) == 60` (30 ham, 30 spam) and `len(X_test) == 20` (10 ham, 10 spam).
- `random_state=42` guarantees deterministic splitting.

---

### Checkpoint 3: Pipeline Assembly and Fitting (lines 44-51)
```python
model = Pipeline(
    [
        ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
        ("classifier", MultinomialNB()),
    ]
)
model.fit(X_train, y_train)
predictions = model.predict(X_test)
```

**Mentor Verification:**
- The pipeline encapsulates both the vectorizer and the classifier into a single estimator object. Students must NOT fit `CountVectorizer` separately on the test set (which would constitute data leakage).
- The vectorizer configuration must have `stop_words="english"` and `ngram_range=(1, 2)`.
- Vocabulary size on the 60 training messages must be exactly **288 features** (`len(model.named_steps["vectorizer"].get_feature_names_out()) == 288`).
- MultinomialNB uses default Laplace smoothing ($\alpha=1.0$).

---

### Checkpoint 4: Quantitative Evaluation and Metrics (lines 53-59)
```python
accuracy = accuracy_score(y_test, predictions)
print("=" * 60)
print("SPAM DETECTIVE")
print("=" * 60)
print(f"Accuracy: {accuracy:.1%}\n")
print(classification_report(y_test, predictions, zero_division=0))
```

**Mentor Verification:**
- Accuracy must be `1.0` (`100.0%`).
- Both precision and recall for both `'ham'` and `'spam'` should be `1.00`.
- All 20 test samples (10 ham, 10 spam) are classified correctly.

---

### Checkpoint 5: Discriminative Log-Odds Clue Extraction (`top_words`, lines 30-35, 60-65)
```python
def top_words(model: Pipeline, class_index: int, n: int = 10) -> list[str]:
    vectorizer = model.named_steps["vectorizer"]
    classifier = model.named_steps["classifier"]
    names = vectorizer.get_feature_names_out()
    scores = classifier.feature_log_prob_[class_index] - classifier.feature_log_prob_[1 - class_index]
    return list(names[np.argsort(scores)[-n:][::-1]])

classes = list(model.named_steps["classifier"].classes_)
spam_index = classes.index("spam")
spam_words = top_words(model, spam_index)
ham_words = top_words(model, 1 - spam_index)
print("Top spam clues:", ", ".join(spam_words))
print("Top normal clues:", ", ".join(ham_words))
```

**Mentor Verification:**
- Mathematical validation: The difference in log probabilities is equivalent to the log-odds ratio:
  $$\text{score}(w) = \log P(w \mid C) - \log P(w \mid \neg C) = \log \frac{P(w \mid C)}{P(w \mid \neg C)}$$
- `classes` in scikit-learn are sorted alphabetically: `['ham', 'spam']`. Therefore, `ham_index = 0` and `spam_index = 1`.
- Top spam clues must match: `buy, price, 50 buy, price guaranteed, 50, order, lowest, guaranteed, lowest price, risk`.
- Top normal clues must match: `meeting, today class, send notes, start, ll, tomorrow, ll minutes, minutes late, minutes, meeting lunch`.

---

### Checkpoint 6: Inference on Live Sample Messages (lines 67-80)
```python
new_messages = [
    "Congratulations! You won a free smartphone. Click now to claim your prize.",
    "Can we meet at the library at 4 pm to review the project?",
    "URGENT: verify your password immediately or your account will be suspended.",
    "Thanks for sending the notes. I will read them tonight.",
]
new_predictions = model.predict(new_messages)
probabilities = model.predict_proba(new_messages)
print("\nNew message predictions:")
for message, prediction, probability in zip(new_messages, new_predictions, probabilities):
    confidence = probability[classes.index(prediction)]
    print(f"  {prediction:4s} ({confidence:.0%}) -> {message}")
```

**Mentor Verification:**
- Message 1 ("Congratulations! You won..."): classified as `spam` with ~100% confidence.
- Message 2 ("Can we meet at the library..."): classified as `ham` with ~99% confidence.
- Message 3 ("URGENT: verify your password..."): classified as `spam` with ~98% confidence.
- Message 4 ("Thanks for sending the notes..."): classified as `ham` with ~88% confidence.

---

### Checkpoint 7: Diagnostic Visualizations (lines 82-103)
```python
# ---- Top-word chart ------------------------------------------------
fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
for ax, words, title, colour in (
    (axes[0], spam_words, "Words that suggest spam", "#c0392b"),
    (axes[1], ham_words, "Words that suggest a normal message", "#2471a3"),
):
    ax.barh(words[::-1], range(1, len(words) + 1), color=colour)
    ax.set_title(title)
    ax.set_xlabel("relative clue strength")
    ax.grid(axis="x", alpha=0.25)
fig.tight_layout()
fig.savefig(OUT / "top_words.png", dpi=150, bbox_inches="tight")
plt.close(fig)

# ---- Confusion matrix ---------------------------------------------
labels = ["ham", "spam"]
cm = confusion_matrix(y_test, predictions, labels=labels)
fig, ax = plt.subplots(figsize=(5, 4))
ConfusionMatrixDisplay(cm, display_labels=labels).plot(ax=ax, cmap="Reds", colorbar=False)
ax.set_title("Spam filter mistakes")
fig.tight_layout()
fig.savefig(OUT / "confusion_matrix.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```

**Mentor Verification:**
- `outputs/top_words.png` contains 2 horizontal bar chart subplots.
  - Left: Red bars (`#c0392b`) for spam words.
  - Right: Blue bars (`#2471a3`) for normal words.
  - Words are sorted in ascending order bottom-to-top (`words[::-1]`) so the strongest clue is at the top.
- `outputs/confusion_matrix.png` displays a 2x2 grid using the `"Reds"` colormap without a colorbar.
  - Matrix values: `[[10, 0], [0, 10]]`.
- Both figures must be explicitly closed with `plt.close(fig)` to free memory.

---

### Checkpoint 8: File Logging and Persistence (lines 105-111)
```python
with open(OUT / "predictions.txt", "w", encoding="utf-8") as handle:
    handle.write(f"accuracy: {accuracy:.4f}\n\n")
    handle.write(classification_report(y_test, predictions, zero_division=0))
    handle.write("\nNew messages:\n")
    for message, prediction, probability in zip(new_messages, new_predictions, probabilities):
        handle.write(f"{prediction} ({probability[classes.index(prediction)]:.2%}) -> {message}\n")
```

**Mentor Verification:**
- File path must be `outputs/predictions.txt`.
- Accuracy is formatted as `accuracy: 1.0000`.
- Includes full classification report.
- Probabilities for the 4 messages are formatted with two decimal places (e.g., `99.97%`, `98.79%`, `98.36%`, `88.40%`).

---

## Common Student Pitfalls and Debugging

| Pitfall | Root Cause | Solution |
|---|---|---|
| **Swapped Class Indices** | Assuming index 0 is spam or index 1 is ham. | In scikit-learn, classes are sorted alphabetically: `classes_ = ['ham', 'spam']`. Index 0 is ham, index 1 is spam. Always use `classes.index("spam")`. |
| **Wrong Column Name** | Accessing `df["message"]` instead of `df["text"]`. | In `messages.csv`, the column header is `text,label`. Use `df["text"]`. |
| **Data Leakage in Vectorization** | Calling `CountVectorizer.fit_transform()` on the whole dataset prior to split. | Assemble a scikit-learn `Pipeline` and call `fit()` exclusively on `X_train`. |
| **Missing Agg Backend** | Omitting `matplotlib.use("Agg")` prior to importing pyplot. | Put `matplotlib.use("Agg")` before `import matplotlib.pyplot as plt` to prevent GUI backend crashes. |
| **Mismatched Step Names in Pipeline** | Naming steps `"vect"` instead of `"vectorizer"` or `"clf"` instead of `"classifier"`. | `top_words()` accesses `model.named_steps["vectorizer"]` and `model.named_steps["classifier"]`. Step names must match exactly. |
| **Unclosed Figures** | Forgetting `plt.close(fig)` after `savefig`. | Add `plt.close(fig)` immediately after each `fig.savefig()` call. |
| **Prediction Input Shape Error** | Passing a single string to `predict()` instead of an iterable. | Always wrap strings in a list: `model.predict(["text"])` or `model.predict(new_messages)`. |
