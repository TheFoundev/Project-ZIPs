# Final Project Requirements: Spam Detective

## Project Objective

Reproduce the complete **Spam Detective** machine learning application from scratch, following `main.py` from `beginner-projects-main/AI-ML Beginners/projects/04_spam_detective/` exactly. Your implementation will load a curated SMS/email text dataset (`data/messages.csv`), construct an end-to-end scikit-learn pipeline coupling `CountVectorizer(stop_words="english", ngram_range=(1, 2))` with a `MultinomialNB` classifier, evaluate classification performance using accuracy, classification report, and a confusion matrix, extract log-odds discriminative keywords, classify sample incoming communications with class probability confidence scores, and persist diagnostic visual charts and a forensic text report to disk.

---

## Functional Requirements

### 1. Environment Setup and Headless Configuration
- Configure matplotlib to use the headless `'Agg'` backend prior to importing `pyplot` (`matplotlib.use("Agg")`).
- Import required standard and third-party modules:
  - `pathlib.Path`
  - `numpy`, `pandas`, `matplotlib.pyplot`
  - `sklearn.feature_extraction.text.CountVectorizer`
  - `sklearn.metrics.accuracy_score`, `classification_report`, `ConfusionMatrixDisplay`, `confusion_matrix`
  - `sklearn.model_selection.train_test_split`
  - `sklearn.naive_bayes.MultinomialNB`
  - `sklearn.pipeline.Pipeline`
- Define filesystem paths dynamically using `pathlib.Path`:
  - `BASE = Path(__file__).resolve().parent`
  - `DATA = BASE / "data"`
  - `OUT = BASE / "outputs"`
- Ensure `outputs/` directory is automatically created using `OUT.mkdir(exist_ok=True)`.

### 2. Dataset Ingestion and Validation
- Load `data/messages.csv` into a pandas DataFrame using `pd.read_csv(DATA / "messages.csv")`.
- Verify the dataset contains exactly 80 message rows and 2 columns:
  - `text`: string content of the message
  - `label`: binary target categorical string (`'spam'` or `'ham'`)
- Verify balanced distribution: exactly 40 ham messages and 40 spam messages, with no null or missing values.

### 3. Stratified Train/Test Split
- Partition the dataset using `train_test_split`:
  ```python
  X_train, X_test, y_train, y_test = train_test_split(
      df["text"], df["label"], test_size=0.25, random_state=42, stratify=df["label"]
  )
  ```
- Verify partition sizes:
  - Training set (`X_train`, `y_train`): 60 samples (30 ham, 30 spam)
  - Testing set (`X_test`, `y_test`): 20 samples (10 ham, 10 spam)
- Enforce determinism via `random_state=42`.
- Enforce class balance preservation across splits via `stratify=df["label"]`.

### 4. Pipeline Assembly and Training
- Build an encapsulated scikit-learn `Pipeline` object with two named steps:
  1. `"vectorizer"`: `CountVectorizer(stop_words="english", ngram_range=(1, 2))`
  2. `"classifier"`: `MultinomialNB()`
- Fit the pipeline exclusively on the training partition: `model.fit(X_train, y_train)`.
- Verify vocabulary extraction: the vectorizer learns exactly 288 unique unigram and bigram features from the 60 training messages.

### 5. Discriminative Log-Odds Feature Extraction (`top_words`)
- Implement the exact helper function signature and logic:
  ```python
  def top_words(model: Pipeline, class_index: int, n: int = 10) -> list[str]:
      vectorizer = model.named_steps["vectorizer"]
      classifier = model.named_steps["classifier"]
      names = vectorizer.get_feature_names_out()
      scores = classifier.feature_log_prob_[class_index] - classifier.feature_log_prob_[1 - class_index]
      return list(names[np.argsort(scores)[-n:][::-1]])
  ```
- Extract the classes list dynamically from the classifier: `classes = list(model.named_steps["classifier"].classes_)` (`['ham', 'spam']`).
- Identify the spam index: `spam_index = classes.index("spam")` (index 1).
- Identify the ham index: `1 - spam_index` (index 0).
- Extract the top 10 discriminative clues for spam and ham:
  - `spam_words = top_words(model, spam_index)`
  - `ham_words = top_words(model, 1 - spam_index)`
- Print top clues to the console:
  - `print("Top spam clues:", ", ".join(spam_words))`
  - `print("Top normal clues:", ", ".join(ham_words))`

### 6. Quantitative Evaluation
- Generate categorical predictions on the test set: `predictions = model.predict(X_test)`.
- Compute test accuracy via `accuracy = accuracy_score(y_test, predictions)` (achieving 100.0% / `1.0000`).
- Print the formatted console banner, accuracy percentage, and classification report:
  ```
  ============================================================
  SPAM DETECTIVE
  ============================================================
  Accuracy: 100.0%

                precision    recall  f1-score   support

           ham       1.00      1.00      1.00        10
          spam       1.00      1.00      1.00        10

      accuracy                           1.00        20
     macro avg       1.00      1.00      1.00        20
  weighted avg       1.00      1.00      1.00        20
  ```

### 7. Inference on Live Sample Messages
- Define the canonical 4 test messages:
  1. `"Congratulations! You won a free smartphone. Click now to claim your prize."`
  2. `"Can we meet at the library at 4 pm to review the project?"`
  3. `"URGENT: verify your password immediately or your account will be suspended."`
  4. `"Thanks for sending the notes. I will read them tonight."`
- Compute predicted labels: `new_predictions = model.predict(new_messages)`.
- Compute class probability distributions: `probabilities = model.predict_proba(new_messages)`.
- Print formatted predictions with confidence percentages:
  ```
  New message predictions:
    spam (100%) -> Congratulations! You won a free smartphone. Click now to claim your prize.
    ham  (99%) -> Can we meet at the library at 4 pm to review the project?
    spam (98%) -> URGENT: verify your password immediately or your account will be suspended.
    ham  (88%) -> Thanks for sending the notes. I will read them tonight.
  ```

### 8. Diagnostic Visualizations
- **Top Clues Horizontal Bar Charts (`outputs/top_words.png`)**:
  - Create figure with 2 subplots: `fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))`.
  - Left subplot (spam): horizontal bars for `spam_words[::-1]`, title `"Words that suggest spam"`, bar color `"#c0392b"`.
  - Right subplot (ham): horizontal bars for `ham_words[::-1]`, title `"Words that suggest a normal message"`, bar color `"#2471a3"`.
  - For both subplots: label x-axis `"relative clue strength"`, enable horizontal grid with `ax.grid(axis="x", alpha=0.25)`.
  - Apply `fig.tight_layout()`, save to `OUT / "top_words.png"` with `dpi=150, bbox_inches="tight"`, and close figure with `plt.close(fig)`.
- **Confusion Matrix Heatmap (`outputs/confusion_matrix.png`)**:
  - Compute matrix with explicit labels: `labels = ["ham", "spam"]`, `cm = confusion_matrix(y_test, predictions, labels=labels)`.
  - Create single axis figure: `fig, ax = plt.subplots(figsize=(5, 4))`.
  - Plot with `ConfusionMatrixDisplay(cm, display_labels=labels).plot(ax=ax, cmap="Reds", colorbar=False)`.
  - Set title: `ax.set_title("Spam filter mistakes")`.
  - Apply `fig.tight_layout()`, save to `OUT / "confusion_matrix.png"` with `dpi=150, bbox_inches="tight"`, and close figure with `plt.close(fig)`.

### 9. Forensic File Logging (`outputs/predictions.txt`)
- Write execution results to `OUT / "predictions.txt"` with `encoding="utf-8"`.
- Log format must include:
  1. Accuracy formatted to 4 decimal places: `accuracy: {accuracy:.4f}\n\n`
  2. Full `classification_report(y_test, predictions, zero_division=0)`
  3. Header `\nNew messages:\n`
  4. Formatted prediction lines with confidence percentage:
     `{prediction} ({probability[classes.index(prediction)]:.2%}) -> {message}\n`

---

## Non-Functional Requirements

- **Reproducibility**: Use `random_state=42` and `stratify=df["label"]` so that split and evaluation results are completely deterministic.
- **Data Leakage Prevention**: Encapsulate vectorization and classification inside `Pipeline`; fit only on `X_train`.
- **Portability & Path Safety**: All file system operations must use `pathlib.Path(__file__).resolve().parent`. Never use raw relative path strings.
- **Headless Compatibility**: Explicitly invoke `matplotlib.use("Agg")` prior to importing `pyplot` to prevent crashes in headless environments.
- **Resource Management**: Explicitly close all matplotlib figure objects using `plt.close(fig)` to avoid memory leaks.

---

## Implementation Milestones

| Milestone | Deliverable | Verification |
|---|---|---|
| 1: Environment & Setup | Headless configuration and path resolution | `OUT.mkdir(exist_ok=True)` executed without error |
| 2: Data Ingestion | Loaded DataFrame | `df.shape == (80, 2)` with columns `["text", "label"]` |
| 3: Stratified Partitioning | Train and test splits | 60 train rows, 20 test rows, exact 50/50 class balance |
| 4: Pipeline Assembly | Fitted scikit-learn Pipeline | 288 vocabulary features extracted from `X_train` |
| 5: Clue Extraction | `top_words()` implementation | 10 spam keywords and 10 ham keywords returned |
| 6: Quantitative Evaluation | Accuracy and classification report | Accuracy = 100.0%, macro avg F1 = 1.00 |
| 7: Sample Inference | 4 test message predictions | 2 spam, 2 ham with high confidence probabilities |
| 8: Visual Artifacts | Dual bar chart & confusion matrix | `top_words.png` and `confusion_matrix.png` generated |
| 9: Forensic Text Export | Audit log written to disk | `outputs/predictions.txt` contains metrics and predictions |
| 10: Complete Run | End-to-end execution | Script prints final confirmation and retrain suggestion |

---

## Expected Deliverables

- [ ] **Working Python script** (`main.py` or `final_spam_detective.py`) matching reference functionality
- [ ] **Console output** matching the canonical format:
  ```
  ============================================================
  SPAM DETECTIVE
  ============================================================
  Accuracy: 100.0%

                precision    recall  f1-score   support

           ham       1.00      1.00      1.00        10
          spam       1.00      1.00      1.00        10

      accuracy                           1.00        20
     macro avg       1.00      1.00      1.00        20
  weighted avg       1.00      1.00      1.00        20

  Top spam clues: buy, price, 50 buy, price guaranteed, 50, order, lowest, guaranteed, lowest price, risk
  Top normal clues: meeting, today class, send notes, start, ll, tomorrow, ll minutes, minutes late, minutes, meeting lunch

  New message predictions:
    spam (100%) -> Congratulations! You won a free smartphone. Click now to claim your prize.
    ham  (99%) -> Can we meet at the library at 4 pm to review the project?
    spam (98%) -> URGENT: verify your password immediately or your account will be suspended.
    ham  (88%) -> Thanks for sending the notes. I will read them tonight.

  Saved: outputs/top_words.png, outputs/confusion_matrix.png, outputs/predictions.txt
  Try this: add five of your own spam and normal messages, then retrain.
  ```
- [ ] **`outputs/top_words.png`** — Horizontal dual-panel bar chart showing top 10 spam clues (red) and ham clues (blue)
- [ ] **`outputs/confusion_matrix.png`** — 2x2 confusion matrix heatmap with display labels `['ham', 'spam']` using `Reds` colormap
- [ ] **`outputs/predictions.txt`** — Text audit log with test accuracy, classification report, and live test predictions
- [ ] **1-page analysis report** containing:
  - Mathematical basis of Naive Bayes and log-odds clue ranking
  - Interpretation of Precision, Recall, and F1-score for spam filtering
  - Discussion of asymmetric error costs (False Positives vs False Negatives)
  - One model limitation and one engineering improvement proposal

---

## Acceptance Criteria

- [ ] Script executes without errors from start to finish via `python main.py`
- [ ] Data loading uses `DATA / "messages.csv"` and extracts `df["text"]` and `df["label"]`
- [ ] Train/test split uses `test_size=0.25`, `random_state=42`, and `stratify=df["label"]`
- [ ] Pipeline pairs `CountVectorizer(stop_words="english", ngram_range=(1, 2))` with `MultinomialNB()`
- [ ] Feature count on training set is exactly 288 features
- [ ] Test set evaluation achieves 1.0 (100.0%) accuracy
- [ ] Top 10 spam clues match expected terms (`buy`, `price`, `50 buy`, `price guaranteed`, etc.)
- [ ] Top 10 normal clues match expected terms (`meeting`, `today class`, `send notes`, `start`, etc.)
- [ ] All 4 new test messages are correctly classified (messages 1 & 3 as spam, 2 & 4 as ham)
- [ ] Both PNG images are valid non-empty files saved with `dpi=150` and `bbox_inches="tight"`
- [ ] `predictions.txt` contains formatted accuracy, report, and predictions
- [ ] `plt.close(fig)` is called after creating each figure

---

## Troubleshooting Guide

| Issue | Cause | Fix |
|---|---|---|
| `ModuleNotFoundError: No module named 'sklearn'` | scikit-learn not installed | Run `pip install scikit-learn` |
| `FileNotFoundError: data/messages.csv` | Relative path execution issue | Use `Path(__file__).resolve().parent / "data" / "messages.csv"` |
| `KeyError: 'message'` | Using wrong column name | Column is named `'text'` in `messages.csv`, not `'message'` |
| Swapped spam/ham clues | Hardcoded class index assumption | Look up class index dynamically via `classes.index("spam")` |
| `ValueError: Found input variables with inconsistent numbers of samples` | Mismatched split variables | Ensure `df["text"]` and `df["label"]` come from same DataFrame |
| Headless terminal crash (`_tkinter.TclError`) | Interactive matplotlib backend | Call `matplotlib.use("Agg")` before `import matplotlib.pyplot as plt` |
| Memory warning / unclosed figures | Missing cleanup | Call `plt.close(fig)` after saving each plot |

---

## Optional Extension Challenges

1. **Custom Message Retraining**: Follow the prompt in `main.py` by adding 5 new custom spam messages and 5 custom ham messages to `data/messages.csv`. Retrain the pipeline and observe how vocabulary size and clue rankings shift.
2. **TF-IDF Comparison**: Replace `CountVectorizer` with `TfidfVectorizer(stop_words="english", ngram_range=(1, 2))` and compare the resulting clue log-odds scores against term-frequency counts.
3. **Threshold Tuning**: Experiment with decision thresholds on `predict_proba()` to reduce False Positives to near zero, requiring $P(\text{spam}) > 0.95$ before flagging an email as spam.
4. **Interactive CLI Classifier**: Add an interactive `input()` prompt loop allowing users to enter custom emails from the command line and receive instant spam classification with confidence percentages.
