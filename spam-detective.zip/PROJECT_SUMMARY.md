# Spam Detective

## Overview
This project uses **Multinomial Naive Bayes** and **CountVectorizer** to classify text messages as spam or ham (legitimate). Using the actual dataset `data/messages.csv` from `beginner-projects-main/AI-ML Beginners/projects/04_spam_detective/`, you will learn how to vectorize text, train a probabilistic classification pipeline, extract discriminative keyword clues, evaluate model metrics, and make predictions on new messages.

## Real-World Use Case
Communication platforms, email providers, and messaging apps use automated spam filtering to block malicious phishing attempts, financial scams, and marketing spam while ensuring authentic messages are delivered reliably.

## Features (Implemented)
- Load text and label data from `data/messages.csv` (80 messages: 40 ham, 40 spam)
- Perform stratified train/test split (75/25) preserving class proportions
- Build scikit-learn `Pipeline` chaining `CountVectorizer` and `MultinomialNB`
- Tokenize text with English stop-word removal and unigram + bigram n-grams (1, 2)
- Train Multinomial Naive Bayes classifier on training split (60 messages)
- Evaluate model performance with accuracy score and full classification report (precision, recall, f1-score)
- Extract and rank top discriminative spam and ham clue words using log-odds differences
- Predict class labels and posterior probabilities for 4 new unseen messages
- Generate dual horizontal bar chart visualization (`outputs/top_words.png`)
- Generate confusion matrix heatmap (`outputs/confusion_matrix.png`)
- Export classification metrics and prediction audit log to `outputs/predictions.txt`

## Technology Stack
- Python 3
- pandas, numpy
- matplotlib
- scikit-learn

## System Requirements
- Python 3.7+
- pip

## Installation Instructions
```bash
cd beginner-projects-main/AI-ML\ Beginners/projects/04_spam_detective
pip install pandas numpy matplotlib scikit-learn
python main.py
```

## Project Structure (Actual)
```
04_spam_detective/
├── main.py
├── data/
│   └── messages.csv
└── outputs/
    ├── confusion_matrix.png
    ├── predictions.txt
    └── top_words.png
```

## How It Works
1. Loads `data/messages.csv` with columns `text` and `label`
2. Uses `text` as feature X, `label` as target y
3. Splits with `train_test_split(df["text"], df["label"], test_size=0.25, random_state=42, stratify=df["label"])`
4. Encapsulates `CountVectorizer(stop_words="english", ngram_range=(1, 2))` and `MultinomialNB()` in a `Pipeline`
5. Fits pipeline on `X_train` to learn vocabulary (288 features) and class word distributions
6. Evaluates test set (20 messages), achieving 100% test accuracy
7. Identifies top 10 spam and ham clue words by subtracting `feature_log_prob_` between classes
8. Tests 4 new incoming messages, computing predicted labels and confidence probabilities
9. Saves horizontal bar charts of clue words to `outputs/top_words.png` and confusion matrix to `outputs/confusion_matrix.png`
10. Writes accuracy, classification report, and test predictions to `outputs/predictions.txt`

## Expected Output
- Console output showing accuracy, classification report, top clue keywords, and predictions with confidence percentages
- `outputs/top_words.png`
- `outputs/confusion_matrix.png`
- `outputs/predictions.txt`

## Security Considerations
- No hardcoded credentials or API keys
- Local file processing only; no external network requests
- Headless matplotlib backend (`matplotlib.use("Agg")`) prevents display server crashes

## Troubleshooting
- Missing packages: run `pip install pandas numpy matplotlib scikit-learn`
- FileNotFoundError: ensure you run the script from the project root or rely on `Path(__file__).resolve().parent`
- Display errors: `matplotlib.use("Agg")` ensures rendering without a desktop display

## Further Learning
- Naive Bayes mathematics and Bayes' Theorem
- Bag-of-Words and TF-IDF representations
- Classification metrics (Precision, Recall, F1-Score, Confusion Matrix)
- Handling class imbalance in NLP datasets
