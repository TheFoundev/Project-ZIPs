# All Correct Answers for Assessments
Project: Spam Detective
---

## Module 01
**q1-01.** What type of machine learning problem is solved in the Spam Detective project?
   **Correct Answer:** b. Supervised binary text classification
   *Explanation:* Spam detection is a supervised binary text classification problem. The model is trained on labeled text messages where each message has one of two discrete target labels: 'spam' or 'ham'.

**q1-02.** In natural language processing and spam filtering terminology, what does the term 'ham' represent?
   **Correct Answer:** b. Legitimate, desired, or non-spam messages
   *Explanation:* In natural language processing and email filtering, 'ham' is the universally accepted industry term for legitimate, non-spam messages.

**q1-03.** Which scikit-learn class is used in main.py to convert raw text into a Bag-of-Words count matrix?
   **Correct Answer:** b. CountVectorizer
   *Explanation:* CountVectorizer from sklearn.feature_extraction.text is used to tokenize messages, build the corpus vocabulary, and create the word count matrix.

**q1-04.** Why do production email filters consider a False Positive to be much worse than a False Negative?
   **Correct Answer:** b. Missing an important legitimate message (e.g. job offer) causes far greater user harm than deleting an unwanted spam email
   *Explanation:* A False Positive occurs when an authentic, important email (such as an interview invitation or hospital notice) is flagged as spam and hidden from the user, causing severe harm. A False Negative merely exposes the user to a minor nuisance spam email.

**q1-05.** What fundamental structural information about text is discarded by the Bag-of-Words model?
   **Correct Answer:** b. Word order, grammar, and sentence structure
   *Explanation:* The Bag-of-Words representation discards word order, grammar, syntax, and sentence structure, treating each text document as an unordered collection of word counts.

**q1-06.** Why do naive keyword blocklists (e.g. marking any message with 'free' as spam) fail in real-world email filtering?
   **Correct Answer:** b. They cause catastrophic false positives on everyday messages like 'Are you free for lunch?'
   *Explanation:* Keyword blocklists flag any message containing trigger words regardless of context, causing normal sentences like 'Are you free for coffee?' or 'Click to see the lecture notes' to be incorrectly quarantined.

**q1-07.** How does statistical machine learning (like Naive Bayes) evaluate a message that contains both a spammy word ('free') and strong legitimate words ('meeting', 'library')?
   **Correct Answer:** b. It weighs the probabilistic evidence across all words simultaneously, allowing legitimate words to outweigh the single spam clue
   *Explanation:* Statistical classifiers compute the joint posterior probability by combining evidence from all tokens in the message. Multiple strong legitimate tokens easily overcome the presence of a single ambiguous word.

**q1-08.** In main.py, how is the outputs directory created to ensure the script does not crash if the directory already exists?
   **Correct Answer:** b. OUT.mkdir(exist_ok=True)
   *Explanation:* In main.py line 27, OUT.mkdir(exist_ok=True) creates the outputs directory using pathlib, with exist_ok=True preventing a FileExistsError if the directory already exists.

**q1-09.** What does the top_words() helper function in main.py calculate to identify the most discriminative words for a class?
   **Correct Answer:** b. The difference between class feature log-probabilities: classifier.feature_log_prob_[class_index] - classifier.feature_log_prob_[1 - class_index]
   *Explanation:* top_words() calculates scores = classifier.feature_log_prob_[class_index] - classifier.feature_log_prob_[1 - class_index], computing the log-odds ratio between the two classes.

**q1-10.** Which of the following describes the complete set of output artifact files produced by running main.py?
   **Correct Answer:** b. outputs/top_words.png, outputs/confusion_matrix.png, outputs/predictions.txt
   *Explanation:* main.py saves top_words.png (bar chart), confusion_matrix.png (matrix heatmap), and predictions.txt (metrics and live prediction logs) to the outputs/ directory.


## Module 02
**q2-01.** Which pandas function is used in main.py to read the messages dataset?
   **Correct Answer:** b. pd.read_csv()
   *Explanation:* In main.py line 39, pd.read_csv(DATA / 'messages.csv') is called to load the comma-separated messages dataset into a pandas DataFrame.

**q2-02.** What are the exact dimensions of the DataFrame loaded from messages.csv?
   **Correct Answer:** b. 80 rows, 2 columns
   *Explanation:* messages.csv contains exactly 80 data rows (excluding the header) and 2 columns: 'text' and 'label'. Therefore df.shape returns (80, 2).

**q2-03.** What is the class distribution between spam and ham in the messages.csv dataset?
   **Correct Answer:** b. 40 spam, 40 ham (50% / 50%)
   *Explanation:* df['label'].value_counts() reveals exactly 40 spam rows and 40 ham rows, representing an exact 50% / 50% balanced class split.

**q2-04.** What is the expected baseline accuracy of a naive model that randomly guesses or always predicts 'spam' on a 50/50 balanced dataset?
   **Correct Answer:** b. 50%
   *Explanation:* On a balanced binary classification dataset where exactly 50% of instances belong to each class, randomly guessing or predicting one class constantly yields exactly 50% accuracy.

**q2-05.** Which of the following phrases is characteristic of the ham messages in messages.csv rather than the spam messages?
   **Correct Answer:** c. "Hi Nina, are we still meeting for lunch at 4:00 tomorrow?"
   *Explanation:* 'Hi Nina, are we still meeting for lunch at 4:00 tomorrow?' is a genuine row from messages.csv (line 16) labeled as ham, reflecting everyday interpersonal scheduling.

**q2-06.** Why is natural language text categorized as 'unstructured data' compared to tabular data?
   **Correct Answer:** b. Text exhibits variable sentence length, rich vocabulary, punctuation nuances, and case variations rather than fixed numeric columns
   *Explanation:* Natural language text is unstructured because sentences vary in length, draw from an open-ended vocabulary, and contain punctuation, typos, and capitalization differences rather than pre-formatted fixed numerical measurements.

**q2-07.** In main.py line 41, what does the argument test_size=0.25 specify?
   **Correct Answer:** b. 25% of the data (20 messages) is reserved for testing, leaving 75% (60 messages) for training
   *Explanation:* test_size=0.25 reserves 25% of the total dataset for testing. Out of 80 messages, 25% equals exactly 20 messages, leaving 60 messages (75%) for training.

**q2-08.** What does setting stratify=df['label'] guarantee during the train-test split?
   **Correct Answer:** b. That the training and testing sets maintain the exact same proportion of spam and ham as the original dataset
   *Explanation:* Stratification ensures that the train and test splits reflect the exact proportion of target classes found in the original dataset (here, 50% spam and 50% ham in both splits).

**q2-09.** How many samples and what class breakdown exist in y_test after executing train_test_split with test_size=0.25 and stratify=df['label']?
   **Correct Answer:** a. 20 samples: 10 spam and 10 ham
   *Explanation:* With 80 total messages and test_size=0.25, the test set has 20 samples. Stratifying on a 50/50 target guarantees exactly 10 spam and 10 ham messages in y_test.

**q2-10.** Why is X_train in main.py a 1D pandas Series of strings (shape (60,)) rather than a 2D DataFrame (shape (60, 1))?
   **Correct Answer:** b. CountVectorizer expects an iterable of raw text documents (strings), which it internally tokenizes and converts into a 2D feature matrix
   *Explanation:* CountVectorizer is designed to take an iterable or 1D Series of raw text documents (strings). It performs tokenization and vocabulary mapping internally, returning the 2D feature count matrix required by the classifier.


## Module 03
**q3-01.** What does CountVectorizer do by default to uppercase letters during text processing?
   **Correct Answer:** b. Converts all characters to lowercase (lowercase=True)
   *Explanation:* By default, CountVectorizer has lowercase=True, meaning all characters are converted to lowercase during tokenization to prevent duplicates like 'Win' and 'win'.

**q3-02.** Which parameter in CountVectorizer removes frequent English function words like 'the', 'and', 'is', and 'at'?
   **Correct Answer:** b. stop_words="english"
   *Explanation:* Setting stop_words='english' activates scikit-learn's built-in 318-word stop words list, automatically filtering common grammatical words like 'the', 'and', 'is', 'at'.

**q3-03.** In natural language processing, what is a 'bigram'?
   **Correct Answer:** b. A sequence of two adjacent words (e.g. 'lowest price')
   *Explanation:* In natural language processing, a bigram is a contiguous sequence of two adjacent words or tokens, such as 'lowest price', 'cash reward', or 'minutes late'.

**q3-04.** What method on a fitted CountVectorizer retrieves the list of learned vocabulary tokens ordered by their feature column index?
   **Correct Answer:** a. vectorizer.get_feature_names_out()
   *Explanation:* vectorizer.get_feature_names_out() returns a NumPy array containing all learned vocabulary tokens ordered by their corresponding feature matrix column indices.

**q3-05.** Why is stop word removal especially beneficial for a Naive Bayes spam classifier?
   **Correct Answer:** a. It eliminates non-discriminative grammatical words that appear with high frequency in both classes, preventing them from diluting informative signals
   *Explanation:* Stop words appear uniformly and with very high frequency in both legitimate and spam messages. Removing them eliminates noise and prevents uninformative words from overwhelming true topical clues.

**q3-06.** In main.py line 46, what does ngram_range=(1, 2) instruct CountVectorizer to do?
   **Correct Answer:** c. Extract both unigrams and bigrams simultaneously
   *Explanation:* ngram_range=(1, 2) specifies min_n=1 and max_n=2, extracting both individual words (unigrams) and two-word pairs (bigrams).

**q3-07.** Which of the following phrases extracted by ngram_range=(1, 2) represents a high-confidence spam clue?
   **Correct Answer:** b. "price guaranteed"
   *Explanation:* 'price guaranteed' is a two-word bigram extracted in main.py that serves as one of the top discriminative clues for spam messages (printed by top_words()).

**q3-08.** What is the total vocabulary size (number of features) learned by CountVectorizer on X_train in the Spam Detective project?
   **Correct Answer:** b. 288
   *Explanation:* Fitting CountVectorizer(stop_words='english', ngram_range=(1, 2)) on the 60 training messages of messages.csv extracts exactly 288 unigram and bigram features.

**q3-09.** Why are text document-term matrices stored as SciPy Compressed Sparse Row (CSR) matrices rather than dense NumPy arrays?
   **Correct Answer:** b. Over 95% of matrix cells are zeros; sparse matrices only store non-zero values, preventing massive memory waste
   *Explanation:* In natural language processing, most documents contain only a tiny fraction of the full vocabulary, resulting in over 95% zero values. Sparse matrices store only non-zero entries, preventing severe memory waste.

**q3-10.** How does CountVectorizer handle Out-Of-Vocabulary (OOV) words when transforming new, unseen test messages?
   **Correct Answer:** b. It silently ignores unknown words and only vectorizes tokens matching the learned vocabulary
   *Explanation:* CountVectorizer ignores Out-Of-Vocabulary (OOV) words at test/inference time without throwing errors, converting only recognized vocabulary terms into feature counts.


## Module 04
**q4-01.** Which scikit-learn class is used as the probabilistic classification estimator in main.py?
   **Correct Answer:** b. MultinomialNB
   *Explanation:* In main.py line 21 and line 47, MultinomialNB from sklearn.naive_bayes is used as the probabilistic classification estimator for modeling term frequency counts.

**q4-02.** Why is the Naive Bayes algorithm described as 'naive'?
   **Correct Answer:** b. It assumes all words in a document are conditionally independent of each other given the class label
   *Explanation:* Naive Bayes is called 'naive' because it makes the simplifying assumption that the presence or frequency of any word in a document is conditionally independent of all other words, given the class label.

**q4-03.** What is the primary architectural purpose of using an scikit-learn Pipeline in main.py?
   **Correct Answer:** b. To encapsulate text vectorization and classification into a unified estimator and prevent data leakage
   *Explanation:* A Pipeline packages preprocessing (CountVectorizer) and modeling (MultinomialNB) into a single object, simplifying workflows and preventing data leakage by ensuring transformations are fit only on training data.

**q4-04.** Why does MultinomialNB perform probability computations using logarithms (feature_log_prob_) rather than raw decimals?
   **Correct Answer:** b. To prevent numerical underflow caused by multiplying dozens of tiny fractional probabilities together
   *Explanation:* Multiplying dozens of fractional probabilities between 0.0 and 1.0 quickly results in numbers smaller than floating-point precision (~10^-50), causing numerical underflow (rounding to 0). Summing logarithms prevents this issue entirely.

**q4-05.** How can you access the fitted CountVectorizer instance from inside the model Pipeline object?
   **Correct Answer:** b. model.named_steps["vectorizer"]
   *Explanation:* In scikit-learn, steps in a Pipeline can be accessed like a dictionary using the .named_steps attribute, such as model.named_steps['vectorizer'].

**q4-06.** In what order are class labels stored in model.named_steps['classifier'].classes_ in this project?
   **Correct Answer:** b. In alphabetical order: ['ham', 'spam']
   *Explanation:* Scikit-learn automatically sorts categorical target strings in alphabetical order when creating classifier.classes_, meaning ['ham', 'spam'] is produced with 'ham' at index 0 and 'spam' at index 1.

**q4-07.** Why does main.py use classes.index('spam') rather than hardcoding spam_index = 1?
   **Correct Answer:** b. To write robust, defensive code that dynamically resolves the class index even if label ordering changes
   *Explanation:* Using classes.index('spam') dynamically queries the exact position of the 'spam' label, preventing silent bugs if class ordering changes due to different labels or preprocessing.

**q4-08.** What are the exact dimensions of classifier.feature_log_prob_ in the Spam Detective project?
   **Correct Answer:** b. (2, 288)
   *Explanation:* feature_log_prob_ has shape (n_classes, n_features). With 2 classes (ham, spam) and 288 vocabulary features learned on X_train, the exact shape is (2, 288).

**q4-09.** What mathematical difference is computed in main.py line 34 to score feature importance for a class?
   **Correct Answer:** a. scores = classifier.feature_log_prob_[class_index] - classifier.feature_log_prob_[1 - class_index]
   *Explanation:* Line 34 computes the log-odds ratio: classifier.feature_log_prob_[class_index] - classifier.feature_log_prob_[1 - class_index], measuring how much more probable a word is in the target class than in the opposing class.

**q4-10.** In the top_words() helper function, what does the slicing syntax [-n:][::-1] accomplish on the argsort indices?
   **Correct Answer:** b. Selects the n largest scores and reverses them so the #1 highest score appears first
   *Explanation:* np.argsort() sorts from smallest to largest. Slicing [-n:] selects the top n largest scores, and [::-1] reverses the array so that the highest score appears at index 0.


## Module 05
**q5-01.** What accuracy score is achieved by the Spam Detective model on the 20 test messages in main.py?
   **Correct Answer:** b. 100.0%
   *Explanation:* In main.py, accuracy_score(y_test, predictions) yields 1.0 (100.0%) because all 20 test messages (10 ham and 10 spam) are classified correctly.

**q5-02.** In binary text classification, what does Precision on the spam class measure?
   **Correct Answer:** b. The percentage of messages flagged as spam that were genuinely spam
   *Explanation:* Precision on the spam class is TP / (TP + FP). It answers: 'Of all messages flagged as spam by the model, what fraction was genuinely spam?'

**q5-03.** What matplotlib plotting function is used in main.py to create the horizontal bar chart of clue words?
   **Correct Answer:** b. ax.barh()
   *Explanation:* In main.py line 87, ax.barh() is used to plot horizontal bars, allowing word and phrase labels to be displayed legibly along the vertical y-axis.

**q5-04.** In the classification report, what does the support column indicate?
   **Correct Answer:** b. The number of true ground-truth instances of each class in the test dataset
   *Explanation:* In scikit-learn's classification report, the 'support' column indicates the number of true ground-truth occurrences of each class in the test set (here, 10 ham and 10 spam).

**q5-05.** What does a False Positive error represent in an email filtering context?
   **Correct Answer:** b. An authentic, legitimate email incorrectly marked as spam and quarantined
   *Explanation:* A False Positive occurs when an authentic, legitimate message (ham) is incorrectly classified as spam and hidden in the junk folder, causing user communication loss.

**q5-06.** What are the exact values along the main diagonal of the confusion matrix computed in main.py (labels=['ham', 'spam'])?
   **Correct Answer:** a. TN = 10, TP = 10
   *Explanation:* With labels=['ham', 'spam'], the confusion matrix is [[10, 0], [0, 10]]. The main diagonal contains True Negatives (10 ham classified as ham) and True Positives (10 spam classified as spam).

**q5-07.** Why does main.py use words[::-1] when plotting horizontal bars with ax.barh()?
   **Correct Answer:** b. Because ax.barh() plots from bottom to top, so reversing places the #1 strongest clue at the top
   *Explanation:* ax.barh() draws items starting from y=0 (bottom) upward. Reversing the ranked list with words[::-1] ensures that the highest-ranked clue is drawn at the top of the chart.

**q5-08.** What method on the pipeline is called in main.py line 75 to compute soft confidence scores for live messages?
   **Correct Answer:** a. model.predict_proba()
   *Explanation:* In main.py line 75, model.predict_proba(new_messages) is invoked to return the probability distribution across all classes for each test message.

**q5-09.** What confidence score does the model assign to the test message 'Thanks for sending the notes. I will read them tonight.'?
   **Correct Answer:** b. ham (88%)
   *Explanation:* In main.py lines 76-79 and predictions.txt, message 4 ('Thanks for sending the notes...') is classified as ham with 88% confidence (88.40%).

**q5-10.** Why might a production email filter enforce a 95% spam probability threshold before quarantining an email rather than the default 50% cutoff?
   **Correct Answer:** a. To minimize False Positives and ensure legitimate messages are almost never quarantined by mistake
   *Explanation:* Requiring a very high confidence threshold (such as 95%) before quarantining emails ensures that legitimate messages are virtually never misclassified as spam (minimizing False Positives).


## Module 06
**q6-01.** What command executes the complete Spam Detective pipeline from the project directory?
   **Correct Answer:** a. python main.py
   *Explanation:* The project docstring on line 4 explicitly states the execution command: 'python main.py', running the self-contained pipeline from start to finish.

**q6-02.** Which text file is created by main.py to store evaluation metrics and live prediction audit logs?
   **Correct Answer:** b. outputs/predictions.txt
   *Explanation:* In main.py line 105, predictions.txt is created in the outputs/ directory to store the accuracy, classification report, and live test message predictions.

**q6-03.** What does main.py suggest students try at the conclusion of the script output?
   **Correct Answer:** b. "Try this: add five of your own spam and normal messages, then retrain."
   *Explanation:* Line 113 of main.py prints the educational prompt: 'Try this: add five of your own spam and normal messages, then retrain.'

**q6-04.** Why is the 'Agg' backend enabled in main.py line 14?
   **Correct Answer:** b. To allow headless figure rendering without requiring an interactive graphical display window
   *Explanation:* Setting matplotlib.use('Agg') configures Matplotlib to render figures in headless memory without requiring a GUI window system, ensuring reliable execution on remote servers and CI/CD runners.

**q6-05.** Why is encoding='utf-8' explicitly specified when writing outputs/predictions.txt?
   **Correct Answer:** b. It guarantees consistent cross-platform character handling and prevents encoding errors on non-UTF8 operating systems
   *Explanation:* Explicitly setting encoding='utf-8' ensures that text containing non-ASCII symbols, currency signs, or smart quotes is written reliably across all operating systems without triggering UnicodeEncodeError.

**q6-06.** When you add 10 new messages containing unique words to messages.csv and re-run main.py, what happens?
   **Correct Answer:** b. The script automatically retrains, discovers the new vocabulary words, and expands the feature matrix
   *Explanation:* Because main.py dynamically computes dataset shapes, vocabulary extraction, and class counts, adding new rows to messages.csv automatically retrains the model with the expanded vocabulary upon re-running.

**q6-07.** What is the 'Good-Word Stuffing' adversarial evasion attack against Bag-of-Words spam filters?
   **Correct Answer:** b. Appending dozens of legitimate, non-spam words (e.g. from encyclopedia or news articles) to an email to dilute the statistical weight of spam keywords
   *Explanation:* Good-word stuffing is an adversarial evasion technique where an attacker appends dozens of legitimate dictionary or encyclopedia words to a spam email so that the classifier's joint probability is overwhelmed by legitimate tokens.

**q6-08.** How does TF-IDF vectorization improve upon raw CountVectorizer word counts?
   **Correct Answer:** a. It downweights words that appear frequently across nearly all documents, emphasizing rare and highly discriminative terms
   *Explanation:* TF-IDF multiplies term frequency by inverse document frequency, penalizing words that appear in nearly all messages and boosting distinctive, informative keywords.

**q6-09.** Which cryptographic email authentication protocols are standardly paired with ML classifiers in commercial email gateways?
   **Correct Answer:** b. SPF, DKIM, and DMARC
   *Explanation:* SPF (Sender Policy Framework), DKIM (DomainKeys Identified Mail), and DMARC (Domain-based Message Authentication, Reporting, and Conformance) are standard cryptographic email protocols used to verify sender authenticity.

**q6-10.** Why do modern transformer models (such as BERT or RoBERTa) outperform traditional Bag-of-Words Naive Bayes models on adversarial and complex text?
   **Correct Answer:** b. They model bidirectional context, syntax, and word order, understanding semantic relationships like negation and sarcasm rather than isolated word counts
   *Explanation:* Transformer models utilize self-attention mechanisms to evaluate words in bidirectional context, capturing grammatical relationships, word order, negation, and nuance that Bag-of-Words models miss.

