# Lesson 01: Reading and Inspecting messages.csv

**Lesson ID:** lesson-01
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Load tabular text data using `pathlib.Path` and `pandas.read_csv()`
- Verify the dataset dimensions, column names, and data types
- Inspect raw text records and their corresponding categorical labels
- Understand how pandas handles variable-length text strings in memory
- Identify potential CSV formatting pitfalls when text contains quotes or commas

## Prerequisites
- Basic familiarity with Python and the `pandas` library
- Completion of Module 01

## Concept Explanation

### The Source Dataset
In machine learning projects, our models are only as good as the underlying data. The **Spam Detective** project relies on a carefully curated dataset located at `data/messages.csv`.

Unlike synthetic tabular problems that feature neat numeric floats (like age, temperature, or square footage), text datasets contain natural human language. When we inspect the CSV file header, we see two essential columns:
1. `text`: The raw message content (a sequence of characters, words, numbers, and punctuation).
2. `label`: The categorical ground-truth annotation (`"spam"` or `"ham"`).

### Robust Path Handling with `pathlib`
In professional code, file paths should never be hardcoded as brittle strings like `"C:\\Users\\aziz\\...\\data\\messages.csv"` or simple relative strings like `"data/messages.csv"`. If you run the script from a different working directory, relative string paths break immediately.

In `main.py` (lines 24-25 and 39), path resolution is handled cleanly:
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
df = pd.read_csv(DATA / "messages.csv")
```
- `__file__` is a special Python variable referencing the script file itself.
- `.resolve().parent` computes the absolute directory containing `main.py`.
- The `/` operator cleanly appends subdirectory paths across all operating systems.

### Inspecting Dataset Dimensions and Types
When `pd.read_csv()` ingests `messages.csv`, it returns a pandas `DataFrame`.
- `df.shape`: Returns `(80, 2)`—indicating exactly 80 rows (messages) and 2 columns.
- `df.dtypes`: Shows that both `text` and `label` are stored with data type `object` (the standard pandas container for Python strings).

### CSV Parsing Nuances in NLP
Text data frequently contains commas, question marks, and quotation marks. In `messages.csv`, some rows contain internal quotes, for example:
`"Buy cheap software today! Best price, limited offer, order now.",spam`
Pandas' default parser correctly handles double-quote enclosures, preventing internal commas from corrupting column alignment.

## Relevant Code (from main.py, lines 24-25 and 38-39)

```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)


def main() -> None:
    df = pd.read_csv(DATA / "messages.csv")
```

### Code Explanation
- **Line 24:** Identifies the project root directory.
- **Line 25:** Defines `DATA` pointing to `04_spam_detective/data`.
- **Line 39:** Calls `pd.read_csv(DATA / "messages.csv")` to load the dataset into DataFrame `df`.

## Worked Example

Let us open a Python terminal and inspect the first three rows of `data/messages.csv`:

```python
import pandas as pd
from pathlib import Path

DATA = Path("data")
df = pd.read_csv(DATA / "messages.csv")

print("Dimensions:", df.shape)
print("\nColumns:", list(df.columns))
print("\nFirst 3 rows:")
print(df.head(3))
```

**Output:**
```
Dimensions: (80, 2)

Columns: ['text', 'label']

First 3 rows:
                                                text label
0  Lowest price guaranteed! Get vitamins at 50% o...  spam
1  Final notice: unpaid bill. Send payment today ...  spam
2  Congratulations! You have won a free vacation....  spam
```

Notice how `df.head(3)` displays the raw message text in the first column and the assigned label in the second column.

## Step-by-Step Student Instructions

1. **Open your terminal** and navigate to the project directory:
   ```bash
   cd "beginner-projects-main/AI-ML Beginners/projects/04_spam_detective"
   ```
2. **Launch Python**:
   ```bash
   python3
   ```
3. **Execute the loading commands**:
   ```python
   import pandas as pd
   df = pd.read_csv("data/messages.csv")
   print("Total messages:", len(df))
   print("Columns:", df.columns.tolist())
   ```
4. **Inspect the info summary**:
   ```python
   df.info()
   ```
   Verify that there are 80 non-null entries for both `text` and `label`. There are no missing values!

## Expected Output or Observable Behaviour

The `df.info()` call confirms clean, complete data:
```
<class 'pandas.core.frame.DataFrame'>
RangeIndex: 80 entries, 0 to 79
Data columns (total 2 columns):
 #   Column  Non-Null Count  Dtype 
---  ------  --------------  ----- 
 0   text    80 non-null     object
 1   label   80 non-null     object
dtypes: object(2)
memory usage: 1.4+ KB
```

## Practical Exercises

- **Exercise 1.1:** How many total rows and columns does `messages.csv` have? Write a Python one-liner to print `(rows, columns)`.
- **Exercise 1.2:** What data type does pandas assign to columns containing string text?
- **Exercise 1.3:** Check if there are any missing values (`NaN`) in the dataset using `df.isnull().sum()`.
- **Exercise 1.4:** Print the first message labeled `"ham"` in the dataset. What is its index and text?

## Common Mistakes and Debugging

| Mistake | Why it happens | Correction |
|---|---|---|
| `FileNotFoundError` | Running the script from a different directory with relative string `"data/messages.csv"` | Use `Path(__file__).resolve().parent / "data" / "messages.csv"` |
| Broken columns due to internal commas | Writing custom `line.split(',')` instead of `pd.read_csv()` | Always rely on `pd.read_csv()` which respects CSV quote escapes |
| Assuming `df['text']` is 2D | In pandas, selecting a single column with single brackets returns a 1D Series | Remember `df['text']` is a Series of strings |
| Assuming `text` column has numeric types | Expecting ML feature matrix immediately | Understand that CSV text must be vectorized before model ingestion |

## Best Practices and Security Considerations

- **Pathlib Over String Concatenation:** Always use `pathlib.Path` with the `/` operator to ensure cross-platform compatibility across Windows, Linux, and macOS.
- **Handling Untrusted CSVs:** When loading user-supplied CSV files, always inspect for malformed rows or encoding issues by specifying `encoding="utf-8"`.
- **Sanitizing Text Inputs:** Ensure text data does not contain null bytes or unintended control characters.

## Summary

The Spam Detective project begins by loading `data/messages.csv` using `pandas.read_csv()` and `pathlib.Path`. The dataset consists of 80 complete, non-null text records across two columns: `text` (the message string) and `label` (the binary ground-truth target). Pandas automatically handles CSV quotation and formatting nuances.

## Knowledge-check Questions

1. What are the names of the two columns in `messages.csv`?
2. What are the exact dimensions (rows and columns) of `df` after loading `messages.csv`?
3. Why is `Path(__file__).resolve().parent` preferred over `"data/messages.csv"`?
4. Are there any missing or null values in `messages.csv`?
5. What pandas data type is assigned to the `text` column?

## References

- pandas read_csv documentation: https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html
- Python pathlib tutorial: https://docs.python.org/3/library/pathlib.html
- Data preparation in Python: https://scikit-learn.org/stable/modules/preprocessing.html
