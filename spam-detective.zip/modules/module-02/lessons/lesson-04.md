# Lesson 04: Stratified Train/Test Splitting for Text Data

**Lesson ID:** lesson-04
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain why datasets must be split into independent training and testing sets
- Describe the mechanism of stratified sampling and why it is critical for classification
- Understand the arguments passed to `train_test_split()` in `main.py`
- Verify the exact shapes and class counts of `X_train`, `X_test`, `y_train`, and `y_test`
- Contrast 1D text Series features with traditional 2D numeric tabular matrices

## Prerequisites
- Completion of Lessons 01, 02, and 03
- Understanding of independent vs dependent variables ($X$ and $y$)

## Concept Explanation

### The Cardinal Rule of Machine Learning: Never Test on Training Data
If you train a model on a set of messages and then evaluate the model on those exact same messages, the model could achieve 100% accuracy simply by memorizing the data. This is known as **data leakage** and leads to catastrophic failure when the system encounters brand new messages in the real world.

To obtain an honest, unbiased assessment of generalizability, we must partition our labeled dataset into:
1. **Training Set ($75\%$):** The data the model studies to learn vocabulary counts and class probabilities.
2. **Testing Set ($25\%$):** Held-out data that the model never sees during training, used exclusively to evaluate final performance.

### Stratified Sampling: Why `stratify=df['label']` Matters
In a standard random split, records are assigned to train or test via an unconstrained coin flip. In small datasets, random chance could assign 35 spam messages to training and only 5 spam messages to testing. This skew distorts both the learning process and the evaluation.

**Stratified sampling** guarantees that the train and test subsets contain the **exact same proportion** of classes as the original dataset:
- Original dataset: 80 messages (50% spam, 50% ham)
- With `test_size=0.25`:
  - **Training Set (60 messages):** Exactly 30 spam (50%) and 30 ham (50%).
  - **Testing Set (20 messages):** Exactly 10 spam (50%) and 10 ham (50%).

Setting `stratify=df["label"]` ensures this perfect balance across both partitions.

### The `random_state` Parameter
Computers generate pseudo-random numbers using a seed value. Specifying `random_state=42` guarantees that every time you, a student, or a grading harness runs `main.py`, the exact same 60 messages land in training and the exact same 20 messages land in testing. This guarantees 100% reproducibility.

### 1D Text Series vs 2D Numeric Features
In tabular regression projects (like predicting lemonade sales), scikit-learn requires features $X$ to be a **2D array or DataFrame** of shape `(n_samples, n_features)` (e.g. `df[["temperature_c"]]`).

However, in NLP pipelines:
- $X$ is passed as a **1D pandas Series of strings** (`df["text"]`), with shape `(80,)`.
- Why? Because `CountVectorizer` expects an iterable of raw text strings (sentences), which it then internally transforms into the 2D feature matrix!

## Relevant Code (from main.py, lines 40-42)

```python
    X_train, X_test, y_train, y_test = train_test_split(
        df["text"], df["label"], test_size=0.25, random_state=42, stratify=df["label"]
    )
```

### Code Explanation
- `df["text"]`: The feature Series containing the 80 raw text messages.
- `df["label"]`: The target Series containing the 80 ground-truth labels.
- `test_size=0.25`: Reserves 25% (20 messages) for evaluation, leaving 75% (60 messages) for training.
- `random_state=42`: Sets the deterministic pseudo-random seed.
- `stratify=df["label"]`: Forces both splits to mirror the 50/50 class ratio.

## Worked Example

Let us execute the split and inspect the resulting shapes and class balances:

```python
import pandas as pd
from sklearn.model_selection import train_test_split

df = pd.read_csv("data/messages.csv")

X_train, X_test, y_train, y_test = train_test_split(
    df["text"], df["label"], test_size=0.25, random_state=42, stratify=df["label"]
)

print(f"X_train shape: {X_train.shape} (Type: {type(X_train).__name__})")
print(f"X_test shape:  {X_test.shape}")
print(f"y_train shape: {y_train.shape}")
print(f"y_test shape:  {y_test.shape}")

print("\nTraining Label Distribution:")
print(y_train.value_counts())

print("\nTesting Label Distribution:")
print(y_test.value_counts())
```

**Output:**
```
X_train shape: (60,) (Type: Series)
X_test shape:  (20,)
y_train shape: (60,)
y_test shape:  (20,)

Training Label Distribution:
label
spam    30
ham     30
Name: count, dtype: int64

Testing Label Distribution:
label
spam    10
ham     10
Name: count, dtype: int64
```

Notice how `stratify` created an exact 30/30 split in training and an exact 10/10 split in testing.

## Step-by-Step Student Instructions

1. **Launch a Python session** in your project directory.
2. **Execute the exact splitting code** from lines 40-42:
   ```python
   import pandas as pd
   from sklearn.model_selection import train_test_split
   df = pd.read_csv("data/messages.csv")
   X_train, X_test, y_train, y_test = train_test_split(
       df["text"], df["label"], test_size=0.25, random_state=42, stratify=df["label"]
   )
   ```
3. **Verify total counts**: Confirm that `len(X_train) + len(X_test) == 80`.
4. **Test the effect of omitting `stratify`**: Try running without `stratify=df["label"]` across multiple seeds (e.g. `random_state=7`, `random_state=99`) and observe how class counts fluctuate unreliably.

## Expected Output or Observable Behaviour

The verification confirms:
- 60 samples in training (30 spam, 30 ham)
- 20 samples in testing (10 spam, 10 ham)
- All shapes are 1D Series of lengths 60 and 20.

## Practical Exercises

- **Exercise 4.1:** How many total samples are allocated to the test set when `test_size=0.25` is applied to 80 rows?
- **Exercise 4.2:** What error occurs if you pass `stratify=df["text"]` instead of `stratify=df["label"]`? Why?
- **Exercise 4.3:** If a dataset has 100 rows with 80 ham and 20 spam, and you use `test_size=0.20` with stratification, how many spam and ham messages will be in the test set?
- **Exercise 4.4:** Why does `CountVectorizer` accept a 1D Series for $X$ whereas `LinearRegression` requires a 2D DataFrame?

## Common Mistakes and Debugging

| Mistake | Why it happens | Correction |
|---|---|---|
| Forgetting `stratify=df['label']` | Omitting stratification in classification tasks | Always stratify on the target variable when splitting classification data |
| Splitting after vectorization | Vectorizing the full dataset before splitting | Always split raw text first to prevent vocabulary data leakage |
| Using double brackets `df[['text']]` | Assuming scikit-learn always requires 2D inputs | Pass 1D `df['text']` because `CountVectorizer` expects an iterable of strings |
| Changing `random_state` | Expecting identical numerical scores with different seeds | Keep `random_state=42` to match project benchmarks |

## Best Practices and Security Considerations

- **Strict Separation:** Never expose the test set to vectorization vocabulary extraction; the test set must simulate unseen future data.
- **Reproducible Seeds:** Always fix random seeds in educational and testing harnesses to guarantee consistent results.
- **Stratification Consistency:** In multi-class or binary classification, always stratify splits, especially when sample counts are below 10,000.

## Summary

In `main.py`, `train_test_split` partitions the 80 messages into 60 training samples and 20 testing samples using `test_size=0.25`. By setting `stratify=df["label"]`, both the training set (30 spam, 30 ham) and test set (10 spam, 10 ham) perfectly preserve the 50/50 balance of the original dataset. The features $X$ are passed as a 1D Series of text strings, which will be vectorized inside the pipeline.

## Knowledge-check Questions

1. What percentage and exact number of samples are allocated to testing in `main.py`?
2. What is the purpose of the `stratify=df["label"]` argument?
3. How many spam messages and how many ham messages are present in `y_test`?
4. Why is `random_state=42` included in the function call?
5. What is the shape of `X_train`?

## References

- scikit-learn train_test_split: https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html
- Cross-validation and data splitting: https://scikit-learn.org/stable/modules/cross_validation.html#stratification
- Avoiding Data Leakage in Machine Learning: https://scikit-learn.org/stable/common_pitfalls.html#data-leakage
