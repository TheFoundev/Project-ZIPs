# Lesson 02: Exploring Label Distribution and Class Balance

**Lesson ID:** lesson-02
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Compute and interpret the frequency distribution of class labels
- Explain the concept of class balance versus class imbalance in classification
- Understand why a 50/50 class balance makes accuracy an honest evaluation metric
- Describe the "Accuracy Paradox" that occurs in heavily imbalanced real-world datasets
- Verify the exact class breakdown of `messages.csv`

## Prerequisites
- Completion of Lesson 01
- Understanding of basic percentages and frequency counts

## Concept Explanation

### What is Class Balance?
In a classification problem, **class balance** refers to the relative proportions of the different target categories in the dataset.
- A dataset is **balanced** when all classes are represented in roughly equal numbers (e.g. 50% spam and 50% ham).
- A dataset is **imbalanced** when one class drastically outnumbers the other (e.g. 98% ham and 2% spam, or 99.5% legitimate transactions and 0.5% credit card fraud).

### Label Distribution in `messages.csv`
Let us examine the target column `df["label"]` in our project:
```python
df["label"].value_counts()
```
Output:
```
label
spam    40
ham     40
Name: count, dtype: int64
```
Out of 80 total messages, exactly **40 are spam** (50.0%) and **40 are ham** (50.0%). The dataset is perfectly balanced.

### Why Balanced Data Simplifies Learning for Beginners
In introductory machine learning, a balanced dataset provides major pedagogical advantages:
1. **Equal Exposure:** The learning algorithm sees an equal number of examples of legitimate writing and spam writing. It doesn't develop an accidental bias toward the majority class.
2. **Straightforward Baseline:** A model that makes purely random guesses would score around 50% accuracy. Any model scoring significantly above 50% has genuinely learned meaningful statistical patterns.
3. **Honest Accuracy:** In a 50/50 split, overall **accuracy** directly reflects how well the model distinguishes between both classes.

### The Accuracy Paradox in Imbalanced Real-World Data
In real-world consumer email systems, true message distributions are typically **heavily imbalanced**—often 85% spam and 15% ham (or vice versa depending on corporate firewalls).

Consider a dataset with **990 ham emails** and **10 spam emails** (total: 1000 emails):
- Suppose a lazy model simply predicts `"ham"` for every single email without reading a single word.
- **Accuracy calculation:**
  $$\text{Accuracy} = \frac{990}{1000} = 99.0\%$$
- On paper, 99.0% accuracy looks outstanding! But in reality, the filter is completely useless: it detected **0% of the spam** (0 out of 10).
- This phenomenon is known as the **Accuracy Paradox**. In Module 05, we will see how metrics like **Precision** and **Recall** reveal these blind spots. However, in our balanced 40/40 project dataset, high accuracy is a genuine achievement.

## Relevant Code (from main.py, line 41)

```python
    X_train, X_test, y_train, y_test = train_test_split(
        df["text"], df["label"], test_size=0.25, random_state=42, stratify=df["label"]
    )
```

### Code Explanation
- Notice `stratify=df["label"]` on line 41.
- Because the dataset is balanced (40 spam, 40 ham), stratifying ensures that the 75% training set (60 messages) has exactly 30 spam and 30 ham, and the 25% test set (20 messages) has exactly 10 spam and 10 ham.

## Worked Example

Let us verify the balance programmatically and calculate normalized proportions:

```python
import pandas as pd

df = pd.read_csv("data/messages.csv")

# Raw counts
counts = df["label"].value_counts()
print("Raw Counts:")
print(counts)

# Proportions
percentages = df["label"].value_counts(normalize=True) * 100
print("\nClass Proportions:")
for label, pct in percentages.items():
    print(f"  {label}: {pct:.1f}%")
```

**Output:**
```
Raw Counts:
label
spam    40
ham     40
Name: count, dtype: int64

Class Proportions:
  spam: 50.0%
  ham: 50.0%
```

Both classes contribute identical proportions to our training pool.

## Step-by-Step Student Instructions

1. **Open your Python terminal** in the project directory.
2. **Compute the class counts**:
   ```python
   import pandas as pd
   df = pd.read_csv("data/messages.csv")
   print(df["label"].value_counts())
   ```
3. **Verify the total**:
   ```python
   assert df["label"].value_counts()["spam"] == 40
   assert df["label"].value_counts()["ham"] == 40
   ```
4. **Reflect on the baseline**: If a model always guessed `"spam"`, what would its accuracy be on this dataset? (Answer: $40/80 = 50\%$).

## Expected Output or Observable Behaviour

The terminal confirms:
```
label
spam    40
ham     40
Name: count, dtype: int64
```
No assertion errors are raised, confirming the 40/40 balanced split.

## Practical Exercises

- **Exercise 2.1:** What is the ratio of spam to ham messages in `messages.csv`?
- **Exercise 2.2:** If a dataset has 95 spam messages and 5 ham messages, what accuracy would a classifier achieve by predicting `"spam"` for all inputs?
- **Exercise 2.3:** Why is an accuracy of 50% considered the baseline "random guess" performance on our dataset?
- **Exercise 2.4:** Write a pandas command that filters `df` to display only the rows where `label == 'ham'`. How many rows are returned?

## Common Mistakes and Debugging

| Mistake | Why it happens | Correction |
|---|---|---|
| Assuming accuracy is always reliable | Overlooking class distribution | Check `df['label'].value_counts()` before trusting accuracy |
| Forgetting `normalize=True` | Trying to calculate percentages manually | Use `df['label'].value_counts(normalize=True)` for proportions |
| Expecting real-world email to be 50/50 | Assuming real inboxes match our curated dataset | Recognize that production filters face severe class imbalance |
| Modifying the CSV labels accidentally | Overwriting `df['label']` during exploration | Use read-only queries when inspecting data |

## Best Practices and Security Considerations

- **Always Check Class Balance First:** Before training any classifier, always check the target distribution. It dictates which evaluation metrics (Accuracy vs F1 / ROC-AUC) you must use.
- **Resampling Techniques:** In imbalanced production settings, data scientists use techniques like SMOTE (synthetic oversampling) or class-weighted loss functions (`class_weight='balanced'`).
- **Data Integrity:** Confirm that labels are uniformly formatted (e.g. no accidental uppercase `"Spam"` or trailing whitespace `"ham "`).

## Summary

The `messages.csv` dataset is balanced, containing 40 spam messages (50%) and 40 ham messages (50%). This balance allows the classifier to learn both classes equally, establishes an intuitive 50% baseline for random guessing, and ensures that overall accuracy provides a reliable measure of classification capability.

## Knowledge-check Questions

1. How many spam messages and how many ham messages are contained in `messages.csv`?
2. What percentage of the dataset does each class represent?
3. What is the "Accuracy Paradox"?
4. If a model predicts "spam" for all 80 messages in our dataset, what would its accuracy score be?
5. Which pandas method counts the occurrences of each unique value in a Series?

## References

- Google Machine Learning Crash Course - Imbalanced Data: https://developers.google.com/machine-learning/data-prep/construct/sampling-splitting/imbalanced-data
- pandas Series.value_counts: https://pandas.pydata.org/docs/reference/api/pandas.Series.value_counts.html
- The Accuracy Paradox in Machine Learning: https://en.wikipedia.org/wiki/Accuracy_paradox
