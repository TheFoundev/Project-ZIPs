# Lesson 03: Analyzing Message Content and Text Characteristics

**Lesson ID:** lesson-03
**Module:** module-02
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Compare the textual and linguistic patterns of spam messages versus legitimate messages
- Identify common lexical triggers in spam (commercial urgency, financial claims, discounts)
- Identify common lexical triggers in ham (scheduling, collaboration, workplace reminders)
- Analyze text length, word count distributions, and punctuation patterns
- Explain why natural text requires specialized preprocessing compared to numeric tables

## Prerequisites
- Completion of Lessons 01 and 02
- Basic Python string operations (splitting, length)

## Concept Explanation

### Linguistic Signatures of Spam Messages
When we inspect the spam rows of `messages.csv`, clear patterns emerge:
- **Financial & Commercial Incentives:** `"Lowest price guaranteed"`, `"50% off"`, `"Earn $250 per week"`, `"cash reward"`, `"$100"`.
- **Urgency & Coercion:** `"Final notice"`, `"unpaid bill"`, `"avoid suspension"`, `"Act fast!"`, `"Order in the next hour"`.
- **Exaggeration & Rewards:** `"Congratulations!"`, `"won a free vacation"`, `"Winner!"`, `"Claim your free gift card"`, `"special reward"`.
- **Imperative Calls-to-Action:** `"Buy now"`, `"Order now"`, `"Sign up now"`, `"Reply YES"`, `"Click www..."`.

Notice how spam messages are crafted to elicit impulsive emotional reactions—either greed, fear, or urgency.

### Linguistic Signatures of Ham Messages
In stark contrast, the legitimate messages in `messages.csv` reflect everyday professional, academic, and personal interactions:
- **Scheduling & Coordination:** `"are we still meeting for lunch at 4:00 tomorrow?"`, `"the team meeting is moved to 11:00 in room 204"`.
- **Academic & Workplace Logistics:** `"Please find the budget attached"`, `"I'll be a few minutes late to the lab session"`, `"The library book is due on Friday"`.
- **Casual Punctuation & Names:** Specific personal names (`"Nina"`, `"Leo"`), polite phrasing (`"Please"`, `"Thanks"`), conversational contractions (`"I'll"`).

### Why Text is Unstructured Data
In traditional datasets (like tabular real estate or finance records), every column has a fixed numerical meaning: column 1 is always square footage (a number between 400 and 5000), column 2 is always number of bedrooms (1 to 5).

Text data is fundamentally different:
1. **Variable Length:** One message may have 6 words (`"Please return the library book."`), while another has 24 words.
2. **Infinite Vocabulary:** English has over 500,000 words, plus slang, abbreviations, URLs, and typographical errors.
3. **Punctuation and Symbols:** Dollar signs (`$`), percentages (`%`), exclamation points (`!`), and quotes carry emotional emphasis but complicate raw token parsing.
4. **Case Sensitivity:** `"FREE"` versus `"free"` convey identical meaning to a human, but naive string comparisons treat them as completely different values.

These complexities explain why we need standard NLP text preprocessors (like scikit-learn's `CountVectorizer`) rather than directly computing statistics on raw strings.

## Relevant Code (from main.py, lines 39 and 68-73)

```python
    df = pd.read_csv(DATA / "messages.csv")
    
    # ...
    # ---- Test a few new messages --------------------------------------
    new_messages = [
        "Congratulations! You won a free smartphone. Click now to claim your prize.",
        "Can we meet at the library at 4 pm to review the project?",
        "URGENT: verify your password immediately or your account will be suspended.",
        "Thanks for sending the notes. I will read them tonight.",
    ]
```

### Code Explanation
- **Line 39:** Ingests the 80 training messages.
- **Lines 68-73:** Defines 4 realistic test messages representing the linguistic categories we analyzed:
  - Message 1 & 3: Classic spam with reward claims and urgent coercion.
  - Message 2 & 4: Classic ham with library meeting scheduling and note sharing.

## Worked Example

Let us write a script to compute average character lengths and inspect sample messages from both classes:

```python
import pandas as pd

df = pd.read_csv("data/messages.csv")

# Add message length
df["char_length"] = df["text"].apply(len)
df["word_count"] = df["text"].apply(lambda t: len(t.split()))

print("Average Message Statistics:")
print(df.groupby("label")[["char_length", "word_count"]].mean())

print("\nSample Spam Message:")
print(df[df["label"] == "spam"]["text"].iloc[0])

print("\nSample Ham Message:")
print(df[df["label"] == "ham"]["text"].iloc[0])
```

**Output:**
```
Average Message Statistics:
       char_length  word_count
label                         
ham      54.675000    9.925000
spam     66.725000   10.875000

Sample Spam Message:
Lowest price guaranteed! Get vitamins at 50% off. Buy now.

Sample Ham Message:
Please find the budget attached. Let me know if you have questions.
```

Spam messages in this dataset are on average slightly longer (66.7 chars vs 54.7 chars), driven by promotional disclaimers and URLs.

## Step-by-Step Student Instructions

1. **Open your Python shell** and load the dataset:
   ```python
   import pandas as pd
   df = pd.read_csv("data/messages.csv")
   ```
2. **Inspect the first 5 spam messages**:
   ```python
   for msg in df[df["label"] == "spam"]["text"].head(5):
       print("SPAM:", msg)
   ```
3. **Inspect the first 5 ham messages**:
   ```python
   for msg in df[df["label"] == "ham"]["text"].head(5):
       print("HAM: ", msg)
   ```
4. **Identify the recurring words**: Notice how `"free"`, `"sale"`, `"order"`, and `"prize"` appear repeatedly in spam, while `"meeting"`, `"late"`, and `"attached"` appear repeatedly in ham.

## Expected Output or Observable Behaviour

The printed samples show distinct semantic differences:
```
SPAM: Lowest price guaranteed! Get vitamins at 50% off. Buy now.
SPAM: Final notice: unpaid bill. Send payment today to avoid suspension.
SPAM: Congratulations! You have won a free vacation. Click www.secure-verify.example now to claim your cash reward.
...
HAM:  Please find the budget attached. Let me know if you have questions.
HAM:  I'll be a few minutes late to the lab session. Start without me.
HAM:  Hi Nina, are we still meeting for lunch at 4:00 tomorrow?
```

## Practical Exercises

- **Exercise 3.1:** What punctuation marks appear most prominently in the spam messages compared to ham messages?
- **Exercise 3.2:** Write a python expression to count how many spam messages contain an exclamation mark (`"!"`).
- **Exercise 3.3:** Why would a model that only looks at character count perform poorly compared to a model that looks at word vocabulary?
- **Exercise 3.4:** Create a synthetic ham message that an overly simplistic filter might mistakenly suspect of being spam.

## Common Mistakes and Debugging

| Mistake | Why it happens | Correction |
|---|---|---|
| Relying on message length alone | Assuming all spam is long and all ham is short | Word choice and vocabulary frequencies are vastly more discriminative |
| Ignoring case normalization | Treating `"URGENT"` and `"urgent"` as unrelated words | Use lowercasing preprocessors to unify token representations |
| Overfitting to sample names | Expecting every ham message to mention `"Nina"` or `"Leo"` | Recognize that models learn generalizable patterns across all training samples |
| Splitting on whitespace manually | Thinking `text.split()` handles punctuation | Use `CountVectorizer` which strips punctuation during tokenization |

## Best Practices and Security Considerations

- **Adversarial Character Substitutions:** Malicious actors deliberately inject misspellings (e.g. `"V!AGRA"` or `"cl1ck"`) to evade naive vocabulary matches.
- **Handling URLs:** Spam frequently contains malicious URLs (e.g. `www.secure-verify.example`). In production, URLs are often mapped to a generic `<URL>` token.
- **Data Privacy:** Raw message logs may contain Personally Identifiable Information (PII) such as phone numbers, student IDs, or names. Sanitize logs before export.

## Summary

Spam messages in `messages.csv` consistently exhibit high-urgency keywords, promotional financial incentives, discount claims, and imperative calls-to-action. In contrast, ham messages focus on workplace scheduling, meeting coordination, and academic tasks. Unstructured text data features variable length and case variation, necessitating systematic tokenization and normalization.

## Knowledge-check Questions

1. Name three common themes or keywords found in the spam messages in `messages.csv`.
2. Name three common themes or keywords found in the ham messages in `messages.csv`.
3. Why is text described as "unstructured data" compared to numeric tabular columns?
4. How does the average character length of spam compare to ham in our dataset?
5. Why is case normalization (converting to lowercase) important in text classification?

## References

- Speech and Language Processing - Text Normalization: https://web.stanford.edu/~jurafsky/slp3/2.pdf
- scikit-learn Working with Text Data: https://scikit-learn.org/stable/tutorial/text_analytics/working_with_text_data.html
- Understanding Phishing and Spam Language: https://www.cisa.gov/secure-our-world/recognize-and-report-phishing
