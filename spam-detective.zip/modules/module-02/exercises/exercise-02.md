# Module 2 Exercises: Data Loading & Text Exploration

## Exercise 2.1: Dataset Schema and Path Inspection (15 min)
**Objective:** Load `messages.csv` using `pathlib` and inspect its shape, columns, and data integrity.

**Problem Statement:** 
Write a Python script to locate `data/messages.csv` relative to your script's directory, load it into a pandas DataFrame, and perform basic integrity checks.

**Requirements:**
1. Use `pathlib.Path(__file__).resolve().parent` to define the base directory
2. Load the CSV file into a DataFrame named `df`
3. Verify that the DataFrame has exactly 80 rows and 2 columns
4. Print the exact column names and verify there are zero null values across both columns

**Constraints:** 
Do not use hardcoded absolute path strings. Use pathlib operations exclusively.

**Expected Behaviour:** 
The script prints the dataset dimensions, confirms zero null values, and prints the first 2 rows.

**Acceptance Criteria:**
- [ ] Path resolution uses `pathlib.Path`
- [ ] `df.shape` is verified as `(80, 2)`
- [ ] Columns are confirmed as `['text', 'label']`
- [ ] `df.isnull().sum()` confirms 0 nulls for all columns

**Hints:**
- Use `assert df.shape == (80, 2), "Unexpected dimensions"` to enforce verification.

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 2.2: Class Balance Analysis and the Accuracy Paradox (15 min)
**Objective:** Analyze the class distribution of `messages.csv` and contrast it with an imbalanced scenario.

**Problem Statement:** 
You need to document the exact class distribution of `messages.csv` and write a short technical note explaining the Accuracy Paradox.

**Requirements:**
1. Compute the exact value counts and normalized proportions for `df['label']`
2. State the baseline accuracy of a "dummy classifier" that always predicts the majority class on `messages.csv`
3. Contrast this with a hypothetical dataset of 1,000 emails containing 980 ham and 20 spam messages:
   - What would a dummy classifier's accuracy be on the hypothetical dataset?
   - What would its recall on spam be?
   - Why does accuracy fail as a sole metric in imbalanced scenarios?

**Constraints:** 
Present clear mathematical calculations for all percentage questions.

**Expected Behaviour:** 
A structured technical note with Python verification code and written mathematical calculations.

**Acceptance Criteria:**
- [ ] Confirms `messages.csv` has 40 spam (50%) and 40 ham (50%)
- [ ] Identifies baseline guessing accuracy as 50% on our project dataset
- [ ] Correctly calculates 98.0% dummy accuracy on the hypothetical dataset
- [ ] Correctly calculates 0.0% spam recall for the dummy predictor and explains why accuracy is deceptive

**Hints:**
- Recall = (True Positives) / (True Positives + False Negatives). If True Positives = 0, Recall is 0%.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 2.3: Linguistic Keyword and Length Comparison (15 min)
**Objective:** Programmatically discover linguistic patterns separating spam from ham messages.

**Problem Statement:** 
Analyze the text characteristics of both classes in `messages.csv`. Determine the mean character length, word count, and frequency of promotional trigger terms.

**Requirements:**
1. Calculate the mean character length and word count for spam messages vs ham messages
2. Write a function to count occurrences of specific keywords: `["free", "guaranteed", "meeting", "attached", "urgent", "lunch"]`
3. Create a summary table showing how many spam messages vs ham messages contain each keyword
4. Write 2-3 sentences summarizing the primary linguistic contrast between the two classes

**Constraints:** 
Use case-insensitive string matching (`message.lower()`).

**Expected Behaviour:** 
A printed comparison table showing average lengths and keyword distribution across classes.

**Acceptance Criteria:**
- [ ] Character length and word counts computed accurately per class
- [ ] Keyword presence table accurately shows spam words dominating spam rows and scheduling words dominating ham rows
- [ ] Summary clearly explains the contrast between commercial urgency and logistical coordination

**Hints:**
- In pandas: `df[df['label'] == 'spam']['text'].str.lower().str.contains('free').sum()`.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 2.4: Verifying Stratified Sampling Proportions (15 min)
**Objective:** Implement and verify the stratified train/test split from `main.py`.

**Problem Statement:** 
Execute `train_test_split()` with `test_size=0.25`, `random_state=42`, and `stratify=df['label']`. Prove mathematically and programmatically that stratification worked.

**Requirements:**
1. Split `df["text"]` and `df["label"]` into `X_train`, `X_test`, `y_train`, `y_test`
2. Print the exact shapes of all 4 arrays/Series
3. Print `y_train.value_counts()` and `y_test.value_counts()`
4. Run a second trial without `stratify` across different random states (e.g. `random_state=123`) and document the class skew that occurs

**Constraints:** 
Follow the exact syntax from lines 40-42 of `main.py`.

**Expected Behaviour:** 
Clean output confirming 30/30 in training and 10/10 in testing, followed by an explanation of why stratification is critical.

**Acceptance Criteria:**
- [ ] Shapes verified: X_train (60,), X_test (20,), y_train (60,), y_test (20,)
- [ ] y_train confirmed to have exactly 30 spam and 30 ham
- [ ] y_test confirmed to have exactly 10 spam and 10 ham
- [ ] Comparison highlights how unstratified splits cause random class imbalances in small datasets

**Hints:**
- Use `pd.concat([y_train.value_counts(), y_test.value_counts()], axis=1, keys=['Train', 'Test'])` to show a side-by-side table.

**Difficulty:** Advanced
**Estimated Completion Time:** 15 minutes
