# Module 6 Exercises: Complete Pipeline & Running

## Exercise 6.1: End-to-End Terminal Execution and Verification (15 min)
**Objective:** Run `main.py` from the command line, verify artifact creation, and benchmark script runtime.

**Problem Statement:** 
Execute the complete `main.py` pipeline using the terminal. Verify that all terminal outputs match specifications and that all generated artifact files are valid.

**Requirements:**
1. Execute `python main.py` from the project directory
2. Capture and document the complete console output
3. Verify that `outputs/top_words.png`, `outputs/confusion_matrix.png`, and `outputs/predictions.txt` exist
4. Use the Unix `time` command to measure execution wall-clock time
5. Verify that the exit status code of the script is 0 (`echo $?`)

**Constraints:** 
Execute in a standard bash/zsh shell environment.

**Expected Behaviour:** 
Flawless terminal execution with console output matching benchmark specifications and all 3 artifact files created.

**Acceptance Criteria:**
- [ ] Script runs without warnings or stack traces
- [ ] Exit code verified as 0
- [ ] Console shows 100.0% accuracy, top clues, and 4 message predictions
- [ ] All 3 files present in `outputs/`

**Hints:**
- Use `ls -lh outputs/` to check file sizes.

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 6.2: Parsing and Auditing `predictions.txt` (15 min)
**Objective:** Write a Python audit script to parse `predictions.txt` and validate recorded metrics.

**Problem Statement:** 
Build an automated test script that reads `outputs/predictions.txt`, parses the recorded accuracy, and verifies that the reported metrics meet compliance standards.

**Requirements:**
1. Open and parse `outputs/predictions.txt` using Python's `open()` with `encoding="utf-8"`
2. Extract the accuracy float value from line 1 and assert that `accuracy >= 0.95`
3. Parse the 4 new message confidence scores and confirm that all 4 confidences are greater than 80%
4. Print a pass/fail compliance certification report

**Constraints:** 
Do not use scikit-learn for parsing; parse the generated text file directly using string methods or regex.

**Expected Behaviour:** 
The script prints compliance validation confirmation indicating that all audited metrics passed.

**Acceptance Criteria:**
- [ ] File opened safely with UTF-8 encoding
- [ ] Accuracy string parsed correctly to float 1.0000
- [ ] All 4 message confidences extracted and verified > 80%
- [ ] Formatted compliance report printed

**Hints:**
- Use `re.search(r'accuracy:\s*([\d\.]+)', text)` to extract accuracy.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 6.3: Dataset Expansion and Retraining Experiment (15 min)
**Objective:** Add 5 custom spam and 5 custom ham messages to `data/messages.csv` and observe retraining dynamics.

**Problem Statement:** 
Act on the challenge printed by `main.py`: expand `data/messages.csv` with 10 custom labeled messages (5 spam and 5 ham). Retrain the pipeline and document the effect on vocabulary size and top clue keywords.

**Requirements:**
1. Create a backup copy of `data/messages.csv`
2. Add 5 realistic spam messages (e.g. crypto giveaways, package delivery, banking alerts)
3. Add 5 realistic ham messages (e.g. study groups, office hours, club meetings)
4. Re-run `python main.py`
5. Record the new total rows, new training vocabulary size, and note any changes in top clue rankings

**Constraints:** 
Maintain strict 50/50 balance in the added messages. Ensure proper CSV quote escaping.

**Expected Behaviour:** 
The pipeline trains smoothly on the 90-row dataset, generating updated plots and text reports.

**Acceptance Criteria:**
- [ ] 10 valid rows added to CSV
- [ ] Class balance preserved (45 spam, 45 ham)
- [ ] Vocabulary expansion verified (> 288 features)
- [ ] Console output reflects retrained model results

**Hints:**
- Inspect new top words in `outputs/top_words.png`.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 6.4: Adversarial Good-Word Stuffing Evasion (15 min)
**Objective:** Conduct an adversarial robustness experiment against the Bag-of-Words Naive Bayes model.

**Problem Statement:** 
Demonstrate the "Good-Word Stuffing" vulnerability by taking a message that the model originally flagged as spam and appending benign legitimate keywords until the model's prediction flips to ham.

**Base Spam Message:**
`"Lowest price guaranteed! Get vitamins at 50% off. Buy now."`

**Requirements:**
1. Confirm that the base message is classified as `spam` with high confidence
2. Create an adversarial message by appending strong ham keywords:
   `"Lowest price guaranteed! Get vitamins at 50% off. Buy now. Meeting at library tomorrow to review study notes for class."`
3. Pass both versions to `model.predict_proba()` and compare the spam probability scores
4. Determine how many ham words are required to flip the prediction from spam to ham
5. Write a 3-sentence security assessment explaining why modern industrial filters pair ML with sender reputation to defeat this attack

**Constraints:** 
Use the trained model pipeline from `main.py`.

**Expected Behaviour:** 
A numerical report showing the drop in spam probability as legitimate tokens are stuffed into the message.

**Acceptance Criteria:**
- [ ] Base message verified classified as spam
- [ ] Adversarial message evaluated with `predict_proba()`
- [ ] Significant probability drop demonstrated
- [ ] Written security analysis documents the vulnerability of pure Bag-of-Words models

**Hints:**
- Words like `"meeting"`, `"library"`, `"notes"`, `"class"` carry large negative log-odds scores that directly cancel out spam words.

**Difficulty:** Advanced
**Estimated Completion Time:** 15 minutes
