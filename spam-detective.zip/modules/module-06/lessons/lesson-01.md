# Lesson 01: Running the End-to-End Pipeline

**Lesson ID:** lesson-01
**Module:** module-06
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Execute `main.py` seamlessly from the command line in any environment
- Trace the complete script execution lifecycle from imports to final termination
- Explain the significance of the `if __name__ == "__main__":` entrypoint
- Verify that all three artifact outputs are generated correctly
- Interpret console diagnostic logs in real time

## Prerequisites
- Completion of Modules 01 through 05
- Terminal navigation and Python execution skills

## Concept Explanation

### The Execution Lifecycle of `main.py`
The entire **Spam Detective** codebase is packaged into a clean, modular Python application. When you enter `python main.py` in your terminal, the script executes through six sequential phases:

```
Phase 1: Environment & Backend Configuration (Lines 10-27)
         Imports pathlib, pandas, scikit-learn, and sets matplotlib "Agg" backend.
         Resolves absolute paths (BASE, DATA, OUT) and creates outputs/ directory.
                             │
                             ▼
Phase 2: Data Ingestion & Partitioning (Lines 39-42)
         Loads messages.csv (80 rows).
         Performs 75/25 stratified split (60 train, 20 test).
                             │
                             ▼
Phase 3: Pipeline Training & Evaluation (Lines 44-59)
         Constructs Pipeline(CountVectorizer + MultinomialNB).
         Fits model on X_train.
         Computes accuracy (100.0%) and prints classification report.
                             │
                             ▼
Phase 4: Feature Interpretability (Lines 60-65)
         Queries classifier.classes_ dynamically.
         Runs top_words() to extract top 10 clues for spam and ham.
                             │
                             ▼
Phase 5: Inference on Live Messages (Lines 67-80)
         Predicts classes and probability confidences for 4 realistic test messages.
                             │
                             ▼
Phase 6: Artifact Serialization & Export (Lines 82-113)
         Generates outputs/top_words.png.
         Generates outputs/confusion_matrix.png.
         Writes outputs/predictions.txt.
```

### The Standard Python Entrypoint
At the bottom of `main.py` (lines 116-117), we find the standard Python execution guard:
```python
if __name__ == "__main__":
    main()
```
- `__name__` is a built-in variable set by Python at runtime.
- When `main.py` is executed directly from the terminal (`python main.py`), `__name__` evaluates to `"__main__"`, triggering `main()`.
- If another script or testing harness imports `main.py` (`import main`), the code inside `main()` is **not** executed automatically, allowing other developers to import helper functions like `top_words()` without accidentally running the entire pipeline!

### Headless Backend Execution
Notice lines 12-15:
```python
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
```
By switching to the `"Agg"` non-interactive backend before importing `pyplot`, `main.py` avoids attempting to connect to an X11, Wayland, or Windows display window. This guarantees that the script runs smoothly on remote Linux servers, Docker containers, and automated grading systems without crashing with `UserWarning` or display connection errors.

## Relevant Code (from main.py, lines 10-27 and 112-117)

```python
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)

# ...

    print("
Saved: outputs/top_words.png, outputs/confusion_matrix.png, outputs/predictions.txt")
    print("Try this: add five of your own spam and normal messages, then retrain.")


if __name__ == "__main__":
    main()
```

### Code Explanation
- **Lines 12-15:** Configures the headless Matplotlib rendering engine.
- **Lines 24-27:** Resolves platform-independent paths and creates `outputs/`.
- **Lines 112-113:** Logs output paths and provides an educational call to action.
- **Lines 116-117:** Provides a modular, reusable script entrypoint.

## Worked Example

Let us run `main.py` from the command line and verify the exact terminal output:

```bash
cd "/home/aziz/foundev/Foundev-main/beginner-projects-main/AI-ML Beginners/projects/04_spam_detective"
python3 main.py
```

**Console Output:**
```
============================================================
SPAM DETECTIVE
============================================================
Accuracy: 100.0%

              precision    recall  f1-score   support

         ham       1.00      1.00      1.00        10
        spam       1.00      1.00      1.00        10

    accuracy                           1.00        20
   macro avg       1.00      1.00      1.00        20
weighted avg       1.00      1.00      1.00        20

Top spam clues: buy, price, 50 buy, price guaranteed, 50, order, lowest, guaranteed, lowest price, risk
Top normal clues: meeting, today class, send notes, start, ll, tomorrow, ll minutes, minutes late, minutes, meeting lunch

New message predictions:
  spam (100%) -> Congratulations! You won a free smartphone. Click now to claim your prize.
  ham  (99%) -> Can we meet at the library at 4 pm to review the project?
  spam (98%) -> URGENT: verify your password immediately or your account will be suspended.
  ham  (88%) -> Thanks for sending the notes. I will read them tonight.

Saved: outputs/top_words.png, outputs/confusion_matrix.png, outputs/predictions.txt
Try this: add five of your own spam and normal messages, then retrain.
```

## Step-by-Step Student Instructions

1. **Open your terminal** and navigate to the project directory:
   ```bash
   cd "beginner-projects-main/AI-ML Beginners/projects/04_spam_detective"
   ```
2. **Execute `main.py`**:
   ```bash
   python main.py
   ```
3. **Verify the generated files** in the `outputs/` directory:
   ```bash
   ls -la outputs/
   ```
4. **Confirm file sizes**: Verify that `top_words.png` and `confusion_matrix.png` are valid image files (> 10 KB) and `predictions.txt` is non-empty.

## Expected Output or Observable Behaviour

The terminal executes cleanly in under 2 seconds, displaying the banner, metrics, top clues, and live message confidences, followed by the confirmation line:
```
Saved: outputs/top_words.png, outputs/confusion_matrix.png, outputs/predictions.txt
```

## Practical Exercises

- **Exercise 1.1:** What is the purpose of `if __name__ == "__main__":` in Python?
- **Exercise 1.2:** Why must `matplotlib.use("Agg")` be called BEFORE importing `matplotlib.pyplot`?
- **Exercise 1.3:** Measure the execution time of `main.py` using the Linux `time` command (`time python main.py`). Approximately how many seconds does it take?
- **Exercise 1.4:** If the `outputs/` directory already exists before running the script, does `main.py` crash? Why or why not?

## Common Mistakes and Debugging

| Mistake | Why it happens | Correction |
|---|---|---|
| Putting code outside functions | Global scope pollution | Encapsulate main logic inside `def main():` |
| Calling `plt.show()` in automated scripts | Halting execution waiting for user to close window | Use `fig.savefig()` and `plt.close(fig)` instead |
| Inverting `if __name__ == "__main__":` | Syntax error | Ensure correct double underscores `__name__` and `"__main__"` |
| Forgetting to install dependencies | `ModuleNotFoundError` for pandas or scikit-learn | Run `pip install pandas scikit-learn matplotlib numpy` |

## Best Practices and Security Considerations

- **Clean Script Architecture:** Encapsulate executable procedures in functions (`main()`) to facilitate automated testing and imports.
- **Fail-Safe Directory Creation:** Always pair directory paths with `mkdir(exist_ok=True)`.
- **Exit Codes:** Ensure scripts terminate with status code 0 on success to support automated CI/CD validation.

## Summary

`main.py` executes a complete, 6-phase machine learning pipeline in under two seconds. By setting the `Agg` headless backend, utilizing `pathlib` for path independence, and structuring the code around `def main():` and `if __name__ == "__main__":`, the project adheres to professional Python software engineering and reproducible research standards.

## Knowledge-check Questions

1. What are the six operational phases executed by `main.py`?
2. What happens if another script imports `main.py` as a module?
3. What is the role of `matplotlib.use("Agg")`?
4. What line in `main.py` guarantees that the `outputs/` directory is created safely?
5. How does `main.py` notify the user that all artifacts have been saved successfully?

## References

- Python __main__ documentation: https://docs.python.org/3/library/__main__.html
- Writing Clean, Modular Python Code: https://peps.python.org/pep-0008/
- Matplotlib Agg backend: https://matplotlib.org/stable/users/explain/backends.html
