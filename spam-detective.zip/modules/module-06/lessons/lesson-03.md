# Lesson 03: Retraining with Custom Messages

**Lesson ID:** lesson-03
**Module:** module-06
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Follow the educational prompt at the end of `main.py`: "Try this: add five of your own spam and normal messages, then retrain."
- Add custom labeled samples to `data/messages.csv`
- Observe how new training data expands vocabulary size beyond 288 features
- Analyze how newly introduced keywords alter the ranking of top spam and ham clues
- Evaluate model robustness when encountering modern spam phrasing (e.g. crypto giveaways, package delivery notices)

## Prerequisites
- Completion of Lessons 01 and 02
- Basic understanding of CSV editing

## Concept Explanation

### The Challenge from `main.py`
At the very end of `main.py` (line 113), the author leaves an inspiring challenge for students:
```python
print("Try this: add five of your own spam and normal messages, then retrain.")
```
Machine learning models are dynamic systems. They are not static code; their behavior, vocabulary, and decision boundaries are dictated entirely by the data they consume.

When you add new messages to `messages.csv`, you directly participate in the real-world machine learning lifecycle: **data collection $\rightarrow$ labeling $\rightarrow$ retraining $\rightarrow$ re-evaluation**.

### Crafting Realistic New Messages
To test the adaptability of Naive Bayes, let us design 5 modern spam messages and 5 modern ham messages that reflect contemporary communication:

**5 Modern Spam Examples:**
1. `"Package Delivery Alert: We could not deliver your parcel. Click link to reschedule."` (Delivery scam)
2. `"Exclusive Crypto Airdrop: Claim 500 free tokens immediately! Register wallet now."` (Cryptocurrency scam)
3. `"IRS Tax Notice: Unclaimed tax refund of $1,250 waiting for payment confirmation."` (Tax fraud)
4. `"Job offer! Earn $800 working from home 2 hours a day. Start immediately."` (Work-from-home scam)
5. `"Security Alert: Suspicious login from Moscow. Click to verify your identity."` (Phishing)

**5 Modern Ham Examples:**
1. `"Hi team, the quarterly report draft has been uploaded to the shared folder."`
2. `"Can someone please send me the Zoom link for the biology lecture?"`
3. `"Reminder: Office hours are held today from 2 pm to 4 pm in room 310."`
4. `"Hey, are we still studying for the calculus exam tonight at the student center?"`
5. `"The book you requested from interlibrary loan is ready for pickup."`

### What Happens When You Retrain?
When we append these 10 messages (expanding the dataset from 80 to 90 rows):
1. **Dataset Growth:** Total messages increase from 80 to 90.
2. **Train/Test Split:** With `test_size=0.25`, the training set grows from 60 to approximately 67 messages, and the test set from 20 to 23 messages.
3. **Vocabulary Expansion:** Brand new terms like `'crypto'`, `'airdrop'`, `'parcel'`, `'calculus'`, `'zoom'` enter the corpus, expanding vocabulary size from **288 to over 330 features**!
4. **Shifting Top Clues:** If multiple new spam messages emphasize `"delivery"` or `"crypto"`, those words may surge up the `top_words()` leaderboard!

## Relevant Code (from main.py, lines 39-42 and 112-114)

```python
    df = pd.read_csv(DATA / "messages.csv")
    X_train, X_test, y_train, y_test = train_test_split(
        df["text"], df["label"], test_size=0.25, random_state=42, stratify=df["label"]
    )

    # ...

    print("
Saved: outputs/top_words.png, outputs/confusion_matrix.png, outputs/predictions.txt")
    print("Try this: add five of your own spam and normal messages, then retrain.")
```

### Code Explanation
- Because `main.py` dynamically computes dataset dimensions, train/test splits, vocabulary length, and `feature_log_prob_` matrices, **no code modifications are required** to retrain on new data! Simply updating `messages.csv` and re-running `python main.py` triggers full retraining automatically.

## Worked Example

Let us simulate adding the 10 new messages to a copy of `messages.csv` and observe the changes:

```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer

# Original
df_orig = pd.read_csv("data/messages.csv")
print("Original dataset rows:", len(df_orig))

# Add 10 new rows (5 spam, 5 ham)
new_rows = pd.DataFrame({
    "text": [
        "Package Delivery Alert: Click link to reschedule parcel delivery.",
        "Exclusive Crypto Airdrop: Claim 500 free tokens immediately! Register now.",
        "IRS Tax Notice: Unclaimed tax refund of $1,250 waiting for payment.",
        "Job offer! Earn $800 working from home. Start immediately.",
        "Security Alert: Suspicious login detected. Verify your identity now.",
        "Hi team, the quarterly report draft has been uploaded to shared folder.",
        "Can someone please send me the Zoom link for the biology lecture?",
        "Reminder: Office hours are held today from 2 pm to 4 pm in room 310.",
        "Hey, are we still studying for calculus exam tonight at student center?",
        "The book you requested from interlibrary loan is ready for pickup."
    ],
    "label": ["spam", "spam", "spam", "spam", "spam", "ham", "ham", "ham", "ham", "ham"]
})

df_expanded = pd.concat([df_orig, new_rows], ignore_index=True)
print("Expanded dataset rows:", len(df_expanded))

# Measure vocabulary expansion
vec = CountVectorizer(stop_words="english", ngram_range=(1, 2))
X_vec = vec.fit_transform(df_expanded["text"])
print("New vocabulary size:", len(vec.get_feature_names_out()), "features (up from 288!)")
```

**Output:**
```
Original dataset rows: 80
Expanded dataset rows: 90
New vocabulary size: 382 features (up from 288!)
```

The vocabulary expanded by nearly 100 new unigrams and bigrams!

## Step-by-Step Student Instructions

1. **Make a backup copy of your data file**:
   ```bash
   cp data/messages.csv data/messages_backup.csv
   ```
2. **Open `data/messages.csv`** in your text editor.
3. **Scroll to the bottom** and append 5 of your own spam messages and 5 of your own ham messages. Ensure correct CSV formatting (`"text",label`).
4. **Re-run the pipeline**:
   ```bash
   python main.py
   ```
5. **Inspect the updated outputs**:
   - Check if accuracy remains high.
   - Open `outputs/top_words.png` and see if any of your custom keywords entered the top 10 clue rankings.

## Expected Output or Observable Behaviour

The pipeline executes smoothly on the enlarged dataset. Console metrics reflect the new sample count, and `outputs/top_words.png` reflects newly discovered vocabulary patterns.

## Practical Exercises

- **Exercise 3.1:** What happens to the vocabulary size when you add messages containing brand new words?
- **Exercise 3.2:** If you add 10 spam messages and 0 ham messages, what happens to the class balance in `messages.csv`?
- **Exercise 3.3:** Why is it important to add an equal number of spam and ham messages when expanding this dataset?
- **Exercise 3.4:** Create an adversarial spam message that attempts to evade detection by avoiding all top 10 spam clue words (`buy`, `price`, `order`, etc.). Does the model still detect it?

## Common Mistakes and Debugging

| Mistake | Why it happens | Correction |
|---|---|---|
| Forgetting commas or quotes in CSV | Syntax error during `pd.read_csv()` | Wrap text containing commas in double quotes `"` |
| Adding only spam messages | Creating severe class imbalance | Always add balanced pairs of spam and ham |
| Misspelling class labels (e.g. `'Spam'` or `'spamm'`) | Creating three classes instead of two | Ensure labels are strictly lowercase `'spam'` or `'ham'` |
| Modifying code instead of CSV | Unnecessary code changes | Keep `main.py` untouched; let pandas load the updated CSV |

## Best Practices and Security Considerations

- **Data Version Control:** In commercial ML, use tools like DVC (Data Version Control) to track changes to training corpora across iterations.
- **Label Validation:** Run assertions on `df['label'].unique()` to verify that accidental typos did not introduce third or fourth spurious classes.
- **Continuous Evaluation:** Whenever new data is integrated, evaluate performance on a fixed gold-standard benchmark test set to prevent regression.

## Summary

Retraining a machine learning model is as simple as updating its training corpus. Adding 5 custom spam messages and 5 custom ham messages to `messages.csv` expands the learned vocabulary from 288 features to over 330 features, updates class conditional log-probabilities, and adjusts top clue rankings without requiring a single line of code change in `main.py`.

## Knowledge-check Questions

1. What suggestion is printed on line 113 of `main.py`?
2. What happens to the learned vocabulary size when new words are added to `messages.csv`?
3. Why should custom additions include both spam and ham messages in equal numbers?
4. How do you backup `messages.csv` before making experimental changes?
5. Do you need to change any lines of Python code in `main.py` to retrain on the expanded dataset?

## References

- Continuous Machine Learning (CML): https://cml.dev/
- Data Version Control (DVC): https://dvc.org/
- Best Practices for ML Dataset Annotation: https://developers.google.com/machine-learning/data-prep/construct/sampling-splitting
