# Lesson 04: Production Extensions, Limitations, and Future Directions

**Lesson ID:** lesson-04
**Module:** module-06
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Identify the inherent architectural limitations of Bag-of-Words and Naive Bayes models
- Describe common adversarial evasion attacks, including "Good-Word Stuffing" and character obfuscation
- Compare CountVectorizer (term frequencies) with TF-IDF (Term Frequency-Inverse Document Frequency)
- Explain how industrial spam filters integrate email protocol metadata (SPF, DKIM, DMARC, IP reputation)
- Outline how modern transformer models (BERT, RoBERTa) capture deep semantic context

## Prerequisites
- Completion of Lessons 01, 02, and 03
- Comprehensive understanding of the full Spam Detective pipeline

## Concept Explanation

### The Limitations of Naive Bayes and Bag-of-Words
While Naive Bayes with `CountVectorizer` is fast, transparent, and surprisingly effective, it has structural limitations:
1. **Total Loss of Word Order:** It cannot distinguish between `"not spam"` and `"spam, not!"` or `"payment was received"` versus `"received no payment"`.
2. **Extreme Probability Confidence:** Because Naive Bayes assumes all words are independent, it continuously multiplies probabilities, often pushing confidence to artificial extremes ($99.999\%$ or $0.0001\%$), even when human context is ambiguous.
3. **Inability to Understand Synonyms:** It treats `"discount"`, `"sale"`, `"bargain"`, and `"markdown"` as four completely unrelated mathematical features.

### Adversarial Attacks: The Evolving Arms Race
Spam filtering is an **adversarial problem**. Unlike predicting the weather, where nature does not deliberately try to fool your model, spammers actively analyze filters and design counter-measures:

#### 1. Good-Word Stuffing
Because Bag-of-Words simply counts word frequencies, a spammer can take a blatant spam email and append 200 words from a Wikipedia article about science or a paragraph from Shakespeare at the bottom in tiny, white font:
- The filter sees 5 spam words (`"buy"`, `"cheap"`, `"pills"`) and 200 strong ham words (`"university"`, `"research"`, `"library"`, `"experiment"`, `"meeting"`).
- The Bayesian posterior is overwhelmed by the legitimate words, and the spam message bypasses the filter into the inbox!

#### 2. Character Obfuscation and Homoglyphs
Spammers deliberately inject typos, punctuation, or foreign alphabets:
- `"C@SH"`, `"W!NNER"`, `"F-R-E-E"`
- Using Cyrillic 'а' (Unicode U+0430) instead of Latin 'a' (Unicode U+0061). To the human eye, `"bank"` looks identical, but `CountVectorizer` sees an unknown OOV token!

### Advanced NLP Upgrades: From Counts to TF-IDF
In our project, `CountVectorizer` counts raw occurrences. In larger corpora, a standard upgrade is **TF-IDF (Term Frequency-Inverse Document Frequency)**:
$$\text{TF-IDF}(t, d) = \text{TF}(t, d) \times \ln \left(\frac{1 + N}{1 + \text{DF}(t)}\right)$$
- Words that appear in almost *every* email (even if not on the stop-word list) receive lower weights.
- Rare, distinctive words that appear only in specific spam campaigns receive higher mathematical weights.

### Modern Industrial Spam Architecture
Modern enterprise email defense systems (like Google Gmail or Microsoft Defender) do not rely on text classification alone. They use a **multi-layered defense-in-depth architecture**:
1. **Protocol Authentication:** Verifying cryptographic headers:
   - **SPF (Sender Policy Framework):** Verifies the sending server's IP address.
   - **DKIM (DomainKeys Identified Mail):** Cryptographically signs email headers.
   - **DMARC:** Specifies enforcement policies for failing domain checks.
2. **Network & Domain Reputation:** Real-time blacklists (DNSBL) that immediately reject connections from known spam botnets.
3. **Deep Learning & Transformers:** Modern LLMs and contextual transformers (like BERT or RoBERTa) that read full sentences in context, completely neutralizing good-word stuffing attacks.

## Relevant Code (from main.py, lines 44-48)

```python
    model = Pipeline(
        [
            ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
            ("classifier", MultinomialNB()),
        ]
    )
```

### Code Explanation
- The beauty of the scikit-learn `Pipeline` is its modularity. If you wish to upgrade to TF-IDF, you simply replace `CountVectorizer(...)` with `TfidfVectorizer(...)` on line 46—the rest of your training, evaluation, and plotting code remains identical!

## Worked Example

Let us see how easily `main.py` can be extended to use `TfidfVectorizer`:

```python
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline

# Upgraded pipeline using TF-IDF weighting!
tfidf_model = Pipeline([
    ("vectorizer", TfidfVectorizer(stop_words="english", ngram_range=(1, 2))),
    ("classifier", MultinomialNB())
])

tfidf_model.fit(X_train, y_train)
tfidf_acc = tfidf_model.score(X_test, y_test)
print(f"TF-IDF Model Accuracy: {tfidf_acc:.1%}")
```

**Output:**
```
TF-IDF Model Accuracy: 100.0%
```

The modular scikit-learn API enables seamless experimentation and architecture upgrades with minimal friction.

## Step-by-Step Student Instructions

1. **Review the architecture diagram** in `architecture.md`.
2. **Reflect on the limitations of Bag-of-Words**:
   Consider how you would classify the sentence: `"This is not spam, it is a genuine meeting notice."`
   Notice how both `"not"` and `"is"` might be stripped by stop words, leaving `"spam"` and `"meeting"` to compete!
3. **Test a good-word stuffing experiment**:
   Take a spam message and append: `"library meeting notes study session project class tomorrow"`.
   Pass it to `model.predict_proba()` and observe how the legitimate words dilute the spam prediction.
4. **Research SPF and DKIM**: Read how email servers verify sender identity before passing messages to machine learning filters.

## Expected Output or Observable Behaviour

Students understand that while `main.py` implements the foundational core of NLP classification, industrial email security pairs statistical text models with cryptographic protocols, reputation databases, and deep contextual representations.

## Practical Exercises

- **Exercise 4.1:** What is "Good-Word Stuffing", and how does it exploit the Bag-of-Words assumption?
- **Exercise 4.2:** What is the difference between `CountVectorizer` and `TfidfVectorizer`?
- **Exercise 4.3:** Name two cryptographic email authentication protocols (e.g. SPF, DKIM) used alongside ML filters.
- **Exercise 4.4:** Why can a contextual transformer model (like BERT) handle the phrase `"not a scam"` better than a Bag-of-Words Naive Bayes model?

## Common Mistakes and Debugging

| Mistake | Why it happens | Correction |
|---|---|---|
| Assuming ML solves 100% of spam | Underestimating adversarial adaptation | Recognize that spam filtering requires multi-layered defense |
| Believing Naive Bayes understands context | Forgetting the independence assumption | Note that negation and sarcasm frequently confuse Bag-of-Words |
| Overfitting to small vocabulary | Assuming 288 features can cover all English spam | Scale training data to tens of thousands of messages in production |
| Ignoring protocol security | Relying only on text content | Combine text classifiers with SPF/DKIM/DMARC header checks |

## Best Practices and Security Considerations

- **Defense in Depth:** Never rely on a single classifier; combine protocol checks, IP reputation, heuristic signatures, and ML models.
- **Adversarial Hardening:** Train models on adversarial perturbations and character obfuscations to build resilience.
- **Model Monitoring:** Continuously monitor incoming false positive reports from users to catch emerging evasion techniques.

## Summary

The Spam Detective project implements the foundational statistical text classification architecture that pioneered automated spam filtering. While Bag-of-Words and Naive Bayes are vulnerable to adversarial good-word stuffing and lack grammatical context, their speed and interpretability make them an essential baseline. Modern industrial filters combine these NLP techniques with TF-IDF, transformer embeddings, and cryptographic protocols like SPF and DKIM.

## Knowledge-check Questions

1. What is the "Good-Word Stuffing" adversarial evasion attack?
2. How does TF-IDF differ from raw term frequency counting?
3. What are SPF and DKIM, and how do they support email filtering?
4. What critical language feature is missed by Bag-of-Words that transformer models (like BERT) capture?
5. How can the scikit-learn Pipeline in `main.py` be upgraded to use TF-IDF?

## References

- scikit-learn TfidfVectorizer: https://scikit-learn.org/stable/modules/generated/sklearn.feature_extraction.text.TfidfVectorizer.html
- Adversarial Attacks on Text Classifiers: https://arxiv.org/abs/1907.11932
- Overview of Email Authentication (SPF, DKIM, DMARC): https://www.cisa.gov/news-events/alerts/2020/09/21/email-security-best-practices
