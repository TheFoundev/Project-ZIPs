# Module 5 Exercises: Evaluation & Visualization

## Exercise 5.1: Computing Evaluation Metrics by Hand (15 min)
**Objective:** Calculate Accuracy, Precision, Recall, and F1-score from a simulated confusion matrix.

**Problem Statement:** 
Suppose an automated filter evaluates 200 incoming messages and produces the following confusion matrix counts (where `"spam"` is the positive class):
- True Positives (TP): 85
- False Positives (FP): 5
- False Negatives (FN): 15
- True Negatives (TN): 95

**Requirements:**
1. Calculate the overall classification Accuracy
2. Calculate Precision on the spam class
3. Calculate Recall on the spam class
4. Calculate the F1-Score for the spam class
5. Analyze whether an FP of 5 is acceptable if these messages were executive emails

**Constraints:** 
Show all mathematical equations and calculation steps clearly.

**Expected Behaviour:** 
A step-by-step derivation calculating each metric and discussing the operational consequences of the 5 false positives.

**Acceptance Criteria:**
- [ ] Accuracy calculated: $(85 + 95) / 200 = 180 / 200 = 90.0\%$
- [ ] Precision calculated: $85 / (85 + 5) = 85 / 90 \approx 94.44\%$
- [ ] Recall calculated: $85 / (85 + 15) = 85 / 100 = 85.0\%$
- [ ] F1-Score calculated: $2 \times (0.9444 \times 0.85) / (0.9444 + 0.85) \approx 89.47\%$
- [ ] Concrete operational discussion explaining why 5 false positive executive emails could cause major business disruption

**Hints:**
- $\text{F1} = \frac{2 \times P \times R}{P + R}$.

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 5.2: Diagnostic Confusion Matrix Generation (15 min)
**Objective:** Compute, print, and visually plot the project's confusion matrix.

**Problem Statement:** 
Write a Python script that evaluates the test set predictions, prints the numerical matrix, and generates a saved PNG plot matching lines 95-103 of `main.py`.

**Requirements:**
1. Generate predictions on `X_test` using the fitted pipeline
2. Compute the confusion matrix with explicit labels `["ham", "spam"]`
3. Use `ConfusionMatrixDisplay` to plot the matrix with `cmap="Reds"` and `colorbar=False`
4. Set the title to `"Spam filter mistakes"` and save to a file named `my_confusion_matrix.png`
5. Close the figure using `plt.close(fig)`

**Constraints:** 
Ensure headless execution by using `matplotlib.use("Agg")`.

**Expected Behaviour:** 
Terminal displays `[[10, 0], [0, 10]]` and saves a crisp PNG image to disk.

**Acceptance Criteria:**
- [ ] Correct confusion matrix dimensions `(2, 2)`
- [ ] Off-diagonal errors verified as 0
- [ ] Plot generated with correct title, colormap, and labels
- [ ] `plt.close()` verified called

**Hints:**
- Use `ConfusionMatrixDisplay(cm, display_labels=labels).plot(ax=ax, cmap="Reds", colorbar=False)`.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 5.3: Customizing the Clue Word Visualization (15 min)
**Objective:** Modify the dual horizontal bar chart to display the top 15 words and custom color themes.

**Problem Statement:** 
Adapt lines 82-93 of `main.py` to plot the top 15 clues for spam and ham using custom hex colors (`#8e44ad` for purple spam, `#27ae60` for green ham).

**Requirements:**
1. Call `top_words(model, spam_index, n=15)` and `top_words(model, ham_index, n=15)`
2. Create a figure with `figsize=(12, 6)` and 2 subplots side by side
3. Plot the horizontal bars with slice reversal `words[::-1]`
4. Apply the custom color palette and verify that the 15 bars render cleanly without truncation
5. Save the result as `top_15_words.png` with `dpi=150` and `bbox_inches="tight"`

**Constraints:** 
Follow clean matplotlib object-oriented styling conventions.

**Expected Behaviour:** 
A dual-panel bar chart displaying 15 bars per panel with purple and green color styling.

**Acceptance Criteria:**
- [ ] Top 15 words successfully extracted for both classes
- [ ] Figure canvas size adjusted to accommodate 15 bars
- [ ] Hex color codes applied correctly
- [ ] PNG exported cleanly with 150 DPI

**Hints:**
- Increase vertical figure height (e.g. `figsize=(12, 6)`) to ensure 15 bars have adequate breathing room.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 5.4: Live Message Testing and Decision Boundary Exploration (15 min)
**Objective:** Evaluate custom test messages using `predict_proba()` and explore adversarial thresholding.

**Problem Statement:** 
Test 5 custom sentences designed to challenge the model's decision boundaries. Inspect how soft probability confidences change when spam and ham words are mixed.

**Custom Sentences to Test:**
1. `"Free tutoring session available at the university library today."`
2. `"Urgent notice: unpaid invoice attached. Send cash today."`
3. `"Meeting cancelled. Lowest price vitamins available."`
4. `"Are you free to meet Nina for lunch at 4 pm?"`
5. `"Congratulations on finishing your exam! Let's celebrate."`

**Requirements:**
1. Pass the list of 5 sentences to `model.predict()` and `model.predict_proba()`
2. Print a formatted table showing: Sentence, Predicted Class, Ham Probability, and Spam Probability
3. Identify which sentence had the lowest prediction confidence (closest to 50/50)
4. Explain how the mixture of tokens in that sentence created competing evidence

**Constraints:** 
Execute against the trained Spam Detective pipeline.

**Expected Behaviour:** 
A formatted output table displaying probabilities and a thoughtful analysis of the most ambiguous sentence.

**Acceptance Criteria:**
- [ ] All 5 sentences evaluated successfully
- [ ] Formatted output confirms probabilities sum to 100% for each sentence
- [ ] Ambiguous sentences (e.g. mixing `"free"` with `"library"` or `"lowest price"` with `"meeting"`) identified
- [ ] Explanation traces token log-probabilities to explain the model's final decision

**Hints:**
- Use `probs[:, classes.index('spam')]` to extract spam probabilities.

**Difficulty:** Advanced
**Estimated Completion Time:** 15 minutes
