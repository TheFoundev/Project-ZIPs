# Lesson 01: Measuring Performance: Accuracy, Precision, Recall, and F1-Score

**Lesson ID:** lesson-01
**Module:** module-05
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Calculate overall classification accuracy using `accuracy_score()`
- Define Precision, Recall, and F1-score in the context of binary text classification
- Interpret every column of scikit-learn's `classification_report()`
- Explain why high Precision on the spam class is vital to protect against false positive errors
- Verify the 100% test performance achieved by the Spam Detective model

## Prerequisites
- Completion of Module 04
- Basic understanding of fractions and percentages

## Concept Explanation

### Beyond Overall Accuracy
In `main.py` lines 53-57, the script calculates overall accuracy:
```python
accuracy = accuracy_score(y_test, predictions)
print(f"Accuracy: {accuracy:.1%}
")
```
Accuracy measures the proportion of total test predictions that matched the true label:
$$\text{Accuracy} = \frac{\text{Correct Predictions}}{\text{Total Predictions}} = \frac{20}{20} = 100.0\%$$

While 100% accuracy on our test set is outstanding, in real-world machine learning, accuracy alone can be misleading. As we discovered in Module 02, an imbalanced filter could achieve 99% accuracy simply by labeling every message as ham while failing to catch any spam at all!

To truly understand how a classifier performs, we must evaluate **Precision**, **Recall**, and **F1-Score**.

### Defining Precision
**Precision** answers the question:
**"Of all the messages the filter labeled as spam, what fraction was actually spam?"**

$$\text{Precision} = \frac{\text{True Positives}}{\text{True Positives} + \text{False Positives}}$$

- If a filter flags 10 messages as spam, and all 10 are real spam (0 false positives), Precision is **1.00 (100%)**.
- If a filter flags 10 messages as spam, but 2 were legitimate work emails (2 false positives), Precision drops to $8/10 = \mathbf{0.80\text{ (80%)}}$.
- In spam filtering, **high precision is paramount** because false positives cause critical user communications to be lost.

### Defining Recall
**Recall** (also called Sensitivity) answers the question:
**"Of all the actual spam messages that were sent, what fraction did the filter successfully catch?"**

$$\text{Recall} = \frac{\text{True Positives}}{\text{True Positives} + \text{False Negatives}}$$

- If there were 10 actual spam messages, and the filter caught all 10, Recall is **1.00 (100%)**.
- If the filter caught 8 spam messages but let 2 slip into the inbox, Recall is $8/10 = \mathbf{0.80\text{ (80%)}}$.

### The F1-Score: Harmonic Mean
Precision and recall often pull in opposite directions: making a filter aggressive increases recall but risks false positives (lower precision); making it cautious protects precision but allows spam through (lower recall).

The **F1-Score** balances both metrics by computing their **harmonic mean**:
$$\text{F1-Score} = 2 \times \frac{\text{Precision} \times \text{Recall}}{\text{Precision} + \text{Recall}}$$
The harmonic mean severely penalizes extreme imbalances (e.g. 100% precision with 5% recall yields an F1 of only ~9.5%).

### Reading `classification_report()`
In `main.py` line 58, `classification_report(y_test, predictions, zero_division=0)` outputs:
```
              precision    recall  f1-score   support

         ham       1.00      1.00      1.00        10
        spam       1.00      1.00      1.00        10

    accuracy                           1.00        20
   macro avg       1.00      1.00      1.00        20
weighted avg       1.00      1.00      1.00        20
```
- **support:** The actual number of true instances in that class in `y_test` (10 ham, 10 spam).
- **macro avg:** The unweighted average of precision, recall, and F1 across both classes.
- **weighted avg:** The average weighted by the support of each class.
- **zero_division=0:** Prevents warnings if a class has 0 predicted instances.

## Relevant Code (from main.py, lines 19 and 53-59)

```python
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay, confusion_matrix

# ...
    accuracy = accuracy_score(y_test, predictions)
    print("=" * 60)
    print("SPAM DETECTIVE")
    print("=" * 60)
    print(f"Accuracy: {accuracy:.1%}\n")
    print(classification_report(y_test, predictions, zero_division=0))
```

### Code Explanation
- **Line 19:** Imports evaluation metric utilities from `sklearn.metrics`.
- **Line 53:** Computes test accuracy.
- **Lines 57-58:** Displays the accuracy percentage and complete classification report.

## Worked Example

Suppose on a different dataset of 100 messages (50 ham, 50 spam), a test run yields:
- 45 spam correctly detected (True Positives = 45)
- 5 spam missed (False Negatives = 5)
- 5 ham incorrectly flagged as spam (False Positives = 5)
- 45 ham delivered correctly (True Negatives = 45)

**Calculations for Spam:**
- $\text{Accuracy} = \frac{45 + 45}{100} = \frac{90}{100} = 90.0\%$
- $\text{Precision} = \frac{45}{45 + 5} = \frac{45}{50} = 90.0\%$
- $\text{Recall} = \frac{45}{45 + 5} = \frac{45}{50} = 90.0\%$
- $\text{F1-Score} = 2 \times \frac{0.90 \times 0.90}{0.90 + 0.90} = 0.90$

In our actual Spam Detective project, all 10 spam and 10 ham test messages were classified without error, yielding 1.00 across all metrics!

## Step-by-Step Student Instructions

1. **Open your Python shell** in the project directory.
2. **Import the metric functions**:
   ```python
   from sklearn.metrics import accuracy_score, classification_report
   ```
3. **Compute the metrics on your test split**:
   ```python
   acc = accuracy_score(y_test, predictions)
   print(f"Accuracy: {acc:.2%}")
   print(classification_report(y_test, predictions, zero_division=0))
   ```
4. **Inspect the support column**: Confirm that support is exactly 10 for `ham` and 10 for `spam`.

## Expected Output or Observable Behaviour

The terminal displays:
```
Accuracy: 100.00%
              precision    recall  f1-score   support

         ham       1.00      1.00      1.00        10
        spam       1.00      1.00      1.00        10

    accuracy                           1.00        20
   macro avg       1.00      1.00      1.00        20
weighted avg       1.00      1.00      1.00        20
```

## Practical Exercises

- **Exercise 1.1:** Write the mathematical definitions for Precision and Recall.
- **Exercise 1.2:** If an email filter catches 90 spam messages but incorrectly flags 10 important legitimate emails as spam, what is its spam precision?
- **Exercise 1.3:** What does the `support` column represent in `classification_report`?
- **Exercise 1.4:** Why does `main.py` set `zero_division=0` in the classification report call?

## Common Mistakes and Debugging

| Mistake | Why it happens | Correction |
|---|---|---|
| Inverting Precision and Recall | Confusing the denominator | Remember Precision divides by all predicted spam; Recall divides by all actual spam |
| Trusting accuracy on imbalanced data | Ignoring class distribution | Always examine the per-class Precision and Recall |
| Forgetting `zero_division=0` | Getting `UndefinedMetricWarning` when zero instances are predicted | Pass `zero_division=0` to ensure clean reporting |
| Passing predictions before true targets | Inverting argument order | Always pass `(y_true, y_pred)` in scikit-learn metric functions |

## Best Practices and Security Considerations

- **Tune for Precision on Spam:** When tuning decision thresholds, configure filters to maintain at least 99.5% precision on spam to avoid catastrophic false positives.
- **Support Verification:** Always check the `support` column to verify that evaluation sets contain sufficient test samples for both classes.
- **Macro vs Weighted Average:** In imbalanced settings, pay attention to the `macro avg` to ensure small classes are not masked by large classes.

## Summary

Evaluating a spam classifier requires assessing accuracy, precision, recall, and F1-score. Precision measures how many flagged emails are genuinely spam, protecting against costly false positive errors. Recall measures the percentage of spam captured. In `main.py`, `classification_report()` demonstrates perfect 100% precision, recall, and F1-score across all 20 test messages.

## Knowledge-check Questions

1. What is the overall test accuracy achieved by `main.py`?
2. What is the mathematical formula for Precision?
3. What is the mathematical formula for Recall?
4. What does the `support` value of 10 for `ham` signify?
5. Why is high precision on the spam class more critical than high recall in consumer email systems?

## References

- scikit-learn classification_report: https://scikit-learn.org/stable/modules/generated/sklearn.metrics.classification_report.html
- Precision and Recall - Wikipedia: https://en.wikipedia.org/wiki/Precision_and_recall
- Evaluating Classification Models - Google ML Crash Course: https://developers.google.com/machine-learning/crash-course/classification/precision-and-recall
