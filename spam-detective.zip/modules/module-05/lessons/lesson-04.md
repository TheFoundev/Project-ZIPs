# Lesson 04: Testing Live Messages and Probability Confidence

**Lesson ID:** lesson-04
**Module:** module-05
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Trace how `main.py` evaluates 4 realistic, previously unseen test messages
- Extract probability confidences using `model.predict_proba()`
- Interpret why specific messages receive high or moderate confidence scores
- Contrast binary classification decisions with continuous probability distributions
- Apply thresholding strategies for uncertain or borderline email classifications

## Prerequisites
- Completion of Lessons 01, 02, and 03
- Understanding of probabilities summing to 1.0

## Concept Explanation

### Beyond Binary Labels: Soft Confidence Scores
When an email arrives, a simple binary label (`"spam"`) tells us what the model decided, but it conceals a crucial piece of information: **how sure was the model?**

Was it 99.9% certain, or was it a 50.1% borderline guess?
- In `main.py` line 74: `new_predictions = model.predict(new_messages)` returns the hard binary labels.
- In `main.py` line 75: `probabilities = model.predict_proba(new_messages)` returns the continuous class probabilities.

For every message, `predict_proba()` outputs an array of floats that sum to exactly 1.0:
$$[P(\text{ham}), P(\text{spam})]$$
The model's **confidence** in its prediction is simply the probability assigned to the predicted class.

### Analyzing the 4 Realistic Project Test Messages
In `main.py` lines 68-73, we evaluate four realistic scenarios:

```python
new_messages = [
    "Congratulations! You won a free smartphone. Click now to claim your prize.",
    "Can we meet at the library at 4 pm to review the project?",
    "URGENT: verify your password immediately or your account will be suspended.",
    "Thanks for sending the notes. I will read them tonight.",
]
```

Let us examine the model's exact predictions and confidence scores:

| # | Message Text | Prediction | Confidence | Key Influential Clues |
|---|---|---|---|---|
| 1 | `"Congratulations! You won a free smartphone. Click now to claim your prize."` | **spam** | **100%** (99.97%) | `"free"`, `"claim"`, `"prize"` |
| 2 | `"Can we meet at the library at 4 pm to review the project?"` | **ham** | **99%** (98.79%) | `"meet"`, `"library"` |
| 3 | `"URGENT: verify your password immediately or your account will be suspended."` | **spam** | **98%** (98.36%) | `"urgent"`, `"password"`, `"suspended"` |
| 4 | `"Thanks for sending the notes. I will read them tonight."` | **ham** | **88%** (88.40%) | `"send notes"` (bigram), `"thanks"` |

### Why Message #4 Has 88% Confidence
Notice that while Messages #1, #2, and #3 achieve 98-100% confidence, Message #4 (`"Thanks for sending the notes. I will read them tonight."`) achieves **88.40%**.
Why the slightly lower confidence?
- `"sending the notes"` activates the strong normal clue bigram `'send notes'`.
- However, words like `"thanks"`, `"read"`, `"tonight"` appear less frequently in the 288-word training vocabulary than keywords like `"library"` or `"meeting"`.
- Without multiple heavy clues, the model still arrives at the correct verdict (`ham`), but with a healthy, honest 88% confidence rather than 99%.

### Operational Thresholding in Production
In a standard scikit-learn setup, any message with $P(\text{spam}) > 0.50$ is labeled as spam.
However, in high-stakes production email services:
- **Confidence > 95% Spam:** Route directly to Junk folder.
- **Confidence between 60% and 95% Spam:** Deliver to Inbox with a visual security warning banner (`"[CAUTION: SUSPECTED SPAM]"`).
- **Confidence < 60% Spam:** Deliver normally to Inbox.
Looking at soft probability confidences makes sophisticated, user-protective filtering policies possible.

## Relevant Code (from main.py, lines 67-80)

```python
    # ---- Test a few new messages --------------------------------------
    new_messages = [
        "Congratulations! You won a free smartphone. Click now to claim your prize.",
        "Can we meet at the library at 4 pm to review the project?",
        "URGENT: verify your password immediately or your account will be suspended.",
        "Thanks for sending the notes. I will read them tonight.",
    ]
    new_predictions = model.predict(new_messages)
    probabilities = model.predict_proba(new_messages)
    print("
New message predictions:")
    for message, prediction, probability in zip(new_messages, new_predictions, probabilities):
        confidence = probability[classes.index(prediction)]
        print(f"  {prediction:4s} ({confidence:.0%}) -> {message}")
```

### Code Explanation
- **Lines 68-73:** Defines the 4 test messages.
- **Lines 74-75:** Computes both predictions and probability matrices.
- **Lines 77-79:** Formats and prints the label, confidence percentage, and message text to the terminal.

## Worked Example

Let us run this exact inference block and inspect the raw probability arrays:

```python
# Assuming model is fitted
for msg in new_messages:
    pred = model.predict([msg])[0]
    probs = model.predict_proba([msg])[0]
    ham_prob = probs[classes.index("ham")]
    spam_prob = probs[classes.index("spam")]
    print(f"Message: {msg[:45]}...")
    print(f"  P(ham) = {ham_prob:.4f} | P(spam) = {spam_prob:.4f} -> {pred.upper()}")
```

**Output:**
```
Message: Congratulations! You won a free smartphone. Cl...
  P(ham) = 0.0003 | P(spam) = 0.9997 -> SPAM
Message: Can we meet at the library at 4 pm to review...
  P(ham) = 0.9879 | P(spam) = 0.0121 -> HAM
Message: URGENT: verify your password immediately or y...
  P(ham) = 0.0164 | P(spam) = 0.9836 -> SPAM
Message: Thanks for sending the notes. I will read th...
  P(ham) = 0.8840 | P(spam) = 0.1160 -> HAM
```

## Step-by-Step Student Instructions

1. **Run `main.py`** and observe the "New message predictions" console output:
   ```bash
   python main.py
   ```
2. **Add a custom 5th message** in your editor:
   `"Urgent: lowest price guaranteed on laptops. Buy now!"`
3. **Re-run the script** and check the model's confidence on your new message:
   Observe how multiple strong spam clues (`"urgent"`, `"lowest price"`, `"buy"`) push confidence to near 100%.
4. **Try a subtle edge-case message**:
   `"Are you free for lunch tomorrow?"`
   Observe whether the model correctly identifies it as `ham`.

## Expected Output or Observable Behaviour

The terminal displays:
```
New message predictions:
  spam (100%) -> Congratulations! You won a free smartphone. Click now to claim your prize.
  ham  (99%) -> Can we meet at the library at 4 pm to review the project?
  spam (98%) -> URGENT: verify your password immediately or your account will be suspended.
  ham  (88%) -> Thanks for sending the notes. I will read them tonight.
```

## Practical Exercises

- **Exercise 4.1:** What is the confidence percentage calculated for the urgent password verification message?
- **Exercise 4.2:** In line 78, what does `classes.index(prediction)` accomplish?
- **Exercise 4.3:** If a message produces `predict_proba()` output of `[0.51, 0.49]`, what is the predicted class, and why might an email system treat this message with caution?
- **Exercise 4.4:** Write a Python function that classifies a message as `"spam"` ONLY if its spam probability exceeds 95%, otherwise classifying it as `"ham"`.

## Common Mistakes and Debugging

| Mistake | Why it happens | Correction |
|---|---|---|
| Passing a single string to `predict_proba` | Passing `"message"` instead of `["message"]` | Always pass a list or Series of strings |
| Assuming column 0 is always ham | Overlooking class ordering | Query `classes.index('ham')` dynamically |
| Forgetting probabilities sum to 1.0 | Trying to evaluate classes independently | Recognize binary Naive Bayes probabilities are normalized sum-to-1 fractions |
| Formatting confidence with `:d` | Passing a float to an integer format specifier | Format with `{confidence:.0%}` or `{confidence:.2%}` |

## Best Practices and Security Considerations

- **Log Probabilities for Auditing:** Always write probability scores alongside predictions to text logs (`outputs/predictions.txt`) for post-incident security forensics.
- **Uncertainty Flagging:** In enterprise mail servers, messages with confidence between 45% and 55% should be routed to a secondary human review queue.
- **Adversarial Resilience:** Evaluate whether inserting harmless ham words (`"meeting library"`) can artificially manipulate the confidence of a spam email.

## Summary

In addition to discrete class predictions from `model.predict()`, `model.predict_proba()` computes continuous class confidence probabilities. Testing realistic messages demonstrates how Naive Bayes accumulates token evidence to assign high confidence (88% to 100%) to both spam threats and authentic workplace communications, enabling nuanced decision thresholding in production.

## Knowledge-check Questions

1. Which method on a fitted Pipeline returns continuous class probability estimates?
2. What confidence score does `main.py` output for the free smartphone message?
3. What confidence score does `main.py` output for the note-sending message?
4. What must the sum of all class probabilities for a single sample always equal?
5. How can confidence scores be used to design a safer quarantine policy in email filtering?

## References

- scikit-learn predict_proba documentation: https://scikit-learn.org/stable/modules/generated/sklearn.naive_bayes.MultinomialNB.html#sklearn.naive_bayes.MultinomialNB.predict_proba
- Probability Calibration for Classifiers: https://scikit-learn.org/stable/modules/calibration.html
- Designing Trustworthy Human-AI Interfaces: https://pair.withgoogle.com/chapter/confidence-calibration/
