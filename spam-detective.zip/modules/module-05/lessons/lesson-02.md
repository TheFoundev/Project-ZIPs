# Lesson 02: The Confusion Matrix: Diagnosing Filter Mistakes

**Lesson ID:** lesson-02
**Module:** module-05
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Define the four quadrants of a binary confusion matrix (TN, FP, FN, TP)
- Map the classes `"ham"` and `"spam"` to matrix rows and columns
- Compute a confusion matrix using `sklearn.metrics.confusion_matrix()`
- Visualize confusion matrices using `ConfusionMatrixDisplay`
- Save the resulting diagnostic plot to `outputs/confusion_matrix.png`

## Prerequisites
- Completion of Lesson 01
- Understanding of True/False Positives and Negatives

## Concept Explanation

### What is a Confusion Matrix?
A **confusion matrix** is a structured $2 \times 2$ grid that cross-tabulates the actual ground-truth classes against the classes predicted by the model. It provides an immediate visual diagnostic showing exactly where a model succeeded and where it became "confused".

In `main.py` lines 96-97, the confusion matrix is constructed with explicit labels:
```python
labels = ["ham", "spam"]
cm = confusion_matrix(y_test, predictions, labels=labels)
```

### The Four Quadrants
When `labels = ["ham", "spam"]`:
- **Rows** represent the **True (Actual) Label**.
- **Columns** represent the **Predicted Label**.

| | Predicted HAM | Predicted SPAM |
|---|---|---|
| **Actual HAM** | **True Negative (TN)**: 10 | **False Positive (FP)**: 0 |
| **Actual SPAM** | **False Negative (FN)**: 0 | **True Positive (TP)**: 10 |

Let us define each quadrant:
1. **True Negative (TN = 10):** Legitimate ham messages that the filter correctly identified as ham and delivered to the inbox.
2. **False Positive (FP = 0):** Legitimate ham messages that the filter mistakenly flagged as spam (quarantined in junk folder). This is a Type I error. In our project, FP is **0**.
3. **False Negative (FN = 0):** Actual spam messages that the filter failed to catch, allowing them to slip into the inbox. This is a Type II error. In our project, FN is **0**.
4. **True Positive (TP = 10):** Spam messages that the filter correctly identified as spam and blocked. In our project, TP is **10**.

### Diagonal Dominance
In an ideal, perfect classifier:
- All values lie strictly along the **main diagonal** (top-left to bottom-right: TN and TP).
- All off-diagonal cells (FP and FN) are exactly **zero**.
The matrix in `main.py` is `[[10, 0], [0, 10]]`, demonstrating perfect diagonal dominance!

### Plotting with `ConfusionMatrixDisplay`
In `main.py` lines 98-103, scikit-learn's `ConfusionMatrixDisplay` renders the matrix into a clean, colored heatmap:
```python
fig, ax = plt.subplots(figsize=(5, 4))
ConfusionMatrixDisplay(cm, display_labels=labels).plot(ax=ax, cmap="Reds", colorbar=False)
ax.set_title("Spam filter mistakes")
fig.tight_layout()
fig.savefig(OUT / "confusion_matrix.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```
- `cmap="Reds"`: Uses a red gradient where deeper red indicates higher sample counts.
- `colorbar=False`: Keeps the layout clean and compact.
- `dpi=150`: Exports a sharp, high-resolution image.
- `plt.close(fig)`: Releases memory immediately after writing to disk.

## Relevant Code (from main.py, lines 95-103)

```python
    # ---- Confusion matrix ---------------------------------------------
    labels = ["ham", "spam"]
    cm = confusion_matrix(y_test, predictions, labels=labels)
    fig, ax = plt.subplots(figsize=(5, 4))
    ConfusionMatrixDisplay(cm, display_labels=labels).plot(ax=ax, cmap="Reds", colorbar=False)
    ax.set_title("Spam filter mistakes")
    fig.tight_layout()
    fig.savefig(OUT / "confusion_matrix.png", dpi=150, bbox_inches="tight")
    plt.close(fig)
```

### Code Explanation
- **Line 96:** Defines `labels = ["ham", "spam"]` to lock row and column order.
- **Line 97:** Computes the $2 \times 2$ NumPy integer array.
- **Lines 98-100:** Plots the heatmap on a matplotlib axis with a red colormap.
- **Lines 101-103:** Saves the image to `outputs/confusion_matrix.png` and closes the figure.

## Worked Example

Let us execute the confusion matrix code and print the raw array:

```python
from sklearn.metrics import confusion_matrix

labels = ["ham", "spam"]
cm = confusion_matrix(y_test, predictions, labels=labels)

print("Raw Confusion Matrix Array:")
print(cm)
print(f"\nTN: {cm[0, 0]} (Actual Ham, Pred Ham)")
print(f"FP: {cm[0, 1]} (Actual Ham, Pred Spam)")
print(f"FN: {cm[1, 0]} (Actual Spam, Pred Ham)")
print(f"TP: {cm[1, 1]} (Actual Spam, Pred Spam)")
```

**Output:**
```
Raw Confusion Matrix Array:
[[10  0]
 [ 0 10]]

TN: 10 (Actual Ham, Pred Ham)
FP: 0 (Actual Ham, Pred Spam)
FN: 0 (Actual Spam, Pred Ham)
TP: 10 (Actual Spam, Pred Spam)
```

Both off-diagonal cells are 0, confirming zero mistakes on the test set.

## Step-by-Step Student Instructions

1. **Open your Python shell** in the project directory.
2. **Generate the confusion matrix**:
   ```python
   from sklearn.metrics import confusion_matrix
   labels = ["ham", "spam"]
   cm = confusion_matrix(y_test, predictions, labels=labels)
   print(cm)
   ```
3. **Verify the file export**:
   Run `python main.py` from the shell and check `outputs/`:
   ```bash
   ls -l outputs/confusion_matrix.png
   ```
4. **Open and view `outputs/confusion_matrix.png`** in your system image viewer.

## Expected Output or Observable Behaviour

The generated image displays a $2 \times 2$ grid titled **"Spam filter mistakes"**:
- Top-left cell (`ham`, `ham`) displays `10` in dark red.
- Bottom-right cell (`spam`, `spam`) displays `10` in dark red.
- The two error cells display `0` in pure white.

## Practical Exercises

- **Exercise 2.1:** In a confusion matrix with `labels=["ham", "spam"]`, which cell index `cm[row, col]` represents False Positives?
- **Exercise 2.2:** What is the formula for Accuracy expressed in terms of TP, TN, FP, and FN?
- **Exercise 2.3:** Why is passing `labels=["ham", "spam"]` explicitly recommended instead of letting scikit-learn infer label order?
- **Exercise 2.4:** Why does `main.py` call `plt.close(fig)` after saving the plot?

## Common Mistakes and Debugging

| Mistake | Why it happens | Correction |
|---|---|---|
| Inverting rows and columns | Confusing predicted vs actual axes | Remember scikit-learn standard: rows = true labels, cols = predicted labels |
| Omitting `labels` argument | Label order depends on first appearance | Always provide explicit `labels=['ham', 'spam']` |
| Forgetting `plt.close(fig)` | Memory leak in GUI or batch pipelines | Call `plt.close(fig)` immediately after `fig.savefig()` |
| FileNotFoundError on save | outputs/ directory does not exist | Ensure `OUT.mkdir(exist_ok=True)` was called |

## Best Practices and Security Considerations

- **Explicit Label Ordering:** Always supply `labels=...` to guarantee that matrix rows and columns maintain deterministic order across software versions.
- **High-DPI Artifacts:** Set `dpi=150` or `dpi=300` when saving figures for reports and presentations.
- **Bounding Boxes:** Use `bbox_inches="tight"` to ensure axes labels and titles are not clipped at the image edges.

## Summary

A confusion matrix provides a comprehensive breakdown of model predictions versus ground truth. In binary spam filtering, it cross-tabulates True Negatives (ham delivered), False Positives (ham quarantined), False Negatives (spam leaked), and True Positives (spam blocked). In `main.py`, `ConfusionMatrixDisplay` renders the matrix with `cmap="Reds"` and exports it to `outputs/confusion_matrix.png`.

## Knowledge-check Questions

1. What are the four quadrants of a binary confusion matrix?
2. What are the exact values of TN, FP, FN, and TP in the Spam Detective test evaluation?
3. Which quadrant represents the most damaging error in consumer email filtering?
4. In scikit-learn's confusion matrix, do rows represent the true labels or the predicted labels?
5. What matplotlib function frees the memory allocated to a figure after saving?

## References

- scikit-learn ConfusionMatrixDisplay: https://scikit-learn.org/stable/modules/generated/sklearn.metrics.ConfusionMatrixDisplay.html
- scikit-learn confusion_matrix: https://scikit-learn.org/stable/modules/generated/sklearn.metrics.confusion_matrix.html
- Understanding the Confusion Matrix: https://towardsdatascience.com/understanding-confusion-matrix-a9ad42dcfd62
