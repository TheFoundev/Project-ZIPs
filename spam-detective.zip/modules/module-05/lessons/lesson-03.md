# Lesson 03: Visualizing Clue Words: Dual Horizontal Bar Charts

**Lesson ID:** lesson-03
**Module:** module-05
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain why horizontal bar charts (`barh`) are the preferred visual format for text labels
- Configure a multi-panel subplot layout with `plt.subplots(1, 2)`
- Apply semantic color styling (red for spam clues, blue for legitimate ham clues)
- Implement array reversing (`[::-1]`) to position top-ranked clues at the summit of the chart
- Interpret the relative clue strength displayed in `outputs/top_words.png`

## Prerequisites
- Completion of Module 04, Lesson 04 (`top_words()` function)
- Basic familiarity with matplotlib plotting

## Concept Explanation

### Why Horizontal Bar Charts for Words?
In standard vertical bar charts (`ax.bar()`), labels sit along the bottom x-axis. When labels are words or multi-word phrases (like `"price guaranteed"` or `"minutes late"`), horizontal text strings collide with each other, forcing awkward 45-degree rotation that is difficult to read.

A **horizontal bar chart (`ax.barh()`)** places categories along the vertical y-axis:
- Long word phrases read naturally from left to right.
- Category names never overlap.
- Relative magnitude is clearly conveyed by the horizontal length of the bars.

### Multi-Panel Subplots: Side-by-Side Comparison
In `main.py` lines 82-93, we construct a side-by-side comparison figure:
```python
fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
```
- `1, 2`: Creates 1 row with 2 distinct subplot axes (`axes[0]` on the left, `axes[1]` on the right).
- `figsize=(11, 4.5)`: Allocates an 11-inch wide by 4.5-inch tall canvas, providing ample room for 10 horizontal bars per side.

### Semantic Color Coding
Color choice in data visualization should convey meaning immediately:
- **Left Panel (Spam Clues):** Plotted in alert crimson red (`#c0392b`), instantly signaling caution, danger, or unwanted spam.
- **Right Panel (Ham Clues):** Plotted in trusted steel blue (`#2471a3`), signaling reliability, legitimacy, and calm communication.

### Reversing Slices with `words[::-1]`
In matplotlib's `barh()`, the first item passed to the function is drawn at the **bottom** ($y=0$), and subsequent items are stacked upward.

The `top_words()` function returns clues in descending order (Rank #1 first: `"buy"`). If we plotted this directly, `"buy"` would appear at the very bottom!
To place the #1 clue prominently at the **top** of the chart:
- We pass `words[::-1]` (reversing the list so Rank #1 is plotted last, at the top).
- We pass `range(1, len(words) + 1)` for the bar lengths.

### Layout Polish and Export
To ensure publication-ready visual polish:
- `ax.set_xlabel("relative clue strength")`: Clear axis labeling.
- `ax.grid(axis="x", alpha=0.25)`: Subtle vertical gridlines for easy visual comparison.
- `fig.tight_layout()`: Automatically adjusts padding between subplots to prevent overlapping titles.
- `fig.savefig(OUT / "top_words.png", dpi=150, bbox_inches="tight")`: Writes a crisp 150-DPI PNG.

## Relevant Code (from main.py, lines 82-93)

```python
    # ---- Top-word chart ------------------------------------------------
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
    for ax, words, title, colour in (
        (axes[0], spam_words, "Words that suggest spam", "#c0392b"),
        (axes[1], ham_words, "Words that suggest a normal message", "#2471a3"),
    ):
        ax.barh(words[::-1], range(1, len(words) + 1), color=colour)
        ax.set_title(title)
        ax.set_xlabel("relative clue strength")
        ax.grid(axis="x", alpha=0.25)
    fig.tight_layout()
    fig.savefig(OUT / "top_words.png", dpi=150, bbox_inches="tight")
    plt.close(fig)
```

### Code Explanation
- **Line 82:** Creates the 1x2 subplot canvas.
- **Lines 83-86:** Iterates cleanly over a tuple of configurations for the spam axis and ham axis.
- **Line 87:** Plots horizontal bars with reversed word order and designated hex colors.
- **Lines 88-90:** Applies titles, axis labels, and subtle gridlines.
- **Lines 91-93:** Adjusts spacing, saves the image, and releases memory.

## Worked Example

Let us run the visualization code and inspect the structure of the generated plot:

```python
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# Using the top words extracted from main.py
spam_words = ['buy', 'price', '50 buy', 'price guaranteed', '50', 'order', 'lowest', 'guaranteed', 'lowest price', 'risk']
ham_words = ['meeting', 'today class', 'send notes', 'start', 'll', 'tomorrow', 'll minutes', 'minutes late', 'minutes', 'meeting lunch']

fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
for ax, words, title, colour in (
    (axes[0], spam_words, "Words that suggest spam", "#c0392b"),
    (axes[1], ham_words, "Words that suggest a normal message", "#2471a3"),
):
    ax.barh(words[::-1], range(1, len(words) + 1), color=colour)
    ax.set_title(title)
    ax.set_xlabel("relative clue strength")
    ax.grid(axis="x", alpha=0.25)

fig.tight_layout()
fig.savefig("test_top_words.png", dpi=150, bbox_inches="tight")
plt.close(fig)
print("Saved test_top_words.png successfully!")
```

**Output:**
```
Saved test_top_words.png successfully!
```

In the resulting image, `'buy'` sits at the top of the red left panel, and `'meeting'` sits at the top of the blue right panel.

## Step-by-Step Student Instructions

1. **Run `python main.py`** in your terminal.
2. **Inspect the `outputs/` folder**:
   ```bash
   ls -la outputs/top_words.png
   ```
3. **Open `top_words.png`** in your image viewer.
4. **Examine the left panel (red)**:
   - Identify the single words (`buy`, `price`, `50`, `order`, `lowest`, `guaranteed`, `risk`).
   - Identify the bigrams (`50 buy`, `price guaranteed`, `lowest price`).
5. **Examine the right panel (blue)**:
   - Identify the single words (`meeting`, `start`, `ll`, `tomorrow`, `minutes`).
   - Identify the bigrams (`today class`, `send notes`, `ll minutes`, `minutes late`, `meeting lunch`).

## Expected Output or Observable Behaviour

The output PNG presents a clean dual-panel visualization:
- Left panel titled **"Words that suggest spam"** in red bars.
- Right panel titled **"Words that suggest a normal message"** in blue bars.
- Labels along the y-axis are completely legible without truncation or collision.

## Practical Exercises

- **Exercise 3.1:** Why does `ax.barh()` display the first list element at the bottom of the axis unless reversed?
- **Exercise 3.2:** What hex color codes are used for the spam and ham bars in `main.py`?
- **Exercise 3.3:** What does `fig.tight_layout()` do when creating multi-panel figures?
- **Exercise 3.4:** If you wanted to display the top 15 words instead of 10, what parameter in `top_words()` would you change?

## Common Mistakes and Debugging

| Mistake | Why it happens | Correction |
|---|---|---|
| Words plotted upside down | Forgetting `words[::-1]` | Reverse list with `[::-1]` so highest clue is at top |
| Text cut off at edges | Omitting `bbox_inches='tight'` | Always pass `bbox_inches='tight'` to `savefig()` |
| Subplots overlapping | Omitting `fig.tight_layout()` | Call `fig.tight_layout()` before `savefig()` |
| GUI popup errors on remote servers | Importing pyplot before setting Agg backend | Put `matplotlib.use('Agg')` before `import matplotlib.pyplot as plt` |

## Best Practices and Security Considerations

- **Headless Agg Backend:** Always set `matplotlib.use("Agg")` at the very top of automated scripts to ensure execution works seamlessly in terminal environments, headless containers, and CI/CD pipelines.
- **Accessibility:** Use high-contrast color palettes (like the chosen red `#c0392b` and blue `#2471a3`) to ensure readability for colorblind users.
- **Resource Management:** Always invoke `plt.close(fig)` to avoid accumulative memory overhead.

## Summary

In `main.py`, top discriminative clues are visualized using dual horizontal bar charts created with `plt.subplots(1, 2)`. Horizontal bars preserve the readability of multi-word bigram phrases, while semantic colors (red for spam, blue for ham) and slice reversal (`words[::-1]`) place the most influential keywords at the top of each panel.

## Knowledge-check Questions

1. Why are horizontal bar charts (`barh`) better suited for text phrases than vertical bar charts?
2. What hex colors are used in `main.py` for spam and ham bars respectively?
3. Why is `words[::-1]` used in the `ax.barh()` call?
4. What output file does `main.py` generate to store the top-word chart?
5. What does the `alpha=0.25` argument control in `ax.grid()`?

## References

- Matplotlib barh Documentation: https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.barh.html
- Matplotlib Subplots Guide: https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.subplots.html
- Color Use in Information Visualization: https://matplotlib.org/stable/users/explain/colors/colormaps.html
