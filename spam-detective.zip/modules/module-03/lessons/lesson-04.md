# Lesson 04: Vocabulary Size, Sparse Matrices, and Feature Inspection

**Lesson ID:** lesson-04
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Inspect the complete 288-feature vocabulary learned on the project's training data
- Understand the mathematical and computational definition of matrix sparsity
- Explain why text matrices are stored as Compressed Sparse Row (`csr_matrix`) structures
- Measure the sparsity percentage of the training term-document matrix (~95.7%)
- Explain how `CountVectorizer` handles Out-Of-Vocabulary (OOV) terms during test inference

## Prerequisites
- Completion of Lessons 01, 02, and 03
- Basic understanding of 2D arrays, matrices, and memory storage

## Concept Explanation

### The Training Vocabulary of Spam Detective
When `main.py` fits `CountVectorizer(stop_words="english", ngram_range=(1, 2))` on the 60 training messages:
```python
vectorizer = model.named_steps["vectorizer"]
names = vectorizer.get_feature_names_out()
print("Vocabulary size:", len(names))
```
The vectorizer discovers exactly **288 unique features** across the 60 training documents.
These 288 features include:
- Numeric tokens: `'00'`, `'100'`, `'11'`, `'15'`, `'204'`, `'250'`, `'50'`
- Unigram words: `'act'`, `'attached'`, `'budget'`, `'buy'`, `'cash'`, `'free'`, `'meeting'`, `'prize'`
- Bigram phrases: `'11 00'`, `'50 buy'`, `'lowest price'`, `'minutes late'`, `'price guaranteed'`

### The Sparsity Phenomenon in NLP
Consider the transformed training matrix:
- Number of rows (samples): **60**
- Number of columns (features): **288**
- Total matrix cells: $60 \times 288 = \mathbf{17,280\text{ cells}}$

How many words does an average text message contain? Only about 8 to 12 words!
Even with bigrams, an average message activates only about **10 to 15 features** out of the 288 columns.
All the remaining ~275 columns in that row are **zeros**!

Let us calculate the non-zero entries:
- In our project, out of 17,280 cells, only **735 cells** contain a non-zero count.
- **Sparsity ratio:**
  $$\text{Sparsity} = 1.0 - \frac{735}{17,280} = 1.0 - 0.0425 = \mathbf{95.75\%}$$
Over 95% of the matrix consists entirely of zeros!

### Why Scipy Sparse Matrices (`csr_matrix`) Are Essential
If we stored every zero as a standard 64-bit floating point number in a regular NumPy dense array, a real-world dataset with 100,000 emails and 50,000 vocabulary words would require:
$$100,000 \times 50,000 \times 8\text{ bytes} = 40,000,000,000\text{ bytes} = \mathbf{40\text{ GB of RAM!}}$$

To prevent this catastrophic waste, scikit-learn stores text matrices using SciPy's **Compressed Sparse Row (`csr_matrix`)** format:
- Instead of storing millions of zeros, a sparse matrix stores only the **row index, column index, and non-zero value** (e.g. `"Row 4, Column 18: count 2"`).
- In our project, `X_train_vec` is stored as a `scipy.sparse._csr.csr_matrix`, taking less than 10 kilobytes of memory.

### Out-Of-Vocabulary (OOV) Terms
What happens when the trained model encounters a new word during testing or deployment?
For example, suppose a user tests:
`"Congratulations! You won a brand new quantum holographic television."`
The words `"quantum"`, `"holographic"`, and `"television"` were never in `messages.csv`, so they do not exist in the 288 learned vocabulary columns.

`CountVectorizer` handles Out-Of-Vocabulary (OOV) terms gracefully:
- It simply ignores unknown tokens!
- Only tokens that match the 288 known vocabulary columns are mapped to the count vector.
- The model will still detect `"congratulations"` and `"won"`, correctly classifying the message as spam despite the unknown words.

## Relevant Code (from main.py, lines 30-35 and 44-50)

```python
def top_words(model: Pipeline, class_index: int, n: int = 10) -> list[str]:
    vectorizer = model.named_steps["vectorizer"]
    classifier = model.named_steps["classifier"]
    names = vectorizer.get_feature_names_out()
    scores = classifier.feature_log_prob_[class_index] - classifier.feature_log_prob_[1 - class_index]
    return list(names[np.argsort(scores)[-n:][::-1]])
```

### Code Explanation
- **Line 31:** Retrieves the fitted `CountVectorizer` step from the pipeline.
- **Line 33:** `names = vectorizer.get_feature_names_out()` extracts the 288 learned feature names in alphabetical order, perfectly aligning with the columns of `classifier.feature_log_prob_`.

## Worked Example

Let us write a small script to verify the vocabulary size, matrix shape, and sparsity of our project's training data:

```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer

df = pd.read_csv("data/messages.csv")
X_train, X_test, y_train, y_test = train_test_split(
    df["text"], df["label"], test_size=0.25, random_state=42, stratify=df["label"]
)

vec = CountVectorizer(stop_words="english", ngram_range=(1, 2))
X_train_vec = vec.fit_transform(X_train)

vocab = vec.get_feature_names_out()
num_features = len(vocab)
total_cells = X_train_vec.shape[0] * X_train_vec.shape[1]
non_zero_cells = X_train_vec.nnz
sparsity = (1.0 - (non_zero_cells / total_cells)) * 100

print(f"Training samples:   {X_train_vec.shape[0]}")
print(f"Vocabulary size:    {num_features} features")
print(f"Matrix shape:       {X_train_vec.shape}")
print(f"Non-zero elements:  {non_zero_cells} / {total_cells}")
print(f"Matrix Sparsity:    {sparsity:.2f}%")
print(f"Data type:          {type(X_train_vec).__name__}")
```

**Output:**
```
Training samples:   60
Vocabulary size:    288 features
Matrix shape:       (60, 288)
Non-zero elements:  735 / 17280
Matrix Sparsity:    95.75%
Data type:          csr_matrix
```

## Step-by-Step Student Instructions

1. **Open your Python shell** in the project directory.
2. **Replicate the code above** to inspect the sparse matrix.
3. **Inspect a slice of the vocabulary**:
   ```python
   print("First 10 features:", vocab[:10].tolist())
   print("Last 10 features: ", vocab[-10:].tolist())
   ```
4. **Examine row 0 as a dense vector**:
   ```python
   row_0 = X_train_vec[0].toarray()
   print("Row 0 shape:", row_0.shape)
   print("Non-zero entries in row 0:", (row_0 > 0).sum())
   ```
   Notice that in row 0, only a handful of entries out of 288 are non-zero.

## Expected Output or Observable Behaviour

The terminal confirms:
- Exact vocabulary size: 288
- Matrix type: `scipy.sparse._csr.csr_matrix`
- Over 95.7% of entries are zero.

## Practical Exercises

- **Exercise 4.1:** What is the exact vocabulary size produced by `CountVectorizer(stop_words="english", ngram_range=(1, 2))` on `X_train` with `random_state=42`?
- **Exercise 4.2:** What does the `.nnz` attribute of a scipy sparse matrix represent?
- **Exercise 4.3:** If a message during test evaluation contains 5 brand new words never seen during training, what happens to those 5 words?
- **Exercise 4.4:** Calculate the memory saving: compare storing a $100,000 \times 50,000$ float64 dense matrix (8 bytes per entry) versus storing only the 1% non-zero entries in CSR format.

## Common Mistakes and Debugging

| Mistake | Why it happens | Correction |
|---|---|---|
| Calling `.toarray()` on massive corpora | Running out of RAM | Keep text matrices in scipy CSR sparse format |
| Expecting test words to expand the vocabulary | Assuming `transform()` adds new words | Remember test vocabulary is strictly fixed to the training vocabulary |
| Accessing `get_feature_names_out()` before `fit()` | Calling methods on an unfitted vectorizer | Always call `fit()` or `fit_transform()` first |
| Forgetting pipeline handles vectorization | Trying to manually pass sparse matrices to pipeline | Scikit-learn Pipelines automatically pass the sparse output to the classifier |

## Best Practices and Security Considerations

- **Vocabulary Freezing:** In production APIs, never allow incoming customer queries to alter the model's vocabulary. The vocabulary must remain frozen after training.
- **Handling Adversarial Padding:** Spammers sometimes stuff thousands of random dictionary words at the end of an email to dilute spam word percentages. Robust filters truncate or penalize excessive document length.
- **Memory Profiling:** Always monitor memory footprint when scaling up `ngram_range` or vocabulary limits (`max_features`).

## Summary

When fitted on `X_train`, `CountVectorizer` produces an alphabetically indexed vocabulary of exactly 288 unigram and bigram features. The resulting $60 \times 288$ term-document matrix is over 95.7% sparse. Storing this representation as a SciPy Compressed Sparse Row (`csr_matrix`) structure conserves memory, while Out-Of-Vocabulary handling ensures robust inference on new messages containing unfamiliar words.

## Knowledge-check Questions

1. How many total features are in the vocabulary learned on `X_train` in `main.py`?
2. What does it mean for a matrix to be "sparse"?
3. What is the approximate sparsity percentage of the training term-document matrix in our project?
4. Which SciPy sparse matrix format does `CountVectorizer.fit_transform()` return?
5. How does `CountVectorizer` handle words in test messages that were never seen during training?

## References

- SciPy Sparse Matrices (CSR format): https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.csr_matrix.html
- scikit-learn Feature Extraction Guide: https://scikit-learn.org/stable/modules/feature_extraction.html
- Handling Out-of-Vocabulary Tokens in NLP: https://web.stanford.edu/~jurafsky/slp3/
