# Lesson 02: Filtering Noise with English Stop Words

**Lesson ID:** lesson-02
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Define what stop words are in computational linguistics and NLP
- Explain why common words like "the", "and", "is", "at", and "to" provide little discriminative power for classification
- Understand the implementation and effect of `stop_words="english"` in `CountVectorizer`
- Measure how stop word filtering reduces vocabulary dimensionality and eliminates background noise
- Identify situations where stop word removal is beneficial versus when it may cause information loss

## Prerequisites
- Completion of Lesson 01
- Understanding of the term-frequency count matrix

## Concept Explanation

### What Are Stop Words?
In any natural human language, a small handful of structural, grammatical words account for a massive percentage of all spoken and written words. In English, words such as:
`"the"`, `"is"`, `"at"`, `"which"`, `"on"`, `"and"`, `"a"`, `"an"`, `"in"`, `"to"`, `"of"`, `"for"`
are known as **stop words**.

These words are essential for grammatical syntax, but in the context of topic classification and spam filtering, they carry virtually **zero discriminative information**.

### The Problem of Stop Words in Spam Detection
Consider the following two messages:
- Spam: `"Claim the prize at the counter for an instant reward."`
- Ham: `"Meet the team at the library for an urgent review."`

Notice how both messages contain the words `"the"`, `"at"`, `"for"`, and `"an"`.
If our vectorizer counts every word indiscriminately:
1. Stop words will appear with the highest frequencies in both spam and ham documents.
2. In a Naive Bayes model, the conditional probabilities $P(\text{"the"} \mid \text{spam})$ and $P(\text{"the"} \mid \text{ham})$ will be nearly identical (e.g. 95% in both).
3. These ubiquitous words bloat the vocabulary matrix with useless columns and dilute the statistical impact of truly informative words like `"prize"`, `"reward"`, `"library"`, and `"review"`.

### The `stop_words="english"` Parameter
In `main.py` line 46, we pass:
```python
CountVectorizer(stop_words="english", ngram_range=(1, 2))
```
Scikit-learn comes preloaded with a built-in English stop-word dictionary containing **318 common English words**.

When `stop_words="english"` is enabled:
- Any token matching a word in the stop-word list is automatically discarded during tokenization.
- It is never added to the vocabulary.
- It does not receive a column in the feature matrix.

### Benefits of Stop Word Removal
1. **Dimensionality Reduction:** Cuts out hundreds of useless vocabulary columns, reducing memory usage and speeding up training.
2. **Noise Reduction:** Prevents the classifier from accidentally assigning statistical importance to subtle, coincidental frequency variations in common words.
3. **Sharper Focus:** Forces the model to evaluate the substantive nouns, verbs, and adjectives that define the intent of the message.

## Relevant Code (from main.py, line 46)

```python
    model = Pipeline(
        [
            ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
            ("classifier", MultinomialNB()),
        ]
    )
```

### Code Explanation
- Setting `stop_words="english"` instructs `CountVectorizer` to filter out common English function words before compiling the vocabulary and generating count features.

## Worked Example

Let us measure the exact impact of stop word filtering on a sample message:

```python
from sklearn.feature_extraction.text import CountVectorizer

message = ["Congratulations! You have won a free vacation to the beach."]

# Without stop words
vec_raw = CountVectorizer()
vec_raw.fit(message)
features_raw = vec_raw.get_feature_names_out()

# With stop words
vec_clean = CountVectorizer(stop_words="english")
vec_clean.fit(message)
features_clean = vec_clean.get_feature_names_out()

print("Features WITHOUT stop word removal (count = {0}):".format(len(features_raw)))
print(list(features_raw))

print("\nFeatures WITH stop word removal (count = {0}):".format(len(features_clean)))
print(list(features_clean))
```

**Output:**
```
Features WITHOUT stop word removal (count = 9):
['beach', 'congratulations', 'free', 'have', 'the', 'to', 'vacation', 'won', 'you']

Features WITH stop word removal (count = 5):
['beach', 'congratulations', 'free', 'vacation', 'won']
```

Notice:
- The words `'have'`, `'the'`, `'to'`, and `'you'` were automatically filtered out as noise.
- Only the 5 high-impact content words were preserved!

## Step-by-Step Student Instructions

1. **Launch a Python session** in your terminal.
2. **Inspect scikit-learn's built-in stop words list**:
   ```python
   from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS
   print("Total built-in stop words:", len(ENGLISH_STOP_WORDS))
   print("Sample stop words:", sorted(list(ENGLISH_STOP_WORDS))[:15])
   ```
3. **Notice words like**: `'about'`, `'above'`, `'across'`, `'after'`, `'again'`, `'all'`, `'almost'`.
4. **Test a sentence with and without the parameter**: Observe how `stop_words="english"` isolates informative content terms.

## Expected Output or Observable Behaviour

The terminal reveals scikit-learn's internal stop words catalogue:
```
Total built-in stop words: 318
Sample stop words: ['a', 'about', 'above', 'across', 'after', 'afterwards', 'again', 'against', 'all', 'almost', 'alone', 'along', 'already', 'also', 'although']
```
Every one of these 318 words is screened out when `stop_words="english"` is configured.

## Practical Exercises

- **Exercise 2.1:** How many total words are in scikit-learn's `ENGLISH_STOP_WORDS` set?
- **Exercise 2.2:** Is the word `"free"` in `ENGLISH_STOP_WORDS`? Why would it be a disaster for spam detection if `"free"` were classified as a stop word?
- **Exercise 2.3:** What happens to the sentence `"To be or not to be"` if processed with `stop_words="english"`?
- **Exercise 2.4:** In sentiment analysis (e.g. reviewing movie reviews), why might removing the stop word `"not"` cause problems?

## Common Mistakes and Debugging

| Mistake | Why it happens | Correction |
|---|---|---|
| Assuming all short words are stop words | Confusing token length with grammatical function | Note that words like `"win"` or `"tax"` are content words, not stop words |
| Removing stop words in sentiment analysis | Forgetting negation words like `"not"` alter meaning | In sentiment tasks, use custom stop word lists that retain negations |
| Passing a language string not supported | Typing `stop_words="spanish"` without custom lists | Note scikit-learn only provides built-in strings for `"english"` |
| Expecting numbers to be stop words | Assuming digits are filtered by stop words | Numbers like `"50"` or `"100"` are retained unless regex is customized |

## Best Practices and Security Considerations

- **Domain-Specific Stop Words:** In specialized domains (e.g. corporate legal emails), common terms like `"company"`, `"confidential"`, or `"regards"` can be appended to custom stop word lists.
- **Multilingual Support:** Scikit-learn's built-in string only supports English. For multilingual spam detection, use libraries like NLTK or spaCy to supply language-specific stop word sets.
- **Verification:** Always verify that high-value domain keywords (like `"free"`, `"cash"`, `"urgent"`) are NOT present in your stop word list.

## Summary

Stop words are frequent structural words (such as `"the"`, `"and"`, `"is"`, `"to"`) that convey grammatical relationships but lack topical discrimination. In `main.py`, setting `stop_words="english"` filters out 318 standard English noise words, shrinking vocabulary dimensionality and allowing the classifier to focus squarely on discriminative keywords.

## Knowledge-check Questions

1. What are stop words in natural language processing?
2. How many built-in stop words are included in scikit-learn's `ENGLISH_STOP_WORDS` collection?
3. Why does removing stop words benefit a Naive Bayes spam detector?
4. Name three words that would be filtered out by `stop_words="english"`.
5. Name two high-value spam words that must NEVER be treated as stop words.

## References

- scikit-learn ENGLISH_STOP_WORDS: https://scikit-learn.org/stable/modules/generated/sklearn.feature_extraction.text.CountVectorizer.html
- NLTK Stopwords Documentation: https://www.nltk.org/book/ch02.html
- Stop Words in Information Retrieval: https://nlp.stanford.edu/IR-book/html/htmledition/dropping-common-terms-stop-words-1.html
