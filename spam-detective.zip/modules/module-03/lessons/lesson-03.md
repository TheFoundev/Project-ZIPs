# Lesson 03: Capturing Phrases with N-Grams

**Lesson ID:** lesson-03
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Define unigrams, bigrams, and n-grams in natural language processing
- Explain why single isolated words (unigrams) often miss contextual meaning
- Understand the `ngram_range` parameter in `CountVectorizer`
- Trace how `ngram_range=(1, 2)` extracts both unigrams and bigrams simultaneously
- Demonstrate how bigrams like "lowest price" or "minutes late" provide distinct clues for spam vs ham

## Prerequisites
- Completion of Lessons 01 and 02
- Understanding of tokenization and vocabulary matrices

## Concept Explanation

### The Limitation of Unigrams (Single Words)
So far, we have looked at text one word at a time. A single token is called a **unigram** ($n=1$).

While unigrams are effective, single words often carry ambiguous meaning in isolation:
- The word `"price"` could appear in a financial market report, a grocery discussion, or a spam flyer.
- The word `"guaranteed"` could appear in an engineering warranty or a spam pitch.
- The word `"late"` could mean a delayed flight, a student arriving late to class, or a late bill notice.

When words are viewed strictly as isolated unigrams, we lose the critical **phrase context** created by words sitting next to each other.

### What is an N-Gram?
An **n-gram** is a contiguous sequence of $n$ items (words) from a given sample of text:
- **Unigram ($n=1$):** Single words (`"lowest"`, `"price"`, `"free"`, `"shipping"`).
- **Bigram ($n=2$):** Two-word pairs (`"lowest price"`, `"free shipping"`, `"price guaranteed"`, `"minutes late"`).
- **Trigram ($n=3$):** Three-word sequences (`"lowest price guaranteed"`, `"free gift card"`).

### The Power of Bigrams in Spam Detection
When words pair together, their discriminative power multiplies dramatically:
- `"lowest"` (could be a temperature reading or test score) + `"price"` (could be a general discussion) $\longrightarrow$ **`"lowest price"`**: Virtually 100% indicative of commercial spam!
- `"price"` + `"guaranteed"` $\longrightarrow$ **`"price guaranteed"`**: Classic high-confidence spam clue!
- `"minutes"` + `"late"` $\longrightarrow$ **`"minutes late"`**: Classic interpersonal ham message clue!
- `"meeting"` + `"lunch"` $\longrightarrow$ **`"meeting lunch"`**: Normal human communication clue!

### The `ngram_range=(1, 2)` Parameter
In `main.py` line 46, the vectorizer is configured with:
```python
CountVectorizer(stop_words="english", ngram_range=(1, 2))
```
The tuple `(min_n, max_n)` tells the vectorizer:
- `min_n = 1`: Include all single words (unigrams).
- `max_n = 2`: Include all adjacent word pairs (bigrams).

When a message like `"Lowest price guaranteed!"` is processed:
1. Stop words are checked (none in this short phrase).
2. Unigrams generated: `["lowest", "price", "guaranteed"]`.
3. Bigrams generated: `["lowest price", "price guaranteed"]`.
4. Total features from this sentence: **5 features** (`"lowest"`, `"price"`, `"guaranteed"`, `"lowest price"`, `"price guaranteed"`).

This gives the model the best of both worlds: broad coverage from single words, plus laser-focused precision from specific two-word phrases!

## Relevant Code (from main.py, lines 30-35, 46, and 62-65)

```python
    model = Pipeline(
        [
            ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
            ("classifier", MultinomialNB()),
        ]
    )

    # ...
    spam_words = top_words(model, spam_index)
    ham_words = top_words(model, 1 - spam_index)
    print("Top spam clues:", ", ".join(spam_words))
    print("Top normal clues:", ", ".join(ham_words))
```

### Code Explanation
- **Line 46:** `ngram_range=(1, 2)` instructs `CountVectorizer` to generate both unigrams and bigrams.
- **Lines 64-65:** When the project prints top clues, notice that bigrams appear directly alongside unigrams:
  - Spam clues include: `'50 buy'`, `'price guaranteed'`, `'lowest price'`.
  - Normal (ham) clues include: `'today class'`, `'send notes'`, `'ll minutes'`, `'minutes late'`, `'meeting lunch'`.

## Worked Example

Let us see how `ngram_range=(1, 2)` extracts unigrams and bigrams from a sample message:

```python
from sklearn.feature_extraction.text import CountVectorizer

text = ["Lowest price guaranteed buy now"]

vec = CountVectorizer(ngram_range=(1, 2))
vec.fit(text)

features = vec.get_feature_names_out()
print("All features extracted (unigrams + bigrams):")
for f in features:
    is_bigram = " " in f
    print(f"  {f:25s} -> {'Bigram (n=2)' if is_bigram else 'Unigram (n=1)'}")
```

**Output:**
```
All features extracted (unigrams + bigrams):
  buy                       -> Unigram (n=1)
  buy now                   -> Bigram (n=2)
  guaranteed                -> Unigram (n=1)
  guaranteed buy            -> Bigram (n=2)
  lowest                    -> Unigram (n=1)
  lowest price              -> Bigram (n=2)
  now                       -> Unigram (n=1)
  price                     -> Unigram (n=1)
  price guaranteed          -> Bigram (n=2)
```

The vectorizer extracted 4 unigrams and 4 bigrams, giving the model 8 rich features from just 4 words.

## Step-by-Step Student Instructions

1. **Launch Python** in your terminal.
2. **Experiment with different n-gram ranges**:
   ```python
   from sklearn.feature_extraction.text import CountVectorizer
   phrase = ["free vacation cash reward"]
   
   v1 = CountVectorizer(ngram_range=(1, 1))
   v2 = CountVectorizer(ngram_range=(2, 2))
   v3 = CountVectorizer(ngram_range=(1, 2))
   
   print("Unigrams only:", v1.fit(phrase).get_feature_names_out().tolist())
   print("Bigrams only: ", v2.fit(phrase).get_feature_names_out().tolist())
   print("Both (1, 2):  ", v3.fit(phrase).get_feature_names_out().tolist())
   ```
3. **Inspect the features learned in `main.py`**:
   Load `X_train` and fit `CountVectorizer(stop_words='english', ngram_range=(1, 2))`.
   Print the bigrams:
   ```python
   [f for f in vec.get_feature_names_out() if " " in f][:10]
   ```

## Expected Output or Observable Behaviour

The terminal confirms:
```
Unigrams only: ['cash', 'free', 'reward', 'vacation']
Bigrams only:  ['cash reward', 'free vacation', 'vacation cash']
Both (1, 2):   ['cash', 'cash reward', 'free', 'free vacation', 'reward', 'vacation', 'vacation cash']
```
Using `ngram_range=(1, 2)` combines both lists seamlessly.

## Practical Exercises

- **Exercise 3.1:** For a sentence with $K$ valid words, how many unigrams and how many bigrams are produced?
- **Exercise 3.2:** What bigrams are produced from `"urgent verify password"` with `ngram_range=(2, 2)`?
- **Exercise 3.3:** Why would setting `ngram_range=(1, 10)` be problematic for a large dataset? (Think about vocabulary explosion).
- **Exercise 3.4:** Look at the top clues output from `main.py`. Identify two bigrams listed under "Top spam clues" and two bigrams listed under "Top normal clues".

## Common Mistakes and Debugging

| Mistake | Why it happens | Correction |
|---|---|---|
| Setting `ngram_range=(2, 1)` | Inverting min and max bounds | Always pass `(min_n, max_n)` with `min_n <= max_n` |
| Using overly large n-gram ranges (e.g. `(1, 5)`) | Causing massive vocabulary explosion | Stick to `(1, 2)` or `(1, 3)` for standard text classification |
| Expecting stop words inside bigrams | Forgetting `stop_words='english'` removes stop words first | Words like `"the"` are removed before bigrams are formed |
| Thinking bigrams require custom regex | Writing manual string split loops | Let `CountVectorizer(ngram_range=(1, 2))` handle it automatically |

## Best Practices and Security Considerations

- **Vocabulary Pruning:** If a dataset is large, adding bigrams can increase vocabulary from 10,000 to 100,000+ words. Use parameters like `min_df=2` (ignore terms appearing in fewer than 2 documents) to keep vocabulary manageable.
- **Handling Negation:** Bigrams like `"not spam"` or `"no fee"` naturally capture negation that unigrams completely miss.
- **Computational Cost:** Bigram generation increases memory usage. Always monitor vocabulary size (`len(vec.get_feature_names_out())`).

## Summary

Unigrams capture isolated word frequencies, but lose the context of multi-word expressions. N-grams capture sequences of $n$ adjacent words. By setting `ngram_range=(1, 2)` in `CountVectorizer`, the Spam Detective project extracts both individual words and two-word bigrams (such as `"lowest price"`, `"price guaranteed"`, and `"minutes late"`), providing discriminative phrase clues that significantly boost classification accuracy.

## Knowledge-check Questions

1. What is the difference between a unigram and a bigram?
2. What does `ngram_range=(1, 2)` specify in `CountVectorizer`?
3. Name two bigrams that appear in the top clues printed by `main.py`.
4. If a sentence has 5 words, how many bigrams will be generated?
5. Why are bigrams like `"lowest price"` more discriminative for spam filtering than the isolated word `"price"`?

## References

- scikit-learn CountVectorizer - ngram_range: https://scikit-learn.org/stable/modules/generated/sklearn.feature_extraction.text.CountVectorizer.html
- N-gram Language Models - Jurafsky & Martin: https://web.stanford.edu/~jurafsky/slp3/3.pdf
- Text Mining with N-Grams: https://en.wikipedia.org/wiki/N-gram
