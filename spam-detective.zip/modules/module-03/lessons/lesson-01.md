# Lesson 01: Tokenization and the Vocabulary Index Mapping

**Lesson ID:** lesson-01
**Module:** module-03
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain the internal tokenization process executed by scikit-learn's `CountVectorizer`
- Understand default token filtering rules (lowercasing, punctuation removal, word boundary matching)
- Trace how a corpus of text strings is converted into a sorted vocabulary index dictionary
- Access the learned vocabulary using `.vocabulary_` and `.get_feature_names_out()`
- Describe how documents are mapped to numerical rows in a count matrix

## Prerequisites
- Completion of Module 01 and Module 02
- Familiarity with Python strings and basic regular expressions

## Concept Explanation

### What is Tokenization?
Before a computer can count words, it must divide a continuous stream of characters into discrete linguistic units called **tokens**. In English, tokens roughly correspond to individual words.

However, raw text is messy:
`"Congratulations! You won a free smartphone. Click now to claim your prize."`

If we simply split by spaces using Python's `text.split()`, the resulting tokens include punctuation attached to words: `'Congratulations!'`, `'smartphone.'`, and `'prize.'`. This would cause `'smartphone.'` (with a period) and `'smartphone'` (without a period) to be treated as two completely distinct, unrelated words!

### How `CountVectorizer` Solves This
In `main.py` (line 46), scikit-learn's `CountVectorizer` automates the entire preparation process:
1. **Lowercasing (`lowercase=True` by default):** Every uppercase character is converted to lowercase (`"Congratulations"` becomes `"congratulations"`).
2. **Punctuation Stripping:** Punctuation characters (`!`, `.`, `,`, `?`, `:`) are stripped out.
3. **Regular Expression Tokenization:** By default, `CountVectorizer` extracts tokens using the regex pattern `r'(?u)\w\w+'`. This isolates sequences of 2 or more alphanumeric characters bounded by word boundaries. (Single characters like `"a"` or `"I"` are ignored by default).

### Building the Vocabulary Dictionary
When `CountVectorizer.fit()` or `fit_transform()` is called on a collection of documents:
1. It scans every document and collects the set of all unique valid tokens.
2. It sorts those tokens alphabetically.
3. It assigns each token a unique column index from $0$ to $V-1$ (where $V$ is the total vocabulary size).
4. It stores this mapping in its internal `.vocabulary_` dictionary:
   ```python
   {"buy": 0, "cash": 1, "claim": 2, ...}
   ```

### Vectorizing New Documents
Once the vocabulary is established, any document is transformed into a fixed-length numerical vector of length $V$. The number at index $i$ is simply the count of how many times vocabulary word $i$ appeared in that document.

## Relevant Code (from main.py, lines 18, 31-33, and 44-48)

```python
from sklearn.feature_extraction.text import CountVectorizer

# ...
def top_words(model: Pipeline, class_index: int, n: int = 10) -> list[str]:
    vectorizer = model.named_steps["vectorizer"]
    classifier = model.named_steps["classifier"]
    names = vectorizer.get_feature_names_out()
    # ...

    model = Pipeline(
        [
            ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
            ("classifier", MultinomialNB()),
        ]
    )
```

### Code Explanation
- **Line 18:** Imports `CountVectorizer`.
- **Line 46:** Creates the vectorizer as the first step of the pipeline with `stop_words="english"` and `ngram_range=(1, 2)`.
- **Lines 31-33:** The helper function accesses `model.named_steps["vectorizer"]` and calls `.get_feature_names_out()` to retrieve an array of the exact vocabulary terms matching the columns of the classifier.

## Worked Example

Let us see how `CountVectorizer` tokenizes a mini-corpus and creates its vocabulary index:

```python
from sklearn.feature_extraction.text import CountVectorizer

corpus = [
    "Final notice: unpaid bill!",
    "Send payment today for bill."
]

vec = CountVectorizer()
X = vec.fit_transform(corpus)

print("Vocabulary Dictionary (word -> column index):")
print(vec.vocabulary_)

print("\nFeature Names Array (ordered by column index):")
print(vec.get_feature_names_out())

print("\nTransformed Matrix (Dense):")
print(X.toarray())
```

**Output:**
```
Vocabulary Dictionary (word -> column index):
{'final': 0, 'notice': 2, 'unpaid': 5, 'bill': 1, 'send': 3, 'payment': 4, 'today': 6}

Feature Names Array (ordered by column index):
['final' 'bill' 'notice' 'send' 'payment' 'unpaid' 'today']  # Alphabetical index 0 to 6

Transformed Matrix (Dense):
[[1 1 1 0 0 1 0]
 [0 1 0 1 1 0 1]]
```

Notice:
- Punctuation (`:`, `!`, `.`) was completely stripped.
- In row 0 (`"Final notice: unpaid bill!"`), indices for `'final'`, `'notice'`, `'unpaid'`, and `'bill'` each have a count of 1.
- In row 1 (`"Send payment today for bill."`), `'bill'` has a count of 1, and `'send'`, `'payment'`, `'today'` each have 1. (Notice `'for'` was retained because stop words were not yet activated).

## Step-by-Step Student Instructions

1. **Open a Python terminal** and import `CountVectorizer`:
   ```python
   from sklearn.feature_extraction.text import CountVectorizer
   ```
2. **Instantiate a basic vectorizer**:
   ```python
   vec = CountVectorizer()
   ```
3. **Fit and transform a sample sentence**:
   ```python
   sample = ["Urgent: claim prize now!", "Claim your free prize today!"]
   matrix = vec.fit_transform(sample)
   ```
4. **Inspect the features**:
   ```python
   print("Feature names:", vec.get_feature_names_out())
   print("Matrix shape:", matrix.shape)
   ```
5. **Notice how "prize" appears in both sentences** and is counted in both rows.

## Expected Output or Observable Behaviour

The vocabulary terms are displayed as clean alphanumeric strings:
```
Feature names: ['claim' 'free' 'now' 'prize' 'today' 'urgent' 'your']
Matrix shape: (2, 7)
```
Each row represents one document across the 7 unique vocabulary features.

## Practical Exercises

- **Exercise 1.1:** Why does default `CountVectorizer` drop single-letter words like `"a"` or `"I"`? Which parameter controls this behavior?
- **Exercise 1.2:** If the sentence `"Sale, sale, SALE!!!"` is passed to `CountVectorizer()`, what is the resulting count for the word `"sale"`?
- **Exercise 1.3:** What is the difference between `vec.vocabulary_` and `vec.get_feature_names_out()`?
- **Exercise 1.4:** If a new message at test time contains the word `"cryptocurrency"` (which never appeared in the training corpus), what does `vec.transform()` do with it?

## Common Mistakes and Debugging

| Mistake | Why it happens | Correction |
|---|---|---|
| Calling `fit()` again on test data | Overwriting the learned training vocabulary | Always call `fit_transform()` on training data, but only `transform()` on test data |
| Expecting punctuation in features | Believing `"!"` is a distinct token | Recognize default token pattern ignores non-alphanumeric punctuation |
| Confusing `.vocabulary_` values with counts | Assuming the dictionary values are word frequencies | Note that dictionary values are column indices, not word counts |
| Trying to index a sparse matrix like a list | Sparse matrices require 2D indexing | Use `.toarray()` or standard matrix slicing |

## Best Practices and Security Considerations

- **Pipeline Encapsulation:** Always package `CountVectorizer` inside an `sklearn.pipeline.Pipeline` to guarantee that vectorization fitting is strictly bound to training folds.
- **Custom Token Patterns:** If domain symbols (like dollar signs `$` or currency symbols) carry signal, customize the `token_pattern` regex parameter.
- **Memory Efficiency:** Avoid converting large corpus matrices with `.toarray()` in production, as it consumes gigabytes of unneeded memory.

## Summary

`CountVectorizer` is the foundational text preprocessing engine in scikit-learn. It normalizes text to lowercase, strips punctuation, tokenizes words via regex, compiles an alphabetically indexed vocabulary, and transforms raw strings into numerical term-frequency row vectors.

## Knowledge-check Questions

1. What regex pattern does `CountVectorizer` use by default to isolate tokens?
2. What happens to uppercase letters by default during `CountVectorizer` processing?
3. What is the difference between `vec.vocabulary_` and `vec.get_feature_names_out()`?
4. How many columns will the transformed matrix have if the corpus has 150 unique valid tokens?
5. Why is single-letter token filtering useful in standard text processing?

## References

- scikit-learn CountVectorizer API: https://scikit-learn.org/stable/modules/generated/sklearn.feature_extraction.text.CountVectorizer.html
- Tokenizing text with scikit-learn: https://scikit-learn.org/stable/modules/feature_extraction.html#customizing-the-vectorizer-classes
- Regular Expressions in Python: https://docs.python.org/3/library/re.html
