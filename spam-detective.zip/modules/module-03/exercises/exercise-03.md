# Module 3 Exercises: Text Vectorization (CountVectorizer)

## Exercise 3.1: Tokenization and Vocabulary Mapping (15 min)
**Objective:** Experiment with `CountVectorizer` parameters and inspect the resulting vocabulary mapping.

**Problem Statement:** 
Given a list of three marketing messages, configure a `CountVectorizer` to lowercase and tokenize the text, and output both the vocabulary dictionary and the term-document matrix.

**Corpus:**
```python
sample_corpus = [
    "Exclusive sale! Buy cheap software today.",
    "Order now to get 50% discount on software.",
    "Buy today, order today! Special discount."
]
```

**Requirements:**
1. Instantiate `CountVectorizer()` with default parameters
2. Fit the vectorizer on `sample_corpus` and transform it into a count matrix
3. Print the vocabulary dictionary (`vec.vocabulary_`) and the feature names array (`vec.get_feature_names_out()`)
4. Print the dense matrix using `.toarray()` and identify which column corresponds to `"software"`

**Constraints:** 
Use scikit-learn's `CountVectorizer`.

**Expected Behaviour:** 
Console output displaying the vocabulary mapping, feature names, and dense term-frequency array.

**Acceptance Criteria:**
- [ ] Punctuation is verified stripped
- [ ] Words are properly lowercased
- [ ] Feature names match alphabetical order
- [ ] Column index for `"software"` is correctly identified and verified against matrix counts

**Hints:**
- Look at `vec.vocabulary_['software']` to find its column index.

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 3.2: Stop Word Elimination Analysis (15 min)
**Objective:** Measure the quantitative impact of stop word filtering on vocabulary size and feature relevance.

**Problem Statement:** 
Take `X_train` from the Spam Detective project and compare `CountVectorizer()` without stop words versus `CountVectorizer(stop_words='english')`.

**Requirements:**
1. Load `messages.csv` and perform the 75/25 stratified split from `main.py`
2. Fit a vectorizer WITHOUT stop words and record the vocabulary length
3. Fit a second vectorizer WITH `stop_words='english'` and record the vocabulary length
4. Calculate the percentage reduction in vocabulary size
5. Print 5 words eliminated by the stop word filter and explain why their removal does not harm spam detection

**Constraints:** 
Keep `ngram_range=(1, 1)` for both trials to isolate the effect of stop words.

**Expected Behaviour:** 
A clear comparison report displaying both vocabulary sizes, reduction percentage, and sample filtered words.

**Acceptance Criteria:**
- [ ] Both vectorizers fitted exclusively on `X_train`
- [ ] Vocabulary size with stop words verified smaller than without
- [ ] Percentage reduction calculated accurately
- [ ] Written justification explaining why grammatical function words lack discriminative signal

**Hints:**
- Use `set(vec_no_stop.get_feature_names_out()) - set(vec_stop.get_feature_names_out())` to find the removed words.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 3.3: Bigram Feature Extraction and Phrase Analysis (15 min)
**Objective:** Compare unigram versus unigram+bigram representations using `ngram_range`.

**Problem Statement:** 
Demonstrate how bigrams capture essential phrase context in spam and ham communications.

**Requirements:**
1. Fit `CountVectorizer(stop_words='english', ngram_range=(1, 2))` on `X_train`
2. Count the total number of unigrams versus bigrams in the learned vocabulary
3. Identify 5 bigrams that strongly indicate commercial spam
4. Identify 5 bigrams that strongly indicate legitimate interpersonal communication (ham)
5. Explain why the bigram `"lowest price"` provides higher confidence than the isolated unigram `"price"`

**Constraints:** 
Use the exact `X_train` split from `main.py` (`random_state=42`, `stratify=df['label']`).

**Expected Behaviour:** 
A breakdown of total unigrams vs bigrams (summing to 288), with labeled lists of spam and ham phrase clues.

**Acceptance Criteria:**
- [ ] Total features confirmed as 288
- [ ] Unigram count and bigram count accurately separated
- [ ] 5 spam bigrams and 5 ham bigrams correctly identified from the vocabulary
- [ ] Clear explanation of phrase disambiguation

**Hints:**
- Filter bigrams using `[f for f in vec.get_feature_names_out() if " " in f]`.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 3.4: Sparse Matrix Representation & Sparsity Computation (15 min)
**Objective:** Calculate matrix sparsity and investigate memory efficiency in NLP.

**Problem Statement:** 
Write a Python script to compute the exact sparsity percentage of the training feature matrix and analyze Out-Of-Vocabulary (OOV) handling.

**Requirements:**
1. Transform `X_train` into a count matrix using the project's vectorizer
2. Extract the matrix shape `(rows, cols)`, total cells, and non-zero entries (`.nnz`)
3. Compute the sparsity percentage using the formula:
   $$\text{Sparsity} = \left(1 - \frac{\text{nnz}}{\text{rows} \times \text{cols}}\right) \times 100$$
4. Test the vectorizer's behavior on a sentence containing OOV words:
   `"Quantum blockchain algorithm predicts lottery jackpot."`
   Show which words are recognized and which are ignored.

**Constraints:** 
Rely on the SciPy sparse matrix methods provided by scikit-learn.

**Expected Behaviour:** 
Numerical printout showing ~95.75% sparsity, followed by an OOV demonstration showing only recognized vocabulary terms retained.

**Acceptance Criteria:**
- [ ] Matrix shape verified as `(60, 288)`
- [ ] Sparsity calculated as approximately 95.7%
- [ ] OOV tokens identified and verified discarded by `transform()` without errors

**Hints:**
- Use `vec.transform([new_sentence]).toarray()` to inspect transformed counts.

**Difficulty:** Advanced
**Estimated Completion Time:** 15 minutes
