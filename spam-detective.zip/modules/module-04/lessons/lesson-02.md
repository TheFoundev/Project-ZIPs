# Lesson 02: Pipeline Architecture in scikit-learn

**Lesson ID:** lesson-02
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain what an scikit-learn `Pipeline` is and why it represents professional ML architecture
- Describe how `Pipeline` chains transformers (`CountVectorizer`) with estimators (`MultinomialNB`)
- Explain how `Pipeline` prevents data leakage between training and testing splits
- Access and inspect individual named pipeline steps using `.named_steps`
- Compare raw multi-step coding against unified pipeline execution

## Prerequisites
- Completion of Lesson 01
- Understanding of `CountVectorizer` and `MultinomialNB`

## Concept Explanation

### What is an scikit-learn Pipeline?
In a complete machine learning workflow, raw input data rarely goes directly into a classifier. Instead, it must pass through a sequence of preprocessing steps:
$$\text{Raw Text} \longrightarrow \text{Tokenization \& Counting} \longrightarrow \text{Classification}$$

Without a pipeline, a developer must write cumbersome, error-prone code:
```python
# The manual, error-prone approach:
vec = CountVectorizer(...)
X_train_vec = vec.fit_transform(X_train)
clf = MultinomialNB()
clf.fit(X_train_vec, y_train)

# During testing, remember to call transform, NOT fit_transform:
X_test_vec = vec.transform(X_test)
preds = clf.predict(X_test_vec)

# For new messages, remember to vectorize again:
new_vec = vec.transform(new_messages)
new_preds = clf.predict(new_vec)
```
If you forget to transform a new message, or accidentally call `fit_transform()` on the test set, your code will either crash or suffer from severe **data leakage**.

### The Clean Solution: `sklearn.pipeline.Pipeline`
An scikit-learn `Pipeline` bundles the sequence of transformations and the final estimator into a **single, unified estimator object**.

In `main.py` lines 44-49, we build:
```python
    model = Pipeline(
        [
            ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
            ("classifier", MultinomialNB()),
        ]
    )
```
The pipeline takes a list of `(name, transform_object)` tuples, ending with an estimator.
Once bundled, the entire system behaves like a single model:
- `model.fit(X_train, y_train)`: Automatically calls `vectorizer.fit_transform(X_train)` and feeds the output directly into `classifier.fit()`.
- `model.predict(X_test)`: Automatically calls `vectorizer.transform(X_test)` and passes the sparse matrix directly to `classifier.predict()`.
- `model.predict(new_messages)`: You pass raw text strings directly; the pipeline handles all feature extraction behind the scenes!

### Preventing Data Leakage
Data leakage occurs when information from the test set inadvertently leaks into model training.
When using `Pipeline`:
- The vocabulary is strictly constructed from `X_train` during `model.fit()`.
- When evaluating `model.predict(X_test)`, the pipeline applies `transform()` (never `fit()`), guaranteeing that test set statistics and tokens cannot contaminate the learned vocabulary.

### Accessing Internal Steps with `.named_steps`
Even though steps are bundled, scikit-learn gives you full transparency. You can access any individual component via the `.named_steps` dictionary attribute:
```python
vectorizer = model.named_steps["vectorizer"]
classifier = model.named_steps["classifier"]
```
This is exactly how `main.py` extracts feature names and model log probabilities in the `top_words()` helper function!

## Relevant Code (from main.py, lines 22, 31-32, and 44-49)

```python
from sklearn.pipeline import Pipeline

# ...
def top_words(model: Pipeline, class_index: int, n: int = 10) -> list[str]:
    vectorizer = model.named_steps["vectorizer"]
    classifier = model.named_steps["classifier"]
    # ...

    model = Pipeline(
        [
            ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
            ("classifier", MultinomialNB()),
        ]
    )
```

### Code Explanation
- **Line 22:** Imports `Pipeline` from `sklearn.pipeline`.
- **Lines 31-32:** Uses `model.named_steps["vectorizer"]` and `model.named_steps["classifier"]` to inspect subcomponents.
- **Lines 44-49:** Assembles the two-stage pipeline.

## Worked Example

Let us verify how `Pipeline` processes a raw text message from start to finish:

```python
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB

# Mini dataset
X_sample = ["Lowest price guaranteed buy now", "Meeting tomorrow at 4 pm"]
y_sample = ["spam", "ham"]

pipe = Pipeline([
    ("vec", CountVectorizer()),
    ("nb", MultinomialNB())
])

# Fit on raw text
pipe.fit(X_sample, y_sample)

# Predict directly on brand new raw strings!
test_msg = ["Buy now for lowest price!"]
prediction = pipe.predict(test_msg)
probability = pipe.predict_proba(test_msg)

print("Direct text prediction:", prediction[0])
print("Class probabilities:   ", probability)
print("Pipeline steps:        ", list(pipe.named_steps.keys()))
```

**Output:**
```
Direct text prediction: spam
Class probabilities:    [[0.14285714 0.85714286]]
Pipeline steps:         ['vec', 'nb']
```

Notice how we passed a raw string directly to `pipe.predict()`. The pipeline handled lowercasing, tokenization, vocabulary matching, and probability calculation in one call!

## Step-by-Step Student Instructions

1. **Open your Python shell** in the project directory.
2. **Replicate the pipeline setup** from `main.py`:
   ```python
   from sklearn.pipeline import Pipeline
   from sklearn.feature_extraction.text import CountVectorizer
   from sklearn.naive_bayes import MultinomialNB
   
   model = Pipeline([
       ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
       ("classifier", MultinomialNB())
   ])
   ```
3. **Verify pipeline properties**:
   ```python
   print(len(model.steps))           # 2 steps
   print(model.steps[0][0])          # 'vectorizer'
   print(model.steps[1][0])          # 'classifier'
   ```
4. **Notice that `model` is not fitted yet**: Trying to call `model.predict()` now raises a `NotFittedError`.

## Expected Output or Observable Behaviour

The step names match the specified keys:
```
2
vectorizer
classifier
```
This confirms that the pipeline structure is cleanly assembled.

## Practical Exercises

- **Exercise 2.1:** What are the names of the two steps in the Spam Detective pipeline?
- **Exercise 2.2:** Why does calling `model.predict(X_test)` not cause data leakage when using a Pipeline?
- **Exercise 2.3:** Write the Python code to extract the learned classes from the classifier inside `model`.
- **Exercise 2.4:** If you wanted to add a `TfidfTransformer` between `CountVectorizer` and `MultinomialNB`, how would you modify the pipeline definition?

## Common Mistakes and Debugging

| Mistake | Why it happens | Correction |
|---|---|---|
| Vectorizing data before passing to Pipeline | Misunderstanding Pipeline role | Pass raw text Series directly into `model.fit(X_train, y_train)` |
| Typos in step names | Misspelling keys like `model.named_steps['vect']` | Use the exact string assigned during pipeline creation (`'vectorizer'`) |
| Calling `fit_transform()` on test data | Attempting manual vectorization | Let the pipeline call `transform()` automatically |
| Putting an estimator in the middle | Placing a model before a transformer | All pipeline steps except the last must be transformers implementing `fit_transform` |

## Best Practices and Security Considerations

- **Single Serialization Artifact:** When saving models for deployment (e.g. with `pickle` or `joblib`), saving the pipeline serializes both vectorizer and classifier together, preventing version mismatch.
- **Cross-Validation Safety:** When performing k-fold cross-validation (`cross_val_score`), passing a pipeline guarantees that vectorizer fitting occurs strictly inside each training fold.
- **Clear Naming:** Use descriptive step names (`'vectorizer'`, `'classifier'`) rather than generic names (`'step1'`, `'step2'`).

## Summary

Scikit-learn's `Pipeline` bundles text vectorization and statistical classification into a single, cohesive estimator. It simplifies execution, eliminates manual feature transformation steps, guarantees protection against data leakage, and provides clear inspectability via `.named_steps`.

## Knowledge-check Questions

1. What two components are chained together inside the pipeline in `main.py`?
2. What attribute on a Pipeline allows you to inspect individual steps by name?
3. How does `Pipeline` prevent data leakage during test set evaluation?
4. What method is automatically called on `CountVectorizer` when `model.fit()` is executed?
5. What method is automatically called on `CountVectorizer` when `model.predict()` is executed?

## References

- scikit-learn Pipeline Documentation: https://scikit-learn.org/stable/modules/generated/sklearn.pipeline.Pipeline.html
- Managing Complex ML Workflows with Pipelines: https://scikit-learn.org/stable/modules/compose.html
- Data Leakage in Machine Learning: https://en.wikipedia.org/wiki/Leakage_(machine_learning)
