# Lesson 04: Model Interpretability: feature_log_prob_ and top_words()

**Lesson ID:** lesson-04
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Inspect the internal parameter `classifier.feature_log_prob_`
- Explain the mathematical concept of log-odds ratio scoring for feature importance
- Trace the `top_words()` helper function line by line
- Understand how `np.argsort()` sorts indices and how slice indexing `[-n:][::-1]` reverses ranking
- Identify the top 10 discriminative clues for spam and ham in the project

## Prerequisites
- Completion of Lessons 01, 02, and 03
- Familiarity with NumPy array indexing and slicing

## Concept Explanation

### The "Black Box" Problem in AI
Many modern deep learning models (like deep neural networks) operate as opaque "black boxes": they make predictions, but humans cannot easily understand *why* a specific decision was reached.

Naive Bayes is the opposite: it is an **inherently interpretable model**. Every single prediction is directly traceable to the specific word probabilities learned during training.

### What is `feature_log_prob_`?
When `MultinomialNB` trains, it computes the log-probability of every vocabulary word for each class and stores them in `classifier.feature_log_prob_`:
- Shape: `(2, 288)`
- Row 0: $\ln P(w_i \mid \text{ham})$ for all 288 vocabulary features.
- Row 1: $\ln P(w_i \mid \text{spam})$ for all 288 vocabulary features.

Every value in this matrix is a negative float (since probabilities are decimals between 0 and 1, and the natural log of any number $< 1$ is negative).
- A value like $-2.5$ represents a relatively high probability (common word).
- A value like $-6.8$ represents a very low probability (rare word).

### The Log-Odds Ratio: Quantifying Clue Strength
Suppose a word like `"today"` appears in both spam and ham. Even if it is frequent, does it help us distinguish spam from ham? No!
To find the words that truly distinguish one class from the other, we must calculate the **log-odds ratio**:

$$\text{Score}_w = \ln P(w \mid \text{spam}) - \ln P(w \mid \text{ham}) = \ln \left(\frac{P(w \mid \text{spam})}{P(w \mid \text{ham})}\right)$$

- **If $\text{Score}_w > 0$:** The word is more probable in spam than in ham. A large positive score means the word is a strong **spam clue**!
- **If $\text{Score}_w < 0$:** The word is more probable in ham than in spam. A large negative score means the word is a strong **ham clue**!

### Dissecting `top_words()` Line by Line
In `main.py` lines 30-35:
```python
def top_words(model: Pipeline, class_index: int, n: int = 10) -> list[str]:
    vectorizer = model.named_steps["vectorizer"]
    classifier = model.named_steps["classifier"]
    names = vectorizer.get_feature_names_out()
    scores = classifier.feature_log_prob_[class_index] - classifier.feature_log_prob_[1 - class_index]
    return list(names[np.argsort(scores)[-n:][::-1]])
```

Let us dissect each operation:
1. `vectorizer` & `classifier`: Unpacks the pipeline steps.
2. `names = vectorizer.get_feature_names_out()`: Gets the array of 288 feature names.
3. `scores = classifier.feature_log_prob_[class_index] - classifier.feature_log_prob_[1 - class_index]`:
   - Computes the log-odds difference between the target class and the opposing class.
   - For spam (`class_index = 1`), `1 - class_index = 0` (ham).
   - Higher scores indicate stronger clues for that specific class.
4. `np.argsort(scores)`: Returns the integer indices that would sort `scores` in ascending order (lowest to highest).
5. `[-n:]`: Slices the last $n$ indices (the $n$ largest scores).
6. `[::-1]`: Reverses the slice so that the #1 largest score comes first!
7. `names[...]`: Indexing `names` with these sorted indices retrieves the actual words.

## Relevant Code (from main.py, lines 30-35 and 60-65)

```python
def top_words(model: Pipeline, class_index: int, n: int = 10) -> list[str]:
    vectorizer = model.named_steps["vectorizer"]
    classifier = model.named_steps["classifier"]
    names = vectorizer.get_feature_names_out()
    scores = classifier.feature_log_prob_[class_index] - classifier.feature_log_prob_[1 - class_index]
    return list(names[np.argsort(scores)[-n:][::-1]])

# ... (inside main)
    classes = list(model.named_steps["classifier"].classes_)
    spam_index = classes.index("spam")
    spam_words = top_words(model, spam_index)
    ham_words = top_words(model, 1 - spam_index)
    print("Top spam clues:", ", ".join(spam_words))
    print("Top normal clues:", ", ".join(ham_words))
```

### Code Explanation
- The helper extracts the 10 most discriminative words for both spam and ham and prints them to the terminal.

## Worked Example

Let us run `top_words()` and inspect the resulting clues and their exact log-odds scores:

```python
import numpy as np

# Assuming model is fitted from main.py
vectorizer = model.named_steps["vectorizer"]
classifier = model.named_steps["classifier"]
names = vectorizer.get_feature_names_out()
classes = list(classifier.classes_)
spam_index = classes.index("spam")

# Calculate scores for spam
scores = classifier.feature_log_prob_[spam_index] - classifier.feature_log_prob_[1 - spam_index]
sorted_indices = np.argsort(scores)[-5:][::-1]

print("Top 5 Spam Clues with Log-Odds Difference:")
for rank, idx in enumerate(sorted_indices, 1):
    print(f"  #{rank}: {names[idx]:20s} (Score: +{scores[idx]:.2f})")
```

**Output:**
```
Top 5 Spam Clues with Log-Odds Difference:
  #1: buy                  (Score: +2.95)
  #2: price                (Score: +2.95)
  #3: 50 buy               (Score: +2.44)
  #4: price guaranteed     (Score: +2.44)
  #5: 50                   (Score: +2.44)
```

Notice that `"buy"` and `"price"` have a log-odds advantage of nearly $+3.0$, meaning they are roughly $\exp(2.95) \approx 19$ times more probable in spam than in ham!

## Step-by-Step Student Instructions

1. **Open your Python shell** with the fitted model.
2. **Execute the `top_words` function**:
   ```python
   spam_words = top_words(model, spam_index)
   ham_words = top_words(model, 1 - spam_index)
   print("Top spam:", spam_words)
   print("Top normal:", ham_words)
   ```
3. **Compare with console output of `main.py`**:
   - Spam clues: `buy`, `price`, `50 buy`, `price guaranteed`, `50`, `order`, `lowest`, `guaranteed`, `lowest price`, `risk`.
   - Normal clues: `meeting`, `today class`, `send notes`, `start`, `ll`, `tomorrow`, `ll minutes`, `minutes late`, `minutes`, `meeting lunch`.
4. **Notice how bigrams appear**: Terms like `'price guaranteed'` and `'minutes late'` are among the strongest clues discovered by the model!

## Expected Output or Observable Behaviour

The printed list matches `main.py`:
```
Top spam clues: buy, price, 50 buy, price guaranteed, 50, order, lowest, guaranteed, lowest price, risk
Top normal clues: meeting, today class, send notes, start, ll, tomorrow, ll minutes, minutes late, minutes, meeting lunch
```

## Practical Exercises

- **Exercise 4.1:** What are the exact dimensions of `classifier.feature_log_prob_` in the Spam Detective project?
- **Exercise 4.2:** Why are all values in `feature_log_prob_` negative numbers?
- **Exercise 4.3:** In `np.argsort(scores)[-n:][::-1]`, what is the purpose of `[::-1]`?
- **Exercise 4.4:** Name three bigrams that appear in the top 10 normal clues list.

## Common Mistakes and Debugging

| Mistake | Why it happens | Correction |
|---|---|---|
| Forgetting `[::-1]` | Getting words in ascending order (weakest first) | Apply `[::-1]` to reverse array so highest score is first |
| Ranking by raw frequency instead of log-odds | Showing words that are common in both classes | Subtract class log probabilities to find discriminative words |
| Using `classifier.coef_` | `coef_` in MultinomialNB is legacy/deprecated | Use `classifier.feature_log_prob_` directly |
| Hardcoding vocabulary length | Assuming vocabulary is always 100 words | Use `vectorizer.get_feature_names_out()` dynamically |

## Best Practices and Security Considerations

- **Model Auditing:** Reviewing top clue words helps detect accidental bias (e.g. if a person's name or department code unexpectedly ranks as a top spam clue).
- **Adversarial Defenses:** Attackers study top clue words to avoid them; monitoring log-odds shifts over time reveals evolving spam tactics.
- **Explainable AI (XAI):** Presenting top clue words alongside flagged emails gives users clear justification for why a message was quarantined.

## Summary

`classifier.feature_log_prob_` stores the log conditional probabilities for all 288 vocabulary features across both classes. By subtracting the opposing class log probabilities, the `top_words()` function calculates the log-odds ratio for every word, isolates the most discriminative tokens using `np.argsort()`, and extracts the top 10 clues that identify spam and ham.

## Knowledge-check Questions

1. What does the matrix `classifier.feature_log_prob_` represent?
2. What mathematical formula does `top_words()` use to score clue strength?
3. What is the shape of `classifier.feature_log_prob_` in our project?
4. What NumPy function returns the indices that sort an array?
5. Name the top 3 spam clues and top 3 normal clues identified by `main.py`.

## References

- scikit-learn MultinomialNB feature_log_prob_: https://scikit-learn.org/stable/modules/generated/sklearn.naive_bayes.MultinomialNB.html
- NumPy argsort documentation: https://numpy.org/doc/stable/reference/generated/numpy.argsort.html
- Interpretable Machine Learning - Christoph Molnar: https://christophm.github.io/interpretable-ml-book/
