# Lesson 01: Probabilistic Foundations: Bayes' Theorem and Multinomial Naive Bayes

**Lesson ID:** lesson-01
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- State Bayes' Theorem and explain its mathematical components (Prior, Likelihood, Posterior)
- Explain why the Naive Bayes algorithm is described as "naive"
- Describe how Multinomial Naive Bayes computes word frequency probabilities for each class
- Explain why log-probabilities are calculated in practice to prevent floating-point underflow
- Understand why Laplace smoothing is necessary when novel words appear

## Prerequisites
- Completion of Module 03 (Text Vectorization)
- Basic understanding of probabilities between 0.0 and 1.0

## Concept Explanation

### Bayes' Theorem in Text Classification
At its core, spam detection answers a fundamental probabilistic question:
**"Given that a message contains words $W = (w_1, w_2, \dots, w_k)$, what is the probability that the message is spam?"**

Mathematically, this conditional probability is written as $P(\text{spam} \mid W)$.
Bayes' Theorem provides the exact formula to compute this:

$$P(\text{spam} \mid W) = \frac{P(W \mid \text{spam}) \cdot P(\text{spam})}{P(W)}$$

Let us break down each component:
1. **Prior Probability $P(\text{spam})$:** The baseline probability of any incoming message being spam before reading its text. In our balanced 40/40 dataset, $P(\text{spam}) = 0.50$ (50%).
2. **Likelihood $P(W \mid \text{spam})$:** The probability that a known spam message would contain this specific combination of words.
3. **Evidence $P(W)$:** The overall probability of observing these words across all messages.
4. **Posterior Probability $P(\text{spam} \mid W)$:** The updated probability that the message is spam after observing its words.

### Why is it Called "Naive"?
To calculate the true likelihood $P(w_1, w_2, \dots, w_k \mid \text{spam})$, a model would need to know the joint probability of all words occurring together in that exact sequence. In natural language, words are clearly dependent on one another (e.g. `"credit"` is often followed by `"card"`).

The **Naive Bayes** algorithm makes a radical simplifying assumption:
**It assumes that all words in a document are conditionally independent of each other, given the class label.**

Under this assumption, the likelihood simplifies to the product of individual word probabilities:
$$P(w_1, w_2, \dots, w_k \mid \text{spam}) = P(w_1 \mid \text{spam}) \times P(w_2 \mid \text{spam}) \times \dots \times P(w_k \mid \text{spam})$$

Even though language grammar violates this independence assumption in reality, Naive Bayes performs remarkably well in practice. While its probability estimates may be slightly overconfident, its **classification ranking** (whether $P(\text{spam}) > P(\text{ham})$) is extraordinarily accurate and computationally lightning-fast.

### Multinomial Naive Bayes
For text data represented by term frequencies (word counts), we use **Multinomial Naive Bayes** (`MultinomialNB`).
It models document word counts as samples drawn from a multinomial distribution:
$$P(w_i \mid c) = \frac{N_{ci} + \alpha}{N_c + \alpha \cdot |V|}$$
where:
- $N_{ci}$ is the count of word $i$ across all training documents of class $c$.
- $N_c$ is the total count of all words in class $c$.
- $\alpha$ is the **Laplace smoothing** parameter (default $\alpha = 1.0$). Adding 1 prevents any probability from being zero if a word appears in one class but not the other!
- $|V|$ is the vocabulary size (288 features in our project).

### Preventing Numerical Underflow with Logarithms
If an email contains 40 words, multiplying 40 small probabilities together (e.g. $0.002 \times 0.0005 \times 0.001 \dots$) causes the resulting decimal to become smaller than the computer's floating-point precision ($10^{-50}$), resulting in **numerical underflow** (rounding to 0.0).

To solve this, scikit-learn computes everything in **log-space**:
$$\ln(A \times B) = \ln(A) + \ln(B)$$
Instead of multiplying tiny decimals, the computer **sums negative logarithms**. This is why `classifier.feature_log_prob_` stores log-probabilities rather than raw probabilities.

## Relevant Code (from main.py, lines 21 and 44-48)

```python
from sklearn.naive_bayes import MultinomialNB

# ...
    model = Pipeline(
        [
            ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
            ("classifier", MultinomialNB()),
        ]
    )
```

### Code Explanation
- **Line 21:** Imports `MultinomialNB` from `sklearn.naive_bayes`.
- **Line 47:** Instantiates `MultinomialNB()`. By default, it applies Laplace smoothing with $\alpha=1.0$ and learns class priors directly from the training data.

## Worked Example

Suppose our training data has two classes with equal priors ($P(\text{spam}) = P(\text{ham}) = 0.5$).
We test a message containing two words: `"cash"` and `"meeting"`.
Suppose historical frequencies give:
- $P(\text{"cash"} \mid \text{spam}) = 0.04$, $P(\text{"cash"} \mid \text{ham}) = 0.001$
- $P(\text{"meeting"} \mid \text{spam}) = 0.001$, $P(\text{"meeting"} \mid \text{ham}) = 0.05$

**1. Calculate Spam Score:**
$$\text{Score}(\text{spam}) = P(\text{spam}) \times P(\text{"cash"} \mid \text{spam}) \times P(\text{"meeting"} \mid \text{spam})$$
$$= 0.5 \times 0.04 \times 0.001 = 0.000020$$

**2. Calculate Ham Score:**
$$\text{Score}(\text{ham}) = P(\text{ham}) \times P(\text{"cash"} \mid \text{ham}) \times P(\text{"meeting"} \mid \text{ham})$$
$$= 0.5 \times 0.001 \times 0.05 = 0.000025$$

**3. Decision:**
Since $0.000025 > 0.000020$, the model classifies the message as **ham**!
Notice how the stronger evidence for `"meeting"` in ham ($0.05$) outweighed the evidence for `"cash"` in spam ($0.04$).

## Step-by-Step Student Instructions

1. **Launch a Python session** in your terminal.
2. **Inspect the prior probabilities** computed by `MultinomialNB`:
   ```python
   import numpy as np
   # With 50/50 balance, log prior is ln(0.5)
   print("Log prior of 50%:", np.log(0.5))
   ```
3. **Verify this matches main.py**:
   Fit the model as in `main.py` and inspect `model.named_steps["classifier"].class_log_prior_`.
   Notice it outputs `[-0.69314718, -0.69314718]`.
4. **Convert back to normal probability**:
   `np.exp(model.named_steps["classifier"].class_log_prior_)` returns `[0.5, 0.5]`.

## Expected Output or Observable Behaviour

The class log priors reflect the exact 50/50 training balance:
```
[-0.69314718 -0.69314718]
```
Taking `np.exp()` confirms prior probabilities of exactly 50% for ham and 50% for spam.

## Practical Exercises

- **Exercise 1.1:** Why is the Naive Bayes algorithm called "naive"? What specific assumption does it make about words in a sentence?
- **Exercise 1.2:** What is Laplace smoothing, and what mathematical problem does it solve when an unknown word appears in a message?
- **Exercise 1.3:** If $P(A) = 0.5$ and $P(B) = 0.01$, what is $\ln(A \times B)$ computed as a sum of logarithms?
- **Exercise 1.4:** Why does Multinomial Naive Bayes fit text count data better than Gaussian Naive Bayes?

## Common Mistakes and Debugging

| Mistake | Why it happens | Correction |
|---|---|---|
| Using `GaussianNB` for text counts | Assuming all Naive Bayes classes behave identically | Use `MultinomialNB` for discrete word counts |
| Multiplying raw probabilities directly | Causing floating-point numerical underflow | Work in log-space by summing log probabilities |
| Setting $\alpha = 0$ in smoothing | Disabling Laplace smoothing | Keep $\alpha = 1.0$ so unseen words do not zero out entire products |
| Thinking Naive Bayes understands grammar | Believing the model parses sentence syntax | Remember it computes purely conditional word counts |

## Best Practices and Security Considerations

- **Laplace Smoothing Default:** Always leave $\alpha=1.0$ (add-one smoothing) enabled to prevent zero-probability crashes on edge-case vocabularies.
- **Fast Training:** MultinomialNB trains in a single pass over the counts, making it ideal for low-latency production pipelines.
- **Class Prior Balancing:** If deploying to heavily imbalanced inboxes, adjust `class_prior` or calibrate thresholds rather than relying solely on default 50% decision cuts.

## Summary

Multinomial Naive Bayes applies Bayes' Theorem to classify documents based on word counts. Its "naive" assumption—that words occur independently given the class—allows it to compute posterior class probabilities by multiplying individual token likelihoods. In practice, calculations are performed by summing logarithms to prevent numerical underflow, and Laplace smoothing guarantees non-zero probabilities for all vocabulary terms.

## Knowledge-check Questions

1. State Bayes' Theorem in the context of predicting spam from a set of words $W$.
2. What is the "naive" independence assumption in Naive Bayes?
3. What is the value of `class_log_prior_` in `main.py`, and why does it equal $\ln(0.5)$?
4. What is numerical underflow, and how does computing in log-space prevent it?
5. What is the purpose of Laplace smoothing (parameter $\alpha=1.0$) in `MultinomialNB`?

## References

- scikit-learn MultinomialNB: https://scikit-learn.org/stable/modules/generated/sklearn.naive_bayes.MultinomialNB.html
- Naive Bayes Classifier in scikit-learn Guide: https://scikit-learn.org/stable/modules/naive_bayes.html#multinomial-naive-bayes
- Stanford NLP - Naive Bayes and Sentiment: https://web.stanford.edu/~jurafsky/slp3/4.pdf
