# Lesson 03: Training the Model and Generating Predictions

**Lesson ID:** lesson-03
**Module:** module-04
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Trace the execution of `model.fit(X_train, y_train)` on the 60 training messages
- Understand how `model.predict(X_test)` generates class predictions on unseen data
- Examine the `classes_` attribute of `MultinomialNB` and verify alphabetical ordering
- Explain why dynamic class indexing (`classes.index("spam")`) is safer than hardcoding indices
- Contrast deterministic class predictions (`predict()`) with probability estimates (`predict_proba()`)

## Prerequisites
- Completion of Lessons 01 and 02
- Understanding of the stratified train/test split

## Concept Explanation

### Training with `model.fit()`
In `main.py` line 50, the entire learning process is triggered by a single line of code:
```python
model.fit(X_train, y_train)
```
When this line executes:
1. `CountVectorizer` scans the 60 messages in `X_train`.
2. It strips stop words, extracts unigrams and bigrams, and builds the 288-word vocabulary.
3. It transforms `X_train` into a $60 \times 288$ sparse count matrix.
4. `MultinomialNB` counts total token frequencies for class `"ham"` (30 messages) and class `"spam"` (30 messages).
5. It applies Laplace smoothing ($\alpha=1.0$) and calculates the log-prior `class_log_prior_` and conditional log-likelihoods `feature_log_prob_`.

Because Naive Bayes requires only a single pass over the counts, training completes in less than **10 milliseconds** on a standard laptop.

### Generating Test Predictions with `model.predict()`
In `main.py` line 51:
```python
predictions = model.predict(X_test)
```
When evaluating the 20 test messages:
1. `vectorizer.transform(X_test)` maps each test message to a 288-column vector using the training vocabulary.
2. `classifier` computes the joint log-posterior for both classes:
   $$\ln P(\text{ham} \mid X) = \ln P(\text{ham}) + \sum_{i} x_i \ln P(w_i \mid \text{ham})$$
   $$\ln P(\text{spam} \mid X) = \ln P(\text{spam}) + \sum_{i} x_i \ln P(w_i \mid \text{spam})$$
3. **The Decision Rule:** Whichever class achieves the higher score is selected as the prediction:
   $$\hat{y} = \arg\max_{c \in \{\text{ham}, \text{spam}\}} P(c \mid X)$$
4. The output `predictions` is a NumPy array of 20 string labels (`'spam'` or `'ham'`).

### Understanding `classes_` and Dynamic Indexing
When `MultinomialNB` fits on string labels, it stores the detected classes in alphabetical order in `classifier.classes_`:
```python
classes = list(model.named_steps["classifier"].classes_)
# Output: ['ham', 'spam']
```
Here:
- Index 0 corresponds to `'ham'`.
- Index 1 corresponds to `'spam'`.

In `main.py` lines 61-63, notice how the code locates spam:
```python
spam_index = classes.index("spam")
spam_words = top_words(model, spam_index)
ham_words = top_words(model, 1 - spam_index)
```
**Why write `classes.index("spam")` instead of hardcoding `spam_index = 1`?**
In professional software, defensive programming is critical. If someone renamed labels to `"unsolicited"` vs `"legitimate"`, alphabetical sorting would invert the indices! Using `classes.index("spam")` dynamically queries the exact index, preventing catastrophic silent bugs.

### Deterministic Prediction vs Probability Estimation
Scikit-learn classifiers provide two core prediction methods:
- `model.predict(X)`: Returns the discrete class label (`'ham'` or `'spam'`).
- `model.predict_proba(X)`: Returns an array of normalized probabilities summing to 1.0 (e.g. `[0.01, 0.99]`).

In `main.py` lines 74-79, both methods are used to show not just *what* the model predicted, but *how confident* it was in that prediction.

## Relevant Code (from main.py, lines 50-51, 60-63, and 74-75)

```python
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    # ...
    classes = list(model.named_steps["classifier"].classes_)
    spam_index = classes.index("spam")
    spam_words = top_words(model, spam_index)
    ham_words = top_words(model, 1 - spam_index)

    # ...
    new_predictions = model.predict(new_messages)
    probabilities = model.predict_proba(new_messages)
```

### Code Explanation
- **Line 50:** Trains the complete pipeline.
- **Line 51:** Generates test set predictions.
- **Lines 60-63:** Queries the dynamic class list and determines index 1 for spam and index 0 for ham.
- **Lines 74-75:** Generates both discrete labels and continuous probabilities for live test messages.

## Worked Example

Let us trace how the classifier predicts on a new test message:
Message: `"URGENT: verify your password immediately or your account will be suspended."`

```python
# Assume model is fitted
msg = ["URGENT: verify your password immediately or your account will be suspended."]

pred = model.predict(msg)
probs = model.predict_proba(msg)
classes = list(model.named_steps["classifier"].classes_)

print("Predicted Label:   ", pred[0])
print("Ham Probability:   ", f"{probs[0][classes.index('ham')]:.2%}")
print("Spam Probability:  ", f"{probs[0][classes.index('spam')]:.2%}")
```

**Output:**
```
Predicted Label:    spam
Ham Probability:    1.64%
Spam Probability:   98.36%
```

Since the spam probability ($98.36\%$) exceeds $50\%$, the deterministic prediction is `'spam'`.

## Step-by-Step Student Instructions

1. **Open your Python terminal** in the project directory.
2. **Execute training and test prediction**:
   ```python
   import pandas as pd
   from sklearn.model_selection import train_test_split
   from sklearn.pipeline import Pipeline
   from sklearn.feature_extraction.text import CountVectorizer
   from sklearn.naive_bayes import MultinomialNB
   
   df = pd.read_csv("data/messages.csv")
   X_train, X_test, y_train, y_test = train_test_split(
       df["text"], df["label"], test_size=0.25, random_state=42, stratify=df["label"]
   )
   model = Pipeline([
       ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
       ("classifier", MultinomialNB())
   ])
   model.fit(X_train, y_train)
   preds = model.predict(X_test)
   ```
3. **Compare predictions to ground truth**:
   ```python
   import numpy as np
   print("Matches:", np.sum(preds == y_test.values), "/ 20")
   ```
   Notice that all 20 test predictions match the ground-truth labels perfectly!

## Expected Output or Observable Behaviour

The terminal confirms:
```
Matches: 20 / 20
```
The model achieved 100% accuracy on the test partition.

## Practical Exercises

- **Exercise 3.1:** What is the data type and length of the array returned by `model.predict(X_test)`?
- **Exercise 3.2:** What are the contents of `model.named_steps["classifier"].classes_`?
- **Exercise 3.3:** Why is `1 - spam_index` guaranteed to give the ham index in a binary classification setting?
- **Exercise 3.4:** What is the difference between `predict()` and `predict_proba()`?

## Common Mistakes and Debugging

| Mistake | Why it happens | Correction |
|---|---|---|
| Hardcoding `spam_index = 1` | Assuming classes always sort into index 1 | Use `classes.index('spam')` dynamically |
| Passing a single string to `predict()` | Passing `"hello"` instead of `["hello"]` | Always pass an iterable (list or Series) of strings |
| Confusing probability order | Assuming probability column 0 is always spam | Check `model.named_steps['classifier'].classes_` for column ordering |
| Calling `fit()` multiple times | Accidentally reinitializing training | Call `fit()` once, then call `predict()` as needed |

## Best Practices and Security Considerations

- **Iterable Consistency:** Always pass a list of strings (`["message"]`) to `predict()`, even when testing a single sentence.
- **Threshold Tuning:** While `predict()` defaults to a 50% cutoff, mission-critical spam systems may require a 90% or 95% threshold before quarantining emails to prevent false positives.
- **Audit Logging:** In enterprise email security, log both the predicted label and the model's confidence probability for administrative review.

## Summary

Calling `model.fit(X_train, y_train)` fits both the vocabulary and the class-conditional probabilities in milliseconds. Calling `model.predict(X_test)` classifies unseen messages by choosing the class with the highest posterior probability. Scikit-learn orders classes alphabetically (`['ham', 'spam']`), and dynamic querying via `classes.index("spam")` ensures resilient code.

## Knowledge-check Questions

1. What two core operations occur when `model.fit(X_train, y_train)` is called on the pipeline?
2. What are the two class labels in `classifier.classes_`, and in what order do they appear?
3. Why is `spam_index = classes.index("spam")` preferred over hardcoding `spam_index = 1`?
4. How many test messages were correctly classified by `main.py` out of the 20 test samples?
5. What does `model.predict_proba()` return, and what must the probabilities for each sample sum to?

## References

- scikit-learn Classifier predict: https://scikit-learn.org/stable/modules/generated/sklearn.naive_bayes.MultinomialNB.html#sklearn.naive_bayes.MultinomialNB.predict
- Probability Calibration in scikit-learn: https://scikit-learn.org/stable/modules/calibration.html
- Decision Rules in Statistical Classification: https://en.wikipedia.org/wiki/Bayes_classifier
