# Module 4 Exercises: Naive Bayes & Pipeline Training

## Exercise 4.1: Manual Naive Bayes Calculation (15 min)
**Objective:** Calculate Bayes' Theorem probability scores by hand for a two-word document.

**Problem Statement:** 
Given class priors $P(\text{spam}) = 0.5$ and $P(\text{ham}) = 0.5$, compute whether a message containing `"free"` and `"meeting"` is classified as spam or ham using the provided conditional probabilities.

**Conditional Probabilities:**
- $P(\text{"free"} \mid \text{spam}) = 0.080$, $P(\text{"free"} \mid \text{ham}) = 0.005$
- $P(\text{"meeting"} \mid \text{spam}) = 0.002$, $P(\text{"meeting"} \mid \text{ham}) = 0.060$

**Requirements:**
1. State the "naive" conditional independence formula for $P(\text{"free"}, \text{"meeting"} \mid \text{class})$
2. Calculate the unnormalized posterior score for class `spam`
3. Calculate the unnormalized posterior score for class `ham`
4. Normalize the scores to find exact percentage probabilities summing to 100%
5. State the final model verdict (`spam` or `ham`)

**Constraints:** 
Show all arithmetic steps clearly.

**Expected Behaviour:** 
A written derivation showing the exact multiplication steps and resulting decision.

**Acceptance Criteria:**
- [ ] Spam score calculated: $0.5 \times 0.080 \times 0.002 = 0.000080$
- [ ] Ham score calculated: $0.5 \times 0.005 \times 0.060 = 0.000150$
- [ ] Normalized probabilities calculated: Ham $\approx 65.22\%$, Spam $\approx 34.78\%$
- [ ] Correctly concludes the message is classified as `ham`

**Hints:**
- Normalized probability $P(\text{ham}) = \frac{\text{Score}(\text{ham})}{\text{Score}(\text{ham}) + \text{Score}(\text{spam})}$.

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 4.2: Building and Inspecting an scikit-learn Pipeline (15 min)
**Objective:** Assemble an scikit-learn Pipeline and access its internal estimators using `.named_steps`.

**Problem Statement:** 
Write a script that creates the project's exact pipeline, trains it on `X_train`, and inspects each component.

**Requirements:**
1. Import `Pipeline`, `CountVectorizer`, and `MultinomialNB`
2. Build the two-stage pipeline with step names `'vectorizer'` and `'classifier'`
3. Train the model using `.fit(X_train, y_train)`
4. Extract and print the vectorizer's vocabulary length from `model.named_steps["vectorizer"]`
5. Extract and print the classifier's class labels from `model.named_steps["classifier"].classes_`

**Constraints:** 
Use the stratified split of `messages.csv` from Module 02.

**Expected Behaviour:** 
The script prints confirmation of 288 vocabulary features and classes `['ham', 'spam']`.

**Acceptance Criteria:**
- [ ] Pipeline constructed with correct step names
- [ ] `.named_steps` syntax used correctly
- [ ] Vocabulary length verified as 288
- [ ] Classes verified as `['ham', 'spam']`

**Hints:**
- Use `len(model.named_steps["vectorizer"].get_feature_names_out())`.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 4.3: Implementing the top_words() Feature Ranker (15 min)
**Objective:** Recreate the `top_words()` helper function and extract the top discriminative clues for both classes.

**Problem Statement:** 
Write and test a standalone function that calculates log-odds scores and prints the top 5 clues for any specified class.

**Requirements:**
1. Implement `top_words(model, class_index, n=5)` following lines 30-35 of `main.py`
2. Retrieve `spam_index` dynamically using `classes.index("spam")`
3. Call `top_words()` for spam and ham with `n=5`
4. Print the top 5 clues alongside their numerical log-odds score differences

**Constraints:** 
Use `np.argsort()` and negative slice indexing.

**Expected Behaviour:** 
A formatted console printout showing top clues for spam and ham with positive log-odds scores.

**Acceptance Criteria:**
- [ ] Function signature and return type match `main.py`
- [ ] Dynamic class index querying implemented
- [ ] Top 5 spam clues match: `buy`, `price`, `50 buy`, `price guaranteed`, `50`
- [ ] Top 5 ham clues match: `meeting`, `today class`, `send notes`, `start`, `ll`

**Hints:**
- Remember `score = classifier.feature_log_prob_[class_index] - classifier.feature_log_prob_[1 - class_index]`.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 4.4: Analyzing Dynamic vs Hardcoded Class Indexing (15 min)
**Objective:** Evaluate defensive programming in machine learning pipelines.

**Problem Statement:** 
Analyze why hardcoding class indices (e.g. `spam_index = 1`) creates high-risk latent bugs in production machine learning software.

**Requirements:**
1. Explain how scikit-learn assigns indices to string targets during `fit()`
2. Demonstrate what happens if the labels in `messages.csv` are changed from `['ham', 'spam']` to `['legitimate', 'unwanted']`
3. Show which class is assigned index 0 and index 1 in the renamed scenario
4. Explain how `classes.index("unwanted")` prevents silent classification failures

**Constraints:** 
Provide a clear code simulation demonstrating both alphabetical sorting outcomes.

**Expected Behaviour:** 
A short technical note explaining scikit-learn's label sorting mechanism with reproducible demonstration code.

**Acceptance Criteria:**
- [ ] Explains alphabetical sorting of string labels in `classes_`
- [ ] Demonstrates that `'legitimate'` becomes index 0 and `'unwanted'` becomes index 1
- [ ] Concludes why dynamic lookup `classes.index(label_name)` is mandatory for robust production code

**Hints:**
- In Python: `sorted(['legitimate', 'unwanted'])` -> `['legitimate', 'unwanted']`.

**Difficulty:** Advanced
**Estimated Completion Time:** 15 minutes
