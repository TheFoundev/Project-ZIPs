# Lesson 01: The Spam Detection Challenge

**Lesson ID:** lesson-01
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Define what email and message spam is and quantify its real-world impact
- Distinguish between legitimate communications ("ham") and unsolicited messages ("spam")
- Identify why spam detection is formulated as a binary classification problem
- Contrast the severity of false positive errors versus false negative errors in communication filters
- Explain how machine learning automates the classification of unstructured text data

## Prerequisites
- Basic familiarity with everyday email or messaging systems
- Understanding of the distinction between supervised learning and unsupervised learning

## Concept Explanation

### What is Spam?
In digital communications, **spam** refers to unsolicited, bulk, and often deceptive or malicious messages sent across email, SMS, messaging apps, and social platforms. First appearing at scale in the late 1990s, spam accounts for tens of billions of messages globally every day—ranging from benign advertisements and coupon promotions to dangerous phishing attacks, credential harvesting, malware delivery, and financial fraud.

In the natural language processing (NLP) and machine learning community, non-spam messages are universally referred to as **ham**. The term originates from the Monty Python comedy sketch where "Spam" is repeated excessively, leading tech pioneers to adopt "ham" as the wholesome, legitimate counterpart.

### Spam Detection as Binary Classification
Machine learning tasks are broadly categorized into regression (predicting continuous numerical quantities, like house prices or temperatures) and classification (predicting discrete categorical labels).

When a system must assign an incoming message to one of exactly two categories—either **ham** (0) or **spam** (1)—this is known as **binary classification**.
- **Input ($X$):** The raw text of a message (e.g., "Congratulations! You won a free smartphone. Click now to claim your prize.")
- **Target ($y$):** A discrete class label, typically represented as `"spam"` vs `"ham"` (or numerical equivalents 1 vs 0).

Unlike predicting a numeric measurement, the model's goal is to learn a decision boundary that partitions the space of all possible messages into two distinct regions: legitimate messages and spam messages.

### The Asymmetric Cost of Classification Errors
In binary classification, an algorithm can make two distinct types of mistakes:
1. **False Positive (Type I Error):** A legitimate message (ham) is incorrectly classified as spam and sent to the junk folder or deleted.
2. **False Negative (Type II Error):** A spam message is incorrectly classified as ham and delivered to the user's main inbox.

These errors do **not** carry equal real-world consequences:
- If a spam email bypasses the filter into your inbox (**False Negative**), it causes minor irritation: you delete it in one second.
- If an urgent job offer, password reset token, or medical appointment confirmation is misrouted to spam (**False Positive**), you may never see it, resulting in severe real-world harm.

Consequently, real-world spam detection systems demand exceptionally high **precision** on the spam class (meaning when the filter flags an email as spam, it must be virtually certain).

## Relevant Code (from main.py, lines 1-8)

```python
"""Project 04: Spam Detective (Naive Bayes text classification).

Run:
    python main.py

The model learns which words are common in spam and which are common in
normal messages, then classifies new messages.
"""
```

### Code Explanation
- **Line 1:** Declares the project title and its core algorithm: Naive Bayes text classification.
- **Lines 3-4:** Shows standard execution from the terminal (`python main.py`).
- **Lines 6-7:** Defines the fundamental statistical learning principle behind the project: counting which words occur frequently in spam vs normal (ham) messages, and using those frequency distributions to classify new, unseen messages.

## Worked Example

Imagine an inbox receives four messages. Let us analyze their nature, the binary target, and the operational risk of misclassification:

| Message Text | True Label | If Filter Classifies as Spam | If Filter Classifies as Ham |
|---|---|---|---|
| "URGENT: Your bank account will be suspended. Click here to verify." | Spam | Correct routing to Junk (True Positive) | Phishing email lands in Inbox; user risks credential theft (False Negative) |
| "Flight itinerary attached for your trip next Tuesday." | Ham | Important travel document hidden from user (False Positive - High Cost) | Correct delivery to Inbox (True Negative) |
| "Lowest price guaranteed! Get vitamins at 50% off. Buy now." | Spam | Junk folder delivery (True Positive) | Minor inbox clutter (False Negative - Low Cost) |
| "Can we meet at 4 pm to review the project?" | Ham | Colleague message missed, meeting ruined (False Positive - High Cost) | Correct delivery to Inbox (True Negative) |

This comparison highlights why statistical classifiers must balance sensitivity with strict safeguards against false alarms.

## Step-by-Step Student Instructions

1. **Open the project repository** in your terminal or IDE:
   ```bash
   cd "beginner-projects-main/AI-ML Beginners/projects/04_spam_detective"
   ```
2. **Open `main.py`** and inspect the docstring on lines 1-8. Notice how the project framing directly describes a two-class text problem.
3. **Identify the two target classes**: Confirm in your mind that every message belongs to either `"spam"` or `"ham"`.
4. **Determine the task type**: Verify why this is binary classification rather than multi-class classification or regression.
5. **Consider the error trade-off**: Ask yourself what safeguards an enterprise email filter would require before moving an email to quarantine.

## Expected Output or Observable Behaviour

When running `main.py`, the program prints a clear banner and demonstrates binary classification in action:

```
============================================================
SPAM DETECTIVE
============================================================
Accuracy: 100.0%

              precision    recall  f1-score   support

         ham       1.00      1.00      1.00        10
        spam       1.00      1.00      1.00        10
```

Notice that the classification report explicitly evaluates performance across two distinct classes: `ham` and `spam`.

## Practical Exercises

- **Exercise 1.1:** Classify the following three messages as `ham` or `spam` based on intuition:
  1. "Hey Mom, arriving at 6:30 tonight."
  2. "Exclusive deal! Claim $500 gift card immediately by texting WIN."
  3. "Your weekly git repository summary is ready to view."
- **Exercise 1.2:** Explain why treating spam detection as a continuous regression problem (e.g. predicting a continuous float from 0.0 to 100.0 without thresholding) is inappropriate for deciding whether to drop or route a message.
- **Exercise 1.3:** Suppose an automated spam filter achieves 99% accuracy on a dataset where 99% of messages are ham and 1% are spam. If it simply labels every single message as ham, what is its spam recall? Explain why accuracy alone is deceptive.
- **Exercise 1.4:** In your own words, describe a real-world scenario where a false positive caused a serious operational failure.

## Common Mistakes and Debugging

| Mistake | Why it happens | Correction |
|---|---|---|
| Confusing "ham" with spam | Assuming "ham" is an acronym or synonym for junk mail | Remember that "ham" universally denotes legitimate, desired messages. |
| Treating spam detection as regression | Thinking the model outputs a continuous sales or price quantity | Frame the target as discrete categories: `"spam"` or `"ham"`. |
| Assuming False Positives and False Negatives are equal | Ignoring the real-world impact on end users | Always prioritize minimizing false positives when filtering user communications. |
| Expecting ML to read text like a human | Assuming the computer understands emotion or semantics directly | Recognize that text must first be converted into numerical features (vectors). |

## Best Practices and Security Considerations

- **User Quarantine Folders:** Never permanently delete suspected spam automatically; route messages to a "Spam" or "Junk" folder so users can recover false positives.
- **Privacy by Design:** Spam filtering algorithms process private, sensitive user messages. Processing must happen within secure boundaries without unauthorized logging of personal details.
- **Adversarial Awareness:** Spammers actively study filter behavior and modify message text to evade detection (e.g. using homoglyphs, zero-width spaces, or obfuscated URLs).

## Summary

Spam detection is the process of identifying unsolicited, bulk, or malicious messages. In machine learning, it is framed as a supervised binary classification task where input text is mapped to one of two target labels: `"ham"` (legitimate) or `"spam"` (unwanted). Crucially, the cost of errors is asymmetric: false positives (blocking legitimate emails) cause far more disruption than false negatives (letting spam slip through).

## Knowledge-check Questions

1. What does the term "ham" signify in email filtering and machine learning?
2. Why is spam detection classified as a binary classification problem rather than regression?
3. Which error type is typically more damaging in an email inbox: a false positive or a false negative? Why?
4. In `main.py`, what are the two target labels evaluated in the classification report?
5. How does the docstring of `main.py` describe the learning process of the model?

## References

- RFC 5322 - Internet Message Format: https://datatracker.ietf.org/doc/html/rfc5322
- scikit-learn Classification Guide: https://scikit-learn.org/stable/supervised_learning.html#classification
- History of Spam in Computing: https://en.wikipedia.org/wiki/Spamming
