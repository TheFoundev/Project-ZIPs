# Lesson 02: Representing Text as Numbers: The Bag-of-Words Model

**Lesson ID:** lesson-02
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain why machine learning algorithms cannot consume raw text strings directly
- Describe the mechanism of tokenization and vocabulary construction
- Illustrate the Bag-of-Words (BoW) text representation with a concrete example
- Identify the trade-offs of the BoW model, including the loss of word order and grammar
- Explain why word frequency distributions remain highly effective for spam detection

## Prerequisites
- Completion of Lesson 01 (understanding spam vs ham)
- Familiarity with basic Python strings and dictionary data structures

## Concept Explanation

### The Numerical Requirement of Machine Learning
All machine learning algorithms—whether linear models, decision trees, or neural networks—are mathematical functions. They perform linear algebra: dot products, matrix multiplications, and probability calculations over vectors of real numbers.

When you pass a raw sentence like `"Congratulations! You have won a free vacation."` to a model, the algorithm cannot natively compute the mathematical gradient or probability of a string. Before any training or classification can occur, unstructured text must be converted into a structured numerical matrix. This fundamental step is known as **feature extraction** or **text vectorization**.

### The Bag-of-Words (BoW) Model
The most established and intuitive representation for text classification is the **Bag-of-Words (BoW)** model.

Imagine taking a sentence, cutting every individual word out onto a slip of paper, and tossing all the slips into a bag. In the bag:
1. **Word order is completely lost:** `"dog bites man"` and `"man bites dog"` result in the exact same collection of words.
2. **Grammar and syntax are discarded:** Verb tenses, punctuation, and structural relationships disappear.
3. **Word counts are preserved:** How many times each word appears is recorded.

### How BoW Works: Three Core Steps
1. **Tokenization:** Breaking raw text into individual terms or words called **tokens** (e.g., splitting by whitespace and stripping punctuation).
2. **Vocabulary Building:** Collecting every unique token found across the entire collection of documents (the **corpus**) and assigning each a fixed column index.
3. **Encoding (Counting):** Representing each document as a vector whose elements count the frequency of each vocabulary word in that document.

### Why BoW Works Remarkably Well for Spam Detection
Despite discarding grammar and word order, BoW is exceptionally powerful for spam detection. Why? Because spam messages and legitimate communications draw from dramatically different vocabularies:
- Spam text disproportionately concentrates words such as `"guaranteed"`, `"winner"`, `"free"`, `"cash"`, `"urgent"`, `"unpaid"`, and `"claim"`.
- Legitimate work or school messages disproportionately concentrate terms such as `"meeting"`, `"notes"`, `"library"`, `"friday"`, `"attached"`, and `"session"`.

Simply measuring which vocabulary words are present—and how frequently they occur—provides overwhelming statistical evidence to determine whether an email is spam or ham.

## Relevant Code (from main.py, lines 18 and 44-48)

```python
from sklearn.feature_extraction.text import CountVectorizer

# ...

    model = Pipeline(
        [
            ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
            ("classifier", MultinomialNB()),
        ]
    )
```

### Code Explanation
- **Line 18:** Imports `CountVectorizer` from scikit-learn's `feature_extraction.text` module. `CountVectorizer` is scikit-learn's standard tool for implementing the Bag-of-Words representation.
- **Line 46:** Instantiates `CountVectorizer` as the first stage of the pipeline. It automatically handles lowercasing, tokenization, stop word filtering, and converting raw text series into a numeric term-document matrix.

## Worked Example

Suppose our training corpus contains just two short messages:
- **Message 1 (Spam):** `"Buy software today software"`
- **Message 2 (Ham):** `"Read book today"`

Let us trace how Bag-of-Words converts these messages into numbers:

**Step 1: Build the unique vocabulary** (alphabetical order):
```
Index 0: "book"
Index 1: "buy"
Index 2: "read"
Index 3: "software"
Index 4: "today"
```
Vocabulary size = 5 unique terms.

**Step 2: Construct the count vectors:**
- For Message 1 (`"Buy software today software"`):
  - "book" appears 0 times
  - "buy" appears 1 time
  - "read" appears 0 times
  - "software" appears 2 times
  - "today" appears 1 time
  - **Vector 1:** `[0, 1, 0, 2, 1]`

- For Message 2 (`"Read book today"`):
  - "book" appears 1 time
  - "buy" appears 0 times
  - "read" appears 1 time
  - "software" appears 0 times
  - "today" appears 1 time
  - **Vector 2:** `[1, 0, 1, 0, 1]`

Now each document is a mathematical vector in $\mathbb{R}^5$, ready to be processed by a classifier.

## Step-by-Step Student Instructions

1. **Open a Python interactive shell** or terminal:
   ```bash
   python3
   ```
2. **Import CountVectorizer** and test a mini-corpus:
   ```python
   from sklearn.feature_extraction.text import CountVectorizer
   corpus = ["Buy software today software", "Read book today"]
   vec = CountVectorizer()
   X = vec.fit_transform(corpus)
   ```
3. **Inspect the learned feature names (vocabulary):**
   ```python
   print(vec.get_feature_names_out())
   # Output: ['book' 'buy' 'read' 'software' 'today']
   ```
4. **Convert the sparse count matrix to a dense array:**
   ```python
   print(X.toarray())
   # Output:
   # [[0 1 0 2 1]
   #  [1 0 1 0 1]]
   ```
5. **Notice how "software" has count 2** in the first row.

## Expected Output or Observable Behaviour

The output array matches our manual worked example:
```
['book' 'buy' 'read' 'software' 'today']
[[0 1 0 2 1]
 [1 0 1 0 1]]
```
This confirms that `CountVectorizer` converts human sentences into exact word counts mapped to vocabulary columns.

## Practical Exercises

- **Exercise 2.1:** What is the vector representation of the message `"Buy book software"` using the 5-word vocabulary above?
- **Exercise 2.2:** Give an example of two English sentences with completely opposite meanings that produce identical Bag-of-Words count vectors.
- **Exercise 2.3:** If a new message contains the word `"microchip"`, which was never seen in the training vocabulary, what happens to that word in the count vector?
- **Exercise 2.4:** Why does `CountVectorizer` default to converting all characters to lowercase before building its vocabulary?

## Common Mistakes and Debugging

| Mistake | Why it happens | Correction |
|---|---|---|
| Feeding raw strings directly to `MultinomialNB` | Forgetting that machine learning requires numeric inputs | Always pass text through `CountVectorizer` before the classifier. |
| Expecting punctuation to form its own features | By default, `CountVectorizer` strips punctuation characters | Note that standard tokenization isolates alphanumeric words. |
| Assuming word order is retained | Believing the model knows which word came first | Remember BoW treats a document as an unordered bag of counts. |
| Forgetting to call `toarray()` when printing | Printing `X` outputs a scipy sparse matrix summary | Use `X.toarray()` to inspect the full matrix in small examples. |

## Best Practices and Security Considerations

- **Sparse Matrix Storage:** In real datasets with 20,000+ words, most words do not appear in any single message. Always keep vectors in sparse format (`scipy.sparse.csr_matrix`) to save gigabytes of RAM.
- **Handling Out-of-Vocabulary (OOV) Terms:** Recognize that words absent from the training vocabulary are simply ignored at inference time.
- **Data Normalization:** Consistent tokenization (lowercasing, punctuation stripping) prevents redundant vocabulary entries like `"Buy"` and `"buy"`.

## Summary

The Bag-of-Words model transforms unstructured text into numerical count vectors. It constructs a vocabulary of all unique words in the corpus and counts term frequencies for each message. While BoW discards word order and grammatical structure, its frequency representations are exceptionally effective for spam classification because spam and legitimate messages use distinctly different vocabularies.

## Knowledge-check Questions

1. Why must raw text be vectorized before being passed to an estimator like `MultinomialNB`?
2. What are the three primary steps executed by the Bag-of-Words model?
3. What critical grammatical property of language is discarded by the Bag-of-Words representation?
4. If a word in a new test message was never present in the training set vocabulary, what is its count in the resulting vector?
5. Which scikit-learn class implements the Bag-of-Words counting mechanism?

## References

- scikit-learn CountVectorizer Reference: https://scikit-learn.org/stable/modules/generated/sklearn.feature_extraction.text.CountVectorizer.html
- Feature Extraction in scikit-learn: https://scikit-learn.org/stable/modules/feature_extraction.html#text-feature-extraction
- Jurafsky & Martin - Speech and Language Processing (BoW): https://web.stanford.edu/~jurafsky/slp3/
