# Lesson 03: Why Natural Language Processing Meets Machine Learning

**Lesson ID:** lesson-03
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Contrast heuristic rule-based filtering with statistical machine learning approaches
- Explain the brittle nature of keyword blacklists and regular expressions
- Describe how spammers evade naive rule-based filters
- Explain how machine learning combines hundreds of subtle vocabulary clues simultaneously
- Understand why statistical NLP models generalize effectively to previously unseen text

## Prerequisites
- Completion of Lesson 01 (Spam problem) and Lesson 02 (Bag-of-Words representation)
- Basic understanding of conditional probability or statistical weighting

## Concept Explanation

### The Naive Rule-Based Approach: Keyword Blocklists
When software developers first encountered spam in the 1990s, the intuitive response was to write manual heuristic rules:
```python
# A fragile, heuristic rule-based filter
if "free" in message.lower() or "win" in message.lower() or "cash" in message.lower():
    mark_as_spam(message)
```

While simple, this naive approach fails immediately in production due to two critical flaws:
1. **Catastrophic False Positives:** A legitimate colleague emailing `"Are you free for lunch tomorrow?"` or a teacher sending `"Let's see who will win the science fair"` gets flagged as spam. The word `"free"` is a normal English word; banning it breaks communication.
2. **Easy Adversarial Evasion:** As soon as spammers realize certain words are blocked, they easily manipulate the text:
   - Modifying spelling: `"F-R-E-E"`, `"Fr33"`, `"w1nner"`, `"c@sh"`
   - Adding noise words or invisible characters
   - Using homoglyphs (substituting Cyrillic 'а' for Latin 'a')

Maintaining thousands of fragile regular expressions becomes an impossible game of whack-a-mole.

### Why Machine Learning is Superior: Statistical Evidence Accumulation
Rather than making a binary YES/NO decision based on a single banned word, statistical machine learning models (like Naive Bayes) treat text classification as **evidence accumulation**.

In machine learning:
- Every word in the vocabulary is assigned a mathematical weight or probability score based on historical data.
- The word `"free"` might appear in 70% of spam messages and 15% of legitimate messages. This means `"free"` increases the probability of spam, but on its own, it is not sufficient to condemn the message.
- The classifier evaluates all words in combination:
  - If a message contains `"free"` + `"lunch"` + `"tomorrow"`, the strong presence of `"lunch"` and `"tomorrow"` pulls the probability heavily toward **ham**.
  - If a message contains `"free"` + `"smartphone"` + `"claim"` + `"prize"`, all four clues point consistently toward **spam**, driving the spam probability to nearly 100%.

### Adaptation and Generalization
Machine learning algorithms learn directly from labeled training data. When spammers invent new campaigns (e.g. cryptocurrency scams or fake delivery notices), engineers do not need to rewrite complex code. They simply feed recent labeled examples into the pipeline, call `model.fit()`, and the algorithm recalculates its statistical weights automatically.

## Relevant Code (from main.py, lines 44-50)

```python
    model = Pipeline(
        [
            ("vectorizer", CountVectorizer(stop_words="english", ngram_range=(1, 2))),
            ("classifier", MultinomialNB()),
        ]
    )
    model.fit(X_train, y_train)
```

### Code Explanation
- **Lines 44-49:** Defines a scikit-learn `Pipeline` that chains together NLP text vectorization (`CountVectorizer`) and statistical learning (`MultinomialNB`).
- **Line 50:** `model.fit(X_train, y_train)` executes the entire learning process. In milliseconds, the computer scans all training messages, counts token frequencies for both spam and ham, and calculates class-conditional probabilities for hundreds of vocabulary terms.

## Worked Example

Consider how a rule-based filter versus a machine learning filter evaluates the message:
`"Can we meet at the library for the free tutoring session?"`

**1. Rule-Based Filter:**
- Check: Does it contain `"free"`? Yes!
- Verdict: **SPAM** (False Positive!). The student misses the tutoring session notice.

**2. Machine Learning Filter (Naive Bayes):**
- Word clues extracted: `['meet', 'library', 'free', 'tutoring', 'session']`
- Probabilities evaluated:
  - `P("meet" | ham)` = High, `P("meet" | spam)` = Low
  - `P("library" | ham)` = Very High, `P("library" | spam)` = Near Zero
  - `P("free" | ham)` = Moderate, `P("free" | spam)` = High
  - `P("tutoring" | ham)` = High, `P("tutoring" | spam)` = Near Zero
  - `P("session" | ham)` = High, `P("session" | spam)` = Low
- Combined Bayesian posterior: $P(\text{ham} \mid \text{words}) \approx 99.4\%$.
- Verdict: **HAM** (Delivered to inbox correctly!).

## Step-by-Step Student Instructions

1. **Review line 44 in `main.py`**: Note how the pipeline cleanly separates vectorization from classification.
2. **Observe how `model.fit(X_train, y_train)` works**: The model doesn't store hardcoded rules; it computes word frequency distributions.
3. **Compare this to hardcoded if-statements**: If you had to write `if "prize" in msg:` for 80 messages, you would need dozens of rules that still fail on subtle cases.
4. **Notice how `CountVectorizer` handles stop words**: Common words like `"the"`, `"at"`, `"for"` are automatically filtered so they don't drown out informative clues.

## Expected Output or Observable Behaviour

Running `main.py` demonstrates the ability of the statistical model to handle nuanced sentences correctly:
```
New message predictions:
  spam (100%) -> Congratulations! You won a free smartphone. Click now to claim your prize.
  ham  (99%) -> Can we meet at the library at 4 pm to review the project?
  spam (98%) -> URGENT: verify your password immediately or your account will be suspended.
  ham  (88%) -> Thanks for sending the notes. I will read them tonight.
```
Notice that the model classifies message #2 as 99% confident `ham` despite common conversational words, and message #1 as 100% `spam`.

## Practical Exercises

- **Exercise 3.1:** Write down a legitimate sentence you might send to a friend that contains the word `"cash"`. Why would a simple `if "cash" in message:` rule fail?
- **Exercise 3.2:** What is the fundamental difference between how a human expert crafts a regex rule and how `MultinomialNB` learns from data?
- **Exercise 3.3:** If a spammer alters `"prize"` to `"pr!ze"`, how might standard whitespace tokenization be affected, and how can preprocessors address this?
- **Exercise 3.4:** Why does an ML filter get smarter when you retrain it on a larger dataset of verified emails?

## Common Mistakes and Debugging

| Mistake | Why it happens | Correction |
|---|---|---|
| Relying on manual keyword blacklists | Assuming humans can anticipate all spam variations | Use machine learning to learn probabilistic weights across the entire vocabulary. |
| Thinking ML is 100% immune to tricks | Forgetting that spammers use adversarial perturbation | Understand that ML filters require continuous retraining and text normalization. |
| Forgetting that words have context | Assuming the presence of a single word dictates the label | ML weighs all words together; strong legitimate words can override a spam word. |
| Modifying raw text manually inside models | Trying to write custom regex inside scikit-learn estimators | Use standard preprocessors and tokenizers provided by scikit-learn. |

## Best Practices and Security Considerations

- **Continuous Retraining:** Email spam patterns shift seasonally (e.g. holiday retail scams, tax season phishing). Models must be retrained on fresh labeled samples periodically.
- **Ensemble Filtering:** Modern industrial systems combine Naive Bayes text models with sender reputation (SPF/DKIM/DMARC), IP lookups, and link analysis.
- **Explainability:** When an email is quarantined, it is valuable to log which token features contributed most heavily to the decision.

## Summary

Simple rule-based filters and keyword blacklists are brittle, generate frequent false positives on normal conversation, and are easily bypassed by spammers. Combining Natural Language Processing with statistical machine learning enables filters to treat classification as probabilistic evidence accumulation. By evaluating the collective weight of all tokens simultaneously, models generalize robustly to new messages and adapt seamlessly to evolving tactics.

## Knowledge-check Questions

1. Why do simple keyword blacklists (e.g. banning `"free"`) lead to unacceptable false positives?
2. How does statistical machine learning treat words differently than a hardcoded if-statement?
3. What happens when a message contains one spammy word (e.g. `"free"`) alongside several strong legitimate words (e.g. `"library"`, `"study"`, `"homework"`)?
4. What method in scikit-learn trains the model to learn statistical token weights from labeled data?
5. Why is machine learning easier to maintain over time than thousands of handwritten regex rules?

## References

- Paul Graham - A Plan for Spam (Pioneering Essay on Bayesian Spam Filtering): http://www.paulgraham.com/spam.html
- scikit-learn Pipeline Guide: https://scikit-learn.org/stable/modules/compose.html#pipeline
- Stanford CS224N - NLP with Machine Learning: https://web.stanford.edu/class/cs224n/
