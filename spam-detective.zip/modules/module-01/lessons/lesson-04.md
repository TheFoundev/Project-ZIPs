# Lesson 04: Anatomy of the Spam Detective Project

**Lesson ID:** lesson-04
**Module:** module-01
**Duration:** 15 minutes

## Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Map out the end-to-end architecture and control flow of `main.py`
- Identify all input files, external dependencies, and output artifacts of the project
- Trace the lifecycle of data from raw CSV rows through vectorization, model training, evaluation, and chart generation
- Explain the role and signature of the `top_words()` helper function
- Navigate the project directory structure with confidence

## Prerequisites
- Completion of Lessons 01, 02, and 03
- Basic familiarity with Python file handling and module imports

## Concept Explanation

### The Spam Detective Workflow
The **Spam Detective** project is a clean, self-contained implementation of an industrial text classification system. In just 117 lines of Python, it demonstrates every phase of a professional machine learning workflow:

```
[ data/messages.csv ]
         │
         ▼
[ pd.read_csv() ] ───> 80 messages (40 spam, 40 ham)
         │
         ▼
[ train_test_split() ] ───> 60 Train (30 spam, 30 ham) + 20 Test (10 spam, 10 ham)
         │
         ▼
[ Pipeline: CountVectorizer + MultinomialNB ]
         │
         ▼
[ model.fit() & model.predict() ]
         │
   ┌─────┴─────────────────────────────────────┐
   ▼                                           ▼
[ Quantitative Evaluation ]           [ Qualitative Inspection ]
- Accuracy (100%)                     - top_words() helper
- Classification Report               - 4 realistic test messages
- Confusion Matrix                    - Probability confidences
   │                                           │
   ▼                                           ▼
[ outputs/confusion_matrix.png ]      [ outputs/top_words.png ]
[ outputs/predictions.txt ]
```

### Directory Structure
The project lives in a clean directory layout:
```
04_spam_detective/
├── main.py                  # The complete executable pipeline
├── data/
│   └── messages.csv         # 80 labeled text messages (text, label)
└── outputs/                 # Automatically created by main.py
    ├── top_words.png        # Dual horizontal bar chart of spam vs ham clues
    ├── confusion_matrix.png # Confusion matrix heatmap
    └── predictions.txt      # Logged metrics, report, and predictions
```

### Path Independence with `pathlib`
Notice lines 24-27 in `main.py`:
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)
```
Using Python's modern `pathlib.Path` ensures that the script executes cleanly regardless of whether you run it from the root repository directory, from a subfolder, or on Windows, macOS, or Linux. The `mkdir(exist_ok=True)` call guarantees that the output folder exists before saving figures or text logs.

### The `top_words()` Helper Function
Unlike black-box models, Naive Bayes is completely transparent. Lines 30-35 define the `top_words()` helper:
```python
def top_words(model: Pipeline, class_index: int, n: int = 10) -> list[str]:
    vectorizer = model.named_steps["vectorizer"]
    classifier = model.named_steps["classifier"]
    names = vectorizer.get_feature_names_out()
    scores = classifier.feature_log_prob_[class_index] - classifier.feature_log_prob_[1 - class_index]
    return list(names[np.argsort(scores)[-n:][::-1]])
```
This function unpacks the pipeline, inspects the learned log probabilities of every word for class $A$ versus class $B$, computes their difference (the **log-odds ratio**), and sorts them to find the top $n$ most discriminative keywords that distinguish spam from ham.

## Relevant Code (from main.py, lines 24-35 and 105-112)

```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)


def top_words(model: Pipeline, class_index: int, n: int = 10) -> list[str]:
    vectorizer = model.named_steps["vectorizer"]
    classifier = model.named_steps["classifier"]
    names = vectorizer.get_feature_names_out()
    scores = classifier.feature_log_prob_[class_index] - classifier.feature_log_prob_[1 - class_index]
    return list(names[np.argsort(scores)[-n:][::-1]])

# ... (inside main)
    with open(OUT / "predictions.txt", "w", encoding="utf-8") as handle:
        handle.write(f"accuracy: {accuracy:.4f}\n\n")
        handle.write(classification_report(y_test, predictions, zero_division=0))
        handle.write("\nNew messages:\n")
        for message, prediction, probability in zip(new_messages, new_predictions, probabilities):
            handle.write(f"{prediction} ({probability[classes.index(prediction)]:.2%}) -> {message}\n")
```

### Code Explanation
- **Lines 24-27:** Resolves filesystem paths safely and creates `outputs/` dynamically.
- **Lines 30-35:** Extracts model interpretability metrics via the pipeline's `named_steps` dictionary.
- **Lines 105-111:** Serializes all evaluation metrics and test inferences to `outputs/predictions.txt` with UTF-8 encoding.

## Worked Example

Let us trace how the project processes an incoming new test message:
Message: `"URGENT: verify your password immediately or your account will be suspended."`

1. **Step 1:** Vectorizer converts the sentence into an n-gram count vector using the 190 learned features. Words like `"urgent"`, `"verify"`, `"password"`, `"suspended"` are identified.
2. **Step 2:** `MultinomialNB` computes log-probabilities:
   - For spam: large positive contributions from `"urgent"`, `"verify"`, `"password"`, `"suspended"`.
   - For ham: near zero probability for those terms.
3. **Step 3:** Softmax / probability normalization:
   - Spam probability: **98.36%**
   - Ham probability: **1.64%**
4. **Step 4:** Decision rule: Since $98.36\% > 50\%$, classify as `"spam"`.
5. **Step 5:** Terminal & file output:
   `spam (98%) -> URGENT: verify your password immediately or your account will be suspended.`

## Step-by-Step Student Instructions

1. **Open `main.py` in your editor** and locate the three primary functional blocks:
   - Setup & helper function (lines 1-36)
   - Pipeline definition, fitting, and evaluation (lines 38-80)
   - Visualization and file exports (lines 82-117)
2. **Examine lines 60-65**: Observe how the script extracts `classes_` from `classifier` to identify whether index 0 is `"ham"` or `"spam"`.
3. **Locate the 4 test messages** on lines 68-73.
4. **Run `python main.py`**:
   Verify that all three files are generated in `outputs/`:
   - `outputs/top_words.png`
   - `outputs/confusion_matrix.png`
   - `outputs/predictions.txt`

## Expected Output or Observable Behaviour

Executing `python main.py` produces console output ending with:
```
Top spam clues: buy, price, 50 buy, price guaranteed, 50, order, lowest, guaranteed, lowest price, risk
Top normal clues: meeting, today class, send notes, start, ll, tomorrow, ll minutes, minutes late, minutes, meeting lunch

New message predictions:
  spam (100%) -> Congratulations! You won a free smartphone. Click now to claim your prize.
  ham  (99%) -> Can we meet at the library at 4 pm to review the project?
  spam (98%) -> URGENT: verify your password immediately or your account will be suspended.
  ham  (88%) -> Thanks for sending the notes. I will read them tonight.

Saved: outputs/top_words.png, outputs/confusion_matrix.png, outputs/predictions.txt
Try this: add five of your own spam and normal messages, then retrain.
```

## Practical Exercises

- **Exercise 4.1:** What are the three artifacts written into the `outputs/` folder by `main.py`?
- **Exercise 4.2:** In line 27, what would happen if `OUT.mkdir()` were called without `exist_ok=True` on a second run of the script?
- **Exercise 4.3:** Look at lines 60-63 in `main.py`. Why is `classes.index("spam")` used instead of assuming spam is always at index 1?
- **Exercise 4.4:** What is the purpose of `matplotlib.use("Agg")` on line 14?

## Common Mistakes and Debugging

| Mistake | Why it happens | Correction |
|---|---|---|
| Hardcoding string paths like `"data/messages.csv"` | Fails when running script from a different current directory | Always use `Path(__file__).resolve().parent / "data"` |
| Forgetting `exist_ok=True` on `mkdir()` | Crashes with `FileExistsError` on subsequent runs | Always pass `exist_ok=True` when making output directories |
| Assuming class indices are fixed | Assuming spam is always 0 or always 1 | Query `model.named_steps["classifier"].classes_` dynamically |
| Missing `plt.close(fig)` | Memory leaks when saving multiple matplotlib figures | Always close figures after saving with `plt.close(fig)` |

## Best Practices and Security Considerations

- **Encoding Safety:** Always specify `encoding="utf-8"` when reading or writing text files (`open(OUT / "predictions.txt", "w", encoding="utf-8")`) to prevent crashes on non-UTF8 OS defaults.
- **Headless Visualization:** In automated CI/CD pipelines and servers without display servers, setting `matplotlib.use("Agg")` prevents GUI errors.
- **Reproducibility:** Hardcode a known `random_state` (e.g. 42) in train/test splits so evaluations remain reproducible.

## Summary

The Spam Detective project encapsulates a complete machine learning pipeline: reading CSV data, splitting into stratified train/test sets, vectorizing text with CountVectorizer, training a Multinomial Naive Bayes classifier in an sklearn Pipeline, extracting top discriminative keywords with `top_words()`, evaluating on test messages, and generating publication-ready charts and audit logs.

## Knowledge-check Questions

1. Which Python standard library module is used to construct platform-independent filesystem paths in `main.py`?
2. What are the two stages combined inside the project's scikit-learn `Pipeline`?
3. What mathematical difference does `top_words()` compute to rank the most discriminative words for a class?
4. What three artifact files are saved in the `outputs/` directory upon script completion?
5. Why is `matplotlib.use("Agg")` invoked before importing `matplotlib.pyplot`?

## References

- Python pathlib documentation: https://docs.python.org/3/library/pathlib.html
- scikit-learn Pipeline named_steps: https://scikit-learn.org/stable/modules/generated/sklearn.pipeline.Pipeline.html
- Matplotlib Non-Interactive Backends: https://matplotlib.org/stable/users/explain/backends.html
