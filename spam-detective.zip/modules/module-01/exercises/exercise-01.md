# Module 1 Exercises: Project Overview & Problem Understanding

## Exercise 1.1: Problem Framing and Asymmetric Costs (15 min)
**Objective:** Define the spam detection challenge as a binary classification problem and analyze the asymmetric operational impact of classification errors.

**Problem Statement:** 
A university IT department is deploying an automated email filter to protect 20,000 students and faculty. You must document why this task is binary classification (rather than regression or clustering) and explain the real-world operational trade-off between False Positives and False Negatives.

**Requirements:**
1. Formulate the machine learning task: define the input $X$ and discrete target $y$
2. Define the two classes ("spam" vs "ham") and state their standard definitions in NLP
3. Compare the practical consequences of a False Positive (legitimate message flagged as spam) versus a False Negative (spam leaking to inbox)
4. Explain why spam filters typically tune their threshold to favor high precision on spam

**Constraints:** 
Base your analysis on the core definitions established in Module 1, Lesson 1 and 4. Keep explanations clear, rigorous, and professional.

**Expected Behaviour:** 
A structured written report (3-4 paragraphs) answering all four requirements with concrete messaging examples.

**Acceptance Criteria:**
- [ ] Task is explicitly identified as supervised binary classification
- [ ] Target classes "spam" and "ham" are clearly defined
- [ ] Comparison clearly shows False Positives have a significantly higher operational cost than False Negatives
- [ ] The justification for prioritizing spam precision is articulated correctly

**Hints:**
- Think about what happens if an email containing a scholarship offer or medical alert is discarded vs an unwanted promotional flyer appearing in the inbox.
- Precision measures: "Of all emails marked as spam, what fraction really was spam?"

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes

---

## Exercise 1.2: Manual Bag-of-Words Vector Calculation (15 min)
**Objective:** Manually compute vocabulary extraction and term frequency count vectors using the Bag-of-Words model.

**Problem Statement:** 
Given a tiny toy corpus of three short communications, construct the unified vocabulary and determine the exact Bag-of-Words count vector for each document.

**Corpus:**
- Doc 1: `"win cash prize win"`
- Doc 2: `"urgent meeting tomorrow"`
- Doc 3: `"prize for meeting win"`

**Requirements:**
1. Extract the sorted unique vocabulary of tokens (lowercase, ignoring punctuation, including single words)
2. State the vocabulary size (number of features)
3. Construct the count matrix where rows represent documents and columns represent vocabulary words in alphabetical order
4. Explain what information from the original sentences was lost during this transformation

**Constraints:** 
Do not use automated code for the initial calculation; perform the token counting by hand first, then verify using Python's `CountVectorizer` if desired.

**Expected Behaviour:** 
A clean markdown table showing the vocabulary index mapping and the $3 \times V$ count matrix.

**Acceptance Criteria:**
- [ ] Vocabulary correctly lists all unique words in alphabetical order
- [ ] Count vectors for all three documents match the exact term frequencies
- [ ] Word order and grammatical structure loss is clearly explained
- [ ] Demonstrates understanding of how text strings become numerical rows

**Hints:**
- In Doc 1, the token `"win"` appears twice.
- If a word does not appear in a document, its count is 0.

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 1.3: Rule-Based vs Machine Learning Case Analysis (15 min)
**Objective:** Compare the failure modes of heuristic keyword blocklists against statistical evidence accumulation.

**Problem Statement:** 
A developer attempts to build a spam filter by creating a list of 5 banned words: `["free", "winner", "cash", "urgent", "click"]`. Analyze how this rule-based filter performs on three realistic messages and contrast it with how a trained Naive Bayes classifier behaves.

**Test Messages:**
1. `"Are you free to click the link and review the urgent project slides?"`
2. `"Winner! Claim your free gift card worth $100. Act fast!"`
3. `"F-R-E-E software download available today only."`

**Requirements:**
1. State the verdict of the naive rule-based filter for each message
2. Identify which messages are false positives, false negatives, or true positives under the rule-based approach
3. Explain how `MultinomialNB` uses multiple token probabilities (e.g., `"project"`, `"review"`, `"slides"`) to avoid false positives
4. Explain how spammers exploit rule-based keyword filters and how ML models mitigate this

**Constraints:** 
Use the principles taught in Lesson 03.

**Expected Behaviour:** 
A comparative breakdown evaluating both approaches across all three test cases.

**Acceptance Criteria:**
- [ ] Rule-based verdicts correctly identified for all 3 messages
- [ ] Identifies Message 1 as a severe False Positive under the rule-based filter
- [ ] Identifies Message 3 as a False Negative evasion under strict word-matching rules
- [ ] Explains how statistical co-occurrence enables ML to classify Message 1 as legitimate

**Hints:**
- Message 1 contains three of the banned words (`"free"`, `"click"`, `"urgent"`), yet is 100% legitimate work communication!

**Difficulty:** Intermediate
**Estimated Completion Time:** 15 minutes

---

## Exercise 1.4: Codebase Architecture & Output Verification (15 min)
**Objective:** Trace the execution pipeline of `main.py` and inspect its generated artifacts.

**Problem Statement:** 
Run the provided `main.py` script from the terminal and inspect the structure of its inputs and generated outputs.

**Requirements:**
1. Navigate to `beginner-projects-main/AI-ML Beginners/projects/04_spam_detective/` and execute `python main.py`
2. Verify that the `outputs/` directory is created
3. Inspect `outputs/predictions.txt` and verify the recorded accuracy and test predictions
4. Locate the lines in `main.py` where:
   - File paths are configured (`BASE`, `DATA`, `OUT`)
   - The pipeline is trained
   - The artifacts are saved to disk

**Constraints:** 
Execute the actual script in your terminal environment.

**Expected Behaviour:** 
Successful execution with console output matching the reference specification and all three output files generated.

**Acceptance Criteria:**
- [ ] Script executes with exit code 0
- [ ] `outputs/top_words.png`, `outputs/confusion_matrix.png`, and `outputs/predictions.txt` verified present
- [ ] Line numbers in `main.py` for path setup (lines 24-27), model training (line 50), and file output (lines 92, 102, 105) documented correctly

**Hints:**
- Use `cat outputs/predictions.txt` or open it in your editor to inspect contents.

**Difficulty:** Basic
**Estimated Completion Time:** 15 minutes
