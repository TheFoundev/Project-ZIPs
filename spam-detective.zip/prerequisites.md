# Prerequisites

## Skills Required
- Basic Python syntax (imports, functions, variables, lists, string formatting)
- Reading CSV files with pandas
- Basic understanding of classification (predicting discrete categories rather than continuous numbers)
- Basic probability concepts (likelihood, conditional probability)
- Familiarity with the terminal or command line

## Tools Required
- Python 3.7+
- pip
- Code editor (VS Code recommended)

## Packages
- pandas
- numpy
- matplotlib
- scikit-learn

## Knowledge to Review
- What is binary text classification?
- How does the Bag-of-Words model convert text into numerical feature vectors?
- What are stop words and n-grams?
- Difference between Precision and Recall in classification
