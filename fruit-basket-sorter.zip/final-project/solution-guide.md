# Mentor Solution Guide: The Fruit Basket Sorter

## Overview

This guide provides mentors, instructors, and code reviewers with the complete reference solution, checkpoint validation criteria, common student pitfalls, and grading benchmarks for the Fruit Basket Sorter project.

The reference solution adheres strictly to `main.py`, demonstrating production-grade scikit-learn patterns: non-interactive backend configuration, defensive path handling, stratified dataset splitting, leakage-free pipeline composition with `StandardScaler` and `KNeighborsClassifier`, comprehensive multi-class evaluation, multi-dimensional inference, and publication-ready diagnostic visualizations.

---

## Complete Reference Solution (`main.py`)

```python
"""Project 05: The Fruit Basket Sorter (K-Nearest Neighbours).

Run:
    python main.py

Fruits are described by sweetness, weight, size, and colour. The model
classifies a mystery fruit by finding the most similar training examples.
"""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)

FEATURES = ["sweetness", "weight_g", "size_cm", "color_score"]
COLOURS = {"apple": "#c0392b", "banana": "#f1c40f", "orange": "#e67e22"}


def main() -> None:
    df = pd.read_csv(DATA / "fruits.csv")
    X = df[FEATURES]
    y = df["fruit"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )

    model = Pipeline(
        [
            ("scale", StandardScaler()),
            ("knn", KNeighborsClassifier(n_neighbors=5)),
        ]
    )
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)

    print("=" * 60)
    print("THE FRUIT BASKET SORTER")
    print("=" * 60)
    print(f"Accuracy: {accuracy:.1%}\n")
    print(classification_report(y_test, predictions, zero_division=0))

    mystery = pd.DataFrame(
        [
            {
                "sweetness": 7.2,
                "weight_g": 170,
                "size_cm": 8.5,
                "color_score": 8.0,
            }
        ]
    )
    mystery_prediction = model.predict(mystery)[0]
    mystery_probability = model.predict_proba(mystery).max()
    print(f"Mystery fruit -> {mystery_prediction} ({mystery_probability:.0%} confident)")

    # ---- Scatter plot --------------------------------------------------
    fig, ax = plt.subplots(figsize=(7.5, 5.5))
    for fruit, group in df.groupby("fruit"):
        ax.scatter(
            group["sweetness"],
            group["weight_g"],
            s=60,
            alpha=0.8,
            label=fruit,
            color=COLOURS[fruit],
        )
    ax.scatter(
        mystery["sweetness"],
        mystery["weight_g"],
        marker="*",
        s=260,
        color="#111111",
        label=f"mystery -> {mystery_prediction}",
        zorder=5,
    )
    ax.set_xlabel("Sweetness score")
    ax.set_ylabel("Weight (g)")
    ax.set_title("Similar fruits form groups")
    ax.legend()
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(OUT / "fruit_scatter.png", dpi=150, bbox_inches="tight")
    plt.close(fig)

    # ---- Confusion matrix ---------------------------------------------
    labels = sorted(df["fruit"].unique())
    cm = confusion_matrix(y_test, predictions, labels=labels)
    fig, ax = plt.subplots(figsize=(5, 4.2))
    ConfusionMatrixDisplay(cm, display_labels=labels).plot(ax=ax, cmap="Oranges", colorbar=False)
    ax.set_title("Fruit classification results")
    fig.tight_layout()
    fig.savefig(OUT / "confusion_matrix.png", dpi=150, bbox_inches="tight")
    plt.close(fig)

    with open(OUT / "metrics.txt", "w", encoding="utf-8") as handle:
        handle.write(f"accuracy: {accuracy:.4f}\n")
        handle.write(f"mystery prediction: {mystery_prediction} ({mystery_probability:.4f})\n\n")
        handle.write(classification_report(y_test, predictions, zero_division=0))

    print("\nSaved: outputs/fruit_scatter.png, outputs/confusion_matrix.png, outputs/metrics.txt")
    print("Try this: change n_neighbors from 5 to 1 or 9 and compare.")


if __name__ == "__main__":
    main()
```

---

## Detailed Checkpoint Analysis

### Checkpoint 1: Headless Matplotlib Backend & Modular Imports

```python
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
```

**What mentors should verify:**
- `matplotlib.use("Agg")` occurs **before** `import matplotlib.pyplot as plt`. If imported in reverse order, GUI backends may initialize and cause silent crashes in headless servers, CI runners, or Docker containers.
- All dependencies are imported from their standard submodules (e.g., `sklearn.neighbors`, `sklearn.pipeline`, `sklearn.preprocessing`).
- No extraneous third-party modules (e.g., `seaborn`, `scipy`) are introduced unless as documented student extensions.

**Common student errors:**
- Placing `matplotlib.use("Agg")` after `plt` import, producing warnings like `UserWarning: This call to matplotlib.use() has no effect...`.
- Attempting to import `KNeighborsClassifier` from `sklearn.cluster` instead of `sklearn.neighbors`.
- Confusing `Pipeline` from `sklearn.pipeline` with external libraries.

---

### Checkpoint 2: Path Anchoring & Output Directory Setup

```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)
```

**What mentors should verify:**
- Script anchors its working directory to `Path(__file__).resolve().parent`. This ensures that executing the script from any directory (e.g., repository root or parent folder) correctly locates the CSV file.
- The `OUT` directory is created with `exist_ok=True` before file writing routines commence.

**Common student errors:**
- Using raw string paths like `DATA = "data/fruits.csv"` which fail when invoked from a different terminal working directory (`FileNotFoundError`).
- Omitting `exist_ok=True`, raising `FileExistsError` on subsequent test runs.

---

### Checkpoint 3: Global Feature List & Color Constants

```python
FEATURES = ["sweetness", "weight_g", "size_cm", "color_score"]
COLOURS = {"apple": "#c0392b", "banana": "#f1c40f", "orange": "#e67e22"}
```

**What mentors should verify:**
- `FEATURES` contains all 4 predictor columns in exact order.
- `COLOURS` provides appropriate hex codes mapping to semantic fruit colors (crimson red for apple, gold yellow for banana, deep orange for orange).

**Common student errors:**
- Omitting `"color_score"`, reducing the model to a 3-feature space.
- Misspelling column names (e.g., `"weight"` instead of `"weight_g"` or `"colour_score"` with British spelling while the CSV uses American `"color_score"`).

---

### Checkpoint 4: Data Ingestion & Shape Verification

```python
df = pd.read_csv(DATA / "fruits.csv")
X = df[FEATURES]
y = df["fruit"]
```

**What mentors should verify:**
- Ingested DataFrame has shape `(60, 5)`.
- $X$ is a 2D `pandas.DataFrame` with shape `(60, 4)`.
- $y$ is a 1D `pandas.Series` with shape `(60,)`.
- Class distribution in $y$ is verified balanced (20 apple, 20 banana, 20 orange).

**Common student errors:**
- Extracting $X$ with single brackets (`df["sweetness"]`) or including the target column in $X$ (causing artificial 100% accuracy via target leakage).
- Extracting $y$ as a 2D DataFrame (`df[["fruit"]]`), triggering scikit-learn `DataConversionWarning: A column-vector y was passed when a 1d array was expected`.

---

### Checkpoint 5: Stratified Train/Test Partitioning

```python
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)
```

**What mentors should verify:**
- `test_size=0.25` splits 60 rows into 45 training rows and 15 test rows.
- `random_state=42` ensures exact reproducibility across runs.
- `stratify=y` guarantees that every class has exactly $20 \times 0.75 = 15$ training examples and $20 \times 0.25 = 5$ test examples.

**Common student errors:**
- Omitting `stratify=y`. Without stratification, random sampling could assign unbalanced class counts (e.g., 7 apples, 4 bananas, 4 oranges) to the test set, skewing evaluation.
- Forgetting `random_state=42`, causing non-deterministic splits that alter test indices across student runs.

---

### Checkpoint 6: Pipeline Assembly with StandardScaler & KNN

```python
model = Pipeline(
    [
        ("scale", StandardScaler()),
        ("knn", KNeighborsClassifier(n_neighbors=5)),
    ]
)
model.fit(X_train, y_train)
```

**What mentors should verify:**
- The model is constructed as a two-stage scikit-learn `Pipeline`.
- The first stage is `StandardScaler()` named `"scale"`.
- The second stage is `KNeighborsClassifier(n_neighbors=5)` named `"knn"`.
- `model.fit()` is called strictly on `(X_train, y_train)`.

**Common student errors:**
- Pre-scaling $X$ before `train_test_split`:
  ```python
  # INCORRECT: Data leakage!
  scaler = StandardScaler()
  X_scaled = scaler.fit_transform(X)
  X_train, X_test, ... = train_test_split(X_scaled, y)
  ```
  *Mentor Note:* Explain why this violates machine learning integrity: test set means and standard deviations leak into the training transformations.
- Forgetting to scale features altogether. In this dataset, `weight_g` ranges from 110g to 230g while `color_score` ranges from 1.0 to 9.5. Without scaling, Euclidean distance is dominated by weight differences, misclassifying fruits.

---

### Checkpoint 7: Evaluation & Classification Report

```python
predictions = model.predict(X_test)
accuracy = accuracy_score(y_test, predictions)
print("=" * 60)
print("THE FRUIT BASKET SORTER")
print("=" * 60)
print(f"Accuracy: {accuracy:.1%}\n")
print(classification_report(y_test, predictions, zero_division=0))
```

**What mentors should verify:**
- Predictions are generated on `X_test` (never `X_train`).
- Accuracy is computed using `accuracy_score(y_test, predictions)` and prints as `100.0%`.
- `classification_report` is printed with `zero_division=0` to prevent warnings if any class precision or recall has a zero denominator.
- Precision, recall, and F1-score are all 1.00 across all 3 classes (apple, banana, orange).

**Common student errors:**
- Evaluating the model on training data (`model.predict(X_train)`), yielding overoptimistic metrics and failing to evaluate true generalization.
- Formatting accuracy as raw float (e.g. `1.0`) instead of percentage (`100.0%`).

---

### Checkpoint 8: Mystery Fruit Inference & Confidence Calculation

```python
mystery = pd.DataFrame(
    [
        {
            "sweetness": 7.2,
            "weight_g": 170,
            "size_cm": 8.5,
            "color_score": 8.0,
        }
    ]
)
mystery_prediction = model.predict(mystery)[0]
mystery_probability = model.predict_proba(mystery).max()
print(f"Mystery fruit -> {mystery_prediction} ({mystery_probability:.0%} confident)")
```

**What mentors should verify:**
- Mystery sample is structured as a DataFrame with identical feature names and column ordering as $X$.
- `model.predict(mystery)[0]` outputs `"apple"`.
- `model.predict_proba(mystery).max()` outputs `1.0` (100% confidence).
- Console prints: `Mystery fruit -> apple (100% confident)`.

**Common student errors:**
- Passing a Python dictionary or raw list without feature names:
  ```python
  # May trigger UserWarning: X does not have valid feature names
  mystery = [[7.2, 170, 8.5, 8.0]]
  ```
- Forgetting `[0]` on the prediction output, resulting in printing an array `['apple']` instead of the clean string.
- Using `model.predict_proba(mystery)` without `.max()` or indexing, resulting in printing a 2D probability matrix `[[1.0, 0.0, 0.0]]`.

---

### Checkpoint 9: Scatter Plot Visualization (`fruit_scatter.png`)

```python
fig, ax = plt.subplots(figsize=(7.5, 5.5))
for fruit, group in df.groupby("fruit"):
    ax.scatter(
        group["sweetness"],
        group["weight_g"],
        s=60,
        alpha=0.8,
        label=fruit,
        color=COLOURS[fruit],
    )
ax.scatter(
    mystery["sweetness"],
    mystery["weight_g"],
    marker="*",
    s=260,
    color="#111111",
    label=f"mystery -> {mystery_prediction}",
    zorder=5,
)
ax.set_xlabel("Sweetness score")
ax.set_ylabel("Weight (g)")
ax.set_title("Similar fruits form groups")
ax.legend()
ax.grid(alpha=0.25)
fig.tight_layout()
fig.savefig(OUT / "fruit_scatter.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```

**What mentors should verify:**
- Figure dimensions are set to `(7.5, 5.5)`.
- Scatter points are grouped by fruit category with distinct colors matching `COLOURS`.
- The mystery fruit is rendered with `marker="*"`, high z-order (`zorder=5`), and size `s=260` so it is clearly visible atop training points.
- Titles, labels, legend, and subtle grid (`alpha=0.25`) are present.
- Figure is exported to `outputs/fruit_scatter.png` at 150 DPI and closed with `plt.close(fig)`.

**Common student errors:**
- Plotting all points in a single color without grouping by fruit class.
- Forgetting `plt.close(fig)`, leaving figures open in memory.
- Forgetting `bbox_inches="tight"`, resulting in clipped axis labels.

---

### Checkpoint 10: Confusion Matrix Visualization (`confusion_matrix.png`)

```python
labels = sorted(df["fruit"].unique())
cm = confusion_matrix(y_test, predictions, labels=labels)
fig, ax = plt.subplots(figsize=(5, 4.2))
ConfusionMatrixDisplay(cm, display_labels=labels).plot(ax=ax, cmap="Oranges", colorbar=False)
ax.set_title("Fruit classification results")
fig.tight_layout()
fig.savefig(OUT / "confusion_matrix.png", dpi=150, bbox_inches="tight")
plt.close(fig)
```

**What mentors should verify:**
- Categorical class labels are sorted alphabetically: `["apple", "banana", "orange"]`.
- `confusion_matrix(y_test, predictions, labels=labels)` computes the 3x3 array:
  $$\begin{bmatrix} 5 & 0 & 0 \\ 0 & 5 & 0 \\ 0 & 0 & 5 \end{bmatrix}$$
- Colormap is set to `"Oranges"` and `colorbar=False`.
- Output image is saved to `outputs/confusion_matrix.png` at 150 DPI and memory is freed with `plt.close(fig)`.

**Common student errors:**
- Omitting `labels=labels`, allowing `confusion_matrix` to infer label ordering implicitly, which may misalign with `display_labels`.
- Setting `colorbar=True` or using the default viridis colormap instead of `"Oranges"`.

---

### Checkpoint 11: Persistent Metrics File Logging (`metrics.txt`)

```python
with open(OUT / "metrics.txt", "w", encoding="utf-8") as handle:
    handle.write(f"accuracy: {accuracy:.4f}\n")
    handle.write(f"mystery prediction: {mystery_prediction} ({mystery_probability:.4f})\n\n")
    handle.write(classification_report(y_test, predictions, zero_division=0))
```

**What mentors should verify:**
- File path is `outputs/metrics.txt` opened with `encoding="utf-8"`.
- Accuracy and probability are formatted with 4 decimal places (`.4f`).
- Text includes the complete classification report.

**Common student errors:**
- Using write mode `"a"` instead of `"w"`, causing repeated runs to append duplicated metrics blocks.
- Omitting `encoding="utf-8"`, which can fail on certain Windows regional settings.

---

## Expected Artifacts Checklist

Mentors should confirm that after execution, the project directory contains:

| Artifact | File Type | Verification Command | Expected Properties |
|---|---|---|---|
| `outputs/fruit_scatter.png` | PNG image | `file outputs/fruit_scatter.png` | Resolution ~1125x825, size > 15 KB |
| `outputs/confusion_matrix.png` | PNG image | `file outputs/confusion_matrix.png` | Resolution ~750x630, size > 10 KB |
| `outputs/metrics.txt` | UTF-8 text | `cat outputs/metrics.txt` | Contains accuracy: 1.0000 and mystery prediction |

---

## Mentor Grading Rubric Breakdown

When evaluating student submissions, assign points according to `final-project/evaluation-rubric.json`:

1. **Data Ingestion & Feature Separation (15 pts)**:
   - Full points (15): Clean loading via pathlib, verified shapes `(60, 4)` and `(60,)`.
   - Partial points (8-12): Hardcoded string paths or missing shape assertions.
   - Low points (0-5): Incomplete feature set or target leakage into $X$.

2. **Stratified Splitting (10 pts)**:
   - Full points (10): `test_size=0.25`, `random_state=42`, `stratify=y` with 45/15 split.
   - Partial points (5): Missing `stratify=y` or missing `random_state`.

3. **Feature Scaling & Pipeline (15 pts)**:
   - Full points (15): Proper `Pipeline` containing `StandardScaler` and `KNeighborsClassifier(n_neighbors=5)`.
   - Partial points (5-10): Scaling performed manually outside pipeline; zero points if scaling omitted.

4. **Model Training & Evaluation (15 pts)**:
   - Full points (15): Fitted on train set only, 100% accuracy, clean classification report.
   - Partial points (8): Evaluated on training data or missing `zero_division=0`.

5. **Mystery Inference & Confidence (10 pts)**:
   - Full points (10): Correct DataFrame format, predicted `"apple"`, confidence 100%.
   - Partial points (5): Prediction correct but confidence calculation missing or malformed.

6. **Terminal Output Formatting (10 pts)**:
   - Full points (10): Clean banner, percentage formatting, matching reference output.

7. **Visualizations (15 pts)**:
   - Full points (15): Both PNG plots rendered cleanly with custom palette, labels, and star marker.
   - Partial points (8): Only one plot generated or formatting issues.

8. **File Output & Cleanup (10 pts)**:
   - Full points (10): All 3 files generated in `outputs/`, figures properly closed.

9. **Student Analysis Report (5 pts)**:
   - Full points (5): Insightful explanation of Euclidean distance, scaling impact, and $k$ parameter trade-offs.
