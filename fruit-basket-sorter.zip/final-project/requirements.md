# Final Project Requirements

## Project Objective

Reproduce the complete Fruit Basket Sorter pipeline from scratch, following `main.py` exactly. Your implementation should ingest the multi-feature fruit dataset (`data/fruits.csv`), partition the samples using stratified sampling, construct an end-to-end scikit-learn Pipeline that chains `StandardScaler` with `KNeighborsClassifier(n_neighbors=5)`, evaluate the multi-class model using test accuracy and a full classification report, classify a mystery fruit with associated probability confidence, generate two high-resolution diagnostic visualizations (a feature scatter plot and a confusion matrix heatmap), and write evaluation artifacts to disk. Finally, you will write a concise analysis report interpreting the geometric and probabilistic behavior of the classifier.

---

## Functional Requirements

1. **Imports and Matplotlib Backend Configuration**
   - Configure the non-interactive Matplotlib backend by calling `matplotlib.use("Agg")` strictly before importing `matplotlib.pyplot`.
   - Import `Path` from `pathlib`.
   - Import `pandas` as `pd`.
   - Import evaluation metrics: `accuracy_score`, `classification_report`, `ConfusionMatrixDisplay`, and `confusion_matrix` from `sklearn.metrics`.
   - Import `train_test_split` from `sklearn.model_selection`.
   - Import `KNeighborsClassifier` from `sklearn.neighbors`.
   - Import `Pipeline` from `sklearn.pipeline`.
   - Import `StandardScaler` from `sklearn.preprocessing`.

2. **Project Path Configuration**
   - Resolve the base directory dynamically using `BASE = Path(__file__).resolve().parent`.
   - Define dataset path `DATA = BASE / "data"` and outputs directory `OUT = BASE / "outputs"`.
   - Ensure the output directory exists using `OUT.mkdir(exist_ok=True)`.

3. **Global Constants Definition**
   - Define the feature list constant: `FEATURES = ["sweetness", "weight_g", "size_cm", "color_score"]`.
   - Define the visual palette dictionary: `COLOURS = {"apple": "#c0392b", "banana": "#f1c40f", "orange": "#e67e22"}`.

4. **Data Ingestion and Shape Verification**
   - Load `data/fruits.csv` into a pandas DataFrame using `pd.read_csv(DATA / "fruits.csv")`.
   - Verify the DataFrame contains 60 rows and 5 columns (`fruit`, `sweetness`, `weight_g`, `size_cm`, `color_score`).
   - Verify the target distribution is balanced with exactly 20 apples, 20 bananas, and 20 oranges.

5. **Feature Matrix ($X$) and Target Vector ($y$) Separation**
   - Extract the 4-column feature matrix: `X = df[FEATURES]`. Verify shape is `(60, 4)` and type is `pandas.DataFrame`.
   - Extract the 1D target label vector: `y = df["fruit"]`. Verify shape is `(60,)` and type is `pandas.Series`.

6. **Stratified Train/Test Splitting**
   - Split $X$ and $y$ using `train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)`.
   - Enforce stratified splitting so both training ($N=45$) and test ($N=15$) partitions contain exact 1:1:1 class proportions (15 train per class, 5 test per class).
   - Verify $X_{\text{train}}$ shape is `(45, 4)` and $X_{\text{test}}$ shape is `(15, 4)`.

7. **Pipeline Construction and Model Fitting**
   - Construct a scikit-learn `Pipeline` encapsulating two sequential stages:
     1. `"scale"`: `StandardScaler()`
     2. `"knn"`: `KNeighborsClassifier(n_neighbors=5)`
   - Fit the complete pipeline exclusively on the training data: `model.fit(X_train, y_train)`. Do not expose test data during fitting.

8. **Model Evaluation & Classification Reporting**
   - Generate test predictions across the test set: `predictions = model.predict(X_test)`.
   - Calculate overall accuracy using `accuracy = accuracy_score(y_test, predictions)`.
   - Generate the detailed multi-class classification report using `classification_report(y_test, predictions, zero_division=0)`.
   - Print banner and metrics to console formatted with exact percentage precision (`Accuracy: {accuracy:.1%}`).

9. **Mystery Fruit Inference and Confidence Estimation**
   - Create a single-row DataFrame representing the query fruit:
     ```python
     mystery = pd.DataFrame(
         [
             {
                 "sweetness": 7.2,
                 "weight_g": 170,
                 "size_cm": 8.5,
                 "color_score": 8.0,
             }
         ]
     )
     ```
   - Predict class label using `mystery_prediction = model.predict(mystery)[0]`.
   - Estimate neighbor consensus confidence using `mystery_probability = model.predict_proba(mystery).max()`.
   - Print inference result: `Mystery fruit -> apple (100% confident)`.

10. **Scatter Plot Visualization (`outputs/fruit_scatter.png`)**
    - Instantiate a figure with `fig, ax = plt.subplots(figsize=(7.5, 5.5))`.
    - Iterate through classes using `for fruit, group in df.groupby("fruit"):` and plot sweetness vs. weight using `ax.scatter()` with `s=60`, `alpha=0.8`, `color=COLOURS[fruit]`, and `label=fruit`.
    - Overlay the mystery fruit with a prominent black star marker: `marker="*"`, `s=260`, `color="#111111"`, `zorder=5`, and `label=f"mystery -> {mystery_prediction}"`.
    - Configure axis labels ("Sweetness score", "Weight (g)"), title ("Similar fruits form groups"), legend, and grid (`alpha=0.25`).
    - Apply `fig.tight_layout()` and export via `fig.savefig(OUT / "fruit_scatter.png", dpi=150, bbox_inches="tight")`.
    - Explicitly release canvas memory via `plt.close(fig)`.

11. **Confusion Matrix Visualization (`outputs/confusion_matrix.png`)**
    - Determine sorted categorical labels: `labels = sorted(df["fruit"].unique())`.
    - Compute the 3x3 confusion matrix: `cm = confusion_matrix(y_test, predictions, labels=labels)`.
    - Instantiate a figure with `fig, ax = plt.subplots(figsize=(5, 4.2))`.
    - Plot the matrix using `ConfusionMatrixDisplay(cm, display_labels=labels).plot(ax=ax, cmap="Oranges", colorbar=False)`.
    - Set title to `"Fruit classification results"`, apply `fig.tight_layout()`, and save to `OUT / "confusion_matrix.png"` (`dpi=150`, `bbox_inches="tight"`).
    - Close figure canvas via `plt.close(fig)`.

12. **Persistent Metrics Logging (`outputs/metrics.txt`)**
    - Write a clean text summary to `OUT / "metrics.txt"` with `encoding="utf-8"`:
      - Line 1: `accuracy: 1.0000` (`{accuracy:.4f}`)
      - Line 2: `mystery prediction: apple (1.0000)` (`{mystery_prediction} ({mystery_probability:.4f})`)
      - Line 3: Blank line separator
      - Lines 4+: Complete classification report table from scikit-learn.

---

## Non-Functional Requirements

- **Reproducibility**: Enforce deterministic execution by locking `random_state=42` during train/test partitioning.
- **Pipeline Integrity**: Feature scaling must occur strictly inside the `Pipeline` object to ensure the scaler is fitted only on $X_{\text{train}}$ and transformed on $X_{\text{test}}$ and mystery samples without data leakage.
- **Path Safety**: Employ `pathlib.Path` for all file system operations; no hardcoded OS-specific separator strings (`/` or `\`).
- **Resource Management**: Every matplotlib figure must be closed via `plt.close(fig)` immediately following export to avoid memory bloat.
- **Type Annotations and Style**: Include Python 3 type annotations (e.g., `def main() -> None:`) and adhere strictly to PEP 8 standards.

---

## Implementation Milestones

| Milestone | Deliverable | Verification Check |
|---|---|---|
| **1: Environment & Setup** | Script template with imports and backend setup | `python -c "import matplotlib; matplotlib.use('Agg'); import sklearn, pandas"` executes cleanly |
| **2: Data Ingestion** | Ingested DataFrame from `data/fruits.csv` | `df.shape == (60, 5)` and column names match schema |
| **3: Feature Separation** | $X$ DataFrame and $y$ Series | `X.shape == (60, 4)` and `y.shape == (60,)` |
| **4: Stratified Splitting** | Train and test partitions | `X_train.shape == (45, 4)`, `X_test.shape == (15, 4)`, class ratios equal 1:1:1 |
| **5: Pipeline Construction** | Two-step Pipeline with `StandardScaler` & `KNN(k=5)` | `len(model.steps) == 2` with step names `"scale"` and `"knn"` |
| **6: Training & Testing** | Fitted model and test predictions | `predictions.shape == (15,)` and `accuracy == 1.0` |
| **7: Mystery Inference** | Prediction and maximum predicted probability | `mystery_prediction == "apple"` and `mystery_probability == 1.0` |
| **8: Scatter Visualization** | Two-dimensional scatter plot with 3 classes + mystery star | `outputs/fruit_scatter.png` generated, valid PNG > 10 KB |
| **9: Confusion Matrix** | 3x3 Heatmap with Orange colormap | `outputs/confusion_matrix.png` generated, valid PNG > 10 KB |
| **10: Output Persistence** | Text summary of metrics and classification report | `outputs/metrics.txt` written with correct 4-decimal precision |

---

## Expected Deliverables

1. **Complete Python Script**: `main.py` (or `final_fruit_sorter.py`) executing cleanly from end to end.
2. **Terminal Console Output**:
   ```
   ============================================================
   THE FRUIT BASKET SORTER
   ============================================================
   Accuracy: 100.0%

                 precision    recall  f1-score   support

            apple       1.00      1.00      1.00         5
           banana       1.00      1.00      1.00         5
           orange       1.00      1.00      1.00         5

         accuracy                           1.00        15
        macro avg       1.00      1.00      1.00        15
     weighted avg       1.00      1.00      1.00        15

   Mystery fruit -> apple (100% confident)

   Saved: outputs/fruit_scatter.png, outputs/confusion_matrix.png, outputs/metrics.txt
   Try this: change n_neighbors from 5 to 1 or 9 and compare.
   ```
3. **Artifact `outputs/fruit_scatter.png`**: High-resolution scatter plot displaying clusters and query star.
4. **Artifact `outputs/confusion_matrix.png`**: Heatmap displaying diagonal counts of 5 apples, 5 bananas, 5 oranges.
5. **Artifact `outputs/metrics.txt`**: Precision-logged metrics matching reference.
6. **Student Analysis Report (1-2 pages Markdown or PDF)**:
   - Explanation of Euclidean distance and why feature scaling was critical for this dataset.
   - Analysis of why the mystery fruit was classified as an apple with 100% confidence.
   - Comparison of model behavior when $k=1$, $k=5$, and $k=9$.
   - Discussion of one real-world edge case (e.g., green cooking bananas or small crabapples) and how to handle it.

---

## Acceptance Criteria

- [ ] Script runs without errors: `python main.py` exit code 0.
- [ ] `accuracy_score` is exactly 1.0 (100.0%) on the test set.
- [ ] Mystery fruit prediction is `"apple"` with confidence `1.0` (100%).
- [ ] `outputs/fruit_scatter.png` contains 3 distinct class colors matching hex codes (`#c0392b`, `#f1c40f`, `#e67e22`) and a prominent black star marker for the mystery fruit.
- [ ] `outputs/confusion_matrix.png` displays a 3x3 matrix where non-zero entries exist solely along the main diagonal (`[[5,0,0],[0,5,0],[0,0,5]]`).
- [ ] `outputs/metrics.txt` contains accuracy, mystery prediction with probability, and full classification report.
- [ ] Matplotlib canvas is closed properly without leaking figure references.

---

## Testing Checklist

```bash
# 1. Verify environment and libraries
python -c "import pandas, numpy, matplotlib, sklearn; print('Dependencies OK')"

# 2. Check input data existence
test -f data/fruits.csv && echo "Dataset found"

# 3. Execute script
python main.py

# 4. Verify outputs directory and files
ls -l outputs/fruit_scatter.png outputs/confusion_matrix.png outputs/metrics.txt

# 5. Verify image validity
file outputs/fruit_scatter.png outputs/confusion_matrix.png

# 6. Check metrics text content
cat outputs/metrics.txt
```

---

## Expected Output Values

| Metric / Parameter | Expected Value | Output Format |
|---|---|---|
| Total Samples | 60 | 20 per fruit |
| Training Samples | 45 | 15 per fruit (stratified) |
| Test Samples | 15 | 5 per fruit (stratified) |
| Overall Test Accuracy | 1.0000 | `100.0%` in console, `1.0000` in metrics.txt |
| Apple Precision / Recall / F1 | 1.00 / 1.00 / 1.00 | Formatted table |
| Banana Precision / Recall / F1 | 1.00 / 1.00 / 1.00 | Formatted table |
| Orange Precision / Recall / F1 | 1.00 / 1.00 / 1.00 | Formatted table |
| Mystery Fruit Prediction | `apple` | String |
| Mystery Fruit Confidence | 1.0000 | `100% confident` in console, `1.0000` in metrics.txt |
| Confusion Matrix Diagonal | `[5, 5, 5]` | 5 per class correctly classified |

---

## Troubleshooting Guide

| Issue | Root Cause | Resolution |
|---|---|---|
| `KeyError: 'sweetness'` | Column names misspelled or trailing whitespace in CSV | Use `df.columns = df.columns.str.strip()` or verify `FEATURES` list spelling. |
| `ValueError: Found array with 0 sample(s)` | Incorrect test size or filtered DataFrame | Ensure `test_size=0.25` on full 60-row dataset. |
| `ValueError: The least populated class in y has only 1 member` | Split without stratification or unbalanced slice | Ensure `stratify=y` is passed to `train_test_split`. |
| Mystery fruit classified incorrectly as banana | `StandardScaler` omitted or not fitted inside pipeline | Wrap KNN in `Pipeline([('scale', StandardScaler()), ('knn', KNeighborsClassifier())])`. |
| Matplotlib GUI warning or hanging execution | Interactive backend used in headless environment | Place `matplotlib.use("Agg")` strictly before importing `pyplot`. |
| Confusion matrix labels transposed | Inconsistent class label ordering | Specify `labels=sorted(df["fruit"].unique())` in both `confusion_matrix` and `ConfusionMatrixDisplay`. |

---

## Optional Extension Challenges

1. **Hyperparameter Tuning ($k$-Value Sweep)**: Implement a loop testing $k \in [1, 3, 5, 7, 9, 11, 15]$ with 5-fold cross-validation (`cross_val_score`) and plot validation accuracy vs. $k$.
2. **Alternative Distance Metrics**: Compare Euclidean distance (`metric="euclidean"`) against Manhattan (`metric="manhattan"`) and Chebyshev (`metric="chebyshev"`) distances.
3. **Distance Weighting**: Compare `weights="uniform"` vs. `weights="distance"` to observe whether inverse distance weighting alters boundary sensitivity.
4. **Interactive Command-Line Fruit Classifier**: Prompt the user to enter custom fruit dimensions (`sweetness`, `weight_g`, `size_cm`, `color_score`) and output real-time classification with probability distribution across all three classes.
5. **Dimensionality Reduction Visualization**: Use PCA (`sklearn.decomposition.PCA(n_components=2)`) to reduce all 4 scaled features to 2 principal components and plot the true multi-feature decision boundary.
