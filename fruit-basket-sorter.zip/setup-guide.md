# Setup Guide: The Fruit Basket Sorter

This guide walks you step-by-step through setting up your local environment, installing all dependencies, verifying the dataset, running the Python pipeline, and confirming output files.

---

## Step 1: Navigate to the Project Directory
Open your terminal (bash, zsh, or command prompt) and navigate into the project directory:

```bash
cd "beginner-projects-main/AI-ML Beginners/projects/05_fruit_sorter"
```

Verify your current working directory and inspect the files:
```bash
# On Linux / macOS:
pwd
ls -la

# On Windows PowerShell:
Get-Location
Get-ChildItem
```

You should see:
- `main.py`
- `data/` directory containing `fruits.csv` (or `fruit_basket.csv`)
- `outputs/` directory (created automatically when `main.py` executes)

---

## Step 2: Set Up a Virtual Environment (Recommended)
Creating an isolated virtual environment prevents library version conflicts across projects.

### On Linux / macOS:
```bash
python3 -m venv venv
source venv/bin/activate
```

### On Windows (PowerShell):
```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

---

## Step 3: Install Required Dependencies
Install `pandas`, `matplotlib`, and `scikit-learn`:

```bash
pip install --upgrade pip
pip install pandas matplotlib scikit-learn
```

To pin your environment dependencies, you can create a `requirements.txt` file:
```txt
pandas>=1.3.0
matplotlib>=3.4.0
scikit-learn>=1.0.0
```

Install via requirements:
```bash
pip install -r requirements.txt
```

---

## Step 4: Verify the Input Dataset
Inspect the raw fruit measurements in `data/fruits.csv`:

```bash
# On Linux / macOS:
head -n 10 data/fruits.csv

# On Windows PowerShell:
Get-Content data/fruits.csv -Head 10
```

Expected first 5 rows:
```csv
fruit,sweetness,weight_g,size_cm,color_score
apple,6.4,165,8.0,8.3
apple,7.1,176,7.8,8.2
banana,8.1,107,18.7,7.2
orange,5.3,194,9.6,5.4
```

Verify that the file contains exactly 60 rows of data (plus 1 header row):
```bash
# On Linux / macOS:
wc -l data/fruits.csv
# Output: 61 data/fruits.csv
```

---

## Step 5: Execute the Project
Run the primary training and inference script:

```bash
python main.py
```

Expected terminal output:
```text
============================================================
THE FRUIT BASKET SORTER
============================================================
Accuracy: 100.0%

              precision    recall  f1-score   support

       apple       1.00      1.00      1.00         5
      banana       1.00      1.00      1.00         5
      orange       1.00      1.00      1.00         5

    accuracy                           1.00        15
   macro avg       1.00      1.00      1.00        15
weighted avg       1.00      1.00      1.00        15

Mystery fruit -> apple (100% confident)

Saved: outputs/fruit_scatter.png, outputs/confusion_matrix.png, outputs/metrics.txt
Try this: change n_neighbors from 5 to 1 or 9 and compare.
```

---

## Step 6: Verify Generated Outputs
Confirm that all expected output artifacts were generated inside the `outputs/` folder:

```bash
ls -la outputs/
```

1. **`outputs/fruit_scatter.png`**: High-resolution 2D scatter plot showing sweetness vs weight for all fruits, colored by class, with the mystery fruit plotted as a large black star (`*`).
2. **`outputs/confusion_matrix.png`**: Formatted 3x3 heatmap plot showing true vs. predicted counts across apple, banana, and orange.
3. **`outputs/metrics.txt`**: Plain text log containing exact numeric scores and classification reports.

To inspect the contents of `outputs/metrics.txt`:
```bash
cat outputs/metrics.txt
```

Expected contents:
```text
accuracy: 1.0000
mystery prediction: apple (1.0000)

              precision    recall  f1-score   support

       apple       1.00      1.00      1.00         5
      banana       1.00      1.00      1.00         5
      orange       1.00      1.00      1.00         5

    accuracy                           1.00        15
   macro avg       1.00      1.00      1.00        15
weighted avg       1.00      1.00      1.00        15
```

---

## Step 7: Troubleshooting Common Setup Issues

| Problem | Symptom | Solution |
|---|---|---|
| **Module Not Found** | `ModuleNotFoundError: No module named 'sklearn'` | Ensure your virtual environment is active and run `pip install scikit-learn`. |
| **Path Error** | `FileNotFoundError: [Errno 2] No such file or directory: '.../data/fruits.csv'` | Verify you are executing from the project folder containing `main.py` and that `data/fruits.csv` exists. |
| **GUI Backend Error** | `UserWarning: Matplotlib is currently using agg, which is a non-GUI backend...` | This is expected and intentional. The script uses `matplotlib.use("Agg")` so it runs seamlessly in headless server and test environments. |
| **Permission Denied** | `PermissionError: [Errno 13] Permission denied: 'outputs/metrics.txt'` | Check directory permissions or ensure `metrics.txt` is not locked open by another text editor. |
