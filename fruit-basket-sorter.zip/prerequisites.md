# Prerequisites

Before starting **The Fruit Basket Sorter** project, learners should review the foundational concepts, tooling requirements, and Python programming constructs required to complete the modules successfully.

---

## 1. Programming Skills Required
- **Python Fundamentals**:
  - Variable assignments, standard data types (ints, floats, strings, lists, dictionaries).
  - Writing and calling functions with type annotations (`def main() -> None:`).
  - Working with Python dictionaries for mappings (e.g., `COLOURS = {"apple": "#c0392b", ...}`).
  - File handling using `with open(...) as handle:`.
  - Path management using Python 3's modern `pathlib.Path` library.
- **Data Manipulation with pandas**:
  - Reading CSV files using `pd.read_csv()`.
  - Subsetting columns using list indexing (`df[["sweetness", "weight_g", ...]]`).
  - Extracting series targets (`df["fruit"]`).
  - Creating single-row inference DataFrames (`pd.DataFrame([{"sweetness": 7.2, ...}])`).
  - Grouping data for plotting (`df.groupby("fruit")`).
- **Basic Plotting with matplotlib**:
  - Creating figures and axes objects with `plt.subplots()`.
  - Scatter plots with `ax.scatter()`, setting labels, legends, and grid lines.
  - Setting headless renderers using `matplotlib.use("Agg")` to support automated/server environments.
  - Exporting figures using `fig.savefig()`.

---

## 2. Mathematical & Machine Learning Foundations
- **Supervised Classification vs. Regression**:
  - Understanding that regression predicts continuous numbers (like temperature or price), whereas classification predicts discrete categories (such as apple, banana, or orange).
  - Understanding multi-class classification (predicting among 3 or more mutually exclusive classes).
- **Geometric Distance in N-Dimensions**:
  - Intuitive understanding of Cartesian distance ($d = \sqrt{(x_2 - x_1)^2 + (y_2 - y_1)^2}$).
  - Extending distance calculation across 4 dimensions: sweetness, weight, size, and color score.
- **Normalization and Feature Scaling**:
  - Grasping why a feature measured in hundreds (e.g., weight in grams: 100g–240g) would mathematically overwhelm a feature measured in small units (e.g., sweetness: 3–9) unless standardized to a common scale.
  - Basic understanding of mean ($\mu$) and standard deviation ($\sigma$).

---

## 3. Software & Environment Requirements
- **Python**: Version 3.8 or newer (3.10+ recommended).
- **Package Manager**: `pip` (Python package installer).
- **Code Editor**: Visual Studio Code, PyCharm, or any text editor with Python syntax highlighting.
- **Operating System**: Linux, macOS, or Windows (WSL2 or standard PowerShell).

---

## 4. Required Python Libraries
To ensure your environment is fully prepared, install the necessary libraries:
```bash
pip install pandas matplotlib scikit-learn
```

| Package | Minimum Version | Primary Purpose in This Project |
|---|---|---|
| `pandas` | 1.3.0+ | Reading `fruits.csv`, structuring feature matrices, grouping records |
| `matplotlib` | 3.4.0+ | Plotting scatter distributions, rendering confusion matrices |
| `scikit-learn` | 1.0.0+ | `StandardScaler`, `KNeighborsClassifier`, `Pipeline`, metrics |

---

## 5. Conceptual Review Checklist
Ensure you can comfortably answer the following questions before starting Module 01:
- [ ] What is the difference between an input feature ($X$) and a target label ($y$)?
- [ ] Why do we split data into training and testing sets instead of evaluating on our training data?
- [ ] What is an odd number of neighbors in KNN, and why does an odd $k$ (e.g., $k=5$) help prevent tie votes in binary decisions?
- [ ] What is a confusion matrix, and why is accuracy alone sometimes insufficient in multi-class problems?
