# Project Summary: The Fruit Basket Sorter

## 1. Executive Summary
**The Fruit Basket Sorter** is a practical, beginner-friendly AI/ML educational project demonstrating supervised multi-class classification on tabular data. The project classifies three fruit varieties—apples, bananas, and oranges—based on four physical measurements: sweetness, weight (grams), size (diameter in cm), and color score.

Using modern machine learning workflows in Python with `pandas`, `matplotlib`, and `scikit-learn`, students build a robust machine learning pipeline pairing `StandardScaler` with `KNeighborsClassifier(n_neighbors=5)`. The model is trained on a stratified dataset of 45 fruits, evaluated on 15 held-out test fruits (achieving 100.0% accuracy), and used to infer the variety and confidence probability of an unknown "mystery fruit".

---

## 2. Core Project Specifications

| Attribute | Specification |
|---|---|
| **Project Name** | The Fruit Basket Sorter |
| **Project Slug** | `fruit-basket-sorter` |
| **Machine Learning Category** | Supervised Multi-Class Classification |
| **Core Algorithm** | K-Nearest Neighbours (`KNeighborsClassifier`, $k=5$, Euclidean distance) |
| **Preprocessing** | Feature Standardization (`StandardScaler`, $z = \frac{x - \mu}{\sigma}$) |
| **Architecture** | scikit-learn `Pipeline([('scale', StandardScaler()), ('knn', KNeighborsClassifier(5))])` |
| **Dataset File** | `data/fruits.csv` (60 rows: 20 apple, 20 banana, 20 orange) |
| **Input Features ($X$)** | 4 continuous numeric features: `sweetness`, `weight_g`, `size_cm`, `color_score` |
| **Target Variable ($y$)** | Categorical label: `fruit` (`apple`, `banana`, `orange`) |
| **Train/Test Partition** | 75% Training (45 samples) / 25% Testing (15 samples), `random_state=42`, `stratify=y` |
| **Test Accuracy** | 100.0% (15 out of 15 correct predictions) |
| **Evaluation Metrics** | Accuracy, Precision, Recall, F1-Score, Support, Confusion Matrix |
| **Mystery Fruit Features** | `sweetness: 7.2`, `weight_g: 170.0`, `size_cm: 8.5`, `color_score: 8.0` |
| **Mystery Fruit Prediction** | **`apple`** with **100% confidence** (`predict_proba = 1.0000`) |
| **Palette Mapping** | `{"apple": "#c0392b", "banana": "#f1c40f", "orange": "#e67e22"}` |
| **Output Files** | `outputs/fruit_scatter.png`, `outputs/confusion_matrix.png`, `outputs/metrics.txt` |
| **Tech Stack** | Python 3, pandas, matplotlib (Agg backend), scikit-learn |

---

## 3. Data Profile & Distributions

| Fruit Class | Sample Count | Sweetness Range | Weight Range (g) | Size Range (cm) | Color Score Range |
|---|---|---|---|---|---|
| **Apple** | 20 (15 train, 5 test) | 6.1 – 8.0 | 136 – 187 | 7.2 – 9.0 | 7.2 – 9.0 |
| **Banana** | 20 (15 train, 5 test) | 7.2 – 8.8 | 103 – 142 | 13.6 – 18.7 | 6.0 – 7.6 |
| **Orange** | 20 (15 train, 5 test) | 3.6 – 5.7 | 161 – 237 | 8.2 – 10.2 | 4.9 – 7.8 |

### Key Observations:
- **Bananas** are characterized by exceptionally long size (13.6–18.7 cm), light weight (103–142 g), and high sweetness (7.2–8.8).
- **Oranges** are heavy (161–237 g), moderately sized (8.2–10.2 cm), but have low sweetness scores (3.6–5.7) and lower color scores (4.9–7.8).
- **Apples** are dense and moderately weighted (136–187 g), compact (7.2–9.0 cm), sweet (6.1–8.0), and score highest in the color index (7.2–9.0).
- The mystery fruit (`sweetness: 7.2`, `weight: 170`, `size: 8.5`, `color: 8.0`) falls squarely into the heart of the apple cluster across all 4 scaled dimensions.

---

## 4. Key Learnings & Educational Outcomes
1. **Multi-Class vs. Binary vs. Regression**: Students master why predicting one of three categories requires multi-class metrics (confusion matrices, macro/weighted averages) rather than regression metrics (MAE, R²).
2. **Feature Scale Sensitivity**: Students visually and mathematically discover why raw Euclidean distance breaks when feature units differ (grams vs. single-digit sweetness), motivating `StandardScaler`.
3. **Pipeline Construction**: Students practice chaining transformers and estimators, understanding how `Pipeline` prevents data leakage and streamlines deployment.
4. **Distance-Based Inference**: Students learn how KNN locates the $k=5$ nearest neighbors and calculates posterior class probabilities using `predict_proba()`.
5. **Headless Data Visualization**: Students construct publishable multi-class scatter plots and confusion matrix figures using headless matplotlib.
