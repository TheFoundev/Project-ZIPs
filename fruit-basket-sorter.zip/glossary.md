# Glossary: Machine Learning & Fruit Sorter Terms

This glossary defines key terminology, algorithms, metrics, and software concepts used throughout **The Fruit Basket Sorter** curriculum.

| Term | Category | Definition |
|---|---|---|
| **K-Nearest Neighbours (KNN)** | Algorithm | A non-parametric, instance-based supervised learning algorithm that classifies new data points based on the majority class among their $k$ nearest training samples in feature space. |
| **Supervised Learning** | Concept | A paradigm in machine learning where algorithms learn mathematical mappings from input features ($X$) to known labeled outputs ($y$). |
| **Multi-Class Classification** | Concept | A predictive modeling task where target instances belong to one of three or more mutually exclusive discrete classes (e.g., apple vs. banana vs. orange). |
| **Feature Matrix ($X$)** | Data Structure | A 2-dimensional tabular structure (rows = samples, columns = measurements) representing independent input variables used for prediction. |
| **Target Vector ($y$)** | Data Structure | A 1-dimensional array or Series containing the ground-truth categorical labels corresponding to each sample in $X$. |
| **Euclidean Distance** | Mathematics | The straight-line distance between two points in Euclidean space: $d(p, q) = \sqrt{\sum_{i=1}^n (q_i - p_i)^2}$. Default metric in scikit-learn's KNN. |
| **Feature Scaling** | Preprocessing | The process of transforming numeric variables onto a comparable numeric scale so distance-based algorithms do not disproportionately favor features with large numerical magnitudes. |
| **StandardScaler (Z-Score)** | Preprocessing | A standardization technique that rescales features to have zero mean ($\mu = 0$) and unit variance ($\sigma = 1$) via the formula $z = \frac{x - \mu}{\sigma}$. |
| **Pipeline** | Architecture | A scikit-learn abstraction that sequentially chains multiple data transformation steps (e.g., scalers) with a final estimator (e.g., classifier), preventing data leakage. |
| **Data Leakage** | ML Best Practice | An inadvertent sharing of information between the training and test sets during preprocessing (e.g., fitting a scaler on the entire dataset), leading to overly optimistic evaluation metrics. |
| **Stratified Split** | Data Sampling | A dataset partitioning technique (`stratify=y`) that ensures each training and testing subset contains identical class proportions to the original dataset. |
| **Hyperparameter** | ML Tuning | A configuration setting whose value is specified before model training begins (e.g., $k=5$ in KNN), as opposed to internal parameters learned from data. |
| **Accuracy** | Metric | The ratio of correctly predicted observations to total observations: $\frac{TP + TN}{TP + TN + FP + FN}$. |
| **Precision** | Metric | The proportion of positive identifications that were actually correct: $\frac{TP}{TP + FP}$. Answers: "Of all items predicted as apples, how many were actually apples?" |
| **Recall (Sensitivity)** | Metric | The proportion of actual positives that were correctly identified: $\frac{TP}{TP + FN}$. Answers: "Of all actual apples in the test set, how many did the model identify?" |
| **F1-Score** | Metric | The harmonic mean of precision and recall: $2 \times \frac{\text{Precision} \times \text{Recall}}{\text{Precision} + \text{Recall}}$. |
| **Support** | Metric | The actual count of true instances of each class present in the evaluation dataset (e.g., 5 apples, 5 bananas, 5 oranges). |
| **Confusion Matrix** | Metric / Visual | A 2D grid comparing ground truth labels against model predictions, showing counts of true positives, false positives, true negatives, and false negatives. |
| **predict_proba()** | Inference | A scikit-learn method that outputs an array of class probability distributions for given samples, calculated as the fraction of neighboring votes belonging to each class. |
| **Agg Backend** | Graphics | A non-interactive matplotlib backend that renders raster graphics directly to image files (PNG, PDF) without requiring an active graphical window or display server. |
| **pathlib.Path** | Python | An object-oriented filesystem module in standard Python that manages directory paths across operating systems using the `/` operator. |
