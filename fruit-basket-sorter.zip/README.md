# The Fruit Basket Sorter

## Overview
This project builds a **K-Nearest Neighbours (KNN)** multi-class classification pipeline to automatically sort fruits into apples, bananas, and oranges. Using the actual dataset `data/fruits.csv` (also referenced as `data/fruit_basket.csv`) from `beginner-projects-main/AI-ML Beginners/projects/05_fruit_sorter/`, you will learn how to preprocess tabular numeric features using `StandardScaler`, assemble a leakage-free `Pipeline`, evaluate multi-class predictions, and classify a mystery fruit with measured confidence.

## Real-World Use Case
Automated agricultural sorting and packing facilities process thousands of harvested fruits per minute. High-speed sensors and computer vision cameras extract physical measurements (weight, diameter, sugar content via refractometry, and optical color spectrum scores). A machine learning classification model classifies each item on the fly so robotic actuators can divert fruits into their respective bins.

## Features (Implemented)
- Load fruit measurements from CSV with pandas
- Select 4 continuous numeric features (`sweetness`, `weight_g`, `size_cm`, `color_score`)
- Split data into stratified training (75%) and testing (25%) sets (45 train, 15 test)
- Build a scikit-learn `Pipeline` combining `StandardScaler` and `KNeighborsClassifier(n_neighbors=5)`
- Train the model strictly on training data to prevent information leakage
- Measure test set classification accuracy (100.0% on test split)
- Generate a comprehensive classification report (precision, recall, f1-score, support)
- Predict the class and confidence probability of an unlabelled "mystery fruit" (`sweetness=7.2, weight_g=170, size_cm=8.5, color_score=8.0` → **apple** at **100% confidence**)
- Visualize class clusters in 2D feature space with custom fruit palette (`#c0392b` for apple, `#f1c40f` for banana, `#e67e22` for orange) and mystery marker
- Plot and save a 3x3 confusion matrix using `ConfusionMatrixDisplay`
- Save performance metrics and mystery prediction to `outputs/metrics.txt`

## Technology Stack
- **Python 3.8+**
- **pandas** (tabular data manipulation)
- **matplotlib** (visualization and publication-quality plots)
- **scikit-learn** (preprocessing, pipeline, KNN classifier, evaluation metrics)

## System Requirements
- Operating System: Linux, macOS, or Windows
- Python 3.8 or higher
- `pip` package manager

## Installation Instructions
```bash
# Navigate to the project root directory
cd "beginner-projects-main/AI-ML Beginners/projects/05_fruit_sorter"

# Install required dependencies
pip install pandas matplotlib scikit-learn

# Execute the main pipeline script
python main.py
```

## Project Structure (Actual)
```
05_fruit_sorter/
├── main.py                     # Complete end-to-end ML pipeline script
├── data/
│   └── fruits.csv              # 60 fruit observations (20 apple, 20 banana, 20 orange)
└── outputs/
    ├── fruit_scatter.png       # 2D scatter plot of sweetness vs weight with mystery point
    ├── confusion_matrix.png    # 3-class confusion matrix plot
    └── metrics.txt             # Summary text file containing accuracy, prediction, and report
```

## How It Works
1. **Loads Dataset**: Reads `data/fruits.csv` containing columns `fruit`, `sweetness`, `weight_g`, `size_cm`, and `color_score`.
2. **Feature & Target Extraction**: Assigns `FEATURES = ["sweetness", "weight_g", "size_cm", "color_score"]` as matrix `X` and column `fruit` as vector `y`.
3. **Stratified Split**: Uses `train_test_split` with `test_size=0.25`, `random_state=42`, and `stratify=y` to ensure an equal distribution of 5 apples, 5 bananas, and 5 oranges in the test set.
4. **Pipeline Construction**: Pairs `StandardScaler()` (which computes $z = \frac{x - \mu}{\sigma}$) with `KNeighborsClassifier(n_neighbors=5)` using Euclidean distance.
5. **Model Fitting & Evaluation**: Fits the pipeline on `X_train` and `y_train`, evaluates accuracy on `X_test`, and prints the scikit-learn classification report.
6. **Mystery Fruit Inference**: Passes a single test sample through the pipeline to predict its label and calculates maximum class probability using `predict_proba()`.
7. **Visualization**: Employs matplotlib's `Agg` headless backend to render and export `fruit_scatter.png` and `confusion_matrix.png`.
8. **Logging**: Writes all evaluation metrics and inference results to `outputs/metrics.txt`.

## Expected Output
Running `python main.py` produces the following console output:
```text
============================================================
THE FRUIT BASKET SORTER
============================================================
Accuracy: 100.0%

              precision    recall  f1-score   support

       apple       1.00      1.00      1.00         5
      banana       1.00      1.00      1.00         5
      orange       1.00      1.00      1.00         5

    accuracy                           1.00        15
   macro avg       1.00      1.00      1.00        15
weighted avg       1.00      1.00      1.00        15

Mystery fruit -> apple (100% confident)

Saved: outputs/fruit_scatter.png, outputs/confusion_matrix.png, outputs/metrics.txt
Try this: change n_neighbors from 5 to 1 or 9 and compare.
```

## Security Considerations
- **Local File Processing**: The script executes strictly within the local environment without making outbound network requests or socket calls.
- **Data Integrity**: The code performs read-only operations on `data/fruits.csv` and only creates new files inside the designated `outputs/` directory.
- **Resource Management**: Figures are properly closed with `plt.close(fig)` to avoid memory leaks during batch or headless execution.

## Troubleshooting
- **Missing Dependencies**: If `ModuleNotFoundError: No module named 'sklearn'` occurs, run `pip install scikit-learn pandas matplotlib`.
- **Display Server Errors**: If running in a headless SSH or container environment, verify `matplotlib.use("Agg")` is called before importing `pyplot`.
- **Path Not Found**: Ensure you execute `python main.py` from within the `05_fruit_sorter` directory or rely on the script's `Path(__file__).resolve().parent` logic.

## Further Learning
- Experiment with hyperparameter tuning by altering `n_neighbors` (e.g., $k=1, 3, 9$).
- Compare Euclidean distance against Manhattan (`cityblock`) and Minkowski distance metrics.
- Benchmark KNN performance against Decision Trees and Support Vector Machines (SVM).
