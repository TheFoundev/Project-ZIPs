# All Correct Answers for Assessments
Project: The Fruit Basket Sorter
---

## Module 01

**q1-01.** What type of machine learning task is implemented in The Fruit Basket Sorter project?
   **Correct Answer:** b. Supervised multi-class classification
   *Explanation:* The Fruit Basket Sorter is a supervised multi-class classification task because it learns from historical examples with known labels to assign fruits into one of three distinct categorical classes: apple, banana, or orange.

**q1-02.** How many distinct target classes are present in the fruits dataset?
   **Correct Answer:** b. 3 classes (apple, banana, orange)
   *Explanation:* The dataset contains exactly 3 fruit categories: 'apple', 'banana', and 'orange', as reflected in df['fruit'].unique() and the COLOURS mapping dictionary.

**q1-03.** Which list of column names represents the input features (X) in main.py?
   **Correct Answer:** a. ['sweetness', 'weight_g', 'size_cm', 'color_score']
   *Explanation:* Line 28 of main.py explicitly defines FEATURES = ['sweetness', 'weight_g', 'size_cm', 'color_score'], which extracts the 4 continuous numeric predictor variables from the DataFrame.

**q1-04.** In main.py, why is X extracted using df[FEATURES] rather than df['sweetness']?
   **Correct Answer:** b. df[FEATURES] extracts all 4 numeric predictor variables as a 2D DataFrame required by scikit-learn
   *Explanation:* In scikit-learn, the feature matrix X must be a 2D tabular array-like structure of shape (n_samples, n_features). Passing df[FEATURES] passes a list of 4 column names, producing a 2D DataFrame of shape (60, 4).

**q1-05.** How does the K-Nearest Neighbours algorithm decide the predicted label for a query fruit?
   **Correct Answer:** b. By finding the k closest training points in feature space and taking a majority vote among their labels
   *Explanation:* KNN operates by calculating the geometric distance between a query sample and all stored training samples, identifying the k nearest neighbors, and performing a majority vote among their class labels.

**q1-06.** What value of k (n_neighbors) is configured for KNeighborsClassifier in main.py?
   **Correct Answer:** c. k = 5
   *Explanation:* In main.py line 44, the classifier is instantiated as KNeighborsClassifier(n_neighbors=5), setting k=5.

**q1-07.** Why is matplotlib.use('Agg') called at the beginning of main.py?
   **Correct Answer:** b. To enforce a headless non-interactive rendering backend that generates image files without requiring a GUI window
   *Explanation:* matplotlib.use('Agg') activates the non-interactive Anti-Grain Geometry backend, which renders directly to raster files (such as PNG) without requiring an interactive window manager or display server.

**q1-08.** Which Python library and class is used to manage file and directory paths in main.py?
   **Correct Answer:** b. pathlib.Path
   *Explanation:* main.py uses pathlib.Path to construct BASE, DATA, and OUT directory paths cleanly across Linux, macOS, and Windows environments.

**q1-09.** If a query point's 5 nearest neighbors consist of 3 apples, 1 banana, and 1 orange, what does model.predict() and model.predict_proba().max() return?
   **Correct Answer:** a. Prediction: 'apple', Confidence: 60%
   *Explanation:* With 3 out of 5 neighbors being apples, apple wins the majority vote (model.predict() returns 'apple'). The confidence probability is the fraction of votes: 3 / 5 = 0.60 (60%).

**q1-10.** Why is K-Nearest Neighbours characterized as a 'non-parametric lazy learner'?
   **Correct Answer:** b. Because it does not learn a fixed set of algebraic parameters (such as weights or coefficients) during fitting, instead storing training instances to compute distances at query time
   *Explanation:* KNN is non-parametric because it makes no assumptions about the underlying distribution of the data and learns no fixed parameters; it is 'lazy' because it delays computation until a prediction query is made by storing the training data.

## Module 02

**q2-01.** How many total samples (rows) are loaded from data/fruits.csv in main.py?
   **Correct Answer:** c. 60 rows
   *Explanation:* data/fruits.csv contains 60 data rows (plus 1 header row), representing 20 observations for each of the 3 fruit varieties.

**q2-02.** Which pandas method provides count, mean, standard deviation, min, and quartiles for numeric features?
   **Correct Answer:** b. df.describe()
   *Explanation:* df.describe() generates summary statistics including count, mean, standard deviation, min, 25%, 50% (median), 75%, and max for all numeric columns in a pandas DataFrame.

**q2-03.** What is the count of each fruit variety in the complete 60-row dataset?
   **Correct Answer:** b. 20 apples, 20 bananas, 20 oranges
   *Explanation:* The dataset is perfectly balanced with exactly 20 apples, 20 bananas, and 20 oranges, totaling 60 observations.

**q2-04.** Which fruit variety has the largest average length (size_cm) in the dataset?
   **Correct Answer:** b. Banana (mean ~ 16.53 cm)
   *Explanation:* Bananas have the largest average size_cm at approximately 16.53 cm (ranging from 13.6 to 18.7 cm), reflecting their elongated physical shape.

**q2-05.** Why is the standard deviation of weight_g (~40.09) dramatically larger than sweetness (~1.46)?
   **Correct Answer:** a. Because weight is measured in grams (ranging 103-237), whereas sweetness is an index (ranging 3.6-8.8)
   *Explanation:* Different features represent physical properties on vastly different measurement scales. Weight is measured in grams (ranging from 103g to 237g), resulting in a standard deviation of ~40, whereas sweetness is a compact scale (3.6 to 8.8) with std ~1.46.

**q2-06.** In train_test_split, what does test_size=0.25 on a 60-row dataset produce?
   **Correct Answer:** b. 45 train samples, 15 test samples
   *Explanation:* With test_size=0.25, 25% of the 60 samples (0.25 * 60 = 15) are allocated to the test set, and 75% (0.75 * 60 = 45) are allocated to the training set.

**q2-07.** What does passing stratify=y to train_test_split guarantee?
   **Correct Answer:** b. It guarantees that the proportion of each fruit class in train and test sets exactly reflects the overall dataset (5 of each fruit in test)
   *Explanation:* Passing stratify=y forces train_test_split to sample proportionally from each class, ensuring exactly 25% of each class (5 apples, 5 bananas, 5 oranges) appears in the test set.

**q2-08.** How does main.py iterate through each fruit class to render the scatter plot?
   **Correct Answer:** b. Using for fruit, group in df.groupby('fruit'):
   *Explanation:* In main.py line 73, df.groupby('fruit') groups the DataFrame by fruit class, yielding each fruit name and its corresponding subset of rows to render colored scatter points in a clean loop.

**q2-09.** If a multi-class dataset has 10 samples of Class A, 10 of Class B, and 10 of Class C, what could happen during an unstratified random split with test_size=0.20 (6 test samples)?
   **Correct Answer:** a. The test set could draw 4 of Class A, 2 of Class B, and 0 of Class C, leaving Class C completely un-evaluated
   *Explanation:* Without stratification, random chance in small sample sizes can lead to extreme sampling bias where a class is severely underrepresented or completely omitted from the test set, preventing fair evaluation.

**q2-10.** On the 2D scatter plot of sweetness vs. weight_g, which quadrant best describes the location of bananas?
   **Correct Answer:** b. High sweetness (> 7.0) and light weight (103-142 g)
   *Explanation:* Bananas occupy the bottom-right region of the sweetness vs. weight plot, characterized by high sweetness (7.2 to 8.8) and light weight (103g to 142g).

## Module 03

**q3-01.** What is the primary reason distance-based algorithms like KNN require feature scaling?
   **Correct Answer:** b. To prevent features with large numeric scales (like weight in grams) from dominating Euclidean distance over features with small scales
   *Explanation:* Because KNN measures proximity using Euclidean distance, features with large numbers (such as weight in hundreds of grams) dominate the sum of squared differences over small-scale features (such as sweetness from 3 to 9). Scaling places all features on equal footing.

**q3-02.** What is the mathematical equation for Z-score standardization implemented by StandardScaler?
   **Correct Answer:** b. z = (x - mean) / standard_deviation
   *Explanation:* StandardScaler implements Z-score standardization: z = (x - mean) / standard_deviation, which centers data at 0 and rescales variance to 1.

**q3-03.** What are the theoretical mean and standard deviation of any feature transformed by StandardScaler?
   **Correct Answer:** b. Mean = 0.0, Standard Deviation = 1.0
   *Explanation:* By definition, Z-score standardization shifts the mean of the transformed feature to 0.0 and divides by the standard deviation so the new standard deviation (and variance) equals 1.0.

**q3-04.** In scikit-learn, what is the critical difference between fit() and transform() on a StandardScaler?
   **Correct Answer:** a. fit() calculates and stores the mean and standard deviation; transform() applies those learned parameters to scale data
   *Explanation:* fit() computes the empirical mean and standard deviation of each feature and stores them in attributes (scaler.mean_, scaler.scale_). transform() applies the formula z = (x - mean) / std to produce the scaled dataset.

**q3-05.** Why must StandardScaler learn its parameters (mean and std) strictly from X_train and NEVER from X_test?
   **Correct Answer:** a. To prevent data leakage, ensuring test data remains an unseen evaluation benchmark
   *Explanation:* Learning parameters from X_test or the full dataset constitutes data leakage, because the test set is supposed to simulate unseen future data whose distributions cannot be known in advance.

**q3-06.** What distance metric does KNeighborsClassifier use by default in scikit-learn?
   **Correct Answer:** b. Minkowski distance with p=2 (standard Euclidean distance)
   *Explanation:* KNeighborsClassifier defaults to metric='minkowski' with p=2, which is mathematically equivalent to the standard Euclidean distance metric.

**q3-07.** Given two standardized 4D vectors A = [0, 0, 0, 0] and B = [1, 2, 2, 4], what is the Euclidean distance d(A, B)?
   **Correct Answer:** b. 5.0
   *Explanation:* The Euclidean distance is sqrt((1-0)^2 + (2-0)^2 + (2-0)^2 + (4-0)^2) = sqrt(1 + 4 + 4 + 16) = sqrt(25) = 5.0.

**q3-08.** What happens to the decision boundary of a KNN classifier when k is set to 1?
   **Correct Answer:** b. The boundary becomes highly complex and jagged, prone to overfitting and noise sensitivity
   *Explanation:* When k=1, the model bases its decision solely on the single closest training instance. This leads to high variance and jagged, complex decision boundaries that capture noise and outliers (overfitting).

**q3-09.** What occurs if you set n_neighbors equal to the total number of training samples (e.g., k=45 on a 45-sample training set)?
   **Correct Answer:** a. High bias (underfitting); the model queries every point in the dataset and predicts the overall majority class regardless of input features
   *Explanation:* When k equals the entire training set size, every single training sample casts a vote on every prediction query, resulting in high bias (underfitting) where the model simply predicts the overall majority class regardless of the input features.

**q3-10.** Why does a Decision Tree remain completely unaffected by feature scaling, whereas KNN is critically dependent on it?
   **Correct Answer:** b. Because Decision Trees evaluate monotonic splits on single features independently (e.g. weight > 150), whereas KNN computes joint geometric distances combining all features into a single metric
   *Explanation:* Decision Trees evaluate single-variable split thresholds independently (e.g. 'is weight > 150?'). The scale or magnitude of other features does not alter the split order. In contrast, KNN calculates a joint geometric distance across all dimensions simultaneously, making it scale-dependent.

## Module 04

**q4-01.** What are the two steps contained within the scikit-learn Pipeline in main.py?
   **Correct Answer:** b. ('scale', StandardScaler()) followed by ('knn', KNeighborsClassifier(n_neighbors=5))
   *Explanation:* In main.py lines 41-46, the pipeline explicitly chains ('scale', StandardScaler()) with ('knn', KNeighborsClassifier(n_neighbors=5)).

**q4-02.** What does model.predict(mystery)[0] return in main.py?
   **Correct Answer:** a. 'apple'
   *Explanation:* The mystery fruit is classified as 'apple' because all 5 of its nearest neighbors in standardized feature space are apples.

**q4-03.** What confidence percentage is reported for the mystery fruit in main.py?
   **Correct Answer:** c. 100% confident
   *Explanation:* The mystery fruit achieves 100% confidence because all 5 nearest neighbors belong to the apple class (5/5 = 1.00 = 100%).

**q4-04.** How is the mystery fruit DataFrame defined in main.py?
   **Correct Answer:** a. pd.DataFrame([{'sweetness': 7.2, 'weight_g': 170, 'size_cm': 8.5, 'color_score': 8.0}])
   *Explanation:* main.py lines 57-66 explicitly defines mystery with sweetness: 7.2, weight_g: 170, size_cm: 8.5, and color_score: 8.0 inside a list of dictionaries passed to pd.DataFrame().

**q4-05.** What occurs when model.fit(X_train, y_train) is called on the Pipeline?
   **Correct Answer:** a. It computes mean and variance of X_train, standardizes X_train, and fits the KNeighborsClassifier with the standardized data and training labels
   *Explanation:* When model.fit(X_train, y_train) is called on the pipeline, StandardScaler calculates mu and sigma, scales X_train, and then passes the scaled matrix to KNeighborsClassifier which stores the instances and builds neighbor indices.

**q4-06.** Why does calling model.predict(mystery) NOT require manually applying StandardScaler to mystery first?
   **Correct Answer:** b. Because the Pipeline automatically passes the input through each intermediate transformer's transform() method before calling predict()
   *Explanation:* scikit-learn Pipeline objects automatically invoke transform() on all intermediate preprocessing steps before passing data to the final estimator's predict() method, ensuring seamless, leak-free preprocessing.

**q4-07.** What does a confidence probability of 1.0 (100%) from model.predict_proba(mystery) signify for KNN with n_neighbors=5?
   **Correct Answer:** a. All 5 of the 5 closest training points in standardized feature space belong to the predicted class
   *Explanation:* In KNN, predict_proba computes the proportion of the k queried neighbors belonging to each class. A probability of 1.0 (5/5) means all 5 neighbors belong to the winning class.

**q4-08.** In what order are class probabilities arranged in the output array of predict_proba()?
   **Correct Answer:** b. In the order defined by model.classes_ (typically alphabetical: apple, banana, orange)
   *Explanation:* In scikit-learn classifiers, predict_proba columns correspond to the sorted classes listed in model.classes_ (for strings, alphabetically: 'apple', 'banana', 'orange').

**q4-09.** What is the primary architectural advantage of using Pipeline over sequential manual function calls?
   **Correct Answer:** a. It prevents data leakage between train and test data and encapsulates preprocessing and modeling into a single deployable unit
   *Explanation:* The Pipeline pattern prevents data leakage by ensuring transformers only learn parameters from training data and encapsulates all preprocessing and modeling steps into an atomic object suitable for deployment.

**q4-10.** If a query fruit produces predict_proba() output [0.60, 0.40, 0.0] with k=5, what were the class counts among its 5 nearest neighbors?
   **Correct Answer:** a. 3 apples, 2 bananas, 0 oranges
   *Explanation:* With k=5, 60% probability for apple corresponds to 0.60 * 5 = 3 apples, 40% probability for banana corresponds to 0.40 * 5 = 2 bananas, and 0% for orange corresponds to 0 oranges.

## Module 05

**q5-01.** What overall test accuracy does the Fruit Basket Sorter achieve in main.py?
   **Correct Answer:** c. 100.0%
   *Explanation:* The Fruit Basket Sorter achieves 100.0% accuracy on its test set, correctly predicting all 15 test items (5 apples, 5 bananas, and 5 oranges).

**q5-02.** In the classification report, what does 'support' represent?
   **Correct Answer:** b. The number of true instances of each class present in the test dataset
   *Explanation:* In scikit-learn classification reports, 'support' represents the ground-truth occurrence count of each class in the specified evaluation dataset.

**q5-03.** In a 3x3 multi-class confusion matrix, what do values along the main diagonal represent?
   **Correct Answer:** a. The number of correctly classified instances for each class (True Positives)
   *Explanation:* In a confusion matrix where rows are actuals and columns are predictions, diagonal cells where row index equals column index represent correctly classified samples (True Positives).

**q5-04.** Which formula defines Precision for a given class?
   **Correct Answer:** a. TP / (TP + FP)
   *Explanation:* Precision is the ratio of true positive predictions to the total predicted positive instances: TP / (TP + FP).

**q5-05.** Which formula defines Recall for a given class?
   **Correct Answer:** b. TP / (TP + FN)
   *Explanation:* Recall is the ratio of correctly identified positive instances to all actual positive instances: TP / (TP + FN).

**q5-06.** Why are macro average and weighted average identical in the classification report of main.py?
   **Correct Answer:** b. Because all three classes have identical support (5 samples each) in the stratified test set
   *Explanation:* Macro average is the unweighted mean across classes, while weighted average weights each class by its support. Because each fruit has an identical support of 5 samples, the weighting factors (5/15) are equal, making the two averages mathematically identical.

**q5-07.** What is the purpose of passing zero_division=0 to classification_report()?
   **Correct Answer:** b. To prevent warnings and assign 0.0 when a class has 0 predicted instances
   *Explanation:* zero_division=0 instructs scikit-learn to return 0.0 without printing runtime warnings when a class receives 0 predictions, avoiding division by zero in precision calculations.

**q5-08.** In the scatter plot in main.py, why is zorder=5 applied to the mystery fruit point?
   **Correct Answer:** a. To render the star marker on top of all other data points so it is never obscured
   *Explanation:* In matplotlib, zorder controls the drawing layer. Setting zorder=5 ensures that the mystery fruit's black star marker is drawn above the background scatter dots (default zorder=2), guaranteeing it is completely visible.

**q5-09.** If a classifier achieves Precision=1.00 and Recall=0.60 on a minority class, what is its F1-Score?
   **Correct Answer:** b. 0.75
   *Explanation:* F1 is the harmonic mean: 2 * (P * R) / (P + R) = 2 * (1.00 * 0.60) / (1.00 + 0.60) = 1.20 / 1.60 = 0.75.

**q5-10.** If row 1 of a confusion matrix has counts [4, 1, 0] for sorted classes ['apple', 'banana', 'orange'], what does the number 1 represent?
   **Correct Answer:** b. 1 true apple misclassified as a banana
   *Explanation:* In a confusion matrix, rows represent actual true classes (Row 1 = Apple) and columns represent predictions (Col 2 = Banana). A 1 in Row 1, Col 2 indicates that 1 actual Apple was mistakenly predicted as a Banana.

## Module 06

**q6-01.** What terminal command is used to run the fruit basket sorter script from its directory?
   **Correct Answer:** a. python main.py
   *Explanation:* The command python main.py executes the primary Python script from the project root directory.

**q6-02.** Which three files are created in the outputs/ directory by main.py?
   **Correct Answer:** b. fruit_scatter.png, confusion_matrix.png, metrics.txt
   *Explanation:* main.py saves exactly three files to the outputs/ directory: fruit_scatter.png (scatter plot), confusion_matrix.png (confusion matrix display), and metrics.txt (accuracy, inference log, and classification report).

**q6-03.** What standard Python idiom at the bottom of main.py ensures the script only executes when run directly?
   **Correct Answer:** b. if __name__ == '__main__': main()
   *Explanation:* if __name__ == '__main__': main() is the standard Python entry point guard, ensuring that main() is only invoked when the file is run directly, and not when imported as a module.

**q6-04.** What encoding is explicitly passed to open() when writing outputs/metrics.txt?
   **Correct Answer:** b. encoding='utf-8'
   *Explanation:* main.py line 110 explicitly specifies encoding='utf-8' when calling open() to ensure consistent, cross-platform UTF-8 text processing without relying on OS defaults.

**q6-05.** Why does DecisionTreeClassifier NOT require a StandardScaler in its pipeline?
   **Correct Answer:** a. Because Decision Trees evaluate single-feature split thresholds (e.g. weight > 150) based on value order rather than geometric distance
   *Explanation:* Decision Trees evaluate split rules on individual features independently (e.g. 'is weight_g > 150?'). The monotonic ordering of values is preserved regardless of scale, making trees completely scale-invariant.

**q6-06.** What is the primary computational disadvantage of KNN when deployed on massive datasets (e.g., millions of rows)?
   **Correct Answer:** b. Inference is slow because it must compute distances between the query sample and all stored training samples (O(N*D))
   *Explanation:* Because KNN stores training data and delays computation until query time, computing Euclidean distances across millions of high-dimensional vectors at inference time becomes computationally expensive (O(N*D)).

**q6-07.** Which Python library is standard for serializing (saving) and deserializing (loading) scikit-learn Pipeline objects?
   **Correct Answer:** a. joblib
   *Explanation:* joblib is the recommended standard library in scikit-learn for saving (joblib.dump) and loading (joblib.load) trained estimators and pipelines with large NumPy array buffers.

**q6-08.** In an industrial automated conveyor sorting system, what should happen if a fruit's prediction confidence is below 70%?
   **Correct Answer:** b. The fruit should be routed to a manual inspection station for human verification rather than misrouted automatically
   *Explanation:* In real-world automation, samples with low model confidence should be routed to a secondary inspection station for manual human review, preventing automated misclassification and packaging errors.

**q6-09.** Why is deserializing untrusted .joblib or .pkl files downloaded from unknown public URLs dangerous?
   **Correct Answer:** b. Python pickle-based formats can execute arbitrary malicious code upon deserialization
   *Explanation:* Python's pickle and joblib formats serialize arbitrary Python objects. When loading an untrusted file, the unpickling process can construct malicious executable objects, allowing remote code execution.

**q6-10.** What experiment does line 116 of main.py explicitly recommend students try?
   **Correct Answer:** a. Change n_neighbors from 5 to 1 or 9 and compare the results
   *Explanation:* Line 116 of main.py explicitly prints: 'Try this: change n_neighbors from 5 to 1 or 9 and compare.' encouraging students to explore hyperparameter tuning.
