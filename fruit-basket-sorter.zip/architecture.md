# Architecture & System Design: The Fruit Basket Sorter

This document outlines the complete architectural design, component interactions, data flow, and pipeline lifecycle for **The Fruit Basket Sorter** machine learning project.

---

## 1. High-Level Architecture

The system implements a classic **Supervised Multi-Class Classification Pipeline** using modern scikit-learn abstractions. The architecture is intentionally decoupled into distinct stages:
1. **Environment & Backend Initialization** (Headless graphics)
2. **Data Ingestion & Feature Engineering** (Tabular extraction)
3. **Stratified Sampling** (Balanced partition)
4. **Pipeline Construction & Fitting** (StandardScaler + KNeighborsClassifier)
5. **Model Evaluation & Reporting** (Accuracy, multi-class metrics, confusion matrix)
6. **Inference / Mystery Fruit Scoring** (Single sample prediction & class probability)
7. **Artifact Export & Storage** (Raster plots and metric text logs)

```mermaid
flowchart TD
    A["Raw Dataset: data/fruits.csv\n(60 rows x 5 columns)"] --> B["pandas DataFrame Ingestion\nX: 4 Features | y: Target Class"]
    B --> C["Stratified Train/Test Split (75/25)\nTrain: 45 samples | Test: 15 samples"]
    C --> D["scikit-learn Pipeline\nStep 1: StandardScaler\nStep 2: KNeighborsClassifier(k=5)"]
    D --> E["Model Training\nPipeline.fit(X_train, y_train)"]
    E --> F["Batch Test Evaluation\npredictions = Pipeline.predict(X_test)"]
    E --> G["Mystery Fruit Inference\nSingle-row DataFrame (sweetness=7.2, ...)"]
    F --> H["Metrics & Confusion Matrix\nAccuracy: 100%\nPrecision/Recall/F1"]
    G --> I["Inference Result\nApple (100% confidence)"]
    H --> J["Artifact Outputs\n- outputs/fruit_scatter.png\n- outputs/confusion_matrix.png\n- outputs/metrics.txt"]
    I --> J
```

---

## 2. Key Components Breakdown

### 2.1 Headless Configuration (`lines 12-15`)
- `matplotlib.use("Agg")` is declared before importing `pyplot`.
- **Purpose**: Bypasses X11 or Wayland windowing systems, preventing GUI crashes in headless servers, Docker containers, and CI/CD automated runners.

### 2.2 Ingestion & Feature Matrix (`lines 23-35`)
- Paths are resolved relative to the file location using `Path(__file__).resolve().parent`.
- `FEATURES = ["sweetness", "weight_g", "size_cm", "color_score"]`: 4 continuous numeric inputs.
- `y = df["fruit"]`: Target discrete label spanning 3 classes (`apple`, `banana`, `orange`).

### 2.3 Stratified Train/Test Partitioning (`lines 37-39`)
- `test_size=0.25`: Allocates 75% (45 instances) to training and 25% (15 instances) to evaluation.
- `random_state=42`: Guarantees deterministic, reproducible splits across systems.
- `stratify=y`: Crucial parameter ensuring each class contributes exactly 15 samples to training and 5 samples to testing.

### 2.4 The scikit-learn Pipeline (`lines 41-46`)
- Encapsulates preprocessing and classification into a unified estimator:
  1. **`scale`**: `StandardScaler()` scales each feature such that $\mu = 0$ and $\sigma = 1$.
  2. **`knn`**: `KNeighborsClassifier(n_neighbors=5)` searches for the 5 closest training instances in the 4-dimensional standardized Euclidean space.
- **Data Leakage Prevention**: When `model.fit(X_train, y_train)` is called, the scaler computes mean and variance strictly on `X_train`. When `model.predict(X_test)` is executed, the test features are transformed using the training parameters, preventing data leakage.

### 2.5 Inference Engine (`lines 57-70`)
- Defines a mystery fruit: `sweetness: 7.2`, `weight_g: 170`, `size_cm: 8.5`, `color_score: 8.0`.
- Executes `model.predict(mystery)` to determine the winning class (`apple`).
- Executes `model.predict_proba(mystery)` to compute class-level probabilities based on neighbor proportions ($5/5 = 1.0$).

### 2.6 Visualization & Artifact Generation (`lines 72-114`)
- **Scatter Plot (`fruit_scatter.png`)**: Projects the multi-dimensional dataset onto 2 key dimensions (`sweetness` vs. `weight_g`), colored with custom fruit hex codes:
  - Apple: `#c0392b` (Deep red)
  - Banana: `#f1c40f` (Vibrant yellow)
  - Orange: `#e67e22` (Warm orange)
  - Mystery Fruit: Plotted with marker `*`, size `s=260`, color `#111111`, and `zorder=5` for foreground visibility.
- **Confusion Matrix (`confusion_matrix.png`)**: Visualizes classification performance across all 3 classes using `ConfusionMatrixDisplay` with the `Oranges` colormap.
- **Metrics Log (`metrics.txt`)**: Stores evaluation metrics, mystery fruit prediction, and full precision/recall/support breakdown.

---

## 3. Data Flow Diagram

```mermaid
sequenceDiagram
    autonumber
    actor User as Student / Developer
    participant Script as main.py
    participant Disk as File System (data/ & outputs/)
    participant Scaler as StandardScaler
    participant KNN as KNeighborsClassifier

    User->>Script: Run python main.py
    Script->>Disk: Read data/fruits.csv
    Disk-->>Script: Tabular Data (60 rows)
    Script->>Script: Split into Train (45) and Test (15) with stratify=y
    Script->>Scaler: Fit on X_train (Calculate mean & std)
    Scaler-->>Script: Scaled X_train
    Script->>KNN: Fit on Scaled X_train with y_train
    Script->>Scaler: Transform X_test
    Script->>KNN: Predict on Scaled X_test
    KNN-->>Script: Test Predictions (100% Accuracy)
    Script->>Scaler: Transform Mystery Fruit [7.2, 170, 8.5, 8.0]
    Script->>KNN: Predict & Predict_proba (Mystery Fruit)
    KNN-->>Script: Result: Apple (100% Confident)
    Script->>Disk: Write fruit_scatter.png
    Script->>Disk: Write confusion_matrix.png
    Script->>Disk: Write metrics.txt
    Script-->>User: Console output complete
```

---

## 4. Pipeline Design Decisions & Rationale

| Architectural Decision | Chosen Strategy | Alternative Considered | Technical Justification |
|---|---|---|---|
| **Feature Scaling** | `StandardScaler` inside `Pipeline` | Normalizing manually with min-max | Weight (100–240g) would dwarf sweetness (3–9) in distance metrics; Pipeline prevents data leakage between train and test splits. |
| **Classifier Choice** | `KNeighborsClassifier(n_neighbors=5)` | Logistic Regression / Decision Tree | Demonstrates instance-based geometric classification; intuitive "nearest neighbors" concept ideal for introductory ML. |
| **Splitting Strategy** | `stratify=y` with `random_state=42` | Random split without stratification | Guarantees exact class balance (5 test instances per fruit class); ensures test metrics are strictly representative. |
| **Inference Representation** | `pd.DataFrame` with column names | NumPy array `[[7.2, 170, ...]]` | Preserves feature names, avoids scikit-learn feature name mismatch warnings, and mirrors real production schema validation. |
