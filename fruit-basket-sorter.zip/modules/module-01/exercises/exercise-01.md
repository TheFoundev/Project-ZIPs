# Module 1 Exercises: Project Overview & Problem Understanding

---

## Exercise 1.1: Multi-Class Problem Formulation (10 min)
**Objective:** Distinguish supervised multi-class classification from binary classification and regression.  
**Problem Statement:** In The Fruit Basket Sorter, the algorithm sorts fruit into apples, bananas, and oranges based on measurements. You must formally classify the machine learning problem type and articulate why regression or binary classification is inappropriate.

**Requirements:**
1. Define supervised learning in the context of the fruit sorting task.
2. Define multi-class classification and state the 3 target classes.
3. Explain why regression cannot be used for this task.
4. Contrast this with binary classification.

**Constraints:** Base your answers on the problem defined in `main.py` and `fruits.csv`.

**Expected Behaviour:** A concise 1-page markdown or text document defining each concept clearly and justifying why this task is supervised multi-class classification.

**Acceptance Criteria:**
- [ ] Supervised learning is correctly defined using labeled pairs $(X, y)$.
- [ ] Multi-class classification is identified, listing `apple`, `banana`, and `orange`.
- [ ] The reason regression does not apply (discrete non-ordered categories vs continuous numbers) is explicitly explained.
- [ ] The distinction from binary classification (3 classes vs 2 classes) is stated.

**Hints:**
- Consider whether an apple is mathematically "greater than" a banana.
- Review Lesson 01 for problem categorization.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes  

---

## Exercise 1.2: Feature and Target Matrix Dissection (15 min)
**Objective:** Inspect the dataset and verify the dimensions of the feature matrix $X$ and target vector $y$.  
**Problem Statement:** You must verify that `main.py` correctly extracts the 4 feature columns into a 2D matrix and the class column into a 1D vector.

**Requirements:**
1. Write a Python script or interactive session that loads `data/fruits.csv`.
2. Extract $X$ using `FEATURES = ["sweetness", "weight_g", "size_cm", "color_score"]`.
3. Extract $y$ using `df["fruit"]`.
4. Print the shape and data type of $X$ and $y$.
5. Verify that $X$ contains 60 rows and 4 columns, and $y$ contains 60 string labels.

**Constraints:** Use pandas and the actual CSV at `data/fruits.csv`. Do not alter the CSV file.

**Expected Behaviour:** Terminal output displaying `X.shape == (60, 4)` and `y.shape == (60,)`.

**Acceptance Criteria:**
- [ ] All 4 feature names match `main.py`: `sweetness`, `weight_g`, `size_cm`, `color_score`.
- [ ] $X$ is a pandas DataFrame of shape `(60, 4)`.
- [ ] $y$ is a pandas Series of shape `(60,)`.
- [ ] The 3 unique values of $y$ (`apple`, `banana`, `orange`) are printed.

**Hints:**
- Use `df[FEATURES]` (passing a list) to get a DataFrame.
- Use `df['fruit'].unique()` to see the distinct classes.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 1.3: Geometric Distance & Nearest Neighbour Voting (15 min)
**Objective:** Calculate manual 1D/2D Euclidean distances and simulate a 5-nearest neighbours voting process.  
**Problem Statement:** Given a new fruit with known measurements, calculate its distance to 6 historical fruits and determine the winning predicted class using $k=5$.

**Requirements:**
1. Given Query Fruit: `Sweetness = 7.0, Weight = 160g`.
2. Historical Fruit Database:
   - F1 (Apple): Sweetness = 7.1, Weight = 165g
   - F2 (Apple): Sweetness = 6.8, Weight = 158g
   - F3 (Apple): Sweetness = 7.2, Weight = 162g
   - F4 (Banana): Sweetness = 8.5, Weight = 110g
   - F5 (Orange): Sweetness = 5.0, Weight = 195g
   - F6 (Apple): Sweetness = 6.5, Weight = 155g
3. Calculate Euclidean distance $d = \sqrt{(s_2 - s_1)^2 + (w_2 - w_1)^2}$ from Query to each fruit.
4. Select the $k=5$ closest fruits.
5. Count the votes for each class and state the prediction and confidence percentage.

**Constraints:** Show all distance calculations clearly.

**Expected Behaviour:** Step-by-step arithmetic showing distances, ranked list of 5 nearest neighbors, and final classification vote.

**Acceptance Criteria:**
- [ ] Correct distance calculated for all 6 points.
- [ ] Top 5 closest points correctly identified.
- [ ] Correct predicted class (Apple) with voting confidence stated.

**Hints:**
- Notice how weight differences (e.g. 5 grams) dwarf sweetness differences (e.g. 0.1 units) without scaling!
- The 4 apples will have distances under 10, whereas banana and orange will have distances > 35.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 1.4: Script Execution & Directory Architecture Verification (10 min)
**Objective:** Execute `main.py` and programmatically verify the existence and integrity of all output files.  
**Problem Statement:** Verify that the project runs cleanly end-to-end and creates `outputs/fruit_scatter.png`, `outputs/confusion_matrix.png`, and `outputs/metrics.txt`.

**Requirements:**
1. Run `python main.py` from the project root.
2. Write a short Python validation script that checks:
   - `outputs/fruit_scatter.png` exists and is non-empty (>10 KB).
   - `outputs/confusion_matrix.png` exists and is non-empty (>10 KB).
   - `outputs/metrics.txt` exists and contains the string `"accuracy: 1.0000"`.
3. Print `"All verification checks passed!"` upon success.

**Constraints:** Must use `pathlib.Path` to perform the checks.

**Expected Behaviour:** Successful run of `main.py` followed by validation script confirming all 3 artifacts exist.

**Acceptance Criteria:**
- [ ] `main.py` executes with exit code 0.
- [ ] All 3 output files verified with `pathlib.Path.exists()`.
- [ ] File sizes verified greater than 0.
- [ ] Text content in `metrics.txt` verified.

**Hints:**
- Use `p = Path("outputs/metrics.txt"); "accuracy: 1.0000" in p.read_text()` to verify content.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 10 minutes  
