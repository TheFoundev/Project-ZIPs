# Lesson 01: The Fruit Basket Problem & Supervised Classification

**Lesson ID:** lesson-01  
**Module:** module-01  
**Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- State the real-world operational problem that **The Fruit Basket Sorter** solves.
- Explain why sorting fruit into discrete categories is a **classification** task rather than a **regression** task.
- Distinguish between **binary classification** and **multi-class classification**.
- Define what makes this task **supervised learning**.
- Identify the inputs and outputs defined in the project script.

---

## 2. Prerequisites
- Basic familiarity with Python variables and print statements.
- An understanding of what tabular data (rows and columns) looks like.

---

## 3. Concept Explanation

### The Agricultural Sorting Problem
In modern agricultural processing plants, millions of pieces of produce pass through conveyor belts daily. Manual sorting by human workers is slow, fatigue-prone, and inconsistent. Automated sorting facilities use optical scanners and load cells to measure fruit attributes in real time—such as sweetness (brix rating), weight in grams, physical diameter, and color chromaticity. 

The machine learning system must examine these measurements and immediately answer: **"Which fruit is this: an apple, a banana, or an orange?"**

### Why is this Classification (and not Regression)?
In machine learning, supervised problems fall into two primary branches:
- **Regression**: Predicts a **continuous numeric quantity** (e.g., predicting the exact temperature in Celsius, price in dollars, or number of cups of lemonade sold). The output is an infinite continuum of possible numbers.
- **Classification**: Predicts a **discrete category or class label** (e.g., "apple", "banana", or "orange"). The output belongs to a predefined set of categories.

Because a fruit cannot be "2.7 apples" or "-1.4 oranges", this is fundamentally a **classification** problem.

### Binary vs. Multi-Class Classification
- **Binary Classification**: Distinguishes between exactly two mutually exclusive classes (e.g., spam vs. not spam, fraud vs. legitimate, defective vs. good).
- **Multi-Class Classification**: Distinguishes among **three or more** distinct classes. In our project, the target variable $y$ contains three classes:
  1. `apple`
  2. `banana`
  3. `orange`

### Why is this Supervised Learning?
This system is an example of **supervised learning** because the model learns from historical records where **both the input measurements and the true class label are known**. Our dataset contains 60 labeled examples. The algorithm examines the patterns connecting measurements to fruit types, allowing it to predict the correct label for new, unseen fruits.

---

## 4. Relevant Code (from main.py, lines 1-8, 28-30)

```python
"""Project 05: The Fruit Basket Sorter (K-Nearest Neighbours).

Run:
    python main.py

Fruits are described by sweetness, weight, size, and colour.  The model
classifies a mystery fruit by finding the most similar training examples.
"""
...
FEATURES = ["sweetness", "weight_g", "size_cm", "color_score"]
COLOURS = {"apple": "#c0392b", "banana": "#f1c40f", "orange": "#e67e22"}
```

---

## 5. Code Explanation
- **Lines 1-8**: The module docstring summarizes the objective: classify an unlabelled mystery fruit by comparing its physical attributes against known training examples.
- **Line 28 (`FEATURES`)**: Defines the 4 quantitative measurements that describe each fruit. These form our independent variables ($X$).
- **Line 29 (`COLOURS`)**: Defines a color lookup dictionary mapping the 3 target classes (`apple`, `banana`, `orange`) to hex codes for visual identification.

---

## 6. Worked Example

**Scenario:** Suppose a sensor records a fruit with:
- Sweetness: 8.5
- Weight: 110 g
- Size: 17.0 cm
- Color score: 6.8

**Analysis:**
1. Is this a classification or regression task?  
   *Answer:* Classification, because we must predict whether it is an apple, a banana, or an orange.
2. How many classes are possible?  
   *Answer:* Three classes (`apple`, `banana`, `orange`). Therefore, it is a multi-class classification problem.
3. Looking at the measurements:
   - Weight is light (110 g).
   - Size is elongated (17.0 cm).
   - Sweetness is high (8.5).
   *Intuition:* This profile strongly matches the known physical properties of a **banana**.

---

## 7. Step-by-Step Student Instructions

1. Open your terminal and navigate to `beginner-projects-main/AI-ML Beginners/projects/05_fruit_sorter`.
2. Open `main.py` in your code editor.
3. Read lines 1 to 30 of `main.py`.
4. Identify the list assigned to `FEATURES` (line 28).
5. Identify the three keys present in `COLOURS` (line 29).
6. Verify in your mind why this task cannot be solved using a standard linear regression line $y = mx + c$.

---

## 8. Expected Output or Observable Behaviour

When you examine the file, you observe that `FEATURES` contains exactly 4 strings:
```python
['sweetness', 'weight_g', 'size_cm', 'color_score']
```
And `COLOURS` associates each fruit class with a distinct hex color:
- `apple`: `#c0392b` (Crimson red)
- `banana`: `#f1c40f` (Banana yellow)
- `orange`: `#e67e22` (Citrus orange)

---

## 9. Practical Exercises

- **Exercise 1.1**: Formulate in your own words why predicting the weight of a fruit is regression, but predicting the fruit type is classification.
- **Exercise 1.2**: List two other agricultural produce items (e.g., lemon, watermelon) and hypothesize what numeric features could be used to classify them.
- **Exercise 1.3**: Explain what makes this machine learning problem "supervised" rather than "unsupervised".
- **Exercise 1.4**: If a dataset contains 100 samples with labels "fresh", "ripe", and "spoiled", what type of machine learning problem is this?

---

## 10. Common Mistakes and Debugging

| Mistake | Why it is incorrect | Correction |
|---|---|---|
| Thinking KNN is for regression only | KNN can perform both regression and classification | In this project, `KNeighborsClassifier` is used for multi-class classification |
| Treating class labels as continuous numbers | Apples, bananas, and oranges have no intrinsic numerical ordering | Use categorical strings or encoded class labels, not continuous floats |
| Confusing features ($X$) with target ($y$) | Features are inputs; target is what we want to predict | `FEATURES` are the 4 measurements; `fruit` is the target label |

---

## 11. Best Practices and Security Considerations

- **Problem Type Alignment**: Always determine whether your target variable is categorical or continuous before selecting an algorithm.
- **Data Validation**: Ensure labels are cleanly categorized without typos (e.g., "Apple" vs. "apple").
- **Local Execution**: The project processes local tabular data and does not expose ports or transmit sensitive personal data.

---

## 12. Summary

The Fruit Basket Sorter is a supervised multi-class classification project. It takes four numeric measurements—sweetness, weight in grams, size in centimeters, and color score—to classify an unknown fruit into one of three predefined categories: apple, banana, or orange. Supervised learning relies on labeled training pairs $(X, y)$ to discover patterns that generalize to unlabelled samples.

---

## 13. Knowledge-check Questions

1. What are the three fruit classes recognized by this project?
2. Why is predicting fruit type considered classification rather than regression?
3. How many input features describe each fruit in the dataset?
4. What does the term "supervised learning" imply about the training dataset?
5. What is the difference between binary classification and multi-class classification?

---

## 14. References

- scikit-learn Supervised Learning Overview: [https://scikit-learn.org/stable/supervised_learning.html](https://scikit-learn.org/stable/supervised_learning.html)
- Machine Learning Classification Guide: [https://scikit-learn.org/stable/tutorial/basic/tutorial.html](https://scikit-learn.org/stable/tutorial/basic/tutorial.html)
- `main.py` lines 1-30 in `beginner-projects-main/AI-ML Beginners/projects/05_fruit_sorter`
