# Lesson 04: Project Architecture & Execution Workflow

**Lesson ID:** lesson-04  
**Module:** module-01  
**Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Trace the complete end-to-end execution flow of `main.py`.
- Explain how `pathlib.Path` manages cross-platform directories (`BASE`, `DATA`, `OUT`).
- Understand why `matplotlib.use("Agg")` is required before importing pyplot.
- Identify all generated output files and where they are persisted on disk.
- Run the script and interpret high-level terminal logs.

---

## 2. Prerequisites
- Completion of Lessons 01, 02, and 03.
- Basic terminal and Python command execution skills.

---

## 3. Concept Explanation

### The Anatomy of an ML Application
A production-ready machine learning script must handle more than just calling `.fit()`. It requires structured pipeline steps:
1. **Environment Setup**: Configuring rendering engines and OS paths.
2. **Data Pipeline**: Ingestion, validation, and stratified splitting.
3. **Model Construction**: Pairing preprocessing transformers with estimators.
4. **Validation & Assessment**: Computing metrics on held-out test data.
5. **Operational Inference**: Scoring new production queries (e.g., the mystery fruit).
6. **Artifact Persistence**: Saving diagnostic plots and text reports.

### Cross-Platform Directory Paths with `pathlib`
Instead of using fragile string manipulation or hardcoded slashes (which break across Windows and POSIX systems), modern Python uses `pathlib.Path`:
- `BASE = Path(__file__).resolve().parent`: Resolves the absolute directory of `main.py`.
- `DATA = BASE / "data"`: Resolves the dataset directory cleanly.
- `OUT = BASE / "outputs"`: Resolves the output directory.
- `OUT.mkdir(exist_ok=True)`: Creates the folder if it does not already exist, avoiding crash errors.

### Headless Rendering with Matplotlib Agg
In automated environments, Docker containers, or headless server instances, there is no graphical monitor (X11 or Wayland display server). If a script attempts to launch an interactive GUI window, it crashes with a `TclError` or display error.
Calling `matplotlib.use("Agg")` before importing `pyplot` tells matplotlib to render plots entirely in memory and export directly to raster files (like PNG) without requiring a GUI window.

---

## 4. Relevant Code (from main.py, lines 10-16, 23-26, 110-120)

```python
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
...
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "outputs"
OUT.mkdir(exist_ok=True)
...
    with open(OUT / "metrics.txt", "w", encoding="utf-8") as handle:
        handle.write(f"accuracy: {accuracy:.4f}\n")
        handle.write(f"mystery prediction: {mystery_prediction} ({mystery_probability:.4f})\n\n")
        handle.write(classification_report(y_test, predictions, zero_division=0))

    print("\nSaved: outputs/fruit_scatter.png, outputs/confusion_matrix.png, outputs/metrics.txt")
    print("Try this: change n_neighbors from 5 to 1 or 9 and compare.")

if __name__ == "__main__":
    main()
```

---

## 5. Code Explanation
- **Lines 12-15**: `matplotlib.use("Agg")` is invoked before `import matplotlib.pyplot as plt`, enforcing headless file-only rendering.
- **Lines 23-26**: `Path(__file__).resolve().parent` establishes the project root; `OUT.mkdir(exist_ok=True)` guarantees the destination folder exists before saving.
- **Lines 110-114**: Opens `outputs/metrics.txt` using a context manager (`with open(...)`) and writes accuracy, mystery prediction, and the classification report formatted with UTF-8 encoding.
- **Lines 119-120**: The standard Python idiom `if __name__ == "__main__": main()` ensures `main()` executes when the file is run directly from the CLI.

---

## 6. Worked Example

**Question:** What happens if `outputs/` does not exist on your computer when you run `python main.py`?

**Walkthrough:**
1. Python executes line 23: `BASE` becomes `/home/aziz/.../05_fruit_sorter`.
2. Python executes line 25: `OUT` becomes `/home/aziz/.../05_fruit_sorter/outputs`.
3. Python executes line 26: `OUT.mkdir(exist_ok=True)`. The operating system creates the directory `outputs/`.
4. If the directory already existed, `exist_ok=True` prevents an `OSError: [Errno 17] File exists`.
5. Later in the script, `fig.savefig(OUT / "fruit_scatter.png")` and `open(OUT / "metrics.txt")` succeed without errors.

---

## 7. Step-by-Step Student Instructions

1. Open your terminal.
2. Navigate to `beginner-projects-main/AI-ML Beginners/projects/05_fruit_sorter`.
3. Run the script:
   ```bash
   python main.py
   ```
4. Verify that the console prints the header, accuracy (100.0%), classification report, and mystery fruit result.
5. Inspect the generated directory:
   ```bash
   ls outputs/
   ```
6. Confirm the presence of `fruit_scatter.png`, `confusion_matrix.png`, and `metrics.txt`.

---

## 8. Expected Output or Observable Behaviour

Terminal output:
```text
============================================================
THE FRUIT BASKET SORTER
============================================================
Accuracy: 100.0%

              precision    recall  f1-score   support

       apple       1.00      1.00      1.00         5
      banana       1.00      1.00      1.00         5
      orange       1.00      1.00      1.00         5

    accuracy                           1.00        15
   macro avg       1.00      1.00      1.00        15
weighted avg       1.00      1.00      1.00        15

Mystery fruit -> apple (100% confident)

Saved: outputs/fruit_scatter.png, outputs/confusion_matrix.png, outputs/metrics.txt
Try this: change n_neighbors from 5 to 1 or 9 and compare.
```

Files verified in `outputs/`:
- `fruit_scatter.png` (approx. 70-120 KB)
- `confusion_matrix.png` (approx. 30-60 KB)
- `metrics.txt` (approx. 500 bytes)

---

## 9. Practical Exercises

- **Exercise 4.1**: Delete the `outputs/` folder and re-run `python main.py`. Does it automatically recreate the folder?
- **Exercise 4.2**: Change `matplotlib.use("Agg")` to appear after `import matplotlib.pyplot as plt`. What warning or behavior do you observe?
- **Exercise 4.3**: Open `outputs/metrics.txt` in your text editor and verify that the contents match the console printout.
- **Exercise 4.4**: Explain what would happen if line 26 `OUT.mkdir(exist_ok=True)` was omitted and the `outputs/` folder did not exist.

---

## 10. Common Mistakes and Debugging

| Mistake | Why it is incorrect | Correction |
|---|---|---|
| Placing `matplotlib.use("Agg")` after `import matplotlib.pyplot as plt` | Backend must be configured before Pyplot initializes | Always place `matplotlib.use("Agg")` immediately after `import matplotlib` |
| Using string concatenation for paths (`BASE + "/data"`) | Fragile; causes path separator errors on Windows vs. Linux | Use `pathlib.Path` and the `/` operator |
| Omitting `exist_ok=True` in `mkdir()` | Throws `FileExistsError` if folder already exists | Always include `exist_ok=True` when creating directories |

---

## 11. Best Practices and Security Considerations

- **Headless Portability**: Always configure non-interactive backends for scripts intended for batch processing, automated testing, or cloud deployments.
- **Resource Cleanup**: Always call `plt.close(fig)` after saving to release memory buffers, especially when running multiple plotting tasks.
- **Explicit File Encodings**: Always pass `encoding="utf-8"` when calling `open()` to ensure consistent cross-platform text processing.

---

## 12. Summary

`main.py` is structured as a complete, robust machine learning script. It uses `pathlib` for resilient cross-platform filesystem management and the `Agg` headless matplotlib backend for non-interactive image generation. The pipeline ingests tabular fruit measurements, trains and evaluates a standardized KNN classifier, scores an unlabelled mystery fruit, and writes all diagnostic charts and evaluation logs to the `outputs/` directory.

---

## 13. Knowledge-check Questions

1. Why must `matplotlib.use("Agg")` be called before importing `matplotlib.pyplot`?
2. What does `Path(__file__).resolve().parent` return?
3. What is the role of `exist_ok=True` in `OUT.mkdir(exist_ok=True)`?
4. What three artifact files are written to the `outputs/` directory?
5. Why is `plt.close(fig)` called after saving each figure?

---

## 14. References

- Python `pathlib` documentation: [https://docs.python.org/3/library/pathlib.html](https://docs.python.org/3/library/pathlib.html)
- Matplotlib backends guide: [https://matplotlib.org/stable/users/explain/backends.html](https://matplotlib.org/stable/users/explain/backends.html)
- `main.py` lines 10-26, 110-120
