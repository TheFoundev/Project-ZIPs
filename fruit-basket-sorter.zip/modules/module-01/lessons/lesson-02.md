# Lesson 02: Physical Measurements: The 4 Fruit Features

**Lesson ID:** lesson-02  
**Module:** module-01  
**Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Identify each of the 4 continuous numeric features used in `main.py`.
- Explain how tabular datasets separate the feature matrix ($X$) from the target vector ($y$).
- Describe the physical meaning and typical numerical range of each measurement.
- Inspect the relationship between feature matrices and pandas DataFrames.

---

## 2. Prerequisites
- Completion of Lesson 01.
- Basic understanding of pandas column indexing (`df[FEATURES]` vs. `df["fruit"]`).

---

## 3. Concept Explanation

### The Anatomy of Tabular Data
In tabular machine learning, data is arranged in a 2-dimensional grid:
- **Rows** correspond to individual instances (samples or observations). In our project, each row is a single piece of harvested fruit.
- **Columns** correspond to either measured attributes (features) or the outcome label (target).

### The Four Input Features ($X$)
In `main.py`, the independent variables are defined in the list `FEATURES`:
1. **`sweetness`**: A continuous numeric score representing sugar content (analogous to the Brix scale used in agriculture). Values typically range between 3.5 and 9.0.
2. **`weight_g`**: The mass of the fruit measured in grams on a scale. Values typically range between 100 g and 240 g.
3. **`size_cm`**: The primary physical dimension or length in centimeters. Values range between 7.0 cm (compact round fruits) and 19.0 cm (elongated fruits).
4. **`color_score`**: An optical color index derived from light reflectance sensors (e.g., scoring red/yellow chromaticity on a scale from 4.0 to 10.0).

### The Target Variable ($y$)
The column `fruit` (also known as `label` in educational settings) contains the ground-truth category for each row. In our dataset, every row is labeled as either `"apple"`, `"banana"`, or `"orange"`.

### Mathematical Representation: $X$ and $y$
- $X$ is a 2D matrix of shape $(N, 4)$, where $N=60$ samples and each sample has 4 numbers.
- $y$ is a 1D vector of shape $(N,)$ containing $N=60$ class strings.

---

## 4. Relevant Code (from main.py, lines 28, 33-35)

```python
FEATURES = ["sweetness", "weight_g", "size_cm", "color_score"]
...
def main() -> None:
    df = pd.read_csv(DATA / "fruits.csv")
    X = df[FEATURES]
    y = df["fruit"]
```

---

## 5. Code Explanation
- **Line 28 (`FEATURES`)**: Defines a reusable Python list holding the names of the 4 feature columns.
- **Line 33 (`pd.read_csv`)**: Reads the tabular CSV file from disk into a pandas DataFrame named `df`.
- **Line 34 (`X = df[FEATURES]`)**: Selects only the 4 feature columns, creating a 2D DataFrame $X$ of shape $(60, 4)$.
- **Line 35 (`y = df["fruit"]`)**: Extracts the single column `"fruit"` as a 1D pandas Series $y$ of length 60.

---

## 6. Worked Example

**Question:** If we inspect row 2 of `fruits.csv`:
```csv
fruit,sweetness,weight_g,size_cm,color_score
apple,6.4,165,8.0,8.3
```
What is $X_0$ and what is $y_0$?

**Solution:**
- **Feature Vector $X_0$**: A 4-element numeric array: `[6.4, 165.0, 8.0, 8.3]`.
- **Target Value $y_0$**: The string label `"apple"`.
- The machine learning model is provided with $X_0$ and must learn that vectors resembling `[6.4, 165.0, 8.0, 8.3]` should be classified as `"apple"`.

---

## 7. Step-by-Step Student Instructions

1. Open a Python terminal or interactive shell.
2. Navigate to `beginner-projects-main/AI-ML Beginners/projects/05_fruit_sorter`.
3. Launch Python and run:
   ```python
   import pandas as pd
   df = pd.read_csv("data/fruits.csv")
   FEATURES = ["sweetness", "weight_g", "size_cm", "color_score"]
   X = df[FEATURES]
   y = df["fruit"]
   print("X shape:", X.shape)
   print("y shape:", y.shape)
   print("First 3 rows of X:\n", X.head(3))
   ```
4. Observe the shapes and column types.

---

## 8. Expected Output or Observable Behaviour

Executing the above snippet produces:
```text
X shape: (60, 4)
y shape: (60,)
First 3 rows of X:
    sweetness  weight_g  size_cm  color_score
0        6.4       165      8.0          8.3
1        7.1       176      7.8          8.2
2        8.1       107     18.7          7.2
```

Notice that `X` has 4 columns and 60 rows, while `y` has 60 string labels.

---

## 9. Practical Exercises

- **Exercise 2.1**: Check the minimum and maximum values of `weight_g` across the entire dataset using `df['weight_g'].min()` and `df['weight_g'].max()`.
- **Exercise 2.2**: Compare `df['size_cm'].mean()` for bananas versus apples. What physical property does this reflect?
- **Exercise 2.3**: What happens if you index $X$ with single brackets `df[FEATURES[0]]` instead of passing the full list? What shape do you get?
- **Exercise 2.4**: Write a Python expression that filters `df` to only show rows where `fruit == "orange"`.

---

## 10. Common Mistakes and Debugging

| Mistake | Why it is incorrect | Correction |
|---|---|---|
| Including `fruit` inside `FEATURES` | `fruit` is the ground truth label to predict, not an input feature | Keep `FEATURES` strictly limited to the 4 numeric predictor variables |
| Passing a string instead of a list | `df["sweetness"]` creates a 1D Series, not a 2D matrix | Pass a list of column names: `df[["sweetness", ...]]` |
| Attempting to fit a model with non-numeric features without encoding | Scikit-learn distance calculations require numeric inputs | Ensure all features in $X$ are floats or integers |

---

## 11. Best Practices and Security Considerations

- **Constants at the Top**: Define `FEATURES` as an uppercase module constant so it can be reused across training and inference consistently.
- **Explicit Target Separation**: Keep feature extraction ($X$) and target extraction ($y$) on separate, clear lines of code.
- **Input Validation**: When working with external CSVs, ensure columns contain expected headers before slicing.

---

## 12. Summary

Each fruit in the dataset is described by four continuous numeric features: sweetness, weight in grams, size in centimeters, and an optical color score. In Python, these columns are extracted into a 2D DataFrame $X$ of shape $(60, 4)$, while the target labels (`"apple"`, `"banana"`, `"orange"`) are isolated in a 1D Series $y$ of shape $(60,)$.

---

## 13. Knowledge-check Questions

1. What are the names of the 4 features in `FEATURES`?
2. What is the shape of the feature matrix $X$ extracted from `data/fruits.csv`?
3. What is the shape and data type of the target vector $y$?
4. Which feature has the largest numeric scale in the raw data?
5. Why must the target column `fruit` be excluded from the feature matrix $X$?

---

## 14. References

- pandas DataFrame indexing documentation: [https://pandas.pydata.org/docs/user_guide/indexing.html](https://pandas.pydata.org/docs/user_guide/indexing.html)
- scikit-learn Dataset loading and feature representations: [https://scikit-learn.org/stable/datasets.html](https://scikit-learn.org/stable/datasets.html)
- `main.py` lines 28-36
