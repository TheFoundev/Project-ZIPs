# Lesson 03: The K-Nearest Neighbours (KNN) Intuition

**Lesson ID:** lesson-03  
**Module:** module-01  
**Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain the core philosophical premise of the K-Nearest Neighbours (KNN) algorithm ("birds of a feather flock together").
- Describe how KNN measures similarity using geometric distance in feature space.
- Explain the voting mechanism used by KNN to classify new data points.
- Understand the role of the hyperparameter $k$ (`n_neighbors=5`).
- Distinguish between parametric models (e.g., linear regression) and non-parametric lazy learners (KNN).

---

## 2. Prerequisites
- Completion of Lessons 01 and 02.
- Basic familiarity with 2D coordinate graphs $(x, y)$.

---

## 3. Concept Explanation

### The Principle of Proximity
The K-Nearest Neighbours algorithm operates on an intuitive, commonsense premise: **similar objects exist close to each other in feature space**. 
If you pick up a piece of fruit that weighs 170 grams, is 8.5 cm long, has high sweetness, and deep red coloring, what is it likely to be? It is almost certainly an apple, because fruits with almost identical physical measurements in your past experience were apples!

### How KNN Classifies a New Point
KNN is a **non-parametric, instance-based learning algorithm** (often called a "lazy learner" because it does not learn explicit mathematical equation coefficients during training like linear regression does; instead, it stores the training examples).

When presented with a new, unlabelled query point (like our mystery fruit):
1. **Computes Distance**: It calculates the geometric distance between the query point and every single training example in the dataset.
2. **Identifies Neighbors**: It sorts the distances and selects the $k$ closest data points (in our project, $k=5$).
3. **Conducts Majority Vote**: It tallies the class labels of those $k$ neighbors. Whichever class has the most votes becomes the predicted label.
4. **Calculates Confidence**: The proportion of the $k$ neighbors belonging to the winning class represents the model's confidence probability (e.g., if all 5 of the 5 closest neighbors are apples, confidence is $5/5 = 100\%$).

### Why Choose $k=5$?
- If $k=1$: The model looks only at the single closest point. This can be overly sensitive to noise, measurement errors, or outliers (overfitting).
- If $k$ is very large (e.g., $k=45$ on a 45-sample dataset): The model simply predicts whichever class is most common overall in the dataset, ignoring local feature differences (underfitting).
- $k=5$ provides a robust balance: it smooths out individual measurement anomalies while remaining sensitive to local cluster boundaries.
- Furthermore, an odd number like 5 is often chosen to reduce tie votes in binary decisions.

---

## 4. Relevant Code (from main.py, lines 19, 44, 67-69)

```python
from sklearn.neighbors import KNeighborsClassifier
...
        [
            ("scale", StandardScaler()),
            ("knn", KNeighborsClassifier(n_neighbors=5)),
        ]
...
mystery_prediction = model.predict(mystery)[0]
mystery_probability = model.predict_proba(mystery).max()
print(f"Mystery fruit -> {mystery_prediction} ({mystery_probability:.0%} confident)")
```

---

## 5. Code Explanation
- **Line 19**: Imports `KNeighborsClassifier` from scikit-learn's `neighbors` module.
- **Line 44**: Instantiates `KNeighborsClassifier` with hyperparameter `n_neighbors=5`.
- **Line 67**: `model.predict(mystery)` queries the 5 nearest neighbors of the mystery fruit and returns the majority class label.
- **Line 68**: `model.predict_proba(mystery)` returns an array of fractional probabilities for each class based on the neighbor distribution, and `.max()` finds the highest probability.

---

## 6. Worked Example

**Scenario:** Suppose we want to classify a mystery fruit using $k=5$. The algorithm computes the distance to all training samples and finds the 5 closest fruits:

| Neighbor Rank | Training Fruit Type | Distance |
|---|---|---|
| 1st closest | Apple | 0.35 |
| 2nd closest | Apple | 0.42 |
| 3rd closest | Apple | 0.48 |
| 4th closest | Apple | 0.51 |
| 5th closest | Apple | 0.55 |

**Voting Tally:**
- Apple: 5 votes ($5/5 = 100\%$)
- Banana: 0 votes ($0/5 = 0\%$)
- Orange: 0 votes ($0/5 = 0\%$)

**Outcome:**
- `model.predict()` returns `"apple"`.
- `model.predict_proba()` returns `[1.0, 0.0, 0.0]`.
- Output: `Mystery fruit -> apple (100% confident)`.

---

## 7. Step-by-Step Student Instructions

1. Open `main.py` and inspect lines 41 to 46.
2. Note that `KNeighborsClassifier` takes the parameter `n_neighbors=5`.
3. Locate lines 67 to 69 where `predict()` and `predict_proba()` are executed.
4. Draw a simple 2D grid on paper. Plot 3 red circles (apples), 3 yellow triangles (bananas), and 3 orange squares (oranges).
5. Place a star marker close to the red circles. Pick the 5 closest shapes. Count the votes.

---

## 8. Expected Output or Observable Behaviour

When running `main.py`, the console shows:
```text
Mystery fruit -> apple (100% confident)
```
This confirms that all 5 of the 5 closest training samples to the mystery fruit in the standardized 4D feature space were apples.

---

## 9. Practical Exercises

- **Exercise 3.1**: What would happen if 3 neighbors voted "orange" and 2 voted "apple"? What would `predict()` and `predict_proba().max()` output?
- **Exercise 3.2**: Why is KNN called an "instance-based" or "memory-based" learning algorithm?
- **Exercise 3.3**: What is the danger of setting $k=1$?
- **Exercise 3.4**: If our dataset has 60 samples, what would happen if we set $k=60$?

---

## 10. Common Mistakes and Debugging

| Mistake | Why it is incorrect | Correction |
|---|---|---|
| Thinking KNN trains an equation like $y = mx + c$ | KNN stores instances; it does not calculate slopes or algebraic intercepts | Understand that KNN relies on distance lookups at query time |
| Forgetting to specify $k$ | Scikit-learn defaults to $k=5$, but explicit declaration ensures code clarity | Always pass `n_neighbors=5` explicitly |
| Confusing $k$ in KNN with $k$ in K-Means | K-Means is an unsupervised clustering algorithm; KNN is a supervised classifier | Remember KNN uses labeled training points to classify queries |

---

## 11. Best Practices and Security Considerations

- **Choose Odd Values of $k$**: For binary classification, odd values prevent ties. In multi-class settings, odd numbers still reduce tie likelihood.
- **Computational Cost**: KNN must compute distances to every training point at query time ($O(N \cdot D)$). While instant for 60 samples, large datasets require indexing trees (BallTree or KDTree).
- **Security**: Because KNN stores training data in memory, ensure sensitive data is not exposed when serializing the model.

---

## 12. Summary

K-Nearest Neighbours classifies a query sample by identifying the $k$ most geometrically similar training instances and conducting a majority vote. In this project, $k=5$ (`n_neighbors=5`), meaning the 5 closest fruits in the 4-dimensional feature space cast votes to determine the mystery fruit's identity and calculate prediction confidence.

---

## 13. Knowledge-check Questions

1. What does the parameter $k$ (`n_neighbors`) control in KNN?
2. How does KNN determine which training instances are the "nearest"?
3. If $k=5$ and 4 neighbors are bananas while 1 is an apple, what does the model predict and with what confidence?
4. Why is KNN referred to as an "instance-based" or "lazy" learner?
5. What is a disadvantage of choosing $k=1$?

---

## 14. References

- scikit-learn Nearest Neighbors Documentation: [https://scikit-learn.org/stable/modules/neighbors.html](https://scikit-learn.org/stable/modules/neighbors.html)
- `KNeighborsClassifier` API Reference: [https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.KNeighborsClassifier.html](https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.KNeighborsClassifier.html)
- `main.py` lines 19, 41-46, 67-69
