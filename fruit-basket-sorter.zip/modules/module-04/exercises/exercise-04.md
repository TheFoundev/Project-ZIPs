# Module 4 Exercises: Pipeline Training & Mystery Fruit

---

## Exercise 4.1: Manual Pipeline Construction & Step Inspection (10 min)
**Objective:** Instantiate a scikit-learn Pipeline and programmatically inspect its internal transformers and estimators.  
**Problem Statement:** Construct the exact 2-step Pipeline from `main.py` and inspect its named steps and parameter dictionary.

**Requirements:**
1. Import `Pipeline`, `StandardScaler`, and `KNeighborsClassifier`.
2. Construct `model = Pipeline([('scale', StandardScaler()), ('knn', KNeighborsClassifier(n_neighbors=5))])`.
3. Extract `model.named_steps['scale']` and verify it is a `StandardScaler`.
4. Extract `model.named_steps['knn']` and verify `n_neighbors == 5`.
5. Access the parameter `scale__with_mean` via `model.get_params()`.

**Constraints:** Must use scikit-learn's `Pipeline`.

**Expected Behaviour:** Terminal output displaying verified step names and configuration parameters.

**Acceptance Criteria:**
- [ ] Pipeline initialized with named steps `'scale'` and `'knn'`.
- [ ] `model.named_steps['knn'].n_neighbors` verified as 5.
- [ ] Parameters inspected using `get_params()`.

**Hints:**
- Use `model.named_steps.keys()` to list step names.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes  

---

## Exercise 4.2: Fitting Pipeline & Generating Test Predictions (15 min)
**Objective:** Fit the Pipeline on `X_train, y_train` and evaluate accuracy on `X_test`.  
**Problem Statement:** Train the complete pipeline on the stratified training set and compare predictions against ground-truth test labels.

**Requirements:**
1. Load `data/fruits.csv` and perform the stratified 75/25 split (`random_state=42`).
2. Train the pipeline using `model.fit(X_train, y_train)`.
3. Predict on `X_test` with `model.predict(X_test)`.
4. Construct a pandas DataFrame with columns `Actual`, `Predicted`, and `Match` (True/False).
5. Verify that all 15 test predictions match actual labels (100% test accuracy).

**Constraints:** Do not call `fit()` on test data.

**Expected Behaviour:** A 15-row table printed to console showing 100% agreement between Actual and Predicted.

**Acceptance Criteria:**
- [ ] Pipeline fitted exclusively on `X_train, y_train`.
- [ ] Predictions generated for all 15 test samples.
- [ ] `accuracy_score(y_test, predictions)` verified as `1.0000`.

**Hints:**
- Use `(y_test.values == predictions).all()` to verify 100% match.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 4.3: Mystery Fruit Inference & Multi-Class Probabilities (15 min)
**Objective:** Pass the mystery fruit into the trained pipeline, extract the winning class, and display the complete probability distribution.  
**Problem Statement:** Score the mystery fruit (`sweetness=7.2, weight_g=170, size_cm=8.5, color_score=8.0`) and format its predicted probability for each of the 3 classes.

**Requirements:**
1. Create the mystery fruit DataFrame matching `main.py` lines 57-66.
2. Predict the label using `model.predict(mystery)[0]`.
3. Predict probabilities using `model.predict_proba(mystery)[0]`.
4. Iterate over `model.classes_` and print a table displaying `Class: Probability%`.
5. Verify that `apple` has 100% probability and other fruits have 0%.

**Constraints:** Input must be a pandas DataFrame with named columns.

**Expected Behaviour:** Clean console output showing:
```text
apple : 100.0%
banana: 0.0%
orange: 0.0%
```

**Acceptance Criteria:**
- [ ] Input DataFrame created with correct 4 keys.
- [ ] Correct prediction (`apple`) extracted.
- [ ] Probability table printed displaying all 3 classes.

**Hints:**
- Use `zip(model.classes_, model.predict_proba(mystery)[0])`.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 4.4: Synthetic Boundary Fruit Stress Testing (15 min)
**Objective:** Create artificial fruit samples situated along decision boundaries to observe non-100% probability distributions.  
**Problem Statement:** Synthesize a fruit observation that produces split neighbor votes (e.g. 3 apples, 2 oranges) to observe lower confidence predictions.

**Requirements:**
1. Examine the feature means of apples (`sweetness ~ 6.9, weight ~ 165`) and oranges (`sweetness ~ 5.1, weight ~ 204`).
2. Synthesize a borderline fruit positioned midway: `sweetness=6.0, weight_g=185, size_cm=8.6, color_score=7.0`.
3. Pass the synthetic fruit into `model.predict()` and `model.predict_proba()`.
4. Report the resulting class and confidence percentage.
5. Explain how a quality control system could flag this sample for human review.

**Constraints:** Use the pipeline model trained on `fruits.csv`.

**Expected Behaviour:** Console output showing a split probability distribution (e.g., 60% vs 40%).

**Acceptance Criteria:**
- [ ] Synthetic observation tested through pipeline.
- [ ] Output demonstrates confidence strictly less than 100%.
- [ ] Written explanation of automated confidence thresholds in production.

**Hints:**
- Adjust sweetness between 5.5 and 6.2 to position the sample between apple and orange clusters.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  
