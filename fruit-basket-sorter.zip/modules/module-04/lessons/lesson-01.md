# Lesson 01: Building scikit-learn Pipelines

**Lesson ID:** lesson-01  
**Module:** module-04  
**Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain what a scikit-learn `Pipeline` is and why it is an essential architectural pattern.
- Identify the components of a Pipeline step tuple: `(step_name, step_object)`.
- Explain how `Pipeline` eliminates boilerplate and prevents data leakage between train and test data.
- Inspect named pipeline steps using `model.named_steps`.

---

## 2. Prerequisites
- Completion of Modules 01, 02, and 03.
- Familiarity with `StandardScaler` and `KNeighborsClassifier`.

---

## 3. Concept Explanation

### The Challenge of Multi-Step Machine Learning
In applied machine learning, raw data rarely goes directly into an algorithm. It usually passes through several transformation steps first:
1. Imputing missing values
2. Encoding categorical text
3. Standardizing numeric feature scales
4. Performing dimensionality reduction
5. Applying the classifier

Without a pipeline, a developer must manually call:
```python
scaler.fit(X_train)
X_train_scaled = scaler.transform(X_train)
knn.fit(X_train_scaled, y_train)

X_test_scaled = scaler.transform(X_test)
predictions = knn.predict(X_test_scaled)

mystery_scaled = scaler.transform(mystery)
mystery_pred = knn.predict(mystery_scaled)
```
This manual workflow is brittle. It is easy to forget `transform()` on new samples, or accidentally call `fit()` on test data, introducing subtle bugs and data leakage.

### What is a Pipeline?
A scikit-learn `Pipeline` bundles a sequence of transformers and a final estimator into a single, cohesive Python object. The entire sequence behaves like a standard estimator:
- Calling `pipeline.fit(X, y)` sequentially calls `fit_transform()` on every transformer step, passing the output of step $n$ as input to step $n+1$, and finally calls `fit()` on the estimator.
- Calling `pipeline.predict(X)` automatically calls `transform()` on every intermediate transformer step before passing the processed features to the final estimator's `predict()` method!

### Step Syntax in `main.py`
In `main.py`, the pipeline is created with a list of 2-element tuples:
```python
model = Pipeline(
    [
        ("scale", StandardScaler()),
        ("knn", KNeighborsClassifier(n_neighbors=5)),
    ]
)
```
- First element (`"scale"`): A human-readable identifier string.
- Second element (`StandardScaler()`): An instantiated scikit-learn transformer object.
- Final step (`"knn"`): The classifier estimator.

---

## 4. Relevant Code (from main.py, lines 20, 41-46)

```python
from sklearn.pipeline import Pipeline
...
    model = Pipeline(
        [
            ("scale", StandardScaler()),
            ("knn", KNeighborsClassifier(n_neighbors=5)),
        ]
    )
```

---

## 5. Code Explanation
- **Line 20**: Imports `Pipeline` from `sklearn.pipeline`.
- **Lines 41-46**: Constructs the 2-step pipeline:
  - Step 1 (`"scale"`): Standardizes features so all 4 dimensions have mean 0 and variance 1.
  - Step 2 (`"knn"`): Classifies based on the 5 nearest neighbors in the scaled space.
- Once declared, `model` can be treated as a single black-box classifier.

---

## 6. Worked Example

Let's inspect the internal structure and steps of a Pipeline object:

```python
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier

model = Pipeline([
    ("scale", StandardScaler()),
    ("knn", KNeighborsClassifier(n_neighbors=5))
])

# Inspect steps list
print("Pipeline steps:", model.steps)

# Inspect individual step by name
print("Scaler object:", model.named_steps["scale"])
print("Classifier object:", model.named_steps["knn"])
```

**Output:**
```text
Pipeline steps: [('scale', StandardScaler()), ('knn', KNeighborsClassifier(n_neighbors=5))]
Scaler object: StandardScaler()
Classifier object: KNeighborsClassifier(n_neighbors=5)
```

You can access and inspect any individual component inside the pipeline at any time using `model.named_steps["step_name"]`!

---

## 7. Step-by-Step Student Instructions

1. Open your terminal in the project directory.
2. Launch Python: `python3`.
3. Create the pipeline:
   ```python
   from sklearn.pipeline import Pipeline
   from sklearn.preprocessing import StandardScaler
   from sklearn.neighbors import KNeighborsClassifier

   model = Pipeline([
       ("scale", StandardScaler()),
       ("knn", KNeighborsClassifier(n_neighbors=5))
   ])
   print("Step names:", list(model.named_steps.keys()))
   ```
4. Verify that `['scale', 'knn']` are printed.

---

## 8. Expected Output or Observable Behaviour

The pipeline object is successfully instantiated with two named steps. Before `fit()` is called, inspecting `model.named_steps['scale'].mean_` will raise an `AttributeError`, confirming that no training data has been seen yet.

---

## 9. Practical Exercises

- **Exercise 1.1**: What happens if you try to put `KNeighborsClassifier` as the *first* step and `StandardScaler` as the *second* step? Why does scikit-learn reject this?
- **Exercise 1.2**: Access the `n_neighbors` parameter of the KNN step through `model.get_params()`.
- **Exercise 1.3**: What is the difference between `Pipeline` and `make_pipeline` in scikit-learn?
- **Exercise 1.4**: How does using a Pipeline make deploying a model to a web API easier?

---

## 10. Common Mistakes and Debugging

| Mistake | Why it is incorrect | Correction |
|---|---|---|
| Placing an estimator before the final step | Intermediate steps in a Pipeline must implement `fit()` and `transform()` | Only the final step can be an estimator with `predict()` |
| Passing a dictionary instead of a list of tuples | Pipeline expects `[(name1, obj1), (name2, obj2)]` | Use a list of 2-element tuples |
| Manually transforming test data before passing to `pipeline.predict()` | The pipeline automatically calls `transform()` internally; manual transformation causes double-scaling! | Pass raw feature DataFrames directly to `pipeline.predict()` |

---

## 11. Best Practices and Security Considerations

- **Single Object Deployment**: Encapsulate all preprocessing transformations into the pipeline so inference code only needs to pass raw inputs to `pipeline.predict()`.
- **Descriptive Step Names**: Use clear, lowercase names (`"scale"`, `"pca"`, `"knn"`) for pipeline steps.
- **Serialization Safety**: When pickling or saving pipelines with joblib, verify the environment uses trusted sources.

---

## 12. Summary

A scikit-learn `Pipeline` chains sequential preprocessing transformers with a terminal estimator into a unified object. In `main.py`, `Pipeline([("scale", StandardScaler()), ("knn", KNeighborsClassifier(n_neighbors=5))])` guarantees that scaling is fit strictly on training data and automatically applied during test evaluation and mystery fruit inference, preventing data leakage and double-scaling errors.

---

## 13. Knowledge-check Questions

1. What are the two items in each tuple passed to a scikit-learn `Pipeline`?
2. What method must all intermediate steps in a Pipeline implement?
3. What happens automatically to raw test data when passed to `pipeline.predict()`?
4. How do you access an individual step inside a pipeline by name?
5. Why does a Pipeline prevent the dangerous bug of "double-scaling"?

---

## 14. References

- scikit-learn Pipeline Documentation: [https://scikit-learn.org/stable/modules/generated/sklearn.pipeline.Pipeline.html](https://scikit-learn.org/stable/modules/generated/sklearn.pipeline.Pipeline.html)
- Composing Estimators User Guide: [https://scikit-learn.org/stable/modules/compose.html](https://scikit-learn.org/stable/modules/compose.html)
- `main.py` lines 20, 41-46
