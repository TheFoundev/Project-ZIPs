# Lesson 04: Prediction Confidence with predict_proba()

**Lesson ID:** lesson-04  
**Module:** module-04  
**Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain how `predict_proba()` calculates class probability estimates in K-Nearest Neighbours.
- Interpret the shape and structure of probability arrays returned by multi-class estimators.
- Map probability outputs to class names using `model.classes_`.
- Understand why the mystery fruit receives a confidence score of 100% (`1.0000`).
- Distinguish between high-confidence decisions and borderline/uncertain predictions.

---

## 2. Prerequisites
- Completion of Lessons 01, 02, and 03.
- Basic understanding of fractions and percentages.

---

## 3. Concept Explanation

### Beyond Hard Classifications: Measuring Confidence
In practical engineering systems, getting a class label is often not enough. An industrial robotic sorting arm needs to know: **"How certain is the model?"**
- If the model is **95-100% confident**, the robot can immediately route the fruit down high-speed chutes.
- If the model is only **40-60% confident** (a borderline fruit on the threshold between varieties), the system might divert the item to a manual inspection station.

### How KNN Computes Class Probabilities
Unlike probabilistic models like Naive Bayes or Logistic Regression which calculate odds via log-likelihoods, KNN computes posterior probabilities through direct neighbor frequency:

$$P(\text{Class } c \mid x) = \frac{\text{Count of neighbors among } k \text{ belonging to Class } c}{k}$$

With $k=5$:
- If 5 neighbors are apples: $P(\text{apple}) = 5/5 = 1.00$ ($100\%$)
- If 4 neighbors are apples and 1 is orange: $P(\text{apple}) = 4/5 = 0.80$ ($80\%$)
- If 3 neighbors are apples and 2 are oranges: $P(\text{apple}) = 3/5 = 0.60$ ($60\%$)

### The Structure of `predict_proba()` Output
Calling `model.predict_proba(mystery)` returns a 2D NumPy array of shape `(n_samples, n_classes)`:
- Columns are ordered lexicographically according to `model.classes_`: `['apple', 'banana', 'orange']`.
- Each row sums to $1.0$.

For our mystery fruit:
$$\text{Output} = \begin{bmatrix} 1.0 & 0.0 & 0.0 \end{bmatrix}$$
- Index 0 (`apple`): $1.0$ ($100\%$)
- Index 1 (`banana`): $0.0$ ($0\%$)
- Index 2 (`orange`): $0.0$ ($0\%$)

Calling `.max()` extracts the highest probability ($1.0$), which is formatted as `100% confident`.

---

## 4. Relevant Code (from main.py, lines 68-70)

```python
    mystery_prediction = model.predict(mystery)[0]
    mystery_probability = model.predict_proba(mystery).max()
    print(f"Mystery fruit -> {mystery_prediction} ({mystery_probability:.0%} confident)")
```

---

## 5. Code Explanation
- **Line 68 (`mystery_probability = ...`)**: Invokes `predict_proba(mystery)` on the pipeline, which scales the sample, queries the 5 neighbors, computes class fractions, and takes `.max()`.
- **Line 69**: Prints the prediction string with the confidence percentage formatted using the Python format specifier `:.0%`.

---

## 6. Worked Example

Let's inspect the raw array returned by `predict_proba()` and pair each class with its exact probability:

```python
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier

df = pd.read_csv("data/fruits.csv")
model = Pipeline([("scale", StandardScaler()), ("knn", KNeighborsClassifier(5))])
model.fit(df[["sweetness", "weight_g", "size_cm", "color_score"]], df["fruit"])

mystery = pd.DataFrame([{"sweetness": 7.2, "weight_g": 170, "size_cm": 8.5, "color_score": 8.0}])

# Inspect class order
classes = model.classes_
print("Class Ordering:", classes)

# Get raw probabilities
probs = model.predict_proba(mystery)[0]
print("Raw Probabilities:", probs)

# Pair classes with probabilities
for cls, prob in zip(classes, probs):
    print(f"P({cls:<6}) = {prob:.1%}")
```

**Output:**
```text
Class Ordering: ['apple' 'banana' 'orange']
Raw Probabilities: [1. 0. 0.]
P(apple ) = 100.0%
P(banana) = 0.0%
P(orange) = 0.0%
```

All 5 of the 5 closest training instances are apples, giving apple 100% of the vote.

---

## 7. Step-by-Step Student Instructions

1. Open your terminal in the project directory.
2. Launch Python: `python3`.
3. Replicate the code from lines 33 to 70 of `main.py`.
4. Inspect `model.classes_` to confirm the alphabetical ordering: `['apple', 'banana', 'orange']`.
5. Call `model.predict_proba(mystery)` and verify the returned shape is `(1, 3)`.
6. Verify that `mystery_probability == 1.0`.

---

## 8. Expected Output or Observable Behaviour

Executing `print(f"{mystery_probability:.0%}")` prints:
```text
100%
```
And `print(f"{mystery_probability:.4f}")` (as written to `metrics.txt`) prints:
```text
1.0000
```

---

## 9. Practical Exercises

- **Exercise 4.1**: Create a synthetic borderline fruit located midway between apple and orange: `[sweetness=6.0, weight_g=175, size_cm=8.5, color_score=7.0]`. What are the class probabilities?
- **Exercise 4.2**: If $k=4$, could a tie occur (e.g. 2 apples and 2 oranges)? What does `predict_proba()` return in that case?
- **Exercise 4.3**: Show that `sum(model.predict_proba(mystery)[0]) == 1.0`.
- **Exercise 4.4**: Why can `predict_proba()` with $k=5$ only output multiples of $0.20$ ($0\%, 20\%, 40\%, 60\%, 80\%, 100\%$)?

---

## 10. Common Mistakes and Debugging

| Mistake | Why it is incorrect | Correction |
|---|---|---|
| Assuming `model.predict_proba()` returns class labels | It returns numeric floating-point probabilities between 0 and 1 | Use `model.predict()` for labels, `predict_proba()` for probabilities |
| Assuming column 0 is always the predicted class | Columns are strictly ordered by `model.classes_` (alphabetical by default) | Map probabilities using `model.classes_` |
| Calling `predict_proba()` on models that don't support it | Some estimators (like standard linear SVM) require special calibration flags | Note that KNN natively supports `predict_proba()` through neighbor counting |

---

## 11. Best Practices and Security Considerations

- **Confidence Thresholding**: In production, implement a minimum confidence threshold (e.g., $\ge 80\%$) before accepting an automated decision.
- **Calibrated Expectations**: Remember that in KNN, a 100% probability means "all $k$ neighbors shared this class," not that the physical object is guaranteed with absolute certainty to be an apple.
- **Granularity Limitation**: For finer probability resolution than steps of $1/k$, increase $k$ or use distance-weighted voting (`weights='distance'`).

---

## 12. Summary

In K-Nearest Neighbours, `predict_proba()` computes the fraction of the $k$ nearest neighbors belonging to each target class. For the mystery fruit with $k=5$, all 5 closest reference points are apples, producing a class probability vector of `[1.0, 0.0, 0.0]` and a 100% confidence prediction.

---

## 13. Knowledge-check Questions

1. How does `KNeighborsClassifier` calculate probabilities in `predict_proba()`?
2. What are the dimensions of the array returned by `predict_proba()` for a single query sample in a 3-class problem?
3. In what order are the class probabilities arranged across columns?
4. If $k=5$ and 3 neighbors are oranges while 2 are apples, what is the probability of orange?
5. Why does the mystery fruit achieve 100% confidence in `main.py`?

---

## 14. References

- scikit-learn `predict_proba` Guide: [https://scikit-learn.org/stable/glossary.html#term-predict_proba](https://scikit-learn.org/stable/glossary.html#term-predict_proba)
- Probability Calibration: [https://scikit-learn.org/stable/modules/calibration.html](https://scikit-learn.org/stable/modules/calibration.html)
- `main.py` lines 67-70
