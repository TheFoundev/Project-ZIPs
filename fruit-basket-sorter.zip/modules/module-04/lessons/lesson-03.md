# Lesson 03: The Mystery Fruit Prediction

**Lesson ID:** lesson-03  
**Module:** module-04  
**Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Construct single-sample inference inputs using pandas DataFrame with dictionaries.
- State the exact feature measurements of the mystery fruit defined in `main.py`.
- Explain how `model.predict()` evaluates a single unlabelled observation through the pipeline.
- Identify the predicted class for the mystery fruit (`apple`).
- Explain why DataFrame inputs prevent feature name mismatch warnings in scikit-learn.

---

## 2. Prerequisites
- Completion of Lessons 01 and 02.
- Understanding of pandas DataFrame creation from Python dictionaries.

---

## 3. Concept Explanation

### The Operational Goal: Scoring an Unknown Fruit
In real-world deployment, the primary objective of training a machine learning model is **inference**: classifying newly harvested, unlabelled items. In `main.py`, a simulated sensor reading arrives representing a piece of produce whose identity is unknown—the **mystery fruit**.

### Constructing the Mystery Fruit Input
To query our trained pipeline, the query input must:
1. Match the exact feature names (`sweetness`, `weight_g`, `size_cm`, `color_score`).
2. Match the exact column order.
3. Be 2-dimensional (a table with 1 row and 4 columns).

In `main.py`, this is accomplished cleanly using:
```python
mystery = pd.DataFrame(
    [
        {
            "sweetness": 7.2,
            "weight_g": 170,
            "size_cm": 8.5,
            "color_score": 8.0,
        }
    ]
)
```
Passing a list of dictionaries to `pd.DataFrame()` creates a 1-row DataFrame preserving explicit column metadata.

### Pipeline Execution on New Observations
When `model.predict(mystery)` is called:
1. The pipeline inspects the 4 features: `[7.2, 170, 8.5, 8.0]`.
2. The `"scale"` transformer calculates $z = \frac{x - \mu_{\text{train}}}{\sigma_{\text{train}}}$:
   - $z_{\text{sweetness}} = (7.2 - 6.791) / 1.488 \approx +0.27$
   - $z_{\text{weight}} = (170 - 166.756) / 40.540 \approx +0.08$
   - $z_{\text{size}} = (8.5 - 11.411) / 3.953 \approx -0.74$
   - $z_{\text{color}} = (8.0 - 7.027) / 1.127 \approx +0.86$
3. The `"knn"` estimator searches its 45 stored training points in 4D space.
4. The 5 closest points are queried, and their labels are counted.
5. `model.predict(mystery)` returns an array `array(['apple'], dtype=object)`.
6. Extracting index `[0]` yields the string `"apple"`.

---

## 4. Relevant Code (from main.py, lines 57-70)

```python
    mystery = pd.DataFrame(
        [
            {
                "sweetness": 7.2,
                "weight_g": 170,
                "size_cm": 8.5,
                "color_score": 8.0,
            }
        ]
    )
    mystery_prediction = model.predict(mystery)[0]
    mystery_probability = model.predict_proba(mystery).max()
    print(f"Mystery fruit -> {mystery_prediction} ({mystery_probability:.0%} confident)")
```

---

## 5. Code Explanation
- **Lines 57-66**: Creates a single-row pandas DataFrame named `mystery` containing the 4 sensor readings.
- **Line 67**: Passes `mystery` into `model.predict()` and extracts the first element with `[0]`.
- **Line 68**: Calls `predict_proba()` to compute class probabilities and extracts the maximum value.
- **Line 69**: Prints the formatted prediction: `Mystery fruit -> apple (100% confident)`.

---

## 6. Worked Example

Let's test an alternative mystery fruit to see how the model behaves when sensor readings change:

```python
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier

df = pd.read_csv("data/fruits.csv")
model = Pipeline([("scale", StandardScaler()), ("knn", KNeighborsClassifier(5))])
model.fit(df[["sweetness", "weight_g", "size_cm", "color_score"]], df["fruit"])

# Mystery Fruit 1 (Original):
m1 = pd.DataFrame([{"sweetness": 7.2, "weight_g": 170, "size_cm": 8.5, "color_score": 8.0}])
print("Mystery 1 Prediction:", model.predict(m1)[0])

# Mystery Fruit 2 (Elongated, light, sweet):
m2 = pd.DataFrame([{"sweetness": 8.5, "weight_g": 115, "size_cm": 17.5, "color_score": 7.0}])
print("Mystery 2 Prediction:", model.predict(m2)[0])

# Mystery Fruit 3 (Heavy, low sweetness):
m3 = pd.DataFrame([{"sweetness": 4.8, "weight_g": 220, "size_cm": 9.0, "color_score": 5.5}])
print("Mystery 3 Prediction:", model.predict(m3)[0])
```

**Output:**
```text
Mystery 1 Prediction: apple
Mystery 2 Prediction: banana
Mystery 3 Prediction: orange
```

The pipeline cleanly and accurately sorts each distinct fruit profile into its correct category!

---

## 7. Step-by-Step Student Instructions

1. Open your terminal in the project directory.
2. Launch Python: `python3`.
3. Recreate lines 57 to 67 of `main.py`.
4. Inspect `mystery.shape` (confirm it is `(1, 4)`).
5. Inspect `model.predict(mystery)` (confirm it returns `array(['apple'])`).
6. Access the scalar string using `[0]`.

---

## 8. Expected Output or Observable Behaviour

Executing lines 57-69 prints:
```text
Mystery fruit -> apple (100% confident)
```
This confirms that the mystery fruit with sweetness 7.2, weight 170g, size 8.5cm, and color score 8.0 is classified as an **apple**.

---

## 9. Practical Exercises

- **Exercise 3.1**: Create a new mystery fruit with `sweetness=8.0, weight_g=120, size_cm=16.0, color_score=6.5`. What does `model.predict()` output?
- **Exercise 3.2**: What happens if you omit one of the four features (e.g., leave out `"color_score"`) when creating `mystery`? What error is raised?
- **Exercise 3.3**: Why is `mystery_prediction = model.predict(mystery)[0]` indexed with `[0]`?
- **Exercise 3.4**: How does the visual position of `mystery` in `fruit_scatter.png` (the black star `*`) corroborate this prediction?

---

## 10. Common Mistakes and Debugging

| Mistake | Why it is incorrect | Correction |
|---|---|---|
| Passing a 1D list `[7.2, 170, 8.5, 8.0]` directly to `predict()` | Scikit-learn requires 2D arrays/DataFrames; raises `ValueError: Expected 2D array, got 1D array instead` | Wrap in a DataFrame `pd.DataFrame([...])` or 2D array `[[...]]` |
| Scrambling column order in a NumPy array | If passing raw arrays without column names, features might be assigned to the wrong dimension | Use a pandas DataFrame with explicit column names |
| Forgetting `[0]` when printing | `predict()` returns a NumPy array; omitting `[0]` prints `['apple']` instead of `'apple'` | Index with `[0]` to retrieve the raw string value |

---

## 11. Best Practices and Security Considerations

- **Schema Validation**: In production APIs, validate incoming JSON payloads to ensure all expected feature keys exist and contain valid numeric ranges before passing to `predict()`.
- **DataFrame Preference**: Passing a DataFrame with feature names allows scikit-learn to verify that column names match the training set.
- **Handling Out-of-Distribution Inputs**: If a sensor records impossible values (e.g. weight = -50g), implement pre-inference sanity filters.

---

## 12. Summary

The mystery fruit represents an operational inference query with measurements: sweetness 7.2, weight 170g, size 8.5cm, and color score 8.0. Encapsulated in a single-row pandas DataFrame, the query passes seamlessly through the pipeline's scaler and KNN estimator, resulting in a predicted label of `"apple"` with 100% voting confidence.

---

## 13. Knowledge-check Questions

1. What are the four measurement values defining the mystery fruit in `main.py`?
2. What class label does `model.predict(mystery)[0]` return?
3. Why does scikit-learn raise an error if you pass `model.predict([7.2, 170, 8.5, 8.0])`?
4. How does the pipeline ensure the mystery fruit's weight in grams doesn't distort its distance calculation?
5. What does the index `[0]` extract from `model.predict(mystery)`?

---

## 14. References

- scikit-learn Estimator `predict` API: [https://scikit-learn.org/stable/glossary.html#term-predict](https://scikit-learn.org/stable/glossary.html#term-predict)
- pandas DataFrame from Dictionary: [https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.from_dict.html](https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.from_dict.html)
- `main.py` lines 57-70
