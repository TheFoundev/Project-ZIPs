# Lesson 02: Training the Pipeline with fit()

**Lesson ID:** lesson-02  
**Module:** module-04  
**Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Trace the internal sequence of operations triggered by `model.fit(X_train, y_train)`.
- Explain how `X_train` is transformed before being stored by the KNN estimator.
- Understand what "training" means for an instance-based lazy learner.
- Generate predictions on held-out test data with `model.predict(X_test)`.
- Compute initial test accuracy using `accuracy_score(y_test, predictions)`.

---

## 2. Prerequisites
- Completion of Lesson 01.
- Understanding of the train/test split from Module 02.

---

## 3. Concept Explanation

### The Anatomy of `model.fit(X_train, y_train)`
When you call `model.fit(X_train, y_train)` on our pipeline:

1. **Step 1 (`"scale"` - `StandardScaler`)**:
   - Computes the mean ($\mu$) and standard deviation ($\sigma$) across each of the 4 columns of `X_train` ($N=45$).
   - Transforms `X_train` into a standardized matrix of shape $(45, 4)$ with zero mean and unit variance.
2. **Step 2 (`"knn"` - `KNeighborsClassifier`)**:
   - Receives the standardized feature matrix and the target array `y_train`.
   - Stores the 45 standardized feature coordinates and their associated class labels (`apple`, `banana`, `orange`).
   - Builds an internal spatial index (such as a KD-Tree or Ball-Tree) to optimize nearest neighbor lookups.

### What Happens During `model.predict(X_test)`
When `model.predict(X_test)` is executed on the 15 test samples:
1. The pipeline automatically routes `X_test` through `StandardScaler.transform()` using the **training statistics** ($\mu_{\text{train}}, \sigma_{\text{train}}$).
2. The scaled test features are fed into `knn.predict()`.
3. For each of the 15 test items, the classifier finds the 5 closest training points in 4D space and votes on the class label.
4. An array of 15 predicted class strings is returned.

### Evaluating Test Accuracy
To evaluate how well the model learned the fruit boundaries, `main.py` compares `predictions` against the ground-truth test labels `y_test`:
```python
accuracy = accuracy_score(y_test, predictions)
```
In our run, all 15 test predictions match the ground-truth labels perfectly, yielding:
$$\text{Accuracy} = \frac{15}{15} = 100.0\%$$

---

## 4. Relevant Code (from main.py, lines 47-50)

```python
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)
```

---

## 5. Code Explanation
- **Line 47 (`model.fit(...)`)**: Fits the pipeline on the 45 training instances.
- **Line 48 (`model.predict(...)`)**: Generates 15 predictions for `X_test`.
- **Line 49 (`accuracy_score(...)`)**: Calculates the proportion of correct classifications on the test set.

---

## 6. Worked Example

Let's run the training and prediction steps interactively:

```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

df = pd.read_csv("data/fruits.csv")
X = df[["sweetness", "weight_g", "size_cm", "color_score"]]
y = df["fruit"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

model = Pipeline([
    ("scale", StandardScaler()),
    ("knn", KNeighborsClassifier(n_neighbors=5))
])

# Fit on training data
model.fit(X_train, y_train)

# Predict on test data
predictions = model.predict(X_test)

# Compare predictions side-by-side with ground truth
results = pd.DataFrame({"Actual": y_test.values, "Predicted": predictions})
print(results.head(6))
print(f"\nAccuracy: {accuracy_score(y_test, predictions):.1%}")
```

**Output:**
```text
    Actual Predicted
0    apple     apple
1   banana    banana
2   orange    orange
3    apple     apple
4   orange    orange
5   banana    banana

Accuracy: 100.0%
```

Every test sample is correctly identified!

---

## 7. Step-by-Step Student Instructions

1. Open your terminal in the project directory.
2. Launch Python: `python3`.
3. Execute lines 33 to 50 from `main.py`.
4. Inspect `predictions` by typing `predictions` and pressing Enter.
5. Print `accuracy` formatted as a percentage: `print(f"{accuracy:.1%}")`.

---

## 8. Expected Output or Observable Behaviour

Executing the code returns an array of 15 strings:
```python
array(['apple', 'banana', 'orange', 'apple', 'orange', 'banana', 'apple',
       'orange', 'banana', 'orange', 'apple', 'banana', 'apple', 'banana',
       'orange'], dtype=object)
```
And `print(f"{accuracy:.1%}")` outputs `100.0%`.

---

## 9. Practical Exercises

- **Exercise 2.1**: Print the first 5 rows of `X_test`. Can you guess which fruit each row represents before looking at `predictions`?
- **Exercise 2.2**: What happens if you pass `X_train` into `model.predict()`? What is the training accuracy?
- **Exercise 2.3**: What error occurs if you pass an empty DataFrame `pd.DataFrame()` into `model.predict()`?
- **Exercise 2.4**: Verify that `y_test.shape == predictions.shape`.

---

## 10. Common Mistakes and Debugging

| Mistake | Why it is incorrect | Correction |
|---|---|---|
| Calling `model.fit(X_test, y_test)` | Trains the model on the evaluation set, completely destroying scientific validation | Always fit on `X_train, y_train` |
| Passing 1D array to `predict()` | Scikit-learn requires 2D input for features | Ensure input is a DataFrame or 2D NumPy array |
| Swapping arguments in `accuracy_score(predictions, y_test)` | Scikit-learn standard convention is `accuracy_score(y_true, y_pred)` | Always pass ground truth first, predictions second |

---

## 11. Best Practices and Security Considerations

- **Strict Data Partitioning**: Never allow the model to see test labels during fitting.
- **Consistent Feature Shapes**: Ensure test matrices have identical column order and names as training matrices.
- **Deterministic Fits**: In algorithms with stochastic components, set random states; for standard KNN, fitting is purely deterministic based on distances.

---

## 12. Summary

Calling `model.fit(X_train, y_train)` on the pipeline fits `StandardScaler` to `X_train` and stores the 45 scaled reference coordinates inside `KNeighborsClassifier`. When `model.predict(X_test)` is executed, test samples are automatically scaled using training parameters and matched against their 5 nearest neighbors, achieving a flawless 100.0% accuracy across all 15 test fruits.

---

## 13. Knowledge-check Questions

1. What two distinct operations occur inside the pipeline during `model.fit(X_train, y_train)`?
2. Why is test data automatically scaled during `model.predict(X_test)`?
3. What is the return type and length of `model.predict(X_test)`?
4. What test accuracy is achieved by `main.py`?
5. Why must `accuracy_score` be given `y_test` rather than `y_train` to assess generalization?

---

## 14. References

- scikit-learn `accuracy_score` Documentation: [https://scikit-learn.org/stable/modules/generated/sklearn.metrics.accuracy_score.html](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.accuracy_score.html)
- Estimator Fitting Conventions: [https://scikit-learn.org/stable/developers/develop.html#fitting](https://scikit-learn.org/stable/developers/develop.html#fitting)
- `main.py` lines 41-50
