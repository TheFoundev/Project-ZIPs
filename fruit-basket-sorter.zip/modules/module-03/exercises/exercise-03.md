# Module 3 Exercises: Feature Scaling & KNN Deep Dive

---

## Exercise 3.1: Raw vs. Standardized Distance Calculations (15 min)
**Objective:** Compare Euclidean distances with and without standardization to observe how large numeric ranges distort proximity.  
**Problem Statement:** Given two fruit measurements, show mathematically how the weight feature dominates distance when unscaled, and how `StandardScaler` restores balanced contribution.

**Requirements:**
1. Consider Point A: `[sweetness=8.0, weight_g=120]`
2. Consider Point B: `[sweetness=4.0, weight_g=125]`
3. Consider Point C: `[sweetness=8.0, weight_g=160]`
4. Compute the raw Euclidean distance $d(A, B)$ and $d(A, C)$. Which point appears closer to A?
5. Assume $\sigma_{\text{sweetness}} = 1.5$ and $\sigma_{\text{weight}} = 40.0$. Standardize the coordinates by dividing differences by $\sigma$.
6. Recompute standardized Euclidean distance. Which point is closer now? Explain the reversal.

**Constraints:** Perform calculations step-by-step showing formulas.

**Expected Behaviour:** Clear arithmetic demonstrating that B is closer in raw space, but C is closer in standardized space.

**Acceptance Criteria:**
- [ ] Raw distance $d(A, B) = \sqrt{4^2 + 5^2} = \sqrt{41} \approx 6.40$.
- [ ] Raw distance $d(A, C) = \sqrt{0^2 + 40^2} = 40.0$.
- [ ] Standardized distance correctly computed and compared.
- [ ] 2-sentence explanation of why standardization reversed the nearest neighbor ranking.

**Hints:**
- $z$-difference for sweetness: $\frac{8.0 - 4.0}{1.5} \approx 2.67$.
- $z$-difference for weight: $\frac{120 - 160}{40} = -1.0$.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 3.2: Manual Z-Score Computation (10 min)
**Objective:** Manually standardize raw measurements using the Z-score equation $z = \frac{x - \mu}{\sigma}$.  
**Problem Statement:** Using the learned training statistics from `main.py`, standardize the 4 features of the mystery fruit.

**Requirements:**
1. Given training parameters:
   - `sweetness`: $\mu = 6.791, \sigma = 1.488$
   - `weight_g`: $\mu = 166.756, \sigma = 40.540$
   - `size_cm`: $\mu = 11.411, \sigma = 3.953$
   - `color_score`: $\mu = 7.027, \sigma = 1.127$
2. Given Mystery Fruit:
   - `sweetness = 7.2`
   - `weight_g = 170.0`
   - `size_cm = 8.5`
   - `color_score = 8.0`
3. Compute $z$ for all 4 features.
4. Verify your manual results against scikit-learn's `StandardScaler.transform()`.

**Constraints:** Round intermediate calculations to 3 decimal places.

**Expected Behaviour:** A 4-element standardized vector matching scikit-learn output.

**Acceptance Criteria:**
- [ ] Correct $z$-score calculated for each feature.
- [ ] Code snippet demonstrating `scaler.transform(mystery)` matches manual calculations.

**Hints:**
- $z_{\text{sweetness}} = (7.2 - 6.791) / 1.488 \approx +0.275$.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes  

---

## Exercise 3.3: 4D Euclidean Distance & Neighbor Ranking (15 min)
**Objective:** Programmatically retrieve the 5 nearest neighbors of the mystery fruit and inspect their feature distances.  
**Problem Statement:** Use `model.named_steps['knn'].kneighbors()` to extract the exact distance to each of the 5 closest training points.

**Requirements:**
1. Train the pipeline as structured in `main.py`.
2. Access the fitted `"scale"` and `"knn"` steps from `model.named_steps`.
3. Transform the `mystery` fruit DataFrame using `"scale"`.
4. Call `kneighbors(n_neighbors=5, return_distance=True)`.
5. Print the distances, row indices, and ground truth fruit labels for all 5 neighbors.

**Constraints:** Must use the pipeline architecture from `main.py`.

**Expected Behaviour:** Console output displaying a table of the 5 nearest neighbors, their Euclidean distances, and their classes.

**Acceptance Criteria:**
- [ ] Distances extracted and printed to 4 decimal places.
- [ ] All 5 nearest neighbors confirmed as `apple`.
- [ ] Distances confirmed to be sorted in ascending order.

**Hints:**
- `distances, indices = model.named_steps["knn"].kneighbors(scaled_mystery)`

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 3.4: Hyperparameter Grid Search over K (15 min)
**Objective:** Test a range of values for $k$ to observe the bias-variance tradeoff and determine the boundary where accuracy deteriorates.  
**Problem Statement:** Evaluate KNN performance across $k \in [1, 2, 3, 5, 7, 9, 15, 25, 35, 45]$ using 5-fold cross-validation.

**Requirements:**
1. Load the dataset and extract $X$ and $y$.
2. Loop through $k \in [1, 2, 3, 5, 7, 9, 15, 25, 35, 45]$.
3. For each $k$, build a Pipeline with `StandardScaler` and `KNeighborsClassifier(n_neighbors=k)`.
4. Compute 5-fold cross-validation accuracy using `cross_val_score(pipe, X, y, cv=5)`.
5. Plot $k$ vs. Mean Cross-Validation Accuracy using matplotlib and save to `outputs/k_tuning_curve.png`.

**Constraints:** Use `scikit-learn.model_selection.cross_val_score`.

**Expected Behaviour:** A plotted curve showing peak performance for low-to-medium $k$ and degradation as $k$ approaches 45.

**Acceptance Criteria:**
- [ ] Cross-validation computed correctly for all 10 values of $k$.
- [ ] Accuracy drops sharply as $k$ approaches dataset size.
- [ ] Plot saved to `outputs/k_tuning_curve.png`.

**Hints:**
- Use `scores.mean()` to get average accuracy per $k$.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  
