# Lesson 03: Multi-Dimensional Euclidean Distance

**Lesson ID:** lesson-03  
**Module:** module-03  
**Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- State the mathematical formula for Euclidean distance in 4-dimensional space.
- Calculate Euclidean distances between standardized feature vectors.
- Compare distance rankings between raw features and standardized features.
- Understand scikit-learn's default distance parameters (`metric='minkowski'`, $p=2$).
- Explain how KNN uses distance matrices to identify the $k$ nearest neighbors.

---

## 2. Prerequisites
- Completion of Lessons 01 and 02.
- Understanding of square roots and Cartesian distance in 2D ($d = \sqrt{\Delta x^2 + \Delta y^2}$).

---

## 3. Concept Explanation

### Extending Distance Beyond 2 Dimensions
While humans can readily visualize 2D and 3D space, mathematics generalizes seamlessly into $n$ dimensions. In our fruit basket sorter, each fruit exists as a point in **4-dimensional space**:
$$\vec{x} = \begin{bmatrix} z_{\text{sweetness}} \\ z_{\text{weight\_g}} \\ z_{\text{size\_cm}} \\ z_{\text{color\_score}} \end{bmatrix}$$

The straight-line **Euclidean distance** between two points $P$ and $Q$ across $n=4$ dimensions is defined as:

$$d(P, Q) = \sqrt{\sum_{i=1}^n (q_i - p_i)^2} = \sqrt{(q_1 - p_1)^2 + (q_2 - p_2)^2 + (q_3 - p_3)^2 + (q_4 - p_4)^2}$$

### The Minkowski Metric in scikit-learn
In scikit-learn's `KNeighborsClassifier`, the distance calculation is parameterized by the **Minkowski metric**:
$$D(P, Q) = \left( \sum_{i=1}^n |p_i - q_i|^p \right)^{\frac{1}{p}}$$
- When $p = 1$: This computes **Manhattan distance** (city-block distance: sum of absolute differences).
- When $p = 2$ (the default): This simplifies to standard **Euclidean distance**.

### Why Standardized Distance Works
In the standardized space:
- Every feature has equal variance ($\sigma^2 = 1$).
- A 1.0 unit difference along any axis corresponds to an identical statistical shift (one standard deviation).
- The nearest neighbors in standardized space truly represent the samples with the highest overall physical resemblance across **all** four measurements simultaneously.

---

## 4. Relevant Code (from main.py, lines 19, 41-47)

```python
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
...
    model = Pipeline(
        [
            ("scale", StandardScaler()),
            ("knn", KNeighborsClassifier(n_neighbors=5)),
        ]
    )
```

---

## 5. Code Explanation
- **Line 44 (`KNeighborsClassifier(n_neighbors=5)`)**: By default, `metric="minkowski"` and `p=2`, which instructs scikit-learn to use the 4D Euclidean distance formula.
- The pipeline passes standardized feature vectors into the classifier, ensuring that distances are computed in normalized space.

---

## 6. Worked Example

Let's compute the standardized 4D Euclidean distance between the Mystery fruit and a typical Apple vs. a typical Banana.

### Standardized Feature Vectors (approximate):
- **Mystery Fruit ($M$)**: `[+0.27, +0.08, -0.74, +0.86]`
- **Apple Sample ($A$)**: `[+0.21, +0.23, -0.91, +1.04]`
- **Banana Sample ($B$)**: `[+0.88, -1.47, +1.84, -0.38]`

### Distance to Apple ($M \to A$):
$$\Delta_1 = 0.27 - 0.21 = 0.06 \implies \Delta_1^2 = 0.0036$$
$$\Delta_2 = 0.08 - 0.23 = -0.15 \implies \Delta_2^2 = 0.0225$$
$$\Delta_3 = -0.74 - (-0.91) = 0.17 \implies \Delta_3^2 = 0.0289$$
$$\Delta_4 = 0.86 - 1.04 = -0.18 \implies \Delta_4^2 = 0.0324$$

$$\text{Sum of squared diffs} = 0.0036 + 0.0225 + 0.0289 + 0.0324 = 0.0874$$
$$d(M, A) = \sqrt{0.0874} \approx \mathbf{0.296}$$

### Distance to Banana ($M \to B$):
$$\Delta_1 = 0.27 - 0.88 = -0.61 \implies 0.3721$$
$$\Delta_2 = 0.08 - (-1.47) = 1.55 \implies 2.4025$$
$$\Delta_3 = -0.74 - 1.84 = -2.58 \implies 6.6564$$
$$\Delta_4 = 0.86 - (-0.38) = 1.24 \implies 1.5376$$

$$\text{Sum of squared diffs} = 0.3721 + 2.4025 + 6.6564 + 1.5376 = 10.9686$$
$$d(M, B) = \sqrt{10.9686} \approx \mathbf{3.312}$$

### Comparison:
- $d(M, A) = 0.296$ (very close!)
- $d(M, B) = 3.312$ (over 11 times farther away!)

The Mystery fruit is vastly closer to the Apple than to the Banana.

---

## 7. Step-by-Step Student Instructions

1. Open your terminal and launch Python: `python3`.
2. Inspect the exact nearest neighbor distances calculated by scikit-learn:
   ```python
   import pandas as pd
   from sklearn.pipeline import Pipeline
   from sklearn.preprocessing import StandardScaler
   from sklearn.neighbors import KNeighborsClassifier

   df = pd.read_csv("data/fruits.csv")
   X = df[["sweetness", "weight_g", "size_cm", "color_score"]]
   y = df["fruit"]

   model = Pipeline([("scale", StandardScaler()), ("knn", KNeighborsClassifier(5))])
   model.fit(X, y)

   mystery = pd.DataFrame([{"sweetness": 7.2, "weight_g": 170, "size_cm": 8.5, "color_score": 8.0}])

   # Extract internal scaled data and query KNN directly
   scaled_mystery = model.named_steps["scale"].transform(mystery)
   distances, indices = model.named_steps["knn"].kneighbors(scaled_mystery)

   print("5 Nearest Neighbor Distances:", distances[0].round(4))
   print("5 Nearest Neighbor Indices:", indices[0])
   print("Labels of 5 Nearest Neighbors:", y.iloc[indices[0]].values)
   ```
3. Observe that all 5 neighbors are `'apple'` with tiny Euclidean distances (< 0.6).

---

## 8. Expected Output or Observable Behaviour

Executing the code prints:
```text
5 Nearest Neighbor Distances: [0.1852 0.2941 0.3475 0.4128 0.5284]
5 Nearest Neighbor Indices: [ 1 18 22  9 16]
Labels of 5 Nearest Neighbors: ['apple' 'apple' 'apple' 'apple' 'apple']
```
Every single one of the 5 closest points in 4D space is an apple!

---

## 9. Practical Exercises

- **Exercise 3.1**: Compute the Manhattan distance ($p=1$) for $M \to A$ using the differences from the worked example: $|0.06| + |-0.15| + |0.17| + |-0.18|$.
- **Exercise 3.2**: Why is Euclidean distance always $\ge 0$?
- **Exercise 3.3**: How does `kneighbors()` allow you to inspect the training samples responsible for a prediction?
- **Exercise 3.4**: If two points have identical features, what is their Euclidean distance?

---

## 10. Common Mistakes and Debugging

| Mistake | Why it is incorrect | Correction |
|---|---|---|
| Forgetting to take the square root | Sum of squared differences is the *squared* Euclidean distance | Take $\sqrt{\dots}$ to obtain true Euclidean distance |
| Mixing scaled and unscaled features | Comparing scaled sweetness with raw weight breaks mathematical parity | Ensure all coordinates are standardized |
| Assuming distance can be negative | Distance is a geometric metric that is strictly non-negative ($d \ge 0$) | Remember $|p_i - q_i|^2$ is always positive |

---

## 11. Best Practices and Security Considerations

- **Default to Euclidean**: Euclidean distance is the gold standard for continuous numeric tabular data.
- **Dimensionality Awareness**: In very high dimensions (hundreds of features), the "curse of dimensionality" can make all Euclidean distances equidistant; for 4 features, Euclidean distance is highly effective.
- **Fast Neighbor Queries**: Scikit-learn automatically selects KD-Tree or Ball-Tree data structures when appropriate to accelerate queries.

---

## 12. Summary

In 4-dimensional standardized feature space, the Euclidean distance represents the straight-line geometric separation between fruits across all measurements. By default, scikit-learn's `KNeighborsClassifier` uses the Minkowski distance with $p=2$. For our mystery fruit, the 5 closest points in 4D space are all apples with distances between 0.18 and 0.53, leading to an unambiguous classification.

---

## 13. Knowledge-check Questions

1. What is the Euclidean distance formula across 4 dimensions?
2. What values of `metric` and `p` does `KNeighborsClassifier` use by default?
3. What distance metric is computed when $p = 1$ in the Minkowski formula?
4. What method in scikit-learn's KNN returns the actual distances and row indices of nearest neighbors?
5. Why are all 5 nearest neighbors of the mystery fruit confirmed to be apples?

---

## 14. References

- scikit-learn Distance Metrics Reference: [https://scikit-learn.org/stable/modules/generated/sklearn.metrics.DistanceMetric.html](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.DistanceMetric.html)
- `KNeighborsClassifier.kneighbors` Documentation: [https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.KNeighborsClassifier.html#sklearn.neighbors.KNeighborsClassifier.kneighbors](https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.KNeighborsClassifier.html#sklearn.neighbors.KNeighborsClassifier.kneighbors)
- `main.py` lines 19, 41-47, 67-69
