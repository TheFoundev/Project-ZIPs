# Lesson 02: Mathematics of StandardScaler

**Lesson ID:** lesson-02  
**Module:** module-03  
**Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- State and explain the mathematical formula for Z-score standardization ($z = \frac{x - \mu}{\sigma}$).
- Explain why standardizing features results in a mean of 0 ($\mu = 0$) and a standard deviation of 1 ($\sigma = 1$).
- Distinguish between `fit()`, `transform()`, and `fit_transform()` in scikit-learn.
- Explain what **data leakage** is and why `StandardScaler` must learn its parameters ($\mu, \sigma$) strictly from `X_train`.
- Trace how `mystery` fruit features are transformed before KNN scoring.

---

## 2. Prerequisites
- Completion of Lesson 01.
- Understanding of mean ($\mu$) and standard deviation ($\sigma$).

---

## 3. Concept Explanation

### The Z-Score Standardization Formula
`StandardScaler` standardizes each feature independently by subtracting the feature's empirical mean and dividing by its standard deviation:

$$z = \frac{x - \mu}{\sigma}$$

Where:
- $x$ is the original raw measurement (e.g., `weight_g = 170`).
- $\mu$ is the arithmetic mean of that feature across the training set: $\mu = \frac{1}{N}\sum_{i=1}^N x_i$.
- $\sigma$ is the standard deviation across the training set: $\sigma = \sqrt{\frac{1}{N}\sum_{i=1}^N (x_i - \mu)^2}$.
- $z$ is the standardized value (the "Z-score").

### Properties of the Standardized Distribution
After transformation:
1. **Zero Mean**: The mean of the transformed feature is exactly **0.0**.
2. **Unit Variance**: The standard deviation (and variance) of the transformed feature is exactly **1.0**.
3. **Equal Influence**: A value of $+2.0$ means "2 standard deviations above the mean," whether referring to weight, sweetness, size, or color score. Every feature now contributes equitably to distance metrics.

### Scikit-Learn API: `fit` vs. `transform`
- **`scaler.fit(X_train)`**: Calculates and stores the mean ($\mu$) and standard deviation ($\sigma$) of each column in `X_train`. It does *not* modify the data.
- **`scaler.transform(X)`**: Uses the previously stored $\mu$ and $\sigma$ to compute $z = \frac{x - \mu}{\sigma}$ on any dataset ($X_{\text{train}}$, $X_{\text{test}}$, or mystery query).
- **`scaler.fit_transform(X_train)`**: Computes parameters and transforms `X_train` in a single step.

### Preventing Data Leakage
A critical error in machine learning is calculating $\mu$ and $\sigma$ across the entire dataset before splitting, or fitting the scaler on `X_test`. 
- **Data Leakage** occurs when information from the test dataset contaminates the training process. 
- In production, unseen future fruits do not exist yet; their statistics cannot be known.
- Therefore, the scaler must **only fit on `X_train`**. When evaluating `X_test` or predicting `mystery`, we use the training $\mu$ and $\sigma$!

---

## 4. Relevant Code (from main.py, lines 20-21, 41-47)

```python
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
...
    model = Pipeline(
        [
            ("scale", StandardScaler()),
            ("knn", KNeighborsClassifier(n_neighbors=5)),
        ]
    )
    model.fit(X_train, y_train)
```

---

## 5. Code Explanation
- **Line 43**: Creates `StandardScaler()`.
- **Line 47 (`model.fit(X_train, y_train)`)**: When called on a `Pipeline`, scikit-learn automatically calls `fit_transform()` on `X_train` for the `"scale"` step, stores the calculated $\mu$ and $\sigma$, and passes the scaled matrix to `"knn"`.
- During `model.predict(X_test)`, the pipeline automatically calls `transform()` on `X_test` using the stored training parameters.

---

## 6. Worked Example

Suppose the training set for `weight_g` (15 fruits of each class, 45 total) has:
- Mean weight: $\mu = 165.0\text{ g}$
- Standard deviation: $\sigma = 38.0\text{ g}$

### Standardizing a Training Fruit:
- A fruit weighing $203\text{ g}$:
  $$z = \frac{203 - 165}{38} = \frac{38}{38} = +1.00$$
  *(1 standard deviation heavier than average)*

### Standardizing a Banana:
- A banana weighing $127\text{ g}$:
  $$z = \frac{127 - 165}{38} = \frac{-38}{38} = -1.00$$
  *(1 standard deviation lighter than average)*

### Standardizing the Mystery Fruit:
- The mystery fruit has `weight_g = 170`:
  $$z = \frac{170 - 165}{38} = \frac{5}{38} \approx +0.13$$
  *(Slightly above average weight)*

Notice how weights ranging from 100 to 240 g are now converted to clean numbers typically between $-2.5$ and $+2.5$!

---

## 7. Step-by-Step Student Instructions

1. Open your terminal and launch Python: `python3`.
2. Inspect the parameters learned by `StandardScaler`:
   ```python
   import pandas as pd
   from sklearn.model_selection import train_test_split
   from sklearn.preprocessing import StandardScaler

   df = pd.read_csv("data/fruits.csv")
   X = df[["sweetness", "weight_g", "size_cm", "color_score"]]
   y = df["fruit"]

   X_train, X_test, y_train, y_test = train_test_split(
       X, y, test_size=0.25, random_state=42, stratify=y
   )

   scaler = StandardScaler()
   scaler.fit(X_train)

   print("Learned Means (mu):", scaler.mean_)
   print("Learned Variances (sigma^2):", scaler.var_)
   print("Learned Scales (sigma):", scaler.scale_)
   ```
3. Verify that `scaler.mean_` has 4 values corresponding to the 4 features.

---

## 8. Expected Output or Observable Behaviour

Executing the script reveals:
```text
Learned Means (mu): [  6.79111111 166.75555556  11.41111111   7.02666667]
Learned Scales (sigma): [ 1.48839062 40.54015694  3.95325997  1.12702164]
```
Notice that `StandardScaler` stores the exact mean and standard deviation for each feature.

---

## 9. Practical Exercises

- **Exercise 2.1**: If a fruit has a sweetness of 8.28, calculate its z-score given $\mu = 6.79$ and $\sigma = 1.49$.
- **Exercise 2.2**: Manually standardize the mystery fruit vector `[7.2, 170.0, 8.5, 8.0]` using the learned means and scales above.
- **Exercise 2.3**: Verify that the mean of `scaler.transform(X_train)[:, 0]` is effectively 0 (`~ 1e-16`).
- **Exercise 2.4**: Why is it wrong to call `scaler.fit(X_test)`?

---

## 10. Common Mistakes and Debugging

| Mistake | Why it is incorrect | Correction |
|---|---|---|
| Calling `fit()` on the test set (`scaler.fit(X_test)`) | Contaminates evaluation by re-centering test data, causing data leakage | Only call `transform(X_test)` |
| Fitting the scaler before splitting train/test | Training data gains subtle knowledge of test distribution parameters | Always split first, then fit scaler strictly on `X_train` |
| Calling `fit()` again on mystery inference data | A single sample cannot have a standard deviation; causes runtime division by zero or NaN | Transform single samples using training parameters |

---

## 11. Best Practices and Security Considerations

- **Pipeline Automation**: Always use scikit-learn `Pipeline` to encapsulate scaling and modeling; the Pipeline guarantees `transform` is used on test and inference data automatically.
- **Handling Zero Variance**: `StandardScaler` gracefully handles features with zero variance by setting scale to 1.0, avoiding division by zero.
- **Preserve Scaling Parameters**: In production, serialize the fitted scaler alongside the model so new queries are transformed with identical parameters.

---

## 12. Summary

`StandardScaler` transforms features via the Z-score equation $z = \frac{x - \mu}{\sigma}$, yielding zero mean and unit variance for all features. To prevent data leakage, $\mu$ and $\sigma$ must be computed strictly on `X_train` and applied unchanged to `X_test` and new inference queries like the mystery fruit.

---

## 13. Knowledge-check Questions

1. What is the Z-score standardization formula?
2. What are the mean and standard deviation of any feature after `StandardScaler` transforms it?
3. What is the difference between `scaler.fit()` and `scaler.transform()`?
4. Why is fitting `StandardScaler` on the entire dataset before splitting considered data leakage?
5. How does `Pipeline` prevent data leakage during model training and evaluation?

---

## 14. References

- scikit-learn `StandardScaler` Documentation: [https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.StandardScaler.html](https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.StandardScaler.html)
- Common Pitfalls and Data Leakage: [https://scikit-learn.org/stable/common_pitfalls.html#data-leakage](https://scikit-learn.org/stable/common_pitfalls.html#data-leakage)
- `main.py` lines 20-21, 41-47
