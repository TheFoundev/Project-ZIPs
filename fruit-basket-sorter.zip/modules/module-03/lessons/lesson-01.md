# Lesson 01: The Curse of Differing Scales

**Lesson ID:** lesson-01  
**Module:** module-03  
**Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Explain why distance-based machine learning algorithms (like KNN) are vulnerable to disparate feature scales.
- Demonstrate mathematically how a feature with a large numerical range (e.g., weight in grams) dominates Euclidean distance over a small-scale feature (e.g., sweetness).
- Identify which features in the fruit dataset would drown out others if unscaled.
- Explain why decision tree-based algorithms are scale-invariant while KNN is strictly scale-sensitive.

---

## 2. Prerequisites
- Completion of Module 01 and Module 02.
- Basic understanding of the Euclidean distance formula ($d = \sqrt{(x_2 - x_1)^2 + (y_2 - y_1)^2}$).

---

## 3. Concept Explanation

### The Geometry of Feature Space
K-Nearest Neighbours treats every fruit as a coordinate point in a multi-dimensional geometric space. For two fruits $A$ and $B$, the distance between them across features $1$ through $n$ is:
$$d(A, B) = \sqrt{(x_{A, 1} - x_{B, 1})^2 + (x_{A, 2} - x_{B, 2})^2 + \dots + (x_{A, n} - x_{B, n})^2}$$

Notice what happens when the components are squared:
- If feature 1 (`sweetness`) differs by **1.0 unit**, its squared contribution is $1.0^2 = 1$.
- If feature 2 (`weight_g`) differs by **30 grams**, its squared contribution is $30^2 = 900$!

In this scenario, the weight difference contributes **900 out of 901** (over 99.8%) to the total squared distance. The algorithm effectively becomes "blind" to sweetness, size, and color score, classifying fruits almost exclusively by weight!

### Units of Measurement are Arbitrary
Consider this: if weight was measured in kilograms instead of grams, a difference of 30 grams would be **0.03 kg**. Squaring 0.03 yields **0.0009**!
Suddenly, weight would contribute virtually nothing to the distance calculation, and sweetness would dominate!
A machine learning algorithm's classification should never depend on whether an engineer chose grams, kilograms, ounces, or pounds.

### Scale Sensitivity Across ML Algorithms
- **Scale-Sensitive Algorithms**: Algorithms that rely on geometric distances, dot products, or gradient descent steps (e.g., KNN, K-Means, Support Vector Machines, Neural Networks, PCA). Feature scaling is mandatory.
- **Scale-Invariant Algorithms**: Rule-based or partition-based models like Decision Trees and Random Forests. These models evaluate splits such as `if weight_g > 150`, which depends only on feature ordering, not numeric scale.

---

## 4. Relevant Code (from main.py, lines 20-21, 41-46)

```python
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
...
    model = Pipeline(
        [
            ("scale", StandardScaler()),
            ("knn", KNeighborsClassifier(n_neighbors=5)),
        ]
    )
```

---

## 5. Code Explanation
- **Line 21**: Imports `StandardScaler` from `sklearn.preprocessing`.
- **Line 41-46**: Wraps `StandardScaler` as the first step in a `Pipeline` directly preceding `KNeighborsClassifier`.
- By chaining `StandardScaler` ahead of `knn`, every feature is normalized before distance calculations occur, neutralizing the scale dominance of `weight_g`.

---

## 6. Worked Example

Let's compute the raw Euclidean distance between an unlabelled query fruit and two candidate training fruits:

- **Query Fruit $Q$**: Sweetness = 7.0, Weight = 150 g
- **Candidate 1 (Apple $A$)**: Sweetness = 7.0, Weight = 170 g (Difference: 0 sweetness, 20g weight)
- **Candidate 2 (Orange $O$)**: Sweetness = 4.0, Weight = 155 g (Difference: 3.0 sweetness, 5g weight)

### Raw Euclidean Distance Calculation:
$$d(Q, A) = \sqrt{(7.0 - 7.0)^2 + (150 - 170)^2} = \sqrt{0 + 400} = 20.0$$
$$d(Q, O) = \sqrt{(7.0 - 4.0)^2 + (150 - 155)^2} = \sqrt{9 + 25} = \sqrt{34} \approx 5.83$$

### The Failure of Raw Distance:
Candidate 2 (Orange) is chosen as the "nearest" neighbor because its weight is only 5g away, even though its sweetness is completely different ($4.0$ vs $7.0$). The massive numerical range of weight masked the crucial sweetness signal!

When scaled properly, the 3.0 sweetness difference carries appropriate proportional weight, correctly identifying Candidate 1 as the true match.

---

## 7. Step-by-Step Student Instructions

1. Open your Python terminal in the project directory.
2. In Python, compute raw distances between samples:
   ```python
   import numpy as np
   q = np.array([7.2, 170.0, 8.5, 8.0])  # Mystery fruit
   apple_sample = np.array([7.1, 176.0, 7.8, 8.2])
   orange_sample = np.array([5.7, 173.0, 9.5, 5.4])

   # Raw squared differences
   print("Apple squared diffs:", (q - apple_sample)**2)
   print("Orange squared diffs:", (q - orange_sample)**2)
   ```
3. Observe how the second element (weight squared difference: $(170 - 176)^2 = 36$ vs $(170 - 173)^2 = 9$) dominates the small sweetness differences ($0.01$ vs $2.25$).

---

## 8. Expected Output or Observable Behaviour

Executing the code prints:
```text
Apple squared diffs: [ 0.01 36.    0.49  0.04]
Orange squared diffs: [ 2.25  9.    1.    6.76]
```
Notice how weight contributes 36.0 out of ~36.54 for Apple, accounting for 98.5% of the raw distance.

---

## 9. Practical Exercises

- **Exercise 1.1**: Calculate the raw distance between `[8.0, 110.0]` and `[8.0, 140.0]`. Which feature accounts for 100% of the distance?
- **Exercise 1.2**: If sweetness was measured on a scale of 0 to 1,000,000 (micro-sweetness units), what would happen to the influence of weight?
- **Exercise 1.3**: Name two other machine learning algorithms besides KNN that require feature scaling.
- **Exercise 1.4**: Why does a Decision Tree not require feature scaling?

---

## 10. Common Mistakes and Debugging

| Mistake | Why it is incorrect | Correction |
|---|---|---|
| Omitting scaling when using KNN | Features with large numerical ranges completely dictate neighbor searches | Always pair distance-based algorithms with a scaler |
| Scaling target variable $y$ | Categorical labels (apple, banana, orange) cannot and should not be standardized | Scale only the numeric feature matrix $X$ |
| Assuming scaling changes the data's underlying shape | Scaling changes the scale and center, not the relative distribution or rank order | Understand that scaling standardizes feature variance |

---

## 11. Best Practices and Security Considerations

- **Pair Distance with Scaling**: Treat feature scaling as mandatory whenever using Euclidean, Manhattan, or Cosine distance metrics.
- **Unit Independence**: Always ensure machine learning predictions remain invariant to unit transformations (grams vs. kilograms).
- **Pipeline Encapsulation**: Use scikit-learn's `Pipeline` to prevent forgetting scaling steps during inference.

---

## 12. Summary

Because K-Nearest Neighbours classifies samples based on Euclidean geometric distance, features with large numeric ranges (like weight in grams: 100-240g) disproportionately influence distance calculations over small-range features (like sweetness: 3-9). Feature standardization eliminates this bias by bringing all features onto an equitable, unitless scale.

---

## 13. Knowledge-check Questions

1. Why does `weight_g` dominate raw distance calculations over `sweetness` in the fruits dataset?
2. What would happen to raw distance calculations if weight were recorded in kilograms instead of grams?
3. Which category of machine learning models is scale-invariant?
4. How does scikit-learn's `Pipeline` help ensure scaling is consistently applied?
5. True or False: The target variable $y$ must be scaled using `StandardScaler`.

---

## 14. References

- scikit-learn Preprocessing and Feature Scaling Guide: [https://scikit-learn.org/stable/modules/preprocessing.html](https://scikit-learn.org/stable/modules/preprocessing.html)
- Distance Metrics in Machine Learning: [https://scikit-learn.org/stable/modules/generated/sklearn.metrics.pairwise.euclidean_distances.html](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.pairwise.euclidean_distances.html)
- `main.py` lines 20-21, 41-46
