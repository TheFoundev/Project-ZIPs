# Lesson 04: Hyperparameter Tuning: Choosing K

**Lesson ID:** lesson-04  
**Module:** module-03  
**Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Define what a **hyperparameter** is and how it differs from learned model parameters.
- Analyze the behavior of KNN when $k=1$ (overfitting, high variance, sensitive to noise).
- Analyze the behavior of KNN when $k$ is large (underfitting, high bias, overly smooth boundaries).
- Explain why odd numbers of neighbors are preferred.
- Experiment with different values of $k$ as prompted by line 116 in `main.py`.

---

## 2. Prerequisites
- Completion of Lessons 01, 02, and 03.
- Familiarity with the bias-variance tradeoff concept.

---

## 3. Concept Explanation

### Parameters vs. Hyperparameters
- **Parameters**: Internal configuration variables whose values are estimated directly from data (e.g., slopes and intercepts in linear regression, weights in neural networks).
- **Hyperparameters**: External configuration settings whose values must be set by the engineer **before** training begins (e.g., $k$ in `KNeighborsClassifier(n_neighbors=5)`).

### The Impact of $k$ on Decision Boundaries

#### 1. Low $k$ ($k=1$): High Variance / Overfitting
When $k=1$, the model considers only the single closest training instance:
- **Pros**: Perfectly memorizes the training data (100% training accuracy).
- **Cons**: Extremely sensitive to noisy measurements, typos, or sensor glitches. An anomalous training sample will create a tiny island around itself. Decision boundaries become jagged and erratic.

#### 2. High $k$ ($k \approx N$): High Bias / Underfitting
When $k$ is very large (e.g., $k = 45$ on our 45-sample training set):
- **Pros**: Completely immune to local noise.
- **Cons**: Decision boundaries become overly simplistic and flat. The model ignores subtle local patterns and simply predicts whichever class has the most instances in the overall dataset.

#### 3. The Sweet Spot ($k=5$)
$k=5$ provides an optimal balance:
- Sufficient voting power to ignore single-sample outliers.
- Tight enough neighborhood radius to preserve delicate cluster boundaries between fruit types.

```mermaid
flowchart LR
    A["k = 1\nOverfitting / High Variance\nJagged boundaries\nNoise sensitive"] --> B["k = 5\nBalanced / Optimal\nSmooth boundaries\nRobust to noise"] --> C["k = 45\nUnderfitting / High Bias\nOversimplified\nPredicts majority class"]
```

### Odd vs. Even Numbers for $k$
Choosing an **odd** integer for $k$ (e.g., 3, 5, 7) prevents 50/50 tie votes in binary classification problems. While 3-way ties can theoretically still occur in multi-class problems with odd $k$, scikit-learn breaks ties deterministically based on neighbor distance and dataset indexing.

---

## 4. Relevant Code (from main.py, lines 44, 116)

```python
    model = Pipeline(
        [
            ("scale", StandardScaler()),
            ("knn", KNeighborsClassifier(n_neighbors=5)),
        ]
    )
...
    print("Try this: change n_neighbors from 5 to 1 or 9 and compare.")
```

---

## 5. Code Explanation
- **Line 44**: Sets hyperparameter `n_neighbors=5` in `KNeighborsClassifier`.
- **Line 116**: Encourages the learner to experiment by changing `n_neighbors` to 1 or 9 and observing the effect on accuracy and prediction metrics.

---

## 6. Worked Example

Let's test accuracy across different values of $k$ on our stratified dataset:

```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

df = pd.read_csv("data/fruits.csv")
X = df[["sweetness", "weight_g", "size_cm", "color_score"]]
y = df["fruit"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

for k in [1, 3, 5, 9, 15, 25, 45]:
    pipe = Pipeline([("scale", StandardScaler()), ("knn", KNeighborsClassifier(n_neighbors=k))])
    pipe.fit(X_train, y_train)
    acc = accuracy_score(y_test, pipe.predict(X_test))
    print(f"k = {k:2d} -> Test Accuracy: {acc:.1%}")
```

**Output:**
```text
k =  1 -> Test Accuracy: 100.0%
k =  3 -> Test Accuracy: 100.0%
k =  5 -> Test Accuracy: 100.0%
k =  9 -> Test Accuracy: 100.0%
k = 15 -> Test Accuracy: 100.0%
k = 25 -> Test Accuracy: 93.3%
k = 45 -> Test Accuracy: 33.3%
```

**Interpretation:**
- For $k \le 15$, the clusters are so cleanly separated that accuracy remains a flawless 100%.
- At $k = 25$, the neighborhood radius expands too broadly, causing misclassifications near cluster boundaries (accuracy drops to 93.3%).
- At $k = 45$ (the entire training set), every neighbor in the dataset votes, producing random ties and reducing accuracy to ~33.3% (pure chance guessing among 3 classes)!

---

## 7. Step-by-Step Student Instructions

1. Open `main.py` in your code editor.
2. Locate line 44: `("knn", KNeighborsClassifier(n_neighbors=5)),`.
3. Change `n_neighbors=5` to `n_neighbors=1`.
4. Run `python main.py`. Observe test accuracy and mystery fruit prediction.
5. Change `n_neighbors=1` to `n_neighbors=9`.
6. Run `python main.py` again. Compare the output.
7. Restore `n_neighbors=5`.

---

## 8. Expected Output or Observable Behaviour

For both $k=1$ and $k=9$, the test accuracy remains 100.0%, and the mystery fruit continues to be classified as `apple` with 100% confidence. This demonstrates that the three fruit varieties form exceptionally dense and well-separated clusters in 4D space.

---

## 9. Practical Exercises

- **Exercise 4.1**: What happens to mystery fruit prediction confidence when $k=45$? Try it!
- **Exercise 4.2**: What happens if you set `n_neighbors=0` or `n_neighbors=-1`? What exception does scikit-learn raise?
- **Exercise 4.3**: Write a loop that uses `cross_val_score` from `sklearn.model_selection` to compute average 5-fold cross-validation accuracy for $k \in [1, 3, 5, 7, 9]$.
- **Exercise 4.4**: Why does setting $k=1$ always yield 100% accuracy on the *training* set, but not necessarily on the *test* set?

---

## 10. Common Mistakes and Debugging

| Mistake | Why it is incorrect | Correction |
|---|---|---|
| Setting $k > N_{\text{train}}$ | Cannot query more neighbors than the total number of training samples | Ensure $k \le \text{len}(X_{\text{train}})$ |
| Using even values of $k$ in 2-class problems | Can produce 50/50 ties requiring tie-breaker logic | Prefer odd values like 3, 5, or 7 |
| Confusing $k$ in KNN with $K$ in K-Means | KNN is supervised classification; K-Means is unsupervised clustering | Distinguish between neighbor count and cluster count |

---

## 11. Best Practices and Security Considerations

- **Tune via Cross-Validation**: On complex datasets, select $k$ using `GridSearchCV` with stratified K-fold cross-validation rather than arbitrary guessing.
- **Rule of Thumb**: A common initial heuristic for choosing $k$ is $k \approx \sqrt{N_{\text{train}}}$. For $N=45$, $\sqrt{45} \approx 6.7 \implies k=5$ or $k=7$.
- **Model Explainability**: In regulated industries (e.g., healthcare or finance), KNN with small $k$ allows practitioners to point to the exact historical cases justifying each decision.

---

## 12. Summary

The hyperparameter $k$ (`n_neighbors`) dictates the size of the voting neighborhood in KNN. Small values ($k=1$) risk overfitting to noise, while excessively large values ($k=45$) cause underfitting by diluting local boundaries. Setting $k=5$ offers an optimal, robust balance, yielding 100% accuracy and stable predictions on the fruit dataset.

---

## 13. Knowledge-check Questions

1. What is the fundamental difference between a model parameter and a hyperparameter?
2. What risk is associated with setting $k=1$?
3. What occurs when $k$ is set equal to the total number of training samples ($k=45$)?
4. Why are odd integers typically preferred for $k$?
5. What does the heuristic $k \approx \sqrt{N}$ suggest for a training set of 45 items?

---

## 14. References

- scikit-learn Hyperparameter Tuning: [https://scikit-learn.org/stable/modules/grid_search.html](https://scikit-learn.org/stable/modules/grid_search.html)
- Understanding the Bias-Variance Tradeoff: [https://scikit-learn.org/stable/auto_examples/model_selection/plot_underfitting_overfitting.html](https://scikit-learn.org/stable/auto_examples/model_selection/plot_underfitting_overfitting.html)
- `main.py` lines 44, 116
