# Module 5 Exercises: Evaluation & Visualization

---

## Exercise 5.1: Multi-Class Accuracy Computation & Error Injection (10 min)
**Objective:** Compute accuracy programmatically and observe how artificial misclassifications degrade the metric.  
**Problem Statement:** Evaluate the baseline test accuracy (100%), then inject 1, 2, and 3 artificial errors into the prediction vector to observe accuracy changes.

**Requirements:**
1. Train the pipeline and generate predictions on `X_test`.
2. Compute baseline accuracy using `accuracy_score(y_test, predictions)` and verify it equals `1.0`.
3. Create a copy of predictions and flip 1 prediction (e.g. change an apple to an orange).
4. Compute accuracy with 1 error ($14/15 \approx 93.3\%$).
5. Flip a 2nd and 3rd prediction and display the resulting accuracy values.

**Constraints:** Use `scikit-learn.metrics.accuracy_score`.

**Expected Behaviour:** Terminal output displaying baseline accuracy and the step-by-step decline as errors are introduced.

**Acceptance Criteria:**
- [ ] Baseline accuracy computed as `100.0%`.
- [ ] 1 error computed as `93.3%`.
- [ ] 2 errors computed as `86.7%`.
- [ ] 3 errors computed as `80.0%`.

**Hints:**
- Use `p_copy = predictions.copy()`.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes  

---

## Exercise 5.2: Parsing the Classification Report as a Dictionary (15 min)
**Objective:** Extract precision, recall, and F1-score programmatically using `output_dict=True`.  
**Problem Statement:** In automated monitoring pipelines, text reports are hard to parse. Use `output_dict=True` to extract metrics as structured data and convert into a pandas DataFrame.

**Requirements:**
1. Generate the classification report dictionary: `report_dict = classification_report(y_test, predictions, output_dict=True)`.
2. Convert `report_dict` into a pandas DataFrame using `pd.DataFrame(report_dict).T`.
3. Print the resulting DataFrame.
4. Programmatically verify that `report_dict['apple']['f1-score'] == 1.0`.
5. Save the table to `outputs/evaluation_table.csv`.

**Constraints:** Use pandas and `classification_report`.

**Expected Behaviour:** A clean tabular DataFrame displayed on screen and written to disk.

**Acceptance Criteria:**
- [ ] Dictionary extracted with `output_dict=True`.
- [ ] Transposed DataFrame constructed.
- [ ] Table exported to `outputs/evaluation_table.csv`.

**Hints:**
- `pd.DataFrame(report_dict).transpose()` transposes rows and columns.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 5.3: Custom Confusion Matrix Visualization & Color Palette (15 min)
**Objective:** Render a customized confusion matrix display with alternative colormaps and normalized percentages.  
**Problem Statement:** While `main.py` visualizes raw counts with `cmap="Oranges"`, produce a normalized confusion matrix showing proportions (0.0 to 1.0) using `cmap="Purples"`.

**Requirements:**
1. Compute the normalized confusion matrix: `cm_norm = confusion_matrix(y_test, predictions, labels=labels, normalize='true')`.
2. Create a figure: `fig, ax = plt.subplots(figsize=(6, 5))`.
3. Plot using `ConfusionMatrixDisplay(cm_norm, display_labels=labels).plot(ax=ax, cmap="Purples", values_format=".2f")`.
4. Set the title to `"Normalized Fruit Classification Confusion Matrix"`.
5. Save to `outputs/confusion_matrix_normalized.png`.

**Constraints:** Must use headless matplotlib and call `plt.close(fig)`.

**Expected Behaviour:** An annotated heatmap image exported to disk showing `1.00` along all diagonal cells.

**Acceptance Criteria:**
- [ ] Normalized matrix computed with `normalize='true'`.
- [ ] Heatmap plotted with `cmap="Purples"` and `values_format=".2f"`.
- [ ] Graphic saved to `outputs/confusion_matrix_normalized.png`.
- [ ] Figure closed without memory leaks.

**Hints:**
- `values_format=".2f"` formats the numbers inside cells to 2 decimal places.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 5.4: Advanced Multi-Feature Scatter Plot with Custom Markers (15 min)
**Objective:** Construct a 2D scatter plot visualizing size vs. color score with custom markers and dynamic query points.  
**Problem Statement:** Create an alternative scatter plot displaying `size_cm` on the X-axis and `color_score` on the Y-axis, highlighting the mystery fruit.

**Requirements:**
1. Create a figure with `figsize=(8, 6)`.
2. Plot each fruit class using distinct markers (e.g. `'o'` for apple, `'s'` for orange, `'^'` for banana).
3. Apply `COLOURS = {"apple": "#c0392b", "banana": "#f1c40f", "orange": "#e67e22"}`.
4. Plot the mystery fruit (`size_cm=8.5, color_score=8.0`) with marker `'*'`, `s=300`, `color="#111111"`, `zorder=5`.
5. Set axis labels with units, title, grid, and legend.
6. Save the plot to `outputs/fruit_scatter_size_color.png`.

**Constraints:** Use matplotlib's `Agg` backend.

**Expected Behaviour:** A publication-quality PNG file exported to `outputs/` displaying the alternative feature space.

**Acceptance Criteria:**
- [ ] Size vs color score plotted on X and Y axes.
- [ ] Distinct markers and colors for each class.
- [ ] Mystery fruit clearly visible with star marker on top.
- [ ] Figure saved to `outputs/fruit_scatter_size_color.png`.

**Hints:**
- Use a marker dictionary: `MARKERS = {"apple": "o", "banana": "^", "orange": "s"}`.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  
