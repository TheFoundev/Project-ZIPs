# Lesson 03: The Multi-Class Confusion Matrix

**Lesson ID:** lesson-03  
**Module:** module-05  
**Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Construct and read a 3x3 multi-class confusion matrix.
- Identify true positives along the principal diagonal and misclassifications on off-diagonal cells.
- Explain why class labels must be explicitly sorted (`labels = sorted(df["fruit"].unique())`).
- Render heatmaps using scikit-learn's `ConfusionMatrixDisplay`.
- Customize visualization aesthetics with colormaps (`cmap="Oranges"`), titles, and headless export.

---

## 2. Prerequisites
- Completion of Lessons 01 and 02.
- Understanding of 2D matrix rows (actual) and columns (predicted).

---

## 3. Concept Explanation

### What is a Confusion Matrix?
A **confusion matrix** is a cross-tabulation table where:
- **Rows** correspond to the **true (actual) class labels**.
- **Columns** correspond to the **predicted class labels**.

For our 3-class fruit sorting problem, the confusion matrix is a $3 \times 3$ grid:

```text
               Predicted
           Apple  Banana  Orange
Actual
 Apple   [   5       0       0   ]
 Banana  [   0       5       0   ]
 Orange  [   0       0       5   ]
```

### Reading the Matrix
- **The Main Diagonal (Top-left to bottom-right)**: Represents all **correct classifications** (True Positives for each class).
  - Row 1, Col 1: 5 actual apples correctly classified as apples.
  - Row 2, Col 2: 5 actual bananas correctly classified as bananas.
  - Row 3, Col 3: 5 actual oranges correctly classified as oranges.
- **Off-Diagonal Cells**: Represent **misclassifications** (confusion between classes).
  - If Row 1, Col 3 had a value of 2, it would mean 2 actual apples were incorrectly predicted as oranges.
  - In our project, all off-diagonal values are **0**, indicating zero errors across the entire test set.

### Why Sort the Labels?
When constructing a confusion matrix:
```python
labels = sorted(df["fruit"].unique())
cm = confusion_matrix(y_test, predictions, labels=labels)
```
Passing `labels=labels` explicitly guarantees that both the confusion matrix rows and columns align with `['apple', 'banana', 'orange']` in alphabetical order, preventing silent label mismatches.

### Visualizing with `ConfusionMatrixDisplay`
Instead of printing a bare numerical array, scikit-learn provides `ConfusionMatrixDisplay`:
- Renders the matrix as an annotated heatmap.
- Automatically places class names along the tick axes.
- Prints the exact count inside each tile.
- Accepts standard matplotlib axes and colormaps (in `main.py`, `cmap="Oranges"` gives a clean citrus theme).

---

## 4. Relevant Code (from main.py, lines 17, 101-108)

```python
from sklearn.metrics import ConfusionMatrixDisplay, confusion_matrix
...
    # ---- Confusion matrix ---------------------------------------------
    labels = sorted(df["fruit"].unique())
    cm = confusion_matrix(y_test, predictions, labels=labels)
    fig, ax = plt.subplots(figsize=(5, 4.2))
    ConfusionMatrixDisplay(cm, display_labels=labels).plot(ax=ax, cmap="Oranges", colorbar=False)
    ax.set_title("Fruit classification results")
    fig.tight_layout()
    fig.savefig(OUT / "confusion_matrix.png", dpi=150, bbox_inches="tight")
    plt.close(fig)
```

---

## 5. Code Explanation
- **Line 101**: Extracts and alphabetically sorts the unique fruit labels: `['apple', 'banana', 'orange']`.
- **Line 102**: Computes the numerical $3 \times 3$ matrix `cm`.
- **Line 103**: Creates a dedicated figure and axis with dimensions 5.0 x 4.2 inches.
- **Line 104**: Instantiates `ConfusionMatrixDisplay` with `cm` and `display_labels`, plotting it onto `ax` with `cmap="Oranges"` and hiding the redundant colorbar.
- **Lines 105-108**: Sets title, formats layout, saves the PNG image to `outputs/confusion_matrix.png`, and closes the figure.

---

## 6. Worked Example

Let's inspect the numerical matrix returned by `confusion_matrix()`:

```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix

df = pd.read_csv("data/fruits.csv")
X_train, X_test, y_train, y_test = train_test_split(
    df[["sweetness", "weight_g", "size_cm", "color_score"]],
    df["fruit"],
    test_size=0.25,
    random_state=42,
    stratify=df["fruit"]
)

model = Pipeline([("scale", StandardScaler()), ("knn", KNeighborsClassifier(5))])
model.fit(X_train, y_train)
preds = model.predict(X_test)

labels = sorted(df["fruit"].unique())
cm = confusion_matrix(y_test, preds, labels=labels)
print("Labels:", labels)
print("Confusion Matrix:\n", cm)
```

**Output:**
```text
Labels: ['apple', 'banana', 'orange']
Confusion Matrix:
 [[5 0 0]
  [0 5 0]
  [0 0 5]]
```

Notice the identity-like structure: all 15 elements sit cleanly along the diagonal.

---

## 7. Step-by-Step Student Instructions

1. Open your terminal in `beginner-projects-main/AI-ML Beginners/projects/05_fruit_sorter`.
2. Run `python main.py`.
3. Open the resulting image `outputs/confusion_matrix.png`.
4. Inspect the vertical Y-axis ("True label") and horizontal X-axis ("Predicted label").
5. Confirm that the three orange diagonal cells show `5`, and all other cells show `0`.

---

## 8. Expected Output or Observable Behaviour

The exported image `outputs/confusion_matrix.png` displays a clean 3x3 grid with:
- Top row (Apple): [5, 0, 0]
- Middle row (Banana): [0, 5, 0]
- Bottom row (Orange): [0, 0, 5]
- Orange tiles along the diagonal, white tiles off the diagonal.
- Title: "Fruit classification results".

---

## 9. Practical Exercises

- **Exercise 3.1**: What would the matrix look like if one orange was misclassified as an apple? Write out the 3x3 numbers.
- **Exercise 3.2**: Change `cmap="Oranges"` to `cmap="Blues"` in a copy of the script and inspect the generated image.
- **Exercise 3.3**: Why is `colorbar=False` used in line 104? What happens if you change it to `colorbar=True`?
- **Exercise 3.4**: How does the sum of all elements in `cm` relate to `len(X_test)`?

---

## 10. Common Mistakes and Debugging

| Mistake | Why it is incorrect | Correction |
|---|---|---|
| Omitting `labels=labels` in `confusion_matrix()` | If test set misses a class, the matrix shrinks to 2x2, causing indexing errors | Always pass explicit sorted `labels` |
| Transposing rows and columns | Standard convention is rows = actual (ground truth), columns = predictions | Do not reverse the axes; verify Y is True and X is Predicted |
| Forgetting `plt.close(fig)` | Figure stays resident in memory | Always call `plt.close(fig)` |

---

## 11. Best Practices and Security Considerations

- **Explicit Label Sorting**: Always sort unique class names to guarantee consistent matrix indexing.
- **Visual Contrast**: Choose single-hue colormaps (`Oranges`, `Blues`, `Greens`) with high contrast so cell numbers remain legible against shaded backgrounds.
- **Sanitize File Paths**: When saving visual matrices in multi-tenant services, ensure output file names avoid directory traversal vulnerabilities.

---

## 12. Summary

The confusion matrix cross-tabulates actual ground truth labels against model predictions. In `main.py`, `confusion_matrix` combined with `ConfusionMatrixDisplay` renders a 3x3 heatmap exported to `outputs/confusion_matrix.png`. The presence of 5 in each diagonal cell and 0 in all off-diagonal cells provides visual proof of 100% classification accuracy.

---

## 13. Knowledge-check Questions

1. In a standard scikit-learn confusion matrix, what do rows represent and what do columns represent?
2. What do numbers located along the principal diagonal represent?
3. What do non-zero values in off-diagonal cells indicate?
4. Why is `labels = sorted(df["fruit"].unique())` passed explicitly to `confusion_matrix()`?
5. What matplotlib colormap is used in `main.py` for the confusion matrix display?

---

## 14. References

- scikit-learn `confusion_matrix` API: [https://scikit-learn.org/stable/modules/generated/sklearn.metrics.confusion_matrix.html](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.confusion_matrix.html)
- `ConfusionMatrixDisplay` Documentation: [https://scikit-learn.org/stable/modules/generated/sklearn.metrics.ConfusionMatrixDisplay.html](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.ConfusionMatrixDisplay.html)
- `main.py` lines 101-108
