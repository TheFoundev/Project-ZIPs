# Lesson 04: Publication-Quality Scatter Visualizations

**Lesson ID:** lesson-04  
**Module:** module-05  
**Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Design clear, publication-quality scatter plots using matplotlib.
- Plot multi-class clusters alongside single-sample query markers.
- Control visual rendering hierarchies using the `zorder` parameter.
- Apply professional styling: figure dimensions (`figsize`), dot sizing (`s`), transparency (`alpha`), grid opacity, and DPI resolution.
- Save graphics cleanly using `bbox_inches="tight"` and free memory with `plt.close()`.

---

## 2. Prerequisites
- Completion of Lessons 01, 02, and 03.
- Basic understanding of matplotlib scatter plotting and figure manipulation.

---

## 3. Concept Explanation

### The Role of Visual Storytelling in ML
Machine learning models are often deployed to non-technical stakeholders—managers, farm supervisors, or quality engineers. A raw prediction of `"apple"` is far more compelling when accompanied by a high-resolution chart showing exactly where the mystery fruit landed relative to historical fruit clusters.

### Key Plotting Techniques in `main.py`

#### 1. Visual Hierarchy with `zorder`
When multiple visual elements overlap, matplotlib draws them in the order they were called. If the mystery fruit was plotted first, subsequent training dots might draw over it, partially obscuring the star.
By setting `zorder=5`, `main.py` guarantees that the mystery fruit marker is drawn **on top of** all other elements (standard points have `zorder=2` by default).

#### 2. Distinctive Query Marker
- `marker="*"`: A five-pointed star immediately distinguishes the query point from standard circular data points (`marker="o"`).
- `s=260`: An enlarged marker area (more than 4x larger than regular points with `s=60`).
- `color="#111111"`: Deep charcoal black provides high contrast against the red, yellow, and orange fruit clusters.
- `label=f"mystery -> {mystery_prediction}"`: The legend dynamically announces the predicted class!

#### 3. Professional Polish & Grid Opacity
- `figsize=(7.5, 5.5)`: Provides balanced 4:3 widescreen proportions.
- `alpha=0.8`: Allows partial visibility through overlapping points in dense cluster cores.
- `ax.grid(alpha=0.25)`: Subdued grid lines provide coordinate reference without visually competing with data points.
- `fig.tight_layout()`: Eliminates wasted whitespace and prevents axis label clipping.
- `dpi=150`: Exports crisp 150 dots-per-inch raster graphics suitable for presentations.

---

## 4. Relevant Code (from main.py, lines 71-98)

```python
    # ---- Scatter plot --------------------------------------------------
    fig, ax = plt.subplots(figsize=(7.5, 5.5))
    for fruit, group in df.groupby("fruit"):
        ax.scatter(
            group["sweetness"],
            group["weight_g"],
            s=60,
            alpha=0.8,
            label=fruit,
            color=COLOURS[fruit],
        )
    ax.scatter(
        mystery["sweetness"],
        mystery["weight_g"],
        marker="*",
        s=260,
        color="#111111",
        label=f"mystery -> {mystery_prediction}",
        zorder=5,
    )
    ax.set_xlabel("Sweetness score")
    ax.set_ylabel("Weight (g)")
    ax.set_title("Similar fruits form groups")
    ax.legend()
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(OUT / "fruit_scatter.png", dpi=150, bbox_inches="tight")
    plt.close(fig)
```

---

## 5. Code Explanation
- **Line 72**: Initializes a new figure and axis of size 7.5 by 5.5 inches.
- **Lines 73-81**: Renders the 3 fruit clusters using the `COLOURS` mapping dictionary.
- **Lines 82-90**: Plots the mystery fruit as a prominent star (`*`, `s=260`, `color="#111111"`, `zorder=5`).
- **Lines 91-95**: Sets axis labels, title, legend, and subtle grid.
- **Lines 96-98**: Adjusts padding with `tight_layout()`, writes `fruit_scatter.png` at 150 DPI, and closes the figure buffer.

---

## 6. Worked Example

Let's inspect how the legend and coordinates are dynamically constructed:

```python
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("data/fruits.csv")
mystery = pd.DataFrame([{"sweetness": 7.2, "weight_g": 170, "size_cm": 8.5, "color_score": 8.0}])
mystery_prediction = "apple"

print("Mystery coordinate: (Sweetness =", mystery["sweetness"].iloc[0], ", Weight =", mystery["weight_g"].iloc[0], ")")
print("Legend label string:", f"mystery -> {mystery_prediction}")
```

**Output:**
```text
Mystery coordinate: (Sweetness = 7.2 , Weight = 170 )
Legend label string: mystery -> apple
```

The black star sits at coordinate $(7.2, 170)$, perfectly nested among the red apple points whose sweetness averages 6.9 and weight averages 165g.

---

## 7. Step-by-Step Student Instructions

1. Open your terminal in `beginner-projects-main/AI-ML Beginners/projects/05_fruit_sorter`.
2. Run `python main.py`.
3. Open `outputs/fruit_scatter.png` in an image viewer.
4. Examine the legend box: notice the entries for `apple`, `banana`, `orange`, and `mystery -> apple`.
5. Observe how the black star marker remains clearly visible in the foreground due to `zorder=5`.

---

## 8. Expected Output or Observable Behaviour

The exported file `outputs/fruit_scatter.png` contains:
- Yellow dots clustered in the bottom-right quadrant.
- Orange dots clustered in the top-left quadrant.
- Red dots clustered in the center.
- A prominent black star inside the red cluster labeled `mystery -> apple`.
- Subdued grid lines at 25% opacity.

---

## 9. Practical Exercises

- **Exercise 4.1**: What happens if you remove `zorder=5` and plot the mystery fruit *before* the loop? Does the star get drawn under the dots?
- **Exercise 4.2**: Change `marker="*"` to `marker="D"` (diamond) or `marker="^"` (triangle). How does the visual clarity change?
- **Exercise 4.3**: Change `bbox_inches="tight"` to omit the parameter. Inspect whether any axis label text gets clipped along image borders.
- **Exercise 4.4**: Why is `alpha=0.25` preferred for grid lines over the default `alpha=1.0`?

---

## 10. Common Mistakes and Debugging

| Mistake | Why it is incorrect | Correction |
|---|---|---|
| Forgetting `zorder` on key markers | Background points can visually overlap and obscure the query marker | Assign `zorder=5` (or higher) to foreground points |
| Hardcoding legend labels | If the prediction changes, the legend title will display outdated text | Use f-string formatting: `f"mystery -> {mystery_prediction}"` |
| Omitting axis units | An axis labeled "Weight" doesn't inform the reader if units are grams, ounces, or lbs | Always specify units: `"Weight (g)"` |

---

## 11. Best Practices and Security Considerations

- **Dynamic Legends**: Ensure legend text updates dynamically based on model outputs (`f"mystery -> {prediction}"`).
- **File Closure**: Always call `plt.close(fig)` to release raster memory buffers.
- **High-DPI Output**: Use `dpi=150` or higher for crisp rendering on high-resolution displays.

---

## 12. Summary

Publishable machine learning visualizations require deliberate attention to visual hierarchy, color choice, and styling. By pairing custom fruit hex codes with an enlarged black star marker (`zorder=5`) and subtle gridlines, `main.py` produces an intuitive scatter plot in `outputs/fruit_scatter.png` that immediately communicates why the mystery fruit was classified as an apple.

---

## 13. Knowledge-check Questions

1. What marker shape and size (`s`) is used for the mystery fruit in `main.py`?
2. What is the role of `zorder=5` in the scatter plot call?
3. Why is `f"mystery -> {mystery_prediction}"` used as the legend label?
4. What DPI setting is specified in `fig.savefig()`?
5. Why is `bbox_inches="tight"` included when saving the figure?

---

## 14. References

- matplotlib `pyplot.scatter` API: [https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.scatter.html](https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.scatter.html)
- matplotlib `zorder` Guide: [https://matplotlib.org/stable/gallery/misc/zorder_demo.html](https://matplotlib.org/stable/gallery/misc/zorder_demo.html)
- `main.py` lines 71-98
