# Lesson 01: Multi-Class Accuracy & Support

**Lesson ID:** lesson-01  
**Module:** module-05  
**Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Define classification accuracy and calculate it mathematically for multi-class problems.
- Interpret the concept of **support** in evaluation datasets.
- Explain why The Fruit Basket Sorter achieves 100.0% accuracy on its test set.
- Identify scenarios where accuracy alone can be misleading (class imbalance).
- Explain why accuracy is a valid, reliable metric for our stratified fruit dataset.

---

## 2. Prerequisites
- Completion of Module 04.
- Familiarity with basic fraction arithmetic and percentages.

---

## 3. Concept Explanation

### What is Classification Accuracy?
Accuracy is the simplest and most intuitive evaluation metric in machine learning. It measures the ratio of correct predictions to the total number of evaluation instances:

$$\text{Accuracy} = \frac{\text{Number of Correct Predictions}}{\text{Total Number of Predictions}} = \frac{\sum_{i=1}^{N_{\text{test}}} \mathbb{I}(y_i = \hat{y}_i)}{N_{\text{test}}}$$

Where:
- $y_i$ is the actual ground truth label.
- $\hat{y}_i$ is the model's predicted label.
- $\mathbb{I}$ is the indicator function (1 if match, 0 if mismatch).
- $N_{\text{test}}$ is the test set size.

In our project:
- Correct predictions: 15 (5 apples, 5 bananas, 5 oranges)
- Total test instances: 15
- **Accuracy**: $\frac{15}{15} = 1.00 = 100.0\%$

### What is Support?
In classification reporting, **support** refers to the actual count of true instances of each class present in the evaluation dataset.
In our test split:
- Apple support: **5**
- Banana support: **5**
- Orange support: **5**
- Total test support: **15**

Because the dataset was partitioned with `stratify=y`, the support is perfectly uniform across all three classes ($33.3\%$ per class).

### The Accuracy Paradox (When Accuracy Misleads)
In datasets with severe **class imbalance**, accuracy can create a dangerous illusion of competence:
- Suppose a medical test dataset contains 990 healthy patients and 10 sick patients.
- A naive dummy model that predicts "healthy" for 100% of cases achieves an apparent **99% accuracy**, while failing to diagnose a single sick patient!

However, on **balanced datasets** like ours—where every class has equal support—accuracy provides a fair, unbiased assessment of overall correctness.

---

## 4. Relevant Code (from main.py, lines 17, 49-54)

```python
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay, confusion_matrix
...
    accuracy = accuracy_score(y_test, predictions)

    print("=" * 60)
    print("THE FRUIT BASKET SORTER")
    print("=" * 60)
    print(f"Accuracy: {accuracy:.1%}\n")
```

---

## 5. Code Explanation
- **Line 17**: Imports `accuracy_score` from `sklearn.metrics`.
- **Line 49**: Computes the test accuracy by comparing ground truth `y_test` against model `predictions`.
- **Lines 51-54**: Formats and prints the results to the terminal using the format specifier `:.1%`, which multiplies by 100 and appends a `%` sign with one decimal point (`100.0%`).

---

## 6. Worked Example

Let's trace how `accuracy_score` computes the metric step-by-step:

| Test Sample Index | Ground Truth ($y_{\text{test}}$) | Model Prediction ($\hat{y}$) | Correct? |
|---|---|---|---|
| 0 | apple | apple | Yes (1) |
| 1 | banana | banana | Yes (1) |
| 2 | orange | orange | Yes (1) |
| 3 | apple | apple | Yes (1) |
| 4 | orange | orange | Yes (1) |
| 5 | banana | banana | Yes (1) |
| 6 | apple | apple | Yes (1) |
| 7 | orange | orange | Yes (1) |
| 8 | banana | banana | Yes (1) |
| 9 | orange | orange | Yes (1) |
| 10 | apple | apple | Yes (1) |
| 11 | banana | banana | Yes (1) |
| 12 | apple | apple | Yes (1) |
| 13 | banana | banana | Yes (1) |
| 14 | orange | orange | Yes (1) |

$$\text{Total Correct} = 15, \quad \text{Total Samples} = 15$$
$$\text{Accuracy} = \frac{15}{15} = 1.0000 = 100.0\%$$

---

## 7. Step-by-Step Student Instructions

1. Open your terminal in the project directory.
2. Launch Python: `python3`.
3. Load the data, fit the model, and generate predictions as shown in `main.py`.
4. Run `from sklearn.metrics import accuracy_score`.
5. Call `accuracy_score(y_test, predictions)` and inspect the raw float (`1.0`).
6. Deliberately introduce an error: `fake_predictions = predictions.copy(); fake_predictions[0] = 'banana'`.
7. Re-calculate accuracy: `accuracy_score(y_test, fake_predictions)`. Observe that accuracy drops to $14/15 \approx 93.3\%$.

---

## 8. Expected Output or Observable Behaviour

Executing `main.py` produces:
```text
============================================================
THE FRUIT BASKET SORTER
============================================================
Accuracy: 100.0%
```
In `outputs/metrics.txt`, the value is recorded with 4 decimal places:
```text
accuracy: 1.0000
```

---

## 9. Practical Exercises

- **Exercise 1.1**: If 2 out of 15 test predictions were incorrect, what would the test accuracy be?
- **Exercise 1.2**: Why does `accuracy_score(y_true, y_pred)` require `y_true` as the first argument?
- **Exercise 1.3**: How does stratification guarantee that test support is exactly 5 per fruit class?
- **Exercise 1.4**: If a dataset had 100 samples with 90 apples, 5 bananas, and 5 oranges, why would accuracy be an unreliable metric?

---

## 10. Common Mistakes and Debugging

| Mistake | Why it is incorrect | Correction |
|---|---|---|
| Evaluating accuracy on `X_train` | Measures memorization rather than generalization | Always evaluate on held-out `X_test` |
| Relying on accuracy for imbalanced datasets | High accuracy can mask total failure on minority classes | Use precision, recall, and confusion matrices |
| Reporting accuracy as an integer (e.g. 100) | `accuracy_score` returns a float between 0.0 and 1.0 | Format with `:.1%` or multiply by 100 |

---

## 11. Best Practices and Security Considerations

- **Balanced Benchmarks**: Ensure test sets have sufficient support across all target classes.
- **Complementary Metrics**: Never rely solely on accuracy; always pair accuracy with precision, recall, and a confusion matrix.
- **Baseline Comparison**: Always compare model accuracy against a dummy baseline classifier (e.g., predicting the majority class = 33.3%).

---

## 12. Summary

Classification accuracy measures the proportion of correct predictions over total evaluation samples. In `main.py`, the pipeline achieves a perfect 100.0% accuracy on the 15-sample test set (support = 5 per class). Because the dataset was stratified and balanced, this metric reliably indicates that the model has learned robust decision boundaries across all three fruit varieties.

---

## 13. Knowledge-check Questions

1. What is the mathematical definition of classification accuracy?
2. What was the exact test accuracy achieved in `main.py`?
3. What is the definition of "support" in a classification evaluation report?
4. What is the support for each fruit class in our 15-sample test set?
5. What is the "accuracy paradox" and why does it occur on imbalanced datasets?

---

## 14. References

- scikit-learn `accuracy_score` API: [https://scikit-learn.org/stable/modules/generated/sklearn.metrics.accuracy_score.html](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.accuracy_score.html)
- Model Evaluation Metrics User Guide: [https://scikit-learn.org/stable/modules/model_evaluation.html#accuracy-score](https://scikit-learn.org/stable/modules/model_evaluation.html#accuracy-score)
- `main.py` lines 49-54
