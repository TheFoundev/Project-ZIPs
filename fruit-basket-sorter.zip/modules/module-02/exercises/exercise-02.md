# Module 2 Exercises: Data Loading & Exploration

---

## Exercise 2.1: Data Loading & Missing Value Verification (10 min)
**Objective:** Load `data/fruits.csv` using pandas and programmatically verify data dimensions, column types, and missing values.  
**Problem Statement:** Before training any ML model, write a verification script to validate that the fruit dataset conforms to expected schema requirements.

**Requirements:**
1. Load `data/fruits.csv` into a pandas DataFrame.
2. Confirm the DataFrame contains exactly 60 rows and 5 columns.
3. Verify that `sweetness`, `weight_g`, `size_cm`, and `color_score` are numeric types.
4. Calculate the sum of missing (`NaN`) values per column and verify all sums equal 0.
5. Print a confirmation summary table.

**Constraints:** Use pandas and execute as a standalone script.

**Expected Behaviour:** Terminal output printing table dimensions, confirming zero missing values, and validating column datatypes.

**Acceptance Criteria:**
- [ ] DataFrame successfully loaded with `pd.read_csv()`.
- [ ] Shape verified as `(60, 5)`.
- [ ] All 4 feature columns verified as numeric.
- [ ] Zero missing values confirmed across all columns.

**Hints:**
- Use `df.isna().sum()` to check for null values.
- Use `pd.api.types.is_numeric_dtype(df[col])` to verify numeric columns.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes  

---

## Exercise 2.2: Cross-Class Feature Statistics & Summary Tables (15 min)
**Objective:** Calculate summary statistics grouped by fruit variety to identify distinguishing physical characteristics.  
**Problem Statement:** Compute the mean, standard deviation, minimum, and maximum for all 4 features broken down by each fruit class (`apple`, `banana`, `orange`).

**Requirements:**
1. Group the DataFrame by `fruit`.
2. Compute the aggregate statistics (`mean`, `min`, `max`) for each feature.
3. Identify which fruit has:
   - The highest average sweetness.
   - The lowest average weight.
   - The highest average color score.
   - The longest average size.
4. Export the aggregated summary table to a CSV file named `fruit_summary_stats.csv`.

**Constraints:** Use `df.groupby('fruit').agg(...)`.

**Expected Behaviour:** A formatted summary table displayed on screen and written to disk.

**Acceptance Criteria:**
- [ ] Aggregation correctly groups by `fruit`.
- [ ] Means and ranges accurately computed.
- [ ] Bananas identified as highest sweetness and longest size.
- [ ] Oranges identified as heaviest and lowest sweetness.
- [ ] Apples identified as highest color score.

**Hints:**
- Use `df.groupby("fruit")[FEATURES].agg(["mean", "min", "max"])`.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 2.3: Stratified Partitioning Verification (15 min)
**Objective:** Compare random train/test splitting with and without stratification to observe class balance effects.  
**Problem Statement:** Split the 60 fruit observations using `test_size=0.25` twice: once with `stratify=y` and once without `stratify`. Analyze the differences in test set class counts.

**Requirements:**
1. Perform Split 1: `train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)`.
2. Print `y_test.value_counts()` for Split 1.
3. Perform Split 2: `train_test_split(X, y, test_size=0.25, random_state=100, stratify=None)`.
4. Print `y_test.value_counts()` for Split 2.
5. Write a 3-sentence explanation of why Split 1 is superior for reliable evaluation.

**Constraints:** Use `scikit-learn.model_selection.train_test_split`.

**Expected Behaviour:** Output demonstrating that Split 1 produces exactly 5 of each fruit, whereas Split 2 produces uneven class counts.

**Acceptance Criteria:**
- [ ] Split 1 shows exactly 5 apples, 5 bananas, and 5 oranges.
- [ ] Split 2 shows skewed distribution (e.g. 7 of one class, 3 of another).
- [ ] Clear written explanation of why stratification prevents test set bias.

**Hints:**
- Without stratification, small datasets are vulnerable to sampling noise.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 2.4: Custom Multi-Feature Scatter Plot Generation (15 min)
**Objective:** Create a multi-panel visualization exploring alternative 2D feature projections.  
**Problem Statement:** While `main.py` visualizes `sweetness` vs. `weight_g`, generate a 2-panel figure plotting:
1. Panel A: `sweetness` vs. `weight_g`
2. Panel B: `size_cm` vs. `color_score`

**Requirements:**
1. Create a figure with 2 subplots side-by-side using `plt.subplots(1, 2, figsize=(14, 5))`.
2. On both subplots, render scatter points for each fruit using `COLOURS = {"apple": "#c0392b", "banana": "#f1c40f", "orange": "#e67e22"}`.
3. Label both axes and add titles to both panels.
4. Save the figure to `outputs/two_panel_fruit_scatter.png`.

**Constraints:** Use the `Agg` headless backend and call `plt.close(fig)`.

**Expected Behaviour:** A clean 2-panel PNG graphic exported to disk illustrating cluster separation across different dimensions.

**Acceptance Criteria:**
- [ ] Two subplots rendered with correct titles and axis labels.
- [ ] Custom fruit colors applied to all points.
- [ ] Figure successfully saved to `outputs/two_panel_fruit_scatter.png`.
- [ ] `plt.close(fig)` executed without memory warnings.

**Hints:**
- Use `for fruit, group in df.groupby("fruit"):` and call `ax[0].scatter(...)` and `ax[1].scatter(...)`.

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  
