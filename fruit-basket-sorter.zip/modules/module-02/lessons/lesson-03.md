# Lesson 03: Class Distribution & Stratified Splitting

**Lesson ID:** lesson-03  
**Module:** module-02  
**Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Inspect class balance using `df['fruit'].value_counts()`.
- Explain what balanced vs. imbalanced class distributions mean in machine learning.
- Understand the parameters of `train_test_split()`: `test_size=0.25`, `random_state=42`, and `stratify=y`.
- Demonstrate why stratified sampling is critical for multi-class classification datasets.
- Verify the exact train and test set sample counts generated in `main.py`.

---

## 2. Prerequisites
- Completion of Lessons 01 and 02.
- Basic understanding of why models must be evaluated on unseen test data.

---

## 3. Concept Explanation

### Class Distribution and Balance
In classification problems, **class distribution** refers to the number of training instances belonging to each target category:
- **Balanced Dataset**: Each class has approximately equal representation.
- **Imbalanced Dataset**: One class heavily outnumbers others (e.g., 99% legitimate emails vs. 1% spam).

In `data/fruits.csv`, checking the value counts reveals:
- `apple`: 20 samples (33.3%)
- `banana`: 20 samples (33.3%)
- `orange`: 20 samples (33.3%)
- **Total**: 60 samples

This is a **perfectly balanced 3-class dataset**.

### The Train/Test Split
To reliably measure how well our machine learning model generalizes to new data, we must never test on the same data used to train the model. 
`main.py` splits the 60 samples using:
```python
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)
```

Let's dissect each argument:
1. **`test_size=0.25`**: Allocates 25% of the data to the test set ($0.25 \times 60 = 15$ samples) and the remaining 75% to the training set ($0.75 \times 60 = 45$ samples).
2. **`random_state=42`**: Sets a deterministic seed for the pseudo-random number generator, ensuring identical splits across all machines and operating systems.
3. **`stratify=y`**: **Stratification** forces the partition to preserve the exact class proportions of the original dataset in both splits!

### Why Stratification is Essential
Imagine what could happen in a purely random split of 15 test items:
- By random chance, the test set might draw 9 apples, 5 bananas, and only 1 orange!
- In extreme cases with small datasets, a class could be completely omitted from the test set ($0$ oranges).
- With `stratify=y`, scikit-learn guarantees that each fruit class contributes exactly 25% of its members to the test set:
  - **Test set**: $20 \times 0.25 = 5$ apples, 5 bananas, 5 oranges (Total = 15).
  - **Train set**: $20 \times 0.75 = 15$ apples, 15 bananas, 15 oranges (Total = 45).

---

## 4. Relevant Code (from main.py, lines 18, 35, 37-39)

```python
from sklearn.model_selection import train_test_split
...
    X = df[FEATURES]
    y = df["fruit"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
```

---

## 5. Code Explanation
- **Line 18**: Imports `train_test_split` from `sklearn.model_selection`.
- **Line 37-39**: Splits feature matrix `X` and target vector `y` into four distinct objects:
  - `X_train`: Training features of shape `(45, 4)`
  - `X_test`: Evaluation features of shape `(15, 4)`
  - `y_train`: Training labels of shape `(45,)`
  - `y_test`: Evaluation labels of shape `(15,)`
- The `stratify=y` argument ensures equal representation across all 3 fruit classes in both subsets.

---

## 6. Worked Example

Let's verify the class distribution of `y_train` and `y_test` in Python:

```python
import pandas as pd
from sklearn.model_selection import train_test_split

df = pd.read_csv("data/fruits.csv")
X = df[["sweetness", "weight_g", "size_cm", "color_score"]]
y = df["fruit"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

print("Full dataset distribution:\n", y.value_counts())
print("\nTraining set distribution:\n", y_train.value_counts())
print("\nTest set distribution:\n", y_test.value_counts())
```

**Output:**
```text
Full dataset distribution:
apple     20
banana    20
orange    20
Name: fruit, dtype: int64

Training set distribution:
apple     15
banana    15
orange    15
Name: fruit, dtype: int64

Test set distribution:
apple     5
banana    5
orange    5
Name: fruit, dtype: int64
```

Every single class is represented in equal proportions across both train and test splits!

---

## 7. Step-by-Step Student Instructions

1. Open your terminal in `beginner-projects-main/AI-ML Beginners/projects/05_fruit_sorter`.
2. Launch Python interactive mode: `python3`.
3. Load the data and perform the split as shown in lines 33-39 of `main.py`.
4. Inspect `y_train.value_counts()` and `y_test.value_counts()`.
5. Remove `stratify=y` and re-run with `random_state=123`. Observe how the counts deviate from 5 per class.

---

## 8. Expected Output or Observable Behaviour

When `stratify=y` is included, the test set count for each fruit is always strictly 5. Without `stratify=y`, test counts might fluctuate to 6 apples, 4 bananas, and 5 oranges depending on the random seed.

---

## 9. Practical Exercises

- **Exercise 3.1**: What would the size of `X_train` and `X_test` be if `test_size=0.20` was used instead of `0.25`?
- **Exercise 3.2**: Explain why passing `random_state=42` makes scientific code reproducible.
- **Exercise 3.3**: What error does scikit-learn raise if you pass `stratify=[1, 2]` with a length different from $y$?
- **Exercise 3.4**: Why is a 50/50 train/test split usually avoided on small datasets of 60 items?

---

## 10. Common Mistakes and Debugging

| Mistake | Why it is incorrect | Correction |
|---|---|---|
| Omitting `stratify=y` on small datasets | Random splits can underrepresent or completely omit rare classes | Always supply `stratify=y` for classification datasets |
| Setting `test_size` too high (e.g., 0.8) | Leaves insufficient data for the model to learn reliable patterns | Standard splits range between 0.15 and 0.30 (0.25 is standard) |
| Hardcoding indices instead of using `train_test_split` | Fails to shuffle data, leading to biased partitions if the CSV is sorted by class | Use `train_test_split` with a fixed `random_state` |

---

## 11. Best Practices and Security Considerations

- **Stratify by Default**: In classification tasks, always enable stratification unless dealing with time-series or grouped data.
- **Reproducible Seeds**: Always set `random_state` in educational and benchmark code to ensure consistent results across student machines.
- **Separation Integrity**: Never allow test set labels or features to influence training parameters.

---

## 12. Summary

The fruits dataset contains 60 samples distributed evenly with 20 apples, 20 bananas, and 20 oranges. Using `train_test_split(..., test_size=0.25, random_state=42, stratify=y)` splits the data into 45 training instances (15 per fruit) and 15 testing instances (5 per fruit). Stratified sampling guarantees that class distributions in the test set mirror the real-world dataset.

---

## 13. Knowledge-check Questions

1. How many total samples exist for each fruit variety in `fruits.csv`?
2. How many samples are allocated to `X_train` and `X_test` with `test_size=0.25`?
3. What is the specific purpose of the `stratify=y` parameter?
4. How many test instances of oranges are guaranteed when using `stratify=y`?
5. What is the role of `random_state=42` in data splitting?

---

## 14. References

- scikit-learn `train_test_split` documentation: [https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html](https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html)
- Stratified Sampling Guide: [https://scikit-learn.org/stable/modules/cross_validation.html#stratification](https://scikit-learn.org/stable/modules/cross_validation.html#stratification)
- `main.py` lines 18, 37-39
