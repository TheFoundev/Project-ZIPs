# Lesson 01: Ingesting Fruit Datasets with pandas

**Lesson ID:** lesson-01  
**Module:** module-02  
**Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Load the fruit dataset from disk using `pd.read_csv()`.
- Inspect the schema, column names, dimensions, and memory usage of the resulting DataFrame.
- Check for missing (null) values and confirm data type consistency.
- Explain why robust path construction with `pathlib.Path` prevents `FileNotFoundError`.

---

## 2. Prerequisites
- Completion of Module 01.
- Basic understanding of comma-separated values (CSV) format.

---

## 3. Concept Explanation

### The Role of Data Ingestion in ML Pipelines
Every machine learning workflow begins with reliable data ingestion. The fruit sorting dataset is stored as a CSV file (`data/fruits.csv` or `data/fruit_basket.csv`). CSV files are plain-text representations of tables where commas delimit fields and newlines delimit rows.

When loaded into pandas, the CSV is converted into a **DataFrame**: an in-memory 2D tabular data structure with labeled axes (rows and columns).

### Verifying Data Integrity
Before passing data to an ML algorithm, a data scientist must verify:
1. **Dimensions**: Does the table contain the expected number of observations and features? In our case, 60 rows and 5 columns.
2. **Column Names**: Are the column headers spelled exactly as expected (`fruit`, `sweetness`, `weight_g`, `size_cm`, `color_score`)?
3. **Data Types**: Are measurement features represented as numeric types (`float64` or `int64`) rather than strings?
4. **Missing Values**: Are there any `NaN` or null values that would cause mathematical errors during distance calculation?

### Cross-Platform File Paths
In `main.py`, file loading is handled via:
```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
df = pd.read_csv(DATA / "fruits.csv")
```
Using `Path(__file__).resolve().parent` ensures the script works whether invoked from the parent directory, a nested subfolder, or an automated test harness.

---

## 4. Relevant Code (from main.py, lines 23-24, 32-33)

```python
BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
...
def main() -> None:
    df = pd.read_csv(DATA / "fruits.csv")
```

---

## 5. Code Explanation
- **Line 23 (`BASE = ...`)**: Resolves the absolute path to the directory containing `main.py`.
- **Line 24 (`DATA = BASE / "data"`)**: Appends the `"data"` folder to `BASE` using the slash operator `/` provided by `pathlib`.
- **Line 33 (`pd.read_csv(...)`)**: Reads `fruits.csv` directly from the resolved `DATA` path into `df`.

---

## 6. Worked Example

**Walkthrough:** Let's inspect the dataset using a Python script:
```python
from pathlib import Path
import pandas as pd

DATA = Path("data")
df = pd.read_csv(DATA / "fruits.csv")

print("Dimensions:", df.shape)
print("Data Types:\n", df.dtypes)
print("Missing Values:\n", df.isnull().sum())
print("\nFirst 3 rows:\n", df.head(3))
```

**Output:**
```text
Dimensions: (60, 5)
Data Types:
 fruit           object
sweetness      float64
weight_g         int64
size_cm        float64
color_score    float64
dtype: object
Missing Values:
 fruit          0
sweetness      0
weight_g       0
size_cm        0
color_score    0
dtype: int64

First 3 rows:
    fruit  sweetness  weight_g  size_cm  color_score
0  apple        6.4       165      8.0          8.3
1  apple        7.1       176      7.8          8.2
2  banana       8.1       107     18.7          7.2
```

**Interpretation:**
- All 60 rows are complete with 0 missing values.
- `sweetness`, `size_cm`, and `color_score` are standard 64-bit floating point numbers.
- `weight_g` is an integer.
- `fruit` is an object (string) containing the class labels.

---

## 7. Step-by-Step Student Instructions

1. Open your terminal in `beginner-projects-main/AI-ML Beginners/projects/05_fruit_sorter`.
2. Launch Python interactive mode: `python3`.
3. Import pandas: `import pandas as pd`.
4. Load the dataset: `df = pd.read_csv("data/fruits.csv")`.
5. Run `df.info()` to view index range, memory usage, and non-null counts.
6. Verify that `df.shape == (60, 5)`.

---

## 8. Expected Output or Observable Behaviour

Executing `df.info()` prints:
```text
<class 'pandas.core.frame.DataFrame'>
RangeIndex: 60 entries, 0 to 59
Data columns (total 5 columns):
 #   Column       Non-Null Count  Dtype  
---  ------       --------------  -----  
 0   fruit        60 non-null     object 
 1   sweetness    60 non-null     float64
 2   weight_g     60 non-null     int64  
 3   size_cm      60 non-null     float64
 4   color_score  60 non-null     float64
dtypes: float64(3), int64(1), object(1)
memory usage: 2.5+ KB
```

---

## 9. Practical Exercises

- **Exercise 1.1**: Write a line of code using `df.columns.tolist()` to extract and display all column names.
- **Exercise 1.2**: Check whether `data/fruits.csv` contains any duplicate rows using `df.duplicated().sum()`.
- **Exercise 1.3**: Display the last 4 rows of the dataset using `df.tail(4)`.
- **Exercise 1.4**: How much memory does this DataFrame consume in RAM?

---

## 10. Common Mistakes and Debugging

| Mistake | Why it is incorrect | Correction |
|---|---|---|
| Hardcoding `"data/fruits.csv"` without Path resolution | Fails if the user executes the script from a different current working directory | Use `DATA = BASE / "data"` with `Path(__file__).resolve().parent` |
| Calling `df.read_csv()` instead of `pd.read_csv()` | `read_csv` is a top-level function of the pandas module, not a DataFrame method | Use `pd.read_csv(...)` |
| Assuming missing data doesn't break KNN | Scikit-learn algorithms will throw a `ValueError: Input contains NaN` | Always run `df.isnull().sum()` to confirm data completeness |

---

## 11. Best Practices and Security Considerations

- **Clean Ingestion**: Always inspect `df.isnull().sum()` upon loading any external CSV.
- **Path Portability**: Use `pathlib.Path` to avoid OS-specific slash direction bugs (`\` on Windows vs `/` on Linux).
- **Read-Only Access**: Treat input data files as immutable sources of truth; never overwrite raw data files during model training.

---

## 12. Summary

Data ingestion in `main.py` is implemented using `pandas.read_csv()` anchored to a dynamic `pathlib.Path` location. The dataset consists of 60 records and 5 columns: 1 categorical target column (`fruit`) and 4 clean numeric feature columns (`sweetness`, `weight_g`, `size_cm`, `color_score`) with no missing values.

---

## 13. Knowledge-check Questions

1. How many total rows and columns are in `data/fruits.csv`?
2. What pandas function is used to load CSV data into memory?
3. How many missing (null) values exist in the fruit dataset?
4. What is the data type of the `weight_g` column in pandas?
5. Why is `Path(__file__).resolve().parent` preferred over relative string paths like `"./data"`?

---

## 14. References

- pandas `read_csv` documentation: [https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html](https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html)
- pandas DataFrame `info` guide: [https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.info.html](https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.info.html)
- `main.py` lines 23-33
