# Lesson 02: Feature Value Ranges & Summary Statistics

**Lesson ID:** lesson-02  
**Module:** module-02  
**Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Use `df.describe()` to compute five-number summaries and standard deviations for numeric features.
- Identify the numerical scale discrepancies across sweetness (3.6-8.8), weight (103-237g), size (7.2-18.7cm), and color score (4.9-9.0).
- Group data by class label using `df.groupby('fruit').mean()` to discover distinguishing characteristics of each fruit.
- Explain why large variations in scale motivate feature standardization.

---

## 2. Prerequisites
- Completion of Lesson 01.
- Understanding of basic statistical metrics: mean, minimum, maximum, and standard deviation.

---

## 3. Concept Explanation

### Why Summary Statistics Matter
Before training an algorithm, exploring summary statistics reveals how data points are distributed in space. Summary statistics provide the baseline for:
1. Detecting outliers or unrealistic measurement artifacts.
2. Determining whether certain features exhibit strong discriminating power between classes.
3. Evaluating the scale disparity between different measurements.

### The Five-Number Summary & Standard Deviation
Calling `df.describe()` generates key descriptive statistics:
- **Count**: Number of non-null observations.
- **Mean ($\mu$)**: Arithmetic average of the feature.
- **Standard Deviation ($\sigma$)**: Spread or dispersion around the mean.
- **Min / Max**: Extreme values observed in the dataset.
- **25%, 50% (Median), 75%**: Percentile quartiles showing data concentration.

### Scale Discrepancies in the Fruit Dataset
Notice the tremendous variation in numerical scales across our 4 features:
- **`sweetness`**: Varies from **3.6 to 8.8** (span of ~5.2 units).
- **`size_cm`**: Varies from **7.2 to 18.7** (span of ~11.5 units).
- **`color_score`**: Varies from **4.9 to 9.0** (span of ~4.1 units).
- **`weight_g`**: Varies from **103 to 237** (span of **134 units**!).

Because the values of `weight_g` are measured in hundreds while `sweetness` is measured in single digits, a raw Euclidean distance calculation without normalization would be dominated by weight!

---

## 4. Relevant Code (from main.py, lines 28, 33-35)

```python
FEATURES = ["sweetness", "weight_g", "size_cm", "color_score"]
...
def main() -> None:
    df = pd.read_csv(DATA / "fruits.csv")
    X = df[FEATURES]
    y = df["fruit"]
```

---

## 5. Code Explanation
- **Line 28 (`FEATURES`)**: Specifies the 4 numeric columns to analyze.
- In data exploration, calling `df[FEATURES].describe()` computes statistics across these exact 4 columns.
- Grouping by the target label (`df.groupby("fruit").mean()`) illustrates how each fruit variety separates cleanly along specific physical dimensions.

---

## 6. Worked Example

Let's run `describe()` on `X` and compute the class means:

```python
import pandas as pd
df = pd.read_csv("data/fruits.csv")
FEATURES = ["sweetness", "weight_g", "size_cm", "color_score"]

print("Overall Summary Statistics:")
print(df[FEATURES].describe().round(2))

print("\nMean Values by Fruit Class:")
print(df.groupby("fruit")[FEATURES].mean().round(2))
```

**Output:**
```text
Overall Summary Statistics:
       sweetness  weight_g  size_cm  color_score
count      60.00     60.00    60.00        60.00
mean        6.77    167.38    11.45         7.06
std         1.46     40.09     4.04         1.13
min         3.60    103.00     7.20         4.90
25%         5.40    136.75     8.18         6.08
50%         7.10    166.00     9.15         7.20
75%         7.93    197.50    16.22         7.82
max         8.80    237.00    18.70         9.00

Mean Values by Fruit Class:
        sweetness  weight_g  size_cm  color_score
fruit                                            
apple        6.91    164.55     7.97         8.09
banana       8.08    123.45    16.53         6.76
orange       5.06    204.15     9.23         5.93
```

**Key Takeaways:**
1. **Bananas**: Distinctly longest (`size_cm` mean = 16.53 cm), lightest (`weight_g` mean = 123.45 g), and sweetest (mean = 8.08).
2. **Oranges**: Heaviest (`weight_g` mean = 204.15 g), lowest sweetness (mean = 5.06), and lowest color score (mean = 5.93).
3. **Apples**: Compact (`size_cm` mean = 7.97 cm), medium weight (mean = 164.55 g), and highest color score (mean = 8.09).

---

## 7. Step-by-Step Student Instructions

1. Open your terminal in the project directory.
2. Launch Python: `python3`.
3. Load the dataset:
   ```python
   import pandas as pd
   df = pd.read_csv("data/fruits.csv")
   ```
4. Execute `df.describe()` and examine the `min`, `max`, and `std` rows.
5. Execute `df.groupby('fruit').agg(['min', 'max'])` to observe non-overlapping ranges between classes.

---

## 8. Expected Output or Observable Behaviour

Notice that bananas have a minimum `size_cm` of 13.6 cm, whereas the maximum `size_cm` for apples is only 9.0 cm. This means `size_cm` alone provides a clear boundary separating bananas from apples and oranges!

---

## 9. Practical Exercises

- **Exercise 2.1**: Which fruit has the lowest minimum sweetness score, and what is its value?
- **Exercise 2.2**: Calculate the standard deviation of `weight_g` compared to `sweetness`. Why is the standard deviation of weight so much larger?
- **Exercise 2.3**: What is the median sweetness score of apples?
- **Exercise 2.4**: Write a pandas query that returns all fruits with `weight_g > 200`. Which fruit type dominates this result?

---

## 10. Common Mistakes and Debugging

| Mistake | Why it is incorrect | Correction |
|---|---|---|
| Running `describe()` on `df['fruit']` | `fruit` is a categorical string column; standard numeric metrics (mean, std) do not exist | Call `describe()` on numeric columns or pass `include='all'` |
| Ignoring feature scale differences | Assuming raw weights and sweetness can be directly compared without normalization | Recognize that weight numbers are 20-30x larger than sweetness numbers |
| Confusing `std` with `mean` | `mean` is the average value, while `std` indicates how spread out the values are | Use `mean` for central tendency, `std` for dispersion |

---

## 11. Best Practices and Security Considerations

- **Class-Conditional Exploration**: Always inspect feature distributions broken down by class label (`groupby`) to confirm the problem is learnable.
- **Sanity Checking**: Verify that measurement values are biologically plausible (e.g., fruit weight > 0, size > 0).
- **Safe Aggregations**: Ensure numeric columns are explicitly isolated to prevent warnings in newer pandas versions.

---

## 12. Summary

Using `df.describe()` and `df.groupby()`, we discover clear physical signatures for each fruit: bananas are long and light, oranges are heavy and less sweet, and apples are compact with high color scores. However, the features operate on drastically different numerical scales (weights in hundreds vs. sweetness in single digits), underscoring the necessity of feature scaling.

---

## 13. Knowledge-check Questions

1. Which fruit class has the highest average sweetness?
2. Which fruit class has the highest average weight in grams?
3. What is the approximate range of `size_cm` across all fruits in the dataset?
4. Why is `weight_g` the feature with the largest standard deviation?
5. Which single feature most clearly separates bananas from apples and oranges without overlap?

---

## 14. References

- pandas `DataFrame.describe` documentation: [https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.describe.html](https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.describe.html)
- pandas `groupby` user guide: [https://pandas.pydata.org/docs/user_guide/groupby.html](https://pandas.pydata.org/docs/user_guide/groupby.html)
- `main.py` lines 28, 33-35
