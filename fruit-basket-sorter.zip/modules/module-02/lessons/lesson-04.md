# Lesson 04: Visualizing Multi-Class Feature Relationships

**Lesson ID:** lesson-04  
**Module:** module-02  
**Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Construct 2D scatter plots using `matplotlib.pyplot` to visualize relationships between numeric features.
- Apply a custom hex color mapping (`COLOURS`) to distinguish multiple classes visually.
- Group tabular data using `df.groupby("fruit")` to iterate and render clean scatter distributions.
- Analyze how sweetness and weight separate apples, bananas, and oranges into natural clusters.
- Configure figure styling: labels, titles, legends, alpha transparency, and grid lines.

---

## 2. Prerequisites
- Completion of Lessons 01, 02, and 03.
- Basic understanding of matplotlib axes and scatter plots (`ax.scatter`).

---

## 3. Concept Explanation

### Why Visualization is Vital in Multi-Class Machine Learning
Numbers in tabular spreadsheets can obscure spatial geometric relationships. By plotting features against each other on a 2D Cartesian plane, we can immediately answer foundational questions:
1. **Are the classes linearly separable or naturally clustered?**
2. **Do any classes overlap significantly in feature space?**
3. **Where does a new query point (like our mystery fruit) land relative to existing clusters?**

### Mapping Categorical Labels to Visual Palettes
In multi-class visualization, assigning distinct, intuitive colors to each category enhances interpretability. In `main.py`, a dictionary maps class strings to hex color codes:
```python
COLOURS = {
    "apple": "#c0392b",   # Vibrant Crimson Red
    "banana": "#f1c40f",  # Bright Yellow
    "orange": "#e67e22"   # Citrus Orange
}
```

### Iterating Over Groups with `df.groupby()`
Instead of writing separate filtering statements for each fruit type (`df[df['fruit'] == 'apple']`, etc.), pandas provides `df.groupby("fruit")`. This yields pairs of `(fruit_name, group_dataframe)`:
```python
for fruit, group in df.groupby("fruit"):
    ax.scatter(
        group["sweetness"],
        group["weight_g"],
        s=60,
        alpha=0.8,
        label=fruit,
        color=COLOURS[fruit],
    )
```
- `s=60`: Sets the marker area in points.
- `alpha=0.8`: Adds subtle transparency so overlapping points remain visible.
- `label=fruit`: Generates legend entries automatically.
- `color=COLOURS[fruit]`: Pulls the fruit-specific hex color.

### Observing Natural Fruit Clusters
When plotting `sweetness` on the X-axis and `weight_g` on the Y-axis:
- **Bananas** cluster in the bottom-right corner: high sweetness (7.2–8.8) and low weight (103–142 g).
- **Oranges** cluster in the top-left quadrant: lower sweetness (3.6–5.7) and high weight (161–237 g).
- **Apples** form a distinct cluster in the middle-right: moderate sweetness (6.1–8.0) and medium weight (136–187 g).

Because these clusters are spatially well-separated, a distance-based algorithm like K-Nearest Neighbours can achieve high classification accuracy!

---

## 4. Relevant Code (from main.py, lines 29, 71-81, 91-98)

```python
COLOURS = {"apple": "#c0392b", "banana": "#f1c40f", "orange": "#e67e22"}
...
    # ---- Scatter plot --------------------------------------------------
    fig, ax = plt.subplots(figsize=(7.5, 5.5))
    for fruit, group in df.groupby("fruit"):
        ax.scatter(
            group["sweetness"],
            group["weight_g"],
            s=60,
            alpha=0.8,
            label=fruit,
            color=COLOURS[fruit],
        )
...
    ax.set_xlabel("Sweetness score")
    ax.set_ylabel("Weight (g)")
    ax.set_title("Similar fruits form groups")
    ax.legend()
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(OUT / "fruit_scatter.png", dpi=150, bbox_inches="tight")
    plt.close(fig)
```

---

## 5. Code Explanation
- **Line 29**: Defines `COLOURS`, a dictionary associating each fruit class with an appropriate visual hex color.
- **Line 72**: Creates a matplotlib Figure and Axes object with dimensions 7.5 x 5.5 inches.
- **Lines 73-81**: Iterates through each unique fruit category, plotting sweetness vs. weight with size 60 and 80% opacity.
- **Lines 91-95**: Configures descriptive axis labels, a title ("Similar fruits form groups"), legend, and subtle grid lines with `alpha=0.25`.
- **Lines 96-98**: Adjusts layout with `tight_layout()`, saves the figure to disk at 150 DPI, and closes the figure buffer with `plt.close(fig)`.

---

## 6. Worked Example

Let's inspect the coordinates of representative cluster centers:

```text
Apple Center:   Sweetness ~ 6.9,  Weight ~ 165 g
Banana Center:  Sweetness ~ 8.1,  Weight ~ 123 g
Orange Center:  Sweetness ~ 5.1,  Weight ~ 204 g
```

If we receive an unknown fruit with `Sweetness = 7.2` and `Weight = 170 g`:
- Distance to Banana Center: $\Delta \text{weight} = |170 - 123| = 47\text{ g}$
- Distance to Orange Center: $\Delta \text{weight} = |170 - 204| = 34\text{ g}$
- Distance to Apple Center: $\Delta \text{weight} = |170 - 165| = 5\text{ g}$, $\Delta \text{sweetness} = |7.2 - 6.9| = 0.3$

Visually and geometrically, the unknown fruit falls directly into the **Apple** cluster!

---

## 7. Step-by-Step Student Instructions

1. Open `main.py` and inspect lines 71 to 98.
2. Run `python main.py` in your terminal.
3. Open the resulting image `outputs/fruit_scatter.png` in an image viewer.
4. Locate the red points (apples), yellow points (bananas), and orange points (oranges).
5. Identify the black star marker (`*`). Notice which cluster surrounds it.

---

## 8. Expected Output or Observable Behaviour

The generated image `outputs/fruit_scatter.png` displays three cleanly segregated clusters:
- Yellow dots grouped at the lower right.
- Orange dots grouped at the upper left.
- Red dots clustered in the center right.
- A large black star placed at coordinates $(7.2, 170)$, sitting completely inside the red apple cluster.

---

## 9. Practical Exercises

- **Exercise 4.1**: Modify lines 75-76 in a copy of the script to plot `size_cm` versus `color_score` instead of `sweetness` versus `weight_g`. How well do classes separate in that view?
- **Exercise 4.2**: Change `alpha=0.8` to `alpha=0.2`. What happens to the visibility of the points?
- **Exercise 4.3**: What is the visual effect of setting `dpi=300` instead of `dpi=150` in `fig.savefig()`?
- **Exercise 4.4**: Why is `bbox_inches="tight"` used when saving matplotlib figures?

---

## 10. Common Mistakes and Debugging

| Mistake | Why it is incorrect | Correction |
|---|---|---|
| Omitting `plt.close(fig)` | Matplotlib retains figure objects in RAM, causing memory leaks in loops | Always call `plt.close(fig)` after saving figures |
| Forgetting `ax.legend()` | Legend entries will not be drawn on the plot | Add `ax.legend()` to display the class labels |
| Passing unmapped colors | If a new fruit class appears that is not in `COLOURS`, Python raises a `KeyError` | Use `.get(fruit, '#7f8c8d')` to provide a fallback color |

---

## 11. Best Practices and Security Considerations

- **Color Accessibility**: Choose color palettes with high mutual contrast so classes can be distinguished even under monochrome viewing or by color-blind users.
- **Clean Figures**: Always label both axes with units of measurement (e.g., "Weight (g)").
- **Memory Safety**: Always close matplotlib figures explicitly with `plt.close()` in production or automated scripts.

---

## 12. Summary

Visualizing tabular data with scatter plots bridges raw numbers and geometric intuition. In `main.py`, `df.groupby("fruit")` combined with a custom color palette (`COLOURS`) reveals that apples, bananas, and oranges form distinct spatial clusters in the sweetness-weight plane, explaining why distance-based classification succeeds so decisively.

---

## 13. Knowledge-check Questions

1. Which hex color represents the `apple` class in `main.py`?
2. What does `df.groupby("fruit")` yield during iteration?
3. Where do bananas cluster on the sweetness vs. weight scatter plot?
4. What is the purpose of setting `alpha=0.8` on scatter markers?
5. Why is `fig.tight_layout()` recommended before saving matplotlib plots?

---

## 14. References

- matplotlib `pyplot.scatter` API: [https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.scatter.html](https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.scatter.html)
- matplotlib Figure saving and DPI reference: [https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.savefig.html](https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.savefig.html)
- `main.py` lines 29, 71-98
