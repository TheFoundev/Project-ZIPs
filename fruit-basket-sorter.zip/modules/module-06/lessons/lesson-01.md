# Lesson 01: End-to-End Pipeline Execution

**Lesson ID:** lesson-01  
**Module:** module-06  
**Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Execute `main.py` seamlessly from the command line interface.
- Trace the lifecycle of data and objects through each stage of the script.
- Audit terminal output to verify successful training, test evaluation, and inference.
- Explain the role of the entry-point block `if __name__ == "__main__": main()`.

---

## 2. Prerequisites
- Completion of Modules 01 through 05.
- Basic terminal and Python execution environment.

---

## 3. Concept Explanation

### The Anatomy of an End-to-End Machine Learning Script
An end-to-end Python script unites data loading, preprocessing, model fitting, metric calculation, operational inference, visual plotting, and disk persistence into an automated pipeline. When you execute:
```bash
python main.py
```
The Python interpreter initiates a deterministic sequence of operations:
1. **Module Importation & Headless Backend Selection** (`lines 10-21`): The `Agg` backend is selected before Pyplot initializes.
2. **Directory & Path Resolution** (`lines 23-26`): `pathlib` establishes `BASE`, `DATA`, and ensures `outputs/` exists via `.mkdir(exist_ok=True)`.
3. **Data Ingestion** (`lines 33-35`): `data/fruits.csv` is loaded into a 60-row DataFrame, separating features $X$ from labels $y$.
4. **Stratified Split** (`lines 37-39`): `train_test_split` partitions data into 45 training instances and 15 testing instances with balanced class distribution.
5. **Pipeline Construction & Fitting** (`lines 41-47`): `StandardScaler` calculates training parameters ($\mu, \sigma$) and fits `KNeighborsClassifier(n_neighbors=5)`.
6. **Test Evaluation** (`lines 48-56`): Test instances are scaled and evaluated; accuracy (100.0%) and the classification report are printed to stdout.
7. **Mystery Fruit Scoring** (`lines 57-70`): The unlabelled query fruit is transformed and predicted as `"apple"` with 100% confidence.
8. **Scatter Plot Generation** (`lines 72-98`): Sweetness vs. weight distribution is rendered and exported to `outputs/fruit_scatter.png`.
9. **Confusion Matrix Generation** (`lines 101-108`): The 3x3 classification matrix is plotted with the `Oranges` colormap and saved to `outputs/confusion_matrix.png`.
10. **Metrics Persistence & Final Confirmation** (`lines 110-116`): The text report is committed to `outputs/metrics.txt`, and user suggestions are printed.

### The Entry Point Guard
At line 119:
```python
if __name__ == "__main__":
    main()
```
This standard Python idiom ensures `main()` executes only when the script is directly called from the CLI. If `main.py` is imported as a library by another module (or automated test suite), it exposes functions and constants without executing the pipeline immediately.

---

## 4. Relevant Code (from main.py, lines 32, 115-120)

```python
def main() -> None:
...
    print("\nSaved: outputs/fruit_scatter.png, outputs/confusion_matrix.png, outputs/metrics.txt")
    print("Try this: change n_neighbors from 5 to 1 or 9 and compare.")

if __name__ == "__main__":
    main()
```

---

## 5. Code Explanation
- **Line 32 (`def main() -> None:`)**: Defines the primary application function with a type hint indicating it returns `None`.
- **Lines 115-116**: Prints a confirmation message listing the three generated output artifacts and suggests hyperparameter experiments to the user.
- **Lines 119-120**: Invokes `main()` when the file is run directly.

---

## 6. Worked Example

Let's trace the terminal execution output from start to finish:

```bash
$ python main.py
============================================================
THE FRUIT BASKET SORTER
============================================================
Accuracy: 100.0%

              precision    recall  f1-score   support

       apple       1.00      1.00      1.00         5
      banana       1.00      1.00      1.00         5
      orange       1.00      1.00      1.00         5

    accuracy                           1.00        15
   macro avg       1.00      1.00      1.00        15
weighted avg       1.00      1.00      1.00        15

Mystery fruit -> apple (100% confident)

Saved: outputs/fruit_scatter.png, outputs/confusion_matrix.png, outputs/metrics.txt
Try this: change n_neighbors from 5 to 1 or 9 and compare.
```

The script executes in under 1 second, providing instant feedback and producing all required outputs.

---

## 7. Step-by-Step Student Instructions

1. Open your terminal.
2. Navigate to `beginner-projects-main/AI-ML Beginners/projects/05_fruit_sorter`.
3. Check the exit status of Python after running:
   ```bash
   python main.py
   echo "Exit status: $?"
   ```
4. Confirm the exit status is `0` (success).
5. Inspect the contents of the `outputs` directory:
   ```bash
   ls -lh outputs/
   ```

---

## 8. Expected Output or Observable Behaviour

The terminal displays the complete text output, exits cleanly with exit code 0, and updates the timestamp on the three output files in `outputs/`.

---

## 9. Practical Exercises

- **Exercise 1.1**: Run `python -m timeit -n 1 -r 1 "import main; main.main()"` to benchmark script runtime.
- **Exercise 1.2**: Import `main` from an interactive Python shell. Verify that `main()` does not automatically run upon import.
- **Exercise 1.3**: What happens if you execute `main.py` from outside its parent directory (e.g. `python projects/05_fruit_sorter/main.py`)? Does `BASE` resolve correctly?
- **Exercise 1.4**: Why is returning exit code 0 important for automated testing and CI/CD pipelines?

---

## 10. Common Mistakes and Debugging

| Mistake | Why it is incorrect | Correction |
|---|---|---|
| Running `main.py` without dependencies installed | Raises `ModuleNotFoundError: No module named 'sklearn'` | Run `pip install -r requirements.txt` first |
| Omitting `if __name__ == "__main__":` | Code executes unconditionally whenever the file is imported | Always encapsulate executable script logic inside an entry-point guard |
| Assuming the script modifies `data/fruits.csv` | Pipeline code should treat raw data as read-only | Check file modification timestamps to confirm input data is unchanged |

---

## 11. Best Practices and Security Considerations

- **Modular Organization**: Encapsulate logic in functions (`main()`) rather than running raw script-level code.
- **Clean Exit**: Ensure scripts terminate with status code 0 on success and non-zero on failure.
- **Zero Side Effects**: Code should only create files within specified output directories (`outputs/`).

---

## 12. Summary

Executing `main.py` runs a complete, modular machine learning pipeline in under one second. From headless matplotlib initialization to model fitting, test evaluation, mystery fruit inference, and artifact generation, the entire workflow is reproducible and self-contained.

---

## 13. Knowledge-check Questions

1. What command executes the complete fruit basket sorter pipeline?
2. What does `if __name__ == "__main__":` accomplish?
3. How many distinct artifact files are saved to `outputs/` during execution?
4. What exit status code indicates a successful Python execution?
5. Why does `Path(__file__).resolve().parent` ensure portability across different execution directories?

---

## 14. References

- Python `__main__` Top-Level Script Environment: [https://docs.python.org/3/library/__main__.html](https://docs.python.org/3/library/__main__.html)
- Python Command Line Execution: [https://docs.python.org/3/using/cmdline.html](https://docs.python.org/3/using/cmdline.html)
- `main.py` lines 32-120
