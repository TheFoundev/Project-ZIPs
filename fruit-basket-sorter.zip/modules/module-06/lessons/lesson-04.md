# Lesson 04: Real-World Extensions & Productionization

**Lesson ID:** lesson-04  
**Module:** module-06  
**Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Formulate real-world engineering architectures for deploying fruit classification models to automated sorting lines.
- Describe how to extend the classification taxonomy to additional fruit varieties (e.g. lemons, pears, strawberries).
- Design strategies for handling sensor noise, outliers, and damaged produce.
- Package the scikit-learn pipeline into a lightweight web microservice (using FastAPI).
- Understand continuous monitoring, model drift, and retraining triggers in production.

---

## 2. Prerequisites
- Completion of Lessons 01, 02, and 03.
- Familiarity with basic client-server and API concepts.

---

## 3. Concept Explanation

### From Desktop Script to Industrial Conveyor Sorter
In an agricultural packaging warehouse, our Python script is not run manually by a person typing commands. Instead, it forms the core analytical brain of an **IoT sorting system**:
1. **Sensors at the Chute**:
   - High-precision load cells measure weight ($g$).
   - Optical time-of-flight laser sensors measure size ($cm$).
   - Spectrophotometers / NIR (Near-Infrared) sensors measure sugar content / sweetness Brix.
   - RGB machine vision cameras calculate dominant chromaticity ($color\_score$).
2. **Real-Time Edge Inference**: The sensor readings are sent via MQTT or WebSockets to an industrial edge computer running our Python pipeline.
3. **Pneumatic Diverters**: If the model predicts `orange` with $\ge 90\%$ confidence, a pneumatic actuator fires, pushing the orange into Bin 3.

```mermaid
flowchart LR
    A["Conveyor Sensors\n- Load cell: 170g\n- NIR sweetness: 7.2\n- Optical size: 8.5cm\n- RGB color: 8.0"] --> B["Edge Controller\nFastAPI / Pipeline\nStandardScaler + KNN"]
    B --> C{"Confidence Check\nProbability >= 90%?"}
    C -- Yes --> D["Pneumatic Actuator\nDivert to Apple Bin"]
    C -- No --> E["Inspection Line\nManual Sorting Station"]
```

### Extending the Fruit Taxonomy
To expand the system to recognize new produce (e.g., lemons, pears, or watermelons):
1. **Collect Labeled Data**: Harvest 20-50 physical measurements for each new variety.
2. **Update the Target Classes**: Append new labels to $y$.
3. **Re-fit Pipeline**: `model.fit(X_train_new, y_train_new)`.
4. **Update Color Maps**: Assign distinctive hex colors for visual tracking:
   ```python
   COLOURS = {
       "apple": "#c0392b",
       "banana": "#f1c40f",
       "orange": "#e67e22",
       "lemon": "#f39c12",
       "pear": "#27ae60"
   }
   ```

### Packaging as a REST Microservice with FastAPI
In modern production architectures, models are wrapped in lightweight HTTP APIs so multiple sorting lines can query them simultaneously:

```python
from fastapi import FastAPI
from pydantic import BaseModel
import pandas as pd
import joblib

app = FastAPI(title="Fruit Sorter Service")
model = joblib.load("fruit_pipeline.joblib")

class FruitMeasurement(BaseModel):
    sweetness: float
    weight_g: float
    size_cm: float
    color_score: float

@app.post("/predict")
def predict_fruit(item: FruitMeasurement):
    df_query = pd.DataFrame([item.dict()])
    prediction = model.predict(df_query)[0]
    confidence = float(model.predict_proba(df_query).max())
    return {"prediction": prediction, "confidence": confidence}
```

---

## 4. Relevant Code (from main.py, lines 28-30, 41-46, 57-70)

```python
FEATURES = ["sweetness", "weight_g", "size_cm", "color_score"]
COLOURS = {"apple": "#c0392b", "banana": "#f1c40f", "orange": "#e67e22"}
...
    mystery = pd.DataFrame(
        [
            {
                "sweetness": 7.2,
                "weight_g": 170,
                "size_cm": 8.5,
                "color_score": 8.0,
            }
        ]
    )
    mystery_prediction = model.predict(mystery)[0]
    mystery_probability = model.predict_proba(mystery).max()
    print(f"Mystery fruit -> {mystery_prediction} ({mystery_probability:.0%} confident)")
```

---

## 5. Code Explanation
- The structure of `mystery` in lines 57-66 directly mirrors a JSON request body received by an industrial REST endpoint.
- Calling `model.predict()` and `model.predict_proba()` provides both the actionable routing decision and the risk-mitigating confidence score.

---

## 6. Worked Example

Let's test model serialization using `joblib` (saving the trained model to disk and reloading it for standalone inference):

```python
import joblib
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier

df = pd.read_csv("data/fruits.csv")
X = df[["sweetness", "weight_g", "size_cm", "color_score"]]
y = df["fruit"]

# Train pipeline
model = Pipeline([("scale", StandardScaler()), ("knn", KNeighborsClassifier(5))])
model.fit(X, y)

# Save pipeline to a single file
joblib.dump(model, "outputs/fruit_pipeline.joblib")
print("Saved pipeline to outputs/fruit_pipeline.joblib")

# Reload and test in a clean environment
loaded_model = joblib.load("outputs/fruit_pipeline.joblib")
mystery = pd.DataFrame([{"sweetness": 7.2, "weight_g": 170, "size_cm": 8.5, "color_score": 8.0}])

print("Reloaded Model Prediction:", loaded_model.predict(mystery)[0])
print("Reloaded Model Confidence:", f"{loaded_model.predict_proba(mystery).max():.0%}")
```

**Output:**
```text
Saved pipeline to outputs/fruit_pipeline.joblib
Reloaded Model Prediction: apple
Reloaded Model Confidence: 100%
```

The pipeline, its learned scaling parameters, and all reference vectors are packaged into a single deployable file!

---

## 7. Step-by-Step Student Instructions

1. Open your terminal in the project directory.
2. Launch Python: `python3`.
3. Import `joblib` and save the fitted model as shown in the worked example.
4. Verify the file size of `outputs/fruit_pipeline.joblib` using `ls -lh outputs/`.
5. Notice that it is small (under 15 KB), making it lightweight enough to run on low-power edge microcontrollers like Raspberry Pi or NVIDIA Jetson Nano.

---

## 8. Expected Output or Observable Behaviour

The model file `fruit_pipeline.joblib` is created. When reloaded, it performs inference instantaneously without needing the original training CSV file.

---

## 9. Practical Exercises

- **Exercise 4.1**: What would happen if a piece of fruit on the conveyor belt was crushed, registering `weight_g = 15` and `size_cm = 2.0`? How should your software guard against invalid inputs?
- **Exercise 4.2**: Design an input validation schema using Python type hints that rejects negative sweetness scores.
- **Exercise 4.3**: How would you detect "data drift" if an orchard starts harvesting a new hybrid variety of apple that is 30% heavier than historical apples?
- **Exercise 4.4**: Why is `joblib` preferred over Python's standard `pickle` for scikit-learn models?

---

## 10. Common Mistakes and Debugging

| Mistake | Why it is incorrect | Correction |
|---|---|---|
| Retraining the model on every single API request | Extremely slow and causes massive memory usage | Train once, serialize with `joblib.dump`, and load once at server startup |
| Trusting unvalidated JSON payloads from external sensors | Invalid data types or missing fields crash the inference server | Use Pydantic models to validate input schemas |
| Neglecting confidence thresholding | Low-confidence classifications could misroute expensive produce | Divert queries with confidence $< 80\%$ to manual inspection |

---

## 11. Best Practices and Security Considerations

- **Schema Enforcement**: Always validate input field names, data types, and realistic physical bounds before passing queries to `model.predict()`.
- **Deserialization Security**: Never load untrusted `.joblib` or `.pkl` files from public internet sources, as pickled files can execute arbitrary Python bytecode.
- **Model Monitoring**: Log inference latency and confidence distributions over time to detect camera lens dirt or sensor drift.

---

## 12. Summary

Deploying The Fruit Basket Sorter into production bridges the gap between educational scripts and automated industrial agriculture. By serializing the scikit-learn pipeline with `joblib`, wrapping it in a FastAPI microservice, and instituting input validation and confidence thresholds, the system provides high-speed, reliable sorting for modern robotic conveyor lines.

---

## 13. Knowledge-check Questions

1. What physical sensors in an automated sorting facility capture the 4 fruit features?
2. What Python library is commonly used to serialize and deserialize scikit-learn pipelines?
3. Why is retraining a model on every HTTP inference request an anti-pattern?
4. What operational action should an automated sorting line take if model confidence is below 70%?
5. Why is deserializing unverified `.pkl` or `.joblib` files from unknown sources a security risk?

---

## 14. References

- Model Persistence with joblib: [https://scikit-learn.org/stable/model_persistence.html](https://scikit-learn.org/stable/model_persistence.html)
- FastAPI Modern Python Web Framework: [https://fastapi.tiangolo.com/](https://fastapi.tiangolo.com/)
- `main.py` lines 28-30, 41-46, 57-70
