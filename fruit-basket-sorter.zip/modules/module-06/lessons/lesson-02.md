# Lesson 02: Logging and Artifact Inspection

**Lesson ID:** lesson-02  
**Module:** module-06  
**Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Audit and inspect all three generated files in the `outputs/` folder.
- Parse the structured plain-text report inside `outputs/metrics.txt`.
- Verify raster image properties (resolution, dimensions) of `fruit_scatter.png` and `confusion_matrix.png`.
- Understand why context managers (`with open(...)`) and UTF-8 encodings are essential for robust disk I/O.

---

## 2. Prerequisites
- Completion of Lesson 01.
- Basic command line file inspection commands (`cat`, `head`, `ls`).

---

## 3. Concept Explanation

### The Importance of Persistent ML Artifacts
In production machine learning systems, terminal printouts disappear when the terminal closes. Machine learning operations (MLOps) relies on **persistent artifacts** to record:
1. **Model Audit Trails**: What exact accuracy and F1 scores were achieved?
2. **Visual Diagnostics**: Are clusters cleanly separated, or is overlap emerging?
3. **Inference Records**: What was the input query, the predicted class, and the model's confidence?

### Inspecting `outputs/metrics.txt`
In `main.py`, lines 110-114 write key results using a Python context manager:
```python
with open(OUT / "metrics.txt", "w", encoding="utf-8") as handle:
    handle.write(f"accuracy: {accuracy:.4f}\n")
    handle.write(f"mystery prediction: {mystery_prediction} ({mystery_probability:.4f})\n\n")
    handle.write(classification_report(y_test, predictions, zero_division=0))
```
- **Context Manager (`with open(...) as handle:`)**: Automatically flushes and closes the file handle upon exiting the block, even if an exception occurs.
- **Explicit Encoding (`encoding="utf-8"`)**: Guarantees cross-platform text consistency, preventing character encoding bugs between Windows (cp1252) and Linux/macOS (utf-8).

### Inspecting Raster Artifacts
1. **`fruit_scatter.png`**:
   - Resolution: 150 DPI
   - Format: PNG (lossless raster compression)
   - Content: Multi-class 2D scatter of sweetness vs. weight with the mystery fruit rendered as a prominent star.
2. **`confusion_matrix.png`**:
   - Resolution: 150 DPI
   - Format: PNG
   - Content: 3x3 heatmap showing true vs. predicted counts with the `Oranges` colormap.

---

## 4. Relevant Code (from main.py, lines 97, 107, 110-115)

```python
    fig.savefig(OUT / "fruit_scatter.png", dpi=150, bbox_inches="tight")
...
    fig.savefig(OUT / "confusion_matrix.png", dpi=150, bbox_inches="tight")
...
    with open(OUT / "metrics.txt", "w", encoding="utf-8") as handle:
        handle.write(f"accuracy: {accuracy:.4f}\n")
        handle.write(f"mystery prediction: {mystery_prediction} ({mystery_probability:.4f})\n\n")
        handle.write(classification_report(y_test, predictions, zero_division=0))

    print("\nSaved: outputs/fruit_scatter.png, outputs/confusion_matrix.png, outputs/metrics.txt")
```

---

## 5. Code Explanation
- **Line 97 & 107**: Calls `fig.savefig()` with `dpi=150` and `bbox_inches="tight"`, writing raster plots directly to the `OUT` directory.
- **Lines 110-114**: Opens `metrics.txt` in write mode (`"w"`) with UTF-8 encoding, writing the accuracy score formatted to 4 decimal places (`1.0000`), the mystery prediction with confidence (`apple (1.0000)`), and the full classification report table.
- **Line 115**: Confirms saved paths to the terminal.

---

## 6. Worked Example

Let's read and parse `outputs/metrics.txt` programmatically using Python:

```python
from pathlib import Path

metrics_path = Path("outputs/metrics.txt")

# Read entire file
content = metrics_path.read_text(encoding="utf-8")
print("=== Contents of outputs/metrics.txt ===")
print(content)

# Extract key values
lines = content.strip().split("\n")
accuracy_val = float(lines[0].split(":")[1].strip())
prediction_val = lines[1].split(":")[1].strip()

print("Extracted Accuracy:", accuracy_val)
print("Extracted Prediction:", prediction_val)
```

**Output:**
```text
=== Contents of outputs/metrics.txt ===
accuracy: 1.0000
mystery prediction: apple (1.0000)

              precision    recall  f1-score   support

       apple       1.00      1.00      1.00         5
      banana       1.00      1.00      1.00         5
      orange       1.00      1.00      1.00         5

    accuracy                           1.00        15
   macro avg       1.00      1.00      1.00        15
weighted avg       1.00      1.00      1.00        15

Extracted Accuracy: 1.0
Extracted Prediction: apple (1.0000)
```

---

## 7. Step-by-Step Student Instructions

1. Open your terminal in `beginner-projects-main/AI-ML Beginners/projects/05_fruit_sorter`.
2. Inspect the file size and permissions of the generated files:
   ```bash
   ls -la outputs/
   ```
3. Display `metrics.txt` in your terminal:
   ```bash
   cat outputs/metrics.txt
   ```
4. Verify that line 1 says `accuracy: 1.0000` and line 2 says `mystery prediction: apple (1.0000)`.

---

## 8. Expected Output or Observable Behaviour

The command `cat outputs/metrics.txt` prints the complete 12-line metrics report matching the console output. Both image files are verified to be valid PNG images with non-zero sizes.

---

## 9. Practical Exercises

- **Exercise 2.1**: Write a Python script that asserts `metrics.exists()` and verifies that `accuracy >= 0.95`.
- **Exercise 2.2**: Use Python's built-in `file` utility or PIL to inspect the image dimensions (width, height in pixels) of `outputs/fruit_scatter.png`.
- **Exercise 2.3**: What happens if you change mode `"w"` to `"a"` in `open()`? Why is `"w"` preferred for reproducible batch runs?
- **Exercise 2.4**: Why is UTF-8 encoding explicitly recommended when writing text files on Windows?

---

## 10. Common Mistakes and Debugging

| Mistake | Why it is incorrect | Correction |
|---|---|---|
| Omitting `encoding="utf-8"` | Default system encoding varies across operating systems (cp1252 on Windows) | Always specify `encoding="utf-8"` |
| Forgetting `handle.close()` when not using `with` | Files may remain locked open in memory, preventing other programs from reading | Always use `with open(...)` context managers |
| Hardcoding non-portable path strings | May fail if paths contain spaces or backslashes | Use `OUT / "metrics.txt"` with `pathlib` |

---

## 11. Best Practices and Security Considerations

- **Atomic Writes**: For critical systems, write to temporary files first and atomically rename to avoid partial writes during crashes.
- **Explicit Formatting**: Format numeric values to fixed decimal places (`:.4f`) to facilitate automated parsing.
- **Clean File Lifecycle**: Ensure temporary debugging files are deleted or ignored via `.gitignore`.

---

## 12. Summary

The `outputs/` directory stores three core artifacts: `fruit_scatter.png`, `confusion_matrix.png`, and `metrics.txt`. By utilizing context managers and explicit UTF-8 encodings, `main.py` provides persistent, auditable documentation of model accuracy (1.0000) and mystery fruit inference (apple at 1.0000 confidence).

---

## 13. Knowledge-check Questions

1. What three files are written to the `outputs/` directory?
2. What accuracy value is recorded on line 1 of `metrics.txt`?
3. What mystery prediction and confidence are recorded on line 2 of `metrics.txt`?
4. Why is `with open(...) as handle:` preferred over calling `handle.close()` manually?
5. Why is `encoding="utf-8"` essential for cross-platform portability?

---

## 14. References

- Python File I/O and Context Managers: [https://docs.python.org/3/tutorial/inputoutput.html#reading-and-writing-files](https://docs.python.org/3/tutorial/inputoutput.html#reading-and-writing-files)
- Python `pathlib.Path.read_text`: [https://docs.python.org/3/library/pathlib.html#pathlib.Path.read_text](https://docs.python.org/3/library/pathlib.html#pathlib.Path.read_text)
- `main.py` lines 97, 107, 110-115
