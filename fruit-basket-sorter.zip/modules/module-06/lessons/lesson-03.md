# Lesson 03: Comparing KNN to Alternative Classifiers

**Lesson ID:** lesson-03  
**Module:** module-06  
**Duration:** 15 minutes  

---

## 1. Purpose and Learning Objectives

By the end of this lesson, you will be able to:
- Compare K-Nearest Neighbours against alternative classification algorithms: Decision Trees, Logistic Regression, Random Forests, and Support Vector Machines (SVM).
- Evaluate the tradeoffs between instance-based learners (KNN) and parametric/eager learners.
- Explain why KNN has $O(1)$ training time but $O(N \cdot D)$ inference time.
- Identify which models require feature scaling and which are scale-invariant.
- Benchmark alternative classifiers on the fruits dataset.

---

## 2. Prerequisites
- Completion of Lessons 01 and 02.
- Understanding of multi-class classification and feature scaling.

---

## 3. Concept Explanation

### The Landscape of Classification Algorithms
While KNN is an exceptionally intuitive, effective algorithm for introductory machine learning, no single algorithm dominates all scenarios (the "No Free Lunch" theorem). Comparing KNN against alternatives reveals fundamental engineering tradeoffs:

| Algorithm | Model Type | Feature Scaling Required? | Training Complexity | Inference Complexity | Interpretability |
|---|---|---|---|---|---|
| **K-Nearest Neighbours (KNN)** | Non-parametric, instance-based | **Yes** (Strictly required) | $O(1)$ (Instant, just stores points) | $O(N \cdot D)$ (Must calculate distance to all training points) | High (can inspect nearest training samples) |
| **Decision Tree** | Non-parametric, rule-based | **No** (Scale-invariant) | $O(N \cdot D \log N)$ | $O(\text{Tree Depth})$ (Very fast) | High (visual if-else rules) |
| **Logistic Regression** | Parametric, linear boundary | **Yes** (For regularization / gradient descent) | $O(N \cdot D)$ | $O(D)$ (Single dot product, extremely fast) | High (feature coefficients) |
| **Random Forest** | Ensemble of trees | **No** (Scale-invariant) | $O(M \cdot N \cdot D \log N)$ | $O(M \cdot \text{Depth})$ | Medium (feature importances) |
| **Support Vector Machine (SVM)** | Maximum margin boundary | **Yes** (Strictly required) | $O(N^2 \cdot D)$ to $O(N^3)$ | $O(N_{\text{support}} \cdot D)$ | Low to Medium |

### Instance-Based vs. Eager Learning
- **Eager Learners (Decision Trees, Logistic Regression, Neural Networks)**: Spend significant computational effort during the `fit()` phase to distill data into a compact mathematical representation (a tree structure or weight vectors). Once fitted, the original training data can be discarded, and inference is lightning-fast.
- **Lazy Learners (KNN)**: Do zero mathematical work during `fit()`—they simply store the training points in memory. However, during `predict()`, they must compute distances between the query point and every single training point. On datasets with millions of rows, KNN becomes computationally prohibitive.

---

## 4. Relevant Code (from main.py, line 44)

```python
    model = Pipeline(
        [
            ("scale", StandardScaler()),
            ("knn", KNeighborsClassifier(n_neighbors=5)),
        ]
    )
```

---

## 5. Code Explanation
- In `main.py`, `Pipeline` is modular. Replacing `("knn", KNeighborsClassifier(n_neighbors=5))` with `("tree", DecisionTreeClassifier())` or `("lr", LogisticRegression())` requires altering only a single line of code!

---

## 6. Worked Example

Let's benchmark 4 different classifiers on our stratified fruit dataset:

```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

df = pd.read_csv("data/fruits.csv")
X = df[["sweetness", "weight_g", "size_cm", "color_score"]]
y = df["fruit"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

models = {
    "KNN (k=5)": Pipeline([("scale", StandardScaler()), ("knn", KNeighborsClassifier(5))]),
    "Decision Tree": DecisionTreeClassifier(random_state=42),
    "Logistic Regression": Pipeline([("scale", StandardScaler()), ("lr", LogisticRegression())]),
    "Random Forest": RandomForestClassifier(n_estimators=100, random_state=42),
}

print(f"{'Model':<22} | {'Test Accuracy':<15} | {'Mystery Prediction'}")
print("-" * 55)

mystery = pd.DataFrame([{"sweetness": 7.2, "weight_g": 170, "size_cm": 8.5, "color_score": 8.0}])

for name, clf in models.items():
    clf.fit(X_train, y_train)
    acc = accuracy_score(y_test, clf.predict(X_test))
    pred = clf.predict(mystery)[0]
    print(f"{name:<22} | {acc:<15.1%} | {pred}")
```

**Output:**
```text
Model                  | Test Accuracy   | Mystery Prediction
-------------------------------------------------------
KNN (k=5)              | 100.0%          | apple
Decision Tree          | 100.0%          | apple
Logistic Regression    | 100.0%          | apple
Random Forest          | 100.0%          | apple
```

All 4 major algorithms achieve 100% test accuracy and agree that the mystery fruit is an apple, confirming the strong separability of the feature distributions!

---

## 7. Step-by-Step Student Instructions

1. Open your terminal in `beginner-projects-main/AI-ML Beginners/projects/05_fruit_sorter`.
2. Launch Python: `python3`.
3. Import `DecisionTreeClassifier` from `sklearn.tree`.
4. Fit a `DecisionTreeClassifier()` directly on `X_train, y_train` without scaling.
5. Predict on `X_test` and check accuracy: `accuracy_score(y_test, tree.predict(X_test))`.
6. Confirm it also achieves 100.0%.

---

## 8. Expected Output or Observable Behaviour

The decision tree achieves 100.0% accuracy on raw, unscaled features, demonstrating its scale-invariant nature.

---

## 9. Practical Exercises

- **Exercise 3.1**: Inspect the decision tree rules using `from sklearn.tree import export_text; print(export_text(tree, feature_names=FEATURES))`.
- **Exercise 3.2**: Why would Logistic Regression fail if two classes were arranged in concentric circles (non-linearly separable)?
- **Exercise 3.3**: If your dataset had 10,000,000 fruit records, why would a Decision Tree be preferred over KNN for high-speed conveyor belt sorting?
- **Exercise 3.4**: Why does Random Forest not require feature scaling?

---

## 10. Common Mistakes and Debugging

| Mistake | Why it is incorrect | Correction |
|---|---|---|
| Assuming KNN is always the best model | KNN scales poorly to large datasets ($O(N)$ query time) and high dimensions | Choose models based on dataset size and latency requirements |
| Scaling features for Decision Trees | Unnecessary; trees evaluate relative ordering, not geometric distance | Trees can be trained directly on raw features |
| Forgetting random_state on Decision Trees | Tree split ties involve pseudo-random selection | Set `random_state=42` for reproducible trees |

---

## 11. Best Practices and Security Considerations

- **Benchmark Multiple Families**: Always benchmark instance-based models against linear models and tree-based ensembles.
- **Latency Constraints**: In real-time edge devices (e.g. Raspberry Pi on a conveyor belt), prioritize models with $O(1)$ inference time.
- **Model Size Auditing**: Verify memory footprint before deploying models to memory-constrained embedded hardware.

---

## 12. Summary

Comparing K-Nearest Neighbours to Decision Trees, Logistic Regression, and Random Forests highlights fundamental machine learning tradeoffs. While KNN offers intuitive proximity-based classification and instant training, eager learners offer faster inference on massive datasets. On our fruit dataset, all major classifiers achieve 100% accuracy and agree on the mystery fruit classification.

---

## 13. Knowledge-check Questions

1. Why does KNN require $O(N \cdot D)$ time during inference, whereas a Decision Tree requires only $O(\text{depth})$?
2. Which family of machine learning algorithms is scale-invariant and does not require `StandardScaler`?
3. What is the fundamental difference between an eager learner and a lazy learner?
4. What prediction did Decision Trees, Logistic Regression, and Random Forests make on the mystery fruit?
5. On a dataset with 5 million rows, why might KNN be unsuitable for sub-millisecond conveyor sorting?

---

## 14. References

- scikit-learn Classifier Comparison: [https://scikit-learn.org/stable/auto_examples/classification/plot_classifier_comparison.html](https://scikit-learn.org/stable/auto_examples/classification/plot_classifier_comparison.html)
- Decision Trees Guide: [https://scikit-learn.org/stable/modules/tree.html](https://scikit-learn.org/stable/modules/tree.html)
- `main.py` lines 41-50
