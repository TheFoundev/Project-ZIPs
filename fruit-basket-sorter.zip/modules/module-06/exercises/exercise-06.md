# Module 6 Exercises: Complete Pipeline & Running

---

## Exercise 6.1: End-to-End Execution & Artifact Audit (10 min)
**Objective:** Run `main.py` and programmatically audit the generated artifacts to confirm exit code 0 and file generation.  
**Problem Statement:** Write an automated audit test that executes `main.py` via subprocess and verifies that all expected output files exist and are non-empty.

**Requirements:**
1. Use Python's `subprocess.run()` to execute `python main.py`.
2. Check that `returncode == 0`.
3. Check that `outputs/fruit_scatter.png` exists and size is $> 20\text{ KB}$.
4. Check that `outputs/confusion_matrix.png` exists and size is $> 15\text{ KB}$.
5. Check that `outputs/metrics.txt` exists and contains `"accuracy: 1.0000"`.
6. Print `"All audit checks passed successfully!"`.

**Constraints:** Use standard Python libraries (`subprocess`, `pathlib`).

**Expected Behaviour:** Test script completes with affirmative confirmation output.

**Acceptance Criteria:**
- [ ] Subprocess executes with returncode 0.
- [ ] All three files verified with `pathlib.Path.is_file()`.
- [ ] Minimum file size thresholds verified.

**Hints:**
- Use `p.stat().st_size` to inspect file size in bytes.

**Difficulty:** Basic  
**Estimated Completion Time:** 10 minutes  

---

## Exercise 6.2: Parsing & Validating outputs/metrics.txt (15 min)
**Objective:** Parse the generated `outputs/metrics.txt` file and assert that key production metrics exceed required service level agreements (SLAs).  
**Problem Statement:** In an MLOps pipeline, write an automated validation script that reads `metrics.txt` and fails if accuracy is below 95% or if mystery prediction is not apple.

**Requirements:**
1. Read `outputs/metrics.txt` using `Path.read_text(encoding="utf-8")`.
2. Parse the accuracy value from line 1.
3. Parse the mystery prediction class and confidence from line 2.
4. Assert that `accuracy >= 0.95`.
5. Assert that `prediction == "apple"`.
6. Assert that `confidence >= 0.90`.
7. Print a formatted summary of parsed metrics.

**Constraints:** Script must raise an `AssertionError` if any SLA fails.

**Expected Behaviour:** Successful script execution confirming all assertions pass.

**Acceptance Criteria:**
- [ ] Accuracy extracted as a float and verified.
- [ ] Prediction extracted as string and verified.
- [ ] Confidence extracted as float and verified.
- [ ] Clean error messaging if assertions fail.

**Hints:**
- Use regex or string `split(":")` to extract numbers cleanly.

**Difficulty:** Basic  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 6.3: Benchmarking Classifiers: KNN vs Decision Tree (15 min)
**Objective:** Compare KNN against a Decision Tree on the fruit dataset and evaluate differences in scaling requirements.  
**Problem Statement:** Train two models on `X_train, y_train`:
1. Model A: Pipeline with `StandardScaler` and `KNeighborsClassifier(n_neighbors=5)`
2. Model B: `DecisionTreeClassifier(random_state=42)` on raw, unscaled features

Compare test accuracy, inference time on 1,000 synthetic queries, and export decision tree rules.

**Requirements:**
1. Train both models on identical stratified splits.
2. Verify test accuracy for both models.
3. Generate 1,000 synthetic fruit queries using `np.random`.
4. Measure and print the elapsed inference time for both models.
5. Print the text rules of the decision tree using `export_text`.

**Constraints:** Use `scikit-learn.tree.DecisionTreeClassifier` and `time.perf_counter()`.

**Expected Behaviour:** Console output showing identical accuracy but highlighting inference speed differences.

**Acceptance Criteria:**
- [ ] Both models achieve 100% test accuracy.
- [ ] Inference time measured for 1,000 samples.
- [ ] Decision tree rules printed showing feature split thresholds.

**Hints:**
- `from sklearn.tree import export_text`

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  

---

## Exercise 6.4: Pipeline Serialization with joblib (15 min)
**Objective:** Serialize the trained fruit sorter pipeline to disk and reload it for standalone inference.  
**Problem Statement:** Package the trained scikit-learn pipeline into a portable `.joblib` binary file and build an inference function that loads the model and classifies query dictionaries.

**Requirements:**
1. Fit the pipeline on `fruits.csv`.
2. Save the pipeline to `outputs/fruit_pipeline.joblib` using `joblib.dump()`.
3. Write a standalone Python function `def classify_fruit(query_dict: dict) -> dict:` that:
   - Loads the pipeline from disk.
   - Formats `query_dict` as a single-row DataFrame.
   - Returns a dictionary `{"class": prediction, "confidence": probability}`.
4. Test the function on the mystery fruit: `{"sweetness": 7.2, "weight_g": 170, "size_cm": 8.5, "color_score": 8.0}`.
5. Verify the function returns `{"class": "apple", "confidence": 1.0}`.

**Constraints:** Must use `joblib` and `pandas`.

**Expected Behaviour:** Standalone inference function executes successfully and returns expected prediction dictionary.

**Acceptance Criteria:**
- [ ] Model saved using `joblib.dump()`.
- [ ] Standalone function successfully reloads model.
- [ ] Inference output verified matching `main.py`.

**Hints:**
- `loaded_model = joblib.load("outputs/fruit_pipeline.joblib")`

**Difficulty:** Intermediate  
**Estimated Completion Time:** 15 minutes  
